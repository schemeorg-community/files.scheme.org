/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:40
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: c-backend.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[868];
static double C_possibly_force_alignment;


#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2152(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2152(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2148(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2148(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(f_6813)
static void C_ccall f_6813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_fcall f_4776(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8111)
static void C_fcall f_8111(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6801)
static void C_fcall f_6801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_ccall f_4754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8121)
static void C_ccall f_8121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5979)
static void C_ccall f_5979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10701)
static void C_ccall f_10701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4933)
static void C_fcall f_4933(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7259)
static void C_fcall f_7259(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7257)
static void C_ccall f_7257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10710)
static C_word C_fcall f_10710(C_word *a,C_word t0);
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_fcall f_3899(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6841)
static void C_fcall f_6841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7343)
static void C_ccall f_7343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5985)
static void C_ccall f_5985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7353)
static void C_ccall f_7353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4600)
static void C_ccall f_4600(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7214)
static void C_ccall f_7214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7323)
static void C_ccall f_7323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7326)
static void C_ccall f_7326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_fcall f_3143(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7220)
static void C_ccall f_7220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8868)
static void C_ccall f_8868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7234)
static void C_fcall f_7234(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_fcall f_5112(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_fcall f_5116(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7244)
static void C_ccall f_7244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8872)
static void C_ccall f_8872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8890)
static void C_ccall f_8890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_fcall f_2651(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8892)
static void C_fcall f_8892(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5541)
static void C_fcall f_5541(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_fcall f_2654(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10201)
static void C_ccall f_10201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8439)
static void C_fcall f_8439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8087)
static void C_ccall f_8087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10250)
static void C_fcall f_10250(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8081)
static void C_ccall f_8081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_2639)
static void C_fcall f_2639(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8078)
static void C_ccall f_8078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3510)
static void C_fcall f_3510(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3547)
static void C_fcall f_3547(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5712)
static void C_ccall f_5712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10246)
static void C_ccall f_10246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5703)
static void C_ccall f_5703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5718)
static void C_ccall f_5718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5709)
static void C_ccall f_5709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10225)
static void C_ccall f_10225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6012)
static void C_fcall f_6012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10222)
static void C_ccall f_10222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_fcall f_2606(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6587)
static void C_fcall f_6587(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_fcall f_7074(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7473)
static void C_fcall f_7473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11805)
static void C_ccall f11805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_fcall f_4906(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_fcall f_6803(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7466)
static void C_fcall f_7466(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11813)
static void C_ccall f11813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_fcall f_4866(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6578)
static void C_ccall f_6578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5233)
static void C_ccall f_5233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5230)
static void C_ccall f_5230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6575)
static void C_ccall f_6575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6572)
static void C_ccall f_6572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_fcall f_4594(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6566)
static void C_ccall f_6566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6560)
static void C_ccall f_6560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6563)
static void C_ccall f_6563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_fcall f_4626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_fcall f_4629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10213)
static void C_ccall f_10213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10219)
static void C_ccall f_10219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9571)
static void C_ccall f_9571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7201)
static void C_ccall f_7201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5676)
static void C_fcall f_5676(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5670)
static void C_fcall f_5670(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9598)
static void C_fcall f_9598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8109)
static void C_ccall f_8109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9562)
static void C_fcall f_9562(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10433)
static void C_ccall f_10433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10436)
static void C_ccall f_10436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10430)
static void C_ccall f_10430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3635)
static void C_fcall f_3635(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9916)
static void C_ccall f_9916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9918)
static void C_fcall f_9918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7036)
static void C_ccall f_7036(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8733)
static void C_ccall f_8733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7045)
static void C_fcall f_7045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8702)
static void C_ccall f_8702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8704)
static void C_fcall f_8704(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7183)
static void C_ccall f_7183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10448)
static void C_ccall f_10448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7155)
static void C_ccall f_7155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7157)
static void C_ccall f_7157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10454)
static void C_ccall f_10454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10457)
static void C_ccall f_10457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7161)
static void C_ccall f_7161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10763)
static void C_ccall f_10763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10424)
static void C_ccall f_10424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6891)
static void C_ccall f_6891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6894)
static void C_ccall f_6894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7191)
static void C_fcall f_7191(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9997)
static void C_ccall f_9997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9994)
static void C_ccall f_9994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5726)
static void C_ccall f_5726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9991)
static void C_ccall f_9991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5361)
static void C_fcall f_5361(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5379)
static void C_ccall f_5379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5376)
static void C_ccall f_5376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7612)
static void C_fcall f_7612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8066)
static void C_ccall f_8066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8069)
static void C_ccall f_8069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5367)
static void C_ccall f_5367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7621)
static void C_fcall f_7621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8063)
static void C_ccall f_8063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8060)
static void C_ccall f_8060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_fcall f_5199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8054)
static void C_ccall f_8054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8057)
static void C_ccall f_8057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7633)
static void C_fcall f_7633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7131)
static void C_ccall f_7131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7139)
static void C_ccall f_7139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7645)
static void C_fcall f_7645(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7141)
static void C_ccall f_7141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5143)
static void C_ccall f_5143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5146)
static void C_ccall f_5146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5140)
static void C_ccall f_5140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9331)
static void C_fcall f_9331(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_fcall f_4414(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6200)
static void C_fcall f_6200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6237)
static void C_ccall f_6237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6234)
static void C_ccall f_6234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6216)
static void C_ccall f_6216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6219)
static void C_ccall f_6219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8683)
static void C_ccall f_8683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4746)
static void C_ccall f_4746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8687)
static void C_ccall f_8687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10273)
static void C_fcall f_10273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6073)
static void C_fcall f_6073(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10288)
static void C_ccall f_10288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8747)
static void C_fcall f_8747(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6068)
static void C_ccall f_6068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6058)
static void C_fcall f_6058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4381)
static void C_ccall f_4381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5441)
static void C_ccall f_5441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_fcall f_5442(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8672)
static void C_fcall f_8672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8666)
static void C_ccall f_8666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6506)
static void C_ccall f_6506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6509)
static void C_ccall f_6509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6500)
static void C_ccall f_6500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6776)
static void C_fcall f_6776(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4378)
static void C_ccall f_4378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6089)
static void C_fcall f_6089(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8210)
static void C_ccall f_8210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8216)
static void C_ccall f_8216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10072)
static void C_ccall f_10072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8221)
static void C_ccall f_8221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10171)
static void C_ccall f_10171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10174)
static void C_ccall f_10174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6546)
static void C_ccall f_6546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10177)
static void C_ccall f_10177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10087)
static void C_ccall f_10087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5923)
static void C_fcall f_5923(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10189)
static void C_ccall f_10189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8240)
static void C_ccall f_8240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_fcall f_5885(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10195)
static void C_ccall f_10195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10198)
static void C_ccall f_10198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6518)
static void C_ccall f_6518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_fcall f_5009(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7602)
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10294)
static void C_ccall f_10294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10297)
static void C_ccall f_10297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10138)
static void C_ccall f_10138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10144)
static void C_ccall f_10144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6249)
static void C_ccall f_6249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6243)
static void C_ccall f_6243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10147)
static void C_ccall f_10147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5916)
static void C_fcall f_5916(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2859)
static void C_fcall f_2859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10150)
static void C_ccall f_10150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5583)
static void C_fcall f_5583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5580)
static void C_fcall f_5580(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10165)
static void C_ccall f_10165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_fcall f_6225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6222)
static void C_ccall f_6222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5564)
static void C_ccall f_5564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10484)
static void C_ccall f_10484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10481)
static void C_ccall f_10481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_fcall f_4705(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10066)
static void C_ccall f_10066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10060)
static void C_ccall f_10060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10069)
static void C_ccall f_10069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10033)
static void C_fcall f_10033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10036)
static void C_ccall f_10036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10460)
static void C_ccall f_10460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10045)
static void C_ccall f_10045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10042)
static void C_ccall f_10042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10048)
static void C_ccall f_10048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5856)
static void C_ccall f_5856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10093)
static void C_ccall f_10093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10096)
static void C_ccall f_10096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10099)
static void C_ccall f_10099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9303)
static void C_fcall f_9303(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9301)
static void C_ccall f_9301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4986)
static void C_fcall f_4986(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9663)
static void C_ccall f_9663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10935)
static void C_ccall f_10935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_fcall f_3425(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5629)
static void C_fcall f_5629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10472)
static void C_ccall f_10472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10478)
static void C_ccall f_10478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6532)
static void C_ccall f_6532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6276)
static void C_ccall f_6276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6279)
static void C_ccall f_6279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6270)
static void C_ccall f_6270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6273)
static void C_ccall f_6273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6521)
static void C_ccall f_6521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3419)
static void C_fcall f_3419(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5907)
static void C_ccall f_5907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6261)
static void C_ccall f_6261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6294)
static void C_fcall f_6294(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7407)
static void C_ccall f_7407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6412)
static void C_ccall f_6412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7444)
static void C_ccall f_7444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10345)
static void C_ccall f_10345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7448)
static void C_ccall f_7448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10342)
static void C_ccall f_10342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10348)
static void C_ccall f_10348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6967)
static void C_ccall f_6967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6964)
static void C_ccall f_6964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8805)
static void C_ccall f_8805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_ccall f_6365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7413)
static void C_ccall f_7413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7416)
static void C_ccall f_7416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10312)
static void C_ccall f_10312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10318)
static void C_ccall f_10318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6958)
static void C_ccall f_6958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8815)
static void C_fcall f_8815(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6986)
static void C_ccall f_6986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6983)
static void C_ccall f_6983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8460)
static void C_fcall f_8460(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8822)
static void C_ccall f_8822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10336)
static void C_ccall f_10336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6979)
static void C_ccall f_6979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6970)
static void C_ccall f_6970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8832)
static void C_fcall f_8832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8839)
static void C_ccall f_8839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10015)
static void C_ccall f_10015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10018)
static void C_ccall f_10018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_ccall f_6995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6992)
static void C_ccall f_6992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8191)
static void C_ccall f_8191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8195)
static void C_ccall f_8195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10324)
static void C_ccall f_10324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10321)
static void C_ccall f_10321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10021)
static void C_ccall f_10021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8198)
static void C_ccall f_8198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8160)
static void C_ccall f_8160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5633)
static void C_ccall f_5633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8178)
static void C_ccall f_8178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8168)
static void C_fcall f_8168(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6383)
static void C_fcall f_6383(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10300)
static void C_ccall f_10300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5298)
static void C_ccall f_5298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_fcall f_3931(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5270)
static void C_fcall f_5270(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_ccall f_7004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7000)
static void C_ccall f_7000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7556)
static void C_fcall f_7556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7026)
static void C_ccall f_7026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_fcall f_4837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7263)
static void C_ccall f_7263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7266)
static void C_ccall f_7266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7269)
static void C_ccall f_7269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6726)
static void C_fcall f_6726(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7275)
static void C_ccall f_7275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7278)
static void C_ccall f_7278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7287)
static void C_ccall f_7287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7281)
static void C_ccall f_7281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8849)
static void C_fcall f_8849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6446)
static void C_ccall f_6446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8771)
static void C_ccall f_8771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9985)
static void C_ccall f_9985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10009)
static void C_ccall f_10009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10965)
static void C_ccall f_10965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8788)
static void C_ccall f_8788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_fcall f_3968(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10114)
static void C_ccall f_10114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8781)
static void C_fcall f_8781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10977)
static void C_ccall f_10977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10123)
static void C_ccall f_10123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10126)
static void C_ccall f_10126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10120)
static void C_ccall f_10120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9553)
static void C_fcall f_9553(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10979)
static void C_ccall f_10979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11009)
static void C_ccall f_11009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11003)
static void C_ccall f_11003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8764)
static void C_fcall f_8764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11018)
static void C_ccall f_11018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8798)
static void C_fcall f_8798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11012)
static void C_ccall f_11012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11015)
static void C_ccall f_11015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7293)
static void C_ccall f_7293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7299)
static void C_ccall f_7299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11028)
static void C_ccall f_11028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7290)
static void C_ccall f_7290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2569)
static void C_fcall f_2569(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6359)
static void C_ccall f_6359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11021)
static void C_ccall f_11021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11024)
static void C_ccall f_11024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6347)
static void C_ccall f_6347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6344)
static void C_ccall f_6344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8331)
static void C_fcall f_8331(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_fcall f_5032(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6316)
static void C_ccall f_6316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7548)
static void C_ccall f_7548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6338)
static void C_ccall f_6338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6335)
static void C_ccall f_6335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6326)
static void C_fcall f_6326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5495)
static void C_fcall f_5495(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7594)
static void C_ccall f_7594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6144)
static void C_ccall f_6144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7591)
static void C_ccall f_7591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5061)
static void C_fcall f_5061(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6134)
static void C_fcall f_6134(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5768)
static void C_ccall f_5768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10372)
static void C_ccall f_10372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7579)
static void C_ccall f_7579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5348)
static void C_ccall f_5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7585)
static void C_ccall f_7585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7581)
static void C_fcall f_7581(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5325)
static void C_fcall f_5325(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_fcall f_5322(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10393)
static void C_ccall f_10393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_fcall f_5338(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10396)
static void C_ccall f_10396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10390)
static void C_ccall f_10390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10369)
static void C_ccall f_10369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10366)
static void C_ccall f_10366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10360)
static void C_ccall f_10360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7688)
static void C_fcall f_7688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5798)
static void C_fcall f_5798(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6946)
static void C_ccall f_6946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6949)
static void C_ccall f_6949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6942)
static void C_ccall f_6942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6939)
static void C_ccall f_6939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8649)
static void C_ccall f_8649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8261)
static void C_fcall f_8261(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8252)
static void C_ccall f_8252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10384)
static void C_ccall f_10384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9358)
static void C_fcall f_9358(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8256)
static void C_fcall f_8256(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10878)
static void C_ccall f_10878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5838)
static void C_ccall f_5838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10883)
static void C_ccall f_10883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7655)
static void C_fcall f_7655(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7651)
static void C_ccall f_7651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5094)
static void C_fcall f_5094(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10896)
static void C_ccall f_10896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4263)
static void C_ccall f_4263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7335)
static void C_ccall f_7335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7339)
static void C_ccall f_7339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6109)
static void C_ccall f_6109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_fcall f_5518(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7302)
static void C_ccall f_7302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7305)
static void C_ccall f_7305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7308)
static void C_ccall f_7308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7311)
static void C_ccall f_7311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7314)
static void C_ccall f_7314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6124)
static void C_ccall f_6124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5505)
static void C_ccall f_5505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6666)
static void C_fcall f_6666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8638)
static void C_fcall f_8638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4305)
static void C_ccall f_4305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4308)
static void C_ccall f_4308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8580)
static void C_fcall f_8580(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_fcall f_3769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8599)
static void C_fcall f_8599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7386)
static void C_ccall f_7386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7380)
static void C_ccall f_7380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8655)
static void C_fcall f_8655(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3745)
static void C_ccall f_3745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6908)
static void C_ccall f_6908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8568)
static void C_fcall f_8568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_fcall f_3115(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6844)
static void C_ccall f_6844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4771)
static void C_ccall f_4771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11032)
static void C_ccall f_11032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8921)
static void C_ccall f_8921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11036)
static void C_ccall f_11036(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_4776)
static void C_fcall trf_4776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4776(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4776(t0,t1,t2);}

C_noret_decl(trf_8111)
static void C_fcall trf_8111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8111(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8111(t0,t1,t2,t3);}

C_noret_decl(trf_6801)
static void C_fcall trf_6801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6801(t0,t1);}

C_noret_decl(trf_4933)
static void C_fcall trf_4933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4933(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4933(t0,t1,t2);}

C_noret_decl(trf_7259)
static void C_fcall trf_7259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7259(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7259(t0,t1,t2);}

C_noret_decl(trf_3899)
static void C_fcall trf_3899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3899(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3899(t0,t1,t2,t3);}

C_noret_decl(trf_6841)
static void C_fcall trf_6841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6841(t0,t1);}

C_noret_decl(trf_3143)
static void C_fcall trf_3143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3143(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3143(t0,t1,t2,t3);}

C_noret_decl(trf_7234)
static void C_fcall trf_7234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7234(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7234(t0,t1,t2);}

C_noret_decl(trf_5112)
static void C_fcall trf_5112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5112(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5112(t0,t1);}

C_noret_decl(trf_5116)
static void C_fcall trf_5116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5116(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5116(t0,t1,t2);}

C_noret_decl(trf_2651)
static void C_fcall trf_2651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2651(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2651(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8892)
static void C_fcall trf_8892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8892(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8892(t0,t1,t2);}

C_noret_decl(trf_5541)
static void C_fcall trf_5541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5541(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5541(t0,t1,t2);}

C_noret_decl(trf_2654)
static void C_fcall trf_2654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2654(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2654(t0,t1,t2,t3);}

C_noret_decl(trf_8439)
static void C_fcall trf_8439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8439(t0,t1);}

C_noret_decl(trf_10250)
static void C_fcall trf_10250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10250(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10250(t0,t1,t2);}

C_noret_decl(trf_2639)
static void C_fcall trf_2639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2639(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2639(t0,t1,t2);}

C_noret_decl(trf_3510)
static void C_fcall trf_3510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3510(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3510(t0,t1,t2,t3);}

C_noret_decl(trf_3547)
static void C_fcall trf_3547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3547(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3547(t0,t1,t2,t3);}

C_noret_decl(trf_6012)
static void C_fcall trf_6012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6012(t0,t1);}

C_noret_decl(trf_2606)
static void C_fcall trf_2606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2606(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2606(t0,t1,t2);}

C_noret_decl(trf_6587)
static void C_fcall trf_6587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6587(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6587(t0,t1);}

C_noret_decl(trf_7074)
static void C_fcall trf_7074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7074(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7074(t0,t1);}

C_noret_decl(trf_7473)
static void C_fcall trf_7473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7473(t0,t1);}

C_noret_decl(trf_4906)
static void C_fcall trf_4906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4906(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4906(t0,t1,t2);}

C_noret_decl(trf_6803)
static void C_fcall trf_6803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6803(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6803(t0,t1,t2,t3);}

C_noret_decl(trf_7466)
static void C_fcall trf_7466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7466(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7466(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4866)
static void C_fcall trf_4866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4866(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4866(t0,t1,t2,t3);}

C_noret_decl(trf_4594)
static void C_fcall trf_4594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4594(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4594(t0,t1,t2,t3);}

C_noret_decl(trf_4626)
static void C_fcall trf_4626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4626(t0,t1);}

C_noret_decl(trf_4629)
static void C_fcall trf_4629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4629(t0,t1);}

C_noret_decl(trf_5676)
static void C_fcall trf_5676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5676(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5676(t0,t1,t2,t3);}

C_noret_decl(trf_5670)
static void C_fcall trf_5670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5670(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5670(t0,t1);}

C_noret_decl(trf_9598)
static void C_fcall trf_9598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9598(t0,t1);}

C_noret_decl(trf_9562)
static void C_fcall trf_9562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9562(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9562(t0,t1);}

C_noret_decl(trf_3635)
static void C_fcall trf_3635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3635(t0,t1);}

C_noret_decl(trf_9918)
static void C_fcall trf_9918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9918(t0,t1);}

C_noret_decl(trf_7045)
static void C_fcall trf_7045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7045(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7045(t0,t1,t2);}

C_noret_decl(trf_8704)
static void C_fcall trf_8704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8704(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8704(t0,t1,t2);}

C_noret_decl(trf_7191)
static void C_fcall trf_7191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7191(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7191(t0,t1,t2);}

C_noret_decl(trf_5361)
static void C_fcall trf_5361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5361(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5361(t0,t1,t2);}

C_noret_decl(trf_7612)
static void C_fcall trf_7612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7612(t0,t1);}

C_noret_decl(trf_7621)
static void C_fcall trf_7621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7621(t0,t1);}

C_noret_decl(trf_5199)
static void C_fcall trf_5199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5199(t0,t1);}

C_noret_decl(trf_7633)
static void C_fcall trf_7633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7633(t0,t1);}

C_noret_decl(trf_7645)
static void C_fcall trf_7645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7645(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7645(t0,t1);}

C_noret_decl(trf_9331)
static void C_fcall trf_9331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9331(t0,t1);}

C_noret_decl(trf_4414)
static void C_fcall trf_4414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4414(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4414(t0,t1,t2,t3);}

C_noret_decl(trf_6200)
static void C_fcall trf_6200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6200(t0,t1);}

C_noret_decl(trf_10273)
static void C_fcall trf_10273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10273(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10273(t0,t1);}

C_noret_decl(trf_6073)
static void C_fcall trf_6073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6073(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6073(t0,t1,t2,t3);}

C_noret_decl(trf_8747)
static void C_fcall trf_8747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8747(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8747(t0,t1);}

C_noret_decl(trf_6058)
static void C_fcall trf_6058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6058(t0,t1,t2);}

C_noret_decl(trf_5442)
static void C_fcall trf_5442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5442(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5442(t0,t1,t2);}

C_noret_decl(trf_8672)
static void C_fcall trf_8672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8672(t0,t1);}

C_noret_decl(trf_6776)
static void C_fcall trf_6776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6776(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6776(t0,t1,t2);}

C_noret_decl(trf_6089)
static void C_fcall trf_6089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6089(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6089(t0,t1);}

C_noret_decl(trf_5923)
static void C_fcall trf_5923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5923(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5923(t0,t1);}

C_noret_decl(trf_5885)
static void C_fcall trf_5885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5885(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5885(t0,t1,t2,t3);}

C_noret_decl(trf_5009)
static void C_fcall trf_5009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5009(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5009(t0,t1);}

C_noret_decl(trf_5916)
static void C_fcall trf_5916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5916(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5916(t0,t1,t2,t3);}

C_noret_decl(trf_2859)
static void C_fcall trf_2859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2859(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2859(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5583)
static void C_fcall trf_5583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5583(t0,t1);}

C_noret_decl(trf_5580)
static void C_fcall trf_5580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5580(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5580(t0,t1);}

C_noret_decl(trf_6225)
static void C_fcall trf_6225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6225(t0,t1);}

C_noret_decl(trf_4705)
static void C_fcall trf_4705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4705(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4705(t0,t1,t2);}

C_noret_decl(trf_10033)
static void C_fcall trf_10033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10033(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10033(t0,t1);}

C_noret_decl(trf_9303)
static void C_fcall trf_9303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9303(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9303(t0,t1);}

C_noret_decl(trf_4986)
static void C_fcall trf_4986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4986(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4986(t0,t1,t2);}

C_noret_decl(trf_3425)
static void C_fcall trf_3425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3425(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3425(t0,t1);}

C_noret_decl(trf_5629)
static void C_fcall trf_5629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5629(t0,t1);}

C_noret_decl(trf_3419)
static void C_fcall trf_3419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3419(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3419(t0,t1);}

C_noret_decl(trf_6294)
static void C_fcall trf_6294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6294(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6294(t0,t1);}

C_noret_decl(trf_8815)
static void C_fcall trf_8815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8815(t0,t1);}

C_noret_decl(trf_8460)
static void C_fcall trf_8460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8460(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8460(t0,t1);}

C_noret_decl(trf_8832)
static void C_fcall trf_8832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8832(t0,t1);}

C_noret_decl(trf_3472)
static void C_fcall trf_3472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3472(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3472(t0,t1,t2,t3);}

C_noret_decl(trf_8168)
static void C_fcall trf_8168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8168(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8168(t0,t1,t2);}

C_noret_decl(trf_6383)
static void C_fcall trf_6383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6383(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6383(t0,t1,t2,t3);}

C_noret_decl(trf_3931)
static void C_fcall trf_3931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3931(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3931(t0,t1,t2,t3);}

C_noret_decl(trf_5270)
static void C_fcall trf_5270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5270(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5270(t0,t1,t2);}

C_noret_decl(trf_7556)
static void C_fcall trf_7556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7556(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7556(t0,t1,t2);}

C_noret_decl(trf_4837)
static void C_fcall trf_4837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4837(t0,t1);}

C_noret_decl(trf_6726)
static void C_fcall trf_6726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6726(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6726(t0,t1);}

C_noret_decl(trf_8849)
static void C_fcall trf_8849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8849(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8849(t0,t1);}

C_noret_decl(trf_3968)
static void C_fcall trf_3968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3968(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3968(t0,t1,t2,t3);}

C_noret_decl(trf_8781)
static void C_fcall trf_8781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8781(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8781(t0,t1);}

C_noret_decl(trf_9553)
static void C_fcall trf_9553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9553(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9553(t0,t1);}

C_noret_decl(trf_8764)
static void C_fcall trf_8764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8764(t0,t1);}

C_noret_decl(trf_8798)
static void C_fcall trf_8798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8798(t0,t1);}

C_noret_decl(trf_2569)
static void C_fcall trf_2569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2569(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2569(t0,t1,t2);}

C_noret_decl(trf_8331)
static void C_fcall trf_8331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8331(t0,t1);}

C_noret_decl(trf_5032)
static void C_fcall trf_5032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5032(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5032(t0,t1,t2);}

C_noret_decl(trf_6326)
static void C_fcall trf_6326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6326(t0,t1);}

C_noret_decl(trf_5495)
static void C_fcall trf_5495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5495(t0,t1,t2);}

C_noret_decl(trf_5061)
static void C_fcall trf_5061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5061(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5061(t0,t1,t2);}

C_noret_decl(trf_6134)
static void C_fcall trf_6134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6134(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6134(t0,t1,t2,t3);}

C_noret_decl(trf_7581)
static void C_fcall trf_7581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7581(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7581(t0,t1,t2);}

C_noret_decl(trf_5325)
static void C_fcall trf_5325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5325(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5325(t0,t1);}

C_noret_decl(trf_5322)
static void C_fcall trf_5322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5322(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5322(t0,t1);}

C_noret_decl(trf_5338)
static void C_fcall trf_5338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5338(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5338(t0,t1,t2,t3);}

C_noret_decl(trf_7688)
static void C_fcall trf_7688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7688(t0,t1);}

C_noret_decl(trf_5798)
static void C_fcall trf_5798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5798(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5798(t0,t1,t2);}

C_noret_decl(trf_8261)
static void C_fcall trf_8261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8261(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8261(t0,t1,t2);}

C_noret_decl(trf_9358)
static void C_fcall trf_9358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9358(t0,t1);}

C_noret_decl(trf_8256)
static void C_fcall trf_8256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8256(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8256(t0,t1);}

C_noret_decl(trf_7655)
static void C_fcall trf_7655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7655(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7655(t0,t1,t2);}

C_noret_decl(trf_5094)
static void C_fcall trf_5094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5094(t0,t1);}

C_noret_decl(trf_5518)
static void C_fcall trf_5518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5518(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5518(t0,t1,t2);}

C_noret_decl(trf_6666)
static void C_fcall trf_6666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6666(t0,t1);}

C_noret_decl(trf_8638)
static void C_fcall trf_8638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8638(t0,t1);}

C_noret_decl(trf_8580)
static void C_fcall trf_8580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8580(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8580(t0,t1);}

C_noret_decl(trf_3769)
static void C_fcall trf_3769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3769(t0,t1);}

C_noret_decl(trf_8599)
static void C_fcall trf_8599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8599(t0,t1,t2);}

C_noret_decl(trf_8655)
static void C_fcall trf_8655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8655(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8655(t0,t1);}

C_noret_decl(trf_8568)
static void C_fcall trf_8568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8568(t0,t1);}

C_noret_decl(trf_3115)
static void C_fcall trf_3115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3115(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3115(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* k6811 in doloop972 in k6799 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_ccall f_6813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6813,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=C_a_i_minus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_6803(t4,((C_word*)t0)[5],t2,t3);}

/* map-loop514 in k4769 in k4756 in k4752 in k4748 in k4744 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_4776(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4776,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:476: g537 */
t5=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[226],t4,lf[227]);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* for-each-loop1494 in k8067 in k8064 in k8061 in k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8111(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8111,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8121,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
t9=t6;
t10=t7;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8078,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1122: foreign-result-conversion */
t12=*((C_word*)lf[168]+1);
f_9916(4,t12,t11,t8,lf[653]);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6799 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in ... */
static void C_fcall f_6801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6801,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6803,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6803(t5,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k4914 in doloop607 in k4883 in k4880 in k4874 in doloop596 in k4859 in k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4916,2,t0,t1);}
t2=C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4906(t3,((C_word*)t0)[4],t2);}

/* k4752 in k4748 in k4744 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4754,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:474: pad0 */
f_4629(t3,((C_word*)t0)[8]);}

/* k4748 in k4744 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:474: pad0 */
f_4629(t3,((C_word*)t0)[8]);}

/* k8119 in for-each-loop1494 in k8067 in k8064 in k8061 in k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_8111(t4,((C_word*)t0)[5],t2,t3);}

/* k5977 in k5927 in k5921 in gen-lit in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5979,2,t0,t1);}
t2=t1;
t3=C_block_size(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5985,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:706: gen */
t6=*((C_word*)lf[1]+1);
f_2549(5,t6,t5,C_SCHEME_TRUE,((C_word*)t0)[4],lf[361]);}

/* ##compiler#encode-literal in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10701,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10710,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10763,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t5)){
t6=t1;
t7=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1387: string-append */
t8=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,lf[850]);}
else{
t6=C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t6)){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1387: string-append */
t9=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,lf[851]);}
else{
if(C_truep(C_charp(t2))){
t7=C_fix(C_character_code(t2));
t8=f_10710(C_a_i(&a,24),t7);
/* ##sys#string-append */
t9=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t4,lf[852],t8);}
else{
if(C_truep(C_i_nullp(t2))){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1387: string-append */
t9=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,lf[853]);}
else{
if(C_truep(C_eofp(t2))){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1387: string-append */
t9=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,lf[854]);}
else{
t7=*((C_word*)lf[353]+1);
t8=C_eqp(*((C_word*)lf[353]+1),t2);
if(C_truep(t8)){
t9=t1;
t10=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1387: string-append */
t11=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[855]);}
else{
if(C_truep(C_fixnump(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10883,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1396: big-fixnum? */
t10=*((C_word*)lf[366]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
if(C_truep(C_i_numberp(t2))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10896,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1405: number->string */
C_number_to_string(3,0,t9,t2);}
else{
if(C_truep(C_i_symbolp(t2))){
t9=C_slot(t2,C_fix(1));
t10=C_i_string_length(t9);
t11=f_10710(C_a_i(&a,24),t10);
/* c-backend.scm:1408: string-append */
t12=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t4,lf[862],t11,t9);}
else{
if(C_truep(C_immp(t2))){
/* c-backend.scm:1413: bomb */
t9=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t4,lf[863],t2);}
else{
if(C_truep(C_byteblockp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10935,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=stub2148(C_SCHEME_UNDEFINED,t10);
t12=C_make_character(C_unfix(t11));
t13=C_a_i_string(&a,1,t12);
t14=t2;
t15=stub2152(C_SCHEME_UNDEFINED,t14);
t16=f_10710(C_a_i(&a,24),t15);
/* ##sys#string-append */
t17=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t9,t13,t16);}
else{
t9=t2;
t10=stub2152(C_SCHEME_UNDEFINED,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10965,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t12=t2;
t13=stub2148(C_SCHEME_UNDEFINED,t12);
t14=C_make_character(C_unfix(t13));
t15=C_a_i_string(&a,1,t14);
t16=t15;
t17=f_10710(C_a_i(&a,24),t10);
t18=t17;
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10977,a[2]=t11,a[3]=t16,a[4]=t18,tmp=(C_word)a,a+=5,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10979,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1426: list-tabulate */
t21=*((C_word*)lf[545]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,t10,t20);}}}}}}}}}}}}

/* doloop602 in k4880 in k4874 in doloop596 in k4859 in k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_4933(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4933,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4943,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_string_ref(((C_word*)t0)[4],t2);
t5=C_fix(C_character_code(t4));
/* c-backend.scm:526: gen */
t6=*((C_word*)lf[1]+1);
f_2549(4,t6,t3,C_make_character(44),t5);}}

/* k5200 in k5197 in k5147 in k5144 in k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in ... */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
/* c-backend.scm:570: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[3],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_5152(2,t3,t2);}}

/* k3188 in k3185 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:176: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[63]);}

/* g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7259(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7259,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7263,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1011: foreign-stub-id */
t4=*((C_word*)lf[597]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_a_i_plus(&a,2,t1,((C_word*)t0)[7]);
/* c-backend.scm:326: iota */
t4=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* ##compiler#generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7257,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7259,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_check_list_2(t2,lf[57]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7556,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_7556(t9,t1,t2);}

/* encode-size in encode-literal in k2629 in k2544 in k2541 in k2538 */
static C_word C_fcall f_10710(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_overflow_check;
t2=C_a_i_arithmetic_shift(&a,2,t1,C_fix(-16));
t3=C_a_i_bitwise_and(&a,2,C_fix(255),t2);
t4=C_make_character(C_unfix(t3));
t5=C_a_i_arithmetic_shift(&a,2,t1,C_fix(-8));
t6=C_a_i_bitwise_and(&a,2,C_fix(255),t5);
t7=C_make_character(C_unfix(t6));
t8=C_a_i_bitwise_and(&a,2,C_fix(255),t1);
t9=C_make_character(C_unfix(t8));
return(C_a_i_string(&a,3,t4,t7,t9));}

/* k3896 in k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3898,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_check_list_2(t2,lf[57]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3915,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3968,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3968(t9,t5,((C_word*)t0)[6],t2);}

/* g380 in k3896 in k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3899(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3899,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3903,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:329: gen */
t5=*((C_word*)lf[1]+1);
f_2549(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3185 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:175: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k6839 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in ... */
static void C_fcall f_6841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6841,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:790: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[481]);}
else{
t2=((C_word*)t0)[3];
f_6282(2,t2,C_SCHEME_UNDEFINED);}}

/* k5125 in g636 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7341 in k7337 in k7333 in k7471 in for-each-loop1241 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in ... */
static void C_ccall f_7343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1042: gen */
t2=*((C_word*)lf[1]+1);
f_2549(11,t2,((C_word*)t0)[2],C_SCHEME_TRUE,((C_word*)t0)[3],lf[565],((C_word*)t0)[4],C_make_character(41),t1,lf[566],((C_word*)t0)[5],lf[567]);}

/* k5983 in k5977 in k5927 in k5921 in gen-lit in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:707: gen */
t2=*((C_word*)lf[1]+1);
f_2549(9,t2,((C_word*)t0)[2],lf[359],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[5],lf[360]);}

/* k7345 in k7471 in for-each-loop1241 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in ... */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1043: foreign-type-declaration */
t2=*((C_word*)lf[174]+1);
f_8254(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k4941 in doloop602 in k4880 in k4874 in doloop596 in k4859 in k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4943,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4933(t3,((C_word*)t0)[4],t2);}

/* k7351 in k7471 in for-each-loop1241 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in ... */
static void C_ccall f_7353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7353,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7359,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1045: ##sys#write-char-0 */
t6=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_make_character(116),t3);}

/* k7357 in k7351 in k7471 in for-each-loop1241 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in ... */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1045: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5103,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:543: lambda-literal-direct */
t4=*((C_word*)lf[281]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[9]);}

/* k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:544: lambda-literal-allocated */
t4=*((C_word*)lf[280]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5109,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_greater_or_equalp(((C_word*)t0)[6],*((C_word*)lf[251]+1)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5298,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* c-backend.scm:546: lset-adjoin */
t6=*((C_word*)lf[252]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],t5);}
else{
t4=t3;
f_5112(t4,C_SCHEME_UNDEFINED);}}

/* k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5100,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5103,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:542: lambda-literal-rest-argument-mode */
t4=*((C_word*)lf[282]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}

/* k3151 in for-each-loop182 in k3126 in k3112 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3143(t4,((C_word*)t0)[5],t2,t3);}

/* a4599 in expr-args in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4600(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4600,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4604,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=C_i_car(t2);
/* c-backend.scm:456: expr */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2654(t6,t1,t5,((C_word*)t0)[3]);}
else{
/* c-backend.scm:455: gen */
t5=*((C_word*)lf[1]+1);
f_2549(3,t5,t3,C_make_character(44));}}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7214,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[57]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7234,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7234(t7,t1,t2);}

/* k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in ... */
static void C_ccall f_7323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:1039: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[570]);}

/* k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in ... */
static void C_ccall f_7326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7326,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7368,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:1048: iota */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[9]);}

/* k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in ... */
static void C_ccall f_7320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:1038: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[571]);}

/* k4602 in a4599 in expr-args in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[2]);
/* c-backend.scm:456: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2654(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5]);}

/* k7221 in k7218 in for-each-loop1190 in generate-foreign-callback-stub-prototypes in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1005: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* for-each-loop182 in k3126 in k3112 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3143(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3143,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3153,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:165: g183 */
t9=((C_word*)t0)[3];
f_3115(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7218 in for-each-loop1190 in generate-foreign-callback-stub-prototypes in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7223,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1004: generate-foreign-callback-header */
t3=*((C_word*)lf[548]+1);
f_8191(4,t3,t2,lf[549],((C_word*)t0)[3]);}

/* k3843 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:235: lambda-literal-closure-size */
t2=*((C_word*)lf[148]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3839 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3425(t2,C_i_zerop(t1));}

/* k8866 in k8847 in k8830 in k8813 in k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_8868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8868,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8872,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_check_list_2(((C_word*)t0)[5],lf[726]);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8890,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8892,a[2]=t7,a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_8892(t13,t9,((C_word*)t0)[5]);}

/* for-each-loop1190 in generate-foreign-callback-stub-prototypes in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7234(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7234,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7244,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7220,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1003: gen */
t8=*((C_word*)lf[1]+1);
f_2549(3,t8,t7,C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3132 in k3126 in k3112 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3134,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* c-backend.scm:171: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,((C_word*)t0)[3],lf[58],t2,lf[59]);}

/* k3832 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:240: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[146],t1,lf[147]);}

/* k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:552: lambda-literal-callee-signatures */
t4=*((C_word*)lf[279]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[12]);}

/* k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5112(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5112,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm:547: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,C_SCHEME_TRUE);}

/* k3126 in k3112 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3128,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[57]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3143,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3143(t7,t3,((C_word*)t0)[2],t1);}

/* g636 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5116(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5116,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greater_or_equalp(t2,*((C_word*)lf[251]+1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5127,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_plus(&a,2,t2,C_fix(1));
/* c-backend.scm:551: lset-adjoin */
t5=*((C_word*)lf[252]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3120 in k3117 in g183 in k3112 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:169: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k7242 in for-each-loop1190 in generate-foreign-callback-stub-prototypes in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7234(t3,((C_word*)t0)[4],t2);}

/* k3825 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:239: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[143],t1,lf[144]);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2518)){
C_save(t1);
C_rereclaim2(2518*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,868);
lf[0]=C_h_intern(&lf[0],15,"\010compileroutput");
lf[1]=C_h_intern(&lf[1],12,"\010compilergen");
lf[2]=C_h_intern(&lf[2],7,"newline");
lf[3]=C_h_intern(&lf[3],7,"display");
lf[4]=C_h_intern(&lf[4],17,"\010compilergen-list");
lf[5]=C_h_intern(&lf[5],11,"intersperse");
lf[6]=C_h_intern(&lf[6],18,"\010compilerunique-id");
lf[7]=C_h_intern(&lf[7],22,"\010compilergenerate-code");
lf[8]=C_h_intern(&lf[8],13,"\010compilerbomb");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[10]=C_h_intern(&lf[10],18,"\003syshash-table-ref");
lf[11]=C_h_intern(&lf[11],14,"\004coreimmediate");
lf[12]=C_h_intern(&lf[12],4,"bool");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[15]=C_h_intern(&lf[15],4,"char");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[17]=C_h_intern(&lf[17],3,"nil");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[19]=C_h_intern(&lf[19],3,"fix");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[21]=C_h_intern(&lf[21],3,"eof");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[24]=C_h_intern(&lf[24],12,"\004coreliteral");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[28]=C_h_intern(&lf[28],2,"if");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[32]=C_h_intern(&lf[32],9,"\004coreproc");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[34]=C_h_intern(&lf[34],9,"\004corebind");
lf[35]=C_h_intern(&lf[35],16,"\004corelet_unboxed");
lf[36]=C_h_intern(&lf[36],8,"\004coreref");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word\052)");
lf[39]=C_h_intern(&lf[39],10,"\004coreunbox");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word\052)");
lf[42]=C_h_intern(&lf[42],13,"\004coreupdate_i");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[44]=C_h_intern(&lf[44],11,"\004coreupdate");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate2(((C_word \052)");
lf[48]=C_h_intern(&lf[48],16,"\004coreupdatebox_i");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[51]=C_h_intern(&lf[51],14,"\004coreupdatebox");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate2(((C_word \052)");
lf[54]=C_h_intern(&lf[54],12,"\004coreclosure");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[57]=C_h_intern(&lf[57],8,"for-each");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[60]=C_h_intern(&lf[60],4,"iota");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\023(\052a=C_CLOSURE_TYPE|");
lf[62]=C_h_intern(&lf[62],8,"\004corebox");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\031(\052a=C_VECTOR_TYPE|1,a[1]=");
lf[65]=C_h_intern(&lf[65],10,"\004corelocal");
lf[66]=C_h_intern(&lf[66],13,"\004coresetlocal");
lf[67]=C_h_intern(&lf[67],11,"\004coreglobal");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[72]=C_h_intern(&lf[72],21,"\010compilerc-ify-string");
lf[73]=C_h_intern(&lf[73],28,"\003syssymbol->qualified-string");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\016\052((C_word\052)lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fast_retrieve(lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[78]=C_h_intern(&lf[78],14,"\004coresetglobal");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\012 /\052 (set! ");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) \052/,");
lf[81]=C_h_intern(&lf[81],21,"\010compileruncommentify");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\016C_mutate2(&lf[");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mutate2((C_word\052)lf[");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[86]=C_h_intern(&lf[86],16,"\004coresetglobal_i");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\005] /\052 ");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\005 \052/ =");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\005] /\052 ");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\006 \052/,0,");
lf[93]=C_h_intern(&lf[93],14,"\004coreundefined");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[95]=C_h_intern(&lf[95],9,"\004corecall");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[101]=C_h_intern(&lf[101],26,"lambda-literal-temporaries");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[103]=C_h_intern(&lf[103],22,"lambda-literal-looping");
lf[104]=C_h_intern(&lf[104],17,"lambda-literal-id");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[107]=C_h_intern(&lf[107],35,"\010compilerno-global-procedure-checks");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\024(void\052)(\052((C_word\052)(");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\005)+1))");
lf[110]=C_h_intern(&lf[110],13,"string-append");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\016\052((C_word\052)lf[");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fast_retrieve_proc(");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\030C_retrieve2_symbol_proc(");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fast_retrieve_proc(");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\016\052((C_word\052)lf[");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\037C_fast_retrieve_symbol_proc(lf[");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\016\052((C_word\052)lf[");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[134]=C_h_intern(&lf[134],6,"unsafe");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\024(void\052)(\052((C_word\052)t");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\026C_fast_retrieve_proc(t");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[139]=C_h_intern(&lf[139],28,"\010compilerno-procedure-checks");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[142]=C_h_intern(&lf[142],24,"\010compileremit-trace-info");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[145]=C_h_intern(&lf[145],17,"\010compilerslashify");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\003/\052 ");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\003 \052/");
lf[148]=C_h_intern(&lf[148],27,"lambda-literal-closure-size");
lf[149]=C_h_intern(&lf[149],28,"\010compilersource-info->string");
lf[150]=C_h_intern(&lf[150],12,"\004corerecurse");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[154]=C_h_intern(&lf[154],16,"\004coredirect_call");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[156]=C_h_intern(&lf[156],13,"\004corecallunit");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[161]=C_h_intern(&lf[161],11,"\004corereturn");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[164]=C_h_intern(&lf[164],11,"\004coreinline");
lf[165]=C_h_intern(&lf[165],20,"\004coreinline_allocate");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[167]=C_h_intern(&lf[167],15,"\004coreinline_ref");
lf[168]=C_h_intern(&lf[168],34,"\010compilerforeign-result-conversion");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[170]=C_h_intern(&lf[170],18,"\004coreinline_update");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[173]=C_h_intern(&lf[173],36,"\010compilerforeign-argument-conversion");
lf[174]=C_h_intern(&lf[174],33,"\010compilerforeign-type-declaration");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[176]=C_h_intern(&lf[176],19,"\004coreinline_loc_ref");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\003\052((");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\021\052)C_data_pointer(");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[182]=C_h_intern(&lf[182],22,"\004coreinline_loc_update");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\004((\052(");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\021\052)C_data_pointer(");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[188]=C_h_intern(&lf[188],16,"\004coreunboxed_ref");
lf[189]=C_h_intern(&lf[189],17,"\004coreunboxed_set!");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\002((");
lf[192]=C_h_intern(&lf[192],19,"\004coreinline_unboxed");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[194]=C_h_intern(&lf[194],11,"\004coreswitch");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[199]=C_h_intern(&lf[199],9,"\004corecond");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[203]=C_h_intern(&lf[203],13,"pair-for-each");
lf[204]=C_h_intern(&lf[204],17,"\003sysstring-append");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[206]=C_h_intern(&lf[206],30,"\010compilerexternal-protos-first");
lf[207]=C_h_intern(&lf[207],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[208]=C_h_intern(&lf[208],22,"foreign-callback-stubs");
lf[209]=C_h_intern(&lf[209],29,"\010compilerforeign-declarations");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\002\052/");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[212]=C_h_intern(&lf[212],28,"\010compilertarget-include-file");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[214]=C_h_intern(&lf[214],18,"\010compilerunit-name");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[216]=C_h_intern(&lf[216],19,"\010compilerused-units");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[218]=C_h_intern(&lf[218],27,"\010compilercompiler-arguments");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\022/\052 Generated from ");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\031   http://www.call-cc.org");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[224]=C_h_intern(&lf[224],18,"string-intersperse");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[228]=C_h_intern(&lf[228],12,"string-split");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[230]=C_h_intern(&lf[230],15,"chicken-version");
lf[231]=C_h_intern(&lf[231],18,"\003sysdecode-seconds");
lf[232]=C_h_intern(&lf[232],15,"current-seconds");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[237]=C_h_intern(&lf[237],23,"\003syslambda-info->string");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY \052create_ptable(void);");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[247]=C_h_intern(&lf[247],9,"make-list");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (\052C_proc");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[251]=C_h_intern(&lf[251],21,"small-parameter-limit");
lf[252]=C_h_intern(&lf[252],11,"lset-adjoin");
lf[253]=C_h_intern(&lf[253],1,"=");
lf[254]=C_h_intern(&lf[254],4,"none");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word \052a");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[265]=C_h_intern(&lf[265],8,"toplevel");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[279]=C_h_intern(&lf[279],32,"lambda-literal-callee-signatures");
lf[280]=C_h_intern(&lf[280],24,"lambda-literal-allocated");
lf[281]=C_h_intern(&lf[281],21,"lambda-literal-direct");
lf[282]=C_h_intern(&lf[282],33,"lambda-literal-rest-argument-mode");
lf[283]=C_h_intern(&lf[283],28,"lambda-literal-rest-argument");
lf[284]=C_h_intern(&lf[284],27,"\010compilermake-variable-list");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[286]=C_h_intern(&lf[286],27,"lambda-literal-customizable");
lf[287]=C_h_intern(&lf[287],29,"lambda-literal-argument-count");
lf[288]=C_h_intern(&lf[288],23,"\003syshash-table-for-each");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[295]=C_h_intern(&lf[295],27,"\010compilermake-argument-list");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n\0523);");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word \052a,t");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\016(void \052dummy){");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000 (void \052dummy) C_regparm C_noret;");
lf[335]=C_h_intern(&lf[335],23,"lambda-literal-external");
lf[336]=C_h_intern(&lf[336],7,"sprintf");
lf[337]=C_h_intern(&lf[337],17,"get-output-string");
lf[338]=C_h_intern(&lf[338],16,"\003syswrite-char-0");
lf[339]=C_h_intern(&lf[339],9,"\003sysprint");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[341]=C_h_intern(&lf[341],18,"open-output-string");
lf[342]=C_h_intern(&lf[342],25,"\010compilerwords-per-flonum");
lf[343]=C_h_intern(&lf[343],6,"reduce");
lf[344]=C_h_intern(&lf[344],1,"+");
lf[345]=C_h_intern(&lf[345],12,"vector->list");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[347]=C_h_intern(&lf[347],14,"\010compilerwords");
lf[348]=C_h_intern(&lf[348],15,"\003sysbytevector\077");
lf[349]=C_h_intern(&lf[349],32,"\010compilerblock-variable-literal\077");
lf[350]=C_h_intern(&lf[350],19,"\010compilerimmediate\077");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[353]=C_h_intern(&lf[353],19,"\003sysundefined-value");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[364]=C_h_intern(&lf[364],23,"\010compilerencode-literal");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[366]=C_h_intern(&lf[366],20,"\010compilerbig-fixnum\077");
lf[367]=C_h_intern(&lf[367],6,"modulo");
lf[368]=C_h_intern(&lf[368],14,"\003syscopy-bytes");
lf[369]=C_h_intern(&lf[369],11,"make-string");
lf[370]=C_h_intern(&lf[370],19,"lambda-literal-body");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word \052a=C_alloc(");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\005)\0523);");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\012((void\052)tr");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\012((void\052)tr");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\024\052sizeof(C_word), 1);");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void\052)toplevel_trampoline,NULL);}");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[419]=C_h_intern(&lf[419],26,"\010compilertarget-stack-size");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[422]=C_h_intern(&lf[422],25,"\010compilertarget-heap-size");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[426]=C_h_intern(&lf[426],40,"\010compilerdisable-stack-overflow-checking");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word \052a;");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[432]=C_h_intern(&lf[432],4,"fold");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c\052C_SIZEOF_PAIR+");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[435]=C_h_intern(&lf[435],28,"\010compilerinsert-timer-checks");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[440]=C_h_intern(&lf[440],23,"\010compilerno-argc-checks");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word \052a,c2=c;");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word \052a;");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\010],\052a=ab;");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\027C_stack_overflow_check;");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word \052a;");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[466]=C_h_intern(&lf[466],6,"fixnum");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[468]=C_h_intern(&lf[468],6,"flonum");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[471]=C_h_intern(&lf[471],7,"pointer");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\006void \052");
lf[473]=C_h_intern(&lf[473],3,"int");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid unboxed type");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word \052a");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[484]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void \052dummy) C_regparm C_noret;");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void \052dummy){");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\003/\052 ");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\003 \052/");
lf[498]=C_h_intern(&lf[498],16,"\010compilercleanup");
lf[499]=C_h_intern(&lf[499],18,"\010compilerdebugging");
lf[500]=C_h_intern(&lf[500],1,"o");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[504]=C_h_intern(&lf[504],34,"lambda-literal-unboxed-temporaries");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[507]=C_h_intern(&lf[507],18,"\010compilerreal-name");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\002/\052");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\002\052/");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\021/\052 end of file \052/");
lf[511]=C_h_intern(&lf[511],35,"\010compilercollected-debugging-output");
lf[512]=C_h_intern(&lf[512],25,"emit-procedure-table-info");
lf[513]=C_h_intern(&lf[513],31,"generate-foreign-callback-stubs");
lf[514]=C_h_intern(&lf[514],31,"\010compilergenerate-foreign-stubs");
lf[515]=C_h_intern(&lf[515],29,"\010compilerforeign-lambda-stubs");
lf[516]=C_h_intern(&lf[516],36,"\010compilergenerate-external-variables");
lf[517]=C_h_intern(&lf[517],27,"\010compilerexternal-variables");
lf[518]=C_h_intern(&lf[518],1,"p");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[520]=C_h_intern(&lf[520],31,"flonum-maximum-decimal-exponent");
lf[521]=C_h_intern(&lf[521],22,"flonum-print-precision");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\052static C_PTABLE_ENTRY \052create_ptable(void)");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void\052)");
lf[538]=C_h_intern(&lf[538],29,"\010compilerstring->c-identifier");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[542]=C_h_intern(&lf[542],19,"\003syshash-table-size");
lf[543]=C_h_intern(&lf[543],11,"string-copy");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[545]=C_h_intern(&lf[545],13,"list-tabulate");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[548]=C_h_intern(&lf[548],41,"\010compilergenerate-foreign-callback-header");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[561]=C_h_intern(&lf[561],4,"void");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[569]=C_h_intern(&lf[569],14,"symbol->string");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,\052C_a=(C_word\052)C_buf;");
lf[571]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[574]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[579]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[580]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[581]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[582]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[583]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[584]=C_decode_literal(C_heaptop,"\376B\000\000\010/\052 from ");
lf[585]=C_decode_literal(C_heaptop,"\376B\000\000\003 \052/");
lf[586]=C_h_intern(&lf[586],21,"foreign-stub-callback");
lf[587]=C_h_intern(&lf[587],16,"foreign-stub-cps");
lf[588]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[589]=C_h_intern(&lf[589],27,"foreign-stub-argument-names");
lf[590]=C_h_intern(&lf[590],17,"foreign-stub-body");
lf[591]=C_h_intern(&lf[591],17,"foreign-stub-name");
lf[592]=C_h_intern(&lf[592],24,"foreign-stub-return-type");
lf[593]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[594]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[595]=C_h_intern(&lf[595],27,"foreign-stub-argument-types");
lf[596]=C_h_intern(&lf[596],19,"\010compilerreal-name2");
lf[597]=C_h_intern(&lf[597],15,"foreign-stub-id");
lf[598]=C_h_intern(&lf[598],5,"float");
lf[599]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[600]=C_h_intern(&lf[600],8,"c-string");
lf[601]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[602]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[603]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[604]=C_h_intern(&lf[604],16,"nonnull-c-string");
lf[605]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[606]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[607]=C_h_intern(&lf[607],3,"ref");
lf[608]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[609]=C_h_intern(&lf[609],5,"const");
lf[610]=C_h_intern(&lf[610],9,"c-pointer");
lf[611]=C_h_intern(&lf[611],15,"nonnull-pointer");
lf[612]=C_h_intern(&lf[612],17,"nonnull-c-pointer");
lf[613]=C_h_intern(&lf[613],8,"function");
lf[614]=C_h_intern(&lf[614],8,"instance");
lf[615]=C_h_intern(&lf[615],16,"nonnull-instance");
lf[616]=C_h_intern(&lf[616],12,"instance-ref");
lf[617]=C_h_intern(&lf[617],27,"\010compilerforeign-type-table");
lf[618]=C_h_intern(&lf[618],17,"nonnull-c-string\052");
lf[619]=C_h_intern(&lf[619],25,"nonnull-unsigned-c-string");
lf[620]=C_h_intern(&lf[620],26,"nonnull-unsigned-c-string\052");
lf[621]=C_h_intern(&lf[621],6,"symbol");
lf[622]=C_h_intern(&lf[622],9,"c-string\052");
lf[623]=C_h_intern(&lf[623],17,"unsigned-c-string");
lf[624]=C_h_intern(&lf[624],18,"unsigned-c-string\052");
lf[625]=C_h_intern(&lf[625],6,"double");
lf[626]=C_h_intern(&lf[626],16,"unsigned-integer");
lf[627]=C_h_intern(&lf[627],18,"unsigned-integer32");
lf[628]=C_h_intern(&lf[628],4,"long");
lf[629]=C_h_intern(&lf[629],7,"integer");
lf[630]=C_h_intern(&lf[630],9,"integer32");
lf[631]=C_h_intern(&lf[631],13,"unsigned-long");
lf[632]=C_h_intern(&lf[632],6,"size_t");
lf[633]=C_h_intern(&lf[633],6,"number");
lf[634]=C_h_intern(&lf[634],18,"unsigned-integer64");
lf[635]=C_h_intern(&lf[635],9,"integer64");
lf[636]=C_h_intern(&lf[636],13,"c-string-list");
lf[637]=C_h_intern(&lf[637],14,"c-string-list\052");
lf[638]=C_h_intern(&lf[638],5,"int32");
lf[639]=C_h_intern(&lf[639],5,"short");
lf[640]=C_h_intern(&lf[640],14,"unsigned-short");
lf[641]=C_h_intern(&lf[641],13,"scheme-object");
lf[642]=C_h_intern(&lf[642],13,"unsigned-char");
lf[643]=C_h_intern(&lf[643],12,"unsigned-int");
lf[644]=C_h_intern(&lf[644],14,"unsigned-int32");
lf[645]=C_h_intern(&lf[645],4,"byte");
lf[646]=C_h_intern(&lf[646],13,"unsigned-byte");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void \052)");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[652]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[653]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[657]=C_decode_literal(C_heaptop,"\376B\000\000\004,\052a=");
lf[658]=C_decode_literal(C_heaptop,"\376B\000\000\020C_stack_pointer;");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\013C_alloc(s);");
lf[660]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[661]=C_decode_literal(C_heaptop,"\376B\000\000\010/\052 from ");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\003 \052/");
lf[663]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[664]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[665]=C_h_intern(&lf[665],36,"foreign-callback-stub-argument-types");
lf[666]=C_h_intern(&lf[666],33,"foreign-callback-stub-return-type");
lf[667]=C_h_intern(&lf[667],24,"foreign-callback-stub-id");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[669]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[670]=C_h_intern(&lf[670],32,"foreign-callback-stub-qualifiers");
lf[671]=C_h_intern(&lf[671],26,"foreign-callback-stub-name");
lf[672]=C_h_intern(&lf[672],13,"\010compilerquit");
lf[673]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[675]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[676]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[679]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\006size_t");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[683]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u64");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[690]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\006void \052");
lf[692]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char \052\052");
lf[693]=C_h_intern(&lf[693],4,"blob");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char \052");
lf[695]=C_h_intern(&lf[695],9,"u16vector");
lf[696]=C_h_intern(&lf[696],17,"nonnull-u16vector");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short \052");
lf[698]=C_h_intern(&lf[698],8,"s8vector");
lf[699]=C_h_intern(&lf[699],16,"nonnull-s8vector");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\015signed char \052");
lf[701]=C_h_intern(&lf[701],9,"u32vector");
lf[702]=C_h_intern(&lf[702],17,"nonnull-u32vector");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int \052");
lf[704]=C_h_intern(&lf[704],9,"s16vector");
lf[705]=C_h_intern(&lf[705],17,"nonnull-s16vector");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\007short \052");
lf[707]=C_h_intern(&lf[707],9,"s32vector");
lf[708]=C_h_intern(&lf[708],17,"nonnull-s32vector");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\005int \052");
lf[710]=C_h_intern(&lf[710],9,"f32vector");
lf[711]=C_h_intern(&lf[711],17,"nonnull-f32vector");
lf[712]=C_decode_literal(C_heaptop,"\376B\000\000\007float \052");
lf[713]=C_h_intern(&lf[713],9,"f64vector");
lf[714]=C_h_intern(&lf[714],17,"nonnull-f64vector");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\010double \052");
lf[716]=C_h_intern(&lf[716],14,"pointer-vector");
lf[717]=C_h_intern(&lf[717],22,"nonnull-pointer-vector");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\007void \052\052");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\006char \052");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char \052");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[726]=C_h_intern(&lf[726],3,"map");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[732]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[733]=C_h_intern(&lf[733],8,"->string");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[736]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\003 (\052");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[745]=C_h_intern(&lf[745],3,"...");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[749]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[750]=C_h_intern(&lf[750],4,"enum");
lf[751]=C_h_intern(&lf[751],5,"union");
lf[752]=C_h_intern(&lf[752],6,"struct");
lf[753]=C_h_intern(&lf[753],8,"template");
lf[754]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c"
"-pointer\376\377\016");
lf[755]=C_h_intern(&lf[755],12,"nonnull-blob");
lf[756]=C_h_intern(&lf[756],8,"u8vector");
lf[757]=C_h_intern(&lf[757],16,"nonnull-u8vector");
lf[758]=C_h_intern(&lf[758],14,"scheme-pointer");
lf[759]=C_h_intern(&lf[759],22,"nonnull-scheme-pointer");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\025(size_t)C_num_to_int(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\020C_num_to_uint64(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\033C_c_pointer_vector_or_null(");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\023C_c_pointer_vector(");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\002\052(");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\002\052(");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\021\052)C_c_pointer_nn(");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[816]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[818]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[819]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\012C_flonum(&");
lf[821]=C_decode_literal(C_heaptop,"\376B\000\000\012C_number(&");
lf[822]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[823]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[824]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[825]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[826]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[827]=C_decode_literal(C_heaptop,"\376B\000\000\023C_a_double_to_num(&");
lf[828]=C_decode_literal(C_heaptop,"\376B\000\000\006,(int)");
lf[829]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[830]=C_decode_literal(C_heaptop,"\376B\000\000\027C_unsigned_int_to_num(&");
lf[831]=C_decode_literal(C_heaptop,"\376B\000\000\017C_long_to_num(&");
lf[832]=C_decode_literal(C_heaptop,"\376B\000\000\030C_unsigned_long_to_num(&");
lf[833]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[834]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[835]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[836]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[837]=C_decode_literal(C_heaptop,"\376B\000\000\011,(void\052)&");
lf[838]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[839]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[840]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[841]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[842]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[843]=C_decode_literal(C_heaptop,"\376B\000\000\011,(void\052)&");
lf[844]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[845]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[846]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[847]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[848]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[849]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[850]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[851]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[852]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[853]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[854]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[855]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[856]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[857]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[858]=C_h_intern(&lf[858],18,"\003sysfixnum->string");
lf[859]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[860]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[861]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[862]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[863]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid literal - cannot encode");
lf[864]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[865]=C_h_intern(&lf[865],5,"cons\052");
lf[866]=C_h_intern(&lf[866],6,"random");
lf[867]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
C_register_lf2(lf,868,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2540,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k8870 in k8866 in k8847 in k8830 in k8813 in k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in ... */
static void C_ccall f_8872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1228: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[741],((C_word*)t0)[5],lf[742],t1,lf[743]);}

/* k8888 in k8866 in k8847 in k8830 in k8813 in k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in ... */
static void C_ccall f_8890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1232: string-intersperse */
t2=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[744]);}

/* expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_2651(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2651,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2654,a[2]=t6,a[3]=t8,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4594,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm:459: expr */
t11=((C_word*)t6)[1];
f_2654(t11,t1,t2,t3);}

/* map-loop1715 in k8866 in k8847 in k8830 in k8813 in k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in ... */
static void C_fcall f_8892(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8892,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8921,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_eqp(lf[745],t4);
if(C_truep(t5)){
t6=t3;
f_8921(2,t6,lf[746]);}
else{
/* c-backend.scm:1236: foreign-type-declaration */
t6=*((C_word*)lf[174]+1);
f_8254(4,t6,t3,t4,lf[747]);}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5549 in for-each-loop775 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5541(t3,((C_word*)t0)[4],t2);}

/* k3555 in for-each-loop271 in k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3547(t4,((C_word*)t0)[5],t2,t3);}

/* for-each-loop775 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5541(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5541,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5551,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:650: g776 */
t5=((C_word*)t0)[3];
f_5442(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4331 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:407: gen */
t2=*((C_word*)lf[1]+1);
f_2549(5,t2,((C_word*)t0)[2],lf[185],t1,lf[186]);}

/* expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_2654(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2654,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=C_eqp(t11,lf[11]);
if(C_truep(t12)){
t13=C_i_car(t9);
t14=C_eqp(t13,lf[12]);
if(C_truep(t14)){
if(C_truep(C_i_cadr(t9))){
/* c-backend.scm:83: gen */
t15=*((C_word*)lf[1]+1);
f_2549(3,t15,t1,lf[13]);}
else{
/* c-backend.scm:83: gen */
t15=*((C_word*)lf[1]+1);
f_2549(3,t15,t1,lf[14]);}}
else{
t15=C_eqp(t13,lf[15]);
if(C_truep(t15)){
t16=C_i_cadr(t9);
t17=C_fix(C_character_code(t16));
/* c-backend.scm:84: gen */
t18=*((C_word*)lf[1]+1);
f_2549(5,t18,t1,lf[16],t17,C_make_character(41));}
else{
t16=C_eqp(t13,lf[17]);
if(C_truep(t16)){
/* c-backend.scm:85: gen */
t17=*((C_word*)lf[1]+1);
f_2549(3,t17,t1,lf[18]);}
else{
t17=C_eqp(t13,lf[19]);
if(C_truep(t17)){
t18=C_i_cadr(t9);
/* c-backend.scm:86: gen */
t19=*((C_word*)lf[1]+1);
f_2549(5,t19,t1,lf[20],t18,C_make_character(41));}
else{
t18=C_eqp(t13,lf[21]);
if(C_truep(t18)){
/* c-backend.scm:87: gen */
t19=*((C_word*)lf[1]+1);
f_2549(3,t19,t1,lf[22]);}
else{
/* c-backend.scm:88: bomb */
t19=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t1,lf[23]);}}}}}}
else{
t13=C_eqp(t11,lf[24]);
if(C_truep(t13)){
t14=C_i_car(t9);
if(C_truep(C_i_vectorp(t14))){
t15=C_i_vector_ref(t14,C_fix(0));
/* c-backend.scm:93: gen */
t16=*((C_word*)lf[1]+1);
f_2549(5,t16,t1,lf[25],t15,lf[26]);}
else{
t15=C_u_i_car(t9);
/* c-backend.scm:94: gen */
t16=*((C_word*)lf[1]+1);
f_2549(5,t16,t1,lf[27],t15,C_make_character(93));}}
else{
t14=C_eqp(t11,lf[28]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2801,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:97: gen */
t16=*((C_word*)lf[1]+1);
f_2549(4,t16,t15,C_SCHEME_TRUE,lf[31]);}
else{
t15=C_eqp(t11,lf[32]);
if(C_truep(t15)){
t16=C_i_car(t9);
/* c-backend.scm:106: gen */
t17=*((C_word*)lf[1]+1);
f_2549(4,t17,t1,lf[33],t16);}
else{
t16=C_eqp(t11,lf[34]);
if(C_truep(t16)){
t17=C_i_car(t9);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2859,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t21=((C_word*)t19)[1];
f_2859(t21,t1,t6,t3,t17);}
else{
t17=C_eqp(t11,lf[35]);
if(C_truep(t17)){
t18=C_i_car(t9);
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2911,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:119: gen */
t20=*((C_word*)lf[1]+1);
f_2549(5,t20,t19,C_SCHEME_TRUE,t18,C_make_character(61));}
else{
t18=C_eqp(t11,lf[36]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2937,a[2]=t9,a[3]=t1,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:125: gen */
t20=*((C_word*)lf[1]+1);
f_2549(3,t20,t19,lf[38]);}
else{
t19=C_eqp(t11,lf[39]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2964,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:130: gen */
t21=*((C_word*)lf[1]+1);
f_2549(3,t21,t20,lf[41]);}
else{
t20=C_eqp(t11,lf[42]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2983,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:135: gen */
t22=*((C_word*)lf[1]+1);
f_2549(3,t22,t21,lf[43]);}
else{
t21=C_eqp(t11,lf[44]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3016,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:142: gen */
t23=*((C_word*)lf[1]+1);
f_2549(3,t23,t22,lf[47]);}
else{
t22=C_eqp(t11,lf[48]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3053,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:149: gen */
t24=*((C_word*)lf[1]+1);
f_2549(3,t24,t23,lf[50]);}
else{
t23=C_eqp(t11,lf[51]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3082,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:156: gen */
t25=*((C_word*)lf[1]+1);
f_2549(3,t25,t24,lf[53]);}
else{
t24=C_eqp(t11,lf[54]);
if(C_truep(t24)){
t25=C_i_car(t9);
t26=t25;
t27=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3114,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t6,a[5]=t26,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:164: gen */
t28=*((C_word*)lf[1]+1);
f_2549(5,t28,t27,lf[61],t26,C_make_character(44));}
else{
t25=C_eqp(t11,lf[62]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3187,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:174: gen */
t27=*((C_word*)lf[1]+1);
f_2549(3,t27,t26,lf[64]);}
else{
t26=C_eqp(t11,lf[65]);
if(C_truep(t26)){
t27=C_i_car(t9);
/* c-backend.scm:178: gen */
t28=*((C_word*)lf[1]+1);
f_2549(4,t28,t1,C_make_character(116),t27);}
else{
t27=C_eqp(t11,lf[66]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3219,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t29=C_i_car(t9);
/* c-backend.scm:181: gen */
t30=*((C_word*)lf[1]+1);
f_2549(5,t30,t28,C_make_character(116),t29,C_make_character(61));}
else{
t28=C_eqp(t11,lf[67]);
if(C_truep(t28)){
t29=C_i_car(t9);
t30=t29;
t31=C_i_cadr(t9);
if(C_truep(C_i_caddr(t9))){
if(C_truep(t31)){
/* c-backend.scm:190: gen */
t32=*((C_word*)lf[1]+1);
f_2549(5,t32,t1,lf[68],t30,lf[69]);}
else{
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3261,a[2]=t1,a[3]=t30,tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3265,a[2]=t32,tmp=(C_word)a,a+=3,tmp);
t34=C_i_cadddr(t9);
/* c-backend.scm:192: ##sys#symbol->qualified-string */
t35=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t35+1)))(3,t35,t33,t34);}}
else{
if(C_truep(t31)){
/* c-backend.scm:194: gen */
t32=*((C_word*)lf[1]+1);
f_2549(5,t32,t1,lf[74],t30,lf[75]);}
else{
/* c-backend.scm:195: gen */
t32=*((C_word*)lf[1]+1);
f_2549(5,t32,t1,lf[76],t30,lf[77]);}}}
else{
t29=C_eqp(t11,lf[78]);
if(C_truep(t29)){
t30=C_i_car(t9);
t31=C_i_cadr(t9);
t32=C_i_caddr(t9);
t33=t32;
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3296,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t33,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t31)){
/* c-backend.scm:202: gen */
t35=*((C_word*)lf[1]+1);
f_2549(5,t35,t34,lf[82],t30,lf[83]);}
else{
/* c-backend.scm:203: gen */
t35=*((C_word*)lf[1]+1);
f_2549(5,t35,t34,lf[84],t30,lf[85]);}}
else{
t30=C_eqp(t11,lf[86]);
if(C_truep(t30)){
t31=C_i_car(t9);
t32=t31;
t33=C_i_cadr(t9);
t34=C_i_caddr(t9);
if(C_truep(t33)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3344,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3358,a[2]=t35,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3362,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:214: ##sys#symbol->qualified-string */
t38=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t38+1)))(3,t38,t37,t34);}
else{
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3365,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3379,a[2]=t35,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3383,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:219: ##sys#symbol->qualified-string */
t38=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t38+1)))(3,t38,t37,t34);}}
else{
t31=C_eqp(t11,lf[93]);
if(C_truep(t31)){
/* c-backend.scm:223: gen */
t32=*((C_word*)lf[1]+1);
f_2549(3,t32,t1,lf[94]);}
else{
t32=C_eqp(t11,lf[95]);
if(C_truep(t32)){
t33=C_i_cdr(t6);
t34=t33;
t35=C_i_length(t34);
t36=t35;
t37=t3;
t38=C_a_i_plus(&a,2,t36,C_fix(1));
t39=t38;
t40=C_i_cdr(t9);
t41=C_i_pairp(t40);
t42=t41;
t43=(C_truep(t42)?C_i_cadr(t9):C_SCHEME_FALSE);
t44=t43;
t45=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3416,a[2]=t9,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t34,a[7]=t3,a[8]=t39,a[9]=((C_word*)t0)[2],a[10]=t36,a[11]=((C_word*)t0)[4],a[12]=t37,a[13]=t44,a[14]=((C_word*)t0)[5],a[15]=t42,tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm:232: source-info->string */
t46=*((C_word*)lf[149]+1);
((C_proc3)(void*)(*((C_word*)t46+1)))(3,t46,t45,t44);}
else{
t33=C_eqp(t11,lf[150]);
if(C_truep(t33)){
t34=C_i_length(t6);
t35=t34;
t36=C_a_i_plus(&a,2,t35,C_fix(1));
t37=t36;
t38=C_i_car(t9);
t39=t38;
t40=C_i_cadr(t9);
t41=t40;
t42=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4026,a[2]=t39,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t35,a[7]=t6,a[8]=t37,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[3],a[11]=t41,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:323: lambda-literal-closure-size */
t43=*((C_word*)lf[148]+1);
((C_proc3)(void*)(*((C_word*)t43+1)))(3,t43,t42,((C_word*)t0)[4]);}
else{
t34=C_eqp(t11,lf[154]);
if(C_truep(t34)){
t35=C_i_cdr(t6);
t36=t35;
t37=C_i_length(t36);
t38=C_a_i_plus(&a,2,t37,C_fix(1));
t39=C_i_caddr(t9);
t40=t39;
t41=C_i_cadddr(t9);
t42=t41;
t43=C_i_zerop(t42);
t44=C_i_not(t43);
t45=t44;
t46=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4109,a[2]=t6,a[3]=t1,a[4]=t36,a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t45,a[9]=t42,a[10]=t40,tmp=(C_word)a,a+=11,tmp);
t47=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4113,a[2]=t46,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:351: find-lambda */
t48=((C_word*)((C_word*)t0)[5])[1];
f_2639(t48,t47,t40);}
else{
t35=C_eqp(t11,lf[156]);
if(C_truep(t35)){
t36=C_i_length(t6);
t37=C_a_i_plus(&a,2,t36,C_fix(1));
t38=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4132,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t39=C_i_car(t9);
/* c-backend.scm:368: gen */
t40=*((C_word*)lf[1]+1);
f_2549(8,t40,t38,C_SCHEME_TRUE,lf[158],t39,lf[159],t37,lf[160]);}
else{
t36=C_eqp(t11,lf[161]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4151,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:373: gen */
t38=*((C_word*)lf[1]+1);
f_2549(4,t38,t37,C_SCHEME_TRUE,lf[163]);}
else{
t37=C_eqp(t11,lf[164]);
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4170,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t39=C_i_car(t9);
/* c-backend.scm:378: gen */
t40=*((C_word*)lf[1]+1);
f_2549(4,t40,t38,t39,C_make_character(40));}
else{
t38=C_eqp(t11,lf[165]);
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4189,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t40=C_i_car(t9);
t41=C_i_length(t6);
/* c-backend.scm:383: gen */
t42=*((C_word*)lf[1]+1);
f_2549(5,t42,t39,t40,lf[166],t41);}
else{
t39=C_eqp(t11,lf[167]);
if(C_truep(t39)){
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4225,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t41=C_i_cadr(t9);
/* c-backend.scm:391: foreign-result-conversion */
t42=*((C_word*)lf[168]+1);
f_9916(4,t42,t40,t41,lf[169]);}
else{
t40=C_eqp(t11,lf[170]);
if(C_truep(t40)){
t41=C_i_cadr(t9);
t42=t41;
t43=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4243,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t44=C_u_i_car(t9);
t45=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4259,a[2]=t43,a[3]=t44,a[4]=t42,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:395: foreign-type-declaration */
t46=*((C_word*)lf[174]+1);
f_8254(4,t46,t45,t42,lf[175]);}
else{
t41=C_eqp(t11,lf[176]);
if(C_truep(t41)){
t42=C_i_car(t9);
t43=t42;
t44=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4275,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t45=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4289,a[2]=t44,a[3]=t43,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:401: foreign-result-conversion */
t46=*((C_word*)lf[168]+1);
f_9916(4,t46,t45,t43,lf[181]);}
else{
t42=C_eqp(t11,lf[182]);
if(C_truep(t42)){
t43=C_i_car(t9);
t44=t43;
t45=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4305,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t44,tmp=(C_word)a,a+=7,tmp);
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4333,a[2]=t45,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:407: foreign-type-declaration */
t47=*((C_word*)lf[174]+1);
f_8254(4,t47,t46,t44,lf[187]);}
else{
t43=C_eqp(t11,lf[188]);
if(C_truep(t43)){
t44=C_i_car(t9);
/* c-backend.scm:414: gen */
t45=*((C_word*)lf[1]+1);
f_2549(3,t45,t1,t44);}
else{
t44=C_eqp(t11,lf[189]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4355,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t46=C_i_car(t9);
/* c-backend.scm:417: gen */
t47=*((C_word*)lf[1]+1);
f_2549(5,t47,t45,lf[191],t46,C_make_character(61));}
else{
t45=C_eqp(t11,lf[192]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4378,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t47=C_i_car(t9);
/* c-backend.scm:422: gen */
t48=*((C_word*)lf[1]+1);
f_2549(4,t48,t46,t47,lf[193]);}
else{
t46=C_eqp(t11,lf[194]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4397,a[2]=t9,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:427: gen */
t48=*((C_word*)lf[1]+1);
f_2549(4,t48,t47,C_SCHEME_TRUE,lf[198]);}
else{
t47=C_eqp(t11,lf[199]);
if(C_truep(t47)){
t48=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4478,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:442: gen */
t49=*((C_word*)lf[1]+1);
f_2549(3,t49,t48,lf[201]);}
else{
t48=t2;
t49=C_slot(t48,C_fix(1));
/* c-backend.scm:450: bomb */
t50=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t50+1)))(4,t50,t1,lf[202],t49);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2631,2,t0,t1);}
t2=C_mutate2((C_word*)lf[6]+1 /* (set! ##compiler#unique-id ...) */,t1);
t3=C_mutate2((C_word*)lf[7]+1 /* (set! ##compiler#generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2633,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2((C_word*)lf[512]+1 /* (set! emit-procedure-table-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6979,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[498]+1 /* (set! ##compiler#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7036,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[284]+1 /* (set! ##compiler#make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7125,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[295]+1 /* (set! ##compiler#make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7141,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2((C_word*)lf[516]+1 /* (set! ##compiler#generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7157,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2((C_word*)lf[207]+1 /* (set! ##compiler#generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7214,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2((C_word*)lf[514]+1 /* (set! ##compiler#generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7257,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate2((C_word*)lf[513]+1 /* (set! generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7579,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[548]+1 /* (set! ##compiler#generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8191,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[174]+1 /* (set! ##compiler#foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8254,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2((C_word*)lf[173]+1 /* (set! ##compiler#foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9301,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2((C_word*)lf[168]+1 /* (set! ##compiler#foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9916,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2((C_word*)lf[364]+1 /* (set! ##compiler#encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10701,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* k5526 in for-each-loop798 in k5476 in k5473 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5518(t3,((C_word*)t0)[4],t2);}

/* k10199 in k10196 in k10193 in k10187 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1335: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4323 in k4306 in k4303 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:409: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[2],lf[184],t1);}

/* k4874 in doloop596 in k4859 in k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4876,2,t0,t1);}
t2=t1;
t3=C_i_string_length(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=C_a_i_arithmetic_shift(&a,2,t4,C_fix(-16));
t7=C_a_i_arithmetic_shift(&a,2,t4,C_fix(-8));
t8=C_a_i_bitwise_and(&a,2,C_fix(255),t7);
t9=C_fixnum_and(C_fix(255),t4);
/* c-backend.scm:519: gen */
t10=*((C_word*)lf[1]+1);
f_2549(12,t10,t5,C_SCHEME_TRUE,lf[235],((C_word*)t0)[2],lf[236],t6,C_make_character(44),t8,C_make_character(44),t9,C_make_character(41));}

/* k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8439,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1171: str */
t2=((C_word*)t0)[2];
f_8261(t2,((C_word*)t0)[3],lf[691]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[636]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[637]));
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[692]);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[693]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_8460(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[755]);
if(C_truep(t6)){
t7=t5;
f_8460(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[756]);
t8=t5;
f_8460(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[4],lf[757])));}}}}}

/* k8085 in k8082 in k8079 in k8067 in k8064 in k8061 in k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8090,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_eqp(lf[561],((C_word*)t0)[3]);
if(C_truep(t3)){
/* c-backend.scm:1130: gen */
t4=*((C_word*)lf[1]+1);
f_2549(3,t4,((C_word*)t0)[2],lf[647]);}
else{
/* c-backend.scm:1129: gen */
t4=*((C_word*)lf[1]+1);
f_2549(3,t4,t2,C_make_character(41));}}

/* k8082 in k8079 in k8067 in k8064 in k8061 in k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1128: gen */
t3=*((C_word*)lf[1]+1);
f_2549(7,t3,t2,lf[648],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[5],C_make_character(41));}

/* k4880 in k4874 in doloop596 in k4859 in k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4933,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4933(t6,t2,C_fix(0));}

/* k4356 in k4353 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:419: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[190]);}

/* g2021 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_10250(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10250,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm:1342: foreign-result-conversion */
t4=*((C_word*)lf[168]+1);
f_9916(4,t4,t1,t3,((C_word*)t0)[2]);}
else{
t3=t2;
/* c-backend.scm:1342: foreign-result-conversion */
t4=*((C_word*)lf[168]+1);
f_9916(4,t4,t1,t3,((C_word*)t0)[2]);}}

/* k4353 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:418: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k8079 in k8067 in k8064 in k8061 in k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_eqp(lf[561],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_8084(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8109,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1127: foreign-argument-conversion */
t5=*((C_word*)lf[173]+1);
f_9301(3,t5,t4,((C_word*)t0)[3]);}}

/* ##compiler#generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_2633,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2637,a[2]=t4,a[3]=t6,a[4]=t2,a[5]=t3,a[6]=t8,a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t10=C_a_i_plus(&a,2,*((C_word*)lf[520]+1),C_fix(1));
/* c-backend.scm:64: flonum-print-precision */
t11=*((C_word*)lf[521]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}

/* find-lambda in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_2639(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2639,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2643,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:70: ##sys#hash-table-ref */
t4=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[78],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));
t27=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2651,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t28=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp));
t29=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4837,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp));
t30=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));
t31=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));
t32=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5670,a[2]=t19,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t33=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5726,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t34=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5916,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6058,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t36=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6134,tmp=(C_word)a,a+=2,tmp));
t37=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6200,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t15,a[5]=t17,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp));
t38=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6942,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t25,a[7]=t13,a[8]=((C_word*)t0)[6],a[9]=t11,a[10]=t9,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:914: debugging */
t39=*((C_word*)lf[499]+1);
((C_proc4)(void*)(*((C_word*)t39+1)))(4,t39,t38,lf[518],lf[519]);}

/* k4886 in k4883 in k4880 in k4874 in doloop596 in k4859 in k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:530: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[233]);}

/* k4883 in k4880 in k4874 in doloop596 in k4859 in k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(7));
t4=C_a_i_bitwise_and(&a,2,C_fix(16777208),t3);
t5=C_a_i_minus(&a,2,t4,((C_word*)t0)[6]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4906,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4906(t9,t2,t5);}

/* k8076 in for-each-loop1494 in k8067 in k8064 in k8061 in k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1122: gen */
t2=*((C_word*)lf[1]+1);
f_2549(9,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[650],t1,((C_word*)t0)[3],lf[651],C_SCHEME_TRUE,lf[652]);}

/* k2641 in find-lambda in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* c-backend.scm:71: bomb */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[9],((C_word*)t0)[3]);}}

/* for-each-loop297 in k3494 in k3486 in k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3510(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3510,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3520,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:258: gen */
t9=*((C_word*)lf[1]+1);
f_2549(8,t9,t6,C_SCHEME_TRUE,C_make_character(116),t8,lf[100],t7,C_make_character(59));}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_4858(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:512: gen */
t4=*((C_word*)lf[1]+1);
f_2549(7,t4,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[239],((C_word*)t0)[4],lf[240]);}}

/* k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:513: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[238]);}

/* for-each-loop271 in k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3547(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3547,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3557,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:249: g272 */
t9=((C_word*)t0)[3];
f_3472(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2614 in for-each-loop47 in k2599 in gen-list in k2544 in k2541 in k2538 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2606(t3,((C_word*)t0)[4],t2);}

/* k5710 in k5707 in k5701 in doloop835 in literal-frame in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:667: ##sys#write-char-0 */
t3=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(93),((C_word*)t0)[6]);}

/* k5713 in k5710 in k5707 in k5701 in doloop835 in literal-frame in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:667: get-output-string */
t3=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10246,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10250,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1340: g2021 */
t3=t2;
f_10250(t3,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10273,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[4];
t4=C_u_i_length(t3);
t5=t2;
f_10273(t5,C_fixnum_greater_or_equal_p(t4,C_fix(2)));}
else{
t3=t2;
f_10273(t3,C_SCHEME_FALSE);}}}

/* k8088 in k8085 in k8082 in k8079 in k8067 in k8064 in k8061 in k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1130: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[647]);}

/* k5701 in doloop835 in literal-frame in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5703,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:667: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[340],C_SCHEME_FALSE,t3);}

/* k5716 in k5713 in k5710 in k5707 in k5701 in doloop835 in literal-frame in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:667: gen-lit */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5916(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k6023 in k6013 in k6010 in k5927 in k5921 in gen-lit in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:714: gen-string-constant */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6058(t2,((C_word*)t0)[3],t1);}

/* k3518 in for-each-loop297 in k3494 in k3486 in k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3510(t4,((C_word*)t0)[5],t2,t3);}

/* k5707 in k5701 in doloop835 in literal-frame in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:667: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[7],C_SCHEME_TRUE,((C_word*)t0)[6]);}

/* k10223 in k10220 in k10217 in k10211 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1336: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6010 in k5927 in k5921 in gen-lit in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_6012(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6012,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:713: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[5],lf[365]);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[4];
/* c-backend.scm:670: bomb */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[346],t3);}}

/* k10220 in k10217 in k10211 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1336: ##sys#write-char-0 */
t3=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[4]);}

/* k6013 in k6010 in k5927 in k5921 in gen-lit in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6025,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:714: encode-literal */
t4=*((C_word*)lf[364]+1);
f_10701(3,t4,t3,((C_word*)t0)[4]);}

/* for-each-loop47 in k2599 in gen-list in k2544 in k2541 in k2538 */
static void C_fcall f_2606(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2606,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2616,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:49: display */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[0]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2599 in gen-list in k2544 in k2541 in k2538 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2601,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2606,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2606(t5,((C_word*)t0)[2],t1);}

/* k6585 in k6570 in k6567 in k6564 in k6561 in k6558 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in ... */
static void C_fcall f_6587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm:845: gen */
t2=*((C_word*)lf[1]+1);
f_2549(8,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[437],((C_word*)t0)[3],lf[438],((C_word*)t0)[3],lf[439]);}
else{
t2=((C_word*)t0)[2];
f_6575(2,t2,C_SCHEME_UNDEFINED);}}

/* k5666 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5580(t2,C_i_zerop(t1));}

/* k3500 in k3497 in k3494 in k3486 in k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:261: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[98]);}

/* k7072 in loop in cleanup in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7074(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7074,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=C_i_string_set(((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3],C_make_character(126));
t3=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:969: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_7045(t4,((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:966: string-copy */
t3=*((C_word*)lf[543]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}
else{
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=C_i_string_set(((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3],((C_word*)t0)[7]);
t3=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:969: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_7045(t4,((C_word*)t0)[5],t3);}
else{
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:969: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7045(t3,((C_word*)t0)[5],t2);}}}

/* k6016 in k6013 in k6010 in k5927 in k5921 in gen-lit in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:715: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[363]);}

/* k7471 in for-each-loop1241 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in ... */
static void C_fcall f_7473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7473,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(0));
t4=C_slot(((C_word*)t0)[3],C_fix(0));
t5=C_slot(((C_word*)t0)[4],C_fix(0));
t6=t2;
t7=t3;
t8=t4;
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7335,a[2]=t6,a[3]=t8,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7347,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
/* c-backend.scm:1045: symbol->string */
t11=*((C_word*)lf[569]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t5);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7353,a[2]=t10,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1045: open-output-string */
t12=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7474 in k7471 in for-each-loop1241 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in ... */
static void C_ccall f_7476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[5])[1];
f_7466(t5,((C_word*)t0)[6],t2,t3,t4);}

/* k5655 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_5623(2,t3,t2);}
else{
/* c-backend.scm:645: lambda-literal-external */
t3=*((C_word*)lf[335]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* f11805 in k3593 in k3590 in k3587 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f11805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:271: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[102]);}

/* k7082 in k7072 in loop in cleanup in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7084,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_string_set(((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3],C_make_character(126));
t4=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:969: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7045(t5,((C_word*)t0)[5],t4);}

/* k5225 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_5227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:555: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[276]);}

/* doloop607 in k4883 in k4880 in k4874 in doloop596 in k4859 in k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_4906(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4906,NULL,3,t0,t1,t2);}
if(C_truep(C_i_zerop(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4916,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:529: gen */
t4=*((C_word*)lf[1]+1);
f_2549(3,t4,t3,lf[234]);}}

/* k5253 in k5250 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in ... */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:564: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[267]);}

/* k5250 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5252,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:563: gen */
t4=*((C_word*)lf[1]+1);
f_2549(6,t4,t3,lf[268],t2,lf[269],C_SCHEME_TRUE);}

/* k5256 in k5253 in k5250 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in ... */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:565: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[2],lf[266],((C_word*)t0)[3]);}

/* doloop972 in k6799 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in ... */
static void C_fcall f_6803(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6803,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6813,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:803: gen */
t5=*((C_word*)lf[1]+1);
f_2549(6,t5,t4,C_SCHEME_TRUE,lf[477],t2,C_make_character(59));}}

/* for-each-loop1241 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in ... */
static void C_fcall f_7466(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7466,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7473,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_pairp(t3);
t7=t5;
f_7473(t7,(C_truep(t6)?C_i_pairp(t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_7473(t6,C_SCHEME_FALSE);}}

/* k4859 in k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4861,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4866,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4866(t5,((C_word*)t0)[2],C_fix(0),((C_word*)t0)[3]);}

/* f11813 in k4008 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f11813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:341: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k4642 in pad0 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#string-append */
t2=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[205],t1);}

/* k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4647,2,t0,t1);}
t2=C_i_vector_ref(t1,C_fix(1));
t3=t2;
t4=C_i_vector_ref(t1,C_fix(2));
t5=t4;
t6=C_i_vector_ref(t1,C_fix(3));
t7=t6;
t8=C_i_vector_ref(t1,C_fix(4));
t9=C_i_vector_ref(t1,C_fix(5));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=C_a_i_plus(&a,2,C_fix(1900),t9);
t12=t11;
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4746,a[2]=t10,a[3]=((C_word*)t0)[3],a[4]=t12,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t5,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t14=C_a_i_plus(&a,2,t8,C_fix(1));
/* c-backend.scm:474: pad0 */
f_4629(t13,t14);}

/* doloop596 in k4859 in k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_4866(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4866,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4876,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* c-backend.scm:517: ##sys#lambda-info->string */
t6=*((C_word*)lf[237]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k5234 in k5231 in k5228 in k5225 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in ... */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:560: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6576 in k6573 in k6570 in k6567 in k6564 in k6561 in k6558 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in ... */
static void C_ccall f_6578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:847: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[433],((C_word*)t0)[3],lf[434]);}

/* k5231 in k5228 in k5225 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in ... */
static void C_ccall f_5233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:558: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[272]);}
else{
/* c-backend.scm:559: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[273]);}}

/* k5228 in k5225 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in ... */
static void C_ccall f_5230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm:556: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[274]);}
else{
/* c-backend.scm:556: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[275]);}}

/* k6573 in k6570 in k6567 in k6564 in k6561 in k6558 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in ... */
static void C_ccall f_6575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(*((C_word*)lf[435]+1))){
/* c-backend.scm:846: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[436]);}
else{
/* c-backend.scm:847: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[433],((C_word*)t0)[3],lf[434]);}}

/* k6570 in k6567 in k6564 in k6561 in k6558 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in ... */
static void C_ccall f_6572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6587,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[134]+1);
if(C_truep(*((C_word*)lf[134]+1))){
t5=t3;
f_6587(t5,C_SCHEME_FALSE);}
else{
t5=*((C_word*)lf[440]+1);
if(C_truep(*((C_word*)lf[440]+1))){
t6=t3;
f_6587(t6,C_SCHEME_FALSE);}
else{
t6=C_i_greaterp(((C_word*)t0)[4],C_fix(2));
t7=t3;
f_6587(t7,(C_truep(t6)?C_i_not(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* expr-args in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_4594(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4594,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4600,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:453: pair-for-each */
t5=*((C_word*)lf[203]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* k6567 in k6564 in k6561 in k6558 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in ... */
static void C_ccall f_6569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:843: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,lf[441],((C_word*)t0)[4],lf[442]);}

/* k6564 in k6561 in k6558 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in ... */
static void C_ccall f_6566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[4],C_fix(0)))){
t3=C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
/* c-backend.scm:841: gen */
t4=*((C_word*)lf[1]+1);
f_2549(4,t4,t2,C_make_character(116),t3);}
else{
/* c-backend.scm:842: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[443]);}}

/* k6558 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in ... */
static void C_ccall f_6560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:838: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[445]);}

/* k6561 in k6558 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_ccall f_6563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:839: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[444]);}

/* header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_4626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4626,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4629,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4647,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4821,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:466: current-seconds */
t5=*((C_word*)lf[232]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5684 in doloop835 in literal-frame in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5686,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[4])[1];
f_5676(t5,((C_word*)t0)[5],t2,t4);}

/* pad0 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_4629(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4629,NULL,2,t1,t2);}
if(C_truep(C_i_lessp(t2,C_fix(10)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4644,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:464: number->string */
C_number_to_string(3,0,t3,t2);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10211 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10213,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10219,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1336: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[832],C_SCHEME_FALSE,t3);}

/* k10217 in k10211 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1336: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k9569 in k9560 in k9551 in k9356 in k9329 in foreign-argument-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_9571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9571,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
if(C_truep(C_i_vectorp(t3))){
t4=C_i_vector_ref(t3,C_fix(0));
/* c-backend.scm:1293: foreign-argument-conversion */
t5=*((C_word*)lf[173]+1);
f_9301(3,t5,t2,t4);}
else{
/* c-backend.scm:1293: foreign-argument-conversion */
t4=*((C_word*)lf[173]+1);
f_9301(3,t4,t2,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t3=((C_word*)t0)[3];
t4=C_u_i_length(t3);
t5=t2;
f_9598(t5,C_fixnum_greater_or_equal_p(t4,C_fix(2)));}
else{
t3=t2;
f_9598(t3,C_SCHEME_FALSE);}}}

/* k7199 in for-each-loop1166 in k7159 in generate-external-variables in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7191(t3,((C_word*)t0)[4],t2);}

/* k4889 in k4886 in k4883 in k4880 in k4874 in doloop596 in k4859 in k4856 in k4853 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4891,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[4])[1];
f_4866(t5,((C_word*)t0)[5],t2,t4);}

/* doloop835 in literal-frame in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5676(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5676,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5686,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5703,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t6,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:667: open-output-string */
t8=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* literal-frame in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5670(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5670,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5676,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5676(t5,t1,C_fix(0),((C_word*)t0)[3]);}

/* k3659 in k3656 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:304: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4594(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3662 in k3659 in k3656 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:305: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[105]);}

/* k5408 in k5398 in k5395 in k5392 in k5389 in k5386 in k5383 in k5380 in k5377 in k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k5412 in k5398 in k5395 in k5392 in k5389 in k5386 in k5383 in k5380 in k5377 in k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:624: intersperse */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3656 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:303: gen */
t3=*((C_word*)lf[1]+1);
f_2549(7,t3,t2,lf[106],((C_word*)t0)[6],C_make_character(44),((C_word*)((C_word*)t0)[7])[1],C_make_character(44));}

/* k9596 in k9569 in k9560 in k9551 in k9356 in k9329 in foreign-argument-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_9598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9598,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[610]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[801]);}
else{
t4=C_eqp(t2,lf[612]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[802]);}
else{
t5=C_eqp(t2,lf[614]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[803]);}
else{
t6=C_eqp(t2,lf[615]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[804]);}
else{
t7=C_eqp(t2,lf[613]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[805]);}
else{
t8=C_eqp(t2,lf[609]);
if(C_truep(t8)){
t9=C_i_cadr(((C_word*)t0)[2]);
/* c-backend.scm:1301: foreign-argument-conversion */
t10=*((C_word*)lf[173]+1);
f_9301(3,t10,((C_word*)t0)[3],t9);}
else{
t9=C_eqp(t2,lf[750]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[806]);}
else{
t10=C_eqp(t2,lf[607]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9663,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t12=C_i_cadr(((C_word*)t0)[2]);
/* c-backend.scm:1304: foreign-type-declaration */
t13=*((C_word*)lf[174]+1);
f_8254(4,t13,t11,t12,lf[809]);}
else{
t11=C_eqp(t2,lf[616]);
if(C_truep(t11)){
t12=C_i_cadr(((C_word*)t0)[2]);
/* c-backend.scm:1307: string-append */
t13=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,((C_word*)t0)[3],lf[810],t12,lf[811]);}
else{
/* c-backend.scm:1308: err */
t12=((C_word*)t0)[4];
f_9303(t12,((C_word*)t0)[3]);}}}}}}}}}}
else{
/* c-backend.scm:1309: err */
t2=((C_word*)t0)[4];
f_9303(t2,((C_word*)t0)[3]);}}

/* k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(*((C_word*)lf[107]+1))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3671,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[8])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3681,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:285: number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[9]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3688,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:286: number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[9]);}}
else{
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3695,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3720,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:289: number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[9]);}
else{
if(C_truep(((C_word*)t0)[10])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3727,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3734,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:297: number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[9]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3738,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3745,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:301: number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[9]);}}}}

/* k8107 in k8079 in k8067 in k8064 in k8061 in k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1127: gen */
t2=*((C_word*)lf[1]+1);
f_2549(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[649],t1);}

/* k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5383 in k5380 in k5377 in k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:625: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[294]);}

/* k5398 in k5395 in k5392 in k5389 in k5386 in k5383 in k5380 in k5377 in k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5414,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:624: make-argument-list */
t6=*((C_word*)lf[295]+1);
f_7141(4,t6,t4,t5,lf[296]);}

/* k9560 in k9551 in k9356 in k9329 in foreign-argument-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_9562(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9562,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[799]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[12]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[800]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* c-backend.scm:1291: ##sys#hash-table-ref */
t4=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[617]+1),((C_word*)t0)[4]);}
else{
t4=t3;
f_9571(2,t4,C_SCHEME_FALSE);}}}}

/* k10431 in k10428 in k10422 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1357: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[845],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10434 in k10431 in k10428 in k10422 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1357: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10428 in k10422 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1357: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3635,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=t2;
t4=C_i_car(t3);
t5=t4;
t6=C_i_cadr(t3);
t7=t6;
t8=C_i_caddr(t3);
t9=t8;
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t11,a[8]=t9,a[9]=t5,a[10]=t7,a[11]=t3,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:281: gen */
t13=*((C_word*)lf[1]+1);
f_2549(6,t13,t12,C_SCHEME_TRUE,lf[129],((C_word*)t0)[7],lf[130]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:307: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[8],C_make_character(61));}}

/* k4064 in k4061 in k4058 in k4055 in k4107 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:361: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k4061 in k4058 in k4055 in k4107 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm:360: expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4594(t3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
/* c-backend.scm:361: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,((C_word*)t0)[2],C_make_character(41));}}

/* k4058 in k4055 in k4107 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=t2;
f_4063(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4078,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:358: expr */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2654(t4,t3,((C_word*)t0)[8],((C_word*)t0)[5]);}}

/* k3627 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(((C_word*)t0)[2],t1);
if(C_truep(t2)){
/* c-backend.scm:248: lambda-literal-looping */
t3=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_3465(2,t3,C_SCHEME_FALSE);}}

/* k6873 in k6870 in k6867 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in ... */
static void C_ccall f_6875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:777: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6870 in k6867 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in ... */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:775: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[491]);}
else{
/* c-backend.scm:776: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[492]);}}

/* ##compiler#foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_9916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9916,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9918,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=C_eqp(t5,lf[15]);
t7=(C_truep(t6)?t6:C_eqp(t5,lf[642]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[813]);}
else{
t8=C_eqp(t5,lf[473]);
t9=(C_truep(t8)?t8:C_eqp(t5,lf[638]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[814]);}
else{
t10=C_eqp(t5,lf[643]);
t11=(C_truep(t10)?t10:C_eqp(t5,lf[644]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[815]);}
else{
t12=C_eqp(t5,lf[639]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[816]);}
else{
t13=C_eqp(t5,lf[640]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[817]);}
else{
t14=C_eqp(t5,lf[645]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[818]);}
else{
t15=C_eqp(t5,lf[646]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[819]);}
else{
t16=C_eqp(t5,lf[598]);
t17=(C_truep(t16)?t16:C_eqp(t5,lf[625]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9985,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1324: open-output-string */
t19=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t18=C_eqp(t5,lf[633]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10009,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1325: open-output-string */
t20=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,t19);}
else{
t19=C_eqp(t5,lf[604]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10033,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_10033(t21,t19);}
else{
t21=C_eqp(t5,lf[600]);
if(C_truep(t21)){
t22=t20;
f_10033(t22,t21);}
else{
t22=C_eqp(t5,lf[612]);
if(C_truep(t22)){
t23=t20;
f_10033(t23,t22);}
else{
t23=C_eqp(t5,lf[622]);
if(C_truep(t23)){
t24=t20;
f_10033(t24,t23);}
else{
t24=C_eqp(t5,lf[618]);
if(C_truep(t24)){
t25=t20;
f_10033(t25,t24);}
else{
t25=C_eqp(t5,lf[623]);
if(C_truep(t25)){
t26=t20;
f_10033(t26,t25);}
else{
t26=C_eqp(t5,lf[624]);
if(C_truep(t26)){
t27=t20;
f_10033(t27,t26);}
else{
t27=C_eqp(t5,lf[619]);
if(C_truep(t27)){
t28=t20;
f_10033(t28,t27);}
else{
t28=C_eqp(t5,lf[620]);
if(C_truep(t28)){
t29=t20;
f_10033(t29,t28);}
else{
t29=C_eqp(t5,lf[621]);
if(C_truep(t29)){
t30=t20;
f_10033(t30,t29);}
else{
t30=C_eqp(t5,lf[636]);
t31=t20;
f_10033(t31,(C_truep(t30)?t30:C_eqp(t5,lf[637])));}}}}}}}}}}}}}}}}}}}}

/* err in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_9918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9918,NULL,2,t0,t1);}
/* c-backend.scm:1315: quit */
t2=*((C_word*)lf[672]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[812],((C_word*)t0)[2]);}

/* k3614 in k3611 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:266: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k6867 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in ... */
static void C_ccall f_6869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm:773: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[493]);}
else{
/* c-backend.scm:773: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[494]);}}

/* k3611 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:265: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2654(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* ##compiler#cleanup in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7036(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7036,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_i_string_length(t2);
t6=t5;
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7045,a[2]=t6,a[3]=t4,a[4]=t2,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_7045(t10,t1,C_fix(0));}

/* k7032 in emit-procedure-table-info in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7034,2,t0,t1);}
t2=C_a_i_plus(&a,2,t1,C_fix(1));
/* c-backend.scm:931: gen */
t3=*((C_word*)lf[1]+1);
f_2549(9,t3,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[539],C_SCHEME_TRUE,lf[540],t2,lf[541]);}

/* k3599 in k3596 in k3593 in k3590 in k3587 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:271: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[102]);}

/* k8731 in map-loop1667 in k8681 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8733,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8704(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8704(t6,((C_word*)t0)[5],t5);}}

/* loop in cleanup in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7045,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[2]))){
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:((C_word*)t0)[4]));}
else{
t3=C_i_string_ref(((C_word*)t0)[4],t2);
t4=t3;
t5=C_i_char_lessp(t4,C_make_character(32));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7074,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_7074(t7,t5);}
else{
t7=C_i_char_greaterp(t4,C_make_character(126));
if(C_truep(t7)){
t8=t6;
f_7074(t8,t7);}
else{
if(C_truep(C_i_char_equalp(t4,C_make_character(42)))){
t8=C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_lessp(t2,t8))){
t9=C_a_i_plus(&a,2,t2,C_fix(1));
t10=C_i_string_ref(((C_word*)t0)[4],t9);
t11=t6;
f_7074(t11,C_i_char_equalp(C_make_character(47),t10));}
else{
t9=t6;
f_7074(t9,C_SCHEME_FALSE);}}
else{
t8=t6;
f_7074(t8,C_SCHEME_FALSE);}}}}}

/* k4088 in k4055 in k4107 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_not(((C_word*)t0)[2]);
if(C_truep(t2)){
if(C_truep(t2)){
/* c-backend.scm:356: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,((C_word*)t0)[3],C_make_character(44));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_4060(2,t4,t3);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm:356: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,((C_word*)t0)[3],C_make_character(44));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_4060(2,t4,t3);}}}

/* k8700 in k8681 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1208: string-intersperse */
t2=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[727]);}

/* map-loop1667 in k8681 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8704(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8704,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8733,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[174]+1);
/* c-backend.scm:1209: g1690 */
t6=*((C_word*)lf[174]+1);
f_8254(4,t6,t3,t4,lf[728]);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7181 in for-each-loop1166 in k7159 in generate-external-variables in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:994: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,((C_word*)t0)[3],t1,C_make_character(59));}

/* k10446 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10448,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10454,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1358: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[848],C_SCHEME_FALSE,t3);}

/* k7153 in a7146 in make-argument-list in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:982: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* ##compiler#generate-external-variables in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7157,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7161,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:988: gen */
t4=*((C_word*)lf[1]+1);
f_2549(3,t4,t3,C_SCHEME_TRUE);}

/* k4111 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:351: lambda-literal-closure-size */
t2=*((C_word*)lf[148]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10452 in k10446 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1358: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10455 in k10452 in k10446 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1358: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[847],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k7159 in generate-external-variables in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7161,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_i_check_list_2(t2,lf[57]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7191,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7191(t7,((C_word*)t0)[3],t2);}

/* k4107 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4109,2,t0,t1);}
t2=C_i_zerop(t1);
t3=t2;
t4=C_u_i_car(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:353: gen */
t6=*((C_word*)lf[1]+1);
f_2549(4,t6,t5,((C_word*)t0)[10],C_make_character(40));}

/* k10761 in encode-literal in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10763,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1387: string-append */
t4=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* k10422 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10424,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10430,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1357: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[846],C_SCHEME_FALSE,t3);}

/* k6889 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in ... */
static void C_ccall f_6891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(*((C_word*)lf[214]+1))){
t3=t2;
f_6894(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:781: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[489]);}}

/* k6892 in k6889 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in ... */
static void C_ccall f_6894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:782: gen */
t2=*((C_word*)lf[1]+1);
f_2549(16,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[483],C_SCHEME_TRUE,lf[484],C_SCHEME_TRUE,lf[485],C_SCHEME_TRUE,lf[486],((C_word*)t0)[3],lf[487],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[488],((C_word*)t0)[3]);}

/* k4055 in k4107 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[9])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4090,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:355: gen */
t4=*((C_word*)lf[1]+1);
f_2549(5,t4,t3,lf[155],((C_word*)t0)[10],C_make_character(41));}
else{
t3=t2;
f_4060(2,t3,C_SCHEME_UNDEFINED);}}

/* k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5733,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep(C_i_numberp(((C_word*)t0)[3]))){
t2=*((C_word*)lf[342]+1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[342]+1));}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* c-backend.scm:677: literal-size */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5726(3,t5,t2,t4);}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[3];
t3=C_block_size(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5789,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)((C_word*)t0)[4])[1];
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5793,a[2]=t5,a[3]=t9,a[4]=t7,a[5]=t10,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:678: vector->list */
t12=*((C_word*)lf[345]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:679: block-variable-literal? */
t3=*((C_word*)lf[349]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}}}}}}

/* k5389 in k5386 in k5383 in k5380 in k5377 in k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:621: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[299]);}
else{
t3=t2;
f_5394(2,t3,C_SCHEME_UNDEFINED);}}

/* for-each-loop1166 in k7159 in generate-external-variables in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7191(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7191,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7201,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_vector_ref(t4,C_fix(0));
t7=C_i_vector_ref(t4,C_fix(1));
t8=C_i_vector_ref(t4,C_fix(2));
t9=(C_truep(t8)?lf[546]:lf[547]);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7183,a[2]=t5,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:994: foreign-type-declaration */
t12=*((C_word*)lf[174]+1);
f_8254(4,t12,t11,t7,t6);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9995 in k9992 in k9989 in k9983 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_9997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1324: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9992 in k9989 in k9983 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_9994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1324: ##sys#write-char-0 */
t3=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[4]);}

/* literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5726,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5733,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:673: immediate? */
t4=*((C_word*)lf[350]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k9989 in k9983 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_9991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1324: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k5392 in k5389 in k5386 in k5383 in k5380 in k5377 in k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:622: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[298]);}

/* k5395 in k5392 in k5389 in k5386 in k5383 in k5380 in k5377 in k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:623: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[297]);}

/* k5368 in k5365 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:610: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,t2,C_SCHEME_TRUE,lf[308],((C_word*)t0)[3],C_make_character(114));}

/* k5380 in k5377 in k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:616: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[303]);}

/* k5383 in k5380 in k5377 in k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:618: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[301]);}
else{
/* c-backend.scm:619: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[302]);}}

/* k5386 in k5383 in k5380 in k5377 in k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:620: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[300]);}

/* emitter in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5361(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5361,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5363,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* k5371 in k5368 in k5365 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:611: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_5376(2,t3,C_SCHEME_UNDEFINED);}}

/* k5377 in k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:615: restore */
f_5325(t2,((C_word*)t0)[3]);}

/* k5374 in k5371 in k5368 in k5365 */
static void C_ccall f_5376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:612: gen */
t3=*((C_word*)lf[1]+1);
f_2549(11,t3,t2,lf[304],((C_word*)t0)[3],lf[305],C_SCHEME_TRUE,lf[306],C_SCHEME_TRUE,lf[307],((C_word*)t0)[3],C_make_character(59));}

/* k7610 in compute-size in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7612,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[598]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7621(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[625]);
if(C_truep(t4)){
t5=t3;
f_7621(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[610]);
if(C_truep(t5)){
t6=t3;
f_7621(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[626]);
if(C_truep(t6)){
t7=t3;
f_7621(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[627]);
if(C_truep(t7)){
t8=t3;
f_7621(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[628]);
if(C_truep(t8)){
t9=t3;
f_7621(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[629]);
if(C_truep(t9)){
t10=t3;
f_7621(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[630]);
if(C_truep(t10)){
t11=t3;
f_7621(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[631]);
if(C_truep(t11)){
t12=t3;
f_7621(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[632]);
if(C_truep(t12)){
t13=t3;
f_7621(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[612]);
if(C_truep(t13)){
t14=t3;
f_7621(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[633]);
if(C_truep(t14)){
t15=t3;
f_7621(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[634]);
if(C_truep(t15)){
t16=t3;
f_7621(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[635]);
if(C_truep(t16)){
t17=t3;
f_7621(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[4],lf[636]);
t18=t3;
f_7621(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[4],lf[637])));}}}}}}}}}}}}}}}}

/* k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5134,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[57]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5270,a[2]=t5,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5270(t7,t3,t1);}

/* k2935 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:126: expr */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2654(t4,t2,t3,((C_word*)t0)[6]);}

/* k8064 in k8061 in k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:1119: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[654]);}

/* k8067 in k8064 in k8061 in k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8111,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8111(t6,t2,((C_word*)t0)[6],((C_word*)t0)[7]);}

/* f_5363 in emitter in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5363,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5367,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[2])?C_make_character(118):lf[311]);
t5=(C_truep(((C_word*)t0)[2])?C_make_character(118):lf[312]);
/* c-backend.scm:607: gen */
t6=*((C_word*)lf[1]+1);
f_2549(14,t6,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[313],t2,C_make_character(114),t4,lf[314],C_SCHEME_TRUE,lf[315],t2,C_make_character(114),t5);}

/* k5365 */
static void C_ccall f_5367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:609: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,lf[309],((C_word*)t0)[3],lf[310]);}

/* k7619 in k7610 in compute-size in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7621,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1094: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[599]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[600]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7633(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[622]);
if(C_truep(t4)){
t5=t3;
f_7633(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[623]);
if(C_truep(t5)){
t6=t3;
f_7633(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[623]);
t7=t3;
f_7633(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[624])));}}}}}

/* k8061 in k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_string_equal_p(lf[655],((C_word*)t0)[8]))){
/* c-backend.scm:1117: gen */
t3=*((C_word*)lf[1]+1);
f_2549(8,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[656],((C_word*)t0)[8],lf[657],lf[658]);}
else{
/* c-backend.scm:1117: gen */
t3=*((C_word*)lf[1]+1);
f_2549(8,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[656],((C_word*)t0)[8],lf[657],lf[659]);}}

/* k8058 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:1116: generate-foreign-callback-header */
t3=*((C_word*)lf[548]+1);
f_8191(4,t3,t2,lf[660],((C_word*)t0)[9]);}

/* k5159 in k5153 in k5150 in k5147 in k5144 in k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in ... */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5161,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[2],lf[254]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5170,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:576: gen */
t4=*((C_word*)lf[1]+1);
f_2549(10,t4,t3,C_SCHEME_TRUE,lf[257],((C_word*)t0)[6],lf[258],C_SCHEME_TRUE,lf[259],((C_word*)t0)[6],lf[260]);}}

/* k5197 in k5147 in k5144 in k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in ... */
static void C_fcall f_5199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5199,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:569: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[263]);}
else{
t2=((C_word*)t0)[3];
f_5152(2,t2,C_SCHEME_UNDEFINED);}}

/* k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8054,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:1113: gen */
t4=*((C_word*)lf[1]+1);
f_2549(3,t4,t3,C_SCHEME_TRUE);}

/* k4733 in k4669 in k4666 in k4663 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:485: gen-list */
t2=*((C_word*)lf[4]+1);
f_2592(3,t2,((C_word*)t0)[2],*((C_word*)lf[216]+1));}

/* k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8160,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1115: cleanup */
t4=*((C_word*)lf[498]+1);
f_7036(3,t4,t3,((C_word*)t0)[10]);}
else{
t3=t2;
f_8060(2,t3,C_SCHEME_UNDEFINED);}}

/* k7631 in k7619 in k7610 in compute-size in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7633,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1096: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[601],((C_word*)t0)[4],lf[602],((C_word*)t0)[4],lf[603]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[604]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7645(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[618]);
if(C_truep(t4)){
t5=t3;
f_7645(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[619]);
if(C_truep(t5)){
t6=t3;
f_7645(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[620]);
t7=t3;
f_7645(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[5],lf[621])));}}}}}

/* a7130 in make-variable-list in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7131,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7139,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:977: number->string */
C_number_to_string(3,0,t3,t2);}

/* k7137 in a7130 in make-variable-list in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:977: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[544],((C_word*)t0)[3],t1);}

/* k5188 in k5185 in k5153 in k5150 in k5147 in k5144 in k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in ... */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:584: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k5147 in k5144 in k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in ... */
static void C_ccall f_5149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[8])){
t4=C_i_zerop(((C_word*)t0)[9]);
t5=t3;
f_5199(t5,C_i_not(t4));}
else{
t4=t3;
f_5199(t4,C_SCHEME_FALSE);}}

/* k7643 in k7631 in k7619 in k7610 in compute-size in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7645(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7645,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1098: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[605],((C_word*)t0)[4],lf[606]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7651,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
/* c-backend.scm:1100: ##sys#hash-table-ref */
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[617]+1),((C_word*)t0)[6]);}
else{
t3=t2;
f_7651(2,t3,C_SCHEME_FALSE);}}}

/* ##compiler#make-argument-list in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7141,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7147,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:980: list-tabulate */
t5=*((C_word*)lf[545]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}

/* k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_5143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:566: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,C_make_character(40));}

/* a7146 in make-argument-list in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7147,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7155,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:982: number->string */
C_number_to_string(3,0,t3,t2);}

/* k5144 in k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in ... */
static void C_ccall f_5146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_5149(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:567: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[264]);}}

/* k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_eqp(lf[265],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5252,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[214]+1))){
/* c-backend.scm:562: string-append */
t5=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[214]+1),lf[270]);}
else{
t5=t4;
f_5252(2,t5,lf[271]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5227,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:554: gen */
t5=*((C_word*)lf[1]+1);
f_2549(6,t5,t4,lf[277],((C_word*)t0)[7],lf[278],C_SCHEME_TRUE);}}

/* k9329 in foreign-argument-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_9331(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9331,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[763]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[639]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[764]);}
else{
t3=C_eqp(((C_word*)t0)[3],lf[640]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[765]);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[631]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[766]);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[625]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9358(t7,t5);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[633]);
t8=t6;
f_9358(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[3],lf[598])));}}}}}}

/* doloop475 in k4401 in k4398 in k4395 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_4414(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4414,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_zerop(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4424,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:433: gen */
t5=*((C_word*)lf[1]+1);
f_2549(4,t5,t4,C_SCHEME_TRUE,lf[195]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4437,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:436: gen */
t5=*((C_word*)lf[1]+1);
f_2549(4,t5,t4,C_SCHEME_TRUE,lf[196]);}}

/* a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6206,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6210,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:748: lambda-literal-argument-count */
t5=*((C_word*)lf[287]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_6200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6200,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:746: ##sys#hash-table-for-each */
t3=*((C_word*)lf[288]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[7]);}

/* k4401 in k4398 in k4395 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_u_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4414(t7,((C_word*)t0)[6],t2,t3);}

/* k4398 in k4395 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:429: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[197]);}

/* k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6237,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[14])){
t4=C_i_cdr(((C_word*)t0)[16]);
/* c-backend.scm:758: intersperse */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_make_character(44));}
else{
/* c-backend.scm:758: intersperse */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[16],C_make_character(44));}}

/* k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6234,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[14])){
t4=C_i_cdr(((C_word*)t0)[16]);
/* c-backend.scm:757: intersperse */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_make_character(44));}
else{
/* c-backend.scm:757: intersperse */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[16],C_make_character(44));}}

/* k2938 in k2935 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2940,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_plus(&a,2,t2,C_fix(1));
/* c-backend.scm:127: gen */
t4=*((C_word*)lf[1]+1);
f_2549(5,t4,((C_word*)t0)[3],lf[37],t3,C_make_character(93));}

/* k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6231,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm:756: make-argument-list */
t4=*((C_word*)lf[295]+1);
f_7141(4,t4,t3,((C_word*)t0)[4],lf[505]);}

/* ##compiler#make-variable-list in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7125,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7131,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:975: list-tabulate */
t5=*((C_word*)lf[545]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}

/* k5153 in k5150 in k5147 in k5144 in k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in ... */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:573: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[261]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5187,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:581: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,C_make_character(41));}}

/* k5150 in k5147 in k5144 in k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in ... */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[6]);}

/* k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6216,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:751: lambda-literal-rest-argument */
t4=*((C_word*)lf[283]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6219,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm:752: lambda-literal-customizable */
t5=*((C_word*)lf[286]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}

/* k4713 in for-each-loop552 in k4693 in k4678 in k4675 in k4672 in k4669 in k4666 in k4663 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4705(t3,((C_word*)t0)[4],t2);}

/* k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6213,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:750: lambda-literal-allocated */
t4=*((C_word*)lf[280]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6210,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6213,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:749: real-name */
t4=*((C_word*)lf[507]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[9]);}

/* k8752 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1213: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[730],t1);}

/* k8681 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8683,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8687,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_cddr(((C_word*)t0)[3]);
t9=C_i_check_list_2(t8,lf[726]);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8702,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8704,a[2]=t7,a[3]=t12,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_8704(t14,t10,t8);}

/* k4744 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4746,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:474: pad0 */
f_4629(t3,((C_word*)t0)[8]);}

/* k8685 in k8681 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1205: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[724],t1,lf[725]);}

/* k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_10273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10273,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[611]);
t4=(C_truep(t3)?t3:C_eqp(t2,lf[612]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10288,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1346: open-output-string */
t6=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_eqp(t2,lf[607]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10312,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1348: open-output-string */
t7=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_eqp(t2,lf[614]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1350: open-output-string */
t8=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=C_eqp(t2,lf[615]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1352: open-output-string */
t9=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=C_eqp(t2,lf[616]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1354: open-output-string */
t10=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t9=C_eqp(t2,lf[609]);
if(C_truep(t9)){
t10=C_i_cadr(((C_word*)t0)[2]);
/* c-backend.scm:1355: foreign-result-conversion */
t11=*((C_word*)lf[168]+1);
f_9916(4,t11,((C_word*)t0)[3],t10,((C_word*)t0)[4]);}
else{
t10=C_eqp(t2,lf[471]);
t11=(C_truep(t10)?t10:C_eqp(t2,lf[610]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10424,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1357: open-output-string */
t13=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=C_eqp(t2,lf[613]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10448,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1358: open-output-string */
t14=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=C_eqp(t2,lf[750]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10472,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1359: open-output-string */
t15=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
/* c-backend.scm:1360: err */
t14=((C_word*)t0)[5];
f_9918(t14,((C_word*)t0)[3]);}}}}}}}}}}
else{
/* c-backend.scm:1361: err */
t2=((C_word*)t0)[5];
f_9918(t2,((C_word*)t0)[3]);}}

/* doloop918 in k6066 in gen-string-constant in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_6073(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6073,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_zerop(t2))){
t4=C_eqp(((C_word*)t0)[2],C_fix(0));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6089,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_6089(t6,t4);}
else{
t6=C_u_i_zerop(((C_word*)t0)[5]);
t7=t5;
f_6089(t7,C_i_not(t6));}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6109,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6124,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6128,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_a_i_plus(&a,2,t3,C_fix(80));
/* c-backend.scm:727: string-like-substring */
f_6134(t6,((C_word*)t0)[4],t3,t7);}}

/* k10286 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10288,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10294,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1346: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[836],C_SCHEME_FALSE,t3);}

/* k2912 in k2909 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:121: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,C_make_character(59));}

/* k2915 in k2912 in k2909 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[2]);
/* c-backend.scm:122: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2654(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5]);}

/* k2909 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* c-backend.scm:120: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8747(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8747,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8754,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:1213: foreign-type-declaration */
t4=*((C_word*)lf[174]+1);
f_8254(4,t4,t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[6],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[3]);
t5=t2;
f_8764(t5,C_eqp(lf[752],t4));}
else{
t4=t2;
f_8764(t4,C_SCHEME_FALSE);}}}

/* k6066 in gen-string-constant in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6068,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_6073(t6,((C_word*)t0)[5],((C_word*)t0)[6],C_fix(0));}

/* k2965 in k2962 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:132: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[40]);}

/* k2962 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:131: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* gen-string-constant in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_6058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6058,NULL,3,t0,t1,t2);}
t3=C_block_size(t2);
t4=t3;
t5=C_fixnum_divide(t4,C_fix(80));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6068,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:721: modulo */
t8=*((C_word*)lf[367]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,C_fix(80));}

/* k6054 in gen-lit in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5923(t2,C_i_not(t1));}

/* k2802 in k2799 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:99: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[30]);}

/* k5453 in k5450 in k5447 in k5444 in g776 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5458,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5465,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5469,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:657: make-argument-list */
t5=*((C_word*)lf[295]+1);
f_7141(4,t5,t4,((C_word*)t0)[3],lf[317]);}

/* k2805 in k2802 in k2799 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:100: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k5450 in k5447 in k5444 in g776 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:656: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,t2,C_SCHEME_TRUE,lf[318],((C_word*)t0)[3],C_make_character(44));}

/* k2799 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:98: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k5456 in k5453 in k5450 in k5447 in k5444 in g776 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:658: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[316]);}

/* k4379 in k4376 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:424: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2811 in k2808 in k2805 in k2802 in k2799 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2816,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_caddr(((C_word*)t0)[3]);
/* c-backend.scm:102: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k5444 in g776 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:654: gen */
t3=*((C_word*)lf[1]+1);
f_2549(8,t3,t2,C_SCHEME_TRUE,lf[319],((C_word*)t0)[3],lf[320],((C_word*)t0)[3],lf[321]);}

/* k2814 in k2811 in k2808 in k2805 in k2802 in k2799 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:103: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_i_check_list_2(t3,lf[57]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5475,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5541,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5541(t9,t5,t3);}

/* g776 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5442(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5442,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5446,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:652: gen */
t4=*((C_word*)lf[1]+1);
f_2549(13,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[322],t2,lf[323],C_SCHEME_TRUE,lf[324],t2,lf[325],t2,lf[326]);}

/* k2808 in k2805 in k2802 in k2799 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:101: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[29]);}

/* k5447 in k5444 in g776 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:655: restore */
f_5325(t2,((C_word*)t0)[3]);}

/* k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8672,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8683,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1206: foreign-type-declaration */
t5=*((C_word*)lf[174]+1);
f_8254(4,t5,t3,t4,lf[729]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8747,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[7],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8747(t5,C_eqp(lf[609],t4));}
else{
t4=t2;
f_8747(t4,C_SCHEME_FALSE);}}}

/* k3693 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3695,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:291: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,((C_word*)t0)[4],lf[115],((C_word*)((C_word*)t0)[2])[1],lf[116]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3708,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3712,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadddr(((C_word*)t0)[5]);
/* c-backend.scm:293: ##sys#symbol->qualified-string */
t6=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k8677 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1204: str */
t2=((C_word*)t0)[2];
f_8261(t2,((C_word*)t0)[3],t1);}

/* k3679 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:285: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[111],t1,lf[112]);}

/* k3686 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:286: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[113],t1,lf[114]);}

/* k8664 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1201: foreign-type-declaration */
t2=*((C_word*)lf[174]+1);
f_8254(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k4395 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:428: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k6504 in k6501 in k6498 in k6495 in k6492 in k6488 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in ... */
static void C_ccall f_6506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:831: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,t2,C_SCHEME_TRUE,lf[404],((C_word*)t0)[5],lf[405]);}

/* k6507 in k6504 in k6501 in k6498 in k6495 in k6492 in k6488 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in ... */
static void C_ccall f_6509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6509,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_6303(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6518,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:833: gen */
t4=*((C_word*)lf[1]+1);
f_2549(6,t4,t3,C_SCHEME_TRUE,lf[402],((C_word*)t0)[2],lf[403]);}}

/* k3669 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* c-backend.scm:287: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,((C_word*)t0)[3],lf[108],((C_word*)((C_word*)t0)[2])[1],lf[109]);}

/* k6498 in k6495 in k6492 in k6488 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in ... */
static void C_ccall f_6500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:822: gen */
t3=*((C_word*)lf[1]+1);
f_2549(16,t3,t2,C_SCHEME_TRUE,lf[412],((C_word*)t0)[5],lf[413],C_SCHEME_TRUE,lf[414],((C_word*)t0)[5],lf[415],C_SCHEME_TRUE,lf[416],C_SCHEME_TRUE,lf[417],C_SCHEME_TRUE,lf[418]);}

/* k6501 in k6498 in k6495 in k6492 in k6488 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in ... */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:827: gen */
t3=*((C_word*)lf[1]+1);
f_2549(14,t3,t2,C_SCHEME_TRUE,lf[406],((C_word*)t0)[6],lf[407],C_SCHEME_TRUE,lf[408],C_SCHEME_TRUE,lf[409],((C_word*)t0)[6],lf[410],C_SCHEME_TRUE,lf[411]);}

/* k4076 in k4058 in k4055 in k4107 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
/* c-backend.scm:359: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[3],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_4063(2,t3,t2);}}

/* k6094 in k6087 in doloop918 in k6066 in gen-string-constant in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:726: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],t1);}

/* for-each-loop980 in k6751 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in ... */
static void C_fcall f_6776(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6776,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6786,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6762,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(t6);
t9=C_eqp(t8,lf[466]);
if(C_truep(t9)){
t10=C_u_i_car(t6);
/* c-backend.scm:806: gen */
t11=*((C_word*)lf[1]+1);
f_2549(7,t11,t5,C_SCHEME_TRUE,lf[467],C_make_character(32),t10,C_make_character(59));}
else{
t10=C_eqp(t8,lf[468]);
if(C_truep(t10)){
t11=C_u_i_car(t6);
/* c-backend.scm:806: gen */
t12=*((C_word*)lf[1]+1);
f_2549(7,t12,t5,C_SCHEME_TRUE,lf[469],C_make_character(32),t11,C_make_character(59));}
else{
t11=C_eqp(t8,lf[15]);
if(C_truep(t11)){
t12=C_u_i_car(t6);
/* c-backend.scm:806: gen */
t13=*((C_word*)lf[1]+1);
f_2549(7,t13,t5,C_SCHEME_TRUE,lf[470],C_make_character(32),t12,C_make_character(59));}
else{
t12=C_eqp(t8,lf[471]);
if(C_truep(t12)){
t13=C_u_i_car(t6);
/* c-backend.scm:806: gen */
t14=*((C_word*)lf[1]+1);
f_2549(7,t14,t5,C_SCHEME_TRUE,lf[472],C_make_character(32),t13,C_make_character(59));}
else{
t13=C_eqp(t8,lf[473]);
if(C_truep(t13)){
t14=C_u_i_car(t6);
/* c-backend.scm:806: gen */
t15=*((C_word*)lf[1]+1);
f_2549(7,t15,t5,C_SCHEME_TRUE,lf[474],C_make_character(32),t14,C_make_character(59));}
else{
t14=C_eqp(t8,lf[12]);
if(C_truep(t14)){
t15=C_u_i_car(t6);
/* c-backend.scm:806: gen */
t16=*((C_word*)lf[1]+1);
f_2549(7,t16,t5,C_SCHEME_TRUE,lf[475],C_make_character(32),t15,C_make_character(59));}
else{
/* c-backend.scm:743: bomb */
t15=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t7,lf[476],t8);}}}}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4376 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:423: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4594(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3356 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:213: gen */
t2=*((C_word*)lf[1]+1);
f_2549(7,t2,((C_word*)t0)[2],lf[87],((C_word*)t0)[3],lf[88],t1,lf[89]);}

/* k6087 in doloop918 in k6066 in gen-string-constant in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_6089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6089,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6096,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6100,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:726: string-like-substring */
f_6134(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8211 in k8208 in k8202 in k8199 in k8196 in k8193 in generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8221,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm:1141: pair-for-each */
t4=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k8208 in k8202 in k8199 in k8196 in k8193 in generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8210,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8213,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8252,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1140: foreign-type-declaration */
t5=*((C_word*)lf[174]+1);
f_8254(4,t5,t4,((C_word*)t0)[7],lf[668]);}

/* k8214 in k8211 in k8208 in k8202 in k8199 in k8196 in k8193 in generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1146: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k6760 in for-each-loop980 in k6751 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_u_i_car(((C_word*)t0)[2]);
/* c-backend.scm:806: gen */
t3=*((C_word*)lf[1]+1);
f_2549(7,t3,((C_word*)t0)[3],C_SCHEME_TRUE,t1,C_make_character(32),t2,C_make_character(59));}

/* k3345 in k3342 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:216: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k10070 in k10067 in k10064 in k10058 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1330: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* a8220 in k8211 in k8208 in k8202 in k8199 in k8196 in k8193 in generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8221,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8225,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8240,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_i_car(t3);
t7=C_i_car(t2);
/* c-backend.scm:1143: foreign-type-declaration */
t8=*((C_word*)lf[174]+1);
f_8254(4,t8,t5,t6,t7);}

/* k8223 in a8220 in k8211 in k8208 in k8202 in k8199 in k8196 in k8193 in generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
/* c-backend.scm:1144: gen */
t4=*((C_word*)lf[1]+1);
f_2549(3,t4,((C_word*)t0)[3],C_make_character(44));}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3342 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:215: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k5927 in k5921 in gen-lit in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5929,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=*((C_word*)lf[353]+1);
t3=C_eqp(((C_word*)t0)[3],*((C_word*)lf[353]+1));
if(C_truep(t3)){
/* c-backend.scm:697: gen */
t4=*((C_word*)lf[1]+1);
f_2549(5,t4,((C_word*)t0)[2],C_SCHEME_TRUE,((C_word*)t0)[4],lf[354]);}
else{
if(C_truep(C_booleanp(((C_word*)t0)[3]))){
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:699: gen */
t4=*((C_word*)lf[1]+1);
f_2549(7,t4,((C_word*)t0)[2],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),lf[355],C_make_character(59));}
else{
/* c-backend.scm:699: gen */
t4=*((C_word*)lf[1]+1);
f_2549(7,t4,((C_word*)t0)[2],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),lf[356],C_make_character(59));}}
else{
if(C_truep(C_charp(((C_word*)t0)[3]))){
t4=C_fix(C_character_code(((C_word*)t0)[3]));
/* c-backend.scm:701: gen */
t5=*((C_word*)lf[1]+1);
f_2549(7,t5,((C_word*)t0)[2],C_SCHEME_TRUE,((C_word*)t0)[4],lf[357],t4,lf[358]);}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t4=C_slot(((C_word*)t0)[3],C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5979,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:704: c-ify-string */
t7=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
/* c-backend.scm:709: gen */
t4=*((C_word*)lf[1]+1);
f_2549(5,t4,((C_word*)t0)[2],C_SCHEME_TRUE,((C_word*)t0)[4],lf[362]);}
else{
t4=C_immp(((C_word*)t0)[3]);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_lambdainfop(((C_word*)t0)[3]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_fixnump(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_6012(t8,t6);}
else{
t8=C_immp(((C_word*)t0)[3]);
t9=t7;
f_6012(t9,C_i_not(t8));}}}}}}}}}

/* k10169 in k10163 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1334: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10172 in k10169 in k10163 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1334: ##sys#write-char-0 */
t3=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[4]);}

/* a6545 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in ... */
static void C_ccall f_6546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6546,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6554,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:809: literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5726(3,t5,t4,t2);}

/* k10175 in k10172 in k10169 in k10163 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1334: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10085 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10087,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10093,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1331: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[826],C_SCHEME_FALSE,t3);}

/* k5921 in gen-lit in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5923(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5923,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:694: gen */
t2=*((C_word*)lf[1]+1);
f_2549(7,t2,((C_word*)t0)[2],C_SCHEME_TRUE,((C_word*)t0)[3],lf[351],((C_word*)t0)[4],lf[352]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:695: block-variable-literal? */
t3=*((C_word*)lf[349]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}}

/* k6784 in for-each-loop980 in k6751 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6776(t3,((C_word*)t0)[4],t2);}

/* k3217 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[2]);
/* c-backend.scm:182: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2654(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5]);}

/* k10187 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10189,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10195,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1335: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[831],C_SCHEME_FALSE,t3);}

/* k8238 in a8220 in k8211 in k8208 in k8202 in k8199 in k8196 in k8193 in generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1143: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],t1);}

/* loop in k5854 in k5836 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5885(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5885,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[2]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_a_i_plus(&a,2,t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5907,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(((C_word*)t0)[4],t2);
/* c-backend.scm:688: literal-size */
t8=((C_word*)((C_word*)t0)[5])[1];
f_5726(3,t8,t6,t7);}}

/* k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5084,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:535: ##sys#hash-table-for-each */
t4=*((C_word*)lf[288]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* k5014 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5016,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_i_check_list_2(t2,lf[57]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5061,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5061(t7,((C_word*)t0)[3],t2);}

/* k3315 in k3294 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:204: uncommentify */
t2=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10193 in k10187 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1335: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10196 in k10193 in k10187 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1335: ##sys#write-char-0 */
t3=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[4]);}

/* k3311 in k3294 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:204: gen */
t2=*((C_word*)lf[1]+1);
f_2549(5,t2,((C_word*)t0)[2],lf[79],t1,lf[80]);}

/* k6516 in k6507 in k6504 in k6501 in k6498 in k6495 in k6492 in k6488 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in ... */
static void C_ccall f_6518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:834: literal-frame */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5670(t3,t2);}

/* prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5009(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5009,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5013,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:534: gen */
t5=*((C_word*)lf[1]+1);
f_2549(3,t5,t4,C_SCHEME_TRUE);}

/* k2867 in loop in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* c-backend.scm:112: expr */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2654(t4,t2,t3,((C_word*)t0)[3]);}

/* k3300 in k3297 in k3294 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:206: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k5861 in k5854 in k5836 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5863,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_plus(&a,2,C_fix(2),t1));}

/* compute-size in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7602,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=C_eqp(t5,lf[15]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7612,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7612(t8,t6);}
else{
t8=C_eqp(t5,lf[473]);
if(C_truep(t8)){
t9=t7;
f_7612(t9,t8);}
else{
t9=C_eqp(t5,lf[638]);
if(C_truep(t9)){
t10=t7;
f_7612(t10,t9);}
else{
t10=C_eqp(t5,lf[639]);
if(C_truep(t10)){
t11=t7;
f_7612(t11,t10);}
else{
t11=C_eqp(t5,lf[12]);
if(C_truep(t11)){
t12=t7;
f_7612(t12,t11);}
else{
t12=C_eqp(t5,lf[561]);
if(C_truep(t12)){
t13=t7;
f_7612(t13,t12);}
else{
t13=C_eqp(t5,lf[640]);
if(C_truep(t13)){
t14=t7;
f_7612(t14,t13);}
else{
t14=C_eqp(t5,lf[641]);
if(C_truep(t14)){
t15=t7;
f_7612(t15,t14);}
else{
t15=C_eqp(t5,lf[642]);
if(C_truep(t15)){
t16=t7;
f_7612(t16,t15);}
else{
t16=C_eqp(t5,lf[643]);
if(C_truep(t16)){
t17=t7;
f_7612(t17,t16);}
else{
t17=C_eqp(t5,lf[644]);
if(C_truep(t17)){
t18=t7;
f_7612(t18,t17);}
else{
t18=C_eqp(t5,lf[645]);
t19=t7;
f_7612(t19,(C_truep(t18)?t18:C_eqp(t5,lf[646])));}}}}}}}}}}}}

/* k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7600,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7602,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:1112: fold */
t7=*((C_word*)lf[432]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,((C_word*)t4)[1],lf[663],((C_word*)t0)[6],t2);}

/* k10292 in k10286 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1346: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10295 in k10292 in k10286 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1346: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[835],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3263 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:192: c-ify-string */
t2=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2873 in k2870 in k2867 in loop in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t5=C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
/* c-backend.scm:114: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_2859(t6,((C_word*)t0)[6],t3,t4,t5);}

/* k2870 in k2867 in loop in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:113: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,C_make_character(59));}

/* k10136 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10138,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10144,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1333: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[829],C_SCHEME_FALSE,t3);}

/* k3259 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:191: gen */
t2=*((C_word*)lf[1]+1);
f_2549(7,t2,((C_word*)t0)[2],lf[70],((C_word*)t0)[3],lf[71],t1,C_make_character(41));}

/* k10142 in k10136 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1333: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6249,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_6252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm:762: lambda-literal-rest-argument-mode */
t4=*((C_word*)lf[282]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* k3366 in k3363 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:221: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6246,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_6249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t2,a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm:761: lambda-literal-direct */
t4=*((C_word*)lf[281]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6243,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_6246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm:760: lambda-literal-looping */
t4=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* k10145 in k10142 in k10136 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1333: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[828],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3363 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3368,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:220: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k3360 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:214: uncommentify */
t2=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5593 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:639: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,t2,C_SCHEME_TRUE,lf[329],((C_word*)t0)[4],lf[330]);}

/* k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6240,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm:759: lambda-literal-external */
t4=*((C_word*)lf[335]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* k5596 in k5593 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:640: restore */
f_5325(t2,((C_word*)((C_word*)t0)[3])[1]);}

/* gen-lit in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5916(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5916,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5923,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6056,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:693: big-fixnum? */
t6=*((C_word*)lf[366]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t5=t4;
f_5923(t5,C_SCHEME_FALSE);}}

/* loop in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_2859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2859,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_greaterp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2869,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:111: gen */
t6=*((C_word*)lf[1]+1);
f_2549(6,t6,t5,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t5=C_i_car(t2);
/* c-backend.scm:115: expr */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2654(t6,t1,t5,t3);}}

/* k10148 in k10145 in k10142 in k10136 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1333: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5583,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:635: lambda-literal-direct */
t3=*((C_word*)lf[281]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[11]);}

/* k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5589,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:637: gen */
t3=*((C_word*)lf[1]+1);
f_2549(11,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[331],((C_word*)t0)[5],lf[332],C_SCHEME_TRUE,lf[333],((C_word*)t0)[5],lf[334]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[9])){
t3=t2;
f_5623(2,t3,((C_word*)t0)[9]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5657,a[2]=t2,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:645: lambda-literal-allocated */
t4=*((C_word*)lf[280]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[11]);}}}}

/* k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5580(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5580,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t3);
t5=t2;
f_5583(t5,t4);}
else{
t3=t2;
f_5583(t3,C_SCHEME_UNDEFINED);}}

/* k10163 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10165,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10171,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1334: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[830],C_SCHEME_FALSE,t3);}

/* k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_6225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6225,NULL,2,t0,t1);}
t2=t1;
t3=(C_truep(t2)?C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1)):C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(0)));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6231,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm:755: make-variable-list */
t6=*((C_word*)lf[284]+1);
f_7125(4,t6,t5,((C_word*)t0)[2],lf[506]);}

/* k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6222,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6939,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:753: lambda-literal-closure-size */
t5=*((C_word*)lf[148]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t3;
f_6225(t4,C_SCHEME_FALSE);}}

/* k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5574,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:632: lambda-literal-customizable */
t4=*((C_word*)lf[286]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[9]);}

/* k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5577,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5580,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5668,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:633: lambda-literal-closure-size */
t5=*((C_word*)lf[148]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t4=t3;
f_5580(t4,C_SCHEME_FALSE);}}

/* k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5571,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:631: lambda-literal-rest-argument-mode */
t4=*((C_word*)lf[282]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}

/* k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in ... */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6258,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=t2,a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(*((C_word*)lf[214]+1))){
/* c-backend.scm:766: string-append */
t4=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[214]+1),lf[502]);}
else{
t4=t3;
f_6261(2,t4,lf[503]);}}

/* k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in ... */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6255,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_6258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm:764: lambda-literal-unboxed-temporaries */
t4=*((C_word*)lf[504]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_6252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6252,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_6255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=t2,a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm:763: lambda-literal-temporaries */
t4=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5564,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5568,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:629: lambda-literal-argument-count */
t5=*((C_word*)lf[287]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5568,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5571,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:630: lambda-literal-rest-argument */
t5=*((C_word*)lf[283]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[7]);}

/* k10482 in k10479 in k10476 in k10470 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1359: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5022 in k5019 in for-each-loop682 in k5014 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5032,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5032(t6,t2,t1);}

/* k10479 in k10476 in k10470 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1359: ##sys#write-char-0 */
t3=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[4]);}

/* k3297 in k3294 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:205: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k5025 in k5022 in k5019 in for-each-loop682 in k5014 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:590: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[246]);}

/* k5168 in k5159 in k5153 in k5150 in k5147 in k5144 in k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in ... */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[4]);}

/* k3294 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3313,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3317,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:204: ##sys#symbol->qualified-string */
t5=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}

/* k5171 in k5168 in k5159 in k5153 in k5150 in k5147 in k5144 in k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in ... */
static void C_ccall f_5173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5173,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* c-backend.scm:579: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,((C_word*)t0)[3],lf[255],t2,lf[256]);}

/* k5019 in for-each-loop682 in k5014 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5021,2,t0,t1);}
t2=*((C_word*)lf[1]+1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5024,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:589: make-list */
t4=*((C_word*)lf[247]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[248]);}

/* for-each-loop552 in k4693 in k4678 in k4675 in k4672 in k4669 in k4666 in k4663 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_4705(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4705,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4715,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:491: gen */
t5=*((C_word*)lf[1]+1);
f_2549(4,t5,t3,C_SCHEME_TRUE,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10064 in k10058 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1330: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10058 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10060,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10066,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1330: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[825],C_SCHEME_FALSE,t3);}

/* k10067 in k10064 in k10058 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1330: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[824],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_10033(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10033,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1329: open-output-string */
t3=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[610]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1330: open-output-string */
t4=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[629]);
t4=(C_truep(t3)?t3:C_eqp(((C_word*)t0)[4],lf[630]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1331: open-output-string */
t6=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[635]);
t6=(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[634]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1332: open-output-string */
t8=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[632]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1333: open-output-string */
t9=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[626]);
t9=(C_truep(t8)?t8:C_eqp(((C_word*)t0)[4],lf[627]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1334: open-output-string */
t11=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[628]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1335: open-output-string */
t12=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[631]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1336: open-output-string */
t13=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[12]);
if(C_truep(t12)){
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[833]);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[561]);
t14=(C_truep(t13)?t13:C_eqp(((C_word*)t0)[4],lf[641]));
if(C_truep(t14)){
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[834]);}
else{
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[5]))){
/* c-backend.scm:1340: ##sys#hash-table-ref */
t16=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,*((C_word*)lf[617]+1),((C_word*)t0)[5]);}
else{
t16=t15;
f_10246(2,t16,C_SCHEME_FALSE);}}}}}}}}}}}}

/* k10034 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10036,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10042,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1329: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[823],C_SCHEME_FALSE,t3);}

/* k10458 in k10455 in k10452 in k10446 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1358: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6751 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in ... */
static void C_ccall f_6753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6753,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[57]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6776,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6776(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10043 in k10040 in k10034 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1329: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[822],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10040 in k10034 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1329: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10046 in k10043 in k10040 in k10034 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1329: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5185 in k5153 in k5150 in k5147 in k5144 in k5141 in k5138 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in ... */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:584: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,((C_word*)t0)[2],C_make_character(59));}
else{
/* c-backend.scm:583: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[262]);}}

/* k5854 in k5836 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5856,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* c-backend.scm:682: words */
t4=*((C_word*)lf[347]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
if(C_truep(C_structurep(((C_word*)t0)[3]))){
t2=C_block_size(((C_word*)t0)[3]);
t3=t2;
t4=C_a_i_plus(&a,2,C_fix(2),t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5885,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5885(t8,((C_word*)t0)[2],C_fix(0),t4);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
/* c-backend.scm:670: bomb */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[346],t3);}}}

/* k10091 in k10085 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1331: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10094 in k10091 in k10085 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1331: ##sys#write-char-0 */
t3=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[4]);}

/* k10097 in k10094 in k10091 in k10085 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1331: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* err in foreign-argument-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_9303(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9303,NULL,2,t0,t1);}
/* c-backend.scm:1247: quit */
t2=*((C_word*)lf[672]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[760],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_9301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9301,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9303,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=C_eqp(t4,lf[641]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[761]);}
else{
t6=C_eqp(t4,lf[15]);
t7=(C_truep(t6)?t6:C_eqp(t4,lf[642]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[762]);}
else{
t8=C_eqp(t4,lf[645]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9331,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_9331(t10,t8);}
else{
t10=C_eqp(t4,lf[473]);
if(C_truep(t10)){
t11=t9;
f_9331(t11,t10);}
else{
t11=C_eqp(t4,lf[638]);
if(C_truep(t11)){
t12=t9;
f_9331(t12,t11);}
else{
t12=C_eqp(t4,lf[643]);
if(C_truep(t12)){
t13=t9;
f_9331(t13,t12);}
else{
t13=C_eqp(t4,lf[644]);
t14=t9;
f_9331(t14,(C_truep(t13)?t13:C_eqp(t4,lf[646])));}}}}}}}

/* for-each-loop580 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_4986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4986,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4996,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:508: gen */
t5=*((C_word*)lf[1]+1);
f_2549(10,t5,t3,C_SCHEME_TRUE,lf[241],t4,lf[242],C_SCHEME_TRUE,lf[243],t4,lf[244]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4438 in k4435 in doloop475 in k4401 in k4398 in k4395 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:438: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,C_make_character(58));}

/* k4444 in k4441 in k4438 in k4435 in doloop475 in k4401 in k4398 in k4395 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=C_i_cddr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[4])[1];
f_4414(t4,((C_word*)t0)[5],t2,t3);}

/* k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_a_i_plus(&a,2,t1,((C_word*)t0)[6]);
/* c-backend.scm:250: iota */
t4=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[7],t3,C_fix(1));}

/* k9661 in k9596 in k9569 in k9560 in k9551 in k9356 in k9329 in foreign-argument-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_9663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1304: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[807],t1,lf[808]);}

/* k4441 in k4438 in k4435 in doloop475 in k4401 in k4398 in k4395 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:439: expr */
t4=((C_word*)((C_word*)t0)[6])[1];
f_2654(t4,t2,t3,((C_word*)t0)[7]);}

/* k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3465,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:249: lambda-literal-temporaries */
t3=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3589,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[11])){
t3=t2;
f_3589(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3613,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:264: gen */
t4=*((C_word*)lf[1]+1);
f_2549(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[12],C_make_character(61));}}}

/* k10933 in encode-literal in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1415: ##sys#string-append */
t2=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4435 in doloop475 in k4401 in k4398 in k4395 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:437: expr */
t4=((C_word*)((C_word*)t0)[6])[1];
f_2654(t4,t2,t3,((C_word*)t0)[7]);}

/* k4425 in k4422 in doloop475 in k4401 in k4398 in k4395 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:435: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k4422 in doloop475 in k4401 in k4398 in k4395 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:434: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k3444 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:244: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4594(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3447 in k3444 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:245: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[96]);}

/* k4666 in k4663 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:481: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,C_SCHEME_TRUE);}

/* k4663 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:480: gen-list */
t3=*((C_word*)lf[4]+1);
f_2592(3,t3,t2,*((C_word*)lf[218]+1));}

/* k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3429,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_eqp(lf[32],t2);
if(C_truep(t3)){
t4=C_slot(((C_word*)t0)[2],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t4);
/* c-backend.scm:243: gen */
t7=*((C_word*)lf[1]+1);
f_2549(7,t7,t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[7],lf[97]);}
else{
if(C_truep(((C_word*)t0)[8])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[2],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3629,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:247: lambda-literal-id */
t6=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[12]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=C_slot(((C_word*)t0)[2],C_fix(1));
t6=C_eqp(lf[67],t5);
if(C_truep(t6)){
t7=*((C_word*)lf[134]+1);
if(C_truep(*((C_word*)lf[134]+1))){
t8=t4;
f_3635(t8,C_SCHEME_FALSE);}
else{
t8=*((C_word*)lf[139]+1);
if(C_truep(*((C_word*)lf[139]+1))){
t9=t4;
f_3635(t9,C_SCHEME_FALSE);}
else{
t9=C_u_i_car(((C_word*)t0)[15]);
t10=t4;
f_3635(t10,C_i_not(t9));}}}
else{
t7=t4;
f_3635(t7,C_SCHEME_FALSE);}}}}

/* k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3425(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3425,NULL,2,t0,t1);}
t2=t1;
t3=C_u_i_car(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3429,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[15])){
if(C_truep(*((C_word*)lf[142]+1))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3827,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:239: slashify */
t6=*((C_word*)lf[145]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[16]);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3834,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:240: uncommentify */
t6=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[16]);}}
else{
t5=t4;
f_3429(2,t5,C_SCHEME_UNDEFINED);}}

/* k5621 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5623,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=C_eqp(((C_word*)t0)[7],lf[254]);
t4=t2;
f_5629(t4,C_i_not(t3));}
else{
t3=t2;
f_5629(t3,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5627 in k5621 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5629,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:647: lset-adjoin */
t3=*((C_word*)lf[252]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5637,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:648: lset-adjoin */
t3=*((C_word*)lf[252]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4199 in k4187 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:387: expr-args */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4594(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k4693 in k4678 in k4675 in k4672 in k4669 in k4666 in k4663 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4695,2,t0,t1);}
t2=*((C_word*)lf[209]+1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4705,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4705(t6,((C_word*)t0)[2],*((C_word*)lf[209]+1));}

/* k5608 in k5605 in k5602 in k5599 in k5596 in k5593 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:644: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[327]);}

/* k5615 in k5605 in k5602 in k5599 in k5596 in k5593 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k10470 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10472,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10478,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1359: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[849],C_SCHEME_FALSE,t3);}

/* k10476 in k10470 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1359: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k5602 in k5599 in k5596 in k5593 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5607,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:642: make-argument-list */
t3=*((C_word*)lf[295]+1);
f_7141(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],lf[328]);}

/* k5599 in k5596 in k5593 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:641: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(40));}

/* k5605 in k5602 in k5599 in k5596 in k5593 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5617,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:643: intersperse */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_make_character(44));}

/* k4669 in k4666 in k4663 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[214]+1))){
/* c-backend.scm:482: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,lf[215],*((C_word*)lf[214]+1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4735,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:484: gen */
t4=*((C_word*)lf[1]+1);
f_2549(3,t4,t3,lf[217]);}}

/* k4672 in k4669 in k4666 in k4663 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4677,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:486: gen */
t3=*((C_word*)lf[1]+1);
f_2549(9,t3,t2,C_SCHEME_TRUE,lf[210],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[211],*((C_word*)lf[212]+1),lf[213]);}

/* k6530 in k6495 in k6492 in k6488 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in ... */
static void C_ccall f_6532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(*((C_word*)lf[419]+1))){
/* c-backend.scm:821: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[420],*((C_word*)lf[419]+1),lf[421]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_6500(2,t3,t2);}}

/* k4675 in k4672 in k4669 in k4666 in k4663 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4680,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[206]+1))){
/* c-backend.scm:488: generate-foreign-callback-stub-prototypes */
t3=*((C_word*)lf[207]+1);
f_7214(3,t3,t2,*((C_word*)lf[208]+1));}
else{
t3=t2;
f_4680(2,t3,C_SCHEME_UNDEFINED);}}

/* k4257 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4259,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:395: foreign-argument-conversion */
t4=*((C_word*)lf[173]+1);
f_9301(3,t4,t3,((C_word*)t0)[4]);}

/* k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in ... */
static void C_ccall f_6276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[13])){
t3=t2;
f_6279(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:788: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[482]);}}

/* k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in ... */
static void C_ccall f_6279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6841,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[14])){
t4=C_i_zerop(((C_word*)t0)[7]);
t5=t3;
f_6841(t5,C_i_not(t4));}
else{
t4=t3;
f_6841(t4,C_SCHEME_FALSE);}}

/* k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in ... */
static void C_ccall f_6270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=C_eqp(lf[265],((C_word*)t0)[10]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6891,a[2]=t2,a[3]=((C_word*)t0)[18],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:779: gen */
t5=*((C_word*)lf[1]+1);
f_2549(3,t5,t4,lf[490]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6869,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:772: gen */
t5=*((C_word*)lf[1]+1);
f_2549(3,t5,t4,lf[495]);}}

/* k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in ... */
static void C_ccall f_6273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm:787: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,C_make_character(40));}

/* k4681 in k4678 in k4675 in k4672 in k4669 in k4666 in k4663 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(*((C_word*)lf[206]+1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* c-backend.scm:493: generate-foreign-callback-stub-prototypes */
t2=*((C_word*)lf[207]+1);
f_7214(3,t2,((C_word*)t0)[2],*((C_word*)lf[208]+1));}}

/* k6519 in k6516 in k6507 in k6504 in k6501 in k6498 in k6495 in k6492 in k6488 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in ... */
static void C_ccall f_6521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:835: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[400],((C_word*)t0)[3],lf[401]);}

/* k4678 in k4675 in k4672 in k4669 in k4666 in k4663 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4683,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(*((C_word*)lf[209]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4695,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:490: gen */
t4=*((C_word*)lf[1]+1);
f_2549(3,t4,t3,C_SCHEME_TRUE);}
else{
if(C_truep(*((C_word*)lf[206]+1))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* c-backend.scm:493: generate-foreign-callback-stub-prototypes */
t3=*((C_word*)lf[207]+1);
f_7214(3,t3,((C_word*)t0)[2],*((C_word*)lf[208]+1));}}}

/* k4994 in for-each-loop580 in k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4986(t3,((C_word*)t0)[4],t2);}

/* k4241 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4246,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:396: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k4244 in k4241 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:397: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[171]);}

/* k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3419,NULL,2,t0,t1);}
t2=t1;
t3=(C_truep(t2)?C_i_cadddr(((C_word*)t0)[2]):C_SCHEME_FALSE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[2],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t4)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3841,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3845,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:235: find-lambda */
t8=((C_word*)((C_word*)t0)[15])[1];
f_2639(t8,t7,t2);}
else{
t6=t5;
f_3425(t6,C_SCHEME_FALSE);}}

/* k6552 in a6545 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_ccall f_6554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6554,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_plus(&a,2,((C_word*)t0)[3],t1));}

/* k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3416,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t2,a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[15])){
t4=C_i_cddr(((C_word*)t0)[2]);
t5=C_i_pairp(t4);
t6=t3;
f_3419(t6,(C_truep(t5)?C_i_caddr(((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t4=t3;
f_3419(t4,C_SCHEME_FALSE);}}

/* k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in ... */
static void C_ccall f_6288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm:794: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[479]);}

/* k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in ... */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
/* c-backend.scm:793: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[480]);}
else{
t3=t2;
f_6288(2,t3,C_SCHEME_UNDEFINED);}}

/* k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in ... */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[9]);}

/* k5905 in loop in k5854 in k5836 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5907,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],t1);
/* c-backend.scm:688: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5885(t3,((C_word*)t0)[4],((C_word*)t0)[5],t2);}

/* k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in ... */
static void C_ccall f_6267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6908,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:770: cleanup */
t4=*((C_word*)lf[498]+1);
f_7036(3,t4,t3,((C_word*)t0)[24]);}

/* k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in ... */
static void C_ccall f_6261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6261,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_6264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t2,a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[19])){
/* c-backend.scm:768: debugging */
t4=*((C_word*)lf[499]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[500],lf[501],((C_word*)t0)[10]);}
else{
t4=t3;
f_6264(2,t4,C_SCHEME_UNDEFINED);}}

/* k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in ... */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_6267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* c-backend.scm:769: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in ... */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_6300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
/* c-backend.scm:798: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,t2,C_SCHEME_TRUE,lf[465],((C_word*)t0)[4],C_make_character(59));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6753,a[2]=((C_word*)t0)[23],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6801,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[21])){
t5=C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t6=t4;
f_6801(t6,C_a_i_plus(&a,2,((C_word*)t0)[8],t5));}
else{
t5=t4;
f_6801(t5,((C_word*)t0)[8]);}}}

/* k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in ... */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=C_eqp(((C_word*)t0)[22],lf[254]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t5=t2;
f_6294(t5,t4);}
else{
t4=t2;
f_6294(t4,C_SCHEME_UNDEFINED);}}

/* k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in ... */
static void C_fcall f_6294(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6294,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm:796: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[478]);}

/* k7405 in k7375 in k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in ... */
static void C_ccall f_7407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1063: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,((C_word*)t0)[7],C_make_character(40));}

/* k8199 in k8196 in k8193 in generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8201,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1137: foreign-callback-stub-argument-types */
t4=*((C_word*)lf[665]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* k8202 in k8199 in k8196 in k8193 in generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8204,2,t0,t1);}
t2=t1;
t3=C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8210,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:1139: make-argument-list */
t5=*((C_word*)lf[295]+1);
f_7141(4,t5,t4,t3,lf[669]);}

/* k2981 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:136: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k2984 in k2981 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[6]);
/* c-backend.scm:137: gen */
t4=*((C_word*)lf[1]+1);
f_2549(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k2987 in k2984 in k2981 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:138: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k2990 in k2987 in k2984 in k2981 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:139: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k6410 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in ... */
static void C_ccall f_6412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:884: intersperse */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k7442 in k7408 in k7405 in k7375 in k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in ... */
static void C_ccall f_7444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k10343 in k10340 in k10334 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1350: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[839],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k7446 in k7408 in k7405 in k7375 in k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in ... */
static void C_ccall f_7448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1064: intersperse */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k10340 in k10334 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1350: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10346 in k10343 in k10340 in k10334 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1350: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6965 in k6962 in k6959 in k6956 in k6953 in k6950 in k6947 in k6944 in k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6970,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:924: emit-procedure-table-info */
t3=*((C_word*)lf[512]+1);
f_6979(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k6962 in k6959 in k6956 in k6953 in k6950 in k6947 in k6944 in k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:923: procedures */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6200(t3,t2);}

/* k6959 in k6956 in k6953 in k6950 in k6947 in k6944 in k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:922: trampolines */
t3=((C_word*)((C_word*)t0)[6])[1];
f_5322(t3,t2);}

/* k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in ... */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_greaterp(((C_word*)t0)[2],C_fix(0)))){
/* c-backend.scm:895: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[371],((C_word*)t0)[2],lf[372]);}
else{
t2=((C_word*)t0)[3];
f_6306(2,t2,C_SCHEME_UNDEFINED);}}

/* k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in ... */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:890: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[374]);}

/* k8803 in k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1219: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[736],t1,lf[737],((C_word*)t0)[3]);}

/* k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in ... */
static void C_ccall f_6365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6383,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6383(t7,t2,t3,((C_word*)t0)[5]);}

/* k7408 in k7405 in k7375 in k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in ... */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7444,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7448,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1064: make-argument-list */
t5=*((C_word*)lf[295]+1);
f_7141(4,t5,t4,((C_word*)t0)[6],lf[562]);}

/* k7411 in k7408 in k7405 in k7375 in k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in ... */
static void C_ccall f_7413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(((C_word*)t0)[5],lf[561]);
if(C_truep(t3)){
t4=t2;
f_7416(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:1065: gen */
t4=*((C_word*)lf[1]+1);
f_2549(3,t4,t2,C_make_character(41));}}

/* k7414 in k7411 in k7408 in k7405 in k7375 in k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in ... */
static void C_ccall f_7416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1066: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[560]);}

/* k7417 in k7414 in k7411 in k7408 in k7405 in k7375 in k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in ... */
static void C_ccall f_7419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:1068: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[556],C_SCHEME_TRUE,lf[557]);}
else{
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:1070: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[3],lf[558]);}
else{
/* c-backend.scm:1071: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[559]);}}}

/* k4152 in k4149 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:375: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[162]);}

/* k10310 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10312,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10318,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1348: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[838],C_SCHEME_FALSE,t3);}

/* k6416 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in ... */
static void C_ccall f_6418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),((C_word*)t0)[3]);}

/* k10316 in k10310 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1348: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k6956 in k6953 in k6950 in k6947 in k6944 in k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:921: generate-foreign-callback-stubs */
t3=*((C_word*)lf[513]+1);
f_7579(4,t3,t2,*((C_word*)lf[208]+1),((C_word*)t0)[7]);}

/* k6953 in k6950 in k6947 in k6944 in k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:920: prototypes */
t3=((C_word*)((C_word*)t0)[8])[1];
f_5009(t3,t2);}

/* k4149 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:374: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k6950 in k6947 in k6944 in k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:919: generate-foreign-stubs */
t3=*((C_word*)lf[514]+1);
f_7257(4,t3,t2,*((C_word*)lf[515]+1),((C_word*)t0)[7]);}

/* k8813 in k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8815,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1221: ->string */
t4=*((C_word*)lf[733]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[6],C_fix(3));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8832(t5,C_eqp(lf[616],t4));}
else{
t4=t2;
f_8832(t4,C_SCHEME_FALSE);}}}

/* k6406 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in ... */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k6987 in k6984 in k6981 in emit-procedure-table-info in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:943: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[530]);}

/* k6984 in k6981 in emit-procedure-table-info in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:942: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[531]);}

/* k6981 in emit-procedure-table-info in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7000,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:933: ##sys#hash-table-for-each */
t4=*((C_word*)lf[288]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8460,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1173: str */
t2=((C_word*)t0)[2];
f_8261(t2,((C_word*)t0)[3],lf[694]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[695]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[696]));
if(C_truep(t3)){
/* c-backend.scm:1174: str */
t4=((C_word*)t0)[2];
f_8261(t4,((C_word*)t0)[3],lf[697]);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[698]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[699]));
if(C_truep(t5)){
/* c-backend.scm:1175: str */
t6=((C_word*)t0)[2];
f_8261(t6,((C_word*)t0)[3],lf[700]);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[701]);
t7=(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[702]));
if(C_truep(t7)){
/* c-backend.scm:1176: str */
t8=((C_word*)t0)[2];
f_8261(t8,((C_word*)t0)[3],lf[703]);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[704]);
t9=(C_truep(t8)?t8:C_eqp(((C_word*)t0)[4],lf[705]));
if(C_truep(t9)){
/* c-backend.scm:1177: str */
t10=((C_word*)t0)[2];
f_8261(t10,((C_word*)t0)[3],lf[706]);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[707]);
t11=(C_truep(t10)?t10:C_eqp(((C_word*)t0)[4],lf[708]));
if(C_truep(t11)){
/* c-backend.scm:1178: str */
t12=((C_word*)t0)[2];
f_8261(t12,((C_word*)t0)[3],lf[709]);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[710]);
t13=(C_truep(t12)?t12:C_eqp(((C_word*)t0)[4],lf[711]));
if(C_truep(t13)){
/* c-backend.scm:1179: str */
t14=((C_word*)t0)[2];
f_8261(t14,((C_word*)t0)[3],lf[712]);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[713]);
t15=(C_truep(t14)?t14:C_eqp(((C_word*)t0)[4],lf[714]));
if(C_truep(t15)){
/* c-backend.scm:1180: str */
t16=((C_word*)t0)[2];
f_8261(t16,((C_word*)t0)[3],lf[715]);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[716]);
t17=(C_truep(t16)?t16:C_eqp(((C_word*)t0)[4],lf[717]));
if(C_truep(t17)){
/* c-backend.scm:1181: str */
t18=((C_word*)t0)[2];
f_8261(t18,((C_word*)t0)[3],lf[718]);}
else{
t18=C_eqp(((C_word*)t0)[4],lf[604]);
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t18)){
t20=t19;
f_8568(t20,t18);}
else{
t20=C_eqp(((C_word*)t0)[4],lf[600]);
if(C_truep(t20)){
t21=t19;
f_8568(t21,t20);}
else{
t21=C_eqp(((C_word*)t0)[4],lf[618]);
if(C_truep(t21)){
t22=t19;
f_8568(t22,t21);}
else{
t22=C_eqp(((C_word*)t0)[4],lf[622]);
t23=t19;
f_8568(t23,(C_truep(t22)?t22:C_eqp(((C_word*)t0)[4],lf[621])));}}}}}}}}}}}}}

/* k8820 in k8813 in k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1221: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,lf[738],((C_word*)t0)[3]);}

/* k10334 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10336,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10342,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1350: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[840],C_SCHEME_FALSE,t3);}

/* k4133 in k4130 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:370: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[157]);}

/* emit-procedure-table-info in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6979,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6983,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7034,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:932: ##sys#hash-table-size */
t6=*((C_word*)lf[542]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4130 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:369: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4594(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k6968 in k6965 in k6962 in k6959 in k6956 in k6953 in k6950 in k6947 in k6944 in k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6970,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4831,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4835,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:498: get-output-string */
t5=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,*((C_word*)lf[511]+1));}

/* k8830 in k8813 in k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8832,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1223: ->string */
t4=*((C_word*)lf[733]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8849,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)t0)[6],C_fix(3)))){
t3=C_i_car(((C_word*)t0)[4]);
t4=t2;
f_8849(t4,C_eqp(lf[613],t3));}
else{
t3=t2;
f_8849(t3,C_SCHEME_FALSE);}}}

/* k8837 in k8830 in k8813 in k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1223: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,lf[739],((C_word*)t0)[3]);}

/* k10013 in k10007 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1325: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10016 in k10013 in k10007 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1325: ##sys#write-char-0 */
t3=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[4]);}

/* k6993 in k6990 in k6987 in k6984 in k6981 in emit-procedure-table-info in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:945: gen */
t2=*((C_word*)lf[1]+1);
f_2549(15,t2,((C_word*)t0)[2],lf[522],C_SCHEME_TRUE,lf[523],C_SCHEME_TRUE,lf[524],C_SCHEME_TRUE,lf[525],C_SCHEME_TRUE,lf[526],C_SCHEME_TRUE,lf[527],C_SCHEME_TRUE,lf[528]);}

/* k6990 in k6987 in k6984 in k6981 in emit-procedure-table-info in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6995,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:944: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[529]);}

/* ##compiler#generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8191,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8195,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1134: foreign-callback-stub-name */
t5=*((C_word*)lf[671]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k8193 in generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8195,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1135: foreign-callback-stub-qualifiers */
t4=*((C_word*)lf[670]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k10322 in k10319 in k10316 in k10310 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1348: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10319 in k10316 in k10310 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1348: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[837],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10019 in k10016 in k10013 in k10007 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1325: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8196 in k8193 in generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8198,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1136: foreign-callback-stub-return-type */
t4=*((C_word*)lf[666]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k4223 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_u_i_car(((C_word*)t0)[2]);
/* c-backend.scm:391: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,((C_word*)t0)[3],t1,t2,C_make_character(41));}

/* k8158 in k8055 in k8052 in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1115: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[661],t1,lf[662]);}

/* k5278 in for-each-loop635 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5270(t3,((C_word*)t0)[4],t2);}

/* k5631 in k5627 in k5621 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* g272 in k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3472,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3476,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:253: gen */
t5=*((C_word*)lf[1]+1);
f_2549(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k5635 in k5627 in k5621 in k5587 in k5581 in k5578 in k5575 in k5572 in k5569 in k5566 in a5563 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3471,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_check_list_2(t2,lf[57]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3488,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3547,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3547(t9,t5,((C_word*)t0)[8],t2);}

/* k8176 in for-each-loop1319 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8168(t3,((C_word*)t0)[4],t2);}

/* k3477 in k3474 in g272 in k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:255: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3474 in g272 in k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3479,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:254: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2654(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k6391 in doloop1056 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in ... */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=C_a_i_minus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_6383(t4,((C_word*)t0)[5],t2,t3);}

/* k3017 in k3014 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[6]);
t4=C_a_i_plus(&a,2,t3,C_fix(1));
/* c-backend.scm:144: gen */
t5=*((C_word*)lf[1]+1);
f_2549(5,t5,t2,lf[45],t4,lf[46]);}

/* k3014 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:143: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* for-each-loop1319 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8168(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8168,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8178,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:1075: g1320 */
t5=((C_word*)t0)[3];
f_7581(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* doloop1056 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in ... */
static void C_fcall f_6383(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6383,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6393,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:894: gen */
t5=*((C_word*)lf[1]+1);
f_2549(6,t5,t4,C_SCHEME_TRUE,lf[373],t2,C_make_character(59));}}

/* k10298 in k10295 in k10292 in k10286 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1346: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5296 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_5112(t3,t2);}

/* for-each-loop405 in k3921 in k3913 in k3896 in k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3931(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3931,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3941,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:334: gen */
t9=*((C_word*)lf[1]+1);
f_2549(8,t9,t6,C_SCHEME_TRUE,C_make_character(116),t8,lf[152],t7,C_make_character(59));}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3486 in k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:259: iota */
t4=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k3924 in k3921 in k3913 in k3896 in k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:336: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[151]);}

/* k3921 in k3913 in k3896 in k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3926,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3931,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3931(t6,t2,((C_word*)t0)[3],t1);}

/* for-each-loop635 in k5132 in k5113 in k5110 in k5107 in k5104 in k5101 in k5098 in k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5270(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5270,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5280,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:548: g636 */
t5=((C_word*)t0)[3];
f_5116(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4819 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:466: ##sys#decode-seconds */
t2=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k7002 in a6999 in k6981 in emit-procedure-table-info in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(lf[265],((C_word*)t0)[2]);
if(C_truep(t2)){
if(C_truep(*((C_word*)lf[214]+1))){
/* c-backend.scm:938: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,((C_word*)t0)[3],lf[532],*((C_word*)lf[214]+1),lf[533]);}
else{
/* c-backend.scm:939: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,((C_word*)t0)[3],lf[534]);}}
else{
/* c-backend.scm:940: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[535]);}}

/* a6999 in k6981 in emit-procedure-table-info in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7000,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7004,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7026,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:935: string->c-identifier */
t6=*((C_word*)lf[538]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k6712 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in ... */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6726,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=*((C_word*)lf[134]+1);
t5=t3;
f_6726(t5,(C_truep(*((C_word*)lf[134]+1))?C_SCHEME_FALSE:C_i_not(*((C_word*)lf[426]+1))));}
else{
t4=t3;
f_6726(t4,C_SCHEME_FALSE);}}

/* k6715 in k6712 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:859: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[462]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_6624(2,t3,t2);}}

/* k3497 in k3494 in k3486 in k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3502,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:261: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[98]);}
else{
/* c-backend.scm:260: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,t2,C_SCHEME_TRUE,lf[99],((C_word*)t0)[4],C_make_character(59));}}

/* k3494 in k3486 in k3469 in k3466 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3510,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3510(t6,t2,((C_word*)t0)[5],t1);}

/* for-each-loop1213 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7556(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7556,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7566,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:1008: g1214 */
t5=((C_word*)t0)[3];
f_7259(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7024 in a6999 in k6981 in emit-procedure-table-info in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:935: gen */
t2=*((C_word*)lf[1]+1);
f_2549(8,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[536],((C_word*)t0)[3],C_make_character(58),t1,lf[537]);}

/* k4829 in k6968 in k6965 in k6962 in k6959 in k6956 in k6953 in k6950 in k6947 in k6944 in k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:496: gen */
t2=*((C_word*)lf[1]+1);
f_2549(11,t2,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[508],C_SCHEME_TRUE,t1,lf[509],C_SCHEME_TRUE,lf[510],C_SCHEME_TRUE);}

/* declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_4837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4837,NULL,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4844,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:505: gen */
t5=*((C_word*)lf[1]+1);
f_2549(5,t5,t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[245]);}

/* k4833 in k6968 in k6965 in k6962 in k6959 in k6956 in k6953 in k6950 in k6947 in k6944 in k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:497: uncommentify */
t2=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7263,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7266,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1012: real-name2 */
t4=*((C_word*)lf[596]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[4]);}

/* k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7266,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1013: foreign-stub-argument-types */
t4=*((C_word*)lf[595]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7269,2,t0,t1);}
t2=t1;
t3=C_i_length(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7275,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7548,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1015: make-variable-list */
t7=*((C_word*)lf[284]+1);
f_7125(4,t7,t6,t4,lf[594]);}

/* k6724 in k6712 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_fcall f_6726(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm:858: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[463]);}
else{
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:859: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[462]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
f_6624(2,t3,t2);}}}

/* k3089 in k3086 in k3083 in k3080 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:160: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k5304 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:540: intersperse */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7275,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:1016: foreign-stub-return-type */
t4=*((C_word*)lf[592]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}

/* k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7278,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:1017: foreign-stub-name */
t4=*((C_word*)lf[591]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}

/* k3086 in k3083 in k3080 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:159: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k3083 in k3080 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:158: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[52]);}

/* k3939 in for-each-loop405 in k3921 in k3913 in k3896 in k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3931(t4,((C_word*)t0)[5],t2,t3);}

/* k3080 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:157: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k4811 in k4756 in k4752 in k4748 in k4744 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:477: string-split */
t2=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[229]);}

/* k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7284,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:1019: foreign-stub-argument-names */
t4=*((C_word*)lf[589]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_7290(2,t3,t1);}
else{
/* c-backend.scm:1019: make-list */
t3=*((C_word*)lf[247]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE);}}

/* k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7281,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:1018: foreign-stub-body */
t4=*((C_word*)lf[590]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[9]);}

/* k4842 in declarations in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4844,2,t0,t1);}
t2=*((C_word*)lf[216]+1);
t3=C_i_check_list_2(*((C_word*)lf[216]+1),lf[57]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4986,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4986(t8,t4,*((C_word*)lf[216]+1));}

/* k8847 in k8830 in k8813 in k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8849,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
t4=t3;
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[740]:C_i_car(t8));
t11=t10;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8868,a[2]=((C_word*)t0)[3],a[3]=t11,a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1229: foreign-type-declaration */
t13=*((C_word*)lf[174]+1);
f_8254(4,t13,t12,t2,lf[748]);}
else{
/* c-backend.scm:1240: err */
t2=((C_word*)t0)[5];
f_8256(t2,((C_word*)t0)[3]);}}

/* k3060 in k3057 in k3054 in k3051 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:153: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k6429 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in ... */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm:899: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,((C_word*)t0)[6],lf[395]);}
else{
/* c-backend.scm:900: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,((C_word*)t0)[7],lf[396],((C_word*)t0)[6]);}}

/* k3057 in k3054 in k3051 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3062,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:152: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k3054 in k3051 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:151: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[49]);}

/* k6444 in k6432 in k6429 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in ... */
static void C_ccall f_6446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),((C_word*)t0)[3]);}

/* k3913 in k3896 in k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3923,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:335: iota */
t4=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[4],C_fix(1),C_fix(1));}

/* k3051 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:150: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k8769 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1215: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[731],t1,lf[732],((C_word*)t0)[3]);}

/* k6435 in k6432 in k6429 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in ... */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:904: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[394]);}

/* k3904 in k3901 in g380 in k3896 in k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:331: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k6432 in k6429 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in ... */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6446,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:902: gen */
t4=*((C_word*)lf[1]+1);
f_2549(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
/* c-backend.scm:904: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,((C_word*)t0)[2],lf[394]);}}

/* k3901 in g380 in k3896 in k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:330: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2654(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k9983 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_9985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9985,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9991,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1324: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[820],C_SCHEME_FALSE,t3);}

/* k10007 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10009,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10015,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1325: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[821],C_SCHEME_FALSE,t3);}

/* k3976 in for-each-loop379 in k3896 in k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3968(t4,((C_word*)t0)[5],t2,t3);}

/* k3590 in k3587 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=t2;
f_3595(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:268: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,((C_word*)t0)[9],C_make_character(44));}}

/* k3596 in k3593 in k3590 in k3587 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:270: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4594(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3593 in k3590 in k3587 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11805,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:270: expr-args */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4594(t4,t3,((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
/* c-backend.scm:269: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,C_make_character(116),((C_word*)t0)[7],C_make_character(44));}}

/* k10963 in encode-literal in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1422: string-intersperse */
t2=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[864]);}

/* k8786 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1217: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[734],t1,lf[735],((C_word*)t0)[3]);}

/* for-each-loop379 in k3896 in k3893 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3968(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3968,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3978,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:325: g380 */
t9=((C_word*)t0)[3];
f_3899(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3020 in k3017 in k3014 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:145: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k3023 in k3020 in k3017 in k3014 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:146: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k10112 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10114,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10120,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1332: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[827],C_SCHEME_FALSE,t3);}

/* k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8781,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1217: ->string */
t4=*((C_word*)lf[733]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[6],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8798(t5,C_eqp(lf[750],t4));}
else{
t4=t2;
f_8798(t4,C_SCHEME_FALSE);}}}

/* k10975 in encode-literal in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1423: cons* */
t2=*((C_word*)lf[865]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k10121 in k10118 in k10112 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1332: ##sys#write-char-0 */
t3=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[4]);}

/* k10124 in k10121 in k10118 in k10112 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1332: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10118 in k10112 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1332: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k9551 in k9356 in k9329 in foreign-argument-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_9553(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9553,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[798]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[604]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9562(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[618]);
if(C_truep(t4)){
t5=t3;
f_9562(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[619]);
if(C_truep(t5)){
t6=t3;
f_9562(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[620]);
t7=t3;
f_9562(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[621])));}}}}}

/* a10978 in encode-literal in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10979,3,t0,t1,t2);}
t3=C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm:1426: encode-literal */
t4=*((C_word*)lf[364]+1);
f_10701(3,t4,t1,t3);}

/* k11007 in k11001 in k2544 in k2541 in k2538 */
static void C_ccall f_11009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11032,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11036,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:57: random */
t5=*((C_word*)lf[866]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_fix(16777216));}

/* k11001 in k2544 in k2541 in k2538 */
static void C_ccall f_11003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11003,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11009,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:57: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[867],C_SCHEME_FALSE,t3);}

/* k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8764,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1215: ->string */
t4=*((C_word*)lf[733]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[6],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8781(t5,C_eqp(lf[751],t4));}
else{
t4=t2;
f_8781(t4,C_SCHEME_FALSE);}}}

/* k11016 in k11013 in k11010 in k11007 in k11001 in k2544 in k2541 in k2538 */
static void C_ccall f_11018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:57: ##sys#write-char-0 */
t3=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(95),((C_word*)t0)[4]);}

/* k4187 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4192,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4201,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:386: gen */
t4=*((C_word*)lf[1]+1);
f_2549(3,t4,t3,C_make_character(44));}
else{
/* c-backend.scm:388: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,((C_word*)t0)[2],C_make_character(41));}}

/* k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8798,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1219: ->string */
t4=*((C_word*)lf[733]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[6],C_fix(3));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8815(t5,C_u_i_memq(t4,lf[749]));}
else{
t4=t2;
f_8815(t4,C_SCHEME_FALSE);}}}

/* k11010 in k11007 in k11001 in k2544 in k2541 in k2538 */
static void C_ccall f_11012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:57: ##sys#write-char-0 */
t3=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(95),((C_word*)t0)[4]);}

/* k11013 in k11010 in k11007 in k11001 in k2544 in k2541 in k2538 */
static void C_ccall f_11015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11028,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:57: current-seconds */
t4=*((C_word*)lf[232]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6634 in k6625 in k6622 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in ... */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[2])){
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
/* c-backend.scm:868: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[447]);}
else{
/* c-backend.scm:869: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[448]);}}
else{
/* c-backend.scm:869: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[448]);}}

/* k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7293,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm:1021: foreign-stub-cps */
t4=*((C_word*)lf[587]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[12]);}

/* k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7299,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm:1023: gen */
t4=*((C_word*)lf[1]+1);
f_2549(3,t4,t3,C_SCHEME_TRUE);}

/* k11026 in k11013 in k11010 in k11007 in k11001 in k2544 in k2541 in k2538 */
static void C_ccall f_11028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:57: ##sys#print */
t2=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7296,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm:1022: foreign-stub-callback */
t4=*((C_word*)lf[586]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[13]);}

/* k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7290,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7293,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm:1020: foreign-result-conversion */
t4=*((C_word*)lf[168]+1);
f_9916(4,t4,t3,((C_word*)t0)[5],lf[588]);}

/* for-each-loop27 in gen in k2544 in k2541 in k2538 */
static void C_fcall f_2569(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2569,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2579,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_eqp(C_SCHEME_TRUE,t4);
if(C_truep(t5)){
/* c-backend.scm:43: newline */
t6=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t3,*((C_word*)lf[0]+1));}
else{
/* c-backend.scm:44: display */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,*((C_word*)lf[0]+1));}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in ... */
static void C_ccall f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:889: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,lf[375],((C_word*)t0)[4],lf[376]);}

/* k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in ... */
static void C_ccall f_6356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[6]);}

/* k4190 in k4187 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:388: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in ... */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:887: gen */
t3=*((C_word*)lf[1]+1);
f_2549(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[377],((C_word*)t0)[7],lf[378]);}

/* k11019 in k11016 in k11013 in k11010 in k11007 in k11001 in k2544 in k2541 in k2538 */
static void C_ccall f_11021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:57: get-output-string */
t3=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k11022 in k11019 in k11016 in k11013 in k11010 in k11007 in k11001 in k2544 in k2541 in k2538 */
static void C_ccall f_11024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:56: string->c-identifier */
t2=*((C_word*)lf[538]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in ... */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:885: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,lf[379],((C_word*)t0)[4],lf[380]);}

/* k3587 in k3463 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:267: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[10],C_make_character(40));}

/* k6622 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in ... */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6666,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=*((C_word*)lf[134]+1);
if(C_truep(*((C_word*)lf[134]+1))){
t5=t3;
f_6666(t5,C_SCHEME_FALSE);}
else{
t5=*((C_word*)lf[440]+1);
t6=t3;
f_6666(t6,(C_truep(*((C_word*)lf[440]+1))?C_SCHEME_FALSE:C_i_not(((C_word*)t0)[9])));}}
else{
t4=t3;
f_6666(t4,C_SCHEME_FALSE);}}

/* k6625 in k6622 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6627,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[2])?C_SCHEME_FALSE:(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:C_i_greaterp(((C_word*)t0)[4],C_fix(0))));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6636,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[435]+1))){
/* c-backend.scm:866: gen */
t4=*((C_word*)lf[1]+1);
f_2549(4,t4,t3,C_SCHEME_TRUE,lf[449]);}
else{
t4=t3;
f_6636(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=((C_word*)t0)[6];
f_6303(2,t3,C_SCHEME_UNDEFINED);}}

/* k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in ... */
static void C_ccall f_6347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6408,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6412,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:884: make-argument-list */
t5=*((C_word*)lf[295]+1);
f_7141(4,t5,t4,((C_word*)t0)[4],lf[381]);}

/* k6342 in k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in ... */
static void C_ccall f_6344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:883: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[7],lf[382]);}

/* k6339 in k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in ... */
static void C_ccall f_6341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:882: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,t2,C_SCHEME_TRUE,lf[383],((C_word*)t0)[4],lf[384]);}

/* k2541 in k2538 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* ##compiler#gen in k2544 in k2541 in k2538 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2549r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2549r(t0,t1,t2);}}

static void C_ccall f_2549r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2569,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2569(t6,t1,t2);}

/* k2544 in k2541 in k2538 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=C_set_block_item(lf[0] /* ##compiler#output */,0,C_SCHEME_FALSE);
t3=C_mutate2((C_word*)lf[1]+1 /* (set! ##compiler#gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2549,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2((C_word*)lf[4]+1 /* (set! ##compiler#gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2592,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11003,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:57: open-output-string */
t7=*((C_word*)lf[341]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k2538 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2543,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k4168 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4173,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:379: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4594(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k4171 in k4168 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:380: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k5040 in for-each-loop695 in k5022 in k5019 in for-each-loop682 in k5014 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5032(t3,((C_word*)t0)[4],t2);}

/* k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8331(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8331,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1160: str */
t2=((C_word*)t0)[2];
f_8261(t2,((C_word*)t0)[3],lf[680]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[632]);
if(C_truep(t2)){
/* c-backend.scm:1161: str */
t3=((C_word*)t0)[2];
f_8261(t3,((C_word*)t0)[3],lf[681]);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[638]);
t4=(C_truep(t3)?t3:C_eqp(((C_word*)t0)[4],lf[630]));
if(C_truep(t4)){
/* c-backend.scm:1162: str */
t5=((C_word*)t0)[2];
f_8261(t5,((C_word*)t0)[3],lf[682]);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[635]);
if(C_truep(t5)){
/* c-backend.scm:1163: str */
t6=((C_word*)t0)[2];
f_8261(t6,((C_word*)t0)[3],lf[683]);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[634]);
if(C_truep(t6)){
/* c-backend.scm:1164: str */
t7=((C_word*)t0)[2];
f_8261(t7,((C_word*)t0)[3],lf[684]);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[639]);
if(C_truep(t7)){
/* c-backend.scm:1165: str */
t8=((C_word*)t0)[2];
f_8261(t8,((C_word*)t0)[3],lf[685]);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[628]);
if(C_truep(t8)){
/* c-backend.scm:1166: str */
t9=((C_word*)t0)[2];
f_8261(t9,((C_word*)t0)[3],lf[686]);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[640]);
if(C_truep(t9)){
/* c-backend.scm:1167: str */
t10=((C_word*)t0)[2];
f_8261(t10,((C_word*)t0)[3],lf[687]);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[631]);
if(C_truep(t10)){
/* c-backend.scm:1168: str */
t11=((C_word*)t0)[2];
f_8261(t11,((C_word*)t0)[3],lf[688]);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[598]);
if(C_truep(t11)){
/* c-backend.scm:1169: str */
t12=((C_word*)t0)[2];
f_8261(t12,((C_word*)t0)[3],lf[689]);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[625]);
t13=(C_truep(t12)?t12:C_eqp(((C_word*)t0)[4],lf[633]));
if(C_truep(t13)){
/* c-backend.scm:1170: str */
t14=((C_word*)t0)[2];
f_8261(t14,((C_word*)t0)[3],lf[690]);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[610]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_8439(t16,t14);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[612]);
if(C_truep(t16)){
t17=t15;
f_8439(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[4],lf[758]);
t18=t15;
f_8439(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[4],lf[759])));}}}}}}}}}}}}}}

/* for-each-loop695 in k5022 in k5019 in for-each-loop682 in k5014 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5032(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5032,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5042,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:589: g696 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6314 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in ... */
static void C_ccall f_6316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6316,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:905: expression */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2651(t3,((C_word*)t0)[5],t1,t2,((C_word*)t0)[6]);}
else{
/* c-backend.scm:905: expression */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2651(t2,((C_word*)t0)[5],t1,((C_word*)t0)[3],((C_word*)t0)[6]);}}

/* k7535 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1025: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[584],t1,lf[585]);}

/* k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:906: lambda-literal-body */
t4=*((C_word*)lf[370]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in ... */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:911: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in ... */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t4=C_eqp(lf[265],((C_word*)t0)[10]);
if(C_truep(t4)){
t5=t3;
f_6326(t5,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[14])){
t5=t3;
f_6326(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
t6=t3;
f_6326(t6,(C_truep(t5)?t5:(C_truep(((C_word*)t0)[15])?((C_word*)t0)[15]:C_i_greaterp(((C_word*)t0)[7],C_fix(0)))));}}}

/* k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in ... */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=C_eqp(lf[265],((C_word*)t0)[10]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6490,a[2]=((C_word*)t0)[16],a[3]=t2,a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[18],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6546,a[2]=((C_word*)t0)[19],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:809: fold */
t6=*((C_word*)lf[432]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,C_fix(0),((C_word*)t0)[16]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6560,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[20],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:837: gen */
t5=*((C_word*)lf[1]+1);
f_2549(4,t5,t4,C_SCHEME_TRUE,lf[446]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6624,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[21],a[6]=t2,a[7]=((C_word*)t0)[22],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
t5=(C_truep(((C_word*)t0)[14])?C_SCHEME_FALSE:C_i_greaterp(((C_word*)t0)[7],C_fix(0)));
if(C_truep(t5)){
if(C_truep(((C_word*)t0)[21])){
/* c-backend.scm:851: gen */
t6=*((C_word*)lf[1]+1);
f_2549(10,t6,t4,C_SCHEME_TRUE,lf[456],C_SCHEME_TRUE,lf[457],C_SCHEME_TRUE,lf[458],((C_word*)t0)[7],lf[459]);}
else{
/* c-backend.scm:854: gen */
t6=*((C_word*)lf[1]+1);
f_2549(6,t6,t4,C_SCHEME_TRUE,lf[460],((C_word*)t0)[7],lf[461]);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[21],a[3]=t4,a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[14])){
t7=t6;
f_6714(2,t7,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:856: gen */
t7=*((C_word*)lf[1]+1);
f_2549(4,t7,t6,C_SCHEME_TRUE,lf[464]);}}}}}

/* k7546 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7548,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[593],t1);
/* c-backend.scm:1015: intersperse */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k6336 in k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in ... */
static void C_ccall f_6338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:879: gen */
t3=*((C_word*)lf[1]+1);
f_2549(9,t3,t2,lf[385],C_SCHEME_TRUE,lf[386],C_SCHEME_TRUE,lf[387],((C_word*)t0)[4],lf[388]);}

/* k6333 in k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in ... */
static void C_ccall f_6335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[8],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6418,a[2]=t2,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:877: gen */
t4=*((C_word*)lf[1]+1);
f_2549(5,t4,t3,C_make_character(44),((C_word*)t0)[8],C_make_character(44));}
else{
t3=t2;
f_6338(2,t3,C_SCHEME_UNDEFINED);}}

/* k6330 in k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in ... */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:875: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,lf[389],((C_word*)t0)[7],lf[390]);}

/* k6324 in k6301 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_fcall f_6326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6326,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6332,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[9],C_fix(0)))){
/* c-backend.scm:874: gen */
t3=*((C_word*)lf[1]+1);
f_2549(7,t3,t2,C_SCHEME_TRUE,lf[391],lf[392],((C_word*)t0)[5],C_make_character(114));}
else{
/* c-backend.scm:874: gen */
t3=*((C_word*)lf[1]+1);
f_2549(7,t3,t2,C_SCHEME_TRUE,lf[393],lf[392],((C_word*)t0)[5],C_make_character(114));}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6431,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[9],C_fix(0)))){
/* c-backend.scm:897: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,C_SCHEME_TRUE,lf[397],lf[398]);}
else{
/* c-backend.scm:897: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,C_SCHEME_TRUE,lf[399],lf[398]);}}}
else{
t2=((C_word*)t0)[4];
f_6306(2,t2,C_SCHEME_UNDEFINED);}}

/* for-each-loop815 in k5485 in k5482 in k5476 in k5473 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5495(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5495,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5505,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:661: g816 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6139 in string-like-substring in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6141,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6144,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:732: ##sys#copy-bytes */
t4=*((C_word*)lf[368]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[5]);}

/* k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7594,2,t0,t1);}
t2=t1;
t3=C_i_length(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:1083: make-argument-list */
t6=*((C_word*)lf[295]+1);
f_7141(4,t6,t5,t4,lf[664]);}

/* k6142 in k6139 in string-like-substring in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7591,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7594,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1081: foreign-callback-stub-argument-types */
t4=*((C_word*)lf[665]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* for-each-loop682 in k5014 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5061(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5061,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5071,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5021,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:588: gen */
t8=*((C_word*)lf[1]+1);
f_2549(6,t8,t7,C_SCHEME_TRUE,lf[249],t6,lf[250]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5482 in k5476 in k5473 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:661: emitter */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5361(t3,t2,C_SCHEME_TRUE);}

/* k5485 in k5482 in k5476 in k5473 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5487,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=C_i_check_list_2(t3,lf[57]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5495,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5495(t8,((C_word*)t0)[2],t3);}

/* string-like-substring in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_6134(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6134,NULL,4,t1,t2,t3,t4);}
t5=C_a_i_minus(&a,2,t4,t3);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6141,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:731: make-string */
t8=*((C_word*)lf[369]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}

/* k5766 in k5762 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:677: + */
C_plus(5,0,((C_word*)t0)[2],C_fix(3),((C_word*)t0)[3],t1);}

/* k5762 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5764,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5768,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* c-backend.scm:677: literal-size */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5726(3,t6,t3,t5);}

/* k10370 in k10367 in k10364 in k10358 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1352: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5473 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:660: emitter */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5361(t3,t2,C_SCHEME_FALSE);}

/* generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7579,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7581,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_check_list_2(t2,lf[57]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8168,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_8168(t9,t1,t2);}

/* k5476 in k5473 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5478,2,t0,t1);}
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
t4=C_i_check_list_2(t3,lf[57]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5518,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5518(t9,t5,t3);}

/* k5346 in doloop725 in restore in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5348,2,t0,t1);}
t2=C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_5338(t4,((C_word*)t0)[5],t2,t3);}

/* k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7585,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7588,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1079: real-name2 */
t4=*((C_word*)lf[596]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[4]);}

/* k5463 in k5453 in k5450 in k5447 in k5444 in g776 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7588,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1080: foreign-callback-stub-return-type */
t4=*((C_word*)lf[666]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k5467 in k5453 in k5450 in k5447 in k5444 in g776 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:657: intersperse */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k6495 in k6492 in k6488 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in ... */
static void C_ccall f_6497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(*((C_word*)lf[214]+1))){
t3=t2;
f_6500(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6532,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[422]+1))){
/* c-backend.scm:818: gen */
t4=*((C_word*)lf[1]+1);
f_2549(8,t4,t3,C_SCHEME_TRUE,lf[423],*((C_word*)lf[422]+1),lf[424],C_SCHEME_TRUE,lf[425]);}
else{
t4=t3;
f_6532(2,t4,C_SCHEME_UNDEFINED);}}}

/* g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7581(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7581,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7585,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1078: foreign-callback-stub-id */
t4=*((C_word*)lf[667]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6488 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in ... */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6490,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_length(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6494,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:811: gen */
t6=*((C_word*)lf[1]+1);
f_2549(10,t6,t5,C_SCHEME_TRUE,lf[428],C_SCHEME_TRUE,lf[429],C_SCHEME_TRUE,lf[430],((C_word*)t0)[6],lf[431]);}

/* k6492 in k6488 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(*((C_word*)lf[426]+1))){
/* c-backend.scm:815: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[427]);}
else{
t3=t2;
f_6497(2,t3,C_SCHEME_UNDEFINED);}}

/* k4803 in map-loop514 in k4769 in k4756 in k4752 in k4748 in k4744 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4805,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4776(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4776(t6,((C_word*)t0)[5],t5);}}

/* restore in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5325(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5325,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5329,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_minus(&a,2,t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5338,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_5338(t8,t3,t4,C_fix(0));}

/* trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5322,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5325,tmp=(C_word)a,a+=2,tmp));
t11=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5361,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5441,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t1,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5564,a[2]=t7,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:627: ##sys#hash-table-for-each */
t14=*((C_word*)lf[288]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,((C_word*)t0)[2]);}

/* k5318 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5094(t2,C_i_zerop(t1));}

/* k10391 in k10388 in k10382 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1354: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[843],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* doloop725 in restore in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5338(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5338,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_negativep(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5348,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:602: gen */
t5=*((C_word*)lf[1]+1);
f_2549(8,t5,t4,C_SCHEME_TRUE,lf[291],t2,lf[292],t3,lf[293]);}}

/* k10394 in k10391 in k10388 in k10382 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1354: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10388 in k10382 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1354: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k4479 in k4476 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:444: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[200]);}

/* k4482 in k4479 in k4476 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:445: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k4485 in k4482 in k4479 in k4476 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:446: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,C_make_character(58));}

/* k5327 in restore in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:603: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[289],((C_word*)t0)[3],lf[290]);}

/* k10367 in k10364 in k10358 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1352: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[841],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10364 in k10358 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1352: ##sys#print */
t3=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k10358 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10360,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10366,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1352: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[842],C_SCHEME_FALSE,t3);}

/* k7564 in for-each-loop1213 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7556(t3,((C_word*)t0)[4],t2);}

/* k4488 in k4485 in k4482 in k4479 in k4476 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_caddr(((C_word*)t0)[3]);
/* c-backend.scm:447: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:448: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k7686 in k7649 in k7643 in k7631 in k7619 in k7610 in compute-size in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm:1107: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[608]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[609]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm:1108: compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_7602(5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[7],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}}

/* k5791 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5796,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5798,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5798(t6,t2,t1);}

/* map-loop862 in k5791 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5798(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5798,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5827,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:678: g868 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5794 in k5791 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:678: reduce */
t2=*((C_word*)lf[343]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],*((C_word*)lf[344]+1),C_fix(0),t1);}

/* k5787 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:678: + */
C_plus(5,0,((C_word*)t0)[2],C_fix(1),((C_word*)t0)[3],t1);}

/* k4476 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:443: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k6944 in k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:917: declarations */
t3=((C_word*)((C_word*)t0)[9])[1];
f_4837(t3,t2);}

/* k6947 in k6944 in k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:918: generate-external-variables */
t3=*((C_word*)lf[516]+1);
f_7157(3,t3,t2,*((C_word*)lf[517]+1));}

/* k6940 in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6942,2,t0,t1);}
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##compiler#output ...) */,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:916: header */
t4=((C_word*)((C_word*)t0)[11])[1];
f_4626(t4,t3);}

/* k6937 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6225(t2,C_i_zerop(t1));}

/* k8647 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1198: foreign-type-declaration */
t2=*((C_word*)lf[174]+1);
f_8254(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* str in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8261(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8261,NULL,3,t0,t1,t2);}
/* c-backend.scm:1153: string-append */
t3=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[674],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8254,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8256,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8261,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=C_eqp(t6,lf[641]);
if(C_truep(t7)){
/* c-backend.scm:1155: str */
t8=t5;
f_8261(t8,t1,lf[675]);}
else{
t8=C_eqp(t6,lf[15]);
t9=(C_truep(t8)?t8:C_eqp(t6,lf[645]));
if(C_truep(t9)){
/* c-backend.scm:1156: str */
t10=t5;
f_8261(t10,t1,lf[676]);}
else{
t10=C_eqp(t6,lf[642]);
t11=(C_truep(t10)?t10:C_eqp(t6,lf[646]));
if(C_truep(t11)){
/* c-backend.scm:1157: str */
t12=t5;
f_8261(t12,t1,lf[677]);}
else{
t12=C_eqp(t6,lf[643]);
t13=(C_truep(t12)?t12:C_eqp(t6,lf[626]));
if(C_truep(t13)){
/* c-backend.scm:1158: str */
t14=t5;
f_8261(t14,t1,lf[678]);}
else{
t14=C_eqp(t6,lf[644]);
t15=(C_truep(t14)?t14:C_eqp(t6,lf[627]));
if(C_truep(t15)){
/* c-backend.scm:1159: str */
t16=t5;
f_8261(t16,t1,lf[679]);}
else{
t16=C_eqp(t6,lf[473]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8331,a[2]=t5,a[3]=t1,a[4]=t6,a[5]=t3,a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_8331(t18,t16);}
else{
t18=C_eqp(t6,lf[629]);
t19=t17;
f_8331(t19,(C_truep(t18)?t18:C_eqp(t6,lf[12])));}}}}}}}

/* k8250 in k8208 in k8202 in k8199 in k8196 in k8193 in generate-foreign-callback-header in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1140: gen */
t2=*((C_word*)lf[1]+1);
f_2549(10,t2,((C_word*)t0)[2],C_SCHEME_TRUE,((C_word*)t0)[3],C_make_character(32),t1,((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[5],C_make_character(40));}

/* k10382 in k10271 in k10244 in k10031 in foreign-result-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10384,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10390,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1354: ##sys#print */
t6=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[844],C_SCHEME_FALSE,t3);}

/* k9356 in k9329 in foreign-argument-conversion in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_9358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9358,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[767]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[629]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[630]));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[768]);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[635]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[769]);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[632]);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[770]);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[634]);
if(C_truep(t6)){
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[771]);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[628]);
if(C_truep(t7)){
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[772]);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[626]);
t9=(C_truep(t8)?t8:C_eqp(((C_word*)t0)[3],lf[627]));
if(C_truep(t9)){
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[773]);}
else{
t10=C_eqp(((C_word*)t0)[3],lf[758]);
if(C_truep(t10)){
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[774]);}
else{
t11=C_eqp(((C_word*)t0)[3],lf[759]);
if(C_truep(t11)){
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[775]);}
else{
t12=C_eqp(((C_word*)t0)[3],lf[610]);
if(C_truep(t12)){
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[776]);}
else{
t13=C_eqp(((C_word*)t0)[3],lf[612]);
if(C_truep(t13)){
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[777]);}
else{
t14=C_eqp(((C_word*)t0)[3],lf[693]);
if(C_truep(t14)){
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[778]);}
else{
t15=C_eqp(((C_word*)t0)[3],lf[755]);
if(C_truep(t15)){
t16=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[779]);}
else{
t16=C_eqp(((C_word*)t0)[3],lf[756]);
if(C_truep(t16)){
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[780]);}
else{
t17=C_eqp(((C_word*)t0)[3],lf[757]);
if(C_truep(t17)){
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[781]);}
else{
t18=C_eqp(((C_word*)t0)[3],lf[695]);
if(C_truep(t18)){
t19=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[782]);}
else{
t19=C_eqp(((C_word*)t0)[3],lf[696]);
if(C_truep(t19)){
t20=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[783]);}
else{
t20=C_eqp(((C_word*)t0)[3],lf[701]);
if(C_truep(t20)){
t21=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[784]);}
else{
t21=C_eqp(((C_word*)t0)[3],lf[702]);
if(C_truep(t21)){
t22=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[785]);}
else{
t22=C_eqp(((C_word*)t0)[3],lf[698]);
if(C_truep(t22)){
t23=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[786]);}
else{
t23=C_eqp(((C_word*)t0)[3],lf[699]);
if(C_truep(t23)){
t24=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[787]);}
else{
t24=C_eqp(((C_word*)t0)[3],lf[704]);
if(C_truep(t24)){
t25=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[788]);}
else{
t25=C_eqp(((C_word*)t0)[3],lf[705]);
if(C_truep(t25)){
t26=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[789]);}
else{
t26=C_eqp(((C_word*)t0)[3],lf[707]);
if(C_truep(t26)){
t27=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[790]);}
else{
t27=C_eqp(((C_word*)t0)[3],lf[708]);
if(C_truep(t27)){
t28=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[791]);}
else{
t28=C_eqp(((C_word*)t0)[3],lf[710]);
if(C_truep(t28)){
t29=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[792]);}
else{
t29=C_eqp(((C_word*)t0)[3],lf[711]);
if(C_truep(t29)){
t30=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[793]);}
else{
t30=C_eqp(((C_word*)t0)[3],lf[713]);
if(C_truep(t30)){
t31=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[794]);}
else{
t31=C_eqp(((C_word*)t0)[3],lf[714]);
if(C_truep(t31)){
t32=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[795]);}
else{
t32=C_eqp(((C_word*)t0)[3],lf[716]);
if(C_truep(t32)){
t33=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[796]);}
else{
t33=C_eqp(((C_word*)t0)[3],lf[717]);
if(C_truep(t33)){
t34=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[797]);}
else{
t34=C_eqp(((C_word*)t0)[3],lf[600]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_9553(t36,t34);}
else{
t36=C_eqp(((C_word*)t0)[3],lf[622]);
if(C_truep(t36)){
t37=t35;
f_9553(t37,t36);}
else{
t37=C_eqp(((C_word*)t0)[3],lf[623]);
t38=t35;
f_9553(t38,(C_truep(t37)?t37:C_eqp(((C_word*)t0)[3],lf[624])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* err in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8256(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8256,NULL,2,t0,t1);}
/* c-backend.scm:1152: quit */
t2=*((C_word*)lf[672]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[673],((C_word*)t0)[2]);}

/* k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
t2=C_i_zerop(t1);
t3=t2;
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:325: lambda-literal-temporaries */
t5=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[9]);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:338: gen */
t5=*((C_word*)lf[1]+1);
f_2549(4,t5,t4,((C_word*)t0)[11],C_make_character(40));}}

/* k10876 in k10881 in encode-literal in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1403: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[856],t1,lf[857]);}

/* k5836 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5838,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep(C_immp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
/* c-backend.scm:670: bomb */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[346],t3);}
else{
if(C_truep(C_lambdainfop(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:682: ##sys#bytevector? */
t3=*((C_word*)lf[348]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}}}

/* k10881 in encode-literal in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10883,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
/* ##sys#fixnum->string */
t4=*((C_word*)lf[858]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=C_a_i_arithmetic_shift(&a,2,((C_word*)t0)[3],C_fix(-24));
t3=C_a_i_bitwise_and(&a,2,C_fix(255),t2);
t4=C_make_character(C_unfix(t3));
t5=C_a_i_arithmetic_shift(&a,2,((C_word*)t0)[3],C_fix(-16));
t6=C_a_i_bitwise_and(&a,2,C_fix(255),t5);
t7=C_make_character(C_unfix(t6));
t8=C_a_i_arithmetic_shift(&a,2,((C_word*)t0)[3],C_fix(-8));
t9=C_a_i_bitwise_and(&a,2,C_fix(255),t8);
t10=C_make_character(C_unfix(t9));
t11=((C_word*)t0)[3];
t12=C_fixnum_and(C_fix(255),t11);
t13=C_make_character(C_unfix(t12));
t14=C_a_i_string(&a,4,t4,t7,t10,t13);
/* ##sys#string-append */
t15=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,((C_word*)t0)[2],lf[859],t14);}}

/* k4291 in k4287 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:401: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[178],t1,lf[179]);}

/* k5825 in map-loop862 in k5791 in k5731 in literal-size in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5827,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5798(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5798(t6,((C_word*)t0)[5],t5);}}

/* g1458 in k7649 in k7643 in k7631 in k7619 in k7610 in compute-size in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_7655(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7655,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm:1102: compute-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7602(5,t4,t1,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t3=t2;
/* c-backend.scm:1102: compute-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7602(5,t4,t1,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k7649 in k7643 in k7631 in k7619 in k7610 in compute-size in k7598 in k7592 in k7589 in k7586 in k7583 in g1320 in generate-foreign-callback-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7651,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1100: g1458 */
t3=t2;
f_7655(t3,((C_word*)t0)[5],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[6]))){
t2=((C_word*)t0)[6];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[607]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7688,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_7688(t6,t4);}
else{
t6=C_eqp(t3,lf[471]);
if(C_truep(t6)){
t7=t5;
f_7688(t7,t6);}
else{
t7=C_eqp(t3,lf[610]);
if(C_truep(t7)){
t8=t5;
f_7688(t8,t7);}
else{
t8=C_eqp(t3,lf[611]);
if(C_truep(t8)){
t9=t5;
f_7688(t9,t8);}
else{
t9=C_eqp(t3,lf[612]);
if(C_truep(t9)){
t10=t5;
f_7688(t10,t9);}
else{
t10=C_eqp(t3,lf[613]);
if(C_truep(t10)){
t11=t5;
f_7688(t11,t10);}
else{
t11=C_eqp(t3,lf[614]);
if(C_truep(t11)){
t12=t5;
f_7688(t12,t11);}
else{
t12=C_eqp(t3,lf[615]);
t13=t5;
f_7688(t13,(C_truep(t12)?t12:C_eqp(t3,lf[616])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}}

/* k4273 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4278,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:402: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k4014 in k4011 in k4008 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:341: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k4008 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11813,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:340: expr-args */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4594(t4,t3,((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
/* c-backend.scm:339: gen */
t3=*((C_word*)lf[1]+1);
f_2549(3,t3,t2,lf[153]);}}

/* k4276 in k4273 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:403: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[177]);}

/* k4011 in k4008 in k4024 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:340: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4594(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5091,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5320,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:539: lambda-literal-closure-size */
t5=*((C_word*)lf[148]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t3;
f_5094(t4,C_SCHEME_FALSE);}}

/* k5095 in k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5097,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:541: lambda-literal-rest-argument */
t4=*((C_word*)lf[283]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}

/* k5092 in k5089 in k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5094,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5306,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
/* c-backend.scm:540: make-variable-list */
t5=*((C_word*)lf[284]+1);
f_7125(4,t5,t3,t4,lf[285]);}
else{
/* c-backend.scm:540: make-variable-list */
t4=*((C_word*)lf[284]+1);
f_7125(4,t4,t3,((C_word*)t0)[4],lf[285]);}}

/* k4287 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4289,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:401: foreign-type-declaration */
t4=*((C_word*)lf[174]+1);
f_8254(4,t4,t3,((C_word*)t0)[3],lf[180]);}

/* a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5084,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5088,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:537: lambda-literal-argument-count */
t5=*((C_word*)lf[287]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3710 in k3693 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:293: c-ify-string */
t2=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5086 in a5083 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5088,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:538: lambda-literal-customizable */
t4=*((C_word*)lf[286]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k3706 in k3693 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:292: gen */
t2=*((C_word*)lf[1]+1);
f_2549(7,t2,((C_word*)t0)[2],lf[117],((C_word*)((C_word*)t0)[3])[1],lf[118],t1,C_make_character(41));}

/* k5069 in for-each-loop682 in k5014 in k5011 in prototypes in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5061(t3,((C_word*)t0)[4],t2);}

/* k10894 in encode-literal in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_10896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1405: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[860],t1,lf[861]);}

/* k4261 in k4257 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:395: gen */
t2=*((C_word*)lf[1]+1);
f_2549(8,t2,((C_word*)t0)[2],C_make_character(40),((C_word*)t0)[3],lf[172],((C_word*)t0)[4],C_make_character(41),t1);}

/* k7333 in k7471 in for-each-loop1241 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in ... */
static void C_ccall f_7335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7335,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7339,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1046: foreign-type-declaration */
t4=*((C_word*)lf[174]+1);
f_8254(4,t4,t3,((C_word*)t0)[4],lf[568]);}

/* k6098 in k6087 in doloop918 in k6066 in gen-string-constant in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:726: c-ify-string */
t2=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7337 in k7333 in k7471 in for-each-loop1241 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in ... */
static void C_ccall f_7339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7339,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1047: foreign-argument-conversion */
t4=*((C_word*)lf[173]+1);
f_9301(3,t4,t3,((C_word*)t0)[5]);}

/* k6107 in doloop918 in k6066 in gen-string-constant in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6109,2,t0,t1);}
t2=C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(80));
t4=((C_word*)((C_word*)t0)[4])[1];
f_6073(t4,((C_word*)t0)[5],t2,t3);}

/* for-each-loop798 in k5476 in k5473 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_5518(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5518,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5528,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:660: g799 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7537,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1025: cleanup */
t4=*((C_word*)lf[498]+1);
f_7036(3,t4,t3,((C_word*)t0)[14]);}
else{
t3=t2;
f_7305(2,t3,C_SCHEME_UNDEFINED);}}

/* k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm:1027: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,t2,C_SCHEME_TRUE,lf[582],((C_word*)t0)[11],lf[583]);}
else{
t3=t2;
f_7308(2,t3,C_SCHEME_UNDEFINED);}}

/* k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_7308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm:1030: gen */
t3=*((C_word*)lf[1]+1);
f_2549(10,t3,t2,C_SCHEME_TRUE,lf[577],((C_word*)t0)[13],lf[578],C_SCHEME_TRUE,lf[579],((C_word*)t0)[13],lf[580]);}
else{
/* c-backend.scm:1032: gen */
t3=*((C_word*)lf[1]+1);
f_2549(6,t3,t2,C_SCHEME_TRUE,lf[581],((C_word*)t0)[13],C_make_character(40));}}

/* k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_7311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[12]);}

/* k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in ... */
static void C_ccall f_7317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[12]);}

/* k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in g1214 in generate-foreign-stubs in k2629 in k2544 in k2541 in ... */
static void C_ccall f_7314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm:1035: gen */
t3=*((C_word*)lf[1]+1);
f_2549(7,t3,t2,lf[572],C_SCHEME_TRUE,lf[573],((C_word*)t0)[13],lf[574]);}
else{
/* c-backend.scm:1036: gen */
t3=*((C_word*)lf[1]+1);
f_2549(7,t3,t2,lf[575],C_SCHEME_TRUE,lf[576],((C_word*)t0)[13],C_make_character(40));}}

/* k6122 in doloop918 in k6066 in gen-string-constant in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:727: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k6126 in doloop918 in k6066 in gen-string-constant in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:727: c-ify-string */
t2=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in ... */
static void C_ccall f_7374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:1049: gen */
t3=*((C_word*)lf[1]+1);
f_2549(4,t3,t2,C_SCHEME_TRUE,lf[564]);}
else{
t3=t2;
f_7377(2,t3,C_SCHEME_UNDEFINED);}}

/* k7375 in k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in ... */
static void C_ccall f_7377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7386,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1051: gen */
t4=*((C_word*)lf[1]+1);
f_2549(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[3],C_SCHEME_TRUE,lf[555]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7407,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t4=C_eqp(((C_word*)t0)[6],lf[561]);
if(C_truep(t4)){
/* c-backend.scm:1062: gen */
t5=*((C_word*)lf[1]+1);
f_2549(3,t5,t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm:1061: gen */
t5=*((C_word*)lf[1]+1);
f_2549(5,t5,t3,C_SCHEME_TRUE,lf[563],((C_word*)t0)[9]);}}}

/* k5503 in for-each-loop815 in k5485 in k5482 in k5476 in k5473 in k5439 in trampolines in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_5505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5495(t3,((C_word*)t0)[4],t2);}

/* k6664 in k6622 in k6298 in k6295 in k6292 in k6289 in k6286 in k6283 in k6280 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in ... */
static void C_fcall f_6666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],lf[254]);
if(C_truep(t2)){
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(2)))){
/* c-backend.scm:863: gen */
t3=*((C_word*)lf[1]+1);
f_2549(8,t3,((C_word*)t0)[4],C_SCHEME_TRUE,lf[450],((C_word*)t0)[3],lf[451],((C_word*)t0)[3],lf[452]);}
else{
t3=((C_word*)t0)[4];
f_6627(2,t3,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm:864: gen */
t3=*((C_word*)lf[1]+1);
f_2549(8,t3,((C_word*)t0)[4],C_SCHEME_TRUE,lf[453],((C_word*)t0)[3],lf[454],((C_word*)t0)[3],lf[455]);}}
else{
t2=((C_word*)t0)[4];
f_6627(2,t2,C_SCHEME_UNDEFINED);}}

/* k4309 in k4306 in k4303 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:410: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k4312 in k4309 in k4306 in k4303 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:411: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[183]);}

/* k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8638,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8649,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1198: string-append */
t5=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[722],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_eqp(C_fix(2),((C_word*)t0)[7]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[2]);
t5=t2;
f_8655(t5,C_eqp(lf[607],t4));}
else{
t4=t2;
f_8655(t4,C_SCHEME_FALSE);}}}

/* k4303 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:408: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(t4,t2,t3,((C_word*)t0)[5]);}

/* k4306 in k4303 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4325,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:409: foreign-argument-conversion */
t4=*((C_word*)lf[173]+1);
f_9301(3,t4,t3,((C_word*)t0)[6]);}

/* k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8580(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8580,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1185: str */
t2=((C_word*)t0)[2];
f_8261(t2,((C_word*)t0)[3],lf[720]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[561]);
if(C_truep(t2)){
/* c-backend.scm:1186: str */
t3=((C_word*)t0)[2];
f_8261(t3,((C_word*)t0)[3],lf[721]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8595,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
/* c-backend.scm:1188: ##sys#hash-table-ref */
t4=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[617]+1),((C_word*)t0)[6]);}
else{
t4=t3;
f_8595(2,t4,C_SCHEME_FALSE);}}}}

/* k3767 in k3752 in k3749 in k3746 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm:312: gen */
t2=*((C_word*)lf[1]+1);
f_2549(5,t2,((C_word*)t0)[2],lf[135],((C_word*)t0)[3],lf[136]);}
else{
/* c-backend.scm:313: gen */
t2=*((C_word*)lf[1]+1);
f_2549(5,t2,((C_word*)t0)[2],lf[137],((C_word*)t0)[3],lf[138]);}}

/* g1654 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8599,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm:1190: foreign-type-declaration */
t4=*((C_word*)lf[174]+1);
f_8254(4,t4,t1,t3,((C_word*)t0)[2]);}
else{
t3=t2;
/* c-backend.scm:1190: foreign-type-declaration */
t4=*((C_word*)lf[174]+1);
f_8254(4,t4,t1,t3,((C_word*)t0)[2]);}}

/* k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:316: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],lf[131]);}

/* k3758 in k3755 in k3752 in k3749 in k3746 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3763,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:315: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4594(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k7387 in k7384 in k7375 in k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in ... */
static void C_ccall f_7389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:1055: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[550],C_SCHEME_TRUE,lf[551]);}
else{
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:1057: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[552]);}
else{
/* c-backend.scm:1058: gen */
t2=*((C_word*)lf[1]+1);
f_2549(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[553]);}}}

/* k7384 in k7375 in k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in ... */
static void C_ccall f_7386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1053: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,t2,C_SCHEME_TRUE,lf[554],C_SCHEME_TRUE);}

/* k7378 in k7375 in k7372 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in ... */
static void C_ccall f_7380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1072: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8655(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8655,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8666,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1201: string-append */
t5=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[723],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8672,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[7],C_fix(2)))){
t3=C_i_car(((C_word*)t0)[2]);
t4=t2;
f_8672(t4,C_eqp(lf[753],t3));}
else{
t3=t2;
f_8672(t3,C_SCHEME_FALSE);}}}

/* k3755 in k3752 in k3749 in k3746 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:314: gen */
t3=*((C_word*)lf[1]+1);
f_2549(7,t3,t2,lf[132],((C_word*)t0)[6],lf[133],((C_word*)t0)[7],C_make_character(44));}

/* k3749 in k3746 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:309: gen */
t3=*((C_word*)lf[1]+1);
f_2549(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[140],((C_word*)t0)[6],lf[141]);}

/* k3752 in k3749 in k3746 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=*((C_word*)lf[134]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3769,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(*((C_word*)lf[134]+1))){
t5=t4;
f_3769(t5,*((C_word*)lf[134]+1));}
else{
t5=*((C_word*)lf[139]+1);
if(C_truep(*((C_word*)lf[139]+1))){
t6=*((C_word*)lf[139]+1);
t7=t4;
f_3769(t7,*((C_word*)lf[139]+1));}
else{
t6=C_u_i_car(((C_word*)t0)[8]);
t7=t4;
f_3769(t7,t6);}}}

/* k3743 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:301: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[127],t1,lf[128]);}

/* k3746 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:308: expr */
t3=((C_word*)((C_word*)t0)[9])[1];
f_2654(t3,t2,((C_word*)t0)[10],((C_word*)t0)[5]);}

/* k7360 in k7357 in k7351 in k7471 in for-each-loop1241 in k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in ... */
static void C_ccall f_7362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1045: get-output-string */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4760 in k4756 in k4752 in k4748 in k4744 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:472: gen */
t2=*((C_word*)lf[1]+1);
f_2549(21,t2,((C_word*)t0)[2],lf[219],((C_word*)t0)[3],lf[220],C_SCHEME_TRUE,lf[221],C_SCHEME_TRUE,lf[222],((C_word*)t0)[4],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[6],C_make_character(32),((C_word*)t0)[7],C_make_character(58),((C_word*)t0)[8],C_SCHEME_TRUE,t1,lf[223]);}

/* k7366 in k7324 in k7321 in k7318 in k7315 in k7312 in k7309 in k7306 in k7303 in k7300 in k7297 in k7294 in k7291 in k7288 in k7285 in k7282 in k7279 in k7276 in k7273 in k7267 in k7264 in k7261 in ... */
static void C_ccall f_7368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7368,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[57]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7374,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7466,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7466(t7,t3,((C_word*)t0)[11],t1,((C_word*)t0)[2]);}

/* k6906 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in k6214 in k6211 in k6208 in a6205 in procedures in ... */
static void C_ccall f_6908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:770: gen */
t2=*((C_word*)lf[1]+1);
f_2549(6,t2,((C_word*)t0)[2],lf[496],t1,lf[497],C_SCHEME_TRUE);}

/* k4756 in k4752 in k4748 in k4744 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4758,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4771,a[2]=t3,a[3]=t7,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4813,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:477: chicken-version */
t10=*((C_word*)lf[230]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,C_SCHEME_TRUE);}

/* k3736 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* c-backend.scm:302: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,((C_word*)t0)[3],lf[125],((C_word*)t0)[4],lf[126]);}

/* k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_8568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8568,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1183: str */
t2=((C_word*)t0)[2];
f_8261(t2,((C_word*)t0)[3],lf[719]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[619]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8580(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[620]);
if(C_truep(t4)){
t5=t3;
f_8580(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[623]);
t6=t3;
f_8580(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[624])));}}}}

/* k3732 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:297: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[123],t1,lf[124]);}

/* k3117 in g183 in k3112 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3122,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:168: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2654(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3112 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3128,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:170: iota */
t5=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(1),C_fix(1));}

/* g183 in k3112 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_fcall f_3115(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3115,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3119,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:167: gen */
t5=*((C_word*)lf[1]+1);
f_2549(5,t5,t4,lf[55],t3,lf[56]);}

/* k3725 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* c-backend.scm:298: gen */
t3=*((C_word*)lf[1]+1);
f_2549(5,t3,((C_word*)t0)[3],lf[121],((C_word*)((C_word*)t0)[2])[1],lf[122]);}

/* k3718 in k3653 in k3633 in k3427 in k3423 in k3417 in k3414 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:289: string-append */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[119],t1,lf[120]);}

/* k3381 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:219: uncommentify */
t2=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#gen-list in k2544 in k2541 in k2538 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2592,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2601,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:50: intersperse */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_make_character(32));}

/* k3377 in expr in expression in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:218: gen */
t2=*((C_word*)lf[1]+1);
f_2549(7,t2,((C_word*)t0)[2],lf[90],((C_word*)t0)[3],lf[91],t1,lf[92]);}

/* k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_8595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8595,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8599,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1188: g1654 */
t3=t2;
f_8599(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm:1191: str */
t2=((C_word*)t0)[5];
f_8261(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8638,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=C_eqp(C_fix(2),t3);
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[4]);
t7=t4;
f_8638(t7,C_u_i_memq(t6,lf[754]));}
else{
t6=t4;
f_8638(t6,C_SCHEME_FALSE);}}
else{
/* c-backend.scm:1241: err */
t2=((C_word*)t0)[6];
f_8256(t2,((C_word*)t0)[3]);}}}}

/* k6842 in k6839 in k6277 in k6274 in k6271 in k6268 in k6265 in k6262 in k6259 in k6256 in k6253 in k6250 in k6247 in k6244 in k6241 in k6238 in k6235 in k6232 in k6229 in k6223 in k6220 in k6217 in ... */
static void C_ccall f_6844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
/* c-backend.scm:791: gen */
t2=*((C_word*)lf[1]+1);
f_2549(3,t2,((C_word*)t0)[3],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_6282(2,t3,t2);}}

/* k2577 in for-each-loop27 in gen in k2544 in k2541 in k2538 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2569(t3,((C_word*)t0)[4],t2);}

/* k4769 in k4756 in k4752 in k4748 in k4744 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4776(t6,t2,t1);}

/* k4772 in k4769 in k4756 in k4752 in k4748 in k4744 in k4645 in header in k2635 in generate-code in k2629 in k2544 in k2541 in k2538 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:475: string-intersperse */
t2=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[225]);}

/* k11030 in k11007 in k11001 in k2544 in k2541 in k2538 */
static void C_ccall f_11032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:57: ##sys#print */
t2=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k8919 in map-loop1715 in k8866 in k8847 in k8830 in k8813 in k8796 in k8779 in k8762 in k8745 in k8670 in k8653 in k8636 in k8593 in k8578 in k8566 in k8458 in k8437 in k8329 in foreign-type-declaration in k2629 in k2544 in ... */
static void C_ccall f_8921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8921,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8892(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8892(t6,((C_word*)t0)[5],t5);}}

/* k11034 in k11007 in k11001 in k2544 in k2541 in k2538 */
static void C_ccall f_11036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:57: number->string */
C_number_to_string(4,0,((C_word*)t0)[2],t1,C_fix(16));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[788] = {
{"f_6813:c_2dbackend_2escm",(void*)f_6813},
{"f_4776:c_2dbackend_2escm",(void*)f_4776},
{"f_8111:c_2dbackend_2escm",(void*)f_8111},
{"f_6801:c_2dbackend_2escm",(void*)f_6801},
{"f_4916:c_2dbackend_2escm",(void*)f_4916},
{"f_4754:c_2dbackend_2escm",(void*)f_4754},
{"f_4750:c_2dbackend_2escm",(void*)f_4750},
{"f_8121:c_2dbackend_2escm",(void*)f_8121},
{"f_5979:c_2dbackend_2escm",(void*)f_5979},
{"f_10701:c_2dbackend_2escm",(void*)f_10701},
{"f_4933:c_2dbackend_2escm",(void*)f_4933},
{"f_5202:c_2dbackend_2escm",(void*)f_5202},
{"f_3190:c_2dbackend_2escm",(void*)f_3190},
{"f_7259:c_2dbackend_2escm",(void*)f_7259},
{"f_3895:c_2dbackend_2escm",(void*)f_3895},
{"f_7257:c_2dbackend_2escm",(void*)f_7257},
{"f_10710:c_2dbackend_2escm",(void*)f_10710},
{"f_3898:c_2dbackend_2escm",(void*)f_3898},
{"f_3899:c_2dbackend_2escm",(void*)f_3899},
{"f_3187:c_2dbackend_2escm",(void*)f_3187},
{"f_6841:c_2dbackend_2escm",(void*)f_6841},
{"f_5127:c_2dbackend_2escm",(void*)f_5127},
{"f_7343:c_2dbackend_2escm",(void*)f_7343},
{"f_5985:c_2dbackend_2escm",(void*)f_5985},
{"f_7347:c_2dbackend_2escm",(void*)f_7347},
{"f_4943:c_2dbackend_2escm",(void*)f_4943},
{"f_7353:c_2dbackend_2escm",(void*)f_7353},
{"f_7359:c_2dbackend_2escm",(void*)f_7359},
{"f_5103:c_2dbackend_2escm",(void*)f_5103},
{"f_5106:c_2dbackend_2escm",(void*)f_5106},
{"f_5109:c_2dbackend_2escm",(void*)f_5109},
{"f_5100:c_2dbackend_2escm",(void*)f_5100},
{"f_3153:c_2dbackend_2escm",(void*)f_3153},
{"f_4600:c_2dbackend_2escm",(void*)f_4600},
{"f_7214:c_2dbackend_2escm",(void*)f_7214},
{"f_7323:c_2dbackend_2escm",(void*)f_7323},
{"f_7326:c_2dbackend_2escm",(void*)f_7326},
{"f_7320:c_2dbackend_2escm",(void*)f_7320},
{"f_4604:c_2dbackend_2escm",(void*)f_4604},
{"f_7223:c_2dbackend_2escm",(void*)f_7223},
{"f_3143:c_2dbackend_2escm",(void*)f_3143},
{"f_7220:c_2dbackend_2escm",(void*)f_7220},
{"f_3845:c_2dbackend_2escm",(void*)f_3845},
{"f_3841:c_2dbackend_2escm",(void*)f_3841},
{"f_8868:c_2dbackend_2escm",(void*)f_8868},
{"f_7234:c_2dbackend_2escm",(void*)f_7234},
{"f_3134:c_2dbackend_2escm",(void*)f_3134},
{"f_3834:c_2dbackend_2escm",(void*)f_3834},
{"f_5115:c_2dbackend_2escm",(void*)f_5115},
{"f_5112:c_2dbackend_2escm",(void*)f_5112},
{"f_3128:c_2dbackend_2escm",(void*)f_3128},
{"f_5116:c_2dbackend_2escm",(void*)f_5116},
{"f_3122:c_2dbackend_2escm",(void*)f_3122},
{"f_7244:c_2dbackend_2escm",(void*)f_7244},
{"f_3827:c_2dbackend_2escm",(void*)f_3827},
{"toplevel:c_2dbackend_2escm",(void*)C_backend_toplevel},
{"f_8872:c_2dbackend_2escm",(void*)f_8872},
{"f_8890:c_2dbackend_2escm",(void*)f_8890},
{"f_2651:c_2dbackend_2escm",(void*)f_2651},
{"f_8892:c_2dbackend_2escm",(void*)f_8892},
{"f_5551:c_2dbackend_2escm",(void*)f_5551},
{"f_3557:c_2dbackend_2escm",(void*)f_3557},
{"f_5541:c_2dbackend_2escm",(void*)f_5541},
{"f_4333:c_2dbackend_2escm",(void*)f_4333},
{"f_2654:c_2dbackend_2escm",(void*)f_2654},
{"f_2631:c_2dbackend_2escm",(void*)f_2631},
{"f_5528:c_2dbackend_2escm",(void*)f_5528},
{"f_10201:c_2dbackend_2escm",(void*)f_10201},
{"f_4325:c_2dbackend_2escm",(void*)f_4325},
{"f_4876:c_2dbackend_2escm",(void*)f_4876},
{"f_8439:c_2dbackend_2escm",(void*)f_8439},
{"f_8087:c_2dbackend_2escm",(void*)f_8087},
{"f_8084:c_2dbackend_2escm",(void*)f_8084},
{"f_4882:c_2dbackend_2escm",(void*)f_4882},
{"f_4358:c_2dbackend_2escm",(void*)f_4358},
{"f_10250:c_2dbackend_2escm",(void*)f_10250},
{"f_4355:c_2dbackend_2escm",(void*)f_4355},
{"f_8081:c_2dbackend_2escm",(void*)f_8081},
{"f_2633:c_2dbackend_2escm",(void*)f_2633},
{"f_2639:c_2dbackend_2escm",(void*)f_2639},
{"f_2637:c_2dbackend_2escm",(void*)f_2637},
{"f_4888:c_2dbackend_2escm",(void*)f_4888},
{"f_4885:c_2dbackend_2escm",(void*)f_4885},
{"f_8078:c_2dbackend_2escm",(void*)f_8078},
{"f_2643:c_2dbackend_2escm",(void*)f_2643},
{"f_3510:c_2dbackend_2escm",(void*)f_3510},
{"f_4855:c_2dbackend_2escm",(void*)f_4855},
{"f_4858:c_2dbackend_2escm",(void*)f_4858},
{"f_3547:c_2dbackend_2escm",(void*)f_3547},
{"f_2616:c_2dbackend_2escm",(void*)f_2616},
{"f_5712:c_2dbackend_2escm",(void*)f_5712},
{"f_5715:c_2dbackend_2escm",(void*)f_5715},
{"f_10246:c_2dbackend_2escm",(void*)f_10246},
{"f_8090:c_2dbackend_2escm",(void*)f_8090},
{"f_5703:c_2dbackend_2escm",(void*)f_5703},
{"f_5718:c_2dbackend_2escm",(void*)f_5718},
{"f_6025:c_2dbackend_2escm",(void*)f_6025},
{"f_3520:c_2dbackend_2escm",(void*)f_3520},
{"f_5709:c_2dbackend_2escm",(void*)f_5709},
{"f_10225:c_2dbackend_2escm",(void*)f_10225},
{"f_6012:c_2dbackend_2escm",(void*)f_6012},
{"f_10222:c_2dbackend_2escm",(void*)f_10222},
{"f_6015:c_2dbackend_2escm",(void*)f_6015},
{"f_2606:c_2dbackend_2escm",(void*)f_2606},
{"f_2601:c_2dbackend_2escm",(void*)f_2601},
{"f_6587:c_2dbackend_2escm",(void*)f_6587},
{"f_5668:c_2dbackend_2escm",(void*)f_5668},
{"f_3502:c_2dbackend_2escm",(void*)f_3502},
{"f_7074:c_2dbackend_2escm",(void*)f_7074},
{"f_6018:c_2dbackend_2escm",(void*)f_6018},
{"f_7473:c_2dbackend_2escm",(void*)f_7473},
{"f_7476:c_2dbackend_2escm",(void*)f_7476},
{"f_5657:c_2dbackend_2escm",(void*)f_5657},
{"f11805:c_2dbackend_2escm",(void*)f11805},
{"f_7084:c_2dbackend_2escm",(void*)f_7084},
{"f_5227:c_2dbackend_2escm",(void*)f_5227},
{"f_4906:c_2dbackend_2escm",(void*)f_4906},
{"f_5255:c_2dbackend_2escm",(void*)f_5255},
{"f_5252:c_2dbackend_2escm",(void*)f_5252},
{"f_5258:c_2dbackend_2escm",(void*)f_5258},
{"f_6803:c_2dbackend_2escm",(void*)f_6803},
{"f_7466:c_2dbackend_2escm",(void*)f_7466},
{"f_4861:c_2dbackend_2escm",(void*)f_4861},
{"f11813:c_2dbackend_2escm",(void*)f11813},
{"f_4644:c_2dbackend_2escm",(void*)f_4644},
{"f_4647:c_2dbackend_2escm",(void*)f_4647},
{"f_4866:c_2dbackend_2escm",(void*)f_4866},
{"f_5236:c_2dbackend_2escm",(void*)f_5236},
{"f_6578:c_2dbackend_2escm",(void*)f_6578},
{"f_5233:c_2dbackend_2escm",(void*)f_5233},
{"f_5230:c_2dbackend_2escm",(void*)f_5230},
{"f_6575:c_2dbackend_2escm",(void*)f_6575},
{"f_6572:c_2dbackend_2escm",(void*)f_6572},
{"f_4594:c_2dbackend_2escm",(void*)f_4594},
{"f_6569:c_2dbackend_2escm",(void*)f_6569},
{"f_6566:c_2dbackend_2escm",(void*)f_6566},
{"f_6560:c_2dbackend_2escm",(void*)f_6560},
{"f_6563:c_2dbackend_2escm",(void*)f_6563},
{"f_4626:c_2dbackend_2escm",(void*)f_4626},
{"f_5686:c_2dbackend_2escm",(void*)f_5686},
{"f_4629:c_2dbackend_2escm",(void*)f_4629},
{"f_10213:c_2dbackend_2escm",(void*)f_10213},
{"f_10219:c_2dbackend_2escm",(void*)f_10219},
{"f_9571:c_2dbackend_2escm",(void*)f_9571},
{"f_7201:c_2dbackend_2escm",(void*)f_7201},
{"f_4891:c_2dbackend_2escm",(void*)f_4891},
{"f_5676:c_2dbackend_2escm",(void*)f_5676},
{"f_5670:c_2dbackend_2escm",(void*)f_5670},
{"f_3661:c_2dbackend_2escm",(void*)f_3661},
{"f_3664:c_2dbackend_2escm",(void*)f_3664},
{"f_5410:c_2dbackend_2escm",(void*)f_5410},
{"f_5414:c_2dbackend_2escm",(void*)f_5414},
{"f_3658:c_2dbackend_2escm",(void*)f_3658},
{"f_9598:c_2dbackend_2escm",(void*)f_9598},
{"f_3655:c_2dbackend_2escm",(void*)f_3655},
{"f_8109:c_2dbackend_2escm",(void*)f_8109},
{"f_5403:c_2dbackend_2escm",(void*)f_5403},
{"f_5400:c_2dbackend_2escm",(void*)f_5400},
{"f_9562:c_2dbackend_2escm",(void*)f_9562},
{"f_10433:c_2dbackend_2escm",(void*)f_10433},
{"f_10436:c_2dbackend_2escm",(void*)f_10436},
{"f_10430:c_2dbackend_2escm",(void*)f_10430},
{"f_3635:c_2dbackend_2escm",(void*)f_3635},
{"f_4066:c_2dbackend_2escm",(void*)f_4066},
{"f_4063:c_2dbackend_2escm",(void*)f_4063},
{"f_4060:c_2dbackend_2escm",(void*)f_4060},
{"f_3629:c_2dbackend_2escm",(void*)f_3629},
{"f_6875:c_2dbackend_2escm",(void*)f_6875},
{"f_6872:c_2dbackend_2escm",(void*)f_6872},
{"f_9916:c_2dbackend_2escm",(void*)f_9916},
{"f_9918:c_2dbackend_2escm",(void*)f_9918},
{"f_3616:c_2dbackend_2escm",(void*)f_3616},
{"f_6869:c_2dbackend_2escm",(void*)f_6869},
{"f_3613:c_2dbackend_2escm",(void*)f_3613},
{"f_7036:c_2dbackend_2escm",(void*)f_7036},
{"f_7034:c_2dbackend_2escm",(void*)f_7034},
{"f_3601:c_2dbackend_2escm",(void*)f_3601},
{"f_8733:c_2dbackend_2escm",(void*)f_8733},
{"f_7045:c_2dbackend_2escm",(void*)f_7045},
{"f_4090:c_2dbackend_2escm",(void*)f_4090},
{"f_8702:c_2dbackend_2escm",(void*)f_8702},
{"f_8704:c_2dbackend_2escm",(void*)f_8704},
{"f_7183:c_2dbackend_2escm",(void*)f_7183},
{"f_10448:c_2dbackend_2escm",(void*)f_10448},
{"f_7155:c_2dbackend_2escm",(void*)f_7155},
{"f_7157:c_2dbackend_2escm",(void*)f_7157},
{"f_4113:c_2dbackend_2escm",(void*)f_4113},
{"f_10454:c_2dbackend_2escm",(void*)f_10454},
{"f_10457:c_2dbackend_2escm",(void*)f_10457},
{"f_7161:c_2dbackend_2escm",(void*)f_7161},
{"f_4109:c_2dbackend_2escm",(void*)f_4109},
{"f_10763:c_2dbackend_2escm",(void*)f_10763},
{"f_10424:c_2dbackend_2escm",(void*)f_10424},
{"f_6891:c_2dbackend_2escm",(void*)f_6891},
{"f_6894:c_2dbackend_2escm",(void*)f_6894},
{"f_4057:c_2dbackend_2escm",(void*)f_4057},
{"f_5733:c_2dbackend_2escm",(void*)f_5733},
{"f_5391:c_2dbackend_2escm",(void*)f_5391},
{"f_7191:c_2dbackend_2escm",(void*)f_7191},
{"f_9997:c_2dbackend_2escm",(void*)f_9997},
{"f_9994:c_2dbackend_2escm",(void*)f_9994},
{"f_5726:c_2dbackend_2escm",(void*)f_5726},
{"f_9991:c_2dbackend_2escm",(void*)f_9991},
{"f_5394:c_2dbackend_2escm",(void*)f_5394},
{"f_5397:c_2dbackend_2escm",(void*)f_5397},
{"f_5370:c_2dbackend_2escm",(void*)f_5370},
{"f_5382:c_2dbackend_2escm",(void*)f_5382},
{"f_5385:c_2dbackend_2escm",(void*)f_5385},
{"f_5388:c_2dbackend_2escm",(void*)f_5388},
{"f_5361:c_2dbackend_2escm",(void*)f_5361},
{"f_5373:c_2dbackend_2escm",(void*)f_5373},
{"f_5379:c_2dbackend_2escm",(void*)f_5379},
{"f_5376:c_2dbackend_2escm",(void*)f_5376},
{"f_7612:c_2dbackend_2escm",(void*)f_7612},
{"f_5134:c_2dbackend_2escm",(void*)f_5134},
{"f_2937:c_2dbackend_2escm",(void*)f_2937},
{"f_8066:c_2dbackend_2escm",(void*)f_8066},
{"f_8069:c_2dbackend_2escm",(void*)f_8069},
{"f_5363:c_2dbackend_2escm",(void*)f_5363},
{"f_5367:c_2dbackend_2escm",(void*)f_5367},
{"f_7621:c_2dbackend_2escm",(void*)f_7621},
{"f_8063:c_2dbackend_2escm",(void*)f_8063},
{"f_8060:c_2dbackend_2escm",(void*)f_8060},
{"f_5161:c_2dbackend_2escm",(void*)f_5161},
{"f_5199:c_2dbackend_2escm",(void*)f_5199},
{"f_8054:c_2dbackend_2escm",(void*)f_8054},
{"f_4735:c_2dbackend_2escm",(void*)f_4735},
{"f_8057:c_2dbackend_2escm",(void*)f_8057},
{"f_7633:c_2dbackend_2escm",(void*)f_7633},
{"f_7131:c_2dbackend_2escm",(void*)f_7131},
{"f_7139:c_2dbackend_2escm",(void*)f_7139},
{"f_5190:c_2dbackend_2escm",(void*)f_5190},
{"f_5149:c_2dbackend_2escm",(void*)f_5149},
{"f_7645:c_2dbackend_2escm",(void*)f_7645},
{"f_7141:c_2dbackend_2escm",(void*)f_7141},
{"f_5143:c_2dbackend_2escm",(void*)f_5143},
{"f_7147:c_2dbackend_2escm",(void*)f_7147},
{"f_5146:c_2dbackend_2escm",(void*)f_5146},
{"f_5140:c_2dbackend_2escm",(void*)f_5140},
{"f_9331:c_2dbackend_2escm",(void*)f_9331},
{"f_4414:c_2dbackend_2escm",(void*)f_4414},
{"f_6206:c_2dbackend_2escm",(void*)f_6206},
{"f_6200:c_2dbackend_2escm",(void*)f_6200},
{"f_4403:c_2dbackend_2escm",(void*)f_4403},
{"f_4400:c_2dbackend_2escm",(void*)f_4400},
{"f_6237:c_2dbackend_2escm",(void*)f_6237},
{"f_6234:c_2dbackend_2escm",(void*)f_6234},
{"f_2940:c_2dbackend_2escm",(void*)f_2940},
{"f_6231:c_2dbackend_2escm",(void*)f_6231},
{"f_7125:c_2dbackend_2escm",(void*)f_7125},
{"f_5155:c_2dbackend_2escm",(void*)f_5155},
{"f_5152:c_2dbackend_2escm",(void*)f_5152},
{"f_6216:c_2dbackend_2escm",(void*)f_6216},
{"f_6219:c_2dbackend_2escm",(void*)f_6219},
{"f_4715:c_2dbackend_2escm",(void*)f_4715},
{"f_6213:c_2dbackend_2escm",(void*)f_6213},
{"f_6210:c_2dbackend_2escm",(void*)f_6210},
{"f_8754:c_2dbackend_2escm",(void*)f_8754},
{"f_8683:c_2dbackend_2escm",(void*)f_8683},
{"f_4746:c_2dbackend_2escm",(void*)f_4746},
{"f_8687:c_2dbackend_2escm",(void*)f_8687},
{"f_10273:c_2dbackend_2escm",(void*)f_10273},
{"f_6073:c_2dbackend_2escm",(void*)f_6073},
{"f_10288:c_2dbackend_2escm",(void*)f_10288},
{"f_2914:c_2dbackend_2escm",(void*)f_2914},
{"f_2917:c_2dbackend_2escm",(void*)f_2917},
{"f_2911:c_2dbackend_2escm",(void*)f_2911},
{"f_8747:c_2dbackend_2escm",(void*)f_8747},
{"f_6068:c_2dbackend_2escm",(void*)f_6068},
{"f_2967:c_2dbackend_2escm",(void*)f_2967},
{"f_2964:c_2dbackend_2escm",(void*)f_2964},
{"f_6058:c_2dbackend_2escm",(void*)f_6058},
{"f_6056:c_2dbackend_2escm",(void*)f_6056},
{"f_2804:c_2dbackend_2escm",(void*)f_2804},
{"f_5455:c_2dbackend_2escm",(void*)f_5455},
{"f_2807:c_2dbackend_2escm",(void*)f_2807},
{"f_5452:c_2dbackend_2escm",(void*)f_5452},
{"f_2801:c_2dbackend_2escm",(void*)f_2801},
{"f_5458:c_2dbackend_2escm",(void*)f_5458},
{"f_4381:c_2dbackend_2escm",(void*)f_4381},
{"f_2813:c_2dbackend_2escm",(void*)f_2813},
{"f_5446:c_2dbackend_2escm",(void*)f_5446},
{"f_2816:c_2dbackend_2escm",(void*)f_2816},
{"f_5441:c_2dbackend_2escm",(void*)f_5441},
{"f_5442:c_2dbackend_2escm",(void*)f_5442},
{"f_2810:c_2dbackend_2escm",(void*)f_2810},
{"f_5449:c_2dbackend_2escm",(void*)f_5449},
{"f_8672:c_2dbackend_2escm",(void*)f_8672},
{"f_3695:c_2dbackend_2escm",(void*)f_3695},
{"f_8679:c_2dbackend_2escm",(void*)f_8679},
{"f_3681:c_2dbackend_2escm",(void*)f_3681},
{"f_3688:c_2dbackend_2escm",(void*)f_3688},
{"f_8666:c_2dbackend_2escm",(void*)f_8666},
{"f_4397:c_2dbackend_2escm",(void*)f_4397},
{"f_6506:c_2dbackend_2escm",(void*)f_6506},
{"f_6509:c_2dbackend_2escm",(void*)f_6509},
{"f_3671:c_2dbackend_2escm",(void*)f_3671},
{"f_6500:c_2dbackend_2escm",(void*)f_6500},
{"f_6503:c_2dbackend_2escm",(void*)f_6503},
{"f_4078:c_2dbackend_2escm",(void*)f_4078},
{"f_6096:c_2dbackend_2escm",(void*)f_6096},
{"f_6776:c_2dbackend_2escm",(void*)f_6776},
{"f_4378:c_2dbackend_2escm",(void*)f_4378},
{"f_3358:c_2dbackend_2escm",(void*)f_3358},
{"f_6089:c_2dbackend_2escm",(void*)f_6089},
{"f_8213:c_2dbackend_2escm",(void*)f_8213},
{"f_8210:c_2dbackend_2escm",(void*)f_8210},
{"f_8216:c_2dbackend_2escm",(void*)f_8216},
{"f_6762:c_2dbackend_2escm",(void*)f_6762},
{"f_3347:c_2dbackend_2escm",(void*)f_3347},
{"f_10072:c_2dbackend_2escm",(void*)f_10072},
{"f_8221:c_2dbackend_2escm",(void*)f_8221},
{"f_8225:c_2dbackend_2escm",(void*)f_8225},
{"f_3344:c_2dbackend_2escm",(void*)f_3344},
{"f_5929:c_2dbackend_2escm",(void*)f_5929},
{"f_10171:c_2dbackend_2escm",(void*)f_10171},
{"f_10174:c_2dbackend_2escm",(void*)f_10174},
{"f_6546:c_2dbackend_2escm",(void*)f_6546},
{"f_10177:c_2dbackend_2escm",(void*)f_10177},
{"f_10087:c_2dbackend_2escm",(void*)f_10087},
{"f_5923:c_2dbackend_2escm",(void*)f_5923},
{"f_6786:c_2dbackend_2escm",(void*)f_6786},
{"f_3219:c_2dbackend_2escm",(void*)f_3219},
{"f_10189:c_2dbackend_2escm",(void*)f_10189},
{"f_8240:c_2dbackend_2escm",(void*)f_8240},
{"f_5885:c_2dbackend_2escm",(void*)f_5885},
{"f_5013:c_2dbackend_2escm",(void*)f_5013},
{"f_5016:c_2dbackend_2escm",(void*)f_5016},
{"f_3317:c_2dbackend_2escm",(void*)f_3317},
{"f_10195:c_2dbackend_2escm",(void*)f_10195},
{"f_10198:c_2dbackend_2escm",(void*)f_10198},
{"f_3313:c_2dbackend_2escm",(void*)f_3313},
{"f_6518:c_2dbackend_2escm",(void*)f_6518},
{"f_5009:c_2dbackend_2escm",(void*)f_5009},
{"f_2869:c_2dbackend_2escm",(void*)f_2869},
{"f_3302:c_2dbackend_2escm",(void*)f_3302},
{"f_5863:c_2dbackend_2escm",(void*)f_5863},
{"f_7602:c_2dbackend_2escm",(void*)f_7602},
{"f_7600:c_2dbackend_2escm",(void*)f_7600},
{"f_10294:c_2dbackend_2escm",(void*)f_10294},
{"f_10297:c_2dbackend_2escm",(void*)f_10297},
{"f_3265:c_2dbackend_2escm",(void*)f_3265},
{"f_2875:c_2dbackend_2escm",(void*)f_2875},
{"f_2872:c_2dbackend_2escm",(void*)f_2872},
{"f_10138:c_2dbackend_2escm",(void*)f_10138},
{"f_3261:c_2dbackend_2escm",(void*)f_3261},
{"f_10144:c_2dbackend_2escm",(void*)f_10144},
{"f_6249:c_2dbackend_2escm",(void*)f_6249},
{"f_3368:c_2dbackend_2escm",(void*)f_3368},
{"f_6246:c_2dbackend_2escm",(void*)f_6246},
{"f_6243:c_2dbackend_2escm",(void*)f_6243},
{"f_10147:c_2dbackend_2escm",(void*)f_10147},
{"f_3365:c_2dbackend_2escm",(void*)f_3365},
{"f_3362:c_2dbackend_2escm",(void*)f_3362},
{"f_5595:c_2dbackend_2escm",(void*)f_5595},
{"f_6240:c_2dbackend_2escm",(void*)f_6240},
{"f_5598:c_2dbackend_2escm",(void*)f_5598},
{"f_5916:c_2dbackend_2escm",(void*)f_5916},
{"f_2859:c_2dbackend_2escm",(void*)f_2859},
{"f_10150:c_2dbackend_2escm",(void*)f_10150},
{"f_5583:c_2dbackend_2escm",(void*)f_5583},
{"f_5589:c_2dbackend_2escm",(void*)f_5589},
{"f_5580:c_2dbackend_2escm",(void*)f_5580},
{"f_10165:c_2dbackend_2escm",(void*)f_10165},
{"f_6225:c_2dbackend_2escm",(void*)f_6225},
{"f_6222:c_2dbackend_2escm",(void*)f_6222},
{"f_5574:c_2dbackend_2escm",(void*)f_5574},
{"f_5577:c_2dbackend_2escm",(void*)f_5577},
{"f_5571:c_2dbackend_2escm",(void*)f_5571},
{"f_6258:c_2dbackend_2escm",(void*)f_6258},
{"f_6255:c_2dbackend_2escm",(void*)f_6255},
{"f_6252:c_2dbackend_2escm",(void*)f_6252},
{"f_5564:c_2dbackend_2escm",(void*)f_5564},
{"f_5568:c_2dbackend_2escm",(void*)f_5568},
{"f_10484:c_2dbackend_2escm",(void*)f_10484},
{"f_5024:c_2dbackend_2escm",(void*)f_5024},
{"f_10481:c_2dbackend_2escm",(void*)f_10481},
{"f_3299:c_2dbackend_2escm",(void*)f_3299},
{"f_5027:c_2dbackend_2escm",(void*)f_5027},
{"f_5170:c_2dbackend_2escm",(void*)f_5170},
{"f_3296:c_2dbackend_2escm",(void*)f_3296},
{"f_5173:c_2dbackend_2escm",(void*)f_5173},
{"f_5021:c_2dbackend_2escm",(void*)f_5021},
{"f_4705:c_2dbackend_2escm",(void*)f_4705},
{"f_10066:c_2dbackend_2escm",(void*)f_10066},
{"f_10060:c_2dbackend_2escm",(void*)f_10060},
{"f_10069:c_2dbackend_2escm",(void*)f_10069},
{"f_10033:c_2dbackend_2escm",(void*)f_10033},
{"f_10036:c_2dbackend_2escm",(void*)f_10036},
{"f_10460:c_2dbackend_2escm",(void*)f_10460},
{"f_6753:c_2dbackend_2escm",(void*)f_6753},
{"f_10045:c_2dbackend_2escm",(void*)f_10045},
{"f_10042:c_2dbackend_2escm",(void*)f_10042},
{"f_10048:c_2dbackend_2escm",(void*)f_10048},
{"f_5187:c_2dbackend_2escm",(void*)f_5187},
{"f_5856:c_2dbackend_2escm",(void*)f_5856},
{"f_10093:c_2dbackend_2escm",(void*)f_10093},
{"f_10096:c_2dbackend_2escm",(void*)f_10096},
{"f_10099:c_2dbackend_2escm",(void*)f_10099},
{"f_9303:c_2dbackend_2escm",(void*)f_9303},
{"f_9301:c_2dbackend_2escm",(void*)f_9301},
{"f_4986:c_2dbackend_2escm",(void*)f_4986},
{"f_4440:c_2dbackend_2escm",(void*)f_4440},
{"f_4446:c_2dbackend_2escm",(void*)f_4446},
{"f_3468:c_2dbackend_2escm",(void*)f_3468},
{"f_9663:c_2dbackend_2escm",(void*)f_9663},
{"f_4443:c_2dbackend_2escm",(void*)f_4443},
{"f_3465:c_2dbackend_2escm",(void*)f_3465},
{"f_10935:c_2dbackend_2escm",(void*)f_10935},
{"f_4437:c_2dbackend_2escm",(void*)f_4437},
{"f_4427:c_2dbackend_2escm",(void*)f_4427},
{"f_4424:c_2dbackend_2escm",(void*)f_4424},
{"f_3446:c_2dbackend_2escm",(void*)f_3446},
{"f_3449:c_2dbackend_2escm",(void*)f_3449},
{"f_4668:c_2dbackend_2escm",(void*)f_4668},
{"f_4665:c_2dbackend_2escm",(void*)f_4665},
{"f_3429:c_2dbackend_2escm",(void*)f_3429},
{"f_3425:c_2dbackend_2escm",(void*)f_3425},
{"f_5623:c_2dbackend_2escm",(void*)f_5623},
{"f_5629:c_2dbackend_2escm",(void*)f_5629},
{"f_4201:c_2dbackend_2escm",(void*)f_4201},
{"f_4695:c_2dbackend_2escm",(void*)f_4695},
{"f_5610:c_2dbackend_2escm",(void*)f_5610},
{"f_5617:c_2dbackend_2escm",(void*)f_5617},
{"f_10472:c_2dbackend_2escm",(void*)f_10472},
{"f_10478:c_2dbackend_2escm",(void*)f_10478},
{"f_5604:c_2dbackend_2escm",(void*)f_5604},
{"f_5601:c_2dbackend_2escm",(void*)f_5601},
{"f_5607:c_2dbackend_2escm",(void*)f_5607},
{"f_4671:c_2dbackend_2escm",(void*)f_4671},
{"f_4674:c_2dbackend_2escm",(void*)f_4674},
{"f_6532:c_2dbackend_2escm",(void*)f_6532},
{"f_4677:c_2dbackend_2escm",(void*)f_4677},
{"f_4259:c_2dbackend_2escm",(void*)f_4259},
{"f_6276:c_2dbackend_2escm",(void*)f_6276},
{"f_6279:c_2dbackend_2escm",(void*)f_6279},
{"f_6270:c_2dbackend_2escm",(void*)f_6270},
{"f_6273:c_2dbackend_2escm",(void*)f_6273},
{"f_4683:c_2dbackend_2escm",(void*)f_4683},
{"f_6521:c_2dbackend_2escm",(void*)f_6521},
{"f_4680:c_2dbackend_2escm",(void*)f_4680},
{"f_4996:c_2dbackend_2escm",(void*)f_4996},
{"f_4243:c_2dbackend_2escm",(void*)f_4243},
{"f_4246:c_2dbackend_2escm",(void*)f_4246},
{"f_3419:c_2dbackend_2escm",(void*)f_3419},
{"f_6554:c_2dbackend_2escm",(void*)f_6554},
{"f_3416:c_2dbackend_2escm",(void*)f_3416},
{"f_6288:c_2dbackend_2escm",(void*)f_6288},
{"f_6285:c_2dbackend_2escm",(void*)f_6285},
{"f_6282:c_2dbackend_2escm",(void*)f_6282},
{"f_5907:c_2dbackend_2escm",(void*)f_5907},
{"f_6267:c_2dbackend_2escm",(void*)f_6267},
{"f_6261:c_2dbackend_2escm",(void*)f_6261},
{"f_6264:c_2dbackend_2escm",(void*)f_6264},
{"f_6297:c_2dbackend_2escm",(void*)f_6297},
{"f_6291:c_2dbackend_2escm",(void*)f_6291},
{"f_6294:c_2dbackend_2escm",(void*)f_6294},
{"f_7407:c_2dbackend_2escm",(void*)f_7407},
{"f_8201:c_2dbackend_2escm",(void*)f_8201},
{"f_8204:c_2dbackend_2escm",(void*)f_8204},
{"f_2983:c_2dbackend_2escm",(void*)f_2983},
{"f_2986:c_2dbackend_2escm",(void*)f_2986},
{"f_2989:c_2dbackend_2escm",(void*)f_2989},
{"f_2992:c_2dbackend_2escm",(void*)f_2992},
{"f_6412:c_2dbackend_2escm",(void*)f_6412},
{"f_7444:c_2dbackend_2escm",(void*)f_7444},
{"f_10345:c_2dbackend_2escm",(void*)f_10345},
{"f_7448:c_2dbackend_2escm",(void*)f_7448},
{"f_10342:c_2dbackend_2escm",(void*)f_10342},
{"f_10348:c_2dbackend_2escm",(void*)f_10348},
{"f_6967:c_2dbackend_2escm",(void*)f_6967},
{"f_6964:c_2dbackend_2escm",(void*)f_6964},
{"f_6961:c_2dbackend_2escm",(void*)f_6961},
{"f_6368:c_2dbackend_2escm",(void*)f_6368},
{"f_6362:c_2dbackend_2escm",(void*)f_6362},
{"f_8805:c_2dbackend_2escm",(void*)f_8805},
{"f_6365:c_2dbackend_2escm",(void*)f_6365},
{"f_7410:c_2dbackend_2escm",(void*)f_7410},
{"f_7413:c_2dbackend_2escm",(void*)f_7413},
{"f_7416:c_2dbackend_2escm",(void*)f_7416},
{"f_7419:c_2dbackend_2escm",(void*)f_7419},
{"f_4154:c_2dbackend_2escm",(void*)f_4154},
{"f_10312:c_2dbackend_2escm",(void*)f_10312},
{"f_6418:c_2dbackend_2escm",(void*)f_6418},
{"f_10318:c_2dbackend_2escm",(void*)f_10318},
{"f_6958:c_2dbackend_2escm",(void*)f_6958},
{"f_6955:c_2dbackend_2escm",(void*)f_6955},
{"f_4151:c_2dbackend_2escm",(void*)f_4151},
{"f_6952:c_2dbackend_2escm",(void*)f_6952},
{"f_8815:c_2dbackend_2escm",(void*)f_8815},
{"f_6408:c_2dbackend_2escm",(void*)f_6408},
{"f_6989:c_2dbackend_2escm",(void*)f_6989},
{"f_6986:c_2dbackend_2escm",(void*)f_6986},
{"f_6983:c_2dbackend_2escm",(void*)f_6983},
{"f_8460:c_2dbackend_2escm",(void*)f_8460},
{"f_8822:c_2dbackend_2escm",(void*)f_8822},
{"f_10336:c_2dbackend_2escm",(void*)f_10336},
{"f_4135:c_2dbackend_2escm",(void*)f_4135},
{"f_6979:c_2dbackend_2escm",(void*)f_6979},
{"f_4132:c_2dbackend_2escm",(void*)f_4132},
{"f_6970:c_2dbackend_2escm",(void*)f_6970},
{"f_8832:c_2dbackend_2escm",(void*)f_8832},
{"f_8839:c_2dbackend_2escm",(void*)f_8839},
{"f_10015:c_2dbackend_2escm",(void*)f_10015},
{"f_10018:c_2dbackend_2escm",(void*)f_10018},
{"f_6995:c_2dbackend_2escm",(void*)f_6995},
{"f_6992:c_2dbackend_2escm",(void*)f_6992},
{"f_8191:c_2dbackend_2escm",(void*)f_8191},
{"f_8195:c_2dbackend_2escm",(void*)f_8195},
{"f_10324:c_2dbackend_2escm",(void*)f_10324},
{"f_10321:c_2dbackend_2escm",(void*)f_10321},
{"f_10021:c_2dbackend_2escm",(void*)f_10021},
{"f_8198:c_2dbackend_2escm",(void*)f_8198},
{"f_4225:c_2dbackend_2escm",(void*)f_4225},
{"f_8160:c_2dbackend_2escm",(void*)f_8160},
{"f_5280:c_2dbackend_2escm",(void*)f_5280},
{"f_5633:c_2dbackend_2escm",(void*)f_5633},
{"f_3472:c_2dbackend_2escm",(void*)f_3472},
{"f_5637:c_2dbackend_2escm",(void*)f_5637},
{"f_3471:c_2dbackend_2escm",(void*)f_3471},
{"f_8178:c_2dbackend_2escm",(void*)f_8178},
{"f_3479:c_2dbackend_2escm",(void*)f_3479},
{"f_3476:c_2dbackend_2escm",(void*)f_3476},
{"f_6393:c_2dbackend_2escm",(void*)f_6393},
{"f_3019:c_2dbackend_2escm",(void*)f_3019},
{"f_3016:c_2dbackend_2escm",(void*)f_3016},
{"f_8168:c_2dbackend_2escm",(void*)f_8168},
{"f_6383:c_2dbackend_2escm",(void*)f_6383},
{"f_10300:c_2dbackend_2escm",(void*)f_10300},
{"f_5298:c_2dbackend_2escm",(void*)f_5298},
{"f_3931:c_2dbackend_2escm",(void*)f_3931},
{"f_3488:c_2dbackend_2escm",(void*)f_3488},
{"f_3926:c_2dbackend_2escm",(void*)f_3926},
{"f_3923:c_2dbackend_2escm",(void*)f_3923},
{"f_5270:c_2dbackend_2escm",(void*)f_5270},
{"f_4821:c_2dbackend_2escm",(void*)f_4821},
{"f_7004:c_2dbackend_2escm",(void*)f_7004},
{"f_7000:c_2dbackend_2escm",(void*)f_7000},
{"f_6714:c_2dbackend_2escm",(void*)f_6714},
{"f_6717:c_2dbackend_2escm",(void*)f_6717},
{"f_3499:c_2dbackend_2escm",(void*)f_3499},
{"f_3496:c_2dbackend_2escm",(void*)f_3496},
{"f_7556:c_2dbackend_2escm",(void*)f_7556},
{"f_7026:c_2dbackend_2escm",(void*)f_7026},
{"f_4831:c_2dbackend_2escm",(void*)f_4831},
{"f_4837:c_2dbackend_2escm",(void*)f_4837},
{"f_4835:c_2dbackend_2escm",(void*)f_4835},
{"f_7263:c_2dbackend_2escm",(void*)f_7263},
{"f_7266:c_2dbackend_2escm",(void*)f_7266},
{"f_7269:c_2dbackend_2escm",(void*)f_7269},
{"f_6726:c_2dbackend_2escm",(void*)f_6726},
{"f_3091:c_2dbackend_2escm",(void*)f_3091},
{"f_5306:c_2dbackend_2escm",(void*)f_5306},
{"f_7275:c_2dbackend_2escm",(void*)f_7275},
{"f_7278:c_2dbackend_2escm",(void*)f_7278},
{"f_3088:c_2dbackend_2escm",(void*)f_3088},
{"f_3085:c_2dbackend_2escm",(void*)f_3085},
{"f_3941:c_2dbackend_2escm",(void*)f_3941},
{"f_3082:c_2dbackend_2escm",(void*)f_3082},
{"f_4813:c_2dbackend_2escm",(void*)f_4813},
{"f_7284:c_2dbackend_2escm",(void*)f_7284},
{"f_7287:c_2dbackend_2escm",(void*)f_7287},
{"f_7281:c_2dbackend_2escm",(void*)f_7281},
{"f_4844:c_2dbackend_2escm",(void*)f_4844},
{"f_8849:c_2dbackend_2escm",(void*)f_8849},
{"f_3062:c_2dbackend_2escm",(void*)f_3062},
{"f_6431:c_2dbackend_2escm",(void*)f_6431},
{"f_3059:c_2dbackend_2escm",(void*)f_3059},
{"f_3056:c_2dbackend_2escm",(void*)f_3056},
{"f_6446:c_2dbackend_2escm",(void*)f_6446},
{"f_3915:c_2dbackend_2escm",(void*)f_3915},
{"f_3053:c_2dbackend_2escm",(void*)f_3053},
{"f_8771:c_2dbackend_2escm",(void*)f_8771},
{"f_6437:c_2dbackend_2escm",(void*)f_6437},
{"f_3906:c_2dbackend_2escm",(void*)f_3906},
{"f_6434:c_2dbackend_2escm",(void*)f_6434},
{"f_3903:c_2dbackend_2escm",(void*)f_3903},
{"f_9985:c_2dbackend_2escm",(void*)f_9985},
{"f_10009:c_2dbackend_2escm",(void*)f_10009},
{"f_3978:c_2dbackend_2escm",(void*)f_3978},
{"f_3592:c_2dbackend_2escm",(void*)f_3592},
{"f_3598:c_2dbackend_2escm",(void*)f_3598},
{"f_3595:c_2dbackend_2escm",(void*)f_3595},
{"f_10965:c_2dbackend_2escm",(void*)f_10965},
{"f_8788:c_2dbackend_2escm",(void*)f_8788},
{"f_3968:c_2dbackend_2escm",(void*)f_3968},
{"f_3022:c_2dbackend_2escm",(void*)f_3022},
{"f_3025:c_2dbackend_2escm",(void*)f_3025},
{"f_10114:c_2dbackend_2escm",(void*)f_10114},
{"f_8781:c_2dbackend_2escm",(void*)f_8781},
{"f_10977:c_2dbackend_2escm",(void*)f_10977},
{"f_10123:c_2dbackend_2escm",(void*)f_10123},
{"f_10126:c_2dbackend_2escm",(void*)f_10126},
{"f_10120:c_2dbackend_2escm",(void*)f_10120},
{"f_9553:c_2dbackend_2escm",(void*)f_9553},
{"f_10979:c_2dbackend_2escm",(void*)f_10979},
{"f_11009:c_2dbackend_2escm",(void*)f_11009},
{"f_11003:c_2dbackend_2escm",(void*)f_11003},
{"f_8764:c_2dbackend_2escm",(void*)f_8764},
{"f_11018:c_2dbackend_2escm",(void*)f_11018},
{"f_4189:c_2dbackend_2escm",(void*)f_4189},
{"f_8798:c_2dbackend_2escm",(void*)f_8798},
{"f_11012:c_2dbackend_2escm",(void*)f_11012},
{"f_11015:c_2dbackend_2escm",(void*)f_11015},
{"f_6636:c_2dbackend_2escm",(void*)f_6636},
{"f_7293:c_2dbackend_2escm",(void*)f_7293},
{"f_7299:c_2dbackend_2escm",(void*)f_7299},
{"f_11028:c_2dbackend_2escm",(void*)f_11028},
{"f_7296:c_2dbackend_2escm",(void*)f_7296},
{"f_7290:c_2dbackend_2escm",(void*)f_7290},
{"f_2569:c_2dbackend_2escm",(void*)f_2569},
{"f_6359:c_2dbackend_2escm",(void*)f_6359},
{"f_6356:c_2dbackend_2escm",(void*)f_6356},
{"f_4192:c_2dbackend_2escm",(void*)f_4192},
{"f_6353:c_2dbackend_2escm",(void*)f_6353},
{"f_11021:c_2dbackend_2escm",(void*)f_11021},
{"f_11024:c_2dbackend_2escm",(void*)f_11024},
{"f_6350:c_2dbackend_2escm",(void*)f_6350},
{"f_3589:c_2dbackend_2escm",(void*)f_3589},
{"f_6624:c_2dbackend_2escm",(void*)f_6624},
{"f_6627:c_2dbackend_2escm",(void*)f_6627},
{"f_6347:c_2dbackend_2escm",(void*)f_6347},
{"f_6344:c_2dbackend_2escm",(void*)f_6344},
{"f_6341:c_2dbackend_2escm",(void*)f_6341},
{"f_2543:c_2dbackend_2escm",(void*)f_2543},
{"f_2549:c_2dbackend_2escm",(void*)f_2549},
{"f_2546:c_2dbackend_2escm",(void*)f_2546},
{"f_2540:c_2dbackend_2escm",(void*)f_2540},
{"f_4170:c_2dbackend_2escm",(void*)f_4170},
{"f_4173:c_2dbackend_2escm",(void*)f_4173},
{"f_5042:c_2dbackend_2escm",(void*)f_5042},
{"f_8331:c_2dbackend_2escm",(void*)f_8331},
{"f_5032:c_2dbackend_2escm",(void*)f_5032},
{"f_6316:c_2dbackend_2escm",(void*)f_6316},
{"f_7537:c_2dbackend_2escm",(void*)f_7537},
{"f_6306:c_2dbackend_2escm",(void*)f_6306},
{"f_6309:c_2dbackend_2escm",(void*)f_6309},
{"f_6303:c_2dbackend_2escm",(void*)f_6303},
{"f_6300:c_2dbackend_2escm",(void*)f_6300},
{"f_7548:c_2dbackend_2escm",(void*)f_7548},
{"f_6338:c_2dbackend_2escm",(void*)f_6338},
{"f_6335:c_2dbackend_2escm",(void*)f_6335},
{"f_6332:c_2dbackend_2escm",(void*)f_6332},
{"f_6326:c_2dbackend_2escm",(void*)f_6326},
{"f_5495:c_2dbackend_2escm",(void*)f_5495},
{"f_6141:c_2dbackend_2escm",(void*)f_6141},
{"f_7594:c_2dbackend_2escm",(void*)f_7594},
{"f_6144:c_2dbackend_2escm",(void*)f_6144},
{"f_7591:c_2dbackend_2escm",(void*)f_7591},
{"f_5061:c_2dbackend_2escm",(void*)f_5061},
{"f_5484:c_2dbackend_2escm",(void*)f_5484},
{"f_5487:c_2dbackend_2escm",(void*)f_5487},
{"f_6134:c_2dbackend_2escm",(void*)f_6134},
{"f_5768:c_2dbackend_2escm",(void*)f_5768},
{"f_5764:c_2dbackend_2escm",(void*)f_5764},
{"f_10372:c_2dbackend_2escm",(void*)f_10372},
{"f_5475:c_2dbackend_2escm",(void*)f_5475},
{"f_7579:c_2dbackend_2escm",(void*)f_7579},
{"f_5478:c_2dbackend_2escm",(void*)f_5478},
{"f_5348:c_2dbackend_2escm",(void*)f_5348},
{"f_7585:c_2dbackend_2escm",(void*)f_7585},
{"f_5465:c_2dbackend_2escm",(void*)f_5465},
{"f_7588:c_2dbackend_2escm",(void*)f_7588},
{"f_5469:c_2dbackend_2escm",(void*)f_5469},
{"f_6497:c_2dbackend_2escm",(void*)f_6497},
{"f_7581:c_2dbackend_2escm",(void*)f_7581},
{"f_6490:c_2dbackend_2escm",(void*)f_6490},
{"f_6494:c_2dbackend_2escm",(void*)f_6494},
{"f_4805:c_2dbackend_2escm",(void*)f_4805},
{"f_5325:c_2dbackend_2escm",(void*)f_5325},
{"f_5322:c_2dbackend_2escm",(void*)f_5322},
{"f_5320:c_2dbackend_2escm",(void*)f_5320},
{"f_10393:c_2dbackend_2escm",(void*)f_10393},
{"f_5338:c_2dbackend_2escm",(void*)f_5338},
{"f_10396:c_2dbackend_2escm",(void*)f_10396},
{"f_10390:c_2dbackend_2escm",(void*)f_10390},
{"f_4481:c_2dbackend_2escm",(void*)f_4481},
{"f_4484:c_2dbackend_2escm",(void*)f_4484},
{"f_4487:c_2dbackend_2escm",(void*)f_4487},
{"f_5329:c_2dbackend_2escm",(void*)f_5329},
{"f_10369:c_2dbackend_2escm",(void*)f_10369},
{"f_10366:c_2dbackend_2escm",(void*)f_10366},
{"f_10360:c_2dbackend_2escm",(void*)f_10360},
{"f_7566:c_2dbackend_2escm",(void*)f_7566},
{"f_4490:c_2dbackend_2escm",(void*)f_4490},
{"f_4493:c_2dbackend_2escm",(void*)f_4493},
{"f_7688:c_2dbackend_2escm",(void*)f_7688},
{"f_5793:c_2dbackend_2escm",(void*)f_5793},
{"f_5798:c_2dbackend_2escm",(void*)f_5798},
{"f_5796:c_2dbackend_2escm",(void*)f_5796},
{"f_5789:c_2dbackend_2escm",(void*)f_5789},
{"f_4478:c_2dbackend_2escm",(void*)f_4478},
{"f_6946:c_2dbackend_2escm",(void*)f_6946},
{"f_6949:c_2dbackend_2escm",(void*)f_6949},
{"f_6942:c_2dbackend_2escm",(void*)f_6942},
{"f_6939:c_2dbackend_2escm",(void*)f_6939},
{"f_8649:c_2dbackend_2escm",(void*)f_8649},
{"f_8261:c_2dbackend_2escm",(void*)f_8261},
{"f_8254:c_2dbackend_2escm",(void*)f_8254},
{"f_8252:c_2dbackend_2escm",(void*)f_8252},
{"f_10384:c_2dbackend_2escm",(void*)f_10384},
{"f_9358:c_2dbackend_2escm",(void*)f_9358},
{"f_8256:c_2dbackend_2escm",(void*)f_8256},
{"f_4026:c_2dbackend_2escm",(void*)f_4026},
{"f_10878:c_2dbackend_2escm",(void*)f_10878},
{"f_5838:c_2dbackend_2escm",(void*)f_5838},
{"f_10883:c_2dbackend_2escm",(void*)f_10883},
{"f_4293:c_2dbackend_2escm",(void*)f_4293},
{"f_5827:c_2dbackend_2escm",(void*)f_5827},
{"f_7655:c_2dbackend_2escm",(void*)f_7655},
{"f_7651:c_2dbackend_2escm",(void*)f_7651},
{"f_4275:c_2dbackend_2escm",(void*)f_4275},
{"f_4016:c_2dbackend_2escm",(void*)f_4016},
{"f_4010:c_2dbackend_2escm",(void*)f_4010},
{"f_4278:c_2dbackend_2escm",(void*)f_4278},
{"f_4013:c_2dbackend_2escm",(void*)f_4013},
{"f_5091:c_2dbackend_2escm",(void*)f_5091},
{"f_5097:c_2dbackend_2escm",(void*)f_5097},
{"f_5094:c_2dbackend_2escm",(void*)f_5094},
{"f_4289:c_2dbackend_2escm",(void*)f_4289},
{"f_5084:c_2dbackend_2escm",(void*)f_5084},
{"f_3712:c_2dbackend_2escm",(void*)f_3712},
{"f_5088:c_2dbackend_2escm",(void*)f_5088},
{"f_3708:c_2dbackend_2escm",(void*)f_3708},
{"f_5071:c_2dbackend_2escm",(void*)f_5071},
{"f_10896:c_2dbackend_2escm",(void*)f_10896},
{"f_4263:c_2dbackend_2escm",(void*)f_4263},
{"f_7335:c_2dbackend_2escm",(void*)f_7335},
{"f_6100:c_2dbackend_2escm",(void*)f_6100},
{"f_7339:c_2dbackend_2escm",(void*)f_7339},
{"f_6109:c_2dbackend_2escm",(void*)f_6109},
{"f_5518:c_2dbackend_2escm",(void*)f_5518},
{"f_7302:c_2dbackend_2escm",(void*)f_7302},
{"f_7305:c_2dbackend_2escm",(void*)f_7305},
{"f_7308:c_2dbackend_2escm",(void*)f_7308},
{"f_7311:c_2dbackend_2escm",(void*)f_7311},
{"f_7317:c_2dbackend_2escm",(void*)f_7317},
{"f_7314:c_2dbackend_2escm",(void*)f_7314},
{"f_6124:c_2dbackend_2escm",(void*)f_6124},
{"f_6128:c_2dbackend_2escm",(void*)f_6128},
{"f_7374:c_2dbackend_2escm",(void*)f_7374},
{"f_7377:c_2dbackend_2escm",(void*)f_7377},
{"f_5505:c_2dbackend_2escm",(void*)f_5505},
{"f_6666:c_2dbackend_2escm",(void*)f_6666},
{"f_4311:c_2dbackend_2escm",(void*)f_4311},
{"f_4314:c_2dbackend_2escm",(void*)f_4314},
{"f_8638:c_2dbackend_2escm",(void*)f_8638},
{"f_4305:c_2dbackend_2escm",(void*)f_4305},
{"f_4308:c_2dbackend_2escm",(void*)f_4308},
{"f_8580:c_2dbackend_2escm",(void*)f_8580},
{"f_3769:c_2dbackend_2escm",(void*)f_3769},
{"f_8599:c_2dbackend_2escm",(void*)f_8599},
{"f_3763:c_2dbackend_2escm",(void*)f_3763},
{"f_3760:c_2dbackend_2escm",(void*)f_3760},
{"f_7389:c_2dbackend_2escm",(void*)f_7389},
{"f_7386:c_2dbackend_2escm",(void*)f_7386},
{"f_7380:c_2dbackend_2escm",(void*)f_7380},
{"f_8655:c_2dbackend_2escm",(void*)f_8655},
{"f_3757:c_2dbackend_2escm",(void*)f_3757},
{"f_3751:c_2dbackend_2escm",(void*)f_3751},
{"f_3754:c_2dbackend_2escm",(void*)f_3754},
{"f_3745:c_2dbackend_2escm",(void*)f_3745},
{"f_3748:c_2dbackend_2escm",(void*)f_3748},
{"f_7362:c_2dbackend_2escm",(void*)f_7362},
{"f_4762:c_2dbackend_2escm",(void*)f_4762},
{"f_7368:c_2dbackend_2escm",(void*)f_7368},
{"f_6908:c_2dbackend_2escm",(void*)f_6908},
{"f_4758:c_2dbackend_2escm",(void*)f_4758},
{"f_3738:c_2dbackend_2escm",(void*)f_3738},
{"f_8568:c_2dbackend_2escm",(void*)f_8568},
{"f_3734:c_2dbackend_2escm",(void*)f_3734},
{"f_3119:c_2dbackend_2escm",(void*)f_3119},
{"f_3114:c_2dbackend_2escm",(void*)f_3114},
{"f_3115:c_2dbackend_2escm",(void*)f_3115},
{"f_3727:c_2dbackend_2escm",(void*)f_3727},
{"f_3720:c_2dbackend_2escm",(void*)f_3720},
{"f_3383:c_2dbackend_2escm",(void*)f_3383},
{"f_2592:c_2dbackend_2escm",(void*)f_2592},
{"f_3379:c_2dbackend_2escm",(void*)f_3379},
{"f_8595:c_2dbackend_2escm",(void*)f_8595},
{"f_6844:c_2dbackend_2escm",(void*)f_6844},
{"f_2579:c_2dbackend_2escm",(void*)f_2579},
{"f_4771:c_2dbackend_2escm",(void*)f_4771},
{"f_4774:c_2dbackend_2escm",(void*)f_4774},
{"f_11032:c_2dbackend_2escm",(void*)f_11032},
{"f_8921:c_2dbackend_2escm",(void*)f_8921},
{"f_11036:c_2dbackend_2escm",(void*)f_11036},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		4
S|  sprintf		21
S|  for-each		22
o|eliminated procedure checks: 136 
o|specializations:
o|  1 (number->string fixnum)
o|  1 (cdddr (pair * (pair * pair)))
o|  3 (>= fixnum fixnum)
o|  1 (> fixnum fixnum)
o|  2 (memq * list)
o|  8 (= fixnum fixnum)
o|  4 (length list)
o|  1 (zero? number)
o|  1 (vector-length vector)
o|  2 (bitwise-and fixnum fixnum)
o|  3 (zero? fixnum)
o|  4 (string-append string string)
o|  5 (car pair)
o|  6 (cdr pair)
o|  5 (first pair)
o|  271 (eqv? * (not float))
o|  21 (##sys#check-output-port * * *)
o|  17 (##sys#check-list (or pair list) *)
o|safe globals: (##compiler#gen-list ##compiler#gen ##compiler#output) 
o|Removed `not' forms: 19 
o|inlining procedure: k2571 
o|contracted procedure: "(c-backend.scm:39) g2835" 
o|inlining procedure: k2553 
o|inlining procedure: k2553 
o|inlining procedure: k2571 
o|inlining procedure: k2608 
o|contracted procedure: "(c-backend.scm:47) g4855" 
o|inlining procedure: k2608 
o|inlining procedure: k2644 
o|inlining procedure: k2644 
o|inlining procedure: k2680 
o|inlining procedure: k2699 
o|inlining procedure: k2699 
o|inlining procedure: k2705 
o|inlining procedure: k2705 
o|inlining procedure: k2731 
o|inlining procedure: k2731 
o|substituted constant variable: a2757 
o|substituted constant variable: a2759 
o|substituted constant variable: a2761 
o|substituted constant variable: a2763 
o|substituted constant variable: a2765 
o|inlining procedure: k2680 
o|inlining procedure: k2775 
o|inlining procedure: k2775 
o|inlining procedure: k2793 
o|inlining procedure: k2793 
o|inlining procedure: k2845 
o|inlining procedure: k2861 
o|inlining procedure: k2861 
o|inlining procedure: k2845 
o|inlining procedure: k2929 
o|inlining procedure: k2929 
o|inlining procedure: k2975 
o|inlining procedure: k2975 
o|inlining procedure: k3045 
o|inlining procedure: k3045 
o|inlining procedure: k3103 
o|inlining procedure: k3145 
o|inlining procedure: k3145 
o|inlining procedure: k3103 
o|inlining procedure: k3198 
o|inlining procedure: k3198 
o|inlining procedure: k3231 
o|inlining procedure: k3249 
o|inlining procedure: k3249 
o|inlining procedure: k3270 
o|inlining procedure: k3270 
o|inlining procedure: k3231 
o|inlining procedure: k3324 
o|inlining procedure: k3324 
o|inlining procedure: k3393 
o|contracted procedure: "(c-backend.scm:242) g257258" 
o|inlining procedure: k3457 
o|inlining procedure: k3500 
o|inlining procedure: k3500 
o|inlining procedure: k3512 
o|contracted procedure: "(c-backend.scm:257) g298306" 
o|inlining procedure: k3512 
o|inlining procedure: k3549 
o|inlining procedure: k3549 
o|inlining procedure: k3457 
o|inlining procedure: k3689 
o|inlining procedure: k3689 
o|contracted procedure: "(c-backend.scm:276) g336337" 
o|propagated global variable: tmp354356 unsafe 
o|propagated global variable: tmp354356 unsafe 
o|propagated global variable: tmp357359 ##compiler#no-procedure-checks 
o|inlining procedure: k3776 
o|propagated global variable: tmp357359 ##compiler#no-procedure-checks 
o|inlining procedure: k3776 
o|contracted procedure: k3786 
o|propagated global variable: r3787 unsafe 
o|inlining procedure: k3783 
o|inlining procedure: k3783 
o|contracted procedure: k3792 
o|propagated global variable: r3793 ##compiler#no-procedure-checks 
o|contracted procedure: "(c-backend.scm:272) g330331" 
o|contracted procedure: "(c-backend.scm:241) g253254" 
o|inlining procedure: k3818 
o|inlining procedure: k3818 
o|inlining procedure: k3849 
o|inlining procedure: k3849 
o|inlining procedure: k3393 
o|inlining procedure: k3890 
o|inlining procedure: k3933 
o|contracted procedure: "(c-backend.scm:333) g406414" 
o|inlining procedure: k3933 
o|inlining procedure: k3970 
o|inlining procedure: k3970 
o|inlining procedure: k3890 
o|inlining procedure: k4027 
o|inlining procedure: k4079 
o|inlining procedure: k4079 
o|inlining procedure: k4091 
o|inlining procedure: k4091 
o|inlining procedure: k4027 
o|inlining procedure: k4143 
o|inlining procedure: k4143 
o|inlining procedure: k4181 
o|inlining procedure: k4181 
o|inlining procedure: k4232 
o|inlining procedure: k4232 
o|inlining procedure: k4294 
o|inlining procedure: k4294 
o|inlining procedure: k4347 
o|inlining procedure: k4347 
o|inlining procedure: k4389 
o|inlining procedure: k4416 
o|inlining procedure: k4416 
o|inlining procedure: k4389 
o|contracted procedure: "(c-backend.scm:450) g495496" 
o|substituted constant variable: a4522 
o|substituted constant variable: a4524 
o|substituted constant variable: a4526 
o|substituted constant variable: a4528 
o|substituted constant variable: a4530 
o|substituted constant variable: a4532 
o|substituted constant variable: a4534 
o|substituted constant variable: a4536 
o|substituted constant variable: a4538 
o|substituted constant variable: a4540 
o|substituted constant variable: a4542 
o|substituted constant variable: a4544 
o|substituted constant variable: a4546 
o|substituted constant variable: a4548 
o|substituted constant variable: a4550 
o|substituted constant variable: a4552 
o|substituted constant variable: a4554 
o|substituted constant variable: a4556 
o|substituted constant variable: a4558 
o|substituted constant variable: a4560 
o|substituted constant variable: a4562 
o|substituted constant variable: a4564 
o|substituted constant variable: a4566 
o|substituted constant variable: a4568 
o|substituted constant variable: a4570 
o|substituted constant variable: a4572 
o|substituted constant variable: a4574 
o|substituted constant variable: a4576 
o|substituted constant variable: a4578 
o|substituted constant variable: a4580 
o|substituted constant variable: a4582 
o|substituted constant variable: a4584 
o|substituted constant variable: a4586 
o|substituted constant variable: a4588 
o|substituted constant variable: a4590 
o|substituted constant variable: a4592 
o|contracted procedure: "(c-backend.scm:79) g127128" 
o|contracted procedure: "(c-backend.scm:78) g118119" 
o|contracted procedure: "(c-backend.scm:77) g115116" 
o|contracted procedure: k4612 
o|inlining procedure: k4631 
o|substituted constant variable: a4640 
o|inlining procedure: k4631 
o|inlining procedure: k4684 
o|inlining procedure: k4684 
o|inlining procedure: k4707 
o|contracted procedure: "(c-backend.scm:491) g553560" 
o|inlining procedure: k4707 
o|propagated global variable: g559561 ##compiler#foreign-declarations 
o|inlining procedure: k4778 
o|contracted procedure: "(c-backend.scm:476) g520529" 
o|inlining procedure: k4778 
o|inlining procedure: k4868 
o|inlining procedure: k4868 
o|inlining procedure: k4908 
o|inlining procedure: k4908 
o|inlining procedure: k4935 
o|inlining procedure: k4935 
o|substituted constant variable: a4968 
o|inlining procedure: k4988 
o|contracted procedure: "(c-backend.scm:506) g581588" 
o|inlining procedure: k4988 
o|propagated global variable: g587589 ##compiler#used-units 
o|inlining procedure: k5063 
o|contracted procedure: "(c-backend.scm:586) g683690" 
o|inlining procedure: k5034 
o|inlining procedure: k5034 
o|inlining procedure: k5063 
o|inlining procedure: k5118 
o|inlining procedure: k5118 
o|inlining procedure: k5156 
o|contracted procedure: k5165 
o|inlining procedure: k5156 
o|inlining procedure: k5203 
o|inlining procedure: k5203 
o|contracted procedure: k5222 
o|inlining procedure: k5234 
o|inlining procedure: k5234 
o|inlining procedure: k5247 
o|inlining procedure: k5247 
o|inlining procedure: k5272 
o|inlining procedure: k5272 
o|inlining procedure: k5308 
o|inlining procedure: k5308 
o|inlining procedure: k5340 
o|inlining procedure: k5340 
o|substituted constant variable: nsrv721 
o|inlining procedure: k5497 
o|inlining procedure: k5497 
o|inlining procedure: k5520 
o|inlining procedure: k5520 
o|inlining procedure: k5543 
o|inlining procedure: k5543 
o|inlining procedure: k5584 
o|inlining procedure: k5584 
o|inlining procedure: k5618 
o|inlining procedure: k5618 
o|inlining procedure: k5648 
o|inlining procedure: k5648 
o|inlining procedure: k5678 
o|inlining procedure: k5678 
o|substituted constant variable: a5705 
o|substituted constant variable: a5706 
o|inlining procedure: k5728 
o|inlining procedure: k5728 
o|inlining procedure: k5740 
o|propagated global variable: r574111201 ##compiler#words-per-flonum 
o|inlining procedure: k5740 
o|inlining procedure: k5752 
o|inlining procedure: k5752 
o|inlining procedure: k5800 
o|inlining procedure: k5800 
o|inlining procedure: k5833 
o|inlining procedure: k5833 
o|inlining procedure: "(c-backend.scm:680) bad-literal95" 
o|inlining procedure: k5848 
o|inlining procedure: k5848 
o|inlining procedure: k5868 
o|inlining procedure: k5887 
o|inlining procedure: k5887 
o|inlining procedure: k5868 
o|inlining procedure: "(c-backend.scm:689) bad-literal95" 
o|inlining procedure: k5918 
o|inlining procedure: k5918 
o|inlining procedure: k5933 
o|inlining procedure: k5933 
o|inlining procedure: k5952 
o|inlining procedure: k5952 
o|inlining procedure: k5955 
o|inlining procedure: k5955 
o|inlining procedure: k5989 
o|inlining procedure: k5989 
o|inlining procedure: k6004 
o|inlining procedure: k6004 
o|inlining procedure: "(c-backend.scm:716) bad-literal95" 
o|contracted procedure: k6036 
o|inlining procedure: k6075 
o|inlining procedure: k6075 
o|inlining procedure: k6318 
o|inlining procedure: k6318 
o|inlining procedure: k6327 
o|inlining procedure: k6385 
o|inlining procedure: k6385 
o|inlining procedure: k6423 
o|inlining procedure: k6423 
o|inlining procedure: k6327 
o|inlining procedure: k6457 
o|inlining procedure: k6457 
o|contracted procedure: k6463 
o|contracted procedure: k6469 
o|inlining procedure: k6466 
o|inlining procedure: k6466 
o|inlining procedure: k6475 
o|inlining procedure: k6475 
o|contracted procedure: k6513 
o|inlining procedure: k6510 
o|inlining procedure: k6510 
o|inlining procedure: k6533 
o|inlining procedure: k6533 
o|inlining procedure: k6555 
o|contracted procedure: k6591 
o|propagated global variable: r6592 unsafe 
o|contracted procedure: k6597 
o|propagated global variable: r6598 ##compiler#no-argc-checks 
o|inlining procedure: k6594 
o|inlining procedure: k6594 
o|inlining procedure: k6555 
o|inlining procedure: k6637 
o|inlining procedure: k6637 
o|contracted procedure: k6655 
o|inlining procedure: k6658 
o|inlining procedure: k6658 
o|inlining procedure: k6667 
o|inlining procedure: k6667 
o|contracted procedure: k6688 
o|propagated global variable: r6689 unsafe 
o|inlining procedure: k6685 
o|inlining procedure: k6685 
o|contracted procedure: k6694 
o|propagated global variable: r6695 ##compiler#no-argc-checks 
o|inlining procedure: k6703 
o|inlining procedure: k6703 
o|inlining procedure: k6718 
o|inlining procedure: k6718 
o|contracted procedure: k6733 
o|propagated global variable: r6734 unsafe 
o|inlining procedure: k6730 
o|inlining procedure: k6730 
o|contracted procedure: k6742 
o|contracted procedure: "(c-backend.scm:806) utype100" 
o|inlining procedure: k6148 
o|inlining procedure: k6148 
o|inlining procedure: k6160 
o|inlining procedure: k6160 
o|inlining procedure: k6172 
o|inlining procedure: k6172 
o|substituted constant variable: a6188 
o|substituted constant variable: a6190 
o|substituted constant variable: a6192 
o|substituted constant variable: a6194 
o|substituted constant variable: a6196 
o|substituted constant variable: a6198 
o|inlining procedure: k6778 
o|inlining procedure: k6778 
o|inlining procedure: k6805 
o|inlining procedure: k6805 
o|inlining procedure: k6826 
o|inlining procedure: k6826 
o|inlining procedure: k6845 
o|inlining procedure: k6845 
o|contracted procedure: k6864 
o|inlining procedure: k6873 
o|inlining procedure: k6873 
o|inlining procedure: k6886 
o|inlining procedure: k6886 
o|inlining procedure: k6916 
o|inlining procedure: k6916 
o|inlining procedure: k6923 
o|inlining procedure: k6923 
o|inlining procedure: k6930 
o|inlining procedure: k6930 
o|contracted procedure: "(c-backend.scm:925) trailer90" 
o|inlining procedure: k7005 
o|inlining procedure: k7005 
o|inlining procedure: k7047 
o|inlining procedure: k7047 
o|inlining procedure: k7085 
o|inlining procedure: k7085 
o|inlining procedure: k7094 
o|inlining procedure: k7094 
o|inlining procedure: k7103 
o|inlining procedure: k7103 
o|inlining procedure: k7193 
o|contracted procedure: "(c-backend.scm:989) g11671174" 
o|inlining procedure: k7193 
o|inlining procedure: k7236 
o|contracted procedure: "(c-backend.scm:1000) g11911198" 
o|inlining procedure: k7236 
o|inlining procedure: k7378 
o|inlining procedure: k7396 
o|inlining procedure: k7396 
o|inlining procedure: k7378 
o|inlining procedure: k7426 
o|inlining procedure: k7426 
o|contracted procedure: k7449 
o|inlining procedure: k7468 
o|contracted procedure: "(c-backend.scm:1040) g12421251" 
o|inlining procedure: k7345 
o|substituted constant variable: a7355 
o|substituted constant variable: a7356 
o|inlining procedure: k7345 
o|inlining procedure: k7468 
o|inlining procedure: k7507 
o|inlining procedure: k7507 
o|inlining procedure: k7558 
o|inlining procedure: k7558 
o|inlining procedure: k7604 
o|inlining procedure: k7604 
o|inlining procedure: k7625 
o|inlining procedure: k7625 
o|inlining procedure: k7661 
o|inlining procedure: k7661 
o|inlining procedure: k7652 
o|inlining procedure: k7652 
o|inlining procedure: k7680 
o|inlining procedure: k7680 
o|substituted constant variable: a7706 
o|inlining procedure: k7710 
o|inlining procedure: k7710 
o|inlining procedure: k7722 
o|inlining procedure: k7722 
o|inlining procedure: k7734 
o|inlining procedure: k7734 
o|inlining procedure: k7746 
o|inlining procedure: k7746 
o|substituted constant variable: a7753 
o|substituted constant variable: a7755 
o|substituted constant variable: a7757 
o|substituted constant variable: a7759 
o|substituted constant variable: a7761 
o|substituted constant variable: a7763 
o|substituted constant variable: a7765 
o|substituted constant variable: a7767 
o|substituted constant variable: a7769 
o|inlining procedure: k7779 
o|inlining procedure: k7779 
o|inlining procedure: k7791 
o|inlining procedure: k7791 
o|substituted constant variable: a7798 
o|substituted constant variable: a7800 
o|substituted constant variable: a7802 
o|substituted constant variable: a7804 
o|substituted constant variable: a7806 
o|inlining procedure: k7810 
o|inlining procedure: k7810 
o|inlining procedure: k7822 
o|inlining procedure: k7822 
o|substituted constant variable: a7829 
o|substituted constant variable: a7831 
o|substituted constant variable: a7833 
o|substituted constant variable: a7835 
o|substituted constant variable: a7837 
o|inlining procedure: k7841 
o|inlining procedure: k7841 
o|inlining procedure: k7853 
o|inlining procedure: k7853 
o|inlining procedure: k7865 
o|inlining procedure: k7865 
o|inlining procedure: k7877 
o|inlining procedure: k7877 
o|inlining procedure: k7889 
o|inlining procedure: k7889 
o|inlining procedure: k7901 
o|inlining procedure: k7901 
o|inlining procedure: k7913 
o|inlining procedure: k7913 
o|substituted constant variable: a7926 
o|substituted constant variable: a7928 
o|substituted constant variable: a7930 
o|substituted constant variable: a7932 
o|substituted constant variable: a7934 
o|substituted constant variable: a7936 
o|substituted constant variable: a7938 
o|substituted constant variable: a7940 
o|substituted constant variable: a7942 
o|substituted constant variable: a7944 
o|substituted constant variable: a7946 
o|substituted constant variable: a7948 
o|substituted constant variable: a7950 
o|substituted constant variable: a7952 
o|substituted constant variable: a7954 
o|substituted constant variable: a7956 
o|inlining procedure: k7960 
o|inlining procedure: k7960 
o|inlining procedure: k7972 
o|inlining procedure: k7972 
o|inlining procedure: k7984 
o|inlining procedure: k7984 
o|inlining procedure: k7996 
o|inlining procedure: k7996 
o|inlining procedure: k8008 
o|inlining procedure: k8008 
o|inlining procedure: k8020 
o|inlining procedure: k8020 
o|substituted constant variable: a8027 
o|substituted constant variable: a8029 
o|substituted constant variable: a8031 
o|substituted constant variable: a8033 
o|substituted constant variable: a8035 
o|substituted constant variable: a8037 
o|substituted constant variable: a8039 
o|substituted constant variable: a8041 
o|substituted constant variable: a8043 
o|substituted constant variable: a8045 
o|substituted constant variable: a8047 
o|substituted constant variable: a8049 
o|substituted constant variable: a8051 
o|inlining procedure: k8088 
o|inlining procedure: k8088 
o|inlining procedure: k8113 
o|contracted procedure: "(c-backend.scm:1120) g14951503" 
o|inlining procedure: k8113 
o|inlining procedure: k8148 
o|inlining procedure: k8148 
o|inlining procedure: k8170 
o|inlining procedure: k8170 
o|inlining procedure: k8226 
o|inlining procedure: k8226 
o|inlining procedure: k8266 
o|inlining procedure: k8266 
o|inlining procedure: k8287 
o|inlining procedure: k8287 
o|inlining procedure: k8311 
o|inlining procedure: k8311 
o|inlining procedure: k8335 
o|inlining procedure: k8335 
o|inlining procedure: k8356 
o|inlining procedure: k8356 
o|inlining procedure: k8374 
o|inlining procedure: k8374 
o|inlining procedure: k8392 
o|inlining procedure: k8392 
o|inlining procedure: k8410 
o|inlining procedure: k8410 
o|inlining procedure: k8431 
o|inlining procedure: k8431 
o|inlining procedure: k8452 
o|inlining procedure: k8452 
o|inlining procedure: k8476 
o|inlining procedure: k8476 
o|inlining procedure: k8500 
o|inlining procedure: k8500 
o|inlining procedure: k8524 
o|inlining procedure: k8524 
o|inlining procedure: k8548 
o|inlining procedure: k8548 
o|inlining procedure: k8572 
o|inlining procedure: k8572 
o|inlining procedure: k8605 
o|inlining procedure: k8605 
o|inlining procedure: k8596 
o|inlining procedure: k8596 
o|inlining procedure: k8626 
o|inlining procedure: k8650 
o|inlining procedure: k8650 
o|inlining procedure: k8706 
o|contracted procedure: "(c-backend.scm:1209) g16731682" 
o|propagated global variable: g16901691 ##compiler#foreign-type-declaration 
o|inlining procedure: k8706 
o|inlining procedure: k8742 
o|inlining procedure: k8742 
o|inlining procedure: k8776 
o|inlining procedure: k8776 
o|inlining procedure: k8810 
o|inlining procedure: k8810 
o|inlining procedure: k8844 
o|inlining procedure: k8894 
o|contracted procedure: "(c-backend.scm:1233) g17211730" 
o|inlining procedure: k8876 
o|inlining procedure: k8876 
o|inlining procedure: k8894 
o|inlining procedure: k8844 
o|substituted constant variable: a8946 
o|substituted constant variable: a8958 
o|substituted constant variable: a8966 
o|substituted constant variable: a8968 
o|substituted constant variable: a8980 
o|substituted constant variable: a8992 
o|substituted constant variable: a9004 
o|substituted constant variable: a9016 
o|substituted constant variable: a9028 
o|substituted constant variable: a9039 
o|substituted constant variable: a9048 
o|substituted constant variable: a9049 
o|inlining procedure: k8626 
o|substituted constant variable: a9061 
o|inlining procedure: k9065 
o|inlining procedure: k9065 
o|substituted constant variable: a9078 
o|substituted constant variable: a9080 
o|substituted constant variable: a9082 
o|substituted constant variable: a9084 
o|inlining procedure: k9088 
o|inlining procedure: k9088 
o|inlining procedure: k9100 
o|inlining procedure: k9100 
o|substituted constant variable: a9107 
o|substituted constant variable: a9109 
o|substituted constant variable: a9111 
o|substituted constant variable: a9113 
o|substituted constant variable: a9115 
o|substituted constant variable: a9120 
o|substituted constant variable: a9122 
o|substituted constant variable: a9127 
o|substituted constant variable: a9129 
o|substituted constant variable: a9134 
o|substituted constant variable: a9136 
o|substituted constant variable: a9141 
o|substituted constant variable: a9143 
o|substituted constant variable: a9148 
o|substituted constant variable: a9150 
o|substituted constant variable: a9155 
o|substituted constant variable: a9157 
o|substituted constant variable: a9162 
o|substituted constant variable: a9164 
o|substituted constant variable: a9169 
o|substituted constant variable: a9171 
o|inlining procedure: k9175 
o|inlining procedure: k9175 
o|substituted constant variable: a9188 
o|substituted constant variable: a9190 
o|substituted constant variable: a9192 
o|substituted constant variable: a9194 
o|substituted constant variable: a9199 
o|substituted constant variable: a9201 
o|inlining procedure: k9205 
o|inlining procedure: k9205 
o|substituted constant variable: a9218 
o|substituted constant variable: a9220 
o|substituted constant variable: a9222 
o|substituted constant variable: a9224 
o|substituted constant variable: a9229 
o|substituted constant variable: a9231 
o|substituted constant variable: a9233 
o|substituted constant variable: a9235 
o|substituted constant variable: a9237 
o|substituted constant variable: a9239 
o|substituted constant variable: a9241 
o|substituted constant variable: a9243 
o|substituted constant variable: a9245 
o|substituted constant variable: a9250 
o|substituted constant variable: a9252 
o|substituted constant variable: a9254 
o|inlining procedure: k9258 
o|inlining procedure: k9258 
o|substituted constant variable: a9265 
o|substituted constant variable: a9267 
o|substituted constant variable: a9269 
o|substituted constant variable: a9274 
o|substituted constant variable: a9276 
o|substituted constant variable: a9281 
o|substituted constant variable: a9283 
o|substituted constant variable: a9288 
o|substituted constant variable: a9290 
o|substituted constant variable: a9295 
o|substituted constant variable: a9297 
o|substituted constant variable: a9299 
o|inlining procedure: k9308 
o|inlining procedure: k9308 
o|inlining procedure: k9323 
o|inlining procedure: k9323 
o|inlining procedure: k9338 
o|inlining procedure: k9338 
o|inlining procedure: k9350 
o|inlining procedure: k9350 
o|inlining procedure: k9368 
o|inlining procedure: k9368 
o|inlining procedure: k9380 
o|inlining procedure: k9380 
o|inlining procedure: k9392 
o|inlining procedure: k9392 
o|inlining procedure: k9407 
o|inlining procedure: k9407 
o|inlining procedure: k9419 
o|inlining procedure: k9419 
o|inlining procedure: k9431 
o|inlining procedure: k9431 
o|inlining procedure: k9443 
o|inlining procedure: k9443 
o|inlining procedure: k9455 
o|inlining procedure: k9455 
o|inlining procedure: k9467 
o|inlining procedure: k9467 
o|inlining procedure: k9479 
o|inlining procedure: k9479 
o|inlining procedure: k9491 
o|inlining procedure: k9491 
o|inlining procedure: k9503 
o|inlining procedure: k9503 
o|inlining procedure: k9515 
o|inlining procedure: k9515 
o|inlining procedure: k9527 
o|inlining procedure: k9527 
o|inlining procedure: k9539 
o|inlining procedure: k9539 
o|inlining procedure: k9554 
o|inlining procedure: k9554 
o|inlining procedure: k9572 
o|contracted procedure: "(c-backend.scm:1291) g18071808" 
o|inlining procedure: k9581 
o|inlining procedure: k9581 
o|inlining procedure: k9572 
o|inlining procedure: k9602 
o|inlining procedure: k9602 
o|inlining procedure: k9614 
o|inlining procedure: k9614 
o|inlining procedure: k9626 
o|inlining procedure: k9626 
o|inlining procedure: k9645 
o|inlining procedure: k9645 
o|inlining procedure: k9668 
o|inlining procedure: k9668 
o|substituted constant variable: a9685 
o|substituted constant variable: a9687 
o|substituted constant variable: a9689 
o|substituted constant variable: a9691 
o|substituted constant variable: a9693 
o|substituted constant variable: a9695 
o|substituted constant variable: a9697 
o|substituted constant variable: a9699 
o|substituted constant variable: a9701 
o|substituted constant variable: a9713 
o|substituted constant variable: a9721 
o|inlining procedure: k9725 
o|inlining procedure: k9725 
o|inlining procedure: k9737 
o|inlining procedure: k9737 
o|substituted constant variable: a9744 
o|substituted constant variable: a9746 
o|substituted constant variable: a9748 
o|substituted constant variable: a9750 
o|substituted constant variable: a9752 
o|inlining procedure: k9756 
o|inlining procedure: k9756 
o|substituted constant variable: a9769 
o|substituted constant variable: a9771 
o|substituted constant variable: a9773 
o|substituted constant variable: a9775 
o|substituted constant variable: a9777 
o|substituted constant variable: a9779 
o|substituted constant variable: a9781 
o|substituted constant variable: a9783 
o|substituted constant variable: a9785 
o|substituted constant variable: a9787 
o|substituted constant variable: a9789 
o|substituted constant variable: a9791 
o|substituted constant variable: a9793 
o|substituted constant variable: a9795 
o|substituted constant variable: a9797 
o|substituted constant variable: a9799 
o|substituted constant variable: a9801 
o|substituted constant variable: a9803 
o|substituted constant variable: a9805 
o|substituted constant variable: a9807 
o|substituted constant variable: a9809 
o|substituted constant variable: a9811 
o|substituted constant variable: a9813 
o|substituted constant variable: a9815 
o|substituted constant variable: a9817 
o|substituted constant variable: a9819 
o|substituted constant variable: a9821 
o|substituted constant variable: a9823 
o|substituted constant variable: a9828 
o|substituted constant variable: a9830 
o|substituted constant variable: a9832 
o|substituted constant variable: a9834 
o|substituted constant variable: a9836 
o|substituted constant variable: a9838 
o|substituted constant variable: a9843 
o|substituted constant variable: a9845 
o|inlining procedure: k9849 
o|inlining procedure: k9849 
o|substituted constant variable: a9856 
o|substituted constant variable: a9858 
o|substituted constant variable: a9860 
o|substituted constant variable: a9862 
o|substituted constant variable: a9864 
o|substituted constant variable: a9866 
o|inlining procedure: k9870 
o|inlining procedure: k9870 
o|inlining procedure: k9882 
o|inlining procedure: k9882 
o|substituted constant variable: a9895 
o|substituted constant variable: a9897 
o|substituted constant variable: a9899 
o|substituted constant variable: a9901 
o|substituted constant variable: a9903 
o|substituted constant variable: a9905 
o|substituted constant variable: a9910 
o|substituted constant variable: a9912 
o|substituted constant variable: a9914 
o|inlining procedure: k9923 
o|inlining procedure: k9923 
o|inlining procedure: k9941 
o|inlining procedure: k9941 
o|inlining procedure: k9956 
o|inlining procedure: k9956 
o|inlining procedure: k9968 
o|inlining procedure: k9968 
o|substituted constant variable: a9987 
o|substituted constant variable: a9988 
o|substituted constant variable: a10011 
o|substituted constant variable: a10012 
o|inlining procedure: k10001 
o|inlining procedure: k10001 
o|substituted constant variable: a10038 
o|substituted constant variable: a10039 
o|substituted constant variable: a10062 
o|substituted constant variable: a10063 
o|inlining procedure: k10052 
o|inlining procedure: k10052 
o|substituted constant variable: a10089 
o|substituted constant variable: a10090 
o|substituted constant variable: a10116 
o|substituted constant variable: a10117 
o|inlining procedure: k10103 
o|inlining procedure: k10103 
o|substituted constant variable: a10140 
o|substituted constant variable: a10141 
o|substituted constant variable: a10167 
o|substituted constant variable: a10168 
o|inlining procedure: k10154 
o|inlining procedure: k10154 
o|substituted constant variable: a10191 
o|substituted constant variable: a10192 
o|substituted constant variable: a10215 
o|substituted constant variable: a10216 
o|inlining procedure: k10205 
o|inlining procedure: k10205 
o|inlining procedure: k10235 
o|inlining procedure: k10235 
o|inlining procedure: k10256 
o|inlining procedure: k10256 
o|inlining procedure: k10268 
o|substituted constant variable: a10290 
o|substituted constant variable: a10291 
o|substituted constant variable: a10314 
o|substituted constant variable: a10315 
o|inlining procedure: k10304 
o|inlining procedure: k10304 
o|substituted constant variable: a10338 
o|substituted constant variable: a10339 
o|substituted constant variable: a10362 
o|substituted constant variable: a10363 
o|inlining procedure: k10352 
o|inlining procedure: k10352 
o|substituted constant variable: a10386 
o|substituted constant variable: a10387 
o|inlining procedure: k10400 
o|inlining procedure: k10400 
o|substituted constant variable: a10426 
o|substituted constant variable: a10427 
o|substituted constant variable: a10450 
o|substituted constant variable: a10451 
o|inlining procedure: k10440 
o|inlining procedure: k10440 
o|substituted constant variable: a10474 
o|substituted constant variable: a10475 
o|substituted constant variable: a10492 
o|substituted constant variable: a10494 
o|substituted constant variable: a10499 
o|substituted constant variable: a10501 
o|substituted constant variable: a10503 
o|substituted constant variable: a10505 
o|substituted constant variable: a10507 
o|substituted constant variable: a10509 
o|substituted constant variable: a10511 
o|substituted constant variable: a10516 
o|substituted constant variable: a10518 
o|inlining procedure: k10268 
o|substituted constant variable: a10530 
o|substituted constant variable: a10541 
o|substituted constant variable: a10543 
o|substituted constant variable: a10545 
o|substituted constant variable: a10547 
o|substituted constant variable: a10549 
o|substituted constant variable: a10554 
o|substituted constant variable: a10556 
o|substituted constant variable: a10558 
o|substituted constant variable: a10563 
o|substituted constant variable: a10565 
o|substituted constant variable: a10570 
o|substituted constant variable: a10572 
o|substituted constant variable: a10574 
o|inlining procedure: k10578 
o|inlining procedure: k10578 
o|inlining procedure: k10590 
o|inlining procedure: k10590 
o|inlining procedure: k10602 
o|inlining procedure: k10602 
o|inlining procedure: k10614 
o|inlining procedure: k10614 
o|inlining procedure: k10626 
o|inlining procedure: k10626 
o|substituted constant variable: a10639 
o|substituted constant variable: a10641 
o|substituted constant variable: a10643 
o|substituted constant variable: a10645 
o|substituted constant variable: a10647 
o|substituted constant variable: a10649 
o|substituted constant variable: a10651 
o|substituted constant variable: a10653 
o|substituted constant variable: a10655 
o|substituted constant variable: a10657 
o|substituted constant variable: a10659 
o|substituted constant variable: a10661 
o|substituted constant variable: a10663 
o|substituted constant variable: a10668 
o|substituted constant variable: a10670 
o|substituted constant variable: a10672 
o|substituted constant variable: a10674 
o|substituted constant variable: a10676 
o|substituted constant variable: a10678 
o|substituted constant variable: a10683 
o|substituted constant variable: a10685 
o|substituted constant variable: a10690 
o|substituted constant variable: a10692 
o|substituted constant variable: a10697 
o|substituted constant variable: a10699 
o|contracted procedure: "(c-backend.scm:1388) finish2146" 
o|inlining procedure: k10767 
o|inlining procedure: k10767 
o|substituted constant variable: a10782 
o|inlining procedure: k10791 
o|inlining procedure: k10791 
o|inlining procedure: k10803 
o|inlining procedure: k10803 
o|contracted procedure: k10818 
o|inlining procedure: k10815 
o|inlining procedure: k10815 
o|substituted constant variable: a10824 
o|substituted constant variable: a10846 
o|inlining procedure: k10884 
o|inlining procedure: k10884 
o|inlining procedure: k10917 
o|inlining procedure: k10917 
o|inlining procedure: "(c-backend.scm:1418) getsize2144" 
o|inlining procedure: "(c-backend.scm:1417) getbits2143" 
o|inlining procedure: "(c-backend.scm:1424) getbits2143" 
o|inlining procedure: "(c-backend.scm:1421) getsize2144" 
o|substituted constant variable: a11005 
o|substituted constant variable: a11006 
o|replaced variables: 2013 
o|removed binding forms: 596 
o|substituted constant variable: r270011046 
o|substituted constant variable: r270011046 
o|substituted constant variable: r270011048 
o|substituted constant variable: r270011048 
o|propagated global variable: r377711102 ##compiler#no-procedure-checks 
o|substituted constant variable: r378411104 
o|substituted constant variable: r385011109 
o|inlining procedure: k4064 
o|inlining procedure: k4190 
o|converted assignments to bindings: (pad0504) 
o|inlining procedure: k5188 
o|substituted constant variable: r524811173 
o|substituted constant variable: r524811173 
o|substituted constant variable: r524811175 
o|substituted constant variable: r524811175 
o|removed side-effect free assignment to unused variable: bad-literal95 
o|substituted constant variable: r572911199 
o|substituted constant variable: r583411207 
o|substituted constant variable: r584911214 
o|substituted constant variable: r595311229 
o|substituted constant variable: r595311229 
o|substituted constant variable: r595311231 
o|substituted constant variable: r595311231 
o|substituted constant variable: r642411253 
o|substituted constant variable: r642411253 
o|substituted constant variable: r642411255 
o|substituted constant variable: r642411255 
o|inlining procedure: k6435 
o|substituted constant variable: r645811258 
o|substituted constant variable: r645811258 
o|substituted constant variable: r645811260 
o|substituted constant variable: r645811260 
o|substituted constant variable: r646711262 
o|substituted constant variable: r659511271 
o|substituted constant variable: r668611280 
o|substituted constant variable: r673111286 
o|contracted procedure: "(c-backend.scm:804) g981988" 
o|substituted constant variable: r614911288 
o|substituted constant variable: r616111290 
o|substituted constant variable: r617311292 
o|substituted constant variable: r682711300 
o|substituted constant variable: r682711300 
o|substituted constant variable: r688711314 
o|substituted constant variable: r688711314 
o|substituted constant variable: r688711316 
o|substituted constant variable: r688711316 
o|substituted constant variable: r693111326 
o|substituted constant variable: r693111326 
o|substituted constant variable: r693111328 
o|substituted constant variable: r693111328 
o|inlining procedure: k7075 
o|inlining procedure: k7075 
o|substituted constant variable: r710411339 
o|substituted constant variable: r750811365 
o|substituted constant variable: r814911434 
o|substituted constant variable: r814911434 
o|substituted constant variable: r814911436 
o|substituted constant variable: r814911436 
o|substituted constant variable: r887711491 
o|substituted constant variable: r930911508 
o|substituted constant variable: r932411510 
o|substituted constant variable: r933911512 
o|substituted constant variable: r935111514 
o|substituted constant variable: r936911516 
o|substituted constant variable: r938111518 
o|substituted constant variable: r939311520 
o|substituted constant variable: r940811522 
o|substituted constant variable: r942011524 
o|substituted constant variable: r943211526 
o|substituted constant variable: r944411528 
o|substituted constant variable: r945611530 
o|substituted constant variable: r946811532 
o|substituted constant variable: r948011534 
o|substituted constant variable: r949211536 
o|substituted constant variable: r950411538 
o|substituted constant variable: r951611540 
o|substituted constant variable: r952811542 
o|substituted constant variable: r954011544 
o|substituted constant variable: r955511546 
o|substituted constant variable: r960311554 
o|substituted constant variable: r961511556 
o|substituted constant variable: r962711558 
o|substituted constant variable: r964611560 
o|substituted constant variable: r992411576 
o|substituted constant variable: r994211578 
o|substituted constant variable: r995711580 
o|substituted constant variable: r996911582 
o|substituted constant variable: r1023611594 
o|removed side-effect free assignment to unused variable: getbits2143 
o|removed side-effect free assignment to unused variable: getsize2144 
o|substituted constant variable: r1076811620 
o|substituted constant variable: r1079211622 
o|substituted constant variable: r1080411624 
o|simplifications: ((let . 1)) 
o|replaced variables: 34 
o|removed binding forms: 2018 
o|inlining procedure: k3596 
o|inlining procedure: k4011 
o|inlining procedure: k4097 
o|inlining procedure: k4602 
o|inlining procedure: k4681 
o|inlining procedure: k6576 
o|inlining procedure: k6640 
o|inlining procedure: k6715 
o|inlining procedure: k7059 
o|inlining procedure: k10945 
o|inlining procedure: k10953 
o|inlining procedure: k10993 
o|converted assignments to bindings: (encode-size2145) 
o|simplifications: ((let . 1)) 
o|replaced variables: 36 
o|removed binding forms: 136 
o|substituted constant variable: r664111862 
o|contracted procedure: k10956 
o|removed binding forms: 45 
o|removed conditional forms: 1 
o|removed binding forms: 2 
o|simplifications: ((if . 60) (##core#call . 838)) 
o|  call simplifications:
o|    eof-object?
o|    integer->char	9
o|    string	5
o|    list?	3
o|    fx>
o|    fx>=	3
o|    string=?
o|    char<?
o|    char>?
o|    char=?	2
o|    string-set!	3
o|    fx/
o|    void	2
o|    boolean?
o|    char?	2
o|    fixnum?	3
o|    string?	2
o|    number?	2
o|    symbol?	7
o|    ##sys#immediate?	4
o|    ##sys#generic-structure?
o|    ##sys#size	5
o|    negative?
o|    apply	13
o|    null?	5
o|    string-length	3
o|    arithmetic-shift	7
o|    >=	5
o|    string-ref	3
o|    bitwise-and	8
o|    -	8
o|    cons	5
o|    ##sys#setslot	4
o|    <	2
o|    length	9
o|    cdr	6
o|    cddr	3
o|    zero?	14
o|    not	12
o|    number->string	10
o|    third	7
o|    fourth	4
o|    ##sys#check-list	17
o|    +	23
o|    >	14
o|    add1	18
o|    sub1	9
o|    car	35
o|    cadr	21
o|    caddr	2
o|    vector?	6
o|    vector-ref	13
o|    first	34
o|    char->integer	4
o|    second	14
o|    pair?	46
o|    eq?	313
o|    ##sys#slot	80
o|contracted procedure: k2574 
o|contracted procedure: k2584 
o|contracted procedure: k2588 
o|contracted procedure: k2556 
o|contracted procedure: k2611 
o|contracted procedure: k2621 
o|contracted procedure: k2625 
o|contracted procedure: k2661 
o|contracted procedure: k2669 
o|contracted procedure: k2677 
o|contracted procedure: k2683 
o|contracted procedure: k2686 
o|contracted procedure: k2692 
o|contracted procedure: k2702 
o|contracted procedure: k2708 
o|contracted procedure: k2719 
o|contracted procedure: k2715 
o|contracted procedure: k2725 
o|contracted procedure: k2734 
o|contracted procedure: k2741 
o|contracted procedure: k2747 
o|contracted procedure: k2769 
o|contracted procedure: k2772 
o|contracted procedure: k2778 
o|contracted procedure: k2785 
o|contracted procedure: k2796 
o|contracted procedure: k2821 
o|contracted procedure: k2825 
o|contracted procedure: k2829 
o|contracted procedure: k2835 
o|contracted procedure: k2842 
o|contracted procedure: k2848 
o|contracted procedure: k2855 
o|contracted procedure: k2864 
o|contracted procedure: k2882 
o|contracted procedure: k2886 
o|contracted procedure: k2890 
o|contracted procedure: k2897 
o|contracted procedure: k2903 
o|contracted procedure: k2906 
o|contracted procedure: k2922 
o|contracted procedure: k2926 
o|contracted procedure: k2932 
o|contracted procedure: k2949 
o|contracted procedure: k2945 
o|contracted procedure: k2953 
o|contracted procedure: k2959 
o|contracted procedure: k2972 
o|contracted procedure: k2978 
o|contracted procedure: k2997 
o|contracted procedure: k3001 
o|contracted procedure: k3005 
o|contracted procedure: k3011 
o|contracted procedure: k3030 
o|contracted procedure: k3038 
o|contracted procedure: k3034 
o|contracted procedure: k3042 
o|contracted procedure: k3048 
o|contracted procedure: k3067 
o|contracted procedure: k3071 
o|contracted procedure: k3077 
o|contracted procedure: k3096 
o|contracted procedure: k3100 
o|contracted procedure: k3106 
o|contracted procedure: k3109 
o|contracted procedure: k3129 
o|contracted procedure: k3139 
o|contracted procedure: k3173 
o|contracted procedure: k3148 
o|contracted procedure: k3158 
o|contracted procedure: k3162 
o|contracted procedure: k3166 
o|contracted procedure: k3170 
o|contracted procedure: k3182 
o|contracted procedure: k3195 
o|contracted procedure: k3201 
o|contracted procedure: k3208 
o|contracted procedure: k3214 
o|contracted procedure: k3224 
o|contracted procedure: k3228 
o|contracted procedure: k3234 
o|contracted procedure: k3237 
o|contracted procedure: k3240 
o|contracted procedure: k3243 
o|contracted procedure: k3267 
o|contracted procedure: k3282 
o|contracted procedure: k3285 
o|contracted procedure: k3288 
o|contracted procedure: k3291 
o|contracted procedure: k3307 
o|contracted procedure: k3327 
o|contracted procedure: k3330 
o|contracted procedure: k3333 
o|contracted procedure: k3336 
o|contracted procedure: k3352 
o|contracted procedure: k3373 
o|contracted procedure: k3387 
o|contracted procedure: k3396 
o|contracted procedure: k3399 
o|contracted procedure: k3402 
o|contracted procedure: k3405 
o|contracted procedure: k3866 
o|contracted procedure: k3408 
o|contracted procedure: k3411 
o|contracted procedure: k3420 
o|contracted procedure: k3815 
o|contracted procedure: k3433 
o|contracted procedure: k3441 
o|contracted procedure: k3454 
o|contracted procedure: k3483 
o|contracted procedure: k3540 
o|contracted procedure: k3515 
o|contracted procedure: k3525 
o|contracted procedure: k3529 
o|contracted procedure: k3533 
o|contracted procedure: k3537 
o|contracted procedure: k3577 
o|contracted procedure: k3552 
o|contracted procedure: k3562 
o|contracted procedure: k3566 
o|contracted procedure: k3570 
o|contracted procedure: k3574 
o|contracted procedure: k3584 
o|contracted procedure: k3620 
o|contracted procedure: k3641 
o|contracted procedure: k3644 
o|contracted procedure: k3647 
o|contracted procedure: k3650 
o|contracted procedure: k3714 
o|contracted procedure: k3806 
o|contracted procedure: k3780 
o|contracted procedure: k3859 
o|contracted procedure: k3852 
o|contracted procedure: k3872 
o|contracted procedure: k3875 
o|contracted procedure: k3878 
o|contracted procedure: k3881 
o|contracted procedure: k3884 
o|contracted procedure: k3887 
o|contracted procedure: k3910 
o|contracted procedure: k3961 
o|contracted procedure: k3936 
o|contracted procedure: k3946 
o|contracted procedure: k3950 
o|contracted procedure: k3954 
o|contracted procedure: k3958 
o|contracted procedure: k3998 
o|contracted procedure: k3973 
o|contracted procedure: k3983 
o|contracted procedure: k3987 
o|contracted procedure: k3991 
o|contracted procedure: k3995 
o|contracted procedure: k4005 
o|contracted procedure: k4030 
o|contracted procedure: k4033 
o|contracted procedure: k4036 
o|contracted procedure: k4039 
o|contracted procedure: k4042 
o|contracted procedure: k4045 
o|contracted procedure: k4115 
o|contracted procedure: k4048 
o|contracted procedure: k4051 
o|contracted procedure: k4070 
o|contracted procedure: k4082 
o|contracted procedure: k4094 
o|contracted procedure: k4097 
o|contracted procedure: k4121 
o|contracted procedure: k4124 
o|contracted procedure: k4127 
o|contracted procedure: k4140 
o|contracted procedure: k4146 
o|contracted procedure: k4159 
o|contracted procedure: k4165 
o|contracted procedure: k4178 
o|contracted procedure: k4184 
o|contracted procedure: k4196 
o|contracted procedure: k4206 
o|contracted procedure: k4210 
o|contracted procedure: k4216 
o|contracted procedure: k4229 
o|contracted procedure: k4235 
o|contracted procedure: k4238 
o|contracted procedure: k4251 
o|contracted procedure: k4267 
o|contracted procedure: k4270 
o|contracted procedure: k4283 
o|contracted procedure: k4297 
o|contracted procedure: k4300 
o|contracted procedure: k4319 
o|contracted procedure: k4327 
o|contracted procedure: k4337 
o|contracted procedure: k4344 
o|contracted procedure: k4350 
o|contracted procedure: k4363 
o|contracted procedure: k4367 
o|contracted procedure: k4373 
o|contracted procedure: k4386 
o|contracted procedure: k4392 
o|contracted procedure: k4408 
o|contracted procedure: k4419 
o|contracted procedure: k4432 
o|contracted procedure: k4451 
o|contracted procedure: k4455 
o|contracted procedure: k4459 
o|contracted procedure: k4463 
o|contracted procedure: k4467 
o|contracted procedure: k4473 
o|contracted procedure: k4498 
o|contracted procedure: k4502 
o|contracted procedure: k4506 
o|contracted procedure: k4518 
o|contracted procedure: k4609 
o|contracted procedure: k4619 
o|contracted procedure: k460911822 
o|contracted procedure: k4634 
o|contracted procedure: k4648 
o|contracted procedure: k4651 
o|contracted procedure: k4654 
o|contracted procedure: k4657 
o|contracted procedure: k4660 
o|contracted procedure: k4690 
o|contracted procedure: k4710 
o|contracted procedure: k4720 
o|contracted procedure: k4724 
o|contracted procedure: k4740 
o|contracted procedure: k4781 
o|contracted procedure: k4784 
o|contracted procedure: k4795 
o|contracted procedure: k4807 
o|contracted procedure: k4815 
o|contracted procedure: k4839 
o|contracted procedure: k4850 
o|contracted procedure: k4871 
o|contracted procedure: k4877 
o|contracted procedure: k4896 
o|contracted procedure: k4929 
o|contracted procedure: k4925 
o|contracted procedure: k4902 
o|contracted procedure: k4911 
o|contracted procedure: k4921 
o|contracted procedure: k4938 
o|contracted procedure: k4948 
o|contracted procedure: k4956 
o|contracted procedure: k4952 
o|contracted procedure: k4960 
o|contracted procedure: k4971 
o|contracted procedure: k4964 
o|contracted procedure: k4975 
o|contracted procedure: k4978 
o|contracted procedure: k4991 
o|contracted procedure: k5001 
o|contracted procedure: k5005 
o|propagated global variable: g587589 ##compiler#used-units 
o|contracted procedure: k5054 
o|contracted procedure: k5066 
o|contracted procedure: k5076 
o|contracted procedure: k5080 
o|contracted procedure: k5037 
o|contracted procedure: k5047 
o|contracted procedure: k5051 
o|contracted procedure: k5121 
o|contracted procedure: k5129 
o|contracted procedure: k5135 
o|contracted procedure: k5182 
o|contracted procedure: k5178 
o|contracted procedure: k5206 
o|contracted procedure: k5216 
o|contracted procedure: k5266 
o|contracted procedure: k5275 
o|contracted procedure: k5285 
o|contracted procedure: k5289 
o|contracted procedure: k5292 
o|contracted procedure: k5300 
o|contracted procedure: k5308 
o|contracted procedure: k5334 
o|contracted procedure: k5343 
o|contracted procedure: k5353 
o|contracted procedure: k5357 
o|contracted procedure: k5416 
o|contracted procedure: k5432 
o|contracted procedure: k5436 
o|contracted procedure: k5470 
o|contracted procedure: k5479 
o|contracted procedure: k5488 
o|contracted procedure: k5500 
o|contracted procedure: k5510 
o|contracted procedure: k5514 
o|contracted procedure: k5523 
o|contracted procedure: k5533 
o|contracted procedure: k5537 
o|contracted procedure: k5546 
o|contracted procedure: k5556 
o|contracted procedure: k5560 
o|contracted procedure: k5642 
o|contracted procedure: k5645 
o|contracted procedure: k5659 
o|contracted procedure: k5681 
o|contracted procedure: k5691 
o|contracted procedure: k5697 
o|contracted procedure: k5737 
o|contracted procedure: k5743 
o|contracted procedure: k5749 
o|contracted procedure: k5755 
o|contracted procedure: k5776 
o|contracted procedure: k5783 
o|contracted procedure: k5803 
o|contracted procedure: k5806 
o|contracted procedure: k5817 
o|contracted procedure: k5829 
o|contracted procedure: k5842 
o|contracted procedure: k5865 
o|contracted procedure: k5871 
o|contracted procedure: k5874 
o|contracted procedure: k5881 
o|contracted procedure: k5890 
o|contracted procedure: k5897 
o|contracted procedure: k5901 
o|contracted procedure: k5909 
o|contracted procedure: k6044 
o|contracted procedure: k5936 
o|propagated global variable: r6045 ##sys#undefined-value 
o|contracted procedure: k5945 
o|contracted procedure: k5958 
o|contracted procedure: k5965 
o|contracted procedure: k5971 
o|contracted procedure: k5974 
o|contracted procedure: k5980 
o|contracted procedure: k5992 
o|contracted procedure: k6040 
o|contracted procedure: k5998 
o|contracted procedure: k6007 
o|contracted procedure: k6033 
o|contracted procedure: k6047 
o|contracted procedure: k6060 
o|contracted procedure: k6063 
o|contracted procedure: k6078 
o|contracted procedure: k6084 
o|contracted procedure: k6114 
o|contracted procedure: k6118 
o|contracted procedure: k6130 
o|contracted procedure: k6136 
o|contracted procedure: k6226 
o|contracted procedure: k6318 
o|contracted procedure: k6372 
o|contracted procedure: k6379 
o|contracted procedure: k6388 
o|contracted procedure: k6398 
o|contracted procedure: k6402 
o|contracted procedure: k6413 
o|contracted procedure: k6426 
o|contracted procedure: k6441 
o|contracted procedure: k6460 
o|contracted procedure: k6482 
o|contracted procedure: k6485 
o|contracted procedure: k6526 
o|contracted procedure: k6603 
o|contracted procedure: k6609 
o|contracted procedure: k6616 
o|contracted procedure: k6631 
o|contracted procedure: k6640 
o|contracted procedure: k6670 
o|contracted procedure: k6676 
o|contracted procedure: k6700 
o|contracted procedure: k6769 
o|contracted procedure: k6781 
o|contracted procedure: k6791 
o|contracted procedure: k6795 
o|contracted procedure: k6766 
o|contracted procedure: k6151 
o|contracted procedure: k6157 
o|contracted procedure: k6163 
o|contracted procedure: k6169 
o|contracted procedure: k6175 
o|contracted procedure: k6181 
o|contracted procedure: k6808 
o|contracted procedure: k6818 
o|contracted procedure: k6822 
o|contracted procedure: k6826 
o|contracted procedure: k6832 
o|contracted procedure: k6848 
o|contracted procedure: k6858 
o|contracted procedure: k6902 
o|contracted procedure: k6916 
o|contracted procedure: k6923 
o|contracted procedure: k6975 
o|contracted procedure: k7008 
o|contracted procedure: k7028 
o|contracted procedure: k7038 
o|contracted procedure: k7050 
o|contracted procedure: k7056 
o|contracted procedure: k7066 
o|contracted procedure: k7069 
o|contracted procedure: k706611872 
o|contracted procedure: k7091 
o|contracted procedure: k7100 
o|contracted procedure: k7121 
o|contracted procedure: k7106 
o|contracted procedure: k7117 
o|contracted procedure: k7113 
o|contracted procedure: k7184 
o|contracted procedure: k7196 
o|contracted procedure: k7206 
o|contracted procedure: k7210 
o|contracted procedure: k7164 
o|contracted procedure: k7167 
o|contracted procedure: k7170 
o|contracted procedure: k7177 
o|contracted procedure: k7227 
o|contracted procedure: k7239 
o|contracted procedure: k7249 
o|contracted procedure: k7253 
o|contracted procedure: k7270 
o|contracted procedure: k7369 
o|contracted procedure: k7435 
o|contracted procedure: k7459 
o|contracted procedure: k7481 
o|contracted procedure: k7485 
o|contracted procedure: k7489 
o|contracted procedure: k7493 
o|contracted procedure: k7497 
o|contracted procedure: k7501 
o|contracted procedure: k7504 
o|contracted procedure: k7510 
o|contracted procedure: k7542 
o|contracted procedure: k7549 
o|contracted procedure: k7561 
o|contracted procedure: k7571 
o|contracted procedure: k7575 
o|contracted procedure: k7595 
o|contracted procedure: k7607 
o|contracted procedure: k7616 
o|contracted procedure: k7628 
o|contracted procedure: k7640 
o|contracted procedure: k7664 
o|contracted procedure: k7661 
o|contracted procedure: k7676 
o|contracted procedure: k7683 
o|contracted procedure: k7695 
o|contracted procedure: k7702 
o|contracted procedure: k7707 
o|contracted procedure: k7713 
o|contracted procedure: k7719 
o|contracted procedure: k7725 
o|contracted procedure: k7731 
o|contracted procedure: k7737 
o|contracted procedure: k7743 
o|contracted procedure: k7770 
o|contracted procedure: k7776 
o|contracted procedure: k7782 
o|contracted procedure: k7788 
o|contracted procedure: k7807 
o|contracted procedure: k7813 
o|contracted procedure: k7819 
o|contracted procedure: k7838 
o|contracted procedure: k7844 
o|contracted procedure: k7850 
o|contracted procedure: k7856 
o|contracted procedure: k7862 
o|contracted procedure: k7868 
o|contracted procedure: k7874 
o|contracted procedure: k7880 
o|contracted procedure: k7886 
o|contracted procedure: k7892 
o|contracted procedure: k7898 
o|contracted procedure: k7904 
o|contracted procedure: k7910 
o|contracted procedure: k7916 
o|contracted procedure: k7957 
o|contracted procedure: k7963 
o|contracted procedure: k7969 
o|contracted procedure: k7975 
o|contracted procedure: k7981 
o|contracted procedure: k7987 
o|contracted procedure: k7993 
o|contracted procedure: k7999 
o|contracted procedure: k8005 
o|contracted procedure: k8011 
o|contracted procedure: k8017 
o|contracted procedure: k8094 
o|contracted procedure: k8100 
o|contracted procedure: k8141 
o|contracted procedure: k8116 
o|contracted procedure: k8126 
o|contracted procedure: k8130 
o|contracted procedure: k8134 
o|contracted procedure: k8138 
o|contracted procedure: k8151 
o|contracted procedure: k8161 
o|contracted procedure: k8173 
o|contracted procedure: k8183 
o|contracted procedure: k8187 
o|contracted procedure: k8205 
o|contracted procedure: k8229 
o|contracted procedure: k8242 
o|contracted procedure: k8246 
o|contracted procedure: k8269 
o|contracted procedure: k8278 
o|contracted procedure: k8281 
o|contracted procedure: k8290 
o|contracted procedure: k8293 
o|contracted procedure: k8302 
o|contracted procedure: k8305 
o|contracted procedure: k8314 
o|contracted procedure: k8317 
o|contracted procedure: k8326 
o|contracted procedure: k8338 
o|contracted procedure: k8347 
o|contracted procedure: k8350 
o|contracted procedure: k8359 
o|contracted procedure: k8368 
o|contracted procedure: k8377 
o|contracted procedure: k8386 
o|contracted procedure: k8395 
o|contracted procedure: k8404 
o|contracted procedure: k8413 
o|contracted procedure: k8422 
o|contracted procedure: k8425 
o|contracted procedure: k8434 
o|contracted procedure: k8446 
o|contracted procedure: k8449 
o|contracted procedure: k8455 
o|contracted procedure: k8467 
o|contracted procedure: k8470 
o|contracted procedure: k8479 
o|contracted procedure: k8482 
o|contracted procedure: k8491 
o|contracted procedure: k8494 
o|contracted procedure: k8503 
o|contracted procedure: k8506 
o|contracted procedure: k8515 
o|contracted procedure: k8518 
o|contracted procedure: k8527 
o|contracted procedure: k8530 
o|contracted procedure: k8539 
o|contracted procedure: k8542 
o|contracted procedure: k8551 
o|contracted procedure: k8554 
o|contracted procedure: k8563 
o|contracted procedure: k8575 
o|contracted procedure: k8587 
o|contracted procedure: k8608 
o|contracted procedure: k8605 
o|contracted procedure: k8620 
o|contracted procedure: k8629 
o|contracted procedure: k8643 
o|contracted procedure: k8660 
o|contracted procedure: k8694 
o|contracted procedure: k8697 
o|contracted procedure: k8709 
o|contracted procedure: k8712 
o|contracted procedure: k8723 
o|contracted procedure: k8735 
o|contracted procedure: k8739 
o|contracted procedure: k8756 
o|contracted procedure: k8773 
o|contracted procedure: k8790 
o|contracted procedure: k8807 
o|contracted procedure: k8824 
o|contracted procedure: k8841 
o|contracted procedure: k8850 
o|contracted procedure: k8853 
o|contracted procedure: k8926 
o|contracted procedure: k8859 
o|contracted procedure: k8885 
o|contracted procedure: k8897 
o|contracted procedure: k8900 
o|contracted procedure: k8911 
o|contracted procedure: k8923 
o|contracted procedure: k8879 
o|contracted procedure: k8935 
o|contracted procedure: k8942 
o|contracted procedure: k8947 
o|contracted procedure: k8954 
o|contracted procedure: k8959 
o|contracted procedure: k8963 
o|contracted procedure: k8969 
o|contracted procedure: k8976 
o|contracted procedure: k8981 
o|contracted procedure: k8988 
o|contracted procedure: k8993 
o|contracted procedure: k9000 
o|contracted procedure: k9005 
o|contracted procedure: k9012 
o|contracted procedure: k9017 
o|contracted procedure: k9024 
o|contracted procedure: k9029 
o|contracted procedure: k9036 
o|contracted procedure: k9041 
o|contracted procedure: k9045 
o|contracted procedure: k9054 
o|contracted procedure: k9062 
o|contracted procedure: k9068 
o|contracted procedure: k9085 
o|contracted procedure: k9091 
o|contracted procedure: k9097 
o|contracted procedure: k9172 
o|contracted procedure: k9178 
o|contracted procedure: k9202 
o|contracted procedure: k9208 
o|contracted procedure: k9255 
o|contracted procedure: k9311 
o|contracted procedure: k9317 
o|contracted procedure: k9320 
o|contracted procedure: k9326 
o|contracted procedure: k9335 
o|contracted procedure: k9341 
o|contracted procedure: k9347 
o|contracted procedure: k9353 
o|contracted procedure: k9362 
o|contracted procedure: k9365 
o|contracted procedure: k9371 
o|contracted procedure: k9377 
o|contracted procedure: k9383 
o|contracted procedure: k9389 
o|contracted procedure: k9395 
o|contracted procedure: k9398 
o|contracted procedure: k9404 
o|contracted procedure: k9410 
o|contracted procedure: k9416 
o|contracted procedure: k9422 
o|contracted procedure: k9428 
o|contracted procedure: k9434 
o|contracted procedure: k9440 
o|contracted procedure: k9446 
o|contracted procedure: k9452 
o|contracted procedure: k9458 
o|contracted procedure: k9464 
o|contracted procedure: k9470 
o|contracted procedure: k9476 
o|contracted procedure: k9482 
o|contracted procedure: k9488 
o|contracted procedure: k9494 
o|contracted procedure: k9500 
o|contracted procedure: k9506 
o|contracted procedure: k9512 
o|contracted procedure: k9518 
o|contracted procedure: k9524 
o|contracted procedure: k9530 
o|contracted procedure: k9536 
o|contracted procedure: k9542 
o|contracted procedure: k9548 
o|contracted procedure: k9557 
o|contracted procedure: k9566 
o|contracted procedure: k9584 
o|contracted procedure: k9581 
o|contracted procedure: k9599 
o|contracted procedure: k9605 
o|contracted procedure: k9611 
o|contracted procedure: k9617 
o|contracted procedure: k9623 
o|contracted procedure: k9629 
o|contracted procedure: k9635 
o|contracted procedure: k9642 
o|contracted procedure: k9648 
o|contracted procedure: k9654 
o|contracted procedure: k9665 
o|contracted procedure: k9671 
o|contracted procedure: k9678 
o|contracted procedure: k9705 
o|contracted procedure: k9714 
o|contracted procedure: k9722 
o|contracted procedure: k9728 
o|contracted procedure: k9734 
o|contracted procedure: k9753 
o|contracted procedure: k9759 
o|contracted procedure: k9846 
o|contracted procedure: k9867 
o|contracted procedure: k9873 
o|contracted procedure: k9879 
o|contracted procedure: k9885 
o|contracted procedure: k9926 
o|contracted procedure: k9929 
o|contracted procedure: k9935 
o|contracted procedure: k9938 
o|contracted procedure: k9944 
o|contracted procedure: k9947 
o|contracted procedure: k9953 
o|contracted procedure: k9959 
o|contracted procedure: k9965 
o|contracted procedure: k9971 
o|contracted procedure: k9977 
o|contracted procedure: k9980 
o|contracted procedure: k10004 
o|contracted procedure: k10028 
o|contracted procedure: k10055 
o|contracted procedure: k10079 
o|contracted procedure: k10082 
o|contracted procedure: k10106 
o|contracted procedure: k10109 
o|contracted procedure: k10133 
o|contracted procedure: k10157 
o|contracted procedure: k10160 
o|contracted procedure: k10184 
o|contracted procedure: k10208 
o|contracted procedure: k10232 
o|contracted procedure: k10238 
o|contracted procedure: k10241 
o|contracted procedure: k10259 
o|contracted procedure: k10256 
o|contracted procedure: k10274 
o|contracted procedure: k10280 
o|contracted procedure: k10283 
o|contracted procedure: k10307 
o|contracted procedure: k10331 
o|contracted procedure: k10355 
o|contracted procedure: k10379 
o|contracted procedure: k10403 
o|contracted procedure: k10410 
o|contracted procedure: k10416 
o|contracted procedure: k10419 
o|contracted procedure: k10443 
o|contracted procedure: k10467 
o|contracted procedure: k10522 
o|contracted procedure: k10531 
o|contracted procedure: k10575 
o|contracted procedure: k10581 
o|contracted procedure: k10587 
o|contracted procedure: k10593 
o|contracted procedure: k10599 
o|contracted procedure: k10605 
o|contracted procedure: k10611 
o|contracted procedure: k10617 
o|contracted procedure: k10623 
o|contracted procedure: k10629 
o|contracted procedure: k10744 
o|contracted procedure: k10740 
o|contracted procedure: k10716 
o|contracted procedure: k10736 
o|contracted procedure: k10732 
o|contracted procedure: k10720 
o|contracted procedure: k10728 
o|contracted procedure: k10724 
o|contracted procedure: k10754 
o|contracted procedure: k10764 
o|contracted procedure: k10770 
o|contracted procedure: k10776 
o|contracted procedure: k10788 
o|contracted procedure: k10794 
o|contracted procedure: k10800 
o|contracted procedure: k10997 
o|contracted procedure: k10806 
o|propagated global variable: r10998 ##sys#undefined-value 
o|contracted procedure: k10812 
o|contracted procedure: k10869 
o|contracted procedure: k10865 
o|contracted procedure: k10830 
o|contracted procedure: k10861 
o|contracted procedure: k10857 
o|contracted procedure: k10834 
o|contracted procedure: k10853 
o|contracted procedure: k10849 
o|contracted procedure: k10838 
o|contracted procedure: k10842 
o|contracted procedure: k10826 
o|contracted procedure: k10887 
o|contracted procedure: k10900 
o|contracted procedure: k10903 
o|contracted procedure: k10914 
o|contracted procedure: k10920 
o|contracted procedure: k10949 
o|contracted procedure: k10937 
o|contracted procedure: k10989 
o|contracted procedure: k10967 
o|contracted procedure: k10985 
o|simplifications: ((let . 91)) 
o|removed binding forms: 761 
o|inlining procedure: k4787 
o|inlining procedure: k4787 
o|inlining procedure: k5809 
o|inlining procedure: k5809 
o|inlining procedure: k7059 
o|inlining procedure: k7059 
o|inlining procedure: k7059 
o|inlining procedure: k8715 
o|inlining procedure: k8715 
o|inlining procedure: k8903 
o|inlining procedure: k8903 
o|inlining procedure: k10761 
o|inlining procedure: k10761 
o|inlining procedure: k10761 
o|inlining procedure: k10761 
o|inlining procedure: k10761 
o|replaced variables: 204 
o|inlining procedure: k6760 
o|inlining procedure: k6760 
o|inlining procedure: k6760 
o|inlining procedure: k6760 
o|inlining procedure: k6760 
o|inlining procedure: k6760 
o|substituted constant variable: r1076212395 
o|substituted constant variable: r1076212395 
o|substituted constant variable: r1076212399 
o|substituted constant variable: r1076212399 
o|substituted constant variable: r1076212403 
o|substituted constant variable: r1076212403 
o|substituted constant variable: r1076212407 
o|substituted constant variable: r1076212407 
o|substituted constant variable: r1076212411 
o|substituted constant variable: r1076212411 
o|simplifications: ((if . 8)) 
o|removed binding forms: 120 
o|substituted constant variable: r676112469 
o|substituted constant variable: r676112471 
o|substituted constant variable: r676112473 
o|substituted constant variable: r676112475 
o|substituted constant variable: r676112477 
o|substituted constant variable: r676112479 
o|replaced variables: 16 
o|removed binding forms: 10 
o|removed binding forms: 10 
o|direct leaf routine/allocation: encode-size2145 24 
o|contracted procedure: "(c-backend.scm:1391) k10784" 
o|contracted procedure: "(c-backend.scm:1410) k10910" 
o|contracted procedure: "(c-backend.scm:1418) k10941" 
o|contracted procedure: "(c-backend.scm:1425) k10971" 
o|removed binding forms: 4 
o|replaced variables: 5 
o|removed binding forms: 3 
o|customizable procedures: (k10031 k10271 err1820 g20212022 k9329 k9356 k9551 k9560 k9596 err1742 k8329 k8437 k8458 k8566 k8578 k8636 k8653 k8670 k8745 k8762 k8779 k8796 k8813 k8830 k8847 err1548 map-loop17151733 map-loop16671692 g16541655 str1549 g13201327 for-each-loop13191526 for-each-loop14941508 k7610 k7619 k7631 k7643 k7686 g14581459 g12141221 for-each-loop12131309 k7471 for-each-loop12411270 for-each-loop11901203 for-each-loop11661180 k7072 loop1137 header89 declarations91 prototypes92 trampolines93 procedures101 k6223 k6839 k6292 k6799 doloop972973 for-each-loop980991 k6724 k6664 k6585 literal-frame94 k6324 doloop10561057 expression88 doloop918919 k6087 string-like-substring99 k5921 k6010 gen-string-constant98 loop887 map-loop862879 gen-lit97 doloop835836 k5578 k5581 k5627 g776783 for-each-loop775791 for-each-loop798808 emitter723 for-each-loop815825 restore722 doloop725726 k5092 k5110 g636643 for-each-loop635646 k5197 for-each-loop695705 for-each-loop682712 for-each-loop580591 doloop602603 doloop607608 doloop596597 pad0504 map-loop514539 for-each-loop552563 doloop475476 g380388 for-each-loop379395 for-each-loop405419 k3417 find-lambda87 k3423 k3633 k3767 g272280 for-each-loop271287 for-each-loop297311 expr-args110 g183191 for-each-loop182198 loop143 expr109 for-each-loop4758 for-each-loop2738) 
o|calls to known targets: 834 
o|fast box initializations: 55 
o|dropping unused closure argument: f_10710 
o|dropping unused closure argument: f_4629 
o|dropping unused closure argument: f_6134 
o|dropping unused closure argument: f_5325 
*/
/* end of file */
