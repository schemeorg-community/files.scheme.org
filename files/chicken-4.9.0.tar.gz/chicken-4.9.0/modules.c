/* Generated from modules.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:38
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: modules.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file modules.c
   unit: modules
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[180];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,110,97,109,101,32,120,50,52,49,50,54,48,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,32,120,50,52,49,50,57,49,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,44),40,115,101,116,45,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,52,49,50,57,52,32,121,50,52,50,50,57,53,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,27),40,35,35,115,121,115,35,109,111,100,117,108,101,45,101,120,112,111,114,116,115,32,109,51,55,52,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,46),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,45,97,108,105,97,115,32,97,108,105,97,115,51,56,50,32,110,97,109,101,51,56,51,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,9),40,115,119,97,112,51,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,7),40,97,51,48,49,48,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,51,57,55,32,103,52,48,57,52,49,54,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,119,105,116,104,45,109,111,100,117,108,101,45,97,108,105,97,115,101,115,32,98,105,110,100,105,110,103,115,51,56,53,32,116,104,117,110,107,51,56,54,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,11),40,103,52,51,57,32,97,52,52,49,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,110,52,51,49,32,100,111,110,101,52,51,50,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,114,101,115,111,108,118,101,45,109,111,100,117,108,101,45,110,97,109,101,32,110,97,109,101,52,50,56,32,108,111,99,52,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,102,105,110,100,45,109,111,100,117,108,101,32,110,97,109,101,52,53,48,32,46,32,116,109,112,52,52,57,52,53,49,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,11),40,103,52,55,56,32,109,52,56,48,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,115,119,105,116,99,104,45,109,111,100,117,108,101,32,109,111,100,52,55,48,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,6),40,103,53,49,49,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,6),40,103,52,57,53,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,52,57,52,32,103,53,48,49,53,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,97,100,100,45,116,111,45,101,120,112,111,114,116,45,108,105,115,116,32,109,111,100,52,56,54,32,101,120,112,115,52,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,60),40,35,35,115,121,115,35,116,111,112,108,101,118,101,108,45,100,101,102,105,110,105,116,105,111,110,45,104,111,111,107,32,115,121,109,53,50,50,32,109,111,100,53,50,51,32,101,120,112,53,50,52,32,118,97,108,53,50,53,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,53,50,55,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,39),40,99,104,101,99,107,45,102,111,114,45,114,101,100,101,102,32,115,121,109,53,51,48,32,101,110,118,53,51,49,32,115,101,110,118,53,51,50,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,101,120,112,111,114,116,32,115,121,109,53,51,55,32,109,111,100,53,51,56,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,51),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,115,121,110,116,97,120,45,101,120,112,111,114,116,32,115,121,109,53,53,51,32,109,111,100,53,53,52,32,118,97,108,53,53,53,41,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,11),40,103,53,55,57,32,97,53,56,49,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,49),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,117,110,100,101,102,105,110,101,100,32,115,121,109,53,54,57,32,109,111,100,53,55,48,32,119,104,101,114,101,53,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,32,110,97,109,101,53,56,57,32,101,120,112,108,105,115,116,53,57,48,32,46,32,116,109,112,53,56,56,53,57,49,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,54,48,56,32,103,54,49,53,54,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,109,97,114,107,45,105,109,112,111,114,116,101,100,45,115,121,109,98,111,108,115,32,115,101,54,48,53,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,101,54,57,51,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,17),40,109,101,114,103,101,45,115,101,32,115,101,115,54,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,17),40,103,55,56,54,32,115,101,120,112,111,114,116,55,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,100,56,50,49,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,55,56,48,32,103,55,57,50,56,49,52,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,55,52,55,32,103,55,53,57,55,55,50,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,55,50,49,32,103,55,51,51,55,51,57,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,45,114,101,103,105,115,116,114,97,116,105,111,110,32,109,111,100,55,48,52,41,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,14),40,103,57,52,48,32,115,101,120,112,57,52,57,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,14),40,103,57,54,49,32,105,101,120,112,57,55,48,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,14),40,103,57,56,50,32,110,101,120,112,57,57,49,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,57,56,49,32,103,57,56,56,57,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,57,54,48,32,103,57,54,55,57,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,57,51,57,32,103,57,52,54,57,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,57,49,48,32,103,57,50,50,57,50,57,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,56,56,50,32,103,56,57,52,57,48,49,41,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,56,53,52,32,103,56,54,54,56,55,51,41,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,88),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,32,110,97,109,101,56,51,55,32,105,101,120,112,111,114,116,115,56,51,56,32,118,101,120,112,111,114,116,115,56,51,57,32,115,101,120,112,111,114,116,115,56,52,48,32,46,32,116,109,112,56,51,54,56,52,49,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,112,114,105,109,105,116,105,118,101,45,97,108,105,97,115,32,115,121,109,49,48,48,55,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,14),40,103,49,48,54,54,32,115,101,49,48,55,55,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,54,48,32,103,49,48,55,50,49,48,56,50,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,51,51,32,103,49,48,52,53,49,48,53,50,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,69),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,105,109,105,116,105,118,101,45,109,111,100,117,108,101,32,110,97,109,101,49,48,50,49,32,118,101,120,112,111,114,116,115,49,48,50,50,32,46,32,116,109,112,49,48,50,48,49,48,50,51,41,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,49,48,57,54,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,102,105,110,100,45,101,120,112,111,114,116,32,115,121,109,49,48,57,49,32,109,111,100,49,48,57,50,32,105,110,100,105,114,101,99,116,49,48,57,51,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,13),40,103,49,50,50,54,32,97,49,50,51,53,41,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,50,50,53,32,103,49,50,51,50,49,50,51,57,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,15),40,103,49,49,57,53,32,115,121,109,49,50,48,52,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,49,57,52,32,103,49,50,48,49,49,50,48,55,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,13),40,103,49,49,55,57,32,117,49,49,56,56,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,103,49,50,57,52,32,109,49,51,48,51,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,50,57,51,32,103,49,51,48,48,49,51,48,57,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,50,53,56,32,103,49,50,55,48,49,50,56,52,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,19),40,119,97,114,110,32,109,115,103,54,52,57,32,105,100,54,53,48,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,11),40,103,54,54,54,32,97,54,54,56,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,11),40,103,54,55,51,32,97,54,55,53,41,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,50,32,105,101,120,112,111,114,116,115,54,53,56,41,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,101,120,112,111,114,116,115,54,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,49,55,56,32,103,49,49,56,53,49,50,53,49,41,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,49,49,53,57,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,49,49,53,49,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,50,52,32,103,49,49,51,54,49,49,52,51,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,110,97,108,105,122,101,45,109,111,100,117,108,101,32,109,111,100,49,49,49,53,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,10),40,115,119,97,112,49,51,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,7),40,97,53,55,55,48,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,7),40,97,53,55,55,53,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,7),40,97,53,55,56,49,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,7),40,97,53,55,54,52,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,52),40,35,35,115,121,115,35,102,105,110,100,45,109,111,100,117,108,101,47,105,109,112,111,114,116,45,108,105,98,114,97,114,121,32,109,110,97,109,101,49,51,50,53,32,108,111,99,49,51,50,54,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,17),40,114,101,115,111,108,118,101,32,115,121,109,49,52,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,116,111,115,116,114,32,120,49,52,48,55,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,110,97,109,101,32,115,112,101,99,49,52,49,50,41,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,7),40,97,53,57,52,51,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,13),40,103,49,52,56,49,32,97,49,52,56,51,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,13),40,103,49,52,56,53,32,97,49,52,56,55,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,105,100,115,49,52,55,50,32,118,49,52,55,51,32,115,49,52,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,52,52,55,32,103,49,52,53,57,49,52,54,53,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,115,49,53,50,53,32,115,49,53,50,54,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,118,49,53,49,56,32,118,49,53,49,57,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,52,57,51,32,103,49,53,48,53,49,53,49,49,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,53,53,50,32,103,49,53,53,57,49,53,54,52,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,13),40,103,49,53,55,48,32,97,49,53,55,50,41,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,13),40,103,49,53,55,52,32,97,49,53,55,54,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,105,109,112,118,49,53,51,53,32,105,109,112,115,49,53,51,54,32,118,49,53,51,55,32,115,49,53,51,56,32,105,100,115,49,53,51,57,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,13),40,114,101,110,32,105,109,112,49,53,56,49,41,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,54,49,48,32,103,49,54,50,50,49,54,50,56,41};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,53,56,52,32,103,49,53,57,54,49,54,48,50,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,58),40,97,53,57,53,51,32,105,109,112,118,49,52,50,56,49,52,50,57,49,52,51,52,32,105,109,112,115,49,52,51,48,49,52,51,49,49,52,51,53,32,105,109,112,105,49,52,51,50,49,52,51,51,49,52,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,115,112,101,99,32,115,112,101,99,49,52,49,55,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,7),40,97,54,53,54,52,41,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,15),40,103,49,54,55,50,32,105,109,112,49,54,56,49,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,15),40,103,49,54,57,57,32,105,109,112,49,55,48,56,41,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,55,52,56,32,103,49,55,54,48,49,55,54,54,41};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,55,50,50,32,103,49,55,51,52,49,55,52,48,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,56,48,50,32,103,49,56,49,52,49,56,50,48,41};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,55,55,54,32,103,49,55,56,56,49,55,57,52,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,54,57,56,32,103,49,55,48,53,49,55,49,49,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,54,55,49,32,103,49,54,55,56,49,54,57,50,41,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,55),40,97,54,53,55,48,32,118,115,118,49,54,53,48,49,54,53,49,49,54,53,54,32,118,115,115,49,54,53,50,49,54,53,51,49,54,53,55,32,118,115,105,49,54,53,52,49,54,53,53,49,54,53,56,41,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,16),40,103,49,54,52,48,32,115,112,101,99,49,54,52,57,41};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,54,51,57,32,103,49,54,52,54,49,56,52,52,41,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,97),40,35,35,115,121,115,35,101,120,112,97,110,100,45,105,109,112,111,114,116,32,120,49,51,56,54,32,114,49,51,56,55,32,99,49,51,56,56,32,105,109,112,111,114,116,45,101,110,118,49,51,56,57,32,109,97,99,114,111,45,101,110,118,49,51,57,48,32,109,101,116,97,63,49,51,57,49,32,114,101,101,120,112,63,49,51,57,50,32,108,111,99,49,51,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,109,111,100,117,108,101,45,114,101,110,97,109,101,32,115,121,109,49,56,53,54,32,112,114,101,102,105,120,49,56,53,55,41};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,15),40,103,49,56,55,53,32,109,111,100,49,56,55,55,41,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,17),40,109,114,101,110,97,109,101,32,115,121,109,49,56,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,13),40,103,49,57,48,51,32,97,49,57,48,53,41,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,97,108,105,97,115,45,103,108,111,98,97,108,45,104,111,111,107,32,115,121,109,49,56,53,57,32,97,115,115,105,103,110,49,56,54,48,32,119,104,101,114,101,49,56,54,49,41,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,105,110,116,101,114,102,97,99,101,32,110,97,109,101,49,57,49,57,32,101,120,112,115,49,57,50,48,41,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,14),40,101,114,114,32,97,114,103,115,49,57,51,53,41,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,16),40,105,102,97,99,101,32,110,97,109,101,49,57,51,54,41};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,50,32,108,115,116,49,57,53,55,41,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,120,112,115,49,57,52,53,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,118,97,108,105,100,97,116,101,45,101,120,112,111,114,116,115,32,101,120,112,115,49,57,50,55,32,108,111,99,49,57,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,62),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,102,117,110,99,116,111,114,32,110,97,109,101,49,57,54,55,32,102,97,114,103,115,49,57,54,56,32,102,101,120,112,115,49,57,54,57,32,98,111,100,121,49,57,55,48,41,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,14),40,101,114,114,32,97,114,103,115,49,57,56,54,41,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,57,57,54,32,103,50,48,48,56,50,48,49,52,41};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,6),40,109,101,114,114,41,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,97,115,50,48,50,49,32,102,97,115,50,48,50,50,41,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,55),40,35,35,115,121,115,35,105,110,115,116,97,110,116,105,97,116,101,45,102,117,110,99,116,111,114,32,110,97,109,101,49,57,55,55,32,102,110,97,109,101,49,57,55,56,32,97,114,103,115,49,57,55,57,41,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,15),40,103,50,48,52,55,32,101,120,112,50,48,53,54,41,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,48,54,53,32,103,50,48,55,55,50,48,56,52,41};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,50,48,52,54,32,103,50,48,53,51,50,48,53,57,41,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,78),40,35,35,115,121,115,35,109,97,116,99,104,45,102,117,110,99,116,111,114,45,97,114,103,117,109,101,110,116,32,97,108,105,97,115,50,48,51,55,32,110,97,109,101,50,48,51,56,32,109,110,97,109,101,50,48,51,57,32,101,120,112,115,50,48,52,48,32,102,110,97,109,101,50,48,52,49,41,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,44),40,109,111,100,117,108,101,45,101,110,118,105,114,111,110,109,101,110,116,32,109,110,97,109,101,50,49,48,50,32,46,32,116,109,112,50,49,48,49,50,49,48,51,41,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3510)
static void C_ccall f_3510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3529)
static void C_ccall f_3529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_fcall f_4973(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_fcall f_3973(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_fcall f_3988(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6439)
static void C_fcall f_6439(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6636)
static void C_fcall f_6636(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4914)
static void C_fcall f_4914(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6635)
static void C_ccall f_6635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5703)
static void C_ccall f_5703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6412)
static void C_ccall f_6412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3769)
static void C_fcall f_3769(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7628)
static void C_ccall f_7628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7602)
static void C_fcall f_7602(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4569)
static void C_fcall f_4569(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4543)
static void C_fcall f_4543(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4340)
static void C_fcall f_4340(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5809)
static void C_ccall f_5809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7426)
static void C_ccall f_7426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_fcall f_3792(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7434)
static void C_fcall f_7434(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4162)
static void C_fcall f_4162(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3550)
static void C_fcall f_3550(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_fcall f_3543(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_fcall f_5435(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4938)
static void C_fcall f_4938(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_fcall f_5869(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5251)
static void C_fcall f_5251(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_fcall f_5263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_fcall f_5473(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5891)
static void C_fcall f_5891(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5483)
static void C_ccall f_5483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_fcall f_4750(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4785)
static void C_fcall f_4785(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6776)
static void C_ccall f_6776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6768)
static void C_ccall f_6768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6718)
static void C_ccall f_6718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6917)
static void C_fcall f_6917(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_fcall f_4715(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5654)
static void C_ccall f_5654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6706)
static void C_ccall f_6706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6731)
static void C_ccall f_6731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7707)
static void C_fcall f_7707(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7701)
static void C_ccall f_7701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5826)
static void C_fcall f_5826(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5667)
static void C_fcall f_5667(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5296)
static void C_ccall f_5296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6177)
static void C_fcall f_6177(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5632)
static void C_fcall f_5632(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7747)
static void C_ccall f_7747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7741)
static void C_ccall f_7741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7744)
static void C_ccall f_7744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_fcall f_6782(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5055)
static void C_fcall f_5055(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7759)
static void C_ccall f_7759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7158)
static void C_fcall f_7158(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7192)
static void C_ccall f_7192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7197)
static void C_ccall f_7197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6558)
static void C_ccall f_6558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_fcall f_6559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6113)
static void C_fcall f_6113(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7354)
static void C_fcall f_7354(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6958)
static void C_fcall f_6958(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6598)
static void C_fcall f_6598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5404)
static void C_fcall f_5404(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6981)
static void C_fcall f_6981(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6585)
static void C_fcall f_6585(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7105)
static void C_ccall f_7105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6101)
static void C_fcall f_6101(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7124)
static void C_ccall f_7124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7571)
static void C_ccall f_7571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_modules_toplevel)
C_externexport void C_ccall C_modules_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7582)
static void C_ccall f_7582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4108)
static void C_fcall f_4108(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7327)
static void C_fcall f_7327(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7595)
static void C_ccall f_7595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7591)
static void C_ccall f_7591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7779)
static void C_ccall f_7779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4320)
static void C_fcall f_4320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5218)
static void C_fcall f_5218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_fcall f_3082(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_fcall f_3090(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_fcall f_5027(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5025)
static void C_fcall f_5025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_fcall f_3864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4291)
static void C_fcall f_4291(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_fcall f_3896(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3654)
static void C_fcall f_3654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4603)
static void C_fcall f_4603(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3041)
static void C_fcall f_3041(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_fcall f_3285(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6338)
static void C_fcall f_6338(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7313)
static void C_ccall f_7313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static C_word C_fcall f_3251(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3819)
static void C_fcall f_3819(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static C_word C_fcall f_3243(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_fcall f_4092(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7512)
static void C_ccall f_7512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5910)
static void C_fcall f_5910(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5919)
static void C_fcall f_5919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_fcall f_5500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5722)
static void C_ccall f_5722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5726)
static void C_ccall f_5726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7533)
static void C_fcall f_7533(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3690)
static void C_fcall f_3690(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4048)
static void C_fcall f_4048(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_fcall f_5341(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_fcall f_4056(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_fcall f_4638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_fcall f_5199(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6817)
static void C_fcall f_6817(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5995)
static void C_fcall f_5995(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5369)
static void C_ccall f_5369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_fcall f_4684(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6854)
static void C_ccall f_6854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5978)
static void C_fcall f_5978(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4661)
static void C_fcall f_4661(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5944)
static void C_ccall f_5944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5792)
static void C_ccall f_5792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_6699)
static void C_ccall f_6699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5954)
static void C_ccall f_5954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_fcall f_5547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5763)
static void C_ccall f_5763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5926)
static void C_ccall f_5926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5771)
static void C_ccall f_5771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5747)
static void C_ccall f_5747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6045)
static void C_fcall f_6045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5754)
static void C_ccall f_5754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5751)
static void C_ccall f_5751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_fcall f_3856(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_fcall f_6257(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5559)
static void C_fcall f_5559(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5531)
static void C_fcall f_5531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6087)
static void C_ccall f_6087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6084)
static void C_ccall f_6084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6681)
static void C_fcall f_6681(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_ccall f_6684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7255)
static void C_fcall f_7255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6285)
static void C_fcall f_6285(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6672)
static void C_ccall f_6672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7653)
static void C_ccall f_7653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f8231)
static void C_ccall f8231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5583)
static void C_ccall f_5583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7013)
static void C_fcall f_7013(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6228)
static void C_fcall f_6228(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_fcall f_6017(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7664)
static void C_ccall f_7664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_ccall f_7470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_fcall f_4204(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7472)
static void C_fcall f_7472(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6219)
static void C_ccall f_6219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6216)
static void C_ccall f_6216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7287)
static void C_ccall f_7287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7672)
static void C_fcall f_7672(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7670)
static void C_ccall f_7670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7441)
static void C_ccall f_7441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5337)
static void C_ccall f_5337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7645)
static void C_ccall f_7645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7649)
static void C_ccall f_7649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7451)
static void C_fcall f_7451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6474)
static void C_fcall f_6474(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6882)
static void C_fcall f_6882(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6876)
static void C_ccall f_6876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_fcall f_3208(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7214)
static void C_fcall f_7214(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7090)
static void C_fcall f_7090(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7098)
static void C_fcall f_7098(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7612)
static void C_ccall f_7612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7208)
static void C_fcall f_7208(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7044)
static void C_ccall f_7044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_fcall f_5134(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_fcall f_3186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_4973)
static void C_fcall trf_4973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4973(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4973(t0,t1,t2);}

C_noret_decl(trf_3973)
static void C_fcall trf_3973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3973(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3973(t0,t1);}

C_noret_decl(trf_3988)
static void C_fcall trf_3988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3988(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3988(t0,t1,t2);}

C_noret_decl(trf_6439)
static void C_fcall trf_6439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6439(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6439(t0,t1,t2);}

C_noret_decl(trf_6636)
static void C_fcall trf_6636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6636(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6636(t0,t1,t2);}

C_noret_decl(trf_4914)
static void C_fcall trf_4914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4914(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4914(t0,t1,t2);}

C_noret_decl(trf_3769)
static void C_fcall trf_3769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3769(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3769(t0,t1,t2,t3);}

C_noret_decl(trf_7602)
static void C_fcall trf_7602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7602(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7602(t0,t1,t2);}

C_noret_decl(trf_4569)
static void C_fcall trf_4569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4569(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4569(t0,t1,t2);}

C_noret_decl(trf_4543)
static void C_fcall trf_4543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4543(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4543(t0,t1,t2);}

C_noret_decl(trf_4340)
static void C_fcall trf_4340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4340(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4340(t0,t1,t2);}

C_noret_decl(trf_3792)
static void C_fcall trf_3792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3792(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3792(t0,t1,t2);}

C_noret_decl(trf_7434)
static void C_fcall trf_7434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7434(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7434(t0,t1,t2);}

C_noret_decl(trf_4162)
static void C_fcall trf_4162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4162(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4162(t0,t1,t2);}

C_noret_decl(trf_3550)
static void C_fcall trf_3550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3550(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3550(t0,t1);}

C_noret_decl(trf_3543)
static void C_fcall trf_3543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3543(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3543(t0,t1,t2);}

C_noret_decl(trf_5435)
static void C_fcall trf_5435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5435(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5435(t0,t1,t2);}

C_noret_decl(trf_4938)
static void C_fcall trf_4938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4938(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4938(t0,t1,t2);}

C_noret_decl(trf_5869)
static void C_fcall trf_5869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5869(t0,t1);}

C_noret_decl(trf_5251)
static void C_fcall trf_5251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5251(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5251(t0,t1,t2);}

C_noret_decl(trf_5263)
static void C_fcall trf_5263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5263(t0,t1,t2);}

C_noret_decl(trf_5473)
static void C_fcall trf_5473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5473(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5473(t0,t1,t2);}

C_noret_decl(trf_5891)
static void C_fcall trf_5891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5891(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5891(t0,t1,t2);}

C_noret_decl(trf_4750)
static void C_fcall trf_4750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4750(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4750(t0,t1,t2);}

C_noret_decl(trf_4785)
static void C_fcall trf_4785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4785(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4785(t0,t1,t2);}

C_noret_decl(trf_6917)
static void C_fcall trf_6917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6917(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6917(t0,t1,t2);}

C_noret_decl(trf_4715)
static void C_fcall trf_4715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4715(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4715(t0,t1,t2);}

C_noret_decl(trf_7707)
static void C_fcall trf_7707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7707(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7707(t0,t1,t2);}

C_noret_decl(trf_5826)
static void C_fcall trf_5826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5826(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5826(t0,t1,t2);}

C_noret_decl(trf_5667)
static void C_fcall trf_5667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5667(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5667(t0,t1,t2);}

C_noret_decl(trf_6177)
static void C_fcall trf_6177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6177(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6177(t0,t1,t2);}

C_noret_decl(trf_5632)
static void C_fcall trf_5632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5632(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5632(t0,t1,t2);}

C_noret_decl(trf_6782)
static void C_fcall trf_6782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6782(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6782(t0,t1,t2);}

C_noret_decl(trf_5055)
static void C_fcall trf_5055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5055(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5055(t0,t1);}

C_noret_decl(trf_7158)
static void C_fcall trf_7158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7158(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7158(t0,t1,t2);}

C_noret_decl(trf_6559)
static void C_fcall trf_6559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6559(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6559(t0,t1,t2);}

C_noret_decl(trf_6113)
static void C_fcall trf_6113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6113(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6113(t0,t1,t2,t3);}

C_noret_decl(trf_7354)
static void C_fcall trf_7354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7354(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7354(t0,t1,t2);}

C_noret_decl(trf_6958)
static void C_fcall trf_6958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6958(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6958(t0,t1,t2);}

C_noret_decl(trf_6598)
static void C_fcall trf_6598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6598(t0,t1);}

C_noret_decl(trf_5404)
static void C_fcall trf_5404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5404(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5404(t0,t1,t2);}

C_noret_decl(trf_6981)
static void C_fcall trf_6981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6981(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6981(t0,t1,t2);}

C_noret_decl(trf_6585)
static void C_fcall trf_6585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6585(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6585(t0,t1,t2);}

C_noret_decl(trf_6101)
static void C_fcall trf_6101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6101(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6101(t0,t1,t2,t3);}

C_noret_decl(trf_4108)
static void C_fcall trf_4108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4108(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4108(t0,t1,t2);}

C_noret_decl(trf_7327)
static void C_fcall trf_7327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7327(t0,t1);}

C_noret_decl(trf_4320)
static void C_fcall trf_4320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4320(t0,t1);}

C_noret_decl(trf_5218)
static void C_fcall trf_5218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5218(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5218(t0,t1,t2);}

C_noret_decl(trf_3082)
static void C_fcall trf_3082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3082(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3082(t0,t1,t2,t3);}

C_noret_decl(trf_3090)
static void C_fcall trf_3090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3090(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3090(t0,t1,t2);}

C_noret_decl(trf_5027)
static void C_fcall trf_5027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5027(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5027(t0,t1,t2);}

C_noret_decl(trf_5025)
static void C_fcall trf_5025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5025(t0,t1);}

C_noret_decl(trf_3864)
static void C_fcall trf_3864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3864(t0,t1);}

C_noret_decl(trf_4291)
static void C_fcall trf_4291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4291(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4291(t0,t1,t2);}

C_noret_decl(trf_3896)
static void C_fcall trf_3896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3896(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3896(t0,t1,t2);}

C_noret_decl(trf_3654)
static void C_fcall trf_3654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3654(t0,t1);}

C_noret_decl(trf_4603)
static void C_fcall trf_4603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4603(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4603(t0,t1,t2);}

C_noret_decl(trf_3041)
static void C_fcall trf_3041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3041(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3041(t0,t1,t2);}

C_noret_decl(trf_3285)
static void C_fcall trf_3285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3285(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3285(t0,t1,t2);}

C_noret_decl(trf_6338)
static void C_fcall trf_6338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6338(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6338(t0,t1,t2);}

C_noret_decl(trf_3819)
static void C_fcall trf_3819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3819(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3819(t0,t1,t2);}

C_noret_decl(trf_4092)
static void C_fcall trf_4092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4092(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4092(t0,t1);}

C_noret_decl(trf_5910)
static void C_fcall trf_5910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5910(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5910(t0,t1);}

C_noret_decl(trf_5919)
static void C_fcall trf_5919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5919(t0,t1);}

C_noret_decl(trf_5500)
static void C_fcall trf_5500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5500(t0,t1,t2);}

C_noret_decl(trf_7533)
static void C_fcall trf_7533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7533(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7533(t0,t1,t2,t3);}

C_noret_decl(trf_3690)
static void C_fcall trf_3690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3690(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3690(t0,t1,t2);}

C_noret_decl(trf_4048)
static void C_fcall trf_4048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4048(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4048(t0,t1);}

C_noret_decl(trf_5341)
static void C_fcall trf_5341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5341(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5341(t0,t1,t2);}

C_noret_decl(trf_4056)
static void C_fcall trf_4056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4056(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4056(t0,t1);}

C_noret_decl(trf_4638)
static void C_fcall trf_4638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4638(t0,t1,t2);}

C_noret_decl(trf_5199)
static void C_fcall trf_5199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5199(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5199(t0,t1,t2);}

C_noret_decl(trf_6817)
static void C_fcall trf_6817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6817(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6817(t0,t1,t2);}

C_noret_decl(trf_5995)
static void C_fcall trf_5995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5995(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5995(t0,t1,t2);}

C_noret_decl(trf_4684)
static void C_fcall trf_4684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4684(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4684(t0,t1,t2);}

C_noret_decl(trf_5978)
static void C_fcall trf_5978(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5978(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5978(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4661)
static void C_fcall trf_4661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4661(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4661(t0,t1,t2);}

C_noret_decl(trf_5547)
static void C_fcall trf_5547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5547(t0,t1);}

C_noret_decl(trf_6045)
static void C_fcall trf_6045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6045(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6045(t0,t1,t2);}

C_noret_decl(trf_3856)
static void C_fcall trf_3856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3856(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3856(t0,t1,t2);}

C_noret_decl(trf_6257)
static void C_fcall trf_6257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6257(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6257(t0,t1,t2);}

C_noret_decl(trf_5559)
static void C_fcall trf_5559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5559(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5559(t0,t1);}

C_noret_decl(trf_5531)
static void C_fcall trf_5531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5531(t0,t1);}

C_noret_decl(trf_6681)
static void C_fcall trf_6681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6681(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6681(t0,t1);}

C_noret_decl(trf_7255)
static void C_fcall trf_7255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7255(t0,t1,t2);}

C_noret_decl(trf_6285)
static void C_fcall trf_6285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6285(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6285(t0,t1,t2);}

C_noret_decl(trf_7013)
static void C_fcall trf_7013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7013(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7013(t0,t1,t2);}

C_noret_decl(trf_6228)
static void C_fcall trf_6228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6228(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6228(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6017)
static void C_fcall trf_6017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6017(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6017(t0,t1,t2);}

C_noret_decl(trf_4204)
static void C_fcall trf_4204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4204(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4204(t0,t1,t2);}

C_noret_decl(trf_7472)
static void C_fcall trf_7472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7472(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7472(t0,t1,t2);}

C_noret_decl(trf_7672)
static void C_fcall trf_7672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7672(t0,t1,t2);}

C_noret_decl(trf_7451)
static void C_fcall trf_7451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7451(t0,t1);}

C_noret_decl(trf_6474)
static void C_fcall trf_6474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6474(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6474(t0,t1,t2);}

C_noret_decl(trf_6882)
static void C_fcall trf_6882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6882(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6882(t0,t1,t2);}

C_noret_decl(trf_3208)
static void C_fcall trf_3208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3208(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3208(t0,t1,t2);}

C_noret_decl(trf_7214)
static void C_fcall trf_7214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7214(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7214(t0,t1,t2);}

C_noret_decl(trf_7090)
static void C_fcall trf_7090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7090(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7090(t0,t1,t2);}

C_noret_decl(trf_7098)
static void C_fcall trf_7098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7098(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7098(t0,t1,t2);}

C_noret_decl(trf_7208)
static void C_fcall trf_7208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7208(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7208(t0,t1,t2);}

C_noret_decl(trf_5134)
static void C_fcall trf_5134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5134(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5134(t0,t1,t2);}

C_noret_decl(trf_3186)
static void C_fcall trf_3186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3186(t0,t1);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* k3187 in k3184 in k3181 in k3178 in k3222 in k3218 in switch-module in k2708 in k2704 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:159: ##sys#current-module */
t2=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3508 in k3465 in k3459 in k3456 in register-syntax-export in k2708 in k2704 */
static void C_ccall f_3510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3510,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:216: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t3);}

/* k4965 in map-loop1060 in k4910 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4967,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4938(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4938(t6,((C_word*)t0)[5],t5);}}

/* ##sys#register-undefined in k2708 in k2704 */
static void C_ccall f_3529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3529,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3536,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:229: module-undefined-list */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k3512 in k3508 in k3465 in k3459 in k3456 in register-syntax-export in k2708 in k2704 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:216: check-for-redef */
t2=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* map-loop1033 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_fcall f_4973(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4973,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5002,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
if(C_truep(C_i_symbolp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4906,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:405: ##sys#primitive-alias */
t8=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}
else{
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##sys#register-module-alias in k2708 in k2704 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2974,4,t0,t1,t2,t3);}
t4=C_a_i_cons(&a,2,t2,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2990,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:122: ##sys#module-alias-environment */
t7=*((C_word*)lf[1]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k6404 in ren in k6394 in k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6406,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t1,t3));}

/* merge-se in k2708 in k2704 */
static void C_fcall f_3973(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3973,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3977,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,*((C_word*)lf[17]+1),t2);}

/* k6428 in k6394 in k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6430,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t0)[2];
t8=C_i_check_list_2(((C_word*)t0)[3],lf[16]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6437,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6439,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,a[6]=((C_word)li94),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_6439(t13,t9,((C_word*)t0)[3]);}

/* loop in k3975 in merge-se in k2708 in k2704 */
static void C_fcall f_3988(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3988,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_caar(t2);
t4=t2;
t5=C_u_i_cdr(t4);
if(C_truep(C_i_assq(t3,t5))){
t6=t2;
t7=C_u_i_cdr(t6);
/* modules.scm:301: loop */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}
else{
t6=t2;
t7=C_u_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4015,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=t2;
t10=C_u_i_cdr(t9);
/* modules.scm:302: loop */
t14=t8;
t15=t10;
t1=t14;
t2=t15;
goto loop;}}}

/* map-loop1610 in k6428 in k6394 in k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6439(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6439,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6468,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:668: g1616 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6435 in k6428 in k6394 in k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:668: values */
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k3975 in merge-se in k2708 in k2704 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3988,a[2]=t3,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3988(t5,((C_word*)t0)[2],t1);}

/* g1699 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6636(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6636,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6672,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:702: macro-env */
t6=((C_word*)t0)[2];
((C_proc2)C_fast_retrieve_proc(t6))(2,t6,t5);}

/* g1066 in k4910 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_fcall f_4914(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4914,NULL,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=C_i_assq(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* modules.scm:411: ##sys#error */
t4=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[73],t2,((C_word*)t0)[3]);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6636,a[2]=((C_word*)t0)[2],a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(((C_word*)t0)[3],lf[30]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6958,a[2]=t6,a[3]=t2,a[4]=((C_word)li105),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_6958(t8,t4,((C_word*)t0)[3]);}

/* k4910 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4912,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li48),tmp=(C_word)a,a+=5,tmp);
t8=C_i_check_list_2(((C_word*)t0)[4],lf[16]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4936,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4938,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,a[6]=((C_word)li49),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_4938(t13,t9,((C_word*)t0)[4]);}

/* ##sys#find-module/import-library in k2708 in k2704 */
static void C_ccall f_5703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5703,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5707,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:559: ##sys#resolve-module-name */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5707,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:560: ##sys#find-module */
t4=*((C_word*)lf[21]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k6410 in ren in k6394 in k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:665: ##sys#string->symbol */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[69]+1)))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],t1);}

/* k4385 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4387,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[62],t1);
t3=((C_word*)t0)[2];
f_4056(t3,C_a_i_list(&a,1,t2));}

/* k4904 in map-loop1033 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4906,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k6623 in k6596 in g1672 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=C_i_cdr(t2);
t4=C_eqp(((C_word*)t0)[3],t3);
if(C_truep(t4)){
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
/* modules.scm:698: ##sys#notice */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),((C_word*)t0)[4],lf[125],((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k3965 in loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3967,2,t0,t1);}
if(C_truep(C_i_assq(((C_word*)t0)[2],t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* modules.scm:275: warn */
t5=((C_word*)t0)[6];
f_3769(t5,t2,lf[93],t4);}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=C_i_assq(t3,((C_word*)t0)[7]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp);
/* modules.scm:272: g666 */
t6=t5;
f_3856(t6,((C_word*)t0)[5],t4);}
else{
t5=((C_word*)t0)[3];
t6=C_u_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3957,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* modules.scm:284: ##sys#current-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(2,*((C_word*)lf[26]+1),t7);}}}

/* k6414 in ren in k6394 in k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:666: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[70]+1)))(4,*((C_word*)lf[70]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k5711 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5716,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=*((C_word*)lf[0]+1);
t4=*((C_word*)lf[26]+1);
t5=*((C_word*)lf[100]+1);
t6=*((C_word*)lf[25]+1);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5722,a[2]=t8,a[3]=t10,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
/* modules.scm:568: ##sys#current-meta-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[100]+1)))(2,*((C_word*)lf[100]+1),t11);}
else{
/* modules.scm:575: ##sys#syntax-error-hook */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[104]+1)))(5,*((C_word*)lf[104]+1),((C_word*)t0)[5],((C_word*)t0)[6],lf[105],((C_word*)t0)[4]);}}

/* k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5710,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5713,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t3)[1])){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t3)[1]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5716,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5792,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5796,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:563: symbol->string */
t8=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[3]);}}

/* ##sys#switch-module in k2708 in k2704 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3173,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3220,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:149: ##sys#current-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(2,*((C_word*)lf[26]+1),t3);}

/* ##sys#register-module in k2708 in k2704 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_3595r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3595r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3595r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(21);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=t2;
t14=C_a_i_record(&a,14,lf[3],t13,t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t6,t10,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);
t15=C_a_i_cons(&a,2,t2,t14);
t16=C_a_i_cons(&a,2,t15,*((C_word*)lf[22]+1));
t17=C_mutate2((C_word*)lf[22]+1 /* (set! ##sys#module-table ...) */,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t14);}

/* warn in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_3769(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3769,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3777,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3781,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:264: symbol->string */
t6=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k3385 in k3382 in k3379 in k3373 in k3370 in k3367 in register-export in k2708 in k2704 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
t4=C_i_check_structure_2(t3,lf[3],lf[39]);
t5=C_i_block_ref(t3,C_fix(3));
t6=C_a_i_cons(&a,2,t2,t5);
t7=((C_word*)t0)[5];
t8=((C_word*)t0)[4];
t9=C_i_check_structure_2(t8,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t10=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t8,C_fix(3),t6);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7626 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7628,2,t0,t1);}
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7641,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7645,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:855: symbol->string */
t4=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2708 in k2704 */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word ab[110],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2710,2,t0,t1);}
t2=C_mutate2((C_word*)lf[1]+1 /* (set! ##sys#module-alias-environment ...) */,t1);
t3=C_mutate2(&lf[2] /* (set! module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2724,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[5]+1 /* (set! module-undefined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2805,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[6]+1 /* (set! set-module-undefined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2814,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[8]+1 /* (set! ##sys#module-name ...) */,lf[2]);
t7=C_mutate2((C_word*)lf[9]+1 /* (set! ##sys#module-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2950,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[13]+1 /* (set! ##sys#register-module-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[14]+1 /* (set! ##sys#with-module-aliases ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2992,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[18]+1 /* (set! ##sys#resolve-module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3076,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[21]+1 /* (set! ##sys#find-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3119,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_mutate2((C_word*)lf[24]+1 /* (set! ##sys#switch-module ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3173,a[2]=t13,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate2((C_word*)lf[28]+1 /* (set! ##sys#add-to-export-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3226,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[31]+1 /* (set! ##sys#toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3315,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[32]+1 /* (set! ##sys#register-meta-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3318,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[34]+1 /* (set! check-for-redef ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3338,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2((C_word*)lf[38]+1 /* (set! ##sys#register-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3359,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate2((C_word*)lf[43]+1 /* (set! ##sys#register-syntax-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate2((C_word*)lf[46]+1 /* (set! ##sys#register-undefined ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3529,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate2((C_word*)lf[47]+1 /* (set! ##sys#register-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3595,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2((C_word*)lf[48]+1 /* (set! ##sys#mark-imported-symbols ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3645,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate2(&lf[50] /* (set! merge-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3973,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate2((C_word*)lf[51]+1 /* (set! ##sys#compiled-module-registration ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4025,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate2((C_word*)lf[60]+1 /* (set! ##sys#register-compiled-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4411,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate2((C_word*)lf[67]+1 /* (set! ##sys#primitive-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4826,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate2((C_word*)lf[72]+1 /* (set! ##sys#register-primitive-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4845,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate2((C_word*)lf[42]+1 /* (set! ##sys#find-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5014,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate2((C_word*)lf[74]+1 /* (set! ##sys#finalize-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5092,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t31=C_set_block_item(lf[22] /* ##sys#module-table */,0,C_SCHEME_END_OF_LIST);
t32=C_mutate2((C_word*)lf[99]+1 /* (set! ##sys#find-module/import-library ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5703,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate2((C_word*)lf[108]+1 /* (set! ##sys#expand-import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5799,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate2((C_word*)lf[41]+1 /* (set! ##sys#module-rename ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7069,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate2((C_word*)lf[137]+1 /* (set! ##sys#alias-global-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7087,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate2((C_word*)lf[140]+1 /* (set! ##sys#register-interface ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7197,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate2((C_word*)lf[142]+1 /* (set! ##sys#validate-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7205,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate2((C_word*)lf[153]+1 /* (set! ##sys#register-functor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7410,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate2((C_word*)lf[155]+1 /* (set! ##sys#instantiate-functor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7426,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate2((C_word*)lf[159]+1 /* (set! ##sys#match-functor-argument ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7591,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t41=lf[167];
t42=*((C_word*)lf[168]+1);
t43=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7735,a[2]=((C_word*)t0)[2],a[3]=t42,a[4]=t41,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:899: ##sys#register-primitive-module */
t44=*((C_word*)lf[72]+1);
((C_proc5)(void*)(*((C_word*)t44+1)))(5,t44,t43,lf[178],t41,*((C_word*)lf[168]+1));}

/* k3382 in k3379 in k3373 in k3370 in k3367 in register-export in k2708 in k2704 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_structure_2(t3,lf[3],lf[29]);
t5=C_i_block_ref(t3,C_fix(4));
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[4];
t8=C_i_check_structure_2(t7,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t9=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t2,t7,C_fix(4),t6);}

/* k3379 in k3373 in k3370 in k3367 in register-export in k2708 in k2704 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3420,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:199: ##sys#current-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(2,*((C_word*)lf[26]+1),t3);}

/* k2704 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2706,2,t0,t1);}
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##sys#current-module ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:73: make-parameter */
t4=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_END_OF_LIST);}

/* k3912 in g673 in k3955 in k3965 in loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_3914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3914,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* module-name in k2708 in k2704 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2724,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[3],lf[4]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(1)));}

/* k3370 in k3367 in register-export in k2708 in k2704 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3435,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[4];
t6=C_i_check_structure_2(t5,lf[3],lf[4]);
t7=C_i_block_ref(t5,C_fix(1));
/* modules.scm:195: ##sys#module-rename */
t8=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,((C_word*)t0)[2],t7);}

/* k3373 in k3370 in k3367 in register-export in k2708 in k2704 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3431,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:198: ##sys#delq */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t4,t2,((C_word*)t0)[3]);}
else{
t4=t3;
f_3381(2,t4,C_SCHEME_FALSE);}}

/* k3367 in register-export in k2708 in k2704 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3369,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3372,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:193: module-undefined-list */
t4=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* g2047 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_fcall f_7602(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7602,NULL,3,t0,t1,t2);}
t3=C_i_symbolp(t2);
t4=(C_truep(t3)?t2:C_i_car(t2));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7612,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:847: ##sys#find-export */
t7=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t5,((C_word*)t0)[3],C_SCHEME_FALSE);}

/* ##sys#register-export in k2708 in k2704 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3359,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t3;
t5=C_i_check_structure_2(t4,lf[3],lf[10]);
t6=C_i_block_ref(t4,C_fix(2));
t7=C_eqp(C_SCHEME_TRUE,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3369,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t9=t8;
f_3369(2,t9,t7);}
else{
/* modules.scm:192: ##sys#find-export */
t9=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,t2,t3,C_SCHEME_TRUE);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* g961 in k4566 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_fcall f_4569(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4569,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4585,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(t2);
if(C_truep(t7)){
/* modules.scm:383: merge-se */
f_3973(t6,C_a_i_list(&a,2,t7,((C_word*)t0)[2]));}
else{
/* modules.scm:383: merge-se */
f_3973(t6,C_a_i_list(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4566 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[2],a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(((C_word*)t0)[3],lf[30]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4661,a[2]=t6,a[3]=t2,a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4661(t8,t4,((C_word*)t0)[3]);}

/* k3534 in register-undefined in k2708 in k2704 */
static void C_ccall f_3536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3536,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3543,a[2]=((C_word*)t0)[3],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
/* modules.scm:229: g579 */
t4=t3;
f_3543(t4,((C_word*)t0)[4],t2);}
else{
if(C_truep(((C_word*)t0)[3])){
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,t1);
/* modules.scm:235: set-module-undefined-list! */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[4],((C_word*)t0)[5],t5);}
else{
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t3,t1);
/* modules.scm:235: set-module-undefined-list! */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],((C_word*)t0)[5],t4);}}}

/* k3343 in check-for-redef in k2708 in k2704 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_assq(((C_word*)t0)[2],((C_word*)t0)[3]))){
/* modules.scm:187: ##sys#warn */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),((C_word*)t0)[4],lf[36],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3779 in warn in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:264: string-append */
t2=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[90],t1,lf[91]);}

/* g940 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_fcall f_4543(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4543,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4555,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cadr(t2);
if(C_truep(t6)){
/* modules.scm:378: merge-se */
f_3973(t5,C_a_i_list(&a,2,t6,((C_word*)t0)[2]));}
else{
/* modules.scm:378: merge-se */
f_3973(t5,C_a_i_list(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}}

/* k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4543,a[2]=((C_word*)t0)[2],a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(((C_word*)t0)[3],lf[30]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4684,a[2]=t6,a[3]=t2,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4684(t8,t4,((C_word*)t0)[3]);}

/* k4553 in g940 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_car(((C_word*)t0)[3],t1));}

/* k4367 in map-loop721 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4340(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4340(t6,((C_word*)t0)[5],t5);}}

/* map-loop721 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_fcall f_4340(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4340,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:314: g727 */
t5=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5809,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* modules.scm:584: r */
t4=((C_word*)t0)[12];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[132]);}

/* k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5806,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* modules.scm:583: r */
t4=((C_word*)t0)[11];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[133]);}

/* k4184 in g786 in k4287 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4186,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[58],((C_word*)t0)[3],t1));}

/* k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5803,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* modules.scm:582: r */
t4=((C_word*)t0)[10];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[134]);}

/* ##sys#instantiate-functor in k2708 in k2704 */
static void C_ccall f_7426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7426,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=C_i_getprop(t5,lf[154],C_SCHEME_FALSE);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7434,a[2]=t2,a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7441,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t10=t9;
f_7441(2,t10,C_SCHEME_UNDEFINED);}
else{
/* modules.scm:817: err */
t10=t8;
f_7434(t10,t9,C_a_i_list(&a,2,lf[160],t3));}}

/* k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5812,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* modules.scm:585: r */
t4=((C_word*)t0)[13];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[131]);}

/* resolve in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5817,3,t0,t1,t2);}
t3=t2;
t4=C_u_i_assq(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=C_i_cdr(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}
else{
t5=C_i_getprop(t3,lf[109],C_SCHEME_FALSE);
if(C_truep(t5)){
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}
else{
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5815,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5817,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t12=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5826,a[2]=((C_word*)t0)[2],a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t13=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5869,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t14=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5891,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t4,a[6]=t6,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t2,a[13]=((C_word)li97),tmp=(C_word)a,a+=14,tmp));
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6552,a[2]=t10,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* modules.scm:670: ##sys#check-syntax */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[117]+1)))(5,*((C_word*)lf[117]+1),t15,((C_word*)t0)[2],((C_word*)t0)[11],lf[130]);}

/* loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_3792(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(11);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3792,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
if(C_truep(C_i_symbolp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
/* modules.scm:270: loop */
t11=t1;
t12=t5;
t1=t11;
t2=t12;
goto loop;}
else{
t4=C_i_cdar(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3819,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li65),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_3819(t8,t1,t4);}}}

/* err in instantiate-functor in k2708 in k2704 */
static void C_fcall f_7434(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7434,NULL,3,t0,t1,t2);}
C_apply(5,0,t1,*((C_word*)lf[104]+1),((C_word*)t0)[2],t2);}

/* g786 in k4287 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_fcall f_4162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4162,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=C_i_assq(t3,((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t4))){
t5=t2;
t6=C_u_i_car(t5);
t7=C_a_i_list(&a,2,lf[55],t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4186,a[2]=t1,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=C_u_i_cdr(t4);
/* modules.scm:329: ##sys#strip-syntax */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[59]+1)))(3,*((C_word*)lf[59]+1),t9,t10);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,2,lf[55],t3));}}

/* k3548 in g579 in k3534 in register-undefined in k2708 in k2704 */
static void C_fcall f_3550(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3550,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_set_cdr(((C_word*)t0)[2],t3));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3775 in warn in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:263: ##sys#warn */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* ##sys#register-functor in k2708 in k2704 */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7410,6,t0,t1,t2,t3,t4,t5);}
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,t3,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_putprop(&a,3,t2,lf[154],t7));}

/* k5844 in k5837 in tostr in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:590: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[70]+1)))(4,*((C_word*)lf[70]+1),((C_word*)t0)[2],t1,lf[110]);}

/* g579 in k3534 in register-undefined in k2708 in k2704 */
static void C_fcall f_3543(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3543,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3550,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=C_i_cdr(t2);
t5=C_i_memq(((C_word*)t0)[2],t4);
t6=t3;
f_3550(t6,C_i_not(t5));}
else{
t4=t3;
f_3550(t4,C_SCHEME_FALSE);}}

/* k5431 in k5427 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5433,2,t0,t1);}
/* modules.scm:525: merge-se */
f_3973(((C_word*)t0)[2],C_a_i_list(&a,6,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]));}

/* map-loop1258 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5435(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5435,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5464,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=C_i_cdr(t6);
if(C_truep(C_i_symbolp(t7))){
t8=t5;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t6);}
else{
t8=C_u_i_car(t6);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5321,a[2]=t8,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:522: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t9);}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4138 in k4148 in loop in k4200 in k4287 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4140,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k4934 in k4910 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4936,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_a_i_record(&a,14,lf[3],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4858,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4874,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4882,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:419: ##sys#current-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(2,*((C_word*)lf[26]+1),t7);}

/* map-loop1060 in k4910 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_fcall f_4938(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4938,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:408: g1066 */
t5=((C_word*)t0)[5];
f_4914(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4148 in loop in k4200 in k4287 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4150,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4140,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
/* modules.scm:343: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_4108(t7,t4,t6);}

/* k3698 in for-each-loop608 in mark-imported-symbols in k2708 in k2704 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3690(t3,((C_word*)t0)[4],t2);}

/* import-name in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_5869(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5869,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5873,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5889,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:595: ##sys#strip-syntax */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[59]+1)))(3,*((C_word*)lf[59]+1),t4,t2);}

/* k4742 in map-loop910 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4715(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4715(t6,((C_word*)t0)[5],t5);}}

/* g1195 in k5248 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5251(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5251,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5255,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:499: display */
t4=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[84],((C_word*)t0)[2]);}

/* k5248 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5251,a[2]=((C_word*)t0)[2],a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5263,a[2]=t4,a[3]=t2,a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5263(t6,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k5253 in g1195 in k5248 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:500: display */
t2=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k5871 in import-name in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=C_i_check_structure_2(t1,lf[3],lf[11]);
t3=C_i_block_ref(t1,C_fix(10));
t4=C_i_check_structure_2(t1,lf[3],lf[12]);
t5=C_i_block_ref(t1,C_fix(11));
t6=C_i_check_structure_2(t1,lf[3],lf[56]);
t7=C_i_block_ref(t1,C_fix(12));
/* modules.scm:599: values */
C_values(5,0,((C_word*)t0)[2],t3,t5,t7);}

/* ##sys#module-exports in k2708 in k2704 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2950,3,t0,t1,t2);}
t3=t2;
t4=C_i_check_structure_2(t3,lf[3],lf[10]);
t5=C_i_block_ref(t3,C_fix(2));
t6=t2;
t7=C_i_check_structure_2(t6,lf[3],lf[11]);
t8=C_i_block_ref(t6,C_fix(10));
t9=t2;
t10=C_i_check_structure_2(t9,lf[3],lf[12]);
t11=C_i_block_ref(t9,C_fix(11));
/* modules.scm:112: values */
C_values(5,0,t1,t5,t8,t11);}

/* k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4510,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[16]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4715,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=((C_word)li43),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_4715(t12,t8,((C_word*)t0)[2]);}

/* for-each-loop1194 in k5248 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5263,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5273,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:497: g1195 */
t5=((C_word*)t0)[3];
f_5251(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5887 in import-name in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:595: ##sys#find-module/import-library */
t2=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[62]);}

/* for-each-loop1178 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5473(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5473,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5483,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:438: g1179 */
t5=((C_word*)t0)[3];
f_5134(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6749 in k6710 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(12),t1);}

/* k5271 in for-each-loop1194 in k5248 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5263(t3,((C_word*)t0)[4],t2);}

/* import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_5891(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5891,NULL,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
/* modules.scm:601: import-name */
f_5869(t1,t2);}
else{
t3=C_i_listp(t2);
t4=C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5910,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t4)){
t6=t5;
f_5910(t6,t4);}
else{
t6=C_i_length(t2);
t7=t5;
f_5910(t7,C_fixnum_lessp(t6,C_fix(2)));}}}

/* k4777 in map-loop882 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4779,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4750(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4750(t6,((C_word*)t0)[5],t5);}}

/* k5481 in for-each-loop1178 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5473(t3,((C_word*)t0)[4],t2);}

/* k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4539,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4542,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* modules.scm:375: ##sys#mark-imported-symbols */
t4=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
t5=C_a_i_record(&a,14,lf[3],t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t4,((C_word*)t0)[4],((C_word*)t0)[5],C_SCHEME_FALSE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t6,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4709,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* modules.scm:372: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t8);}

/* map-loop882 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_fcall f_4750(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4750,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_cdr(t4);
if(C_truep(C_i_pairp(t6))){
t7=C_u_i_car(t4);
t8=C_i_cadr(t4);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4494,a[2]=t5,a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=C_i_caddr(t4);
t12=C_u_i_car(t4);
/* modules.scm:363: ##sys#ensure-transformer */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t10,t11,t12);}
else{
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t4);}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* map-loop854 in register-compiled-module in k2708 in k2704 */
static void C_fcall f_4785(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4785,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4814,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
if(C_truep(C_i_symbolp(t4))){
t6=t5;
t7=t4;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4441,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:348: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t8);}
else{
t6=C_i_car(t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4463,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=C_u_i_cdr(t4);
t10=C_u_i_car(t4);
/* modules.scm:358: ##sys#ensure-transformer */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t8,t9,t10);}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6774 in k6759 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6776,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6782,a[2]=t6,a[3]=t9,a[4]=t4,a[5]=((C_word)li101),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_6782(t11,t7,((C_word*)t0)[4]);}

/* k4583 in g961 in k4566 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_car(((C_word*)t0)[3],t1));}

/* k4521 in map-loop910 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4523,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list3(&a,3,((C_word*)t0)[3],C_SCHEME_FALSE,t1));}

/* k6766 in k6759 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(4),t1);}

/* k6759 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_structure_2(((C_word*)t0)[2],lf[3],lf[29]);
t4=C_i_block_ref(((C_word*)t0)[2],C_fix(4));
t5=t4;
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6776,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6817,a[2]=t9,a[3]=t12,a[4]=t7,a[5]=((C_word)li102),tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_6817(t14,t10,((C_word*)t0)[5]);}

/* k6716 in k6713 in k6710 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6681(t2,C_SCHEME_UNDEFINED);}

/* k6713 in k6710 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6731,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_check_structure_2(((C_word*)t0)[4],lf[3],lf[33]);
t5=C_i_block_ref(((C_word*)t0)[4],C_fix(9));
t6=C_a_i_list(&a,2,lf[55],((C_word*)((C_word*)t0)[3])[1]);
t7=C_a_i_list(&a,2,lf[127],t6);
t8=C_a_i_list(&a,1,t7);
/* modules.scm:731: append */
t9=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t3,t5,t8);}
else{
t3=((C_word*)t0)[2];
f_6681(t3,C_SCHEME_UNDEFINED);}}

/* k6710 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6751,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_check_structure_2(((C_word*)t0)[4],lf[3],lf[56]);
t5=C_i_block_ref(((C_word*)t0)[4],C_fix(12));
/* modules.scm:727: merge-se */
f_3973(t3,C_a_i_list(&a,2,t5,((C_word*)t0)[5]));}

/* map-loop1776 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6917(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6917,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4711 in k4707 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
/* modules.scm:371: merge-se */
f_3973(((C_word*)t0)[2],C_a_i_list(&a,6,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]));}

/* map-loop910 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_fcall f_4715(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4715,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_car(t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4523,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=C_u_i_cdr(t4);
t10=C_u_i_car(t4);
/* modules.scm:368: ##sys#ensure-transformer */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t8,t9,t10);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5652 in k5643 in loop in k5628 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5654,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k6701 in k6679 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:735: append */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k3942 in k3955 in k3965 in loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* modules.scm:293: loop2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3819(t4,((C_word*)t0)[4],t3);}

/* k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6706,2,t0,t1);}
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[3],lf[10]);
t3=C_i_block_ref(((C_word*)t0)[2],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6712,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=C_eqp(C_SCHEME_TRUE,t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6761,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6854,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_structure_2(((C_word*)t0)[2],lf[3],lf[12]);
t9=C_i_block_ref(((C_word*)t0)[2],C_fix(11));
/* modules.scm:711: append */
t10=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,((C_word*)t0)[6],t9);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6865,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=C_i_check_structure_2(((C_word*)t0)[2],lf[3],lf[10]);
t8=C_i_block_ref(((C_word*)t0)[2],C_fix(2));
t9=C_eqp(C_SCHEME_TRUE,t8);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:t8);
t11=t10;
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6876,a[2]=t6,a[3]=t11,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6917,a[2]=t15,a[3]=t18,a[4]=t13,a[5]=((C_word)li104),tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_6917(t20,t16,((C_word*)t0)[7]);}}

/* k6729 in k6713 in k6710 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(9),t1);}

/* k3955 in k3965 in loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3957,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp);
/* modules.scm:272: g673 */
t4=t3;
f_3896(t4,((C_word*)t0)[6],t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_car(t4);
/* modules.scm:292: warn */
t6=((C_word*)t0)[5];
f_3769(t6,t3,lf[95],t5);}}

/* k5462 in map-loop1258 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5464,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5435(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5435(t6,((C_word*)t0)[5],t5);}}

/* k3923 in g673 in k3955 in k3965 in loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* modules.scm:290: loop2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3819(t4,((C_word*)t0)[4],t3);}

/* k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6390,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:661: ##sys#check-syntax */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[117]+1)))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[8],((C_word*)t0)[6],lf[122]);}
else{
/* modules.scm:669: ##sys#syntax-error-hook */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[104]+1)))(5,*((C_word*)lf[104]+1),((C_word*)t0)[4],((C_word*)t0)[8],lf[123],((C_word*)t0)[6]);}}

/* for-each-loop2046 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_fcall f_7707(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7707,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7717,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:843: g2047 */
t5=((C_word*)t0)[3];
f_7602(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ren in k6394 in k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6398,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6406,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6412,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6416,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=C_i_car(t2);
/* modules.scm:666: ##sys#symbol->string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[111]+1)))(3,*((C_word*)lf[111]+1),t5,t6);}

/* k6394 in k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6396,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6398,a[2]=t2,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=t3;
t9=C_i_check_list_2(((C_word*)t0)[2],lf[16]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6430,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6474,a[2]=t7,a[3]=t12,a[4]=t5,a[5]=t8,a[6]=((C_word)li95),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_6474(t14,t10,((C_word*)t0)[2]);}

/* k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_caddr(((C_word*)t0)[6]);
/* modules.scm:662: tostr */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5826(t4,t2,t3);}

/* k7699 in map-loop2065 in k7651 in k7647 in k7643 in k7626 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7701,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7672(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7672(t6,((C_word*)t0)[5],t5);}}

/* k5643 in loop in k5628 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5645,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5654,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* modules.scm:454: loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5632(t7,t4,t6);}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* modules.scm:455: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5632(t4,((C_word*)t0)[3],t3);}}

/* k7715 in for-each-loop2046 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7707(t3,((C_word*)t0)[4],t2);}

/* k4707 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4709,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4713,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:373: ##sys#current-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(2,*((C_word*)lf[26]+1),t3);}

/* tostr in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_5826(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5826,NULL,3,t0,t1,t2);}
if(C_truep(C_i_stringp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5839,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:590: keyword? */
t4=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}

/* k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5287,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[30]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5473,a[2]=t5,a[3]=((C_word*)t0)[9],a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5473(t7,t3,t1);}

/* map-loop1124 in finalize-module in k2708 in k2704 */
static void C_fcall f_5667(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5667,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5696,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_car(t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5118,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:446: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t8);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5296,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t5,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t7=((C_word*)t0)[4];
t8=C_i_check_structure_2(t7,lf[3],lf[10]);
t9=C_i_block_ref(t7,C_fix(2));
t10=C_i_check_structure_2(t7,lf[3],lf[4]);
t11=C_i_block_ref(t7,C_fix(1));
t12=t11;
t13=C_i_check_structure_2(t7,lf[3],lf[39]);
t14=C_i_block_ref(t7,C_fix(3));
t15=t14;
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3769,a[2]=t12,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp);
t17=C_eqp(C_SCHEME_TRUE,t9);
if(C_truep(t17)){
t18=t6;
f_5328(2,t18,C_SCHEME_END_OF_LIST);}
else{
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3792,a[2]=t19,a[3]=t16,a[4]=t15,a[5]=t12,a[6]=((C_word)li66),tmp=(C_word)a,a+=7,tmp));
t21=((C_word*)t19)[1];
f_3792(t21,t6,t9);}}

/* k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
/* modules.scm:518: ##sys#error */
t3=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[96],((C_word*)t0)[8]);}
else{
t3=t2;
f_5296(2,t3,C_SCHEME_UNDEFINED);}}

/* k5837 in tostr in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5839,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:590: ##sys#symbol->string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[111]+1)))(3,*((C_word*)lf[111]+1),t2,((C_word*)t0)[3]);}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
/* modules.scm:591: ##sys#symbol->string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[111]+1)))(3,*((C_word*)lf[111]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
if(C_truep(C_i_numberp(((C_word*)t0)[3]))){
/* modules.scm:592: number->string */
C_number_to_string(3,0,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
/* modules.scm:593: ##sys#syntax-error-hook */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],((C_word*)t0)[4],lf[112]);}}}}

/* k7733 in k2708 in k2704 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7779,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:902: append */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[177],((C_word*)t0)[4]);}

/* k7736 in k7733 in k2708 in k2704 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:904: ##sys#register-primitive-module */
t3=*((C_word*)lf[72]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[176],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}

/* map-loop1493 in k6085 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6177(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6177,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6206,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:625: g1499 */
t5=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7730 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:841: ##sys#find-module */
t2=*((C_word*)lf[21]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[3]);}

/* loop in k5628 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5632(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5632,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5645,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_caar(t2);
/* modules.scm:453: ##sys#find-export */
t5=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* k5628 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5630,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5632,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5632(t5,((C_word*)t0)[3],t1);}

/* k7745 in k7742 in k7739 in k7736 in k7733 in k2708 in k2704 */
static void C_ccall f_7747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7750,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:909: register-feature! */
t3=*((C_word*)lf[171]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[172]);}

/* k6352 in g1574 in loop in k6217 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:653: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6228(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],t1);}

/* k7739 in k7736 in k7733 in k2708 in k2704 */
static void C_ccall f_7741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7744,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:905: ##sys#register-primitive-module */
t3=*((C_word*)lf[72]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[175],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}

/* k7742 in k7739 in k7736 in k7733 in k2708 in k2704 */
static void C_ccall f_7744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7747,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:907: ##sys#register-module-alias */
t3=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[173],lf[174]);}

/* map-loop1748 in k6774 in k6759 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6782(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6782,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5053 in loop in k5023 in find-export in k2708 in k2704 */
static void C_fcall f_5055(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* modules.scm:434: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5027(t4,((C_word*)t0)[2],t3);}}

/* k7757 in module-environment in k7748 in k7745 in k7742 in k7739 in k7736 in k7733 in k2708 in k2704 */
static void C_ccall f_7759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7759,2,t0,t1);}
t2=C_i_check_structure_2(t1,lf[3],lf[27]);
t3=C_i_block_ref(t1,C_fix(13));
t4=C_i_car(t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[170],((C_word*)t0)[3],t4,C_SCHEME_TRUE));}

/* k6778 in k6774 in k6759 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:714: append */
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* ##sys#find-module in k2708 in k2704 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3119r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3119r(t0,t1,t2,t3);}}

static void C_ccall f_3119r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_TRUE:C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_nullp(t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:C_i_car(t7));
t10=C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:C_i_cdr(t7));
t12=C_i_assq(t2,*((C_word*)lf[22]+1));
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_i_cdr(t12));}
else{
if(C_truep(t5)){
/* modules.scm:143: error */
t13=*((C_word*)lf[19]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t1,t9,lf[23],t2);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}}

/* k3115 in loop in resolve-module-name in k2708 in k2704 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li9),tmp=(C_word)a,a+=7,tmp);
/* modules.scm:131: g439 */
t4=t3;
f_3090(t4,((C_word*)t0)[7],t2);}
else{
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7748 in k7745 in k7742 in k7739 in k7736 in k7733 in k2708 in k2704 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7750,2,t0,t1);}
t2=C_mutate2((C_word*)lf[169]+1 /* (set! module-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7752,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* module-environment in k7748 in k7745 in k7742 in k7739 in k7736 in k7733 in k2708 in k2704 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7752r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7752r(t0,t1,t2,t3);}}

static void C_ccall f_7752r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?t2:C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7759,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:912: ##sys#find-module/import-library */
t8=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,lf[169]);}

/* g1903 in k7193 in k7190 in k7122 in alias-global-hook in k2708 in k2704 */
static void C_fcall f_7158(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7158,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
/* modules.scm:769: mrename */
t4=((C_word*)t0)[2];
f_7090(t4,t1,((C_word*)t0)[3]);}
else{
t4=C_i_getprop(t3,lf[68],C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:t3));}}

/* ##sys#finalize-module in k2708 in k2704 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5092,3,t0,t1,t2);}
t3=t2;
t4=C_i_check_structure_2(t3,lf[3],lf[10]);
t5=C_i_block_ref(t3,C_fix(2));
t6=t5;
t7=t2;
t8=C_i_check_structure_2(t7,lf[3],lf[4]);
t9=C_i_block_ref(t7,C_fix(1));
t10=t9;
t11=t2;
t12=C_i_check_structure_2(t11,lf[3],lf[39]);
t13=C_i_block_ref(t11,C_fix(3));
t14=t13;
t15=t2;
t16=C_i_check_structure_2(t15,lf[3],lf[29]);
t17=C_i_block_ref(t15,C_fix(4));
t18=t17;
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_END_OF_LIST;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_FALSE;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=t2;
t26=C_i_check_structure_2(t25,lf[3],lf[44]);
t27=C_i_block_ref(t25,C_fix(5));
t28=C_i_check_list_2(t27,lf[16]);
t29=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5127,a[2]=t18,a[3]=t20,a[4]=t1,a[5]=t2,a[6]=t10,a[7]=t6,a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5667,a[2]=t24,a[3]=t31,a[4]=t22,a[5]=((C_word)li70),tmp=(C_word)a,a+=6,tmp));
t33=((C_word*)t31)[1];
f_5667(t33,t29,t27);}

/* k7190 in k7122 in alias-global-hook in k2708 in k2704 */
static void C_ccall f_7192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:764: g1901 */
t3=t1;
((C_proc2)C_fast_retrieve_proc(t3))(2,t3,t2);}

/* ##sys#register-interface in k2708 in k2704 */
static void C_ccall f_7197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7197,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_putprop(&a,3,t2,lf[141],t3));}

/* k7193 in k7190 in k7122 in alias-global-hook in k2708 in k2704 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7195,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7158,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li114),tmp=(C_word)a,a+=5,tmp);
/* modules.scm:747: g1903 */
t4=t3;
f_7158(t4,((C_word*)t0)[4],t2);}
else{
/* modules.scm:771: mrename */
t3=((C_word*)t0)[3];
f_7090(t3,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k5694 in map-loop1124 in finalize-module in k2708 in k2704 */
static void C_ccall f_5696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5696,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5667(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5667(t6,((C_word*)t0)[5],t5);}}

/* k7366 in loop2 in loop in validate-exports in k2708 in k2704 */
static void C_ccall f_7368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7368,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k5427 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5429,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5433,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:527: ##sys#current-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(2,*((C_word*)lf[26]+1),t3);}

/* k5226 in for-each-loop1225 in k5196 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5218(t3,((C_word*)t0)[4],t2);}

/* k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* modules.scm:671: ##sys#current-module */
t3=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6555,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7044,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_check_structure_2(t2,lf[3],lf[53]);
t6=C_i_block_ref(t2,C_fix(8));
t7=C_i_cdr(((C_word*)t0)[7]);
/* modules.scm:677: append */
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t6,t7);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7059,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_check_structure_2(t2,lf[3],lf[52]);
t6=C_i_block_ref(t2,C_fix(7));
t7=C_i_cdr(((C_word*)t0)[7]);
/* modules.scm:680: append */
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t6,t7);}}
else{
t4=t3;
f_6558(2,t4,C_SCHEME_UNDEFINED);}}

/* k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li108),tmp=(C_word)a,a+=9,tmp);
t3=C_i_cdr(((C_word*)t0)[8]);
t4=C_i_check_list_2(t3,lf[30]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7011,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7013,a[2]=t7,a[3]=t2,a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7013(t9,t5,t3);}

/* g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6559,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li98),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li107),tmp=(C_word)a,a+=8,tmp);
/* modules.scm:682: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* loop in loop in k6094 in k6085 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6113(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6113,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
/* modules.scm:629: values */
C_values(5,0,t1,((C_word*)t0)[2],t3,((C_word*)t0)[3]);}
else{
t4=C_i_caar(t2);
if(C_truep(C_i_memq(t4,((C_word*)t0)[4]))){
t5=t2;
t6=C_u_i_cdr(t5);
/* modules.scm:630: loop */
t13=t1;
t14=t6;
t15=t3;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t5=t2;
t6=C_u_i_cdr(t5);
t7=t2;
t8=C_u_i_car(t7);
t9=C_a_i_cons(&a,2,t8,t3);
/* modules.scm:631: loop */
t13=t1;
t14=t6;
t15=t9;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* check-for-redef in k2708 in k2704 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3338,5,t0,t1,t2,t3,t4);}
t5=C_i_assq(t2,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3345,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
/* modules.scm:185: ##sys#warn */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),t6,lf[37],t2);}
else{
t7=t6;
f_3345(2,t7,C_SCHEME_FALSE);}}

/* loop2 in loop in validate-exports in k2708 in k2704 */
static void C_fcall f_7354(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7354,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7368,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
/* modules.scm:806: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7255(t5,t3,t4);}
else{
t3=C_i_car(t2);
if(C_truep(C_i_symbolp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
/* modules.scm:807: loop2 */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
/* modules.scm:808: err */
t4=((C_word*)((C_word*)t0)[6])[1];
f_7208(t4,t1,C_a_i_list(&a,3,lf[149],((C_word*)t0)[2],((C_word*)t0)[7]));}}}

/* a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6571,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=t3;
t7=t4;
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6584,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=t7,a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* modules.scm:688: ##sys#mark-imported-symbols */
t11=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t5);}

/* k3320 in register-meta-expression in k2708 in k2704 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3322,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_check_structure_2(t1,lf[3],lf[33]);
t3=C_i_block_ref(t1,C_fix(9));
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=((C_word*)t0)[3];
t6=C_i_check_structure_2(t1,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t7=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t1,C_fix(9),t4);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6966 in for-each-loop1698 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6958(t3,((C_word*)t0)[4],t2);}

/* a6564 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6565,2,t0,t1);}
/* modules.scm:683: import-spec */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5891(t2,t1,((C_word*)t0)[3]);}

/* ##sys#toplevel-definition-hook in k2708 in k2704 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3315,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}

/* ##sys#register-meta-expression in k2708 in k2704 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3318,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3322,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:180: ##sys#current-module */
t4=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3311 in add-to-export-list in k2708 in k2704 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=C_i_check_structure_2(t3,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t3,C_fix(2),t1);}

/* for-each-loop1698 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6958(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6958,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6968,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:700: g1699 */
t5=((C_word*)t0)[3];
f_6636(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6596 in g1672 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6598,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:696: import-env */
t3=((C_word*)t0)[5];
((C_proc2)C_fast_retrieve_proc(t3))(2,t3,t2);}

/* for-each-loop1293 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5404(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5404,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5414,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:530: g1294 */
t5=((C_word*)t0)[3];
f_5341(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* for-each-loop1671 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6981(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6981,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6991,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:689: g1672 */
t5=((C_word*)t0)[3];
f_6585(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp);
t3=C_i_check_list_2(((C_word*)t0)[4],lf[30]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6635,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6981,a[2]=t6,a[3]=t2,a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_6981(t8,t4,((C_word*)t0)[4]);}

/* g1672 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6585(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6585,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_i_getprop(t6,lf[68],C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6598,a[2]=t4,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t7)){
t9=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t10=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t9);
t11=t8;
f_6598(t11,t10);}
else{
t9=t8;
f_6598(t9,C_SCHEME_UNDEFINED);}}

/* k5412 in for-each-loop1293 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5404(t3,((C_word*)t0)[4],t2);}

/* k7103 in g1875 in k7092 in mrename in alias-global-hook in k2708 in k2704 */
static void C_ccall f_7105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_i_check_structure_2(t2,lf[3],lf[4]);
t4=C_i_block_ref(t2,C_fix(1));
/* modules.scm:754: ##sys#module-rename */
t5=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],((C_word*)t0)[4],t4);}

/* loop in k6094 in k6085 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6101(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6101,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6113,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word)li86),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_6113(t7,t1,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
t4=C_i_caar(t2);
if(C_truep(C_i_memq(t4,((C_word*)t0)[3]))){
t5=t2;
t6=C_u_i_cdr(t5);
/* modules.scm:632: loop */
t16=t1;
t17=t6;
t18=t3;
t1=t16;
t2=t17;
t3=t18;
goto loop;}
else{
t5=t2;
t6=C_u_i_cdr(t5);
t7=t2;
t8=C_u_i_car(t7);
t9=C_a_i_cons(&a,2,t8,t3);
/* modules.scm:633: loop */
t16=t1;
t17=t6;
t18=t9;
t1=t16;
t2=t17;
t3=t18;
goto loop;}}}

/* k7122 in alias-global-hook in k2708 in k2704 */
static void C_ccall f_7124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7124,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=C_i_getprop(t2,lf[68],C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t4=((C_word*)t0)[2];
if(C_truep(C_i_getprop(t4,lf[49],C_SCHEME_FALSE))){
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:764: ##sys#active-eval-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[138]+1)))(2,*((C_word*)lf[138]+1),t5);}}}}

/* k6989 in for-each-loop1671 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6981(t3,((C_word*)t0)[4],t2);}

/* k7569 in loop in k7439 in instantiate-functor in k2708 in k2704 */
static void C_ccall f_7571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7571,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7582,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
t7=((C_word*)t0)[6];
t8=C_u_i_cdr(t7);
/* modules.scm:834: loop */
t9=((C_word*)((C_word*)t0)[7])[1];
f_7533(t9,t4,t6,t8);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_modules_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_modules_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("modules_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3946)){
C_save(t1);
C_rereclaim2(3946*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,180);
lf[0]=C_h_intern(&lf[0],18,"\003syscurrent-module");
lf[1]=C_h_intern(&lf[1],28,"\003sysmodule-alias-environment");
lf[3]=C_h_intern(&lf[3],6,"module");
lf[4]=C_h_intern(&lf[4],11,"module-name");
lf[5]=C_h_intern(&lf[5],21,"module-undefined-list");
lf[6]=C_h_intern(&lf[6],26,"set-module-undefined-list!");
lf[7]=C_h_intern(&lf[7],14,"\003sysblock-set!");
lf[8]=C_h_intern(&lf[8],15,"\003sysmodule-name");
lf[9]=C_h_intern(&lf[9],18,"\003sysmodule-exports");
lf[10]=C_h_intern(&lf[10],18,"module-export-list");
lf[11]=C_h_intern(&lf[11],15,"module-vexports");
lf[12]=C_h_intern(&lf[12],15,"module-sexports");
lf[13]=C_h_intern(&lf[13],25,"\003sysregister-module-alias");
lf[14]=C_h_intern(&lf[14],23,"\003syswith-module-aliases");
lf[15]=C_h_intern(&lf[15],16,"\003sysdynamic-wind");
lf[16]=C_h_intern(&lf[16],3,"map");
lf[17]=C_h_intern(&lf[17],6,"append");
lf[18]=C_h_intern(&lf[18],23,"\003sysresolve-module-name");
lf[19]=C_h_intern(&lf[19],5,"error");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\035module alias refers to itself");
lf[21]=C_h_intern(&lf[21],15,"\003sysfind-module");
lf[22]=C_h_intern(&lf[22],16,"\003sysmodule-table");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\020module not found");
lf[24]=C_h_intern(&lf[24],17,"\003sysswitch-module");
lf[25]=C_h_intern(&lf[25],21,"\003sysmacro-environment");
lf[26]=C_h_intern(&lf[26],23,"\003syscurrent-environment");
lf[27]=C_h_intern(&lf[27],25,"module-saved-environments");
lf[28]=C_h_intern(&lf[28],22,"\003sysadd-to-export-list");
lf[29]=C_h_intern(&lf[29],17,"module-exist-list");
lf[30]=C_h_intern(&lf[30],8,"for-each");
lf[31]=C_h_intern(&lf[31],28,"\003systoplevel-definition-hook");
lf[32]=C_h_intern(&lf[32],28,"\003sysregister-meta-expression");
lf[33]=C_h_intern(&lf[33],23,"module-meta-expressions");
lf[34]=C_h_intern(&lf[34],15,"check-for-redef");
lf[35]=C_h_intern(&lf[35],8,"\003syswarn");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\047redefinition of imported syntax binding");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000&redefinition of imported value binding");
lf[38]=C_h_intern(&lf[38],19,"\003sysregister-export");
lf[39]=C_h_intern(&lf[39],19,"module-defined-list");
lf[40]=C_h_intern(&lf[40],8,"\003sysdelq");
lf[41]=C_h_intern(&lf[41],17,"\003sysmodule-rename");
lf[42]=C_h_intern(&lf[42],15,"\003sysfind-export");
lf[43]=C_h_intern(&lf[43],26,"\003sysregister-syntax-export");
lf[44]=C_h_intern(&lf[44],26,"module-defined-syntax-list");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000!use of syntax precedes definition");
lf[46]=C_h_intern(&lf[46],22,"\003sysregister-undefined");
lf[47]=C_h_intern(&lf[47],19,"\003sysregister-module");
lf[48]=C_h_intern(&lf[48],25,"\003sysmark-imported-symbols");
lf[49]=C_h_intern(&lf[49],12,"\004corealiased");
lf[51]=C_h_intern(&lf[51],32,"\003syscompiled-module-registration");
lf[52]=C_h_intern(&lf[52],19,"module-import-forms");
lf[53]=C_h_intern(&lf[53],24,"module-meta-import-forms");
lf[54]=C_h_intern(&lf[54],10,"\003sysappend");
lf[55]=C_h_intern(&lf[55],5,"quote");
lf[56]=C_h_intern(&lf[56],15,"module-iexports");
lf[57]=C_h_intern(&lf[57],4,"list");
lf[58]=C_h_intern(&lf[58],4,"cons");
lf[59]=C_h_intern(&lf[59],16,"\003sysstrip-syntax");
lf[60]=C_h_intern(&lf[60],28,"\003sysregister-compiled-module");
lf[61]=C_h_intern(&lf[61],16,"\003sysfast-reverse");
lf[62]=C_h_intern(&lf[62],6,"import");
lf[63]=C_h_intern(&lf[63],4,"eval");
lf[64]=C_h_intern(&lf[64],22,"\003sysensure-transformer");
lf[65]=C_h_intern(&lf[65],9,"\003syserror");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\0000cannot find implementation of re-exported syntax");
lf[67]=C_h_intern(&lf[67],19,"\003sysprimitive-alias");
lf[68]=C_h_intern(&lf[68],14,"\004coreprimitive");
lf[69]=C_h_intern(&lf[69],18,"\003sysstring->symbol");
lf[70]=C_h_intern(&lf[70],17,"\003sysstring-append");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\002#%");
lf[72]=C_h_intern(&lf[72],29,"\003sysregister-primitive-module");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\0002unknown syntax referenced while registering module");
lf[74]=C_h_intern(&lf[74],19,"\003sysfinalize-module");
lf[75]=C_h_intern(&lf[75],7,"\004coredb");
lf[76]=C_h_intern(&lf[76],17,"get-output-string");
lf[77]=C_h_intern(&lf[77],7,"display");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\002)\047");
lf[79]=C_h_intern(&lf[79],5,"cadar");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\042\012Warning:    suggesting: `(import ");
lf[81]=C_h_intern(&lf[81],19,"\003syswrite-char/port");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\025\012Warning:    (import ");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\037\012Warning:    suggesting one of:");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\015\012Warning:    ");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\004 in:");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\052reference to possibly unbound identifier `");
lf[87]=C_h_intern(&lf[87],18,"open-output-string");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000$(internal) indirect export not found");
lf[89]=C_h_intern(&lf[89],13,"string-append");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\014 in module `");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[92]=C_h_intern(&lf[92],14,"symbol->string");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000!indirect export of syntax binding");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\033indirect reexport of syntax");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\042indirect export of unknown binding");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\021module unresolved");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\037exported identifier of module `");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\026\047 has not been defined");
lf[99]=C_h_intern(&lf[99],30,"\003sysfind-module/import-library");
lf[100]=C_h_intern(&lf[100],28,"\003syscurrent-meta-environment");
lf[101]=C_h_intern(&lf[101],19,"\003sysnotices-enabled");
lf[102]=C_h_intern(&lf[102],8,"\003sysload");
lf[103]=C_h_intern(&lf[103],26,"\003sysmeta-macro-environment");
lf[104]=C_h_intern(&lf[104],21,"\003syssyntax-error-hook");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000#cannot import from undefined module");
lf[106]=C_h_intern(&lf[106],18,"\003sysfind-extension");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\007.import");
lf[108]=C_h_intern(&lf[108],17,"\003sysexpand-import");
lf[109]=C_h_intern(&lf[109],16,"\004coremacro-alias");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[111]=C_h_intern(&lf[111],18,"\003syssymbol->string");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid prefix");
lf[113]=C_h_intern(&lf[113],8,"keyword\077");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\005srfi-");
lf[116]=C_h_intern(&lf[116],18,"\003sysnumber->string");
lf[117]=C_h_intern(&lf[117],16,"\003syscheck-syntax");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[119]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\037renamed identifier not imported");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000");
lf[122]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[124]=C_h_intern(&lf[124],10,"\003sysnotice");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000(re-importing already imported identifier");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000$re-importing already imported syntax");
lf[127]=C_h_intern(&lf[127],18,"\003sysmark-primitive");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000%`reexport\047 only valid inside a module");
lf[129]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[131]=C_h_intern(&lf[131],4,"srfi");
lf[132]=C_h_intern(&lf[132],6,"prefix");
lf[133]=C_h_intern(&lf[133],6,"except");
lf[134]=C_h_intern(&lf[134],6,"rename");
lf[135]=C_h_intern(&lf[135],4,"only");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[137]=C_h_intern(&lf[137],21,"\003sysalias-global-hook");
lf[138]=C_h_intern(&lf[138],27,"\003sysactive-eval-environment");
lf[139]=C_h_intern(&lf[139],21,"\003sysqualified-symbol\077");
lf[140]=C_h_intern(&lf[140],22,"\003sysregister-interface");
lf[141]=C_h_intern(&lf[141],14,"\004coreinterface");
lf[142]=C_h_intern(&lf[142],20,"\003sysvalidate-exports");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\021unknown interface");
lf[144]=C_h_intern(&lf[144],1,"x");
lf[145]=C_h_intern(&lf[145],1,"\052");
lf[146]=C_h_intern(&lf[146],7,"\000syntax");
lf[147]=C_h_intern(&lf[147],10,"\000interface");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid interface specification");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid export");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid export");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\017invalid exports");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\017invalid exports");
lf[153]=C_h_intern(&lf[153],20,"\003sysregister-functor");
lf[154]=C_h_intern(&lf[154],12,"\004corefunctor");
lf[155]=C_h_intern(&lf[155],23,"\003sysinstantiate-functor");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000/argument list mismatch in functor instantiation");
lf[157]=C_h_intern(&lf[157],11,"\004coremodule");
lf[158]=C_h_intern(&lf[158],21,"\004corelet-module-alias");
lf[159]=C_h_intern(&lf[159],26,"\003sysmatch-functor-argument");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000!instantation of undefined functor");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\021argument module `");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000$\047 does not match required signature\012");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\022in instantiation `");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\016\047 of functor `");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\0007\047, because the following required exports are missing:\012");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376"
"\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000"
"\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005"
"caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaa"
"r\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadad"
"r\376\003\000\000\002\376\001\000\000\006caddar\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdada"
"r\376\003\000\000\002\376\001\000\000\006cdaddr\376\003\000\000\002\376\001\000\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cdddd"
"r\376\003\000\000\002\376\001\000\000\010set-car!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\004lis"
"t\376\003\000\000\002\376\001\000\000\006length\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\007"
"reverse\376\003\000\000\002\376\001\000\000\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004assq\376\003\000\000\002\376\001\000\000\004assv\376"
"\003\000\000\002\376\001\000\000\005assoc\376\003\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\016string->symbol\376"
"\003\000\000\002\376\001\000\000\007number\077\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010compl"
"ex\077\376\003\000\000\002\376\001\000\000\010inexact\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\005zero\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001\000\000\005e"
"ven\077\376\003\000\000\002\376\001\000\000\011positive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\001+\376"
"\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376\001\000\000\001\052\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000"
"\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002"
"\376\001\000\000\003lcm\376\003\000\000\002\376\001\000\000\003abs\376\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000"
"\005round\376\003\000\000\002\376\001\000\000\016exact->inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log"
"\376\003\000\000\002\376\001\000\000\004expt\376\003\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asi"
"n\376\003\000\000\002\376\001\000\000\004acos\376\003\000\000\002\376\001\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000"
"\000\002\376\001\000\000\005char\077\376\003\000\000\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000"
"\000\002\376\001\000\000\007char<=\077\376\003\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000"
"\012char-ci>=\077\376\003\000\000\002\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespa"
"ce\077\376\003\000\000\002\376\001\000\000\015char-numeric\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\020char-lower-case\077\376\003"
"\000\000\002\376\001\000\000\013char-upcase\376\003\000\000\002\376\001\000\000\015char-downcase\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integ"
"er->char\376\003\000\000\002\376\001\000\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376"
"\003\000\000\002\376\001\000\000\011string>=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376"
"\003\000\000\002\376\001\000\000\013string-ci>\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\013make-s"
"tring\376\003\000\000\002\376\001\000\000\015string-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string-set!\376\003\000\000\002\376\001\000\000\015s"
"tring-append\376\003\000\000\002\376\001\000\000\013string-copy\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000"
"\000\002\376\001\000\000\011substring\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000"
"\002\376\001\000\000\012vector-ref\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\015v"
"ector-length\376\003\000\000\002\376\001\000\000\014vector->list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003"
"\000\000\002\376\001\000\000\012procedure\077\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\005force\376"
"\003\000\000\002\376\001\000\000\036call-with-current-continuation\376\003\000\000\002\376\001\000\000\013input-port\077\376\003\000\000\002\376\001\000\000\014output-por"
"t\077\376\003\000\000\002\376\001\000\000\022current-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\024call-with-i"
"nput-file\376\003\000\000\002\376\001\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-"
"output-file\376\003\000\000\002\376\001\000\000\020close-input-port\376\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\004load\376\003"
"\000\000\002\376\001\000\000\004read\376\003\000\000\002\376\001\000\000\013eof-object\077\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000"
"\005write\376\003\000\000\002\376\001\000\000\007display\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\024with-input"
"-from-file\376\003\000\000\002\376\001\000\000\023with-output-to-file\376\003\000\000\002\376\001\000\000\004eval\376\003\000\000\002\376\001\000\000\013char-ready\077\376\003\000\000\002\376"
"\001\000\000\011imag-part\376\003\000\000\002\376\001\000\000\011real-part\376\003\000\000\002\376\001\000\000\011magnitude\376\003\000\000\002\376\001\000\000\011numerator\376\003\000\000\002\376\001\000\000\013"
"denominator\376\003\000\000\002\376\001\000\000\031scheme-report-environment\376\003\000\000\002\376\001\000\000\020null-environment\376\003\000\000\002\376\001\000"
"\000\027interaction-environment\376\003\000\000\002\376\001\000\000\004else\376\377\016");
lf[168]=C_h_intern(&lf[168],29,"\003sysdefault-macro-environment");
lf[169]=C_h_intern(&lf[169],18,"module-environment");
lf[170]=C_h_intern(&lf[170],11,"environment");
lf[171]=C_h_intern(&lf[171],17,"register-feature!");
lf[172]=C_h_intern(&lf[172],19,"module-environments");
lf[173]=C_h_intern(&lf[173],4,"r5rs");
lf[174]=C_h_intern(&lf[174],6,"scheme");
lf[175]=C_h_intern(&lf[175],9,"r5rs-null");
lf[176]=C_h_intern(&lf[176],9,"r4rs-null");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\014dynamic-wind\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\377\016");
lf[178]=C_h_intern(&lf[178],4,"r4rs");
lf[179]=C_h_intern(&lf[179],14,"make-parameter");
C_register_lf2(lf,180,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2706,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:72: make-parameter */
t3=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_FALSE);}

/* k7580 in k7569 in loop in k7439 in instantiate-functor in k2708 in k2704 */
static void C_ccall f_7582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7582,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* loop in k4200 in k4287 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_fcall f_4108(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4108,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_caar(t2);
if(C_truep(C_i_assq(t3,((C_word*)t0)[2]))){
t4=t2;
t5=C_u_i_cdr(t4);
/* modules.scm:339: loop */
t17=t1;
t18=t5;
t1=t17;
t2=t18;
goto loop;}
else{
t4=C_i_caar(t2);
t5=t2;
t6=C_u_i_car(t5);
t7=C_u_i_car(t6);
t8=C_a_i_list(&a,2,lf[55],t7);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4150,a[2]=t9,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t11=t2;
t12=C_u_i_car(t11);
t13=C_u_i_cdr(t12);
/* modules.scm:342: ##sys#strip-syntax */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[59]+1)))(3,*((C_word*)lf[59]+1),t10,t13);}}}

/* k7325 in loop in validate-exports in k2708 in k2704 */
static void C_fcall f_7327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7327,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
/* modules.scm:802: iface */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7214(t3,((C_word*)t0)[4],t2);}
else{
/* modules.scm:803: err */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7208(t2,((C_word*)t0)[4],C_a_i_list(&a,3,lf[148],((C_word*)t0)[2],((C_word*)t0)[6]));}}

/* k7593 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7595,2,t0,t1);}
t2=t1;
t3=C_eqp(((C_word*)t0)[2],lf[145]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7602,a[2]=t5,a[3]=t2,a[4]=((C_word)li128),tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[2];
t8=C_i_check_list_2(t7,lf[30]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7628,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7707,a[2]=t11,a[3]=t6,a[4]=((C_word)li130),tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_7707(t13,t9,t7);}}

/* ##sys#match-functor-argument in k2708 in k2704 */
static void C_ccall f_7591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7591,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7595,a[2]=t5,a[3]=t1,a[4]=t6,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7732,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:841: ##sys#resolve-module-name */
t9=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t4,lf[3]);}

/* k4336 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:314: ##sys#fast-reverse */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[61]+1)))(3,*((C_word*)lf[61]+1),((C_word*)t0)[2],t1);}

/* k7777 in k7733 in k2708 in k2704 */
static void C_ccall f_7779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:900: ##sys#register-primitive-module */
t2=*((C_word*)lf[72]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[174],t1,((C_word*)t0)[3]);}

/* module-undefined-list in k2708 in k2704 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2805,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[3],lf[5]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(6)));}

/* k4318 in map-loop747 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_fcall f_4320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4320,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4291(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4291(t6,((C_word*)t0)[5],t5);}}

/* set-module-undefined-list! in k2708 in k2704 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2814,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* k6501 in map-loop1584 in k6394 in k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6503,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6474(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6474(t6,((C_word*)t0)[5],t5);}}

/* k5204 in k5201 in g1226 in k5196 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),((C_word*)t0)[3]);}

/* k5201 in g1226 in k5196 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* modules.scm:512: display */
t4=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* k6515 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_fixnump(t2))){
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=((C_word*)t0)[3];
f_5919(t6,C_i_nullp(t5));}
else{
t3=((C_word*)t0)[3];
f_5919(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_5919(t2,C_SCHEME_FALSE);}}

/* for-each-loop1225 in k5196 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5218,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5228,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:509: g1226 */
t5=((C_word*)t0)[3];
f_5199(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4880 in k4934 in k4910 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4882,2,t0,t1);}
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[3],lf[11]);
t3=C_i_block_ref(((C_word*)t0)[2],C_fix(10));
t4=C_i_check_structure_2(((C_word*)t0)[2],lf[3],lf[12]);
t5=C_i_block_ref(((C_word*)t0)[2],C_fix(11));
/* modules.scm:419: merge-se */
f_3973(((C_word*)t0)[3],C_a_i_list(&a,3,t1,t3,t5));}

/* loop in resolve-module-name in k2708 in k2704 */
static void C_fcall f_3082(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3082,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3117,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* modules.scm:133: ##sys#module-alias-environment */
t5=*((C_word*)lf[1]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k4876 in k4872 in k4934 in k4910 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4878,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_i_check_structure_2(((C_word*)t0)[3],lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t4=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(13),t2);}

/* k4872 in k4934 in k4910 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4878,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:422: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t3);}

/* k3422 in k3418 in k3379 in k3373 in k3370 in k3367 in register-export in k2708 in k2704 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:199: check-for-redef */
t2=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k3418 in k3379 in k3373 in k3370 in k3367 in register-export in k2708 in k2704 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3420,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:199: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t3);}

/* g439 in k3115 in loop in resolve-module-name in k2708 in k2704 */
static void C_fcall f_3090(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3090,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_memq(t3,((C_word*)t0)[2]))){
/* modules.scm:137: error */
t4=*((C_word*)lf[19]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[3],lf[20],((C_word*)t0)[4]);}
else{
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* modules.scm:138: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3082(t5,t1,t3,t4);}}

/* k5000 in map-loop1033 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5002,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4973(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4973(t6,((C_word*)t0)[5],t5);}}

/* ##sys#register-primitive-module in k2708 in k2704 */
static void C_ccall f_4845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4845r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4845r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4845r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_i_car(t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4852,a[2]=t3,a[3]=t2,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:400: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t8);}

/* ##sys#find-export in k2708 in k2704 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5014,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=C_i_check_structure_2(t5,lf[3],lf[10]);
t7=C_i_block_ref(t5,C_fix(2));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5025,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=C_eqp(C_SCHEME_TRUE,t7);
if(C_truep(t9)){
t10=t3;
t11=C_i_check_structure_2(t10,lf[3],lf[29]);
t12=t8;
f_5025(t12,C_i_block_ref(t10,C_fix(4)));}
else{
t10=t8;
f_5025(t10,t7);}}

/* k4850 in register-primitive-module in k2708 in k2704 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4852,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t0)[2];
t8=C_i_check_list_2(t7,lf[16]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4912,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4973,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_4973(t13,t9,t7);}

/* k4856 in k4934 in k4910 in k4850 in register-primitive-module in k2708 in k2704 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4858,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,*((C_word*)lf[22]+1));
t4=C_mutate2((C_word*)lf[22]+1 /* (set! ##sys#module-table ...) */,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* k3879 in g666 in k3965 in loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3881,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3864(t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* loop in k5023 in find-export in k2708 in k2704 */
static void C_fcall f_5027(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5027,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_i_car(t2);
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t2;
t6=C_u_i_car(t5);
if(C_truep(C_i_pairp(t6))){
t7=C_i_caar(t2);
t8=C_eqp(((C_word*)t0)[2],t7);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5055,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t10=t2;
t11=C_u_i_car(t10);
t12=C_u_i_cdr(t11);
t13=t9;
f_5055(t13,C_i_memq(((C_word*)t0)[2],t12));}
else{
t10=t9;
f_5055(t10,C_SCHEME_FALSE);}}}
else{
t7=t2;
t8=C_u_i_cdr(t7);
/* modules.scm:435: loop */
t16=t1;
t17=t8;
t1=t16;
t2=t17;
goto loop;}}}}

/* k5023 in find-export in k2708 in k2704 */
static void C_fcall f_5025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5025,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5027(t5,((C_word*)t0)[4],t1);}

/* k3862 in g666 in k3965 in loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_3864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3864,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* modules.scm:283: loop2 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3819(t6,t3,t5);}

/* map-loop747 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_fcall f_4291(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4291,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_cdr(t4);
if(C_truep(C_i_symbolp(t5))){
t6=C_u_i_car(t4);
t7=C_u_i_cdr(t4);
t8=C_a_i_cons(&a,2,t6,t7);
t9=t3;
f_4320(t9,C_a_i_list(&a,2,lf[55],t8));}
else{
t6=C_u_i_car(t4);
t7=C_a_i_list(&a,2,lf[55],t6);
t8=C_a_i_list(&a,2,lf[55],C_SCHEME_END_OF_LIST);
t9=C_u_i_cdr(t4);
t10=t3;
f_4320(t10,C_a_i_list(&a,4,lf[57],t7,t8,t9));}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3866 in k3862 in g666 in k3965 in loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* g673 in k3955 in k3965 in loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_3896(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3896,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_symbolp(t3))){
t4=C_i_car(((C_word*)t0)[2]);
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,t4,t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3914,a[2]=t1,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
/* modules.scm:287: loop2 */
t12=((C_word*)((C_word*)t0)[3])[1];
f_3819(t12,t9,t11);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(((C_word*)t0)[2]);
/* modules.scm:289: warn */
t6=((C_word*)t0)[4];
f_3769(t6,t4,lf[94],t5);}}

/* k4812 in map-loop854 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4814,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4785(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4785(t6,((C_word*)t0)[5],t5);}}

/* k4287 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4289,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[57],t1);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_i_check_structure_2(t4,lf[3],lf[11]);
t6=C_i_block_ref(t4,C_fix(10));
t7=C_a_i_list(&a,2,lf[55],t6);
t8=t7;
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4162,a[2]=((C_word*)t0)[3],a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t14=C_i_check_list_2(((C_word*)t0)[4],lf[16]);
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4202,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t8,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4204,a[2]=t12,a[3]=t17,a[4]=t10,a[5]=t13,a[6]=((C_word)li33),tmp=(C_word)a,a+=7,tmp));
t19=((C_word*)t17)[1];
f_4204(t19,t15,((C_word*)t0)[4]);}

/* k4626 in k4600 in k4566 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4628,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,*((C_word*)lf[22]+1));
t4=C_mutate2((C_word*)lf[22]+1 /* (set! ##sys#module-table ...) */,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* k3652 in for-each-loop608 in mark-imported-symbols in k2708 in k2704 */
static void C_fcall f_3654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3654,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_putprop(&a,3,t2,lf[49],C_SCHEME_TRUE));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4613 in g982 in k4600 in k4566 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_car(((C_word*)t0)[3],t1));}

/* ##sys#mark-imported-symbols in k2708 in k2704 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3645,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[30]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3690,a[2]=t5,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3690(t7,t1,t2);}

/* k4600 in k4566 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4603,a[2]=((C_word*)t0)[2],a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(((C_word*)t0)[3],lf[30]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4638,a[2]=t6,a[3]=t2,a[4]=((C_word)li40),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4638(t8,t4,((C_word*)t0)[3]);}

/* g982 in k4600 in k4566 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_fcall f_4603(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4603,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4615,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cadr(t2);
if(C_truep(t6)){
/* modules.scm:387: merge-se */
f_3973(t5,C_a_i_list(&a,2,t6,((C_word*)t0)[2]));}
else{
/* modules.scm:387: merge-se */
f_3973(t5,C_a_i_list(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}}

/* map-loop397 in with-module-aliases in k2708 in k2704 */
static void C_fcall f_3041(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3041,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_i_cadr(t3);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t8=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t7);
t9=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t7);
t10=C_slot(t2,C_fix(1));
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t7);
t9=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t7);
t10=C_slot(t2,C_fix(1));
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6299 in g1570 in loop in k6217 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:646: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6228(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],t1);}

/* for-each-loop494 in k3240 in add-to-export-list in k2708 in k2704 */
static void C_fcall f_3285(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3285,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_3243(C_a_i(&a,3),((C_word*)t0)[2],t3);
t5=C_slot(t2,C_fix(1));
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1574 in loop in k6217 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6338(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6338,NULL,3,t0,t1,t2);}
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=C_i_cadr(t2);
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_a_i_cons(&a,2,t5,t6);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6354,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:656: ##sys#delq */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t10,t2,((C_word*)t0)[7]);}

/* ##sys#resolve-module-name in k2708 in k2704 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3076,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3082,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3082(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* k7311 in loop in validate-exports in k2708 in k2704 */
static void C_ccall f_7313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7313,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k3273 in k3266 in k3263 in k3240 in add-to-export-list in k2708 in k2704 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=C_i_check_structure_2(t3,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t3,C_fix(4),t1);}

/* k3277 in k3263 in k3240 in add-to-export-list in k2708 in k2704 */
static void C_ccall f_3279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_i_check_structure_2(t2,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t4=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t2,C_fix(11),t1);}

/* k3263 in k3240 in add-to-export-list in k2708 in k2704 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3279,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_i_check_structure_2(t4,lf[3],lf[12]);
t6=C_i_block_ref(t4,C_fix(11));
/* modules.scm:173: append */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,((C_word*)((C_word*)t0)[6])[1],t6);}

/* k3266 in k3263 in k3240 in add-to-export-list in k2708 in k2704 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:174: append */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* g511 in k3240 in add-to-export-list in k2708 in k2704 */
static C_word C_fcall f_3251(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_overflow_check;
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}

/* loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_3819(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3819,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_i_cdr(((C_word*)t0)[2]);
/* modules.scm:273: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3792(t4,t1,t3);}
else{
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3967,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* modules.scm:274: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t5);}}

/* k4461 in map-loop854 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4463,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list3(&a,3,((C_word*)t0)[3],C_SCHEME_FALSE,t1));}

/* k3240 in add-to-export-list in k2708 in k2704 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3242,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3251,a[2]=t4,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3243,a[2]=t2,a[3]=t5,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[2];
t8=C_i_check_list_2(t7,lf[30]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3285,a[2]=t6,a[3]=t11,a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_3285(t13,t9,t7);}

/* g495 in k3240 in add-to-export-list in k2708 in k2704 */
static C_word C_fcall f_3243(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_overflow_check;
t2=C_i_assq(t1,((C_word*)t0)[2]);
if(C_truep(t2)){
return(f_3251(C_a_i(&a,3),((C_word*)t0)[3],t2));}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* ##sys#register-syntax-export in k2708 in k2704 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3448,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t3;
t6=C_i_check_structure_2(t5,lf[3],lf[10]);
t7=C_i_block_ref(t5,C_fix(2));
t8=C_eqp(C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3458,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_3458(2,t10,t8);}
else{
/* modules.scm:211: ##sys#find-export */
t10=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,t2,t3,C_SCHEME_TRUE);}}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k4692 in for-each-loop939 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4684(t3,((C_word*)t0)[4],t2);}

/* k3433 in k3370 in k3367 in register-export in k2708 in k2704 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:194: ##sys#toplevel-definition-hook */
t2=*((C_word*)lf[31]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3],((C_word*)t0)[4],C_SCHEME_FALSE);}

/* k3429 in k3373 in k3370 in k3367 in register-export in k2708 in k2704 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:198: set-module-undefined-list! */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k4094 in k4200 in k4287 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4092(t2,C_a_i_cons(&a,2,lf[57],t1));}

/* k4090 in k4200 in k4287 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_fcall f_4092(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4092,NULL,2,t0,t1);}
t2=C_a_i_list(&a,6,lf[60],((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);
t3=C_a_i_list(&a,1,t2);
/* modules.scm:306: ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[6],((C_word*)t0)[7],t3);}

/* k7510 in k7439 in instantiate-functor in k2708 in k2704 */
static void C_ccall f_7512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7512,2,t0,t1);}
t2=C_eqp(lf[145],((C_word*)t0)[2]);
t3=(C_truep(t2)?C_a_i_cons(&a,2,C_SCHEME_TRUE,((C_word*)t0)[3]):C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]));
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,lf[157],t4);
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,3,lf[158],t1,t5));}

/* k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[2];
t4=C_i_check_structure_2(t3,lf[3],lf[4]);
t5=C_i_block_ref(t3,C_fix(1));
t6=C_a_i_list(&a,2,lf[55],t5);
t7=t6;
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t0)[2];
t13=C_i_check_structure_2(t12,lf[3],lf[56]);
t14=C_i_block_ref(t12,C_fix(12));
t15=C_i_check_list_2(t14,lf[16]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t7,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4291,a[2]=t11,a[3]=t18,a[4]=t9,a[5]=((C_word)li34),tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_4291(t20,t16,t14);}

/* k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_5910(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5910,NULL,2,t0,t1);}
if(C_truep(t1)){
/* modules.scm:603: ##sys#syntax-error-hook */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[104]+1)))(5,*((C_word*)lf[104]+1),((C_word*)t0)[2],((C_word*)t0)[3],lf[114],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5919,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[4]);
/* modules.scm:604: c */
t5=((C_word*)t0)[9];
((C_proc4)C_fast_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[14],t4);}}

/* k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_5919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5919,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5930,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5934,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[4]);
/* modules.scm:607: ##sys#number->string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),t4,t5);}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5944,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5954,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word)li96),tmp=(C_word)a,a+=13,tmp);
/* modules.scm:609: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t4,t5);}}

/* k4058 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:306: ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* loop in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(17);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5500,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
t4=C_i_symbolp(t3);
t5=(C_truep(t4)?t3:C_i_car(t3));
t6=t5;
if(C_truep(C_i_assq(t6,((C_word*)t0)[2]))){
t7=t2;
t8=C_u_i_cdr(t7);
/* modules.scm:463: loop */
t16=t1;
t17=t8;
t1=t16;
t2=t17;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5531,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=C_i_assq(t6,((C_word*)t0)[4]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5544,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5547,a[2]=t9,a[3]=t7,a[4]=t6,a[5]=t10,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t9)){
t12=C_i_cdr(t9);
t13=t11;
f_5547(t13,C_i_symbolp(t12));}
else{
t12=t11;
f_5547(t12,C_SCHEME_FALSE);}}}}

/* k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5722,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* modules.scm:570: ##sys#meta-macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[103]+1)))(2,*((C_word*)lf[103]+1),t4);}

/* k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5725,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t5,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word)li72),tmp=(C_word)a,a+=12,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5759,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5765,a[2]=((C_word*)t0)[12],a[3]=((C_word)li76),tmp=(C_word)a,a+=4,tmp);
/* modules.scm:565: ##sys#dynamic-wind */
t9=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,t6,t8,t6);}

/* swap1333 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* modules.scm:565: current-module13351336 */
t3=((C_word*)t0)[10];
((C_proc2)C_fast_retrieve_proc(t3))(2,t3,t2);}

/* ##sys#primitive-alias in k2708 in k2704 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4826,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4830,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4839,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_slot(t2,C_fix(1));
/* modules.scm:395: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[70]+1)))(4,*((C_word*)lf[70]+1),t4,lf[71],t5);}

/* k3468 in k3465 in k3459 in k3456 in register-syntax-export in k2708 in k2704 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
t5=C_i_check_structure_2(t4,lf[3],lf[39]);
t6=C_i_block_ref(t4,C_fix(3));
t7=C_a_i_cons(&a,2,t3,t6);
t8=((C_word*)t0)[4];
t9=C_i_check_structure_2(t8,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t10=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t2,t8,C_fix(3),t7);}
else{
t3=t2;
f_3476(2,t3,C_SCHEME_UNDEFINED);}}

/* k3474 in k3468 in k3465 in k3459 in k3456 in register-syntax-export in k2708 in k2704 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3476,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
t4=C_i_check_structure_2(t3,lf[3],lf[44]);
t5=C_i_block_ref(t3,C_fix(5));
t6=C_a_i_cons(&a,2,t2,t5);
t7=((C_word*)t0)[5];
t8=((C_word*)t0)[4];
t9=C_i_check_structure_2(t8,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t10=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t8,C_fix(5),t6);}

/* loop in k7439 in instantiate-functor in k2708 in k2704 */
static void C_fcall f_7533(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7533,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
/* modules.scm:826: merr */
t4=((C_word*)t0)[2];
f_7451(t4,t1);}}
else{
if(C_truep(C_i_nullp(t3))){
/* modules.scm:827: merr */
t4=((C_word*)t0)[2];
f_7451(t4,t1);}
else{
t4=C_i_car(t3);
t5=C_i_car(t4);
t6=t5;
t7=C_i_car(t2);
t8=t7;
t9=C_u_i_cdr(t4);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7571,a[2]=t6,a[3]=t8,a[4]=t1,a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:833: ##sys#match-functor-argument */
t11=*((C_word*)lf[159]+1);
((C_proc7)(void*)(*((C_word*)t11+1)))(7,t11,t10,t6,((C_word*)t0)[4],t8,t9,((C_word*)t0)[5]);}}}

/* for-each-loop608 in mark-imported-symbols in k2708 in k2704 */
static void C_fcall f_3690(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3690,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3700,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3654,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(t6);
if(C_truep(C_i_symbolp(t8))){
t9=C_u_i_car(t6);
t10=C_u_i_cdr(t6);
t11=C_eqp(t9,t10);
t12=t7;
f_3654(t12,C_i_not(t11));}
else{
t9=t7;
f_3654(t9,C_SCHEME_FALSE);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4046 in compiled-module-registration in k2708 in k2704 */
static void C_fcall f_4048(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4048,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4056,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4387,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:313: ##sys#strip-syntax */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[59]+1)))(3,*((C_word*)lf[59]+1),t5,((C_word*)t0)[6]);}
else{
t5=t4;
f_4056(t5,C_SCHEME_END_OF_LIST);}}

/* g1294 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5341(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5341,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5345,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(t2);
/* modules.scm:532: merge-se */
f_3973(t3,C_a_i_list(&a,2,t4,((C_word*)t0)[2]));}

/* k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5341,a[2]=((C_word*)t0)[2],a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(((C_word*)t0)[3],lf[30]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5363,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5404,a[2]=t6,a[3]=t2,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5404(t8,t4,((C_word*)t0)[3]);}

/* k5343 in g1294 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_set_car(t3,t1));}

/* k4837 in primitive-alias in k2708 in k2704 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:394: ##sys#string->symbol */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[69]+1)))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],t1);}

/* k4828 in primitive-alias in k2708 in k2704 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_a_i_putprop(&a,3,t1,lf[68],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* k3459 in k3456 in register-syntax-export in k2708 in k2704 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3461,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_i_check_structure_2(t2,lf[3],lf[4]);
t4=C_i_block_ref(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3467,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_assq(((C_word*)t0)[3],t1))){
/* modules.scm:215: ##sys#warn */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),t5,lf[45],((C_word*)t0)[3]);}
else{
t6=t5;
f_3467(2,t6,C_SCHEME_UNDEFINED);}}

/* k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_fcall f_4056(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4056,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=*((C_word*)lf[59]+1);
t10=((C_word*)t0)[3];
t11=C_i_check_structure_2(t10,lf[3],lf[33]);
t12=C_i_block_ref(t10,C_fix(9));
t13=C_i_check_list_2(t12,lf[16]);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4338,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4340,a[2]=t8,a[3]=t16,a[4]=t6,a[5]=t9,a[6]=((C_word)li35),tmp=(C_word)a,a+=7,tmp));
t18=((C_word*)t16)[1];
f_4340(t18,t14,t12);}

/* k3465 in k3459 in k3456 in register-syntax-export in k2708 in k2704 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3510,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:216: ##sys#current-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(2,*((C_word*)lf[26]+1),t3);}

/* k4407 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[62],t1);
t3=C_a_i_list(&a,2,lf[55],t2);
t4=C_a_i_list(&a,2,lf[63],t3);
t5=((C_word*)t0)[2];
f_4048(t5,C_a_i_list(&a,1,t4));}

/* for-each-loop981 in k4600 in k4566 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_fcall f_4638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4638,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4648,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:385: g982 */
t5=((C_word*)t0)[3];
f_4603(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4050 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:306: ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k5183 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5195,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:505: cadar */
t4=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k5186 in k5183 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:506: display */
t2=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[78],((C_word*)t0)[3]);}

/* k3456 in register-syntax-export in k2708 in k2704 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3458,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* modules.scm:212: module-undefined-list */
t4=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4646 in for-each-loop981 in k4600 in k4566 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4638(t3,((C_word*)t0)[4],t2);}

/* k5193 in k5183 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:505: display */
t2=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k5196 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[2],a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5218,a[2]=t4,a[3]=t2,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5218(t6,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* g1226 in k5196 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5199(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5199,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5203,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:511: display */
t4=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[82],((C_word*)t0)[2]);}

/* map-loop1722 in k6759 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6817(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6817,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5161,2,t0,t1);}
t2=C_i_getprop(((C_word*)t0)[2],lf[75],C_SCHEME_FALSE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=C_i_length(t3);
t6=C_eqp(C_fix(1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5185,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:504: display */
t8=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[80],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:508: display */
t8=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[83],((C_word*)t0)[4]);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8231,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:515: get-output-string */
t6=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}}

/* k5167 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5176,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:515: get-output-string */
t3=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* ##sys#register-compiled-module in k2708 in k2704 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr6r,(void*)f_4411r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_4411r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_4411r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(19);
t7=C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_car(t6));
t9=t8;
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_i_check_list_2(t5,lf[16]);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4473,a[2]=t3,a[3]=t9,a[4]=t2,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4785,a[2]=t13,a[3]=t17,a[4]=t11,a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_4785(t19,t15,t5);}

/* k4439 in map-loop854 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=C_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* modules.scm:351: ##sys#error */
t4=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[62],lf[66],((C_word*)t0)[2]);}}
else{
/* modules.scm:351: ##sys#error */
t3=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[62],lf[66],((C_word*)t0)[2]);}}

/* k5174 in k5167 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:515: ##sys#warn */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),((C_word*)t0)[2],t1);}

/* k4492 in map-loop882 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4494,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list3(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k4669 in for-each-loop960 in k4566 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4661(t3,((C_word*)t0)[4],t2);}

/* k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5148,2,t0,t1);}
t2=t1;
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5152,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:492: display */
t5=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[86],t2);}

/* g1481 in loop in k5971 in k5962 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_5995(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5995,NULL,3,t0,t1,t2);}
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
/* modules.scm:618: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5978(t5,t1,t3,t4,((C_word*)t0)[5]);}

/* k5361 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=C_i_check_structure_2(t3,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t3,C_fix(10),((C_word*)t0)[4]);}

/* k5367 in k5361 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=C_i_check_structure_2(t3,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t3,C_fix(11),((C_word*)t0)[5]);}

/* for-each-loop939 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_fcall f_4684(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4684,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4694,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:376: g940 */
t5=((C_word*)t0)[3];
f_4543(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6863 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(2),t1);}

/* k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:493: display */
t3=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[4]);}

/* k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:496: display */
t4=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[85],((C_word*)t0)[4]);}
else{
t3=t2;
f_5161(2,t3,C_SCHEME_UNDEFINED);}}

/* k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5961,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:612: ##sys#check-syntax */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[117]+1)))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[8],((C_word*)t0)[3],lf[118]);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* modules.scm:623: c */
t3=((C_word*)t0)[10];
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[14],((C_word*)t0)[12]);}}

/* k5370 in k5367 in k5361 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5398,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_i_check_structure_2(t4,lf[3],lf[56]);
t6=C_i_block_ref(t4,C_fix(12));
/* modules.scm:547: merge-se */
f_3973(t3,C_a_i_list(&a,2,t6,((C_word*)t0)[6]));}

/* k5962 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5964,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)((C_word*)t0)[2])[1];
t7=C_i_cddr(((C_word*)t0)[3]);
t8=C_i_check_list_2(t7,lf[16]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5973,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6045,a[2]=t5,a[3]=t11,a[4]=t3,a[5]=t6,a[6]=((C_word)li85),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_6045(t13,t9,t7);}

/* k5373 in k5370 in k5367 in k5361 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5394,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:550: ##sys#current-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(2,*((C_word*)lf[26]+1),t3);}

/* k6852 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(11),t1);}

/* k4471 in register-compiled-module in k2708 in k2704 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4473,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t0)[2];
t8=C_i_check_list_2(t7,lf[16]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4750,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=((C_word)li44),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_4750(t13,t9,t7);}

/* loop in k5971 in k5962 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_5978(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5978,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
/* modules.scm:615: values */
C_values(5,0,t1,t3,t4,((C_word*)t0)[2]);}
else{
t5=C_i_car(t2);
t6=C_i_assq(t5,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5995,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word)li82),tmp=(C_word)a,a+=7,tmp);
/* modules.scm:613: g1481 */
t8=t7;
f_5995(t8,t1,t6);}
else{
t7=t2;
t8=C_u_i_car(t7);
t9=C_i_assq(t8,((C_word*)t0)[5]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6017,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li83),tmp=(C_word)a,a+=7,tmp);
/* modules.scm:613: g1485 */
t11=t10;
f_6017(t11,t1,t9);}
else{
t10=t2;
t11=C_u_i_cdr(t10);
/* modules.scm:622: loop */
t15=t1;
t16=t11;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}}

/* k4231 in map-loop780 in k4287 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4233,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4204(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4204(t6,((C_word*)t0)[5],t5);}}

/* k5971 in k5962 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5973,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word)li84),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5978(t5,((C_word*)t0)[5],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* for-each-loop960 in k4566 in k4540 in k4537 in k4531 in k4508 in k4471 in register-compiled-module in k2708 in k2704 */
static void C_fcall f_4661(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4661,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4671,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:380: g961 */
t5=((C_word*)t0)[3];
f_4569(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a5781 in a5764 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5782,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[101]+1));
t3=C_mutate2((C_word*)lf[101]+1 /* (set! ##sys#notices-enabled ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a5943 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5944,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* modules.scm:610: import-spec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5891(t3,t1,t2);}

/* k5790 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:562: ##sys#find-extension */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[106]+1)))(4,*((C_word*)lf[106]+1),((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k6689 in k6682 in k6679 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:736: macro-env */
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}

/* k5794 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[70]+1)))(4,*((C_word*)lf[70]+1),((C_word*)t0)[2],t1,lf[107]);}

/* ##sys#expand-import in k2708 in k2704 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_5799,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5803,a[2]=t9,a[3]=t4,a[4]=t5,a[5]=t6,a[6]=t8,a[7]=t2,a[8]=t1,a[9]=t7,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* modules.scm:581: r */
t11=t3;
((C_proc3)C_fast_retrieve_proc(t11))(3,t11,t10,lf[135]);}

/* k6697 in k6679 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:735: import-env */
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}

/* k6693 in k6682 in k6679 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:736: append */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5954,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=t3;
t7=t4;
t8=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t5,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],tmp=(C_word)a,a+=15,tmp);
/* modules.scm:611: c */
t9=((C_word*)t0)[6];
((C_proc4)C_fast_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[11],((C_word*)t0)[8]);}

/* k5542 in loop in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5531(t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k5545 in loop in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5547,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_5531(t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5597,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:470: ##sys#current-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(2,*((C_word*)lf[26]+1),t2);}}

/* k5761 in k5757 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k3840 in k3965 in loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* modules.scm:276: loop2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3819(t4,((C_word*)t0)[4],t3);}

/* a5764 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5765,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5771,a[2]=t5,a[3]=t3,a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[2],a[3]=((C_word)li74),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5782,a[2]=t3,a[3]=t5,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp);
/* modules.scm:565: ##sys#dynamic-wind */
t9=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* k5924 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:605: import-name */
f_5869(((C_word*)t0)[3],t1);}

/* k5595 in k5545 in loop in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5597,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5559,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=C_i_cdr(t3);
t6=t4;
f_5559(t6,C_i_symbolp(t5));}
else{
t5=t4;
f_5559(t5,C_SCHEME_FALSE);}}

/* a5770 in a5764 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5771,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[101]+1));
t3=C_mutate2((C_word*)lf[101]+1 /* (set! ##sys#notices-enabled ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a5775 in a5764 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5776,2,t0,t1);}
/* modules.scm:572: ##sys#load */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[102]+1)))(5,*((C_word*)lf[102]+1),t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k5384 in k5373 in k5370 in k5367 in k5361 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5386,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5390,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:551: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t3);}

/* k5928 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:606: ##sys#intern-symbol */
C_string_to_symbol(3,0,((C_word*)t0)[2],t1);}

/* k5932 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:607: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[70]+1)))(4,*((C_word*)lf[70]+1),((C_word*)t0)[2],lf[115],t1);}

/* k5742 in k5738 in k5735 in k5731 in k5728 in swap1333 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5744,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5747,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:565: current-meta-environment13391340 */
t4=((C_word*)t0)[7];
((C_proc4)C_fast_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}

/* k5738 in k5735 in k5731 in k5728 in swap1333 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5740,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5744,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:565: current-meta-environment13391340 */
t4=((C_word*)t0)[9];
((C_proc2)C_fast_retrieve_proc(t4))(2,t4,t3);}

/* k5745 in k5742 in k5738 in k5735 in k5731 in k5728 in swap1333 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5747,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5751,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:565: macro-environment13411342 */
t4=((C_word*)t0)[7];
((C_proc2)C_fast_retrieve_proc(t4))(2,t4,t3);}

/* k5392 in k5373 in k5370 in k5367 in k5361 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5394,2,t0,t1);}
/* modules.scm:550: merge-se */
f_3973(((C_word*)t0)[2],C_a_i_list(&a,3,t1,((C_word*)t0)[3],((C_word*)t0)[4]));}

/* k5388 in k5384 in k5373 in k5370 in k5367 in k5361 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5390,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=C_i_check_structure_2(t4,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t6=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,C_fix(13),t2);}

/* k5396 in k5370 in k5367 in k5361 in k5338 in k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_i_check_structure_2(t2,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t4=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t2,C_fix(12),t1);}

/* k6265 in for-each-loop1552 in loop in k6217 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6257(t3,((C_word*)t0)[4],t2);}

/* k5573 in k5557 in k5595 in k5545 in loop in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5575,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5531(t2,C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_FALSE));}

/* k5577 in k5557 in k5595 in k5545 in loop in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:476: ##sys#warn */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* map-loop1447 in k5962 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6045,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6074,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:613: g1453 */
t5=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5752 in k5749 in k5745 in k5742 in k5738 in k5735 in k5731 in k5728 in swap1333 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5749 in k5745 in k5742 in k5738 in k5735 in k5731 in k5728 in swap1333 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5751,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5754,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:565: macro-environment13411342 */
t4=((C_word*)t0)[5];
((C_proc4)C_fast_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]);}

/* k5757 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:573: ##sys#find-module */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[62]);}

/* g666 in k3965 in loop2 in loop in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_3856(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3856,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3864,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)t0)[2]);
t5=t4;
t6=C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3881,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t6)){
t8=t3;
f_3864(t8,C_a_i_cons(&a,2,t5,t6));}
else{
t8=((C_word*)t0)[2];
t9=C_u_i_car(t8);
/* modules.scm:282: ##sys#module-rename */
t10=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t9,((C_word*)t0)[4]);}}

/* k6250 in loop in k6217 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:643: values */
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* for-each-loop1552 in loop in k6217 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6257(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6257,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6267,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:641: ##sys#warn */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),t3,lf[120],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5557 in k5595 in k5545 in loop in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5559(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5559,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_5531(t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}
else{
if(C_truep(((C_word*)t0)[5])){
/* modules.scm:483: ##sys#module-rename */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t2=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5579,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5583,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:479: symbol->string */
t6=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[7]);}}}

/* k5731 in k5728 in swap1333 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5733,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5737,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* modules.scm:565: current-environment13371338 */
t4=((C_word*)t0)[11];
((C_proc2)C_fast_retrieve_proc(t4))(2,t4,t3);}

/* k5728 in swap1333 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5730,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5733,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* modules.scm:565: current-module13351336 */
t4=((C_word*)t0)[11];
((C_proc4)C_fast_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[6])[1]);}

/* k5735 in k5731 in k5728 in swap1333 in k5723 in k5720 in k5714 in k5708 in k5705 in find-module/import-library in k2708 in k2704 */
static void C_ccall f_5737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5737,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5740,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* modules.scm:565: current-environment13371338 */
t4=((C_word*)t0)[9];
((C_proc4)C_fast_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[5])[1]);}

/* k6094 in k6085 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6096,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6101,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word)li87),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_6101(t6,((C_word*)t0)[4],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k5533 in k5529 in loop in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k5529 in loop in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5531,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5535,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* modules.scm:484: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5500(t6,t3,t5);}

/* k6085 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6087,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)((C_word*)t0)[2])[1];
t7=C_i_cddr(((C_word*)t0)[3]);
t8=C_i_check_list_2(t7,lf[16]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6096,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6177,a[2]=t5,a[3]=t11,a[4]=t3,a[5]=t6,a[6]=((C_word)li88),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_6177(t13,t9,t7);}

/* k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6084,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:624: ##sys#check-syntax */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[117]+1)))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[8],((C_word*)t0)[3],lf[119]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* modules.scm:634: c */
t3=((C_word*)t0)[10];
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[13],((C_word*)t0)[12]);}}

/* k3002 in k2999 in swap387 in k2994 in with-module-aliases in k2708 in k2704 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2999 in swap387 in k2994 in with-module-aliases in k2708 in k2704 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3001,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3004,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:124: module-alias-environment389390 */
t4=((C_word*)t0)[5];
((C_proc4)C_fast_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]);}

/* k6072 in map-loop1447 in k5962 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6074,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6045(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6045(t6,((C_word*)t0)[5],t5);}}

/* k6679 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6681(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6681,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6699,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6703,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:735: import-env */
t5=((C_word*)t0)[5];
((C_proc2)C_fast_retrieve_proc(t5))(2,t5,t4);}

/* k3037 in k3033 in with-module-aliases in k2708 in k2704 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:126: append */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k6682 in k6679 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6695,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:736: macro-env */
t4=((C_word*)t0)[2];
((C_proc2)C_fast_retrieve_proc(t4))(2,t4,t3);}

/* k3033 in with-module-aliases in k2708 in k2704 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3035,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:128: ##sys#module-alias-environment */
t4=*((C_word*)lf[1]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* loop in validate-exports in k2708 in k2704 */
static void C_fcall f_7255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
loop:
a=C_alloc(11);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7255,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(t2);
t4=t3;
if(C_truep(C_i_symbolp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7287,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=C_u_i_cdr(t6);
/* modules.scm:795: loop */
t23=t5;
t24=t7;
t1=t23;
t2=t24;
goto loop;}
else{
if(C_truep(C_i_listp(t4))){
t5=C_i_car(t4);
t6=C_eqp(lf[146],t5);
if(C_truep(t6)){
t7=C_u_i_cdr(t4);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7313,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=t2;
t10=C_u_i_cdr(t9);
/* modules.scm:799: loop */
t23=t8;
t24=t10;
t1=t23;
t2=t24;
goto loop;}
else{
t7=C_u_i_car(t4);
t8=C_eqp(lf[147],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7327,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t10=C_u_i_cdr(t4);
if(C_truep(C_i_pairp(t10))){
t11=C_i_cadr(t4);
t12=t9;
f_7327(t12,C_i_symbolp(t11));}
else{
t11=t9;
f_7327(t11,C_SCHEME_FALSE);}}
else{
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7354,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t10,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li119),tmp=(C_word)a,a+=9,tmp));
t12=((C_word*)t10)[1];
f_7354(t12,t1,t4);}}}
else{
/* modules.scm:797: err */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7208(t5,t1,C_a_i_list(&a,3,lf[150],t4,((C_word*)t0)[5]));}}}
else{
/* modules.scm:792: err */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7208(t3,t1,C_a_i_list(&a,2,lf[151],((C_word*)t0)[5]));}}}

/* g1570 in loop in k6217 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6285(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6285,NULL,3,t0,t1,t2);}
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=C_i_cadr(t2);
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_a_i_cons(&a,2,t5,t6);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6301,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t9,tmp=(C_word)a,a+=8,tmp);
/* modules.scm:649: ##sys#delq */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t10,t2,((C_word*)t0)[7]);}

/* k6670 in g1699 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_i_cdr(t2);
t6=C_eqp(t4,t5);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[3];
t8=C_u_i_car(t7);
/* modules.scm:704: ##sys#notice */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),((C_word*)t0)[4],lf[126],t8);}}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[7])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6706,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[8])){
t4=t3;
f_6706(2,t4,C_SCHEME_UNDEFINED);}
else{
/* modules.scm:708: ##sys#syntax-error-hook */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t3,((C_word*)t0)[11],lf[128]);}}
else{
t3=t2;
f_6681(t3,C_SCHEME_UNDEFINED);}}

/* k7651 in k7647 in k7643 in k7626 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7653,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_i_check_list_2(t7,lf[16]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7672,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=((C_word)li129),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_7672(t13,t9,t7);}

/* a3010 in k2994 in with-module-aliases in k2708 in k2704 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3011,2,t0,t1);}
/* modules.scm:129: thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,t1);}

/* f8231 in k5159 in k5156 in k5153 in k5150 in k5146 in g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f8231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:515: ##sys#warn */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),((C_word*)t0)[2],t1);}

/* k7021 in for-each-loop1639 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7013(t3,((C_word*)t0)[4],t2);}

/* k5581 in k5557 in k5595 in k5545 in loop in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:477: string-append */
t2=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[97],t1,lf[98]);}

/* for-each-loop1639 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_7013(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7013,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7023,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:681: g1640 */
t5=((C_word*)t0)[3];
f_6559(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7009 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[129]);}

/* loop in k6217 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6228(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6228,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t7=t6;
t8=C_i_check_list_2(t7,lf[30]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6252,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6257,a[2]=t11,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_6257(t13,t9,t7);}
else{
t7=C_i_caar(t3);
t8=C_i_assq(t7,t6);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6285,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t4,a[7]=t6,a[8]=((C_word)li90),tmp=(C_word)a,a+=9,tmp);
/* modules.scm:638: g1570 */
t10=t9;
f_6285(t10,t1,t8);}
else{
t9=t3;
t10=C_u_i_cdr(t9);
t11=t3;
t12=C_u_i_car(t11);
t13=C_a_i_cons(&a,2,t12,t5);
/* modules.scm:650: loop */
t30=t1;
t31=t2;
t32=t10;
t33=t4;
t34=t13;
t35=t6;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
t5=t34;
t6=t35;
goto loop;}}}
else{
t7=C_i_caar(t2);
t8=C_i_assq(t7,t6);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6338,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t5,a[7]=t6,a[8]=((C_word)li91),tmp=(C_word)a,a+=9,tmp);
/* modules.scm:636: g1574 */
t10=t9;
f_6338(t10,t1,t8);}
else{
t9=t2;
t10=C_u_i_cdr(t9);
t11=t2;
t12=C_u_i_car(t11);
t13=C_a_i_cons(&a,2,t12,t4);
/* modules.scm:657: loop */
t30=t1;
t31=t10;
t32=t3;
t33=t13;
t34=t5;
t35=t6;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
t5=t34;
t6=t35;
goto loop;}}}

/* k6466 in map-loop1610 in k6428 in k6394 in k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6468,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6439(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6439(t6,((C_word*)t0)[5],t5);}}

/* g1485 in loop in k5971 in k5962 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6017(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6017,NULL,3,t0,t1,t2);}
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
/* modules.scm:621: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5978(t5,t1,t3,((C_word*)t0)[5],t4);}

/* k7662 in map-loop2065 in k7651 in k7647 in k7643 in k7626 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[70]+1)))(4,*((C_word*)lf[70]+1),((C_word*)t0)[2],lf[166],t1);}

/* k7468 in merr in k7439 in instantiate-functor in k2708 in k2704 */
static void C_ccall f_7470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7470,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* modules.scm:822: err */
t3=((C_word*)t0)[3];
f_7434(t3,((C_word*)t0)[4],C_a_i_list(&a,3,lf[156],((C_word*)t0)[5],t2));}

/* map-loop780 in k4287 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_fcall f_4204(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4204,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4233,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:325: g786 */
t5=((C_word*)t0)[5];
f_4162(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* map-loop1996 in merr in k7439 in instantiate-functor in k2708 in k2704 */
static void C_fcall f_7472(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7472,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4200 in k4287 in k4062 in k4054 in k4046 in compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4202,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[57],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4096,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[7]))){
t6=t4;
f_4092(t6,C_a_i_cons(&a,2,lf[57],C_SCHEME_END_OF_LIST));}
else{
t6=((C_word*)t0)[8];
t7=C_i_check_structure_2(t6,lf[3],lf[44]);
t8=C_i_block_ref(t6,C_fix(5));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4108,a[2]=((C_word*)t0)[7],a[3]=t10,a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_4108(t12,t5,t8);}}

/* k6217 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6219,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6228,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word)li92),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6228(t6,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6216,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* modules.scm:635: ##sys#check-syntax */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[117]+1)))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[7],((C_word*)t0)[2],lf[121]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* modules.scm:660: c */
t3=((C_word*)t0)[9];
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[10],((C_word*)t0)[11]);}}

/* k7285 in loop in validate-exports in k2708 in k2704 */
static void C_ccall f_7287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7287,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5328,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[16]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5435,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5435(t7,t3,t1);}

/* k5319 in map-loop1258 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_u_i_car(((C_word*)t0)[4]);
/* modules.scm:523: ##sys#error */
t4=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],lf[88],t3);}}

/* map-loop2065 in k7651 in k7647 in k7643 in k7626 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_fcall f_7672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7672,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7701,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7664,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:858: symbol->string */
t7=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7668 in k7651 in k7647 in k7643 in k7626 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(12,0,((C_word*)t0)[2],*((C_word*)lf[89]+1),lf[161],((C_word*)t0)[3],lf[162],lf[163],((C_word*)t0)[4],lf[164],((C_word*)t0)[5],lf[165],t1);}

/* k7439 in instantiate-functor in k2708 in k2704 */
static void C_ccall f_7441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7441,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=C_u_i_cdr(((C_word*)t0)[2]);
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li125),tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7512,a[2]=t5,a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7533,a[2]=t8,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word)li126),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_7533(t13,t9,((C_word*)t0)[4],t3);}

/* k6204 in map-loop1493 in k6085 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6206,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6177(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6177(t6,((C_word*)t0)[5],t5);}}

/* k5116 in map-loop1124 in finalize-module in k2708 in k2704 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_assq(((C_word*)t0)[3],t1));}

/* k5335 in k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5337,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5340,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* modules.scm:529: ##sys#mark-imported-symbols */
t4=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}

/* k5332 in k5326 in k5294 in k5291 in k5285 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5334,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5429,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* modules.scm:526: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t4);}

/* k7639 in k7626 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:851: ##sys#syntax-error-hook */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],lf[3],t1);}

/* k7643 in k7626 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7645,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:856: symbol->string */
t4=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k7647 in k7643 in k7626 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7649,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:857: symbol->string */
t4=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* merr in k7439 in instantiate-functor in k2708 in k2704 */
static void C_fcall f_7451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7451,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=t2;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_check_list_2(((C_word*)t0)[4],lf[16]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7470,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7472,a[2]=t7,a[3]=t11,a[4]=t5,a[5]=((C_word)li124),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_7472(t13,t9,((C_word*)t0)[4]);}

/* map-loop1584 in k6394 in k6391 in k6388 in k6214 in k6082 in k5959 in a5953 in k5917 in k5908 in import-spec in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6474(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6474,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6503,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:668: g1590 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##sys#add-to-export-list in k2708 in k2704 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3226,4,t0,t1,t2,t3);}
t4=t2;
t5=C_i_check_structure_2(t4,lf[3],lf[10]);
t6=C_i_block_ref(t4,C_fix(2));
t7=C_eqp(t6,C_SCHEME_TRUE);
if(C_truep(t7)){
t8=t2;
t9=C_i_check_structure_2(t8,lf[3],lf[29]);
t10=C_i_block_ref(t8,C_fix(4));
t11=t10;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3242,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:165: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t12);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3313,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:175: append */
t9=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t6,t3);}}

/* k3222 in k3218 in switch-module in k2708 in k2704 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3224,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:150: ##sys#current-module */
t5=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k3218 in switch-module in k2708 in k2704 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3224,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:149: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t3);}

/* map-loop1802 in k6874 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_fcall f_6882(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6882,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6878 in k6874 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:720: append */
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k6874 in k6704 in k6676 in k6633 in k6582 in a6570 in g1640 in k6556 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_6876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6876,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6882,a[2]=t6,a[3]=t9,a[4]=t4,a[5]=((C_word)li103),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_6882(t11,t7,((C_word*)t0)[4]);}

/* g478 in k3178 in k3222 in k3218 in switch-module in k2708 in k2704 */
static void C_fcall f_3208(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3208,NULL,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t4=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,C_fix(13),((C_word*)t0)[2]);}

/* iface in validate-exports in k2708 in k2704 */
static void C_fcall f_7214(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7214,NULL,3,t0,t1,t2);}
t3=C_i_getprop(t2,lf[141],C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* modules.scm:783: err */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7208(t4,t1,C_a_i_list(&a,3,lf[143],*((C_word*)lf[144]+1),((C_word*)t0)[3]));}}

/* ##sys#alias-global-hook in k2708 in k2704 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7087,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7090,a[2]=t3,a[3]=t4,a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7124,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:756: ##sys#qualified-symbol? */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[139]+1)))(3,*((C_word*)lf[139]+1),t6,t2);}

/* mrename in alias-global-hook in k2708 in k2704 */
static void C_fcall f_7090(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7090,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7094,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:749: ##sys#current-module */
t4=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7092 in mrename in alias-global-hook in k2708 in k2704 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7094,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li112),tmp=(C_word)a,a+=6,tmp);
/* modules.scm:747: g1875 */
t3=t2;
f_7098(t3,((C_word*)t0)[5],t1);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* g1875 in k7092 in mrename in alias-global-hook in k2708 in k2704 */
static void C_fcall f_7098(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7098,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7105,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t2;
t5=C_i_check_structure_2(t4,lf[3],lf[4]);
t6=C_i_block_ref(t4,C_fix(1));
/* modules.scm:754: ##sys#module-rename */
t7=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,((C_word*)t0)[2],t6);}
else{
/* modules.scm:753: ##sys#register-undefined */
t4=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k7610 in g2047 in k7593 in match-functor-argument in k2708 in k2704 */
static void C_ccall f_7612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7612,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##sys#module-rename in k2708 in k2704 */
static void C_ccall f_7069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7069,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7077,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_slot(t3,C_fix(1));
t6=C_slot(t2,C_fix(1));
/* modules.scm:742: string-append */
t7=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,lf[136],t6);}

/* ##sys#validate-exports in k2708 in k2704 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7205,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7208,a[2]=t3,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7214,a[2]=t5,a[3]=t2,a[4]=((C_word)li118),tmp=(C_word)a,a+=5,tmp));
t10=C_eqp(lf[145],t2);
if(C_truep(t10)){
t11=t2;
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
if(C_truep(C_i_symbolp(t2))){
/* modules.scm:785: iface */
t11=((C_word*)t7)[1];
f_7214(t11,t1,t2);}
else{
if(C_truep(C_i_listp(t2))){
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7255,a[2]=t12,a[3]=t7,a[4]=t5,a[5]=t2,a[6]=((C_word)li120),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_7255(t14,t1,t2);}
else{
/* modules.scm:787: err */
t11=((C_word*)t5)[1];
f_7208(t11,t1,C_a_i_list(&a,2,lf[152],t2));}}}}

/* err in validate-exports in k2708 in k2704 */
static void C_fcall f_7208(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7208,NULL,3,t0,t1,t2);}
C_apply(5,0,t1,*((C_word*)lf[104]+1),((C_word*)t0)[2],t2);}

/* k7075 in module-rename in k2708 in k2704 */
static void C_ccall f_7077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* modules.scm:741: ##sys#string->symbol */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[69]+1)))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],t1);}

/* ##sys#compiled-module-registration in k2708 in k2704 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4025,3,t0,t1,t2);}
t3=t2;
t4=C_i_check_structure_2(t3,lf[3],lf[39]);
t5=C_i_block_ref(t3,C_fix(3));
t6=t5;
t7=t2;
t8=C_i_check_structure_2(t7,lf[3],lf[4]);
t9=C_i_block_ref(t7,C_fix(1));
t10=t2;
t11=C_i_check_structure_2(t10,lf[3],lf[52]);
t12=C_i_block_ref(t10,C_fix(7));
t13=t2;
t14=C_i_check_structure_2(t13,lf[3],lf[12]);
t15=C_i_block_ref(t13,C_fix(11));
t16=t15;
t17=t2;
t18=C_i_check_structure_2(t17,lf[3],lf[53]);
t19=C_i_block_ref(t17,C_fix(8));
t20=t19;
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4048,a[2]=t1,a[3]=t2,a[4]=t6,a[5]=t16,a[6]=t20,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t12))){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4409,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:312: ##sys#strip-syntax */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[59]+1)))(3,*((C_word*)lf[59]+1),t22,t12);}
else{
t22=t21;
f_4048(t22,C_SCHEME_END_OF_LIST);}}

/* k7042 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_7044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(8),t1);}

/* k4013 in loop in k3975 in merge-se in k2708 in k2704 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4015,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k7057 in k6553 in k6550 in k5813 in k5810 in k5807 in k5804 in k5801 in expand-import in k2708 in k2704 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[3],C_SCHEME_FALSE);
/* modules.scm:89: ##sys#block-set! */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(7),t1);}

/* k2994 in with-module-aliases in k2708 in k2704 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2996,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2997,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3011,a[2]=((C_word*)t0)[3],a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
/* modules.scm:124: ##sys#dynamic-wind */
t8=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[4],t6,t7,t6);}

/* swap387 in k2994 in with-module-aliases in k2708 in k2704 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:124: module-alias-environment389390 */
t3=((C_word*)t0)[4];
((C_proc2)C_fast_retrieve_proc(t3))(2,t3,t2);}

/* ##sys#with-module-aliases in k2708 in k2704 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2992,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[1]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2996,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_i_check_list_2(t2,lf[16]);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3035,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3041,a[2]=t9,a[3]=t13,a[4]=t7,a[5]=((C_word)li7),tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_3041(t15,t11,t2);}

/* k2988 in register-module-alias in k2708 in k2704 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2990,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* modules.scm:121: ##sys#module-alias-environment */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}

/* k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5127,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[7]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
t6=C_i_check_structure_2(t5,lf[3],lf[12]);
t7=C_i_block_ref(t5,C_fix(11));
/* modules.scm:450: merge-se */
f_3973(t3,C_a_i_list(&a,2,t7,t2));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:451: ##sys#macro-environment */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(2,*((C_word*)lf[25]+1),t5);}}

/* k3193 in k3184 in k3181 in k3178 in k3222 in k3218 in switch-module in k2708 in k2704 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_u_i_cdr(((C_word*)t0)[2]);
/* modules.scm:158: ##sys#macro-environment */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),((C_word*)t0)[3],t2);}

/* k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5133,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5287,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* modules.scm:516: module-undefined-list */
t5=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}

/* g1179 in k5131 in k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_fcall f_5134(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5134,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=t3;
t5=t2;
t6=C_u_i_car(t5);
if(C_truep(C_i_memq(t6,((C_word*)t0)[2]))){
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:490: open-output-string */
t8=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k5128 in k5125 in finalize-module in k2708 in k2704 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5130,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[8]);
t5=(C_truep(t4)?((C_word*)t0)[2]:((C_word*)t0)[8]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5500,a[2]=t2,a[3]=t7,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=((C_word)li68),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_5500(t9,t3,t5);}

/* k3184 in k3181 in k3178 in k3222 in k3218 in switch-module in k2708 in k2704 */
static void C_fcall f_3186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3186,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3195,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(t2);
/* modules.scm:157: ##sys#current-environment */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t4,t5);}
else{
/* modules.scm:159: ##sys#current-module */
t4=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k3181 in k3178 in k3222 in k3218 in switch-module in k2708 in k2704 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[3];
t4=C_i_check_structure_2(t3,lf[3],lf[27]);
t5=t2;
f_3186(t5,C_i_block_ref(t3,C_fix(13)));}
else{
t3=t2;
f_3186(t3,((C_word*)((C_word*)t0)[4])[1]);}}

/* k3178 in k3222 in k3218 in switch-module in k2708 in k2704 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3208,a[2]=((C_word*)t0)[5],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
/* modules.scm:147: g478 */
t4=t3;
f_3208(t4,t2,t1);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[5]);
t4=t2;
f_3183(2,t4,t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[432] = {
{"f_3189:modules_2escm",(void*)f_3189},
{"f_3510:modules_2escm",(void*)f_3510},
{"f_4967:modules_2escm",(void*)f_4967},
{"f_3529:modules_2escm",(void*)f_3529},
{"f_3514:modules_2escm",(void*)f_3514},
{"f_4973:modules_2escm",(void*)f_4973},
{"f_2974:modules_2escm",(void*)f_2974},
{"f_6406:modules_2escm",(void*)f_6406},
{"f_3973:modules_2escm",(void*)f_3973},
{"f_6430:modules_2escm",(void*)f_6430},
{"f_3988:modules_2escm",(void*)f_3988},
{"f_6439:modules_2escm",(void*)f_6439},
{"f_6437:modules_2escm",(void*)f_6437},
{"f_3977:modules_2escm",(void*)f_3977},
{"f_6636:modules_2escm",(void*)f_6636},
{"f_4914:modules_2escm",(void*)f_4914},
{"f_6635:modules_2escm",(void*)f_6635},
{"f_4912:modules_2escm",(void*)f_4912},
{"f_5703:modules_2escm",(void*)f_5703},
{"f_5707:modules_2escm",(void*)f_5707},
{"f_6412:modules_2escm",(void*)f_6412},
{"f_4387:modules_2escm",(void*)f_4387},
{"f_4906:modules_2escm",(void*)f_4906},
{"f_6625:modules_2escm",(void*)f_6625},
{"f_3967:modules_2escm",(void*)f_3967},
{"f_6416:modules_2escm",(void*)f_6416},
{"f_5713:modules_2escm",(void*)f_5713},
{"f_5716:modules_2escm",(void*)f_5716},
{"f_5710:modules_2escm",(void*)f_5710},
{"f_3173:modules_2escm",(void*)f_3173},
{"f_3595:modules_2escm",(void*)f_3595},
{"f_3769:modules_2escm",(void*)f_3769},
{"f_3387:modules_2escm",(void*)f_3387},
{"f_7628:modules_2escm",(void*)f_7628},
{"f_2710:modules_2escm",(void*)f_2710},
{"f_3384:modules_2escm",(void*)f_3384},
{"f_3381:modules_2escm",(void*)f_3381},
{"f_2706:modules_2escm",(void*)f_2706},
{"f_3914:modules_2escm",(void*)f_3914},
{"f_2724:modules_2escm",(void*)f_2724},
{"f_3372:modules_2escm",(void*)f_3372},
{"f_3375:modules_2escm",(void*)f_3375},
{"f_3369:modules_2escm",(void*)f_3369},
{"f_7602:modules_2escm",(void*)f_7602},
{"f_3359:modules_2escm",(void*)f_3359},
{"f_4569:modules_2escm",(void*)f_4569},
{"f_4568:modules_2escm",(void*)f_4568},
{"f_3536:modules_2escm",(void*)f_3536},
{"f_3345:modules_2escm",(void*)f_3345},
{"f_3781:modules_2escm",(void*)f_3781},
{"f_4543:modules_2escm",(void*)f_4543},
{"f_4542:modules_2escm",(void*)f_4542},
{"f_4555:modules_2escm",(void*)f_4555},
{"f_4369:modules_2escm",(void*)f_4369},
{"f_4340:modules_2escm",(void*)f_4340},
{"f_5809:modules_2escm",(void*)f_5809},
{"f_5806:modules_2escm",(void*)f_5806},
{"f_4186:modules_2escm",(void*)f_4186},
{"f_5803:modules_2escm",(void*)f_5803},
{"f_7426:modules_2escm",(void*)f_7426},
{"f_5812:modules_2escm",(void*)f_5812},
{"f_5817:modules_2escm",(void*)f_5817},
{"f_5815:modules_2escm",(void*)f_5815},
{"f_3792:modules_2escm",(void*)f_3792},
{"f_7434:modules_2escm",(void*)f_7434},
{"f_4162:modules_2escm",(void*)f_4162},
{"f_3550:modules_2escm",(void*)f_3550},
{"f_3777:modules_2escm",(void*)f_3777},
{"f_7410:modules_2escm",(void*)f_7410},
{"f_5846:modules_2escm",(void*)f_5846},
{"f_3543:modules_2escm",(void*)f_3543},
{"f_5433:modules_2escm",(void*)f_5433},
{"f_5435:modules_2escm",(void*)f_5435},
{"f_4140:modules_2escm",(void*)f_4140},
{"f_4936:modules_2escm",(void*)f_4936},
{"f_4938:modules_2escm",(void*)f_4938},
{"f_4150:modules_2escm",(void*)f_4150},
{"f_3700:modules_2escm",(void*)f_3700},
{"f_5869:modules_2escm",(void*)f_5869},
{"f_4744:modules_2escm",(void*)f_4744},
{"f_5251:modules_2escm",(void*)f_5251},
{"f_5250:modules_2escm",(void*)f_5250},
{"f_5255:modules_2escm",(void*)f_5255},
{"f_5873:modules_2escm",(void*)f_5873},
{"f_2950:modules_2escm",(void*)f_2950},
{"f_4510:modules_2escm",(void*)f_4510},
{"f_5263:modules_2escm",(void*)f_5263},
{"f_5889:modules_2escm",(void*)f_5889},
{"f_5473:modules_2escm",(void*)f_5473},
{"f_6751:modules_2escm",(void*)f_6751},
{"f_5273:modules_2escm",(void*)f_5273},
{"f_5891:modules_2escm",(void*)f_5891},
{"f_4779:modules_2escm",(void*)f_4779},
{"f_5483:modules_2escm",(void*)f_5483},
{"f_4539:modules_2escm",(void*)f_4539},
{"f_4533:modules_2escm",(void*)f_4533},
{"f_4750:modules_2escm",(void*)f_4750},
{"f_4785:modules_2escm",(void*)f_4785},
{"f_6776:modules_2escm",(void*)f_6776},
{"f_4585:modules_2escm",(void*)f_4585},
{"f_4523:modules_2escm",(void*)f_4523},
{"f_6768:modules_2escm",(void*)f_6768},
{"f_6761:modules_2escm",(void*)f_6761},
{"f_6718:modules_2escm",(void*)f_6718},
{"f_6715:modules_2escm",(void*)f_6715},
{"f_6712:modules_2escm",(void*)f_6712},
{"f_6917:modules_2escm",(void*)f_6917},
{"f_4713:modules_2escm",(void*)f_4713},
{"f_4715:modules_2escm",(void*)f_4715},
{"f_5654:modules_2escm",(void*)f_5654},
{"f_6703:modules_2escm",(void*)f_6703},
{"f_3944:modules_2escm",(void*)f_3944},
{"f_6706:modules_2escm",(void*)f_6706},
{"f_6731:modules_2escm",(void*)f_6731},
{"f_3957:modules_2escm",(void*)f_3957},
{"f_5464:modules_2escm",(void*)f_5464},
{"f_3925:modules_2escm",(void*)f_3925},
{"f_6390:modules_2escm",(void*)f_6390},
{"f_7707:modules_2escm",(void*)f_7707},
{"f_6398:modules_2escm",(void*)f_6398},
{"f_6396:modules_2escm",(void*)f_6396},
{"f_6393:modules_2escm",(void*)f_6393},
{"f_7701:modules_2escm",(void*)f_7701},
{"f_5645:modules_2escm",(void*)f_5645},
{"f_7717:modules_2escm",(void*)f_7717},
{"f_4709:modules_2escm",(void*)f_4709},
{"f_5826:modules_2escm",(void*)f_5826},
{"f_5287:modules_2escm",(void*)f_5287},
{"f_5667:modules_2escm",(void*)f_5667},
{"f_5296:modules_2escm",(void*)f_5296},
{"f_5293:modules_2escm",(void*)f_5293},
{"f_5839:modules_2escm",(void*)f_5839},
{"f_7735:modules_2escm",(void*)f_7735},
{"f_7738:modules_2escm",(void*)f_7738},
{"f_6177:modules_2escm",(void*)f_6177},
{"f_7732:modules_2escm",(void*)f_7732},
{"f_5632:modules_2escm",(void*)f_5632},
{"f_5630:modules_2escm",(void*)f_5630},
{"f_7747:modules_2escm",(void*)f_7747},
{"f_6354:modules_2escm",(void*)f_6354},
{"f_7741:modules_2escm",(void*)f_7741},
{"f_7744:modules_2escm",(void*)f_7744},
{"f_6782:modules_2escm",(void*)f_6782},
{"f_5055:modules_2escm",(void*)f_5055},
{"f_7759:modules_2escm",(void*)f_7759},
{"f_6780:modules_2escm",(void*)f_6780},
{"f_3119:modules_2escm",(void*)f_3119},
{"f_3117:modules_2escm",(void*)f_3117},
{"f_7750:modules_2escm",(void*)f_7750},
{"f_7752:modules_2escm",(void*)f_7752},
{"f_7158:modules_2escm",(void*)f_7158},
{"f_5092:modules_2escm",(void*)f_5092},
{"f_7192:modules_2escm",(void*)f_7192},
{"f_7197:modules_2escm",(void*)f_7197},
{"f_7195:modules_2escm",(void*)f_7195},
{"f_5696:modules_2escm",(void*)f_5696},
{"f_7368:modules_2escm",(void*)f_7368},
{"f_5429:modules_2escm",(void*)f_5429},
{"f_5228:modules_2escm",(void*)f_5228},
{"f_6552:modules_2escm",(void*)f_6552},
{"f_6555:modules_2escm",(void*)f_6555},
{"f_6558:modules_2escm",(void*)f_6558},
{"f_6559:modules_2escm",(void*)f_6559},
{"f_6113:modules_2escm",(void*)f_6113},
{"f_3338:modules_2escm",(void*)f_3338},
{"f_7354:modules_2escm",(void*)f_7354},
{"f_6571:modules_2escm",(void*)f_6571},
{"f_3322:modules_2escm",(void*)f_3322},
{"f_6968:modules_2escm",(void*)f_6968},
{"f_6565:modules_2escm",(void*)f_6565},
{"f_3315:modules_2escm",(void*)f_3315},
{"f_3318:modules_2escm",(void*)f_3318},
{"f_3313:modules_2escm",(void*)f_3313},
{"f_6958:modules_2escm",(void*)f_6958},
{"f_6598:modules_2escm",(void*)f_6598},
{"f_5404:modules_2escm",(void*)f_5404},
{"f_6981:modules_2escm",(void*)f_6981},
{"f_6584:modules_2escm",(void*)f_6584},
{"f_6585:modules_2escm",(void*)f_6585},
{"f_5414:modules_2escm",(void*)f_5414},
{"f_7105:modules_2escm",(void*)f_7105},
{"f_6101:modules_2escm",(void*)f_6101},
{"f_7124:modules_2escm",(void*)f_7124},
{"f_6991:modules_2escm",(void*)f_6991},
{"f_7571:modules_2escm",(void*)f_7571},
{"toplevel:modules_2escm",(void*)C_modules_toplevel},
{"f_7582:modules_2escm",(void*)f_7582},
{"f_4108:modules_2escm",(void*)f_4108},
{"f_7327:modules_2escm",(void*)f_7327},
{"f_7595:modules_2escm",(void*)f_7595},
{"f_7591:modules_2escm",(void*)f_7591},
{"f_4338:modules_2escm",(void*)f_4338},
{"f_7779:modules_2escm",(void*)f_7779},
{"f_2805:modules_2escm",(void*)f_2805},
{"f_4320:modules_2escm",(void*)f_4320},
{"f_2814:modules_2escm",(void*)f_2814},
{"f_6503:modules_2escm",(void*)f_6503},
{"f_5206:modules_2escm",(void*)f_5206},
{"f_5203:modules_2escm",(void*)f_5203},
{"f_6517:modules_2escm",(void*)f_6517},
{"f_5218:modules_2escm",(void*)f_5218},
{"f_4882:modules_2escm",(void*)f_4882},
{"f_3082:modules_2escm",(void*)f_3082},
{"f_4878:modules_2escm",(void*)f_4878},
{"f_4874:modules_2escm",(void*)f_4874},
{"f_3424:modules_2escm",(void*)f_3424},
{"f_3420:modules_2escm",(void*)f_3420},
{"f_3090:modules_2escm",(void*)f_3090},
{"f_5002:modules_2escm",(void*)f_5002},
{"f_4845:modules_2escm",(void*)f_4845},
{"f_5014:modules_2escm",(void*)f_5014},
{"f_4852:modules_2escm",(void*)f_4852},
{"f_4858:modules_2escm",(void*)f_4858},
{"f_3881:modules_2escm",(void*)f_3881},
{"f_5027:modules_2escm",(void*)f_5027},
{"f_5025:modules_2escm",(void*)f_5025},
{"f_3864:modules_2escm",(void*)f_3864},
{"f_4291:modules_2escm",(void*)f_4291},
{"f_3868:modules_2escm",(void*)f_3868},
{"f_3896:modules_2escm",(void*)f_3896},
{"f_4814:modules_2escm",(void*)f_4814},
{"f_4289:modules_2escm",(void*)f_4289},
{"f_4628:modules_2escm",(void*)f_4628},
{"f_3654:modules_2escm",(void*)f_3654},
{"f_4615:modules_2escm",(void*)f_4615},
{"f_3645:modules_2escm",(void*)f_3645},
{"f_4602:modules_2escm",(void*)f_4602},
{"f_4603:modules_2escm",(void*)f_4603},
{"f_3041:modules_2escm",(void*)f_3041},
{"f_6301:modules_2escm",(void*)f_6301},
{"f_3285:modules_2escm",(void*)f_3285},
{"f_6338:modules_2escm",(void*)f_6338},
{"f_3076:modules_2escm",(void*)f_3076},
{"f_7313:modules_2escm",(void*)f_7313},
{"f_3275:modules_2escm",(void*)f_3275},
{"f_3279:modules_2escm",(void*)f_3279},
{"f_3265:modules_2escm",(void*)f_3265},
{"f_3268:modules_2escm",(void*)f_3268},
{"f_3251:modules_2escm",(void*)f_3251},
{"f_3819:modules_2escm",(void*)f_3819},
{"f_4463:modules_2escm",(void*)f_4463},
{"f_3242:modules_2escm",(void*)f_3242},
{"f_3243:modules_2escm",(void*)f_3243},
{"f_3448:modules_2escm",(void*)f_3448},
{"f_4694:modules_2escm",(void*)f_4694},
{"f_3435:modules_2escm",(void*)f_3435},
{"f_3431:modules_2escm",(void*)f_3431},
{"f_4096:modules_2escm",(void*)f_4096},
{"f_4092:modules_2escm",(void*)f_4092},
{"f_7512:modules_2escm",(void*)f_7512},
{"f_4064:modules_2escm",(void*)f_4064},
{"f_5910:modules_2escm",(void*)f_5910},
{"f_5919:modules_2escm",(void*)f_5919},
{"f_4060:modules_2escm",(void*)f_4060},
{"f_5500:modules_2escm",(void*)f_5500},
{"f_5722:modules_2escm",(void*)f_5722},
{"f_5725:modules_2escm",(void*)f_5725},
{"f_5726:modules_2escm",(void*)f_5726},
{"f_4826:modules_2escm",(void*)f_4826},
{"f_3470:modules_2escm",(void*)f_3470},
{"f_3476:modules_2escm",(void*)f_3476},
{"f_7533:modules_2escm",(void*)f_7533},
{"f_3690:modules_2escm",(void*)f_3690},
{"f_4048:modules_2escm",(void*)f_4048},
{"f_5341:modules_2escm",(void*)f_5341},
{"f_5340:modules_2escm",(void*)f_5340},
{"f_5345:modules_2escm",(void*)f_5345},
{"f_4839:modules_2escm",(void*)f_4839},
{"f_4830:modules_2escm",(void*)f_4830},
{"f_3461:modules_2escm",(void*)f_3461},
{"f_4056:modules_2escm",(void*)f_4056},
{"f_3467:modules_2escm",(void*)f_3467},
{"f_4409:modules_2escm",(void*)f_4409},
{"f_4638:modules_2escm",(void*)f_4638},
{"f_4052:modules_2escm",(void*)f_4052},
{"f_5185:modules_2escm",(void*)f_5185},
{"f_5188:modules_2escm",(void*)f_5188},
{"f_3458:modules_2escm",(void*)f_3458},
{"f_4648:modules_2escm",(void*)f_4648},
{"f_5195:modules_2escm",(void*)f_5195},
{"f_5198:modules_2escm",(void*)f_5198},
{"f_5199:modules_2escm",(void*)f_5199},
{"f_6817:modules_2escm",(void*)f_6817},
{"f_5161:modules_2escm",(void*)f_5161},
{"f_5169:modules_2escm",(void*)f_5169},
{"f_4411:modules_2escm",(void*)f_4411},
{"f_4441:modules_2escm",(void*)f_4441},
{"f_5176:modules_2escm",(void*)f_5176},
{"f_4494:modules_2escm",(void*)f_4494},
{"f_4671:modules_2escm",(void*)f_4671},
{"f_5148:modules_2escm",(void*)f_5148},
{"f_5995:modules_2escm",(void*)f_5995},
{"f_5363:modules_2escm",(void*)f_5363},
{"f_5369:modules_2escm",(void*)f_5369},
{"f_4684:modules_2escm",(void*)f_4684},
{"f_6865:modules_2escm",(void*)f_6865},
{"f_5152:modules_2escm",(void*)f_5152},
{"f_5155:modules_2escm",(void*)f_5155},
{"f_5158:modules_2escm",(void*)f_5158},
{"f_5961:modules_2escm",(void*)f_5961},
{"f_5372:modules_2escm",(void*)f_5372},
{"f_5964:modules_2escm",(void*)f_5964},
{"f_5375:modules_2escm",(void*)f_5375},
{"f_6854:modules_2escm",(void*)f_6854},
{"f_4473:modules_2escm",(void*)f_4473},
{"f_5978:modules_2escm",(void*)f_5978},
{"f_4233:modules_2escm",(void*)f_4233},
{"f_5973:modules_2escm",(void*)f_5973},
{"f_4661:modules_2escm",(void*)f_4661},
{"f_5782:modules_2escm",(void*)f_5782},
{"f_5944:modules_2escm",(void*)f_5944},
{"f_5792:modules_2escm",(void*)f_5792},
{"f_6691:modules_2escm",(void*)f_6691},
{"f_5796:modules_2escm",(void*)f_5796},
{"f_5799:modules_2escm",(void*)f_5799},
{"f_6699:modules_2escm",(void*)f_6699},
{"f_6695:modules_2escm",(void*)f_6695},
{"f_5954:modules_2escm",(void*)f_5954},
{"f_5544:modules_2escm",(void*)f_5544},
{"f_5547:modules_2escm",(void*)f_5547},
{"f_5763:modules_2escm",(void*)f_5763},
{"f_3842:modules_2escm",(void*)f_3842},
{"f_5765:modules_2escm",(void*)f_5765},
{"f_5926:modules_2escm",(void*)f_5926},
{"f_5597:modules_2escm",(void*)f_5597},
{"f_5771:modules_2escm",(void*)f_5771},
{"f_5776:modules_2escm",(void*)f_5776},
{"f_5386:modules_2escm",(void*)f_5386},
{"f_5930:modules_2escm",(void*)f_5930},
{"f_5934:modules_2escm",(void*)f_5934},
{"f_5744:modules_2escm",(void*)f_5744},
{"f_5740:modules_2escm",(void*)f_5740},
{"f_5747:modules_2escm",(void*)f_5747},
{"f_5394:modules_2escm",(void*)f_5394},
{"f_5390:modules_2escm",(void*)f_5390},
{"f_5398:modules_2escm",(void*)f_5398},
{"f_6267:modules_2escm",(void*)f_6267},
{"f_5575:modules_2escm",(void*)f_5575},
{"f_5579:modules_2escm",(void*)f_5579},
{"f_6045:modules_2escm",(void*)f_6045},
{"f_5754:modules_2escm",(void*)f_5754},
{"f_5751:modules_2escm",(void*)f_5751},
{"f_5759:modules_2escm",(void*)f_5759},
{"f_3856:modules_2escm",(void*)f_3856},
{"f_6252:modules_2escm",(void*)f_6252},
{"f_6257:modules_2escm",(void*)f_6257},
{"f_5559:modules_2escm",(void*)f_5559},
{"f_5733:modules_2escm",(void*)f_5733},
{"f_5730:modules_2escm",(void*)f_5730},
{"f_5737:modules_2escm",(void*)f_5737},
{"f_6096:modules_2escm",(void*)f_6096},
{"f_5535:modules_2escm",(void*)f_5535},
{"f_5531:modules_2escm",(void*)f_5531},
{"f_6087:modules_2escm",(void*)f_6087},
{"f_6084:modules_2escm",(void*)f_6084},
{"f_3004:modules_2escm",(void*)f_3004},
{"f_3001:modules_2escm",(void*)f_3001},
{"f_6074:modules_2escm",(void*)f_6074},
{"f_6681:modules_2escm",(void*)f_6681},
{"f_3039:modules_2escm",(void*)f_3039},
{"f_6684:modules_2escm",(void*)f_6684},
{"f_3035:modules_2escm",(void*)f_3035},
{"f_7255:modules_2escm",(void*)f_7255},
{"f_6285:modules_2escm",(void*)f_6285},
{"f_6672:modules_2escm",(void*)f_6672},
{"f_6678:modules_2escm",(void*)f_6678},
{"f_7653:modules_2escm",(void*)f_7653},
{"f_3011:modules_2escm",(void*)f_3011},
{"f8231:modules_2escm",(void*)f8231},
{"f_7023:modules_2escm",(void*)f_7023},
{"f_5583:modules_2escm",(void*)f_5583},
{"f_7013:modules_2escm",(void*)f_7013},
{"f_7011:modules_2escm",(void*)f_7011},
{"f_6228:modules_2escm",(void*)f_6228},
{"f_6468:modules_2escm",(void*)f_6468},
{"f_6017:modules_2escm",(void*)f_6017},
{"f_7664:modules_2escm",(void*)f_7664},
{"f_7470:modules_2escm",(void*)f_7470},
{"f_4204:modules_2escm",(void*)f_4204},
{"f_7472:modules_2escm",(void*)f_7472},
{"f_4202:modules_2escm",(void*)f_4202},
{"f_6219:modules_2escm",(void*)f_6219},
{"f_6216:modules_2escm",(void*)f_6216},
{"f_7287:modules_2escm",(void*)f_7287},
{"f_5328:modules_2escm",(void*)f_5328},
{"f_5321:modules_2escm",(void*)f_5321},
{"f_7672:modules_2escm",(void*)f_7672},
{"f_7670:modules_2escm",(void*)f_7670},
{"f_7441:modules_2escm",(void*)f_7441},
{"f_6206:modules_2escm",(void*)f_6206},
{"f_5118:modules_2escm",(void*)f_5118},
{"f_5337:modules_2escm",(void*)f_5337},
{"f_5334:modules_2escm",(void*)f_5334},
{"f_7641:modules_2escm",(void*)f_7641},
{"f_7645:modules_2escm",(void*)f_7645},
{"f_7649:modules_2escm",(void*)f_7649},
{"f_7451:modules_2escm",(void*)f_7451},
{"f_6474:modules_2escm",(void*)f_6474},
{"f_3226:modules_2escm",(void*)f_3226},
{"f_3224:modules_2escm",(void*)f_3224},
{"f_3220:modules_2escm",(void*)f_3220},
{"f_6882:modules_2escm",(void*)f_6882},
{"f_6880:modules_2escm",(void*)f_6880},
{"f_6876:modules_2escm",(void*)f_6876},
{"f_3208:modules_2escm",(void*)f_3208},
{"f_7214:modules_2escm",(void*)f_7214},
{"f_7087:modules_2escm",(void*)f_7087},
{"f_7090:modules_2escm",(void*)f_7090},
{"f_7094:modules_2escm",(void*)f_7094},
{"f_7098:modules_2escm",(void*)f_7098},
{"f_7612:modules_2escm",(void*)f_7612},
{"f_7069:modules_2escm",(void*)f_7069},
{"f_7205:modules_2escm",(void*)f_7205},
{"f_7208:modules_2escm",(void*)f_7208},
{"f_7077:modules_2escm",(void*)f_7077},
{"f_4025:modules_2escm",(void*)f_4025},
{"f_7044:modules_2escm",(void*)f_7044},
{"f_4015:modules_2escm",(void*)f_4015},
{"f_7059:modules_2escm",(void*)f_7059},
{"f_2996:modules_2escm",(void*)f_2996},
{"f_2997:modules_2escm",(void*)f_2997},
{"f_2992:modules_2escm",(void*)f_2992},
{"f_2990:modules_2escm",(void*)f_2990},
{"f_5127:modules_2escm",(void*)f_5127},
{"f_3195:modules_2escm",(void*)f_3195},
{"f_5133:modules_2escm",(void*)f_5133},
{"f_5134:modules_2escm",(void*)f_5134},
{"f_5130:modules_2escm",(void*)f_5130},
{"f_3186:modules_2escm",(void*)f_3186},
{"f_3183:modules_2escm",(void*)f_3183},
{"f_3180:modules_2escm",(void*)f_3180},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  for-each		14
S|  map		21
o|eliminated procedure checks: 297 
o|specializations:
o|  2 (cddr (pair * pair))
o|  1 (< fixnum fixnum)
o|  2 (string-append string string)
o|  1 (= fixnum fixnum)
o|  6 (##sys#check-list (or pair list) *)
o|  2 (cdar (pair pair *))
o|  1 (caar (pair pair *))
o|  27 (car pair)
o|  47 (cdr pair)
o|safe globals: (lookup) 
o|Removed `not' forms: 7 
o|removed side-effect free assignment to unused variable: module? 
o|contracted procedure: "(modules.scm:118) %make-module" 
o|inlining procedure: k3043 
o|contracted procedure: "(modules.scm:127) g403412" 
o|inlining procedure: k3043 
o|inlining procedure: k3095 
o|inlining procedure: k3095 
o|inlining procedure: k3087 
o|inlining procedure: k3087 
o|inlining procedure: k3136 
o|inlining procedure: k3136 
o|inlining procedure: k3187 
o|inlining procedure: k3187 
o|inlining procedure: k3248 
o|inlining procedure: k3248 
o|inlining procedure: k3231 
o|inlining procedure: k3287 
o|inlining procedure: k3287 
o|inlining procedure: k3231 
o|inlining procedure: k3323 
o|inlining procedure: k3323 
o|inlining procedure: k3349 
o|inlining procedure: k3349 
o|inlining procedure: k3361 
o|inlining procedure: k3361 
o|inlining procedure: k3450 
o|contracted procedure: "(modules.scm:223) set-module-defined-syntax-list!" 
o|inlining procedure: k3450 
o|inlining procedure: k3531 
o|inlining procedure: k3545 
o|inlining procedure: k3545 
o|inlining procedure: k3588 
o|inlining procedure: k3588 
o|inlining procedure: k3531 
o|inlining procedure: k3692 
o|contracted procedure: "(modules.scm:244) g609616" 
o|inlining procedure: k3649 
o|contracted procedure: "(modules.scm:249) g622623" 
o|inlining procedure: k3649 
o|inlining procedure: k3692 
o|merged explicitly consed rest parameter: ses687 
o|inlining procedure: k3990 
o|inlining procedure: k3990 
o|inlining procedure: k4094 
o|inlining procedure: k4094 
o|inlining procedure: k4110 
o|inlining procedure: k4110 
o|inlining procedure: k4170 
o|inlining procedure: k4170 
o|inlining procedure: k4206 
o|inlining procedure: k4206 
o|inlining procedure: k4293 
o|contracted procedure: "(modules.scm:318) g753762" 
o|inlining procedure: k4245 
o|inlining procedure: k4245 
o|inlining procedure: k4293 
o|inlining procedure: k4342 
o|inlining procedure: k4342 
o|inlining procedure: k4444 
o|contracted procedure: "(modules.scm:357) find-reexport847" 
o|inlining procedure: k4422 
o|inlining procedure: k4422 
o|inlining procedure: k4444 
o|consed rest parameter at call site: "(modules.scm:378) merge-se" 1 
o|inlining procedure: k4560 
o|consed rest parameter at call site: "(modules.scm:378) merge-se" 1 
o|inlining procedure: k4560 
o|consed rest parameter at call site: "(modules.scm:378) merge-se" 1 
o|inlining procedure: k4571 
o|consed rest parameter at call site: "(modules.scm:383) merge-se" 1 
o|inlining procedure: k4590 
o|consed rest parameter at call site: "(modules.scm:383) merge-se" 1 
o|inlining procedure: k4590 
o|consed rest parameter at call site: "(modules.scm:383) merge-se" 1 
o|inlining procedure: k4571 
o|consed rest parameter at call site: "(modules.scm:387) merge-se" 1 
o|inlining procedure: k4620 
o|consed rest parameter at call site: "(modules.scm:387) merge-se" 1 
o|inlining procedure: k4620 
o|consed rest parameter at call site: "(modules.scm:387) merge-se" 1 
o|inlining procedure: k4640 
o|inlining procedure: k4640 
o|inlining procedure: k4663 
o|inlining procedure: k4663 
o|inlining procedure: k4686 
o|inlining procedure: k4686 
o|consed rest parameter at call site: "(modules.scm:371) merge-se" 1 
o|inlining procedure: k4717 
o|contracted procedure: "(modules.scm:367) g916925" 
o|inlining procedure: k4717 
o|inlining procedure: k4752 
o|contracted procedure: "(modules.scm:361) g888897" 
o|inlining procedure: k4476 
o|inlining procedure: k4476 
o|inlining procedure: k4752 
o|inlining procedure: k4787 
o|inlining procedure: k4787 
o|contracted procedure: "(modules.scm:396) g10091010" 
o|consed rest parameter at call site: "(modules.scm:419) merge-se" 1 
o|inlining procedure: k4916 
o|inlining procedure: k4916 
o|inlining procedure: k4940 
o|inlining procedure: k4940 
o|inlining procedure: k4975 
o|contracted procedure: "(modules.scm:403) g10391048" 
o|inlining procedure: k4894 
o|inlining procedure: k4894 
o|inlining procedure: k4975 
o|inlining procedure: k5029 
o|inlining procedure: k5029 
o|inlining procedure: k5041 
o|inlining procedure: k5056 
o|inlining procedure: k5056 
o|inlining procedure: k5041 
o|inlining procedure: k5140 
o|inlining procedure: k5140 
o|inlining procedure: k5177 
o|inlining procedure: k5177 
o|inlining procedure: k5220 
o|inlining procedure: k5220 
o|substituted constant variable: a5240 
o|contracted procedure: "(modules.scm:502) g12131214" 
o|inlining procedure: k5265 
o|inlining procedure: k5265 
o|consed rest parameter at call site: "(modules.scm:532) merge-se" 1 
o|consed rest parameter at call site: "(modules.scm:550) merge-se" 1 
o|consed rest parameter at call site: "(modules.scm:547) merge-se" 1 
o|contracted procedure: "(modules.scm:543) set-module-vexports!" 
o|inlining procedure: k5406 
o|inlining procedure: k5406 
o|consed rest parameter at call site: "(modules.scm:525) merge-se" 1 
o|inlining procedure: k5437 
o|contracted procedure: "(modules.scm:520) g12641273" 
o|inlining procedure: k5299 
o|inlining procedure: k5299 
o|inlining procedure: k5437 
o|contracted procedure: "(modules.scm:524) module-indirect-exports" 
o|removed side-effect free assignment to unused variable: indirect?638 
o|inlining procedure: k3782 
o|inlining procedure: k3782 
o|inlining procedure: k3794 
o|inlining procedure: k3794 
o|inlining procedure: k3821 
o|inlining procedure: k3821 
o|inlining procedure: k3879 
o|inlining procedure: k3879 
o|inlining procedure: k3853 
o|inlining procedure: k3853 
o|inlining procedure: k3898 
o|inlining procedure: k3898 
o|inlining procedure: k5475 
o|inlining procedure: k5475 
o|inlining procedure: k5502 
o|inlining procedure: k5502 
o|inlining procedure: k5542 
o|inlining procedure: k5542 
o|contracted procedure: k5569 
o|inlining procedure: k5566 
o|inlining procedure: k5566 
o|consed rest parameter at call site: "(modules.scm:450) merge-se" 1 
o|inlining procedure: k5634 
o|inlining procedure: k5634 
o|inlining procedure: k5669 
o|contracted procedure: "(modules.scm:446) g11301139" 
o|inlining procedure: k5669 
o|inlining procedure: k5711 
o|inlining procedure: k5711 
o|substituted constant variable: a5797 
o|inlining procedure: k5822 
o|inlining procedure: k5822 
o|contracted procedure: "(modules.scm:587) lookup" 
o|inlining procedure: k2689 
o|inlining procedure: k2689 
o|contracted procedure: "(modules.scm:60) g229230" 
o|inlining procedure: k5828 
o|inlining procedure: k5828 
o|inlining procedure: k5847 
o|inlining procedure: k5847 
o|inlining procedure: k5893 
o|inlining procedure: k5893 
o|inlining procedure: k5914 
o|inlining procedure: k5914 
o|inlining procedure: k5956 
o|inlining procedure: k5980 
o|inlining procedure: k5980 
o|inlining procedure: k6014 
o|inlining procedure: k6014 
o|inlining procedure: k6047 
o|inlining procedure: k6047 
o|inlining procedure: k5956 
o|inlining procedure: k6103 
o|inlining procedure: k6115 
o|inlining procedure: k6115 
o|inlining procedure: k6103 
o|inlining procedure: k6179 
o|inlining procedure: k6179 
o|inlining procedure: k6211 
o|inlining procedure: k6230 
o|inlining procedure: k6259 
o|contracted procedure: "(modules.scm:639) g15531560" 
o|inlining procedure: k6259 
o|inlining procedure: k6282 
o|inlining procedure: k6282 
o|inlining procedure: k6230 
o|inlining procedure: k6211 
o|inlining procedure: k6441 
o|inlining procedure: k6441 
o|inlining procedure: k6476 
o|inlining procedure: k6476 
o|inlining procedure: k6518 
o|inlining procedure: k6518 
o|substituted constant variable: a6545 
o|inlining procedure: k6602 
o|contracted procedure: k6608 
o|inlining procedure: k6602 
o|contracted procedure: "(modules.scm:693) g16851686" 
o|inlining procedure: k6641 
o|contracted procedure: k6647 
o|inlining procedure: k6641 
o|inlining procedure: k6716 
o|inlining procedure: k6716 
o|consed rest parameter at call site: "(modules.scm:727) merge-se" 1 
o|inlining procedure: k6784 
o|inlining procedure: k6784 
o|inlining procedure: k6819 
o|inlining procedure: k6819 
o|inlining procedure: k6884 
o|inlining procedure: k6884 
o|inlining procedure: k6919 
o|inlining procedure: k6919 
o|inlining procedure: k6960 
o|inlining procedure: k6960 
o|inlining procedure: k6983 
o|inlining procedure: k6983 
o|inlining procedure: k7015 
o|inlining procedure: k7015 
o|inlining procedure: k7035 
o|contracted procedure: "(modules.scm:675) set-module-meta-import-forms!" 
o|inlining procedure: k7035 
o|contracted procedure: "(modules.scm:678) set-module-import-forms!" 
o|inlining procedure: k7095 
o|inlining procedure: k7095 
o|inlining procedure: k7119 
o|inlining procedure: k7119 
o|contracted procedure: "(modules.scm:747) g18871888" 
o|inlining procedure: k7141 
o|inlining procedure: k7141 
o|inlining procedure: k7166 
o|inlining procedure: k7166 
o|contracted procedure: "(modules.scm:770) g19121913" 
o|contracted procedure: "(modules.scm:761) g18931894" 
o|contracted procedure: "(modules.scm:757) g18831884" 
o|contracted procedure: "(modules.scm:775) g19211922" 
o|merged explicitly consed rest parameter: args1935 
o|inlining procedure: k7221 
o|inlining procedure: k7221 
o|consed rest parameter at call site: "(modules.scm:783) err1933" 1 
o|contracted procedure: "(modules.scm:782) g19401941" 
o|inlining procedure: k7227 
o|inlining procedure: k7227 
o|contracted procedure: k7245 
o|inlining procedure: k7242 
o|inlining procedure: k7257 
o|inlining procedure: k7257 
o|contracted procedure: k7266 
o|inlining procedure: k7275 
o|inlining procedure: k7275 
o|contracted procedure: k7293 
o|inlining procedure: k7299 
o|inlining procedure: k7299 
o|inlining procedure: k7322 
o|inlining procedure: k7322 
o|consed rest parameter at call site: "(modules.scm:803) err1933" 1 
o|inlining procedure: k7356 
o|inlining procedure: k7356 
o|consed rest parameter at call site: "(modules.scm:808) err1933" 1 
o|consed rest parameter at call site: "(modules.scm:797) err1933" 1 
o|consed rest parameter at call site: "(modules.scm:792) err1933" 1 
o|inlining procedure: k7242 
o|consed rest parameter at call site: "(modules.scm:787) err1933" 1 
o|contracted procedure: "(modules.scm:811) g19711972" 
o|merged explicitly consed rest parameter: args1986 
o|consed rest parameter at call site: "(modules.scm:822) err1985" 1 
o|inlining procedure: k7474 
o|inlining procedure: k7474 
o|inlining procedure: k7526 
o|inlining procedure: k7526 
o|inlining procedure: k7535 
o|inlining procedure: k7535 
o|consed rest parameter at call site: "(modules.scm:817) err1985" 1 
o|contracted procedure: "(modules.scm:814) g19811982" 
o|inlining procedure: k7596 
o|inlining procedure: k7607 
o|inlining procedure: k7607 
o|inlining procedure: k7596 
o|inlining procedure: k7674 
o|contracted procedure: "(modules.scm:858) g20712080" 
o|substituted constant variable: a7660 
o|inlining procedure: k7674 
o|inlining procedure: k7709 
o|inlining procedure: k7709 
o|propagated global variable: r4rs-syntax2092 ##sys#default-macro-environment 
o|replaced variables: 799 
o|removed binding forms: 394 
o|substituted constant variable: defined-list246 
o|substituted constant variable: exist-list247 
o|substituted constant variable: defined-syntax-list248 
o|substituted constant variable: undefined-list249 
o|substituted constant variable: import-forms250 
o|substituted constant variable: meta-import-forms251 
o|substituted constant variable: meta-expressions252 
o|substituted constant variable: saved-environments256 
o|substituted constant variable: r33247805 
o|substituted constant variable: r33507807 
o|removed call to pure procedure with unused result: "(modules.scm:202) void" 
o|removed call to pure procedure with unused result: "(modules.scm:217) void" 
o|substituted constant variable: r35897817 
o|substituted constant variable: r35897817 
o|substituted constant variable: prop625 
o|substituted constant variable: val626 
o|removed call to pure procedure with unused result: "(modules.scm:248) void" 
o|removed call to pure procedure with unused result: "(modules.scm:298) void" 
o|substituted constant variable: r39917824 
o|removed call to pure procedure with unused result: "(modules.scm:295) void" 
o|substituted constant variable: r40957826 
o|substituted constant variable: r40957826 
o|substituted constant variable: r41117830 
o|removed call to pure procedure with unused result: "(modules.scm:331) void" 
o|substituted constant variable: r45617848 
o|substituted constant variable: r45617848 
o|substituted constant variable: r45917853 
o|substituted constant variable: r45917853 
o|substituted constant variable: r46217858 
o|substituted constant variable: r46217858 
o|contracted procedure: "(modules.scm:355) g860869" 
o|substituted constant variable: prop1012 
o|substituted constant variable: r50307882 
o|substituted constant variable: prop1216 
o|removed call to pure procedure with unused result: "(modules.scm:531) void" 
o|removed call to pure procedure with unused result: "(modules.scm:536) void" 
o|substituted constant variable: r37837902 
o|substituted constant variable: r37957904 
o|converted assignments to bindings: (warn639) 
o|substituted constant variable: r55037918 
o|removed call to pure procedure with unused result: "(modules.scm:472) void" 
o|inlining procedure: k5542 
o|substituted constant variable: r55677925 
o|substituted constant variable: r56357926 
o|inlining procedure: k5711 
o|substituted constant variable: se219 
o|substituted constant variable: prop232 
o|converted assignments to bindings: (ren1580) 
o|substituted constant variable: r65197973 
o|substituted constant variable: r66037975 
o|substituted constant variable: prop1688 
o|substituted constant variable: r66427977 
o|removed call to pure procedure with unused result: "(modules.scm:734) void" 
o|removed call to pure procedure with unused result: "(modules.scm:687) void" 
o|removed call to pure procedure with unused result: "(modules.scm:686) void" 
o|removed call to pure procedure with unused result: "(modules.scm:682) void" 
o|removed call to pure procedure with unused result: "(modules.scm:750) void" 
o|removed call to pure procedure with unused result: "(modules.scm:758) void" 
o|removed call to pure procedure with unused result: "(modules.scm:762) void" 
o|substituted constant variable: prop1915 
o|removed call to pure procedure with unused result: "(modules.scm:765) void" 
o|substituted constant variable: prop1896 
o|substituted constant variable: prop1886 
o|converted assignments to bindings: (mrename1867) 
o|substituted constant variable: prop1924 
o|substituted constant variable: prop1943 
o|substituted constant variable: r72588017 
o|substituted constant variable: prop1974 
o|substituted constant variable: r75278030 
o|substituted constant variable: r75278030 
o|converted assignments to bindings: (merr1993) 
o|converted assignments to bindings: (err1985) 
o|substituted constant variable: prop1984 
o|simplifications: ((let . 5)) 
o|replaced variables: 51 
o|removed binding forms: 828 
o|contracted procedure: k3391 
o|contracted procedure: k3471 
o|contracted procedure: k3655 
o|contracted procedure: k3978 
o|contracted procedure: k3984 
o|contracted procedure: k4191 
o|inlining procedure: k4833 
o|inlining procedure: k5167 
o|contracted procedure: k5346 
o|contracted procedure: k5364 
o|contracted procedure: k5560 
o|substituted constant variable: r55438115 
o|inlining procedure: k2697 
o|contracted procedure: k6573 
o|contracted procedure: k6576 
o|contracted procedure: k6579 
o|removed call to pure procedure with unused result: "(modules.scm:734) void" 
o|contracted procedure: k7100 
o|inlining procedure: k7103 
o|contracted procedure: k7135 
o|contracted procedure: k7149 
o|contracted procedure: k7163 
o|inlining procedure: k7177 
o|replaced variables: 14 
o|removed binding forms: 120 
o|inlining procedure: k4425 
o|contracted procedure: k5164 
o|contracted procedure: k6593 
o|contracted procedure: k7127 
o|contracted procedure: k7146 
o|contracted procedure: k7218 
o|contracted procedure: k7430 
o|simplifications: ((let . 1)) 
o|replaced variables: 3 
o|removed binding forms: 42 
o|inlining procedure: "(modules.scm:240) make-module" 
o|inlining procedure: "(modules.scm:370) make-module" 
o|substituted constant variable: r44268329 
o|inlining procedure: "(modules.scm:401) make-module" 
o|replaced variables: 7 
o|removed binding forms: 3 
o|removed conditional forms: 1 
o|removed side-effect free assignment to unused variable: make-module 
o|substituted constant variable: iexports3808413 
o|substituted constant variable: explist3778434 
o|substituted constant variable: explist3778446 
o|substituted constant variable: iexports3808449 
o|inlining procedure: k5819 
o|inlining procedure: k5819 
o|replaced variables: 10 
o|removed binding forms: 5 
o|substituted constant variable: r58208579 
o|substituted constant variable: r58208579 
o|substituted constant variable: r58208579 
o|replaced variables: 3 
o|removed binding forms: 15 
o|removed conditional forms: 1 
o|removed binding forms: 3 
o|simplifications: ((if . 17) (##core#call . 573)) 
o|  call simplifications:
o|    list?	3
o|    fx<
o|    fixnum?
o|    ##sys#call-with-values	2
o|    cddr	3
o|    ##sys#intern-symbol
o|    string?
o|    number?
o|    number->string
o|    cdar	3
o|    length	2
o|    write-char	2
o|    caddr	2
o|    set-car!	4
o|    ##sys#cons	11
o|    ##sys#list	21
o|    apply	4
o|    caar	9
o|    symbol?	18
o|    ##sys#make-structure	4
o|    list	5
o|    not	3
o|    set-cdr!
o|    eq?	20
o|    null?	30
o|    assq	28
o|    cdr	36
o|    memq	6
o|    ##sys#check-list	29
o|    pair?	48
o|    car	40
o|    cadr	15
o|    ##sys#setslot	21
o|    ##sys#slot	73
o|    cons	80
o|    values	6
o|    ##sys#check-structure	25
o|    ##sys#block-ref	13
o|contracted procedure: k2726 
o|contracted procedure: k2735 
o|contracted procedure: k2744 
o|contracted procedure: k2753 
o|contracted procedure: k2762 
o|contracted procedure: k2771 
o|contracted procedure: k2780 
o|contracted procedure: k2789 
o|contracted procedure: k2807 
o|contracted procedure: k2816 
o|contracted procedure: k2825 
o|contracted procedure: k2843 
o|contracted procedure: k2861 
o|contracted procedure: k2870 
o|contracted procedure: k2879 
o|contracted procedure: k2897 
o|contracted procedure: k2906 
o|contracted procedure: k2915 
o|contracted procedure: k2924 
o|contracted procedure: k2933 
o|contracted procedure: k2942 
o|contracted procedure: k2984 
o|contracted procedure: k2980 
o|contracted procedure: k3030 
o|contracted procedure: k3046 
o|contracted procedure: k3049 
o|contracted procedure: k3060 
o|contracted procedure: k3072 
o|contracted procedure: k3023 
o|contracted procedure: k3027 
o|contracted procedure: k3084 
o|contracted procedure: k3092 
o|contracted procedure: k3098 
o|contracted procedure: k3108 
o|contracted procedure: k3166 
o|contracted procedure: k3121 
o|contracted procedure: k3160 
o|contracted procedure: k3124 
o|contracted procedure: k3154 
o|contracted procedure: k3127 
o|contracted procedure: k3148 
o|contracted procedure: k3130 
o|contracted procedure: k3133 
o|contracted procedure: k3175 
o|contracted procedure: k3202 
o|contracted procedure: k3234 
o|contracted procedure: k3245 
o|contracted procedure: k3254 
o|contracted procedure: k3260 
o|contracted procedure: k3290 
o|contracted procedure: k3300 
o|contracted procedure: k3304 
o|contracted procedure: k3330 
o|contracted procedure: k3340 
o|contracted procedure: k3346 
o|contracted procedure: k3364 
o|contracted procedure: k3376 
o|contracted procedure: k3402 
o|contracted procedure: k3398 
o|contracted procedure: k3410 
o|contracted procedure: k3453 
o|contracted procedure: k3485 
o|contracted procedure: k3481 
o|contracted procedure: k2798 
o|contracted procedure: k3500 
o|contracted procedure: k3496 
o|contracted procedure: k3515 
o|contracted procedure: k3537 
o|contracted procedure: k3559 
o|contracted procedure: k3555 
o|contracted procedure: k3570 
o|contracted procedure: k3566 
o|contracted procedure: k3580 
o|contracted procedure: k3588 
o|contracted procedure: k3638 
o|contracted procedure: k3597 
o|contracted procedure: k3632 
o|contracted procedure: k3600 
o|contracted procedure: k3626 
o|contracted procedure: k3603 
o|contracted procedure: k3620 
o|contracted procedure: k3606 
o|contracted procedure: k3609 
o|contracted procedure: k3617 
o|contracted procedure: k3613 
o|contracted procedure: k3683 
o|contracted procedure: k3695 
o|contracted procedure: k3705 
o|contracted procedure: k3709 
o|contracted procedure: k3680 
o|contracted procedure: k3665 
o|contracted procedure: k3672 
o|contracted procedure: k3993 
o|contracted procedure: k4019 
o|contracted procedure: k3999 
o|contracted procedure: k4074 
o|contracted procedure: k4284 
o|contracted procedure: k4078 
o|contracted procedure: k4082 
o|contracted procedure: k4164 
o|contracted procedure: k4167 
o|contracted procedure: k4173 
o|contracted procedure: k4180 
o|contracted procedure: k4197 
o|contracted procedure: k4086 
o|contracted procedure: k4070 
o|contracted procedure: k4066 
o|contracted procedure: k4097 
o|contracted procedure: k4113 
o|contracted procedure: k4158 
o|contracted procedure: k4119 
o|contracted procedure: k4127 
o|contracted procedure: k4144 
o|contracted procedure: k4134 
o|contracted procedure: k4209 
o|contracted procedure: k4212 
o|contracted procedure: k4223 
o|contracted procedure: k4235 
o|contracted procedure: k4296 
o|contracted procedure: k4299 
o|contracted procedure: k4310 
o|contracted procedure: k4322 
o|contracted procedure: k4278 
o|contracted procedure: k4248 
o|contracted procedure: k4255 
o|contracted procedure: k4266 
o|contracted procedure: k4270 
o|contracted procedure: k4333 
o|contracted procedure: k4345 
o|contracted procedure: k4348 
o|contracted procedure: k4359 
o|contracted procedure: k4371 
o|contracted procedure: k4374 
o|contracted procedure: k4381 
o|contracted procedure: k4388 
o|contracted procedure: k4403 
o|contracted procedure: k4399 
o|contracted procedure: k4395 
o|contracted procedure: k4819 
o|contracted procedure: k4413 
o|contracted procedure: k4468 
o|contracted procedure: k4505 
o|contracted procedure: k4528 
o|contracted procedure: k4534 
o|contracted procedure: k4549 
o|contracted procedure: k4557 
o|contracted procedure: k4563 
o|contracted procedure: k4594 
o|contracted procedure: k4574 
o|contracted procedure: k4587 
o|contracted procedure: k4597 
o|contracted procedure: k4609 
o|contracted procedure: k4617 
o|contracted procedure: k4623 
o|contracted procedure: k4634 
o|contracted procedure: k4630 
o|contracted procedure: k4643 
o|contracted procedure: k4653 
o|contracted procedure: k4657 
o|contracted procedure: k4666 
o|contracted procedure: k4676 
o|contracted procedure: k4680 
o|contracted procedure: k4689 
o|contracted procedure: k4699 
o|contracted procedure: k4703 
o|contracted procedure: k4720 
o|contracted procedure: k4723 
o|contracted procedure: k4734 
o|contracted procedure: k4746 
o|contracted procedure: k4517 
o|contracted procedure: k4755 
o|contracted procedure: k4758 
o|contracted procedure: k4769 
o|contracted procedure: k4781 
o|contracted procedure: k4502 
o|contracted procedure: k4479 
o|contracted procedure: k4488 
o|contracted procedure: k4496 
o|contracted procedure: k4790 
o|contracted procedure: k4793 
o|contracted procedure: k4804 
o|contracted procedure: k4816 
o|contracted procedure: k4447 
o|contracted procedure: k4419 
o|contracted procedure: k4435 
o|contracted procedure: k4425 
o|contracted procedure: k4457 
o|contracted procedure: k4841 
o|contracted procedure: k5007 
o|contracted procedure: k4847 
o|contracted procedure: k4907 
o|contracted procedure: k4919 
o|contracted procedure: k4922 
o|contracted procedure: k4931 
o|contracted procedure: k4853 
o|contracted procedure: k4864 
o|contracted procedure: k4860 
o|contracted procedure: k4868 
o|contracted procedure: k4943 
o|contracted procedure: k4946 
o|contracted procedure: k4957 
o|contracted procedure: k4969 
o|contracted procedure: k4978 
o|contracted procedure: k4981 
o|contracted procedure: k4992 
o|contracted procedure: k5004 
o|contracted procedure: k4897 
o|contracted procedure: k5032 
o|contracted procedure: k5082 
o|contracted procedure: k5035 
o|contracted procedure: k5044 
o|contracted procedure: k5071 
o|contracted procedure: k5047 
o|contracted procedure: k5085 
o|contracted procedure: k5122 
o|contracted procedure: k5136 
o|contracted procedure: k5143 
o|contracted procedure: k5242 
o|contracted procedure: k5180 
o|contracted procedure: k5211 
o|contracted procedure: k5223 
o|contracted procedure: k5233 
o|contracted procedure: k5237 
o|contracted procedure: k5245 
o|contracted procedure: k5268 
o|contracted procedure: k5278 
o|contracted procedure: k5282 
o|contracted procedure: k5288 
o|contracted procedure: k5329 
o|contracted procedure: k5355 
o|contracted procedure: k5358 
o|contracted procedure: k5380 
o|contracted procedure: k2888 
o|contracted procedure: k5409 
o|contracted procedure: k5419 
o|contracted procedure: k5423 
o|contracted procedure: k5440 
o|contracted procedure: k5443 
o|contracted procedure: k5454 
o|contracted procedure: k5466 
o|contracted procedure: k5323 
o|contracted procedure: k5302 
o|contracted procedure: k5305 
o|contracted procedure: k3785 
o|contracted procedure: k3797 
o|contracted procedure: k3969 
o|contracted procedure: k3803 
o|contracted procedure: k3815 
o|contracted procedure: k3824 
o|contracted procedure: k3831 
o|contracted procedure: k3961 
o|contracted procedure: k3837 
o|contracted procedure: k3850 
o|contracted procedure: k3872 
o|contracted procedure: k3876 
o|contracted procedure: k3890 
o|contracted procedure: k3936 
o|contracted procedure: k3901 
o|contracted procedure: k3918 
o|contracted procedure: k3908 
o|contracted procedure: k3932 
o|contracted procedure: k5478 
o|contracted procedure: k5488 
o|contracted procedure: k5492 
o|contracted procedure: k5611 
o|contracted procedure: k5496 
o|contracted procedure: k5505 
o|contracted procedure: k5508 
o|contracted procedure: k5605 
o|contracted procedure: k5511 
o|contracted procedure: k5517 
o|contracted procedure: k5539 
o|inlining procedure: k5542 
o|contracted procedure: k5551 
o|inlining procedure: k5542 
o|contracted procedure: k5591 
o|contracted procedure: k5602 
o|contracted procedure: k5614 
o|contracted procedure: k5637 
o|contracted procedure: k5663 
o|contracted procedure: k5672 
o|contracted procedure: k5675 
o|contracted procedure: k5686 
o|contracted procedure: k5698 
o|contracted procedure: k5112 
o|contracted procedure: k5819 
o|contracted procedure: k5831 
o|contracted procedure: k5850 
o|contracted procedure: k5859 
o|contracted procedure: k5896 
o|contracted procedure: k6547 
o|contracted procedure: k5905 
o|contracted procedure: k5936 
o|contracted procedure: k5950 
o|contracted procedure: k5965 
o|contracted procedure: k5968 
o|contracted procedure: k5983 
o|contracted procedure: k6041 
o|contracted procedure: k5989 
o|contracted procedure: k6001 
o|contracted procedure: k6005 
o|contracted procedure: k6011 
o|contracted procedure: k6023 
o|contracted procedure: k6027 
o|contracted procedure: k6050 
o|contracted procedure: k6053 
o|contracted procedure: k6064 
o|contracted procedure: k6076 
o|contracted procedure: k6088 
o|contracted procedure: k6091 
o|contracted procedure: k6106 
o|contracted procedure: k6118 
o|contracted procedure: k6147 
o|contracted procedure: k6127 
o|contracted procedure: k6141 
o|contracted procedure: k6173 
o|contracted procedure: k6153 
o|contracted procedure: k6167 
o|contracted procedure: k6182 
o|contracted procedure: k6185 
o|contracted procedure: k6196 
o|contracted procedure: k6208 
o|contracted procedure: k6224 
o|contracted procedure: k6233 
o|contracted procedure: k6239 
o|contracted procedure: k6247 
o|contracted procedure: k6262 
o|contracted procedure: k6272 
o|contracted procedure: k6276 
o|contracted procedure: k6329 
o|contracted procedure: k6279 
o|contracted procedure: k6291 
o|contracted procedure: k6307 
o|contracted procedure: k6311 
o|contracted procedure: k6303 
o|contracted procedure: k6295 
o|contracted procedure: k6323 
o|contracted procedure: k6382 
o|contracted procedure: k6332 
o|contracted procedure: k6344 
o|contracted procedure: k6360 
o|contracted procedure: k6364 
o|contracted procedure: k6356 
o|contracted procedure: k6348 
o|contracted procedure: k6376 
o|contracted procedure: k6418 
o|contracted procedure: k6425 
o|contracted procedure: k6432 
o|contracted procedure: k6444 
o|contracted procedure: k6447 
o|contracted procedure: k6458 
o|contracted procedure: k6470 
o|contracted procedure: k6479 
o|contracted procedure: k6482 
o|contracted procedure: k6493 
o|contracted procedure: k6505 
o|contracted procedure: k6509 
o|contracted procedure: k6531 
o|contracted procedure: k6521 
o|contracted procedure: k6535 
o|contracted procedure: k6542 
o|contracted procedure: k6587 
o|contracted procedure: k6599 
o|contracted procedure: k6619 
o|contracted procedure: k6615 
o|contracted procedure: k6627 
o|contracted procedure: k6630 
o|contracted procedure: k6666 
o|contracted procedure: k6638 
o|contracted procedure: k6662 
o|contracted procedure: k6656 
o|contracted procedure: k6673 
o|contracted procedure: k6722 
o|contracted procedure: k6745 
o|contracted procedure: k6741 
o|contracted procedure: k6737 
o|contracted procedure: k6756 
o|contracted procedure: k6787 
o|contracted procedure: k6813 
o|contracted procedure: k6809 
o|contracted procedure: k6790 
o|contracted procedure: k6801 
o|contracted procedure: k6822 
o|contracted procedure: k6848 
o|contracted procedure: k6844 
o|contracted procedure: k6825 
o|contracted procedure: k6836 
o|contracted procedure: k6951 
o|contracted procedure: k6870 
o|contracted procedure: k6887 
o|contracted procedure: k6913 
o|contracted procedure: k6909 
o|contracted procedure: k6890 
o|contracted procedure: k6901 
o|contracted procedure: k6922 
o|contracted procedure: k6948 
o|contracted procedure: k6944 
o|contracted procedure: k6925 
o|contracted procedure: k6936 
o|contracted procedure: k6963 
o|contracted procedure: k6973 
o|contracted procedure: k6977 
o|contracted procedure: k6986 
o|contracted procedure: k6996 
o|contracted procedure: k7000 
o|contracted procedure: k7003 
o|contracted procedure: k7006 
o|contracted procedure: k7018 
o|contracted procedure: k7028 
o|contracted procedure: k7032 
o|contracted procedure: k2852 
o|contracted procedure: k7050 
o|contracted procedure: k2834 
o|contracted procedure: k7065 
o|contracted procedure: k7079 
o|contracted procedure: k7083 
o|contracted procedure: k7152 
o|contracted procedure: k7160 
o|contracted procedure: k7169 
o|contracted procedure: k7230 
o|contracted procedure: k7236 
o|contracted procedure: k7406 
o|contracted procedure: k7260 
o|contracted procedure: k7402 
o|contracted procedure: k7272 
o|contracted procedure: k7278 
o|contracted procedure: k7398 
o|contracted procedure: k7394 
o|contracted procedure: k7302 
o|contracted procedure: k7319 
o|contracted procedure: k7332 
o|contracted procedure: k7338 
o|contracted procedure: k7345 
o|contracted procedure: k7359 
o|contracted procedure: k7370 
o|contracted procedure: k7388 
o|contracted procedure: k7376 
o|contracted procedure: k7422 
o|contracted procedure: k7418 
o|contracted procedure: k7442 
o|contracted procedure: k7445 
o|contracted procedure: k7457 
o|contracted procedure: k7465 
o|contracted procedure: k7461 
o|contracted procedure: k7477 
o|contracted procedure: k7503 
o|contracted procedure: k7499 
o|contracted procedure: k7480 
o|contracted procedure: k7491 
o|contracted procedure: k7529 
o|contracted procedure: k7522 
o|contracted procedure: k7518 
o|contracted procedure: k7514 
o|contracted procedure: k7538 
o|contracted procedure: k7544 
o|contracted procedure: k7553 
o|contracted procedure: k7559 
o|contracted procedure: k7562 
o|contracted procedure: k7565 
o|contracted procedure: k7576 
o|contracted procedure: k7599 
o|contracted procedure: k7617 
o|contracted procedure: k7604 
o|contracted procedure: k7614 
o|contracted procedure: k7623 
o|contracted procedure: k7632 
o|contracted procedure: k7665 
o|contracted procedure: k7677 
o|contracted procedure: k7680 
o|contracted procedure: k7691 
o|contracted procedure: k7703 
o|contracted procedure: k7712 
o|contracted procedure: k7722 
o|contracted procedure: k7726 
o|contracted procedure: k7770 
o|contracted procedure: k7754 
o|contracted procedure: k7767 
o|simplifications: ((let . 94)) 
o|removed binding forms: 475 
o|inlining procedure: "(modules.scm:115) module-sexports" 
o|inlining procedure: "(modules.scm:114) module-vexports" 
o|inlining procedure: "(modules.scm:113) module-export-list" 
o|inlining procedure: k3052 
o|inlining procedure: k3052 
o|inlining procedure: "(modules.scm:155) module-saved-environments" 
o|inlining procedure: "(modules.scm:152) set-module-saved-environments!" 
o|inlining procedure: "(modules.scm:174) set-module-exist-list!" 
o|inlining procedure: "(modules.scm:173) set-module-sexports!" 
o|inlining procedure: "(modules.scm:173) module-sexports" 
o|inlining procedure: "(modules.scm:164) module-exist-list" 
o|inlining procedure: "(modules.scm:175) set-module-export-list!" 
o|inlining procedure: "(modules.scm:162) module-export-list" 
o|inlining procedure: "(modules.scm:181) set-module-meta-expressions!" 
o|inlining procedure: "(modules.scm:181) module-meta-expressions" 
o|inlining procedure: "(modules.scm:203) set-module-defined-list!" 
o|inlining procedure: "(modules.scm:206) module-defined-list" 
o|inlining procedure: "(modules.scm:200) set-module-exist-list!" 
o|inlining procedure: "(modules.scm:200) module-exist-list" 
o|inlining procedure: "(modules.scm:195) module-name" 
o|inlining procedure: "(modules.scm:191) module-export-list" 
o|inlining procedure: "(modules.scm:225) module-defined-syntax-list" 
o|inlining procedure: "(modules.scm:219) set-module-defined-list!" 
o|inlining procedure: "(modules.scm:222) module-defined-list" 
o|inlining procedure: "(modules.scm:213) module-name" 
o|inlining procedure: "(modules.scm:210) module-export-list" 
o|inlining procedure: k3584 
o|inlining procedure: k3584 
o|inlining procedure: "(modules.scm:337) module-defined-syntax-list" 
o|inlining procedure: k4215 
o|inlining procedure: k4215 
o|inlining procedure: "(modules.scm:323) module-vexports" 
o|inlining procedure: k4302 
o|inlining procedure: k4302 
o|inlining procedure: "(modules.scm:322) module-iexports" 
o|inlining procedure: "(modules.scm:316) module-name" 
o|inlining procedure: k4351 
o|inlining procedure: k4351 
o|inlining procedure: "(modules.scm:314) module-meta-expressions" 
o|inlining procedure: "(modules.scm:311) module-meta-import-forms" 
o|inlining procedure: "(modules.scm:310) module-sexports" 
o|inlining procedure: "(modules.scm:309) module-import-forms" 
o|inlining procedure: "(modules.scm:308) module-name" 
o|inlining procedure: "(modules.scm:307) module-defined-list" 
o|inlining procedure: k4726 
o|inlining procedure: k4726 
o|inlining procedure: k4761 
o|inlining procedure: k4761 
o|inlining procedure: k4796 
o|inlining procedure: k4796 
o|inlining procedure: "(modules.scm:417) set-module-saved-environments!" 
o|inlining procedure: "(modules.scm:421) module-sexports" 
o|inlining procedure: "(modules.scm:420) module-vexports" 
o|inlining procedure: k4949 
o|inlining procedure: k4949 
o|inlining procedure: k4984 
o|inlining procedure: k4984 
o|inlining procedure: "(modules.scm:428) module-exist-list" 
o|inlining procedure: "(modules.scm:427) module-export-list" 
o|inlining procedure: "(modules.scm:548) set-module-saved-environments!" 
o|inlining procedure: "(modules.scm:545) set-module-iexports!" 
o|inlining procedure: "(modules.scm:547) module-iexports" 
o|inlining procedure: "(modules.scm:544) set-module-sexports!" 
o|inlining procedure: k5446 
o|inlining procedure: k5446 
o|inlining procedure: "(modules.scm:255) module-defined-list" 
o|inlining procedure: "(modules.scm:254) module-name" 
o|inlining procedure: "(modules.scm:253) module-export-list" 
o|inlining procedure: "(modules.scm:450) module-sexports" 
o|inlining procedure: k5678 
o|inlining procedure: k5678 
o|inlining procedure: "(modules.scm:447) module-defined-syntax-list" 
o|inlining procedure: "(modules.scm:444) module-exist-list" 
o|inlining procedure: "(modules.scm:443) module-defined-list" 
o|inlining procedure: "(modules.scm:442) module-name" 
o|inlining procedure: "(modules.scm:441) module-export-list" 
o|inlining procedure: "(modules.scm:598) module-iexports" 
o|inlining procedure: "(modules.scm:597) module-sexports" 
o|inlining procedure: "(modules.scm:596) module-vexports" 
o|inlining procedure: k6056 
o|inlining procedure: k6056 
o|inlining procedure: k6188 
o|inlining procedure: k6188 
o|inlining procedure: k6450 
o|inlining procedure: k6450 
o|inlining procedure: k6485 
o|inlining procedure: k6485 
o|inlining procedure: "(modules.scm:729) set-module-meta-expressions!" 
o|inlining procedure: "(modules.scm:732) module-meta-expressions" 
o|inlining procedure: "(modules.scm:725) set-module-iexports!" 
o|inlining procedure: "(modules.scm:727) module-iexports" 
o|inlining procedure: "(modules.scm:712) set-module-exist-list!" 
o|inlining procedure: k6793 
o|inlining procedure: k6793 
o|inlining procedure: k6828 
o|inlining procedure: k6828 
o|inlining procedure: "(modules.scm:714) module-exist-list" 
o|inlining procedure: "(modules.scm:711) set-module-sexports!" 
o|inlining procedure: "(modules.scm:711) module-sexports" 
o|inlining procedure: "(modules.scm:718) set-module-export-list!" 
o|inlining procedure: k6893 
o|inlining procedure: k6893 
o|inlining procedure: k6928 
o|inlining procedure: k6928 
o|inlining procedure: "(modules.scm:721) module-export-list" 
o|inlining procedure: "(modules.scm:709) module-export-list" 
o|inlining procedure: "(modules.scm:677) module-meta-import-forms" 
o|inlining procedure: "(modules.scm:680) module-import-forms" 
o|inlining procedure: "(modules.scm:754) module-name" 
o|inlining procedure: "(modules.scm:754) module-name" 
o|inlining procedure: k7483 
o|inlining procedure: k7483 
o|inlining procedure: k7683 
o|inlining procedure: k7683 
o|inlining procedure: "(modules.scm:913) module-saved-environments" 
o|replaced variables: 152 
o|removed side-effect free assignment to unused variable: module-export-list 
o|removed side-effect free assignment to unused variable: set-module-export-list! 
o|removed side-effect free assignment to unused variable: module-defined-list 
o|removed side-effect free assignment to unused variable: set-module-defined-list! 
o|removed side-effect free assignment to unused variable: module-exist-list 
o|removed side-effect free assignment to unused variable: set-module-exist-list! 
o|removed side-effect free assignment to unused variable: module-defined-syntax-list 
o|removed side-effect free assignment to unused variable: module-import-forms 
o|removed side-effect free assignment to unused variable: module-meta-import-forms 
o|removed side-effect free assignment to unused variable: module-meta-expressions 
o|removed side-effect free assignment to unused variable: set-module-meta-expressions! 
o|removed side-effect free assignment to unused variable: module-vexports 
o|removed side-effect free assignment to unused variable: module-sexports 
o|removed side-effect free assignment to unused variable: set-module-sexports! 
o|removed side-effect free assignment to unused variable: module-iexports 
o|removed side-effect free assignment to unused variable: set-module-iexports! 
o|removed side-effect free assignment to unused variable: module-saved-environments 
o|removed side-effect free assignment to unused variable: set-module-saved-environments! 
o|replaced variables: 135 
o|removed binding forms: 123 
o|inlining procedure: k2964 
o|contracted procedure: k3068 
o|inlining procedure: k3281 
o|inlining procedure: k3437 
o|inlining procedure: k4888 
o|inlining procedure: k5400 
o|inlining procedure: k5621 
o|inlining procedure: k5880 
o|inlining procedure: k6753 
o|inlining procedure: k6856 
o|inlining procedure: k7046 
o|inlining procedure: k7061 
o|inlining procedure: k7110 
o|inlining procedure: k71108287 
o|inlining procedure: k7760 
o|replaced variables: 87 
o|removed binding forms: 128 
o|contracted procedure: k2956 
o|contracted procedure: k2960 
o|contracted procedure: k3228 
o|contracted procedure: k3237 
o|contracted procedure: k3334 
o|contracted procedure: k3444 
o|contracted procedure: k3406 
o|contracted procedure: k3414 
o|contracted procedure: k3525 
o|contracted procedure: k3462 
o|contracted procedure: k3489 
o|contracted procedure: k3504 
o|contracted procedure: k4027 
o|contracted procedure: k4030 
o|contracted procedure: k4033 
o|contracted procedure: k4036 
o|contracted procedure: k4039 
o|contracted procedure: k4326 
o|contracted procedure: k4281 
o|contracted procedure: k4239 
o|contracted procedure: k4104 
o|contracted procedure: k4330 
o|contracted procedure: k4884 
o|contracted procedure: k5016 
o|contracted procedure: k5094 
o|contracted procedure: k5097 
o|contracted procedure: k5100 
o|contracted procedure: k5103 
o|contracted procedure: k5119 
o|contracted procedure: k3715 
o|contracted procedure: k3718 
o|contracted procedure: k3721 
o|contracted procedure: k5874 
o|contracted procedure: k5877 
o|contracted procedure: k6707 
o|contracted procedure: k6733 
o|contracted procedure: k6770 
o|contracted procedure: k6867 
o|removed binding forms: 74 
o|replaced variables: 27 
o|removed binding forms: 15 
o|direct leaf routine/allocation: g511512 3 
o|direct leaf routine with hoistable closures/allocation: g495502 (g511512) 3 
o|contracted procedure: "(modules.scm:164) k3293" 
o|removed binding forms: 2 
o|customizable procedures: (g20472054 for-each-loop20462058 map-loop20652083 loop2020 merr1993 map-loop19962013 err1985 loop21956 k7325 loop1944 iface1934 err1933 g19031904 mrename1867 g18751876 g16401647 for-each-loop16391843 g16721679 for-each-loop16711691 g16991706 for-each-loop16981710 map-loop17761793 map-loop18021819 map-loop17221739 map-loop17481765 k6679 k6596 k5908 k5917 tostr1400 map-loop15841601 map-loop16101627 g15741575 g15701571 loop1534 for-each-loop15521563 map-loop14931510 loop1517 loop1524 map-loop14471464 g14851486 g14811482 loop1471 import-spec1402 import-name1401 map-loop11241142 loop1150 k5545 k5557 k5529 loop1158 g11791186 for-each-loop11781250 g673674 g666667 k3862 warn639 loop2657 loop651 map-loop12581283 g12941301 for-each-loop12931308 g11951202 for-each-loop11941206 g12261233 for-each-loop12251238 k5023 k5053 loop1095 map-loop10331051 g10661075 map-loop10601081 map-loop854872 map-loop882900 map-loop910928 g940947 for-each-loop939953 g961968 for-each-loop960974 g982989 for-each-loop981995 merge-se k4046 k4054 map-loop721738 k4318 map-loop747771 g786795 map-loop780813 loop820 k4090 loop692 k3652 for-each-loop608628 g579580 k3548 for-each-loop494514 g478479 k3184 g439440 loop430 map-loop397415) 
o|calls to known targets: 253 
o|identified direct recursive calls: f_3041 2 
o|identified direct recursive calls: f_3285 1 
o|identified direct recursive calls: f_3988 2 
o|identified direct recursive calls: f_4108 1 
o|identified direct recursive calls: f_5027 1 
o|identified direct recursive calls: f_3792 1 
o|identified direct recursive calls: f_5500 1 
o|identified direct recursive calls: f_5978 1 
o|identified direct recursive calls: f_6113 2 
o|identified direct recursive calls: f_6101 2 
o|identified direct recursive calls: f_6228 2 
o|identified direct recursive calls: f_6782 2 
o|identified direct recursive calls: f_6817 2 
o|identified direct recursive calls: f_6882 2 
o|identified direct recursive calls: f_6917 2 
o|identified direct recursive calls: f_7354 1 
o|identified direct recursive calls: f_7255 2 
o|identified direct recursive calls: f_7472 2 
o|fast box initializations: 56 
o|fast global references: 15 
o|fast global assignments: 2 
o|dropping unused closure argument: f_3973 
o|dropping unused closure argument: f_5869 
*/
/* end of file */
