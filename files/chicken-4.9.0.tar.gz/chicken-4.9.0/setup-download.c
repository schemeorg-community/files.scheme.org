/* Generated from setup-download.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:40
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: setup-download.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -feature chicken-compile-shared -dynamic -emit-import-library setup-download -output-file setup-download.c
   used units: library eval chicken_2dsyntax extras irregex posix utils srfi_2d1 data_2dstructures tcp srfi_2d13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_irregex_toplevel)
C_externimport void C_ccall C_irregex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_2d1_toplevel)
C_externimport void C_ccall C_srfi_2d1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_2d13_toplevel)
C_externimport void C_ccall C_srfi_2d13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[257];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,100,32,102,115,116,114,49,53,55,32,97,114,103,115,49,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,40),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,101,116,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,101,120,105,115,116,105,110,103,45,118,101,114,115,105,111,110,32,101,103,103,49,54,57,32,118,101,114,115,105,111,110,49,55,48,32,118,115,49,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,7),40,97,49,53,51,53,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,51,52,54,32,103,51,53,51,51,53,57,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,97,49,55,49,55,32,103,51,51,57,51,52,48,51,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,33),40,97,49,53,55,50,32,115,114,99,50,56,52,50,56,53,50,57,49,32,118,101,114,50,56,54,50,56,55,50,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,59),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,108,111,99,97,108,32,101,103,103,50,54,49,32,100,105,114,50,54,50,32,46,32,116,109,112,50,54,48,50,54,51,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,7),40,97,49,56,49,52,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,97,49,56,55,50,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,13),40,97,49,56,54,54,32,101,120,51,56,54,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,7),40,97,49,56,56,55,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,7),40,97,49,56,57,57,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,20),40,97,49,56,57,51,32,46,32,97,114,103,115,51,56,48,51,56,56,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,49,56,56,49,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,15),40,97,49,56,54,48,32,107,51,55,57,51,56,53,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,97,49,56,51,53,32,114,101,116,117,114,110,51,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,37),40,97,49,56,50,48,32,108,111,99,51,54,56,51,54,57,51,55,50,32,118,101,114,115,105,111,110,51,55,48,51,55,49,51,55,51,41,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,49,56,48,56,32,101,103,103,51,54,55,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,97,116,104,101,114,45,101,103,103,45,105,110,102,111,114,109,97,116,105,111,110,32,100,105,114,51,54,53,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,66),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,109,97,107,101,45,115,118,110,45,108,115,45,99,109,100,32,117,97,114,103,51,57,53,32,112,97,114,103,51,57,54,32,112,110,97,109,51,57,55,32,116,109,112,51,57,52,51,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,50,50,50,52,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,37),40,97,50,50,53,50,32,102,105,108,101,100,105,114,53,51,52,53,51,53,53,51,57,32,118,101,114,53,51,54,53,51,55,53,52,48,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,50,51,49,56,32,102,53,51,50,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,115,118,110,32,101,103,103,53,49,48,32,114,101,112,111,53,49,49,32,46,32,116,109,112,53,48,57,53,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,39),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,100,101,99,111,110,115,116,114,117,99,116,45,117,114,108,32,117,114,108,53,53,53,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,7),40,97,50,52,56,55,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,51,48,56,56,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,11),40,103,55,51,48,32,109,55,51,50,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,6),40,115,107,105,112,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,7),40,97,51,48,54,49,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,102,105,108,101,115,32,102,105,108,101,115,55,52,56,41,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,32),40,97,51,48,57,52,32,105,110,55,56,51,55,56,52,55,56,55,32,111,117,116,55,56,53,55,56,54,55,56,56,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,49),40,97,50,52,57,51,32,104,111,115,116,53,57,55,53,57,56,54,48,51,32,112,111,114,116,53,57,57,54,48,48,54,48,52,32,108,111,99,110,54,48,49,54,48,50,54,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,104,116,116,112,32,101,103,103,53,55,50,32,117,114,108,53,55,51,32,46,32,116,109,112,53,55,49,53,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,7),40,97,50,54,55,51,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,50,54,55,54,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,50,54,55,57,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,50,54,56,50,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,78),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,109,97,107,101,45,72,84,84,80,45,71,69,84,47,49,46,49,32,108,111,99,97,116,105,111,110,54,50,56,32,117,115,101,114,45,97,103,101,110,116,54,50,57,32,104,111,115,116,54,51,48,32,116,109,112,54,50,55,54,51,49,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,53),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,114,101,115,112,111,110,115,101,45,109,97,116,99,104,45,99,111,100,101,63,32,109,114,115,112,54,52,51,32,99,111,100,101,54,52,52,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,97,50,55,50,57,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,99,104,117,110,107,115,32,100,97,116,97,56,50,53,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,50,56,50,51,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,36),40,97,50,56,50,57,32,105,110,112,120,54,56,55,54,56,56,54,57,49,32,111,117,116,112,120,54,56,57,54,57,48,54,57,50,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,32),40,97,50,55,52,51,32,105,110,54,55,48,54,55,49,54,56,48,32,111,117,116,54,55,50,54,55,51,54,56,49,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,100),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,104,116,116,112,45,99,111,110,110,101,99,116,32,104,111,115,116,54,52,57,32,112,111,114,116,54,53,48,32,108,111,99,110,54,53,49,32,112,114,111,120,121,45,104,111,115,116,54,53,50,32,112,114,111,120,121,45,112,111,114,116,54,53,51,32,112,114,111,120,121,45,117,115,101,114,45,112,97,115,115,54,53,52,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,39),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,99,104,101,99,107,45,101,103,103,45,110,97,109,101,32,110,97,109,101,56,52,49,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,51,50,57,54,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,7),40,97,51,51,48,53,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,51,51,52,52,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,51,51,53,51,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,80),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,114,101,116,114,105,101,118,101,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,56,52,56,32,116,114,97,110,115,112,111,114,116,56,52,57,32,108,111,99,97,116,105,111,110,56,53,48,32,46,32,116,109,112,56,52,55,56,53,49,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,51,51,56,48,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,49,56,49,32,103,49,57,51,50,48,55,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,52,50,56,32,103,52,52,48,52,52,55,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,51,49,48,54,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,7),40,97,51,49,49,56,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,32),40,97,51,49,50,56,32,105,110,56,48,56,56,48,57,56,49,50,32,111,117,116,56,49,48,56,49,49,56,49,51,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,49),40,97,51,49,49,50,32,104,111,115,116,55,57,54,55,57,55,56,48,50,32,112,111,114,116,55,57,56,55,57,57,56,48,51,32,108,111,99,110,56,48,48,56,48,49,56,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,7),40,97,51,51,56,53,41,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,7),40,97,51,52,50,52,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,69),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,115,32,116,114,97,110,115,112,111,114,116,57,48,55,32,108,111,99,97,116,105,111,110,57,48,56,32,46,32,116,109,112,57,48,54,57,48,57,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,7),40,97,51,52,52,55,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,50,51,32,103,50,51,53,50,52,57,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,52,55,57,32,103,52,57,49,52,57,56,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,7),40,97,51,52,53,50,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,7),40,97,51,52,56,48,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,85),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,115,32,110,97,109,101,57,51,56,32,116,114,97,110,115,112,111,114,116,57,51,57,32,108,111,99,97,116,105,111,110,57,52,48,32,46,32,116,109,112,57,51,55,57,52,49,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_fcall f_2934(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_fcall f_2912(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3089)
static void C_ccall f_3089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_fcall f_1583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_fcall f_1983(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_fcall f_2721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_fcall f_2633(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f3687)
static void C_ccall f3687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_fcall f_2395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f3683)
static void C_ccall f3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_fcall f_3240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_fcall f_1906(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_fcall f_2793(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_fcall f_3169(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_fcall f_1695(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_fcall f_2104(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_fcall f_2984(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_fcall f_1316(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_fcall f_2971(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_ccall f_1287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_fcall f_1399(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1461)
static void C_fcall f_1461(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2698)
static void C_fcall f_2698(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_fcall f_2889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_fcall f_1332(C_word t0) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_fcall f_1347(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2934)
static void C_fcall trf_2934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2934(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2934(t0,t1);}

C_noret_decl(trf_2912)
static void C_fcall trf_2912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2912(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2912(t0,t1,t2);}

C_noret_decl(trf_1583)
static void C_fcall trf_1583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1583(t0,t1);}

C_noret_decl(trf_1983)
static void C_fcall trf_1983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1983(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1983(t0,t1,t2);}

C_noret_decl(trf_2721)
static void C_fcall trf_2721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2721(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2721(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2633)
static void C_fcall trf_2633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2633(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2633(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2395)
static void C_fcall trf_2395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2395(t0,t1);}

C_noret_decl(trf_3240)
static void C_fcall trf_3240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3240(t0,t1);}

C_noret_decl(trf_1906)
static void C_fcall trf_1906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1906(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1906(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2793)
static void C_fcall trf_2793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2793(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2793(t0,t1);}

C_noret_decl(trf_3169)
static void C_fcall trf_3169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3169(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3169(t0,t1,t2);}

C_noret_decl(trf_1695)
static void C_fcall trf_1695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1695(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1695(t0,t1,t2);}

C_noret_decl(trf_2104)
static void C_fcall trf_2104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2104(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2104(t0,t1,t2);}

C_noret_decl(trf_2984)
static void C_fcall trf_2984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2984(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2984(t0,t1);}

C_noret_decl(trf_1316)
static void C_fcall trf_1316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1316(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1316(t0,t1,t2);}

C_noret_decl(trf_2971)
static void C_fcall trf_2971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2971(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2971(t0,t1,t2);}

C_noret_decl(trf_1399)
static void C_fcall trf_1399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1399(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1399(t0,t1,t2);}

C_noret_decl(trf_1461)
static void C_fcall trf_1461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1461(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1461(t0,t1,t2);}

C_noret_decl(trf_2698)
static void C_fcall trf_2698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2698(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2698(t0,t1,t2);}

C_noret_decl(trf_2889)
static void C_fcall trf_2889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2889(t0,t1);}

C_noret_decl(trf_1332)
static void C_fcall trf_1332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1332(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1332(t0);}

C_noret_decl(trf_1347)
static void C_fcall trf_1347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1347(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1347(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:49: tcp-connect-timeout");
t3=C_fast_retrieve(lf[254]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(30000));}

/* a2673 in k2641 in k2638 in k2635 in setup-download#make-HTTP-GET/1.1 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2674,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* a1717 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1718,3,t0,t1,t2);}
t3=C_fast_retrieve(lf[46]);
C_trace("setup-download.scm:125: g342");
t4=C_fast_retrieve(lf[46]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[47],t2);}

/* k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[5],"setup-download#\052windows-shell\052"))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1623,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:116: open-output-string");
t4=C_fast_retrieve(lf[37]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1644,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:117: open-output-string");
t4=C_fast_retrieve(lf[37]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1666,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:114: normalize-pathname");
t4=C_fast_retrieve(lf[41]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1296,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:27: ##sys#require");
((C_proc3)C_fast_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t2,lf[256]);}

/* k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1293,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1670,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:113: normalize-pathname");
t4=C_fast_retrieve(lf[41]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k2932 in k2914 in g730 in k2906 in k2900 in k2891 in skip in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in ... */
static void C_fcall f_2934(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2934,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:348: warning");
t3=C_fast_retrieve(lf[25]);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[5]);
C_trace("setup-download.scm:352: open-input-string");
t3=C_fast_retrieve(lf[103]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2935 in k2932 in k2914 in g730 in k2906 in k2900 in k2891 in skip in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in ... */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
C_trace("setup-download.scm:352: open-input-string");
t3=C_fast_retrieve(lf[103]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k2281 in k2255 in a2252 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2283,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(C_retrieve2(lf[3],"setup-download#\052mode\052"),lf[81]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2293,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:211: create-directory");
t6=C_fast_retrieve(lf[42]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
t5=t3;
f_2287(2,t5,((C_word*)t0)[6]);}}

/* k2285 in k2281 in k2255 in a2252 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(C_retrieve2(lf[0],"setup-download#\052quiet\052"))?lf[78]:lf[79]);
C_trace("setup-download.scm:157: conc");
t3=C_fast_retrieve(lf[66]);
((C_proc15)(void*)(*((C_word*)t3+1)))(15,t3,((C_word*)t0)[2],lf[80],((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[4],C_make_character(32),C_make_character(34),((C_word*)t0)[5],C_make_character(34),C_make_character(32),C_make_character(34),t1,C_make_character(34),t2);}

/* a2682 in setup-download#make-HTTP-GET/1.1 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2683,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(80));}

/* k1703 in for-each-loop346 in k1677 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_1705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1695(t3,((C_word*)t0)[4],t2);}

/* a2679 in k2635 in setup-download#make-HTTP-GET/1.1 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2680,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[165]);}

/* k1566 in k1551 in k1548 in a1535 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm:106: directory?");
t2=C_fast_retrieve(lf[23]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
C_trace("setup-download.scm:108: values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[5],lf[22]);}}

/* setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_2177r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2177r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2177r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a=C_alloc(8);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_nullp(t14);
t16=(C_truep(t15)?C_SCHEME_FALSE:C_i_car(t14));
t17=C_i_nullp(t14);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t14));
t19=C_i_nullp(t18);
t20=(C_truep(t19)?C_SCHEME_FALSE:C_i_car(t18));
t21=t20;
t22=C_i_nullp(t18);
t23=(C_truep(t22)?C_SCHEME_END_OF_LIST:C_i_cdr(t18));
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2205,a[2]=t2,a[3]=t7,a[4]=t3,a[5]=t12,a[6]=t1,a[7]=t21,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
C_trace("setup-download.scm:181: string-append");
t25=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t25+1)))(5,t25,t24,lf[92],t16,lf[93]);}
else{
t25=t24;
f_2205(2,t25,lf[94]);}}

/* a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1809,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1815,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1821,a[2]=t2,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:136: ##sys#call-with-values");
C_call_with_values(4,0,t1,t3,t4);}

/* k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[2],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:135: filter-map");
t3=C_fast_retrieve(lf[61]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}

/* setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1800,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1804,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:134: directory");
t4=C_fast_retrieve(lf[49]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3095,4,t0,t1,t2,t3);}
t4=t1;
t5=t2;
t6=t3;
t7=((C_word*)t0)[2];
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2887,a[2]=t5,a[3]=t6,a[4]=t7,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:336: d");
f_1316(t8,lf[132],C_SCHEME_END_OF_LIST);}

/* k2914 in g730 in k2906 in k2900 in k2891 in skip in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=t1;
t3=C_i_string_equal_p(lf[105],t2);
t4=(C_truep(t3)?t3:C_u_i_string_equal_p(lf[106],t2));
if(C_truep(t4)){
C_trace("setup-download.scm:352: open-input-string");
t5=C_fast_retrieve(lf[103]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2934,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_string_equal_p(t2,((C_word*)((C_word*)t0)[4])[1]);
t7=t5;
f_2934(t7,C_i_not(t6));}
else{
t6=t5;
f_2934(t6,C_SCHEME_FALSE);}}}

/* g730 in k2906 in k2900 in k2891 in skip in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_fcall f_2912(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2912,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2916,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:345: irregex-match-substring");
t4=C_fast_retrieve(lf[83]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(1));}

/* k1973 in k1956 in k1953 in k1950 in k1947 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1975,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[217]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word)li56),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1983(t7,t3,t1);}

/* k1969 in map-loop428 in k1973 in k1956 in k1953 in k1950 in k1947 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#string-append");
((C_proc4)C_fast_retrieve_symbol_proc(lf[218]))(4,*((C_word*)lf[218]+1),((C_word*)t0)[2],t1,lf[219]);}

/* a3088 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_3089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3089,2,t0,t1);}
C_trace("setup-download.scm:382: http-connect");
f_2721(t1,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k3058 in k3044 in k3041 in k3038 in k3022 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3062,a[2]=((C_word*)t0)[2],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:377: with-output-to-file");
t3=C_fast_retrieve(lf[126]);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],t1,t2,lf[127]);}

/* k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_fcall f_1583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1583,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("setup-download.scm:110: values");
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[28]);}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:112: create-directory");
t3=C_fast_retrieve(lf[42]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1679,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1718,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1726,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:125: directory");
t6=C_fast_retrieve(lf[49]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[5]);}
else{
C_trace("setup-download.scm:131: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}}}}

/* k2906 in k2900 in k2891 in skip in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:337: g730");
t3=t2;
f_2912(t3,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:353: string-every");
t3=C_fast_retrieve(lf[109]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fast_retrieve(lf[110]),((C_word*)t0)[2]);}}

/* map-loop428 in k1973 in k1956 in k1953 in k1950 in k1947 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_fcall f_1983(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1983,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1971,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:166: string-chomp");
t7=C_fast_retrieve(lf[220]);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,lf[221]);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2900 in k2891 in skip in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2902,2,t0,t1);}
if(C_truep(t1)){
C_trace("setup-download.scm:342: open-input-string");
t2=C_fast_retrieve(lf[103]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[104]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:343: irregex-match");
t3=C_fast_retrieve(lf[98]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[111],((C_word*)t0)[3]);}}

/* k1979 in k1973 in k1956 in k1953 in k1950 in k1947 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:165: string-concatenate");
t2=C_fast_retrieve(lf[215]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2090 in map-loop479 in k2094 in k2071 in k2068 in k2065 in k2062 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#string-append");
((C_proc4)C_fast_retrieve_symbol_proc(lf[218]))(4,*((C_word*)lf[218]+1),((C_word*)t0)[2],t1,lf[238]);}

/* k2625 in k2844 in k2817 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2627,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:258: make-property-condition");
t4=C_fast_retrieve(lf[116]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[181]);}

/* k2621 in k2844 in k2817 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:252: signal");
t2=C_fast_retrieve(lf[180]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2065 in k2062 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2067,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2070,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2141,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2145,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:172: string-append");
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[5],lf[240]);}

/* k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li41),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word)li46),tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:298: ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[8],t2,t3);}

/* setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_fcall f_2721(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2721,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2725,a[2]=t5,a[3]=t2,a[4]=t6,a[5]=t3,a[6]=t4,a[7]=t7,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2857,a[2]=t8,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2860,a[2]=t9,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:296: open-output-string");
t11=C_fast_retrieve(lf[37]);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
C_trace("setup-download.scm:294: d");
f_1316(t8,lf[188],C_a_i_list(&a,3,t2,t3,lf[191]));}}

/* a3061 in k3058 in k3044 in k3041 in k3038 in k3022 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in ... */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3062,2,t0,t1);}
C_trace("setup-download.scm:377: g768");
t2=*((C_word*)lf[125]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k3131 in a3128 in a3112 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:393: close-input-port");
t4=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k3134 in k3131 in a3128 in a3112 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:394: close-output-port");
t3=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2094 in k2071 in k2068 in k2065 in k2062 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[217]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2104(t7,t3,t1);}

/* k3137 in k3134 in k3131 in a3128 in a3112 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k2711 in k2707 in setup-download#response-match-code? in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_string_equal_p(((C_word*)t0)[3],t1));}

/* k2071 in k2068 in k2065 in k2062 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2073,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[237]);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:178: with-input-from-pipe");
t7=C_fast_retrieve(lf[86]);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],C_fast_retrieve(lf[87]));}}

/* k2641 in k2638 in k2635 in setup-download#make-HTTP-GET/1.1 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2643,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:260: ##sys#get-keyword");
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t3,lf[162],((C_word*)t0)[2],t4);}

/* k2068 in k2065 in k2062 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2070,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:173: with-input-from-pipe");
t4=C_fast_retrieve(lf[86]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fast_retrieve(lf[87]));}

/* k2644 in k2641 in k2638 in k2635 in setup-download#make-HTTP-GET/1.1 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=t1;
t3=C_i_get_keyword(lf[141],((C_word*)t0)[2],C_SCHEME_FALSE);
t4=C_i_get_keyword(lf[142],((C_word*)t0)[2],C_SCHEME_FALSE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
C_trace("setup-download.scm:270: string-append");
t7=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[160],((C_word*)t0)[7],((C_word*)t0)[9]);}
else{
t7=t6;
f_2662(2,t7,((C_word*)t0)[9]);}}

/* k2638 in k2635 in setup-download#make-HTTP-GET/1.1 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2640,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2677,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:260: ##sys#get-keyword");
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t3,lf[164],((C_word*)t0)[2],t4);}

/* setup-download#make-HTTP-GET/1.1 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_fcall f_2633(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2633,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2637,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2683,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:260: ##sys#get-keyword");
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t6,lf[167],t5,t7);}

/* k2635 in setup-download#make-HTTP-GET/1.1 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:260: ##sys#get-keyword");
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t3,lf[166],((C_word*)t0)[2],t4);}

/* a3112 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3113,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=t3;
t7=t4;
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3119,a[2]=t5,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t7,a[8]=((C_word)li58),tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:385: ##sys#call-with-values");
C_call_with_values(4,0,t1,t8,t9);}

/* k2629 in k2625 in k2844 in k2817 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:253: make-composite-condition");
t2=C_fast_retrieve(lf[115]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* a3118 in a3112 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3127,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:390: string-append");
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],lf[229]);}

/* k2707 in setup-download#response-match-code? in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2709,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2713,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:288: irregex-match-substring");
t4=C_fast_retrieve(lf[83]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}

/* setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2443r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2443r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2443r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word *a=C_alloc(10);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=C_i_nullp(t9);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_FALSE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_nullp(t18);
t20=(C_truep(t19)?C_SCHEME_FALSE:C_i_car(t18));
t21=t20;
t22=C_i_nullp(t18);
t23=(C_truep(t22)?C_SCHEME_END_OF_LIST:C_i_cdr(t18));
t24=C_i_nullp(t23);
t25=(C_truep(t24)?C_SCHEME_FALSE:C_i_car(t23));
t26=t25;
t27=C_i_nullp(t23);
t28=(C_truep(t27)?C_SCHEME_END_OF_LIST:C_i_cdr(t23));
t29=C_i_nullp(t28);
t30=(C_truep(t29)?C_SCHEME_FALSE:C_i_car(t28));
t31=t30;
t32=C_i_nullp(t28);
t33=(C_truep(t32)?C_SCHEME_END_OF_LIST:C_i_cdr(t28));
t34=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2483,a[2]=t3,a[3]=t7,a[4]=t21,a[5]=t26,a[6]=t31,a[7]=t2,a[8]=t16,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t11)){
t35=t34;
f_2483(2,t35,t11);}
else{
C_trace("setup-download.scm:236: get-temporary-directory");
f_1332(t34);}}

/* k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2488,a[2]=((C_word*)t0)[2],a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li33),tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:234: ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[9],t3,t4);}

/* k2660 in k2644 in k2641 in k2638 in k2635 in setup-download#make-HTTP-GET/1.1 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[9])){
C_trace("setup-download.scm:278: string-append");
t4=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[157],((C_word*)t0)[9],lf[158]);}
else{
t4=t3;
f_2666(2,t4,lf[159]);}}

/* k2664 in k2660 in k2644 in k2641 in k2638 in k2635 in setup-download#make-HTTP-GET/1.1 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:267: conc");
t2=C_fast_retrieve(lf[66]);
((C_proc25)(void*)(*((C_word*)t2+1)))(25,t2,((C_word*)t0)[2],lf[143],((C_word*)t0)[3],lf[144],lf[145],lf[146],((C_word*)t0)[4],lf[147],lf[148],((C_word*)t0)[5],lf[149],lf[150],((C_word*)t0)[6],lf[151],lf[152],((C_word*)t0)[7],C_make_character(58),((C_word*)t0)[8],lf[153],t1,lf[154],((C_word*)t0)[9],lf[155],lf[156]);}

/* k1442 in k1436 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1444,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1456,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:91: directory");
t7=C_fast_retrieve(lf[49]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[234]);}}

/* k3147 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:398: abort");
t2=C_fast_retrieve(lf[114]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,tmp=(C_word)a,a+=14,tmp);
C_trace("setup-download.scm:309: d");
f_1316(t3,lf[183],C_a_i_list(&a,1,((C_word*)t0)[12]));}

/* k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word)li43),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2793(t6,t2);}

/* k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2819,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
C_trace("setup-download.scm:311: response-match-code?");
f_2698(t3,((C_word*)t0)[13],C_fix(407));}

/* k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2760,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_stringp(t2))){
C_trace("setup-download.scm:285: irregex-match");
t4=C_fast_retrieve(lf[98]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[184],t2);}
else{
t4=t3;
f_2763(2,t4,C_SCHEME_FALSE);}}

/* a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2494,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=t3;
t7=t4;
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2498,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t6,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[8],a[3]=t8,a[4]=t7,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-download.scm:241: string-append");
t10=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,lf[138],((C_word*)t0)[2]);}
else{
t10=t9;
f_2527(2,t10,lf[139]);}}

/* k2062 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
C_trace("setup-download.scm:171: string-append");
t4=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[241],((C_word*)t0)[5],lf[242]);}
else{
t4=t3;
f_2067(2,t4,lf[243]);}}

/* a2487 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
C_trace("setup-download.scm:237: deconstruct-url");
f_2395(t1,((C_word*)t0)[2]);}

/* f3687 in k2813 in k2801 in k2795 in loop in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in ... */
static void C_ccall f3687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:327: loop");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2793(t2,((C_word*)t0)[3]);}

/* k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:305: d");
f_1316(t2,lf[185],C_SCHEME_END_OF_LIST);}

/* k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2757,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2760,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("setup-download.scm:307: read-line");
t5=C_fast_retrieve(lf[113]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:304: flush-output");
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_2498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2498,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:244: make-pathname");
t4=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[9],((C_word*)t0)[10]);}

/* a1535 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1536,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1547,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:103: make-pathname");
t3=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1550,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:104: make-pathname");
t3=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[27]);}}

/* k3125 in a3118 in a3112 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:388: http-connect");
f_2721(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1110)){
C_save(t1);
C_rereclaim2(1110*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,257);
lf[4]=C_h_intern(&lf[4],7,"default");
lf[7]=C_h_intern(&lf[7],18,"\003sysstandard-error");
lf[8]=C_h_intern(&lf[8],19,"\003sysstandard-output");
lf[9]=C_h_intern(&lf[9],12,"flush-output");
lf[10]=C_h_intern(&lf[10],7,"fprintf");
lf[11]=C_h_intern(&lf[11],34,"setup-download#temporary-directory");
lf[13]=C_h_intern(&lf[13],26,"create-temporary-directory");
lf[15]=C_h_intern(&lf[15],5,"error");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\021version not found");
lf[17]=C_h_intern(&lf[17],4,"sort");
lf[18]=C_h_intern(&lf[18],20,"setup-api#version>=\077");
lf[19]=C_h_intern(&lf[19],31,"setup-download#locate-egg/local");
lf[20]=C_h_intern(&lf[20],13,"make-pathname");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[23]=C_h_intern(&lf[23],10,"directory\077");
lf[24]=C_h_intern(&lf[24],12,"file-exists\077");
lf[25]=C_h_intern(&lf[25],7,"warning");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000-extension has no such version - using default");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[30]=C_h_intern(&lf[30],6,"system");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[32]=C_h_intern(&lf[32],7,"sprintf");
lf[33]=C_h_intern(&lf[33],17,"get-output-string");
lf[34]=C_h_intern(&lf[34],9,"\003sysprint");
lf[35]=C_h_intern(&lf[35],16,"\003syswrite-char-0");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\006xcopy ");
lf[37]=C_h_intern(&lf[37],18,"open-output-string");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\003/\052 ");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\006cp -r ");
lf[40]=C_h_intern(&lf[40],2,"qs");
lf[41]=C_h_intern(&lf[41],18,"normalize-pathname");
lf[42]=C_h_intern(&lf[42],16,"create-directory");
lf[43]=C_h_intern(&lf[43],8,"for-each");
lf[44]=C_h_intern(&lf[44],12,"delete-file\052");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\0006 deleting stale file `~a\047 from local build directory~%");
lf[46]=C_h_intern(&lf[46],14,"string-suffix\077");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[48]=C_h_intern(&lf[48],6,"filter");
lf[49]=C_h_intern(&lf[49],9,"directory");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\004tags");
lf[51]=C_h_intern(&lf[51],37,"setup-download#gather-egg-information");
lf[52]=C_h_intern(&lf[52],7,"version");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000.extension has syntactically invalid .meta file");
lf[54]=C_h_intern(&lf[54],20,"with-input-from-file");
lf[55]=C_h_intern(&lf[55],4,"read");
lf[56]=C_h_intern(&lf[56],22,"with-exception-handler");
lf[57]=C_h_intern(&lf[57],30,"call-with-current-continuation");
lf[58]=C_h_intern(&lf[58],14,"string->symbol");
lf[59]=C_h_intern(&lf[59],7,"call/cc");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[61]=C_h_intern(&lf[61],10,"filter-map");
lf[63]=C_h_intern(&lf[63],11,"\000recursive\077");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\004 -R ");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[66]=C_h_intern(&lf[66],4,"conc");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\007svn ls ");
lf[68]=C_h_intern(&lf[68],29,"setup-download#locate-egg/svn");
lf[69]=C_h_intern(&lf[69],13,"string-append");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\005tags/");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\006trunk/");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\005 1>&2");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\013svn export ");
lf[81]=C_h_intern(&lf[81],4,"meta");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\005.meta");
lf[83]=C_h_intern(&lf[83],23,"irregex-match-substring");
lf[84]=C_h_intern(&lf[84],14,"irregex-search");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\016^tags/([^/]+)/");
lf[86]=C_h_intern(&lf[86],20,"with-input-from-pipe");
lf[87]=C_h_intern(&lf[87],10,"read-lines");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\047checking available versions ...~%  ~a~%");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\020not a valid port");
lf[98]=C_h_intern(&lf[98],13,"irregex-match");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000$(http://)\077([^/:]+)(:([^:/]+))\077(/.\052)\077");
lf[100]=C_h_intern(&lf[100],30,"setup-download#locate-egg/http");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[103]=C_h_intern(&lf[103],17,"open-input-string");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\002#f");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000 files-versions are not identical");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000=unrecognized file-information - possibly corrupt transmission");
lf[109]=C_h_intern(&lf[109],12,"string-every");
lf[110]=C_h_intern(&lf[110],19,"char-set:whitespace");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\031 \052#\134|[- ]\052([^- ]\052) \052\134|#.\052");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\011 \052#!eof \052");
lf[113]=C_h_intern(&lf[113],9,"read-line");
lf[114]=C_h_intern(&lf[114],5,"abort");
lf[115]=C_h_intern(&lf[115],24,"make-composite-condition");
lf[116]=C_h_intern(&lf[116],23,"make-property-condition");
lf[117]=C_h_intern(&lf[117],20,"setup-download-error");
lf[118]=C_h_intern(&lf[118],3,"exn");
lf[119]=C_h_intern(&lf[119],7,"message");
lf[120]=C_h_intern(&lf[120],9,"arguments");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\011[Server] ");
lf[122]=C_h_intern(&lf[122],17,"close-output-port");
lf[123]=C_h_intern(&lf[123],16,"close-input-port");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[125]=C_h_intern(&lf[125],7,"display");
lf[126]=C_h_intern(&lf[126],19,"with-output-to-file");
lf[127]=C_h_intern(&lf[127],7,"\000binary");
lf[128]=C_h_intern(&lf[128],20,"\003sysread-string/port");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\0001invalid file name - possibly corrupt transmission");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\023reading files ...~%");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\006\077name=");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\006&mode=");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\012&tests=yes");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[137]=C_h_intern(&lf[137],8,"->string");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\011&version=");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[141]=C_h_intern(&lf[141],11,"\000proxy-host");
lf[142]=C_h_intern(&lf[142],16,"\000proxy-user-pass");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\004GET ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\011 HTTP/1.1");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\014Connection: ");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\014User-Agent: ");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\010Accept: ");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\006Host: ");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\020Content-length: ");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\033Proxy-Authorization: Basic ");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\007http://");
lf[161]=C_h_intern(&lf[161],15,"\003sysget-keyword");
lf[162]=C_h_intern(&lf[162],15,"\000content-length");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[164]=C_h_intern(&lf[164],7,"\000accept");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\005close");
lf[166]=C_h_intern(&lf[166],11,"\000connection");
lf[167]=C_h_intern(&lf[167],5,"\000port");
lf[169]=C_h_intern(&lf[169],11,"tcp-connect");
lf[170]=C_h_intern(&lf[170],26,"string-concatenate-reverse");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002~%");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000/invalid response from server - please try again");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\017reading chunks ");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000$[Tt]ransfer-[Ee]ncoding:\134s\052chunked.\052");
lf[177]=C_h_intern(&lf[177],12,"string-null\077");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\003\052/\052");
lf[179]=C_h_intern(&lf[179],11,"\000proxy-port");
lf[180]=C_h_intern(&lf[180],6,"signal");
lf[181]=C_h_intern(&lf[181],10,"http-fetch");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid response from server");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\034HTTP/[0-9.]+\134s+([0-9]+)\134s+.\052");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\026reading response ...~%");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\003\052/\052");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\023requesting ~s ...~%");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000&connecting to host ~s, port ~a ~a...~%");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\005(via ");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension name");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[198]=C_h_intern(&lf[198],12,"string-index");
lf[199]=C_h_intern(&lf[199],33,"setup-download#retrieve-extension");
lf[200]=C_h_intern(&lf[200],8,"\000version");
lf[201]=C_h_intern(&lf[201],6,"\000quiet");
lf[202]=C_h_intern(&lf[202],12,"\000destination");
lf[203]=C_h_intern(&lf[203],9,"\000username");
lf[204]=C_h_intern(&lf[204],9,"\000password");
lf[205]=C_h_intern(&lf[205],6,"\000tests");
lf[206]=C_h_intern(&lf[206],6,"\000trunk");
lf[207]=C_h_intern(&lf[207],6,"\000clean");
lf[208]=C_h_intern(&lf[208],5,"local");
lf[209]=C_h_intern(&lf[209],3,"svn");
lf[210]=C_h_intern(&lf[210],4,"http");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\0001cannot retrieve extension - unsupported transport");
lf[212]=C_h_intern(&lf[212],16,"\003sysdynamic-wind");
lf[213]=C_h_intern(&lf[213],5,"\000mode");
lf[214]=C_h_intern(&lf[214],30,"setup-download#list-extensions");
lf[215]=C_h_intern(&lf[215],18,"string-concatenate");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[217]=C_h_intern(&lf[217],3,"map");
lf[218]=C_h_intern(&lf[218],17,"\003sysstring-append");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[220]=C_h_intern(&lf[220],12,"string-chomp");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\047listing extension directory ...~%  ~a~%");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\007\077list=1");
lf[230]=C_h_intern(&lf[230],8,"read-all");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[232]=C_h_intern(&lf[232],38,"setup-download#list-extension-versions");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\010unknown\012");
lf[235]=C_h_intern(&lf[235],17,"directory-exists\077");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\005/tags");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\010unknown\012");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\005/tags");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[248]=C_h_intern(&lf[248],8,"char-set");
lf[249]=C_h_intern(&lf[249],14,"make-parameter");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install ");
lf[251]=C_h_intern(&lf[251],15,"chicken-version");
lf[252]=C_h_intern(&lf[252],17,"tcp-write-timeout");
lf[253]=C_h_intern(&lf[253],16,"tcp-read-timeout");
lf[254]=C_h_intern(&lf[254],19,"tcp-connect-timeout");
lf[255]=C_h_intern(&lf[255],11,"\003sysrequire");
lf[256]=C_h_intern(&lf[256],9,"setup-api");
C_register_lf2(lf,257,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1260,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* a3128 in a3112 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3129,4,t0,t1,t2,t3);}
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3133,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:392: read-all");
t7=C_fast_retrieve(lf[230]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}

/* k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1531,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li3),tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1573,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word)li6),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:94: ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[8],t3,t4);}

/* a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2744,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=t3;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2748,a[2]=t5,a[3]=t1,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:299: d");
f_1316(t8,lf[187],C_a_i_list(&a,1,((C_word*)t0)[4]));}

/* k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2853,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:301: make-HTTP-GET/1.1");
f_2633(t3,((C_word*)t0)[7],C_retrieve2(lf[1],"setup-download#\052chicken-install-user-agent\052"),((C_word*)t0)[8],C_a_i_list(&a,8,lf[167],((C_word*)t0)[9],lf[164],lf[186],lf[141],((C_word*)t0)[5],lf[179],((C_word*)t0)[6]));}

/* k2412 in k2408 in k2404 in k2397 in setup-download#deconstruct-url in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
C_trace("setup-download.scm:224: values");
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t2);}
else{
C_trace("setup-download.scm:224: values");
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[96]);}}

/* k2408 in k2404 in k2397 in setup-download#deconstruct-url in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2410,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-download.scm:231: irregex-match-substring");
t4=C_fast_retrieve(lf[83]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_fix(5));}
else{
t4=t3;
f_2414(2,t4,C_SCHEME_FALSE);}}

/* a2729 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2730,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
if(C_truep(t4)){
C_trace("setup-download.scm:298: tcp-connect");
t5=C_fast_retrieve(lf[169]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}
else{
t5=((C_word*)t0)[5];
C_trace("setup-download.scm:298: tcp-connect");
t6=C_fast_retrieve(lf[169]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t3,t5);}}

/* a3106 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3107,2,t0,t1);}
C_trace("setup-download.scm:386: deconstruct-url");
f_2395(t1,((C_word*)t0)[2]);}

/* setup-download#deconstruct-url in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_fcall f_2395(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2395,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2399,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:223: irregex-match");
t4=C_fast_retrieve(lf[98]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[99],t2);}

/* k2397 in setup-download#deconstruct-url in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2399,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
C_trace("setup-download.scm:225: irregex-match-substring");
t4=C_fast_retrieve(lf[83]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(2));}
else{
t4=t3;
f_2406(2,t4,((C_word*)t0)[3]);}}

/* k2955 in k2906 in k2900 in k2891 in skip in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm:354: skip");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2889(t2,((C_word*)t0)[3]);}
else{
C_trace("setup-download.scm:356: error");
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[108],((C_word*)t0)[4]);}}

/* k2525 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2527,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:242: ->string");
t4=C_fast_retrieve(lf[137]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_retrieve2(lf[3],"setup-download#\052mode\052"));}

/* k2518 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_2504(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("setup-download.scm:245: create-directory");
t2=C_fast_retrieve(lf[42]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* f3683 in k2813 in k2801 in k2795 in loop in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in ... */
static void C_ccall f3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:327: loop");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2793(t2,((C_word*)t0)[3]);}

/* k3245 in setup-download#check-egg-name in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
C_trace("setup-download.scm:428: error");
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[194],((C_word*)t0)[3]);}}

/* k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[7];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[8];
t8=((C_word*)t0)[9];
t9=((C_word*)t0)[10];
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3089,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t7,a[6]=t8,a[7]=t9,a[8]=((C_word)li27),tmp=(C_word)a,a+=9,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3095,a[2]=t6,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:380: ##sys#call-with-values");
C_call_with_values(4,0,t2,t10,t11);}

/* k2505 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
C_trace("setup-download.scm:249: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],t2);}
else{
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-download.scm:249: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
C_trace("setup-download.scm:249: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],lf[101]);}}}

/* k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_2501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2501,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2504,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2520,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:245: file-exists?");
t5=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* setup-download#check-egg-name in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_fcall f_3240(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3240,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3247,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=t2;
if(C_truep((C_truep(C_i_equalp(t5,lf[195]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t5,lf[196]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t5,lf[197]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3234,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:424: string-index");
t7=C_fast_retrieve(lf[198]);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,C_retrieve2(lf[192],"setup-download#slashes"));}}

/* k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2205,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
C_trace("setup-download.scm:182: string-append");
t4=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[89],((C_word*)t0)[7],lf[90]);}
else{
t4=t3;
f_2208(2,t4,lf[91]);}}

/* k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2208,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2333,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:183: make-pathname");
t5=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* a2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2236,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:195: string-append");
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[70],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
if(C_truep(((C_word*)t0)[5])){
C_trace("setup-download.scm:82: warning");
t4=C_fast_retrieve(lf[25]);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[26],t3,((C_word*)t0)[5]);}
else{
if(C_truep(C_i_member(lf[71],((C_word*)t0)[3]))){
C_trace("setup-download.scm:199: values");
C_values(4,0,t1,lf[72],lf[73]);}
else{
C_trace("setup-download.scm:200: values");
C_values(4,0,t1,lf[74],lf[75]);}}}}

/* k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2225,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word)li22),tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:185: ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[9],t3,t4);}

/* setup-download#retrieve-extension in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_3252r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3252r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3252r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a=C_alloc(20);
t6=C_i_get_keyword(lf[200],t5,C_SCHEME_FALSE);
t7=t6;
t8=C_i_get_keyword(lf[201],t5,C_SCHEME_FALSE);
t9=t8;
t10=C_i_get_keyword(lf[202],t5,C_SCHEME_FALSE);
t11=t10;
t12=C_i_get_keyword(lf[203],t5,C_SCHEME_FALSE);
t13=t12;
t14=C_i_get_keyword(lf[204],t5,C_SCHEME_FALSE);
t15=t14;
t16=C_i_get_keyword(lf[205],t5,C_SCHEME_FALSE);
t17=t16;
t18=C_i_get_keyword(lf[141],t5,C_SCHEME_FALSE);
t19=t18;
t20=C_i_get_keyword(lf[179],t5,C_SCHEME_FALSE);
t21=t20;
t22=C_i_get_keyword(lf[142],t5,C_SCHEME_FALSE);
t23=t22;
t24=C_i_get_keyword(lf[206],t5,C_SCHEME_FALSE);
t25=t24;
t26=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3286,a[2]=t5,a[3]=t9,a[4]=t25,a[5]=t3,a[6]=t2,a[7]=t4,a[8]=t7,a[9]=t11,a[10]=t13,a[11]=t15,a[12]=t17,a[13]=t19,a[14]=t21,a[15]=t23,a[16]=t1,tmp=(C_word)a,a+=17,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3354,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:430: ##sys#get-keyword");
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t26,lf[213],t5,t27);}

/* k2298 in k2255 in a2252 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:204: conc");
t2=C_fast_retrieve(lf[66]);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],((C_word*)t0)[3],C_make_character(47),((C_word*)t0)[4],C_make_character(47),t1);}

/* k3284 in setup-download#retrieve-extension in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3286,2,t0,t1);}
t2=t1;
t3=C_i_get_keyword(lf[207],((C_word*)t0)[2],C_SCHEME_FALSE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
C_trace("setup-download.scm:434: check-egg-name");
f_3240(t5,((C_word*)t0)[6]);}

/* k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:185: with-input-from-pipe");
t3=C_fast_retrieve(lf[86]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[9],C_fast_retrieve(lf[87]));}

/* k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2217,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2220,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2317,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2319,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:188: filter-map");
t6=C_fast_retrieve(lf[61]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2211,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:184: d");
f_1316(t3,lf[88],C_a_i_list(&a,1,t2));}

/* k2331 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
C_trace("setup-download.scm:183: make-svn-ls-cmd");
f_1906(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,C_a_i_list(&a,2,lf[63],C_SCHEME_TRUE));}

/* k2529 in k2525 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-download.scm:238: string-append");
t2=*((C_word*)lf[69]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[3],((C_word*)t0)[4],lf[133],((C_word*)t0)[5],((C_word*)t0)[6],lf[134],t1,lf[135]);}
else{
C_trace("setup-download.scm:238: string-append");
t2=*((C_word*)lf[69]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[3],((C_word*)t0)[4],lf[133],((C_word*)t0)[5],((C_word*)t0)[6],lf[134],t1,lf[136]);}}

/* k2010 in map-loop428 in k1973 in k1956 in k1953 in k1950 in k1947 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1983(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1983(t6,((C_word*)t0)[5],t5);}}

/* k2315 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:186: existing-version");
f_1347(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* a2318 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2319,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2323,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:190: irregex-search");
t4=C_fast_retrieve(lf[84]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[85],t2);}

/* k2308 in a2252 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:201: make-pathname");
t2=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* a3296 in k3290 in k3284 in setup-download#retrieve-extension in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3297,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#\052trunk\052"));
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,C_retrieve2(lf[3],"setup-download#\052mode\052"));
t5=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate2(&lf[2] /* (set! setup-download#*trunk* ...) */,((C_word*)((C_word*)t0)[6])[1]);
t7=C_mutate2(&lf[3] /* (set! setup-download#*mode* ...) */,((C_word*)((C_word*)t0)[7])[1]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}

/* k1947 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-download.scm:162: string-append");
t4=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[223],((C_word*)t0)[4],lf[224]);}
else{
t4=t3;
f_1952(2,t4,lf[225]);}}

/* k3290 in k3284 in setup-download#retrieve-extension in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3292,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[3];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[4];
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3297,a[2]=t9,a[3]=t11,a[4]=t13,a[5]=t3,a[6]=t5,a[7]=t7,a[8]=((C_word)li49),tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3306,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word)li50),tmp=(C_word)a,a+=15,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3345,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t9,a[6]=t11,a[7]=t13,a[8]=((C_word)li51),tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:435: ##sys#dynamic-wind");
t17=*((C_word*)lf[212]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[17],t14,t15,t16);}

/* k1919 in setup-download#make-svn-ls-cmd in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:154: conc");
t2=C_fast_retrieve(lf[66]);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[2],lf[67],((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* a3353 in setup-download#retrieve-extension in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3354,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[4]);}

/* setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr4r,(void*)f_3357r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3357r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3357r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a=C_alloc(24);
t5=C_i_get_keyword(lf[201],t4,C_SCHEME_FALSE);
t6=C_i_get_keyword(lf[203],t4,C_SCHEME_FALSE);
t7=t6;
t8=C_i_get_keyword(lf[204],t4,C_SCHEME_FALSE);
t9=t8;
t10=C_i_get_keyword(lf[141],t4,C_SCHEME_FALSE);
t11=t10;
t12=C_i_get_keyword(lf[179],t4,C_SCHEME_FALSE);
t13=t12;
t14=C_i_get_keyword(lf[142],t4,C_SCHEME_FALSE);
t15=t14;
t16=t5;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3381,a[2]=t19,a[3]=t17,a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
t21=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3386,a[2]=t2,a[3]=t3,a[4]=t7,a[5]=t9,a[6]=t11,a[7]=t13,a[8]=t15,a[9]=((C_word)li61),tmp=(C_word)a,a+=10,tmp);
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3425,a[2]=t17,a[3]=t19,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:448: ##sys#dynamic-wind");
t23=*((C_word*)lf[212]+1);
((C_proc5)(void*)(*((C_word*)t23+1)))(5,t23,t1,t20,t21,t22);}

/* k1953 in k1950 in k1947 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:164: d");
f_1316(t3,lf[222],C_a_i_list(&a,1,t2));}

/* k1950 in k1947 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:163: make-svn-ls-cmd");
f_1906(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* k1956 in k1953 in k1950 in k1947 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1975,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:167: with-input-from-pipe");
t7=C_fast_retrieve(lf[86]);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],C_fast_retrieve(lf[87]));}

/* a3344 in k3290 in k3284 in setup-download#retrieve-extension in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3345,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#\052trunk\052"));
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,C_retrieve2(lf[3],"setup-download#\052mode\052"));
t5=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate2(&lf[2] /* (set! setup-download#*trunk* ...) */,((C_word*)((C_word*)t0)[6])[1]);
t7=C_mutate2(&lf[3] /* (set! setup-download#*mode* ...) */,((C_word*)((C_word*)t0)[7])[1]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}

/* setup-download#make-svn-ls-cmd in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_fcall f_1906(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1906,NULL,5,t1,t2,t3,t4,t5);}
t6=C_i_get_keyword(lf[63],t5,C_SCHEME_FALSE);
t7=(C_truep(t6)?lf[64]:lf[65]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1921,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:154: qs");
t10=C_fast_retrieve(lf[40]);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}

/* a1899 in a1893 in a1881 in a1860 in k1842 in a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3386,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[208]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[3];
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1394,a[2]=t4,a[3]=t9,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:85: directory");
t11=C_fast_retrieve(lf[49]);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t5);}
else{
t4=C_eqp(t2,lf[209]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[3];
t7=C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
t8=C_i_nullp(t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:C_i_car(t7));
t10=C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:C_i_cdr(t7));
t12=C_i_nullp(t11);
t13=(C_truep(t12)?C_SCHEME_FALSE:C_i_car(t11));
t14=t13;
t15=C_i_nullp(t11);
t16=(C_truep(t15)?C_SCHEME_END_OF_LIST:C_i_cdr(t11));
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1949,a[2]=t5,a[3]=t6,a[4]=t14,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
C_trace("setup-download.scm:161: string-append");
t18=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t17,lf[226],t9,lf[227]);}
else{
t18=t17;
f_1949(2,t18,lf[228]);}}
else{
t5=C_eqp(t2,lf[210]);
if(C_truep(t5)){
t6=t1;
t7=((C_word*)t0)[3];
t8=((C_word*)t0)[6];
t9=((C_word*)t0)[7];
t10=((C_word*)t0)[8];
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3107,a[2]=t7,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3113,a[2]=t8,a[3]=t9,a[4]=t10,a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:385: ##sys#call-with-values");
C_call_with_values(4,0,t6,t11,t12);}
else{
C_trace("setup-download.scm:459: error");
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[231],((C_word*)t0)[2]);}}}}

/* k3195 in k3212 in get-chunks in k2779 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in ... */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3197,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3200,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:416: d");
f_1316(t3,lf[172],C_SCHEME_END_OF_LIST);}

/* k3189 in k3212 in get-chunks in k2779 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in ... */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:413: string-concatenate-reverse");
t2=C_fast_retrieve(lf[170]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* a3380 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* loop in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_fcall f_2793(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2793,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2797,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:323: read-line");
t3=C_fast_retrieve(lf[113]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k2789 in k2785 in k2782 in k2779 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in ... */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
C_trace("setup-download.scm:333: values");
C_values(4,0,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}

/* k2795 in loop in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2797,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:324: string-null?");
t4=C_fast_retrieve(lf[177]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:329: d");
f_1316(t2,lf[174],C_SCHEME_END_OF_LIST);}
else{
C_trace("setup-download.scm:333: values");
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[5])[1]);}}

/* k2782 in k2779 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:331: close-input-port");
t4=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2779 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3169,a[2]=t5,a[3]=t3,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3169(t7,t2,C_SCHEME_END_OF_LIST);}

/* k2785 in k2782 in k2779 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in ... */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:332: open-input-string");
t3=C_fast_retrieve(lf[103]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k3155 in k3151 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:399: make-composite-condition");
t2=C_fast_retrieve(lf[115]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k3151 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3153,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3157,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:404: make-property-condition");
t4=C_fast_retrieve(lf[116]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[117]);}

/* k2404 in k2397 in setup-download#deconstruct-url in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2406,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2423,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("setup-download.scm:226: irregex-match-substring");
t5=C_fast_retrieve(lf[83]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(3));}
else{
t5=t4;
f_2423(2,t5,C_SCHEME_FALSE);}}

/* k2421 in k2404 in k2397 in setup-download#deconstruct-url in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2423,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2426,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:227: irregex-match-substring");
t3=C_fast_retrieve(lf[83]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],C_fix(4));}
else{
t2=((C_word*)t0)[2];
f_2410(2,t2,C_fix(80));}}

/* k2424 in k2421 in k2404 in k2397 in setup-download#deconstruct-url in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2426,2,t0,t1);}
t2=C_a_i_string_to_number(&a,2,t1,C_fix(10));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_2410(2,t3,t2);}
else{
C_trace("setup-download.scm:229: error");
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[97],t1);}}

/* get-chunks in k2779 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_fcall f_3169(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3169,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3214,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:408: read-line");
t4=C_fast_retrieve(lf[113]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k3159 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:400: make-property-condition");
t2=C_fast_retrieve(lf[116]);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],lf[118],lf[119],t1,lf[120],((C_word*)t0)[3]);}

/* k1753 in k1747 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1755,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:99: directory");
t3=C_fast_retrieve(lf[49]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[2];
f_1528(2,t2,C_SCHEME_FALSE);}}

/* k1747 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:98: directory?");
t3=C_fast_retrieve(lf[23]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[2];
f_1528(2,t2,C_SCHEME_FALSE);}}

/* k3038 in k3022 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:375: read");
t3=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}

/* k3041 in k3038 in k3022 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in ... */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("read-string/port");
t3=C_fast_retrieve(lf[128]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[7]);}

/* k3044 in k3041 in k3038 in k3022 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in ... */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3060,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:377: make-pathname");
t5=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k1731 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1583(t2,C_i_not(t1));}

/* k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1737,2,t0,t1);}
t2=C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_1583(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1733,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:109: directory?");
t5=C_fast_retrieve(lf[23]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[7]);}}

/* k2801 in k2795 in loop in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2803,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2815,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:291: irregex-match");
t3=C_fast_retrieve(lf[98]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[176],((C_word*)t0)[5]);}}

/* k3028 in k3025 in k3022 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in ... */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:372: get-files");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2971(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k3035 in k3025 in k3022 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in ... */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:371: create-directory");
t2=C_fast_retrieve(lf[42]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3047 in k3044 in k3041 in k3038 in k3022 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
C_trace("setup-download.scm:378: get-files");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2971(t3,((C_word*)t0)[5],t2);}

/* k1724 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:125: filter");
t2=C_fast_retrieve(lf[48]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k3025 in k3022 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3037,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:371: make-pathname");
t4=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k3022 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3024,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:370: d");
f_1316(t2,lf[124],C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:374: d");
f_1316(t2,lf[129],C_a_i_list(&a,1,((C_word*)t0)[6]));}}

/* a2823 in k2817 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
C_trace("setup-download.scm:312: tcp-connect");
t2=C_fast_retrieve(lf[169]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2817 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2819,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[9],a[10]=((C_word)li45),tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:312: ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[10],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:320: response-match-code?");
f_2698(t2,((C_word*)t0)[12],C_fix(200));}}

/* k2813 in k2801 in k2795 in loop in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in ... */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:326: d");
f_1316(t3,lf[175],C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3687,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:326: d");
f_1316(t2,lf[175],C_a_i_list(&a,1,((C_word*)t0)[5]));}}

/* k1602 in k1599 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:119: system");
t3=C_fast_retrieve(lf[30]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k1599 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:118: d");
f_1316(t3,lf[31],C_a_i_list(&a,1,t2));}

/* k3004 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:365: close-output-port");
t3=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2844 in k2817 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_2769(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=C_a_i_list(&a,1,((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2623,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2627,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:254: make-property-condition");
t6=C_fast_retrieve(lf[116]);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,t5,lf[118],lf[119],lf[182],lf[120],t3);}}

/* k2838 in a2829 in k2817 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:314: display");
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)((C_word*)t0)[3])[1]);}

/* k1654 in k1651 in k1648 in k1642 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in ... */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:117: ##sys#print");
t3=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k1657 in k1654 in k1651 in k1648 in k1642 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in ... */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:117: get-output-string");
t2=C_fast_retrieve(lf[33]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2139 in k2065 in k2062 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:172: make-svn-ls-cmd");
f_1906(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,C_SCHEME_END_OF_LIST);}

/* k2143 in k2065 in k2062 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:172: make-pathname");
t2=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k3007 in k3004 in k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k1651 in k1648 in k1642 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:117: ##sys#print");
t3=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k1648 in k1642 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:117: ##sys#print");
t3=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k1760 in k1753 in k1747 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:99: existing-version");
f_1347(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k3198 in k3195 in k3212 in get-chunks in k2779 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_3200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:417: read-line");
t3=C_fast_retrieve(lf[113]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k3201 in k3198 in k3195 in k3212 in get-chunks in k2779 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in ... */
static void C_ccall f_3203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3203,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
C_trace("setup-download.scm:418: get-chunks");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3169(t3,((C_word*)t0)[5],t2);}

/* a2829 in k2817 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2830,4,t0,t1,t2,t3);}
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2840,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:315: make-HTTP-GET/1.1");
f_2633(t6,((C_word*)t0)[4],C_retrieve2(lf[1],"setup-download#\052chicken-install-user-agent\052"),((C_word*)t0)[5],C_a_i_list(&a,10,lf[167],((C_word*)t0)[6],lf[164],lf[178],lf[141],((C_word*)t0)[7],lf[179],((C_word*)t0)[8],lf[142],((C_word*)t0)[9]));}

/* k1664 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:114: qs");
t2=C_fast_retrieve(lf[40]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2131 in map-loop479 in k2094 in k2071 in k2068 in k2065 in k2062 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2133,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2104(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2104(t6,((C_word*)t0)[5],t5);}}

/* k3232 in setup-download#check-egg-name in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_not(t1));}

/* k2864 in k2858 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:296: ##sys#print");
t3=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k2867 in k2864 in k2858 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:296: ##sys#write-char-0");
((C_proc4)C_fast_retrieve_symbol_proc(lf[35]))(4,*((C_word*)lf[35]+1),t2,C_make_character(58),((C_word*)t0)[4]);}

/* k2858 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[32]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:296: ##sys#print");
t6=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[190],C_SCHEME_FALSE,t3);}

/* k1633 in k1630 in k1627 in k1621 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in ... */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:116: ##sys#print");
t3=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k1636 in k1633 in k1630 in k1627 in k1621 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in ... */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:116: get-output-string");
t2=C_fast_retrieve(lf[33]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1630 in k1627 in k1621 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:116: ##sys#write-char-0");
((C_proc4)C_fast_retrieve_symbol_proc(lf[35]))(4,*((C_word*)lf[35]+1),t2,C_make_character(32),((C_word*)t0)[5]);}

/* k2851 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:300: display");
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)((C_word*)t0)[3])[1]);}

/* k2855 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2857,2,t0,t1);}
C_trace("setup-download.scm:294: d");
f_1316(((C_word*)t0)[2],lf[188],C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3218,2,t0,t1);}
t2=C_mutate2(&lf[192] /* (set! setup-download#slashes ...) */,t1);
t3=C_mutate2(&lf[193] /* (set! setup-download#check-egg-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3240,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[199]+1 /* (set! setup-download#retrieve-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3252,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[214]+1 /* (set! setup-download#list-extensions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3357,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[232]+1 /* (set! setup-download#list-extension-versions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3430,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* k1642 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1644,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[32]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:117: ##sys#print");
t6=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[39],C_SCHEME_FALSE,t3);}

/* k3212 in get-chunks in k2779 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2723 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in ... */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=C_a_i_string_to_number(&a,2,t1,C_fix(16));
if(C_truep(t2)){
if(C_truep(C_i_zerop(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:412: d");
f_1316(t3,lf[171],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3197,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("read-string/port");
t4=C_fast_retrieve(lf[128]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[5]);}}
else{
C_trace("setup-download.scm:410: error");
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],lf[173]);}}

/* for-each-loop346 in k1677 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_fcall f_1695(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1695,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1705,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1684,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:128: d");
f_1316(t7,lf[45],C_a_i_list(&a,1,t6));}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2100 in k2094 in k2071 in k2068 in k2065 in k2062 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:176: string-concatenate");
t2=C_fast_retrieve(lf[215]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* map-loop479 in k2094 in k2071 in k2068 in k2065 in k2062 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_fcall f_2104(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2104,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2092,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:177: string-chomp");
t7=C_fast_retrieve(lf[220]);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,lf[239]);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1677 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1679,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[43]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1695,a[2]=t4,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1695(t6,((C_word*)t0)[2],t1);}

/* k1671 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:131: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k1668 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:113: qs");
t2=C_fast_retrieve(lf[40]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* a3480 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3481,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k1682 in for-each-loop346 in k1677 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:129: delete-file*");
t2=C_fast_retrieve(lf[44]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=lf[0] /* setup-download#*quiet* */ =C_SCHEME_FALSE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1311,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3488,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:54: chicken-version");
t5=C_fast_retrieve(lf[251]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:51: tcp-write-timeout");
t3=C_fast_retrieve(lf[252]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(30000));}

/* k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:50: tcp-read-timeout");
t3=C_fast_retrieve(lf[253]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(30000));}

/* k3486 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:54: conc");
t2=C_fast_retrieve(lf[66]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[250],t1);}

/* k2982 in k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_fcall f_2984(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2984,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_u_i_cdr(t3);
t5=((C_word*)t0)[3];
t6=t4;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3149,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3153,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:402: string-append");
t10=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,lf[121],t2);}
else{
t2=C_eofp(((C_word*)t0)[2]);
t3=(C_truep(t2)?t2:C_i_not(((C_word*)t0)[2]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:364: close-input-port");
t5=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3024,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:369: string-suffix?");
t5=C_fast_retrieve(lf[46]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[130],((C_word*)t0)[2]);}
else{
C_trace("setup-download.scm:368: error");
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],lf[131],((C_word*)t0)[2]);}}}}

/* setup-download#d in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_fcall f_1316(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1316,NULL,3,t1,t2,t3);}
t4=(C_truep(C_retrieve2(lf[0],"setup-download#\052quiet\052"))?*((C_word*)lf[7]+1):*((C_word*)lf[8]+1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1323,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t6,*((C_word*)lf[10]+1),t5,t2,t3);}

/* k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=C_mutate2(&lf[1] /* (set! setup-download#*chicken-install-user-agent* ...) */,t1);
t3=lf[2] /* setup-download#*trunk* */ =C_SCHEME_FALSE;;
t4=C_mutate2(&lf[3] /* (set! setup-download#*mode* ...) */,lf[4]);
t5=C_mutate2(&lf[5] /* (set! setup-download#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t6=C_mutate2(&lf[6] /* (set! setup-download#d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1316,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:64: make-parameter");
t8=C_fast_retrieve(lf[249]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,C_SCHEME_FALSE);}

/* a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[208]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1438,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1498,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:88: string-append");
t9=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t5,lf[236]);}
else{
t4=C_eqp(t2,lf[209]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[4];
t8=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_nullp(t12);
t14=(C_truep(t13)?C_SCHEME_FALSE:C_i_car(t12));
t15=t14;
t16=C_i_nullp(t12);
t17=(C_truep(t16)?C_SCHEME_END_OF_LIST:C_i_cdr(t12));
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2064,a[2]=t5,a[3]=t7,a[4]=t6,a[5]=t15,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t10)){
C_trace("setup-download.scm:170: string-append");
t19=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t18,lf[244],t10,lf[245]);}
else{
t19=t18;
f_2064(2,t19,lf[246]);}}
else{
C_trace("setup-download.scm:470: error");
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[247],((C_word*)t0)[2]);}}}

/* a3305 in k3290 in k3284 in setup-download#retrieve-extension in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3306,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[208]);
if(C_truep(t3)){
C_trace("setup-download.scm:440: locate-egg/local");
((C_proc7)C_fast_retrieve_symbol_proc(lf[19]))(7,*((C_word*)lf[19]+1),t1,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
t4=C_eqp(t2,lf[209]);
if(C_truep(t4)){
C_trace("setup-download.scm:442: locate-egg/svn");
((C_proc8)C_fast_retrieve_symbol_proc(lf[68]))(8,*((C_word*)lf[68]+1),t1,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[9]);}
else{
t5=C_eqp(t2,lf[210]);
if(C_truep(t5)){
C_trace("setup-download.scm:444: locate-egg/http");
((C_proc10)C_fast_retrieve_symbol_proc(lf[100]))(10,*((C_word*)lf[100]+1),t1,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[10],((C_word*)t0)[11],((C_word*)t0)[12],((C_word*)t0)[13]);}
else{
C_trace("setup-download.scm:446: error");
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[211],((C_word*)t0)[2]);}}}}

/* k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3448,a[2]=t5,a[3]=t3,a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li67),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3481,a[2]=t3,a[3]=t5,a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:463: ##sys#dynamic-wind");
t9=*((C_word*)lf[212]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[8],t6,t7,t8);}

/* k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:360: read");
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_fcall f_2971(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2971,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2975,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:359: skip");
t4=((C_word*)((C_word*)t0)[7])[1];
f_2889(t4,t3);}

/* k2976 in k2973 in get-files in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2984,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_u_i_car(t2);
t5=t3;
f_2984(t5,C_eqp(lf[15],t4));}
else{
t4=t3;
f_2984(t4,C_SCHEME_FALSE);}}

/* a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1836,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:142: string->symbol");
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:140: call/cc");
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[5],t2);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3447 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3448,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2237 in a2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_member(lf[71],((C_word*)t0)[2]))){
C_trace("setup-download.scm:199: values");
C_values(4,0,((C_word*)t0)[3],lf[72],lf[73]);}
else{
C_trace("setup-download.scm:200: values");
C_values(4,0,((C_word*)t0)[3],lf[74],lf[75]);}}

/* a3424 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3425,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2234 in a2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:195: values");
C_values(4,0,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k1627 in k1621 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in ... */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:116: ##sys#print");
t3=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* a1866 in a1860 in k1842 in a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1867,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:144: k379");
t4=((C_word*)t0)[4];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1860 in k1842 in a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1861,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:144: with-exception-handler");
t5=C_fast_retrieve(lf[56]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k1618 in k1602 in k1599 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in ... */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
C_trace("setup-download.scm:120: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
C_trace("setup-download.scm:121: values");
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[29]);}}

/* k1621 in k1596 in k1593 in k1590 in k1581 in k1735 in a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1623,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[32]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:116: ##sys#print");
t6=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[36],C_SCHEME_FALSE,t3);}

/* k2261 in k2258 in k2255 in a2252 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:215: system");
t3=C_fast_retrieve(lf[30]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k2258 in k2255 in a2252 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2260,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:214: d");
f_1316(t3,lf[77],C_a_i_list(&a,1,t2));}

/* k1854 in k1842 in a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:144: g383");
t3=t1;
((C_proc2)C_fast_retrieve_proc(t3))(2,t3,t2);}

/* k1857 in k1854 in k1842 in a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}

/* k1361 in setup-download#existing-version in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_pairp(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_u_i_car(t1):C_SCHEME_FALSE));}

/* a1872 in a1866 in a1860 in k1842 in a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:146: warning");
t3=C_fast_retrieve(lf[25]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[53],((C_word*)t0)[3]);}

/* k2255 in a2252 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2257,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2260,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2283,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2300,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=C_eqp(C_retrieve2(lf[3],"setup-download#\052mode\052"),lf[81]);
if(C_truep(t6)){
t7=((C_word*)t0)[6];
C_trace("setup-download.scm:220: conc");
t8=C_fast_retrieve(lf[66]);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,((C_word*)t0)[8],C_make_character(47),t7,lf[82]);}
else{
C_trace("setup-download.scm:204: conc");
t7=C_fast_retrieve(lf[66]);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t4,((C_word*)t0)[7],C_make_character(47),((C_word*)t0)[6],C_make_character(47),((C_word*)t0)[8]);}}

/* a2252 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2253,4,t0,t1,t2,t3);}
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2257,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2310,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[6])){
C_trace("setup-download.scm:201: make-pathname");
t8=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
C_trace("setup-download.scm:201: get-temporary-directory");
f_1332(t7);}}

/* k2891 in skip in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=t1;
t3=C_eofp(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_2902(2,t5,t3);}
else{
C_trace("setup-download.scm:341: irregex-match");
t5=C_fast_retrieve(lf[98]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[112],t2);}}

/* k1454 in k1442 in k1436 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1461,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li65),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1461(t6,t2,t1);}

/* k1457 in k1454 in k1442 in k1436 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:90: string-concatenate");
t2=C_fast_retrieve(lf[215]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* a1881 in a1860 in k1842 in a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in ... */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[3],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:144: ##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1278,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1875 in a1872 in a1866 in a1860 in k1842 in a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:149: return");
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],C_SCHEME_FALSE);}

/* k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_2d1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1275,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1426 in map-loop181 in k1392 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1428,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1399(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1399(t6,((C_word*)t0)[5],t5);}}

/* k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1290,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_2d13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1287,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2321 in a2318 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm:191: irregex-match-substring");
t2=C_fast_retrieve(lf[83]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(1));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1887 in a1881 in a1860 in k1842 in a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
C_trace("setup-download.scm:150: with-input-from-file");
t2=C_fast_retrieve(lf[54]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],*((C_word*)lf[55]+1));}

/* k2277 in k2261 in k2258 in k2255 in a2252 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in ... */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
C_trace("setup-download.scm:216: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
C_trace("setup-download.scm:217: values");
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[76]);}}

/* k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_2dstructures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1825,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:139: file-exists?");
t4=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1821,4,t0,t1,t2,t3);}
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1825,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:138: make-pathname");
t6=C_fast_retrieve(lf[20]);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,t2,((C_word*)t0)[2],lf[60]);}

/* k1395 in k1392 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:85: string-concatenate");
t2=C_fast_retrieve(lf[215]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* map-loop181 in k1392 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_fcall f_1399(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1399,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1428,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-download.scm:85: g204");
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,lf[216]);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_1500r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1500r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1500r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(7);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_nullp(t14);
t16=(C_truep(t15)?C_SCHEME_FALSE:C_i_car(t14));
t17=t16;
t18=C_i_nullp(t14);
t19=(C_truep(t18)?C_SCHEME_END_OF_LIST:C_i_cdr(t14));
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1522,a[2]=t2,a[3]=t7,a[4]=t17,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:95: make-pathname");
t21=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t20,t3,t2);}

/* k1392 in a3385 in setup-download#list-extensions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1399,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1399(t6,t2,t1);}

/* k2873 in k2870 in k2867 in k2864 in k2858 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:296: ##sys#print");
t3=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[189],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k2870 in k2867 in k2864 in k2858 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:296: ##sys#print");
t3=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k1436 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1438,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1444,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:89: directory-exists?");
t4=C_fast_retrieve(lf[235]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1488 in map-loop223 in k1454 in k1442 in k1436 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1490,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1461(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1461(t6,((C_word*)t0)[5],t5);}}

/* a1814 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
C_trace("setup-download.scm:137: locate-egg/local");
((C_proc4)C_fast_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1557 in k1551 in k1548 in a1535 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm:107: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],lf[21]);}
else{
C_trace("setup-download.scm:108: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],lf[22]);}}

/* k1551 in k1548 in a1535 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1568,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:106: file-exists?");
t4=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k1548 in a1535 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1550,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
if(C_truep(((C_word*)t0)[5])){
C_trace("setup-download.scm:82: warning");
t5=C_fast_retrieve(lf[25]);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[26],t4,((C_word*)t0)[5]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t3;
f_1553(2,t6,t5);}}

/* k2876 in k2873 in k2870 in k2867 in k2864 in k2858 in setup-download#http-connect in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:296: get-output-string");
t2=C_fast_retrieve(lf[33]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1264 in k1261 in k1258 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1269,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1272,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_irregex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1321 in setup-download#d in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:62: flush-output");
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* map-loop223 in k1454 in k1442 in k1436 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_fcall f_1461(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1461,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1490,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-download.scm:91: g246");
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,lf[233]);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* setup-download#response-match-code? in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_fcall f_2698(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2698,NULL,3,t1,t2,t3);}
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2709,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:288: number->string");
C_number_to_string(3,0,t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1525,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1528,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_retrieve2(lf[2],"setup-download#\052trunk\052");
if(C_truep(C_retrieve2(lf[2],"setup-download#\052trunk\052"))){
t5=t3;
f_1528(2,t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1749,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:98: file-exists?");
t6=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}

/* k1258 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1263,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1261 in k1258 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1266,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1528,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1531,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
C_trace("setup-download.scm:100: make-pathname");
t4=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t4=t3;
f_1531(2,t4,C_SCHEME_FALSE);}}

/* k1842 in a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1844,2,t0,t1);}
t2=t1;
t3=C_a_i_list2(&a,2,lf[52],((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1856,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:144: call-with-current-continuation");
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k1334 in setup-download#get-temporary-directory in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:68: create-temporary-directory");
t3=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1496 in a3452 in k3441 in setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in ... */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:88: make-pathname");
t2=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* skip in k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in ... */
static void C_fcall f_2889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2889,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2893,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:339: read-line");
t3=C_fast_retrieve(lf[113]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2291 in k2281 in k2255 in a2252 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in setup-download#locate-egg/svn in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
C_trace("setup-download.scm:220: conc");
t3=C_fast_retrieve(lf[66]);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],((C_word*)t0)[4],C_make_character(47),t2,lf[82]);}

/* k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1522,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1525,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:96: make-pathname");
t4=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[50]);}

/* k2885 in a3094 in k2502 in k2499 in k2496 in a2493 in k2481 in setup-download#locate-egg/http in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in ... */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2889,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word)li29),tmp=(C_word)a,a+=6,tmp));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2971,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word)li31),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_2971(t10,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* setup-download#get-temporary-directory in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_fcall f_1332(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1332,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:67: temporary-directory");
((C_proc2)C_fast_retrieve_symbol_proc(lf[11]))(2,*((C_word*)lf[11]+1),t2);}

/* k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1330,2,t0,t1);}
t2=C_mutate2((C_word*)lf[11]+1 /* (set! setup-download#temporary-directory ...) */,t1);
t3=C_mutate2(&lf[12] /* (set! setup-download#get-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1332,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2(&lf[14] /* (set! setup-download#existing-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1347,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[19]+1 /* (set! setup-download#locate-egg/local ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1500,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[51]+1 /* (set! setup-download#gather-egg-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1800,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2(&lf[62] /* (set! setup-download#make-svn-ls-cmd ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1906,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[68]+1 /* (set! setup-download#locate-egg/svn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2177,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2(&lf[95] /* (set! setup-download#deconstruct-url ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2395,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[100]+1 /* (set! setup-download#locate-egg/http ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2443,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2(&lf[140] /* (set! setup-download#make-HTTP-GET/1.1 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2633,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2(&lf[168] /* (set! setup-download#response-match-code? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2698,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2(&lf[102] /* (set! setup-download#http-connect ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2721,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3218,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:420: char-set");
t15=C_fast_retrieve(lf[248]);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_make_character(92),C_make_character(47));}

/* setup-download#list-extension-versions in k3216 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_3430r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3430r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3430r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(9);
t6=C_i_get_keyword(lf[201],t5,C_SCHEME_FALSE);
t7=t6;
t8=C_i_get_keyword(lf[203],t5,C_SCHEME_FALSE);
t9=t8;
t10=C_i_get_keyword(lf[204],t5,C_SCHEME_FALSE);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3443,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t4,a[6]=t9,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:462: check-egg-name");
f_3240(t12,t2);}

/* a1572 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in ... */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1573,4,t0,t1,t2,t3);}
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1737,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:109: file-exists?");
t7=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[4]);}

/* k1343 in k1340 in k1334 in setup-download#get-temporary-directory in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* setup-download#existing-version in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_fcall f_1347(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1347,NULL,4,t1,t2,t3,t4);}
if(C_truep(t3)){
if(C_truep(C_i_member(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
C_trace("setup-download.scm:76: error");
t5=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[16],t2,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1363,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:77: sort");
t6=C_fast_retrieve(lf[17]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_fast_retrieve(lf[18]));}}

/* a1893 in a1881 in a1860 in k1842 in a1835 in k1829 in k1823 in a1820 in a1808 in k1802 in setup-download#gather-egg-information in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in ... */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1894r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1894r(t0,t1,t2);}}

static void C_ccall f_1894r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:144: k379");
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* k1340 in k1334 in setup-download#get-temporary-directory in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1342,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:69: temporary-directory");
((C_proc3)C_fast_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* a2676 in k2638 in k2635 in setup-download#make-HTTP-GET/1.1 in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1264 in k1261 in k1258 in ... */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2677,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[163]);}

/* k1545 in a1535 in k1529 in k1526 in k1523 in k1520 in setup-download#locate-egg/local in k1328 in k1309 in k1304 in k1301 in k1298 in k1294 in k1291 in k1288 in k1285 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in ... */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:103: values");
C_values(4,0,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[285] = {
{"f_1296:setup_2ddownload_2escm",(void*)f_1296},
{"f_2674:setup_2ddownload_2escm",(void*)f_2674},
{"f_1718:setup_2ddownload_2escm",(void*)f_1718},
{"f_1598:setup_2ddownload_2escm",(void*)f_1598},
{"f_1595:setup_2ddownload_2escm",(void*)f_1595},
{"f_1293:setup_2ddownload_2escm",(void*)f_1293},
{"f_1290:setup_2ddownload_2escm",(void*)f_1290},
{"f_1592:setup_2ddownload_2escm",(void*)f_1592},
{"f_2934:setup_2ddownload_2escm",(void*)f_2934},
{"f_2937:setup_2ddownload_2escm",(void*)f_2937},
{"f_2283:setup_2ddownload_2escm",(void*)f_2283},
{"f_2287:setup_2ddownload_2escm",(void*)f_2287},
{"f_2683:setup_2ddownload_2escm",(void*)f_2683},
{"f_1705:setup_2ddownload_2escm",(void*)f_1705},
{"f_2680:setup_2ddownload_2escm",(void*)f_2680},
{"f_1568:setup_2ddownload_2escm",(void*)f_1568},
{"f_2177:setup_2ddownload_2escm",(void*)f_2177},
{"f_1809:setup_2ddownload_2escm",(void*)f_1809},
{"f_1804:setup_2ddownload_2escm",(void*)f_1804},
{"f_1800:setup_2ddownload_2escm",(void*)f_1800},
{"f_3095:setup_2ddownload_2escm",(void*)f_3095},
{"f_2916:setup_2ddownload_2escm",(void*)f_2916},
{"f_2912:setup_2ddownload_2escm",(void*)f_2912},
{"f_1975:setup_2ddownload_2escm",(void*)f_1975},
{"f_1971:setup_2ddownload_2escm",(void*)f_1971},
{"f_3089:setup_2ddownload_2escm",(void*)f_3089},
{"f_3060:setup_2ddownload_2escm",(void*)f_3060},
{"f_1583:setup_2ddownload_2escm",(void*)f_1583},
{"f_2908:setup_2ddownload_2escm",(void*)f_2908},
{"f_1983:setup_2ddownload_2escm",(void*)f_1983},
{"f_2902:setup_2ddownload_2escm",(void*)f_2902},
{"f_1981:setup_2ddownload_2escm",(void*)f_1981},
{"f_2092:setup_2ddownload_2escm",(void*)f_2092},
{"f_2627:setup_2ddownload_2escm",(void*)f_2627},
{"f_2623:setup_2ddownload_2escm",(void*)f_2623},
{"f_2067:setup_2ddownload_2escm",(void*)f_2067},
{"f_2725:setup_2ddownload_2escm",(void*)f_2725},
{"f_2721:setup_2ddownload_2escm",(void*)f_2721},
{"f_3062:setup_2ddownload_2escm",(void*)f_3062},
{"f_3133:setup_2ddownload_2escm",(void*)f_3133},
{"f_3136:setup_2ddownload_2escm",(void*)f_3136},
{"f_2096:setup_2ddownload_2escm",(void*)f_2096},
{"f_3139:setup_2ddownload_2escm",(void*)f_3139},
{"f_2713:setup_2ddownload_2escm",(void*)f_2713},
{"f_2073:setup_2ddownload_2escm",(void*)f_2073},
{"f_2643:setup_2ddownload_2escm",(void*)f_2643},
{"f_2070:setup_2ddownload_2escm",(void*)f_2070},
{"f_2646:setup_2ddownload_2escm",(void*)f_2646},
{"f_2640:setup_2ddownload_2escm",(void*)f_2640},
{"f_2633:setup_2ddownload_2escm",(void*)f_2633},
{"f_2637:setup_2ddownload_2escm",(void*)f_2637},
{"f_3113:setup_2ddownload_2escm",(void*)f_3113},
{"f_2631:setup_2ddownload_2escm",(void*)f_2631},
{"f_3119:setup_2ddownload_2escm",(void*)f_3119},
{"f_2709:setup_2ddownload_2escm",(void*)f_2709},
{"f_2443:setup_2ddownload_2escm",(void*)f_2443},
{"f_2483:setup_2ddownload_2escm",(void*)f_2483},
{"f_2662:setup_2ddownload_2escm",(void*)f_2662},
{"f_2666:setup_2ddownload_2escm",(void*)f_2666},
{"f_1444:setup_2ddownload_2escm",(void*)f_1444},
{"f_3149:setup_2ddownload_2escm",(void*)f_3149},
{"f_2763:setup_2ddownload_2escm",(void*)f_2763},
{"f_2769:setup_2ddownload_2escm",(void*)f_2769},
{"f_2766:setup_2ddownload_2escm",(void*)f_2766},
{"f_2760:setup_2ddownload_2escm",(void*)f_2760},
{"f_2494:setup_2ddownload_2escm",(void*)f_2494},
{"f_2064:setup_2ddownload_2escm",(void*)f_2064},
{"f_2488:setup_2ddownload_2escm",(void*)f_2488},
{"f3687:setup_2ddownload_2escm",(void*)f3687},
{"f_2754:setup_2ddownload_2escm",(void*)f_2754},
{"f_2757:setup_2ddownload_2escm",(void*)f_2757},
{"f_2751:setup_2ddownload_2escm",(void*)f_2751},
{"f_2498:setup_2ddownload_2escm",(void*)f_2498},
{"f_1536:setup_2ddownload_2escm",(void*)f_1536},
{"f_3127:setup_2ddownload_2escm",(void*)f_3127},
{"toplevel:setup_2ddownload_2escm",(void*)C_toplevel},
{"f_3129:setup_2ddownload_2escm",(void*)f_3129},
{"f_1531:setup_2ddownload_2escm",(void*)f_1531},
{"f_2744:setup_2ddownload_2escm",(void*)f_2744},
{"f_2748:setup_2ddownload_2escm",(void*)f_2748},
{"f_2414:setup_2ddownload_2escm",(void*)f_2414},
{"f_2410:setup_2ddownload_2escm",(void*)f_2410},
{"f_2730:setup_2ddownload_2escm",(void*)f_2730},
{"f_3107:setup_2ddownload_2escm",(void*)f_3107},
{"f_2395:setup_2ddownload_2escm",(void*)f_2395},
{"f_2399:setup_2ddownload_2escm",(void*)f_2399},
{"f_2957:setup_2ddownload_2escm",(void*)f_2957},
{"f_2527:setup_2ddownload_2escm",(void*)f_2527},
{"f_2520:setup_2ddownload_2escm",(void*)f_2520},
{"f3683:setup_2ddownload_2escm",(void*)f3683},
{"f_3247:setup_2ddownload_2escm",(void*)f_3247},
{"f_2504:setup_2ddownload_2escm",(void*)f_2504},
{"f_2507:setup_2ddownload_2escm",(void*)f_2507},
{"f_2501:setup_2ddownload_2escm",(void*)f_2501},
{"f_3240:setup_2ddownload_2escm",(void*)f_3240},
{"f_2205:setup_2ddownload_2escm",(void*)f_2205},
{"f_2208:setup_2ddownload_2escm",(void*)f_2208},
{"f_2225:setup_2ddownload_2escm",(void*)f_2225},
{"f_2220:setup_2ddownload_2escm",(void*)f_2220},
{"f_3252:setup_2ddownload_2escm",(void*)f_3252},
{"f_2300:setup_2ddownload_2escm",(void*)f_2300},
{"f_3286:setup_2ddownload_2escm",(void*)f_3286},
{"f_2214:setup_2ddownload_2escm",(void*)f_2214},
{"f_2217:setup_2ddownload_2escm",(void*)f_2217},
{"f_2211:setup_2ddownload_2escm",(void*)f_2211},
{"f_2333:setup_2ddownload_2escm",(void*)f_2333},
{"f_2531:setup_2ddownload_2escm",(void*)f_2531},
{"f_2012:setup_2ddownload_2escm",(void*)f_2012},
{"f_2317:setup_2ddownload_2escm",(void*)f_2317},
{"f_2319:setup_2ddownload_2escm",(void*)f_2319},
{"f_2310:setup_2ddownload_2escm",(void*)f_2310},
{"f_3297:setup_2ddownload_2escm",(void*)f_3297},
{"f_1949:setup_2ddownload_2escm",(void*)f_1949},
{"f_3292:setup_2ddownload_2escm",(void*)f_3292},
{"f_1921:setup_2ddownload_2escm",(void*)f_1921},
{"f_3354:setup_2ddownload_2escm",(void*)f_3354},
{"f_3357:setup_2ddownload_2escm",(void*)f_3357},
{"f_1955:setup_2ddownload_2escm",(void*)f_1955},
{"f_1952:setup_2ddownload_2escm",(void*)f_1952},
{"f_1958:setup_2ddownload_2escm",(void*)f_1958},
{"f_3345:setup_2ddownload_2escm",(void*)f_3345},
{"f_1906:setup_2ddownload_2escm",(void*)f_1906},
{"f_1900:setup_2ddownload_2escm",(void*)f_1900},
{"f_3386:setup_2ddownload_2escm",(void*)f_3386},
{"f_3197:setup_2ddownload_2escm",(void*)f_3197},
{"f_3191:setup_2ddownload_2escm",(void*)f_3191},
{"f_3381:setup_2ddownload_2escm",(void*)f_3381},
{"f_2793:setup_2ddownload_2escm",(void*)f_2793},
{"f_2791:setup_2ddownload_2escm",(void*)f_2791},
{"f_2797:setup_2ddownload_2escm",(void*)f_2797},
{"f_2772:setup_2ddownload_2escm",(void*)f_2772},
{"f_2784:setup_2ddownload_2escm",(void*)f_2784},
{"f_2781:setup_2ddownload_2escm",(void*)f_2781},
{"f_2787:setup_2ddownload_2escm",(void*)f_2787},
{"f_3157:setup_2ddownload_2escm",(void*)f_3157},
{"f_3153:setup_2ddownload_2escm",(void*)f_3153},
{"f_2406:setup_2ddownload_2escm",(void*)f_2406},
{"f_2423:setup_2ddownload_2escm",(void*)f_2423},
{"f_2426:setup_2ddownload_2escm",(void*)f_2426},
{"f_3169:setup_2ddownload_2escm",(void*)f_3169},
{"f_3161:setup_2ddownload_2escm",(void*)f_3161},
{"f_1755:setup_2ddownload_2escm",(void*)f_1755},
{"f_1749:setup_2ddownload_2escm",(void*)f_1749},
{"f_3040:setup_2ddownload_2escm",(void*)f_3040},
{"f_3043:setup_2ddownload_2escm",(void*)f_3043},
{"f_3046:setup_2ddownload_2escm",(void*)f_3046},
{"f_1733:setup_2ddownload_2escm",(void*)f_1733},
{"f_1737:setup_2ddownload_2escm",(void*)f_1737},
{"f_2803:setup_2ddownload_2escm",(void*)f_2803},
{"f_3030:setup_2ddownload_2escm",(void*)f_3030},
{"f_3037:setup_2ddownload_2escm",(void*)f_3037},
{"f_3049:setup_2ddownload_2escm",(void*)f_3049},
{"f_1726:setup_2ddownload_2escm",(void*)f_1726},
{"f_3027:setup_2ddownload_2escm",(void*)f_3027},
{"f_3024:setup_2ddownload_2escm",(void*)f_3024},
{"f_2824:setup_2ddownload_2escm",(void*)f_2824},
{"f_2819:setup_2ddownload_2escm",(void*)f_2819},
{"f_2815:setup_2ddownload_2escm",(void*)f_2815},
{"f_1604:setup_2ddownload_2escm",(void*)f_1604},
{"f_1601:setup_2ddownload_2escm",(void*)f_1601},
{"f_3006:setup_2ddownload_2escm",(void*)f_3006},
{"f_2846:setup_2ddownload_2escm",(void*)f_2846},
{"f_2840:setup_2ddownload_2escm",(void*)f_2840},
{"f_1656:setup_2ddownload_2escm",(void*)f_1656},
{"f_1659:setup_2ddownload_2escm",(void*)f_1659},
{"f_2141:setup_2ddownload_2escm",(void*)f_2141},
{"f_2145:setup_2ddownload_2escm",(void*)f_2145},
{"f_3009:setup_2ddownload_2escm",(void*)f_3009},
{"f_1653:setup_2ddownload_2escm",(void*)f_1653},
{"f_1650:setup_2ddownload_2escm",(void*)f_1650},
{"f_1762:setup_2ddownload_2escm",(void*)f_1762},
{"f_3200:setup_2ddownload_2escm",(void*)f_3200},
{"f_3203:setup_2ddownload_2escm",(void*)f_3203},
{"f_2830:setup_2ddownload_2escm",(void*)f_2830},
{"f_1666:setup_2ddownload_2escm",(void*)f_1666},
{"f_2133:setup_2ddownload_2escm",(void*)f_2133},
{"f_3234:setup_2ddownload_2escm",(void*)f_3234},
{"f_2866:setup_2ddownload_2escm",(void*)f_2866},
{"f_2869:setup_2ddownload_2escm",(void*)f_2869},
{"f_2860:setup_2ddownload_2escm",(void*)f_2860},
{"f_1635:setup_2ddownload_2escm",(void*)f_1635},
{"f_1638:setup_2ddownload_2escm",(void*)f_1638},
{"f_1632:setup_2ddownload_2escm",(void*)f_1632},
{"f_2853:setup_2ddownload_2escm",(void*)f_2853},
{"f_2857:setup_2ddownload_2escm",(void*)f_2857},
{"f_3218:setup_2ddownload_2escm",(void*)f_3218},
{"f_1644:setup_2ddownload_2escm",(void*)f_1644},
{"f_3214:setup_2ddownload_2escm",(void*)f_3214},
{"f_1695:setup_2ddownload_2escm",(void*)f_1695},
{"f_2102:setup_2ddownload_2escm",(void*)f_2102},
{"f_2104:setup_2ddownload_2escm",(void*)f_2104},
{"f_1679:setup_2ddownload_2escm",(void*)f_1679},
{"f_1673:setup_2ddownload_2escm",(void*)f_1673},
{"f_1670:setup_2ddownload_2escm",(void*)f_1670},
{"f_3481:setup_2ddownload_2escm",(void*)f_3481},
{"f_1684:setup_2ddownload_2escm",(void*)f_1684},
{"f_1306:setup_2ddownload_2escm",(void*)f_1306},
{"f_1303:setup_2ddownload_2escm",(void*)f_1303},
{"f_1300:setup_2ddownload_2escm",(void*)f_1300},
{"f_3488:setup_2ddownload_2escm",(void*)f_3488},
{"f_2984:setup_2ddownload_2escm",(void*)f_2984},
{"f_1316:setup_2ddownload_2escm",(void*)f_1316},
{"f_1311:setup_2ddownload_2escm",(void*)f_1311},
{"f_3453:setup_2ddownload_2escm",(void*)f_3453},
{"f_3306:setup_2ddownload_2escm",(void*)f_3306},
{"f_3443:setup_2ddownload_2escm",(void*)f_3443},
{"f_2975:setup_2ddownload_2escm",(void*)f_2975},
{"f_2971:setup_2ddownload_2escm",(void*)f_2971},
{"f_2978:setup_2ddownload_2escm",(void*)f_2978},
{"f_1836:setup_2ddownload_2escm",(void*)f_1836},
{"f_1831:setup_2ddownload_2escm",(void*)f_1831},
{"f_3448:setup_2ddownload_2escm",(void*)f_3448},
{"f_2239:setup_2ddownload_2escm",(void*)f_2239},
{"f_3425:setup_2ddownload_2escm",(void*)f_3425},
{"f_2236:setup_2ddownload_2escm",(void*)f_2236},
{"f_1629:setup_2ddownload_2escm",(void*)f_1629},
{"f_1867:setup_2ddownload_2escm",(void*)f_1867},
{"f_1861:setup_2ddownload_2escm",(void*)f_1861},
{"f_1620:setup_2ddownload_2escm",(void*)f_1620},
{"f_1623:setup_2ddownload_2escm",(void*)f_1623},
{"f_2263:setup_2ddownload_2escm",(void*)f_2263},
{"f_2260:setup_2ddownload_2escm",(void*)f_2260},
{"f_1856:setup_2ddownload_2escm",(void*)f_1856},
{"f_1859:setup_2ddownload_2escm",(void*)f_1859},
{"f_1363:setup_2ddownload_2escm",(void*)f_1363},
{"f_1873:setup_2ddownload_2escm",(void*)f_1873},
{"f_2257:setup_2ddownload_2escm",(void*)f_2257},
{"f_2253:setup_2ddownload_2escm",(void*)f_2253},
{"f_2893:setup_2ddownload_2escm",(void*)f_2893},
{"f_1456:setup_2ddownload_2escm",(void*)f_1456},
{"f_1459:setup_2ddownload_2escm",(void*)f_1459},
{"f_1882:setup_2ddownload_2escm",(void*)f_1882},
{"f_1275:setup_2ddownload_2escm",(void*)f_1275},
{"f_1877:setup_2ddownload_2escm",(void*)f_1877},
{"f_1278:setup_2ddownload_2escm",(void*)f_1278},
{"f_1272:setup_2ddownload_2escm",(void*)f_1272},
{"f_1428:setup_2ddownload_2escm",(void*)f_1428},
{"f_1287:setup_2ddownload_2escm",(void*)f_1287},
{"f_1284:setup_2ddownload_2escm",(void*)f_1284},
{"f_2323:setup_2ddownload_2escm",(void*)f_2323},
{"f_1888:setup_2ddownload_2escm",(void*)f_1888},
{"f_2279:setup_2ddownload_2escm",(void*)f_2279},
{"f_1281:setup_2ddownload_2escm",(void*)f_1281},
{"f_1825:setup_2ddownload_2escm",(void*)f_1825},
{"f_1821:setup_2ddownload_2escm",(void*)f_1821},
{"f_1397:setup_2ddownload_2escm",(void*)f_1397},
{"f_1399:setup_2ddownload_2escm",(void*)f_1399},
{"f_1500:setup_2ddownload_2escm",(void*)f_1500},
{"f_1394:setup_2ddownload_2escm",(void*)f_1394},
{"f_2875:setup_2ddownload_2escm",(void*)f_2875},
{"f_2872:setup_2ddownload_2escm",(void*)f_2872},
{"f_1438:setup_2ddownload_2escm",(void*)f_1438},
{"f_1490:setup_2ddownload_2escm",(void*)f_1490},
{"f_1815:setup_2ddownload_2escm",(void*)f_1815},
{"f_1559:setup_2ddownload_2escm",(void*)f_1559},
{"f_1553:setup_2ddownload_2escm",(void*)f_1553},
{"f_1550:setup_2ddownload_2escm",(void*)f_1550},
{"f_2878:setup_2ddownload_2escm",(void*)f_2878},
{"f_1266:setup_2ddownload_2escm",(void*)f_1266},
{"f_1269:setup_2ddownload_2escm",(void*)f_1269},
{"f_1323:setup_2ddownload_2escm",(void*)f_1323},
{"f_1461:setup_2ddownload_2escm",(void*)f_1461},
{"f_2698:setup_2ddownload_2escm",(void*)f_2698},
{"f_1525:setup_2ddownload_2escm",(void*)f_1525},
{"f_1260:setup_2ddownload_2escm",(void*)f_1260},
{"f_1263:setup_2ddownload_2escm",(void*)f_1263},
{"f_1528:setup_2ddownload_2escm",(void*)f_1528},
{"f_1844:setup_2ddownload_2escm",(void*)f_1844},
{"f_1336:setup_2ddownload_2escm",(void*)f_1336},
{"f_1498:setup_2ddownload_2escm",(void*)f_1498},
{"f_2889:setup_2ddownload_2escm",(void*)f_2889},
{"f_2293:setup_2ddownload_2escm",(void*)f_2293},
{"f_1522:setup_2ddownload_2escm",(void*)f_1522},
{"f_2887:setup_2ddownload_2escm",(void*)f_2887},
{"f_1332:setup_2ddownload_2escm",(void*)f_1332},
{"f_1330:setup_2ddownload_2escm",(void*)f_1330},
{"f_3430:setup_2ddownload_2escm",(void*)f_3430},
{"f_1573:setup_2ddownload_2escm",(void*)f_1573},
{"f_1345:setup_2ddownload_2escm",(void*)f_1345},
{"f_1347:setup_2ddownload_2escm",(void*)f_1347},
{"f_1894:setup_2ddownload_2escm",(void*)f_1894},
{"f_1342:setup_2ddownload_2escm",(void*)f_1342},
{"f_2677:setup_2ddownload_2escm",(void*)f_2677},
{"f_1547:setup_2ddownload_2escm",(void*)f_1547},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding nonexported module bindings: setup-download#constant148 
o|hiding nonexported module bindings: setup-download#*quiet* 
o|hiding nonexported module bindings: setup-download#*chicken-install-user-agent* 
o|hiding nonexported module bindings: setup-download#*trunk* 
o|hiding nonexported module bindings: setup-download#*mode* 
o|hiding nonexported module bindings: setup-download#*windows-shell* 
o|hiding nonexported module bindings: setup-download#d 
o|hiding nonexported module bindings: setup-download#get-temporary-directory 
o|hiding nonexported module bindings: setup-download#existing-version 
o|hiding nonexported module bindings: setup-download#when-no-such-version-warning 
o|hiding nonexported module bindings: setup-download#list-eggs/local 
o|hiding nonexported module bindings: setup-download#list-egg-versions/local 
o|hiding nonexported module bindings: setup-download#make-svn-ls-cmd 
o|hiding nonexported module bindings: setup-download#make-svn-export-cmd 
o|hiding nonexported module bindings: setup-download#list-eggs/svn 
o|hiding nonexported module bindings: setup-download#list-egg-versions/svn 
o|hiding nonexported module bindings: setup-download#metafile 
o|hiding nonexported module bindings: setup-download#deconstruct-url 
o|hiding nonexported module bindings: setup-download#network-failure 
o|hiding nonexported module bindings: setup-download#make-HTTP-GET/1.1 
o|hiding nonexported module bindings: setup-download#match-http-response 
o|hiding nonexported module bindings: setup-download#response-match-code? 
o|hiding nonexported module bindings: setup-download#match-chunked-transfer-encoding 
o|hiding nonexported module bindings: setup-download#http-connect 
o|hiding nonexported module bindings: setup-download#http-retrieve-files 
o|hiding nonexported module bindings: setup-download#http-fetch 
o|hiding nonexported module bindings: setup-download#list-eggs/http 
o|hiding nonexported module bindings: setup-download#throw-server-error 
o|hiding nonexported module bindings: setup-download#read-chunks 
o|hiding nonexported module bindings: setup-download#slashes 
o|hiding nonexported module bindings: setup-download#valid-extension-name? 
o|hiding nonexported module bindings: setup-download#check-egg-name 
S|applied compiler syntax:
S|  for-each		1
S|  sprintf		3
S|  map		4
o|eliminated procedure checks: 38 
o|specializations:
o|  8 (eqv? * (not float))
o|  1 (cddr (pair * pair))
o|  1 (string=? string string)
o|  2 (string-append string string)
o|  2 (zero? fixnum)
o|  3 (##sys#check-output-port * * *)
o|  2 (##sys#check-list (or pair list) *)
o|  2 (car pair)
o|  1 (current-output-port)
o|  1 (current-error-port)
o|Removed `not' forms: 4 
o|merged explicitly consed rest parameter: args158 
o|inlining procedure: k1337 
o|inlining procedure: k1337 
o|inlining procedure: k1349 
o|inlining procedure: k1349 
o|inlining procedure: k1374 
o|inlining procedure: k1374 
o|inlining procedure: k1538 
o|inlining procedure: k1538 
o|inlining procedure: k1575 
o|inlining procedure: k1575 
o|inlining procedure: k1605 
o|inlining procedure: k1605 
o|consed rest parameter at call site: "(setup-download.scm:118) setup-download#d" 2 
o|substituted constant variable: a1625 
o|substituted constant variable: a1626 
o|substituted constant variable: a1646 
o|substituted constant variable: a1647 
o|inlining procedure: k1671 
o|inlining procedure: k1697 
o|contracted procedure: "(setup-download.scm:125) g347354" 
o|consed rest parameter at call site: "(setup-download.scm:128) setup-download#d" 2 
o|inlining procedure: k1697 
o|propagated global variable: g342343 string-suffix? 
o|inlining procedure: k1671 
o|contracted procedure: k1741 
o|propagated global variable: r1742 setup-download#*trunk* 
o|inlining procedure: k1744 
o|inlining procedure: k1744 
o|inlining procedure: k1826 
o|inlining procedure: k1826 
o|merged explicitly consed rest parameter: tmp394398 
o|inlining procedure: k2227 
o|inlining procedure: k2227 
o|inlining procedure: k2264 
o|inlining procedure: k2264 
o|consed rest parameter at call site: "(setup-download.scm:214) setup-download#d" 2 
o|contracted procedure: "(setup-download.scm:202) setup-download#make-svn-export-cmd" 
o|inlining procedure: "(setup-download.scm:212) setup-download#metafile" 
o|inlining procedure: k2298 
o|inlining procedure: "(setup-download.scm:207) setup-download#metafile" 
o|inlining procedure: k2298 
o|inlining procedure: k2308 
o|inlining procedure: k2308 
o|inlining procedure: k2324 
o|inlining procedure: k2324 
o|consed rest parameter at call site: "(setup-download.scm:184) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:183) setup-download#make-svn-ls-cmd" 4 
o|inlining procedure: k2415 
o|inlining procedure: k2415 
o|inlining procedure: k2430 
o|inlining procedure: k2430 
o|substituted constant variable: setup-download#constant148 
o|inlining procedure: k2512 
o|inlining procedure: k2512 
o|contracted procedure: "(setup-download.scm:247) setup-download#http-fetch" 
o|contracted procedure: "(setup-download.scm:383) setup-download#http-retrieve-files" 
o|inlining procedure: k2894 
o|inlining procedure: k2894 
o|inlining procedure: k2923 
o|inlining procedure: k2923 
o|substituted constant variable: a2947 
o|inlining procedure: k2952 
o|inlining procedure: k2952 
o|inlining procedure: k2979 
o|contracted procedure: "(setup-download.scm:362) setup-download#throw-server-error" 
o|inlining procedure: k2979 
o|contracted procedure: k3013 
o|inlining procedure: k3010 
o|consed rest parameter at call site: "(setup-download.scm:370) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:374) setup-download#d" 2 
o|inlining procedure: k3010 
o|consed rest parameter at call site: "(setup-download.scm:336) setup-download#d" 2 
o|inlining procedure: k2533 
o|inlining procedure: k2533 
o|merged explicitly consed rest parameter: tmp627631 
o|inlining procedure: k2700 
o|inlining procedure: k2700 
o|inlining procedure: k2740 
o|inlining procedure: k2740 
o|inlining procedure: k2773 
o|contracted procedure: "(setup-download.scm:330) setup-download#read-chunks" 
o|contracted procedure: k3177 
o|inlining procedure: k3174 
o|consed rest parameter at call site: "(setup-download.scm:412) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:416) setup-download#d" 2 
o|inlining procedure: k3174 
o|consed rest parameter at call site: "(setup-download.scm:329) setup-download#d" 2 
o|inlining procedure: k2773 
o|inlining procedure: k2798 
o|inlining procedure: k2798 
o|consed rest parameter at call site: "(setup-download.scm:326) setup-download#d" 2 
o|contracted procedure: "(setup-download.scm:325) setup-download#match-chunked-transfer-encoding" 
o|consed rest parameter at call site: "(setup-download.scm:315) setup-download#make-HTTP-GET/1.1" 4 
o|inlining procedure: k2841 
o|inlining procedure: k2841 
o|contracted procedure: "(setup-download.scm:321) setup-download#network-failure" 
o|consed rest parameter at call site: "(setup-download.scm:309) setup-download#d" 2 
o|contracted procedure: "(setup-download.scm:308) setup-download#match-http-response" 
o|inlining procedure: k2688 
o|inlining procedure: k2688 
o|consed rest parameter at call site: "(setup-download.scm:305) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:301) setup-download#make-HTTP-GET/1.1" 4 
o|consed rest parameter at call site: "(setup-download.scm:299) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:294) setup-download#d" 2 
o|substituted constant variable: a2862 
o|substituted constant variable: a2863 
o|inlining procedure: k2855 
o|consed rest parameter at call site: "(setup-download.scm:294) setup-download#d" 2 
o|inlining procedure: k2855 
o|consed rest parameter at call site: "(setup-download.scm:294) setup-download#d" 2 
o|inlining procedure: k3242 
o|inlining procedure: k3242 
o|contracted procedure: "(setup-download.scm:427) setup-download#valid-extension-name?" 
o|contracted procedure: k3225 
o|inlining procedure: k3222 
o|inlining procedure: k3222 
o|inlining procedure: k3308 
o|inlining procedure: k3308 
o|inlining procedure: k3326 
o|inlining procedure: k3326 
o|substituted constant variable: a3339 
o|substituted constant variable: a3341 
o|substituted constant variable: a3343 
o|inlining procedure: k3388 
o|contracted procedure: "(setup-download.scm:453) setup-download#list-eggs/local" 
o|inlining procedure: k1401 
o|contracted procedure: "(setup-download.scm:85) g187196" 
o|inlining procedure: k1401 
o|inlining procedure: k3388 
o|contracted procedure: "(setup-download.scm:455) setup-download#list-eggs/svn" 
o|inlining procedure: k1985 
o|contracted procedure: "(setup-download.scm:166) g434443" 
o|substituted constant variable: a1972 
o|inlining procedure: k1985 
o|consed rest parameter at call site: "(setup-download.scm:164) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:163) setup-download#make-svn-ls-cmd" 4 
o|inlining procedure: k3406 
o|contracted procedure: "(setup-download.scm:457) setup-download#list-eggs/http" 
o|inlining procedure: k3406 
o|substituted constant variable: a3419 
o|substituted constant variable: a3421 
o|substituted constant variable: a3423 
o|inlining procedure: k3455 
o|contracted procedure: "(setup-download.scm:466) setup-download#list-egg-versions/local" 
o|inlining procedure: k1439 
o|inlining procedure: k1463 
o|contracted procedure: "(setup-download.scm:91) g229238" 
o|inlining procedure: k1463 
o|inlining procedure: k1439 
o|inlining procedure: k3455 
o|contracted procedure: "(setup-download.scm:468) setup-download#list-egg-versions/svn" 
o|inlining procedure: k2074 
o|inlining procedure: k2074 
o|inlining procedure: k2106 
o|contracted procedure: "(setup-download.scm:177) g485494" 
o|substituted constant variable: a2093 
o|inlining procedure: k2106 
o|consed rest parameter at call site: "(setup-download.scm:172) setup-download#make-svn-ls-cmd" 4 
o|substituted constant variable: a3477 
o|substituted constant variable: a3479 
o|replaced variables: 346 
o|removed binding forms: 177 
o|removed side-effect free assignment to unused variable: setup-download#constant148 
o|substituted constant variable: r17453514 
o|substituted constant variable: r18273516 
o|substituted constant variable: r23253542 
o|removed side-effect free assignment to unused variable: setup-download#metafile 
o|substituted constant variable: r24163545 
o|substituted constant variable: r24163545 
o|inlining procedure: k2512 
o|inlining procedure: k2512 
o|inlining procedure: k2923 
o|inlining procedure: k2923 
o|substituted constant variable: r25343571 
o|substituted constant variable: r25343571 
o|substituted constant variable: r25343573 
o|substituted constant variable: r25343573 
o|removed call to pure procedure with unused result: "(setup-download.scm:260) get-keyword" 
o|substituted constant variable: r27013576 
o|substituted constant variable: r26893598 
o|substituted constant variable: r28563601 
o|substituted constant variable: r28563601 
o|substituted constant variable: r32233605 
o|substituted constant variable: r14403623 
o|substituted constant variable: r20753625 
o|replaced variables: 20 
o|removed binding forms: 372 
o|inlining procedure: "(setup-download.scm:105) setup-download#when-no-such-version-warning" 
o|inlining procedure: "(setup-download.scm:197) setup-download#when-no-such-version-warning" 
o|contracted procedure: k2650 
o|inlining procedure: k2804 
o|inlining procedure: k2804 
o|replaced variables: 17 
o|removed binding forms: 51 
o|removed side-effect free assignment to unused variable: setup-download#when-no-such-version-warning 
o|substituted constant variable: r25133635 
o|replaced variables: 10 
o|removed binding forms: 19 
o|removed binding forms: 8 
o|simplifications: ((if . 41) (##core#call . 192)) 
o|  call simplifications:
o|    ##sys#setslot	4
o|    zero?
o|    number->string
o|    string?	2
o|    read-string	2
o|    cadr
o|    eof-object?	2
o|    string=?	3
o|    string->number	2
o|    ##sys#get-keyword	23
o|    list
o|    ##sys#apply
o|    cons	8
o|    car	17
o|    null?	35
o|    cdr	17
o|    ##sys#call-with-values	10
o|    not	5
o|    ##sys#check-list	3
o|    ##sys#slot	10
o|    eq?	13
o|    values	20
o|    pair?	7
o|    member	3
o|    apply
o|contracted procedure: k1318 
o|contracted procedure: k1355 
o|contracted procedure: k1367 
o|contracted procedure: k1793 
o|contracted procedure: k1502 
o|contracted procedure: k1787 
o|contracted procedure: k1505 
o|contracted procedure: k1781 
o|contracted procedure: k1508 
o|contracted procedure: k1775 
o|contracted procedure: k1511 
o|contracted procedure: k1769 
o|contracted procedure: k1514 
o|contracted procedure: k1763 
o|contracted procedure: k1517 
o|inlining procedure: k1557 
o|contracted procedure: k1578 
o|contracted procedure: k1608 
o|contracted procedure: k1688 
o|contracted procedure: k1700 
o|contracted procedure: k1710 
o|contracted procedure: k1714 
o|contracted procedure: k1850 
o|contracted procedure: k1846 
o|contracted procedure: k1908 
o|contracted procedure: k1915 
o|contracted procedure: k2382 
o|contracted procedure: k2179 
o|contracted procedure: k2376 
o|contracted procedure: k2182 
o|contracted procedure: k2370 
o|contracted procedure: k2185 
o|contracted procedure: k2364 
o|contracted procedure: k2188 
o|contracted procedure: k2358 
o|contracted procedure: k2191 
o|contracted procedure: k2352 
o|contracted procedure: k2194 
o|contracted procedure: k2346 
o|contracted procedure: k2197 
o|contracted procedure: k2340 
o|contracted procedure: k2200 
o|contracted procedure: k2243 
o|contracted procedure: k2267 
o|contracted procedure: k1929 
o|contracted procedure: k2288 
o|contracted procedure: k2301 
o|contracted procedure: k2427 
o|contracted procedure: k2608 
o|contracted procedure: k2445 
o|contracted procedure: k2602 
o|contracted procedure: k2448 
o|contracted procedure: k2596 
o|contracted procedure: k2451 
o|contracted procedure: k2590 
o|contracted procedure: k2454 
o|contracted procedure: k2584 
o|contracted procedure: k2457 
o|contracted procedure: k2578 
o|contracted procedure: k2460 
o|contracted procedure: k2572 
o|contracted procedure: k2463 
o|contracted procedure: k2566 
o|contracted procedure: k2466 
o|contracted procedure: k2560 
o|contracted procedure: k2469 
o|contracted procedure: k2554 
o|contracted procedure: k2472 
o|contracted procedure: k2548 
o|contracted procedure: k2475 
o|contracted procedure: k2542 
o|contracted procedure: k2478 
o|contracted procedure: k2897 
o|contracted procedure: k2917 
o|contracted procedure: k2920 
o|contracted procedure: k2944 
o|contracted procedure: k2989 
o|contracted procedure: k2998 
o|contracted procedure: k3001 
o|contracted procedure: k3068 
o|contracted procedure: k3054 
o|contracted procedure: k3074 
o|contracted procedure: k2647 
o|contracted procedure: k2653 
o|contracted procedure: k2736 
o|contracted procedure: k3171 
o|contracted procedure: k3186 
o|contracted procedure: k3208 
o|contracted procedure: k2691 
o|contracted procedure: k3236 
o|contracted procedure: k3254 
o|contracted procedure: k3257 
o|contracted procedure: k3260 
o|contracted procedure: k3263 
o|contracted procedure: k3266 
o|contracted procedure: k3269 
o|contracted procedure: k3272 
o|contracted procedure: k3275 
o|contracted procedure: k3278 
o|contracted procedure: k3281 
o|contracted procedure: k3287 
o|contracted procedure: k3311 
o|contracted procedure: k3320 
o|contracted procedure: k3329 
o|contracted procedure: k3359 
o|contracted procedure: k3362 
o|contracted procedure: k3365 
o|contracted procedure: k3368 
o|contracted procedure: k3371 
o|contracted procedure: k3374 
o|contracted procedure: k3391 
o|contracted procedure: k1404 
o|contracted procedure: k1407 
o|contracted procedure: k1418 
o|contracted procedure: k1430 
o|contracted procedure: k3400 
o|contracted procedure: k2041 
o|contracted procedure: k1935 
o|contracted procedure: k2035 
o|contracted procedure: k1938 
o|contracted procedure: k2029 
o|contracted procedure: k1941 
o|contracted procedure: k2023 
o|contracted procedure: k1944 
o|contracted procedure: k1976 
o|contracted procedure: k1988 
o|contracted procedure: k1991 
o|contracted procedure: k2002 
o|contracted procedure: k2014 
o|contracted procedure: k3409 
o|contracted procedure: k3432 
o|contracted procedure: k3435 
o|contracted procedure: k3438 
o|contracted procedure: k3458 
o|contracted procedure: k1466 
o|contracted procedure: k1469 
o|contracted procedure: k1480 
o|contracted procedure: k1492 
o|contracted procedure: k3467 
o|contracted procedure: k2170 
o|contracted procedure: k2050 
o|contracted procedure: k2164 
o|contracted procedure: k2053 
o|contracted procedure: k2158 
o|contracted procedure: k2056 
o|contracted procedure: k2152 
o|contracted procedure: k2059 
o|contracted procedure: k2077 
o|contracted procedure: k2097 
o|contracted procedure: k2109 
o|contracted procedure: k2112 
o|contracted procedure: k2123 
o|contracted procedure: k2135 
o|simplifications: ((if . 1) (let . 13)) 
o|removed binding forms: 152 
o|substituted constant variable: r15583771 
o|inlining procedure: k2237 
o|inlining procedure: k1410 
o|inlining procedure: k1410 
o|inlining procedure: k1994 
o|inlining procedure: k1994 
o|inlining procedure: k1472 
o|inlining procedure: k1472 
o|inlining procedure: k2115 
o|inlining procedure: k2115 
o|replaced variables: 104 
o|removed conditional forms: 1 
o|removed binding forms: 48 
o|replaced variables: 16 
o|removed binding forms: 1 
o|removed binding forms: 4 
o|customizable procedures: (map-loop479497 map-loop223248 map-loop428446 map-loop181206 setup-download#check-egg-name setup-download#response-match-code? setup-download#make-HTTP-GET/1.1 loop697 get-chunks824 k2982 get-files747 skip719 g730731 k2932 setup-download#http-connect setup-download#deconstruct-url setup-download#make-svn-ls-cmd setup-download#get-temporary-directory setup-download#existing-version k1581 for-each-loop346358 setup-download#d) 
o|calls to known targets: 91 
o|fast box initializations: 9 
o|fast global references: 56 
o|fast global assignments: 25 
o|dropping unused closure argument: f_2721 
o|dropping unused closure argument: f_2633 
o|dropping unused closure argument: f_2395 
o|dropping unused closure argument: f_3240 
o|dropping unused closure argument: f_1906 
o|dropping unused closure argument: f_1316 
o|dropping unused closure argument: f_2698 
o|dropping unused closure argument: f_1332 
o|dropping unused closure argument: f_1347 
*/
/* end of file */
