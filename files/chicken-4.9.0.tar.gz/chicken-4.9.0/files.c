/* Generated from files.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:37
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: files.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file files.c
   unit: files
*/

#include "chicken.h"

#include <errno.h>

#ifndef _WIN32
# include <sys/stat.h>
# define C_mkdir(str)       C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#else
# define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_irregex_toplevel)
C_externimport void C_ccall C_irregex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[103];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,21),40,100,101,108,101,116,101,45,102,105,108,101,42,32,102,105,108,101,54,52,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,100,57,52,32,108,57,53,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,99,111,112,121,32,111,114,105,103,102,105,108,101,55,50,32,110,101,119,102,105,108,101,55,51,32,46,32,116,109,112,55,49,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,100,49,51,52,32,108,49,51,53,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,46),40,102,105,108,101,45,109,111,118,101,32,111,114,105,103,102,105,108,101,49,49,50,32,110,101,119,102,105,108,101,49,49,51,32,46,32,116,109,112,49,49,49,49,49,52,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,26),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,63,32,112,110,49,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,11),40,108,112,32,108,101,110,49,55,50,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,17),40,99,104,111,112,45,112,100,115,32,115,116,114,49,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,115,49,56,57,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,19),40,99,111,110,99,45,100,105,114,115,32,100,105,114,115,49,56,55,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,27),40,99,97,110,111,110,105,99,97,108,105,122,101,45,100,105,114,115,32,100,105,114,115,49,57,51,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,45),40,95,109,97,107,101,45,112,97,116,104,110,97,109,101,32,108,111,99,50,48,49,32,100,105,114,50,48,50,32,102,105,108,101,50,48,51,32,101,120,116,50,48,52,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,43),40,109,97,107,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,50,50,55,32,102,105,108,101,50,50,56,32,46,32,116,109,112,50,50,54,50,50,57,41,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,52),40,109,97,107,101,45,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,50,52,48,32,102,105,108,101,50,52,49,32,46,32,116,109,112,50,51,57,50,52,50,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,18),40,115,116,114,105,112,45,112,100,115,32,100,105,114,50,53,57,41,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,26),40,100,101,99,111,109,112,111,115,101,45,112,97,116,104,110,97,109,101,32,112,110,50,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,7),40,97,49,52,51,52,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,47),40,97,49,52,52,48,32,100,105,114,50,54,56,50,54,57,50,55,52,32,102,105,108,101,50,55,48,50,55,49,50,55,53,32,101,120,116,50,55,50,50,55,51,50,55,54,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,100,105,114,101,99,116,111,114,121,32,112,110,50,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,49,52,52,57,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,47),40,97,49,52,53,53,32,100,105,114,50,56,50,50,56,51,50,56,56,32,102,105,108,101,50,56,52,50,56,53,50,56,57,32,101,120,116,50,56,54,50,56,55,50,57,48,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,21),40,112,97,116,104,110,97,109,101,45,102,105,108,101,32,112,110,50,56,49,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,49,52,54,52,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,47),40,97,49,52,55,48,32,100,105,114,50,57,54,50,57,55,51,48,50,32,102,105,108,101,50,57,56,50,57,57,51,48,51,32,101,120,116,51,48,48,51,48,49,51,48,52,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,101,120,116,101,110,115,105,111,110,32,112,110,50,57,53,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,7),40,97,49,52,55,57,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,47),40,97,49,52,56,53,32,100,105,114,51,49,48,51,49,49,51,49,54,32,102,105,108,101,51,49,50,51,49,51,51,49,55,32,101,120,116,51,49,52,51,49,53,51,49,56,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,100,105,114,101,99,116,111,114,121,32,112,110,51,48,57,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,7),40,97,49,52,57,55,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,47),40,97,49,53,48,51,32,100,105,114,51,50,52,51,50,53,51,51,48,32,102,105,108,101,51,50,54,51,50,55,51,51,49,32,101,120,116,51,50,56,51,50,57,51,51,50,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,101,120,116,101,110,115,105,111,110,32,112,110,51,50,51,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,53,49,53,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,45),40,97,49,53,50,49,32,95,51,51,57,51,52,48,51,52,53,32,102,105,108,101,51,52,49,51,52,50,51,52,54,32,101,120,116,51,52,51,51,52,52,51,52,55,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,100,105,114,101,99,116,111,114,121,32,112,110,51,51,55,32,100,105,114,51,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,7),40,97,49,53,51,51,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,44),40,97,49,53,51,57,32,100,105,114,51,53,52,51,53,53,51,54,48,32,95,51,53,54,51,53,55,51,54,49,32,101,120,116,51,53,56,51,53,57,51,54,50,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,37),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,102,105,108,101,32,112,110,51,53,50,32,102,105,108,101,51,53,51,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,49,53,53,49,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,45),40,97,49,53,53,55,32,100,105,114,51,54,57,51,55,48,51,55,53,32,102,105,108,101,51,55,49,51,55,50,51,55,54,32,95,51,55,51,51,55,52,51,55,55,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,101,120,116,101,110,115,105,111,110,32,112,110,51,54,55,32,101,120,116,51,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,9),40,116,101,109,112,100,105,114,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,12),40,97,49,54,49,56,32,112,52,49,53,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,35),40,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,102,105,108,101,32,46,32,116,109,112,52,48,53,52,48,54,41,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,28),40,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,18),40,97,100,100,112,97,114,116,32,112,97,114,116,115,52,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,11),40,103,52,54,55,32,112,52,55,54,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,52,54,54,32,103,52,55,51,52,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,105,52,53,52,32,112,114,101,118,52,53,53,32,112,97,114,116,115,52,53,54,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,40),40,110,111,114,109,97,108,105,122,101,45,112,97,116,104,110,97,109,101,32,112,97,116,104,52,52,50,32,46,32,116,109,112,52,52,49,52,52,51,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,24),40,100,105,114,101,99,116,111,114,121,45,110,117,108,108,63,32,100,105,114,53,48,56,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,28),40,100,101,99,111,109,112,111,115,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,53,49,55,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,14),40,102,95,50,49,54,55,32,112,110,49,53,49,41,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,14),40,102,95,50,49,55,51,32,114,116,49,53,50,41,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,14),40,102,95,50,49,56,50,32,114,116,49,53,52,41,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,30),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,45,114,111,111,116,32,112,110,49,53,57,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,19),40,114,111,111,116,45,111,114,105,103,105,110,32,114,116,49,54,48,41,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,22),40,114,111,111,116,45,100,105,114,101,99,116,111,114,121,32,114,116,49,54,49,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2050)
static C_word C_fcall f_2050(C_word t0);
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_970)
static void C_ccall f_970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_fcall f_1601(C_word t0,C_word t1) C_noret;
C_noret_decl(f_911)
static void C_ccall f_911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_911)
static void C_ccall f_911r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_fcall f_1851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1412)
static void C_ccall f_1412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1416)
static void C_ccall f_1416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_762)
static void C_ccall f_762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1408)
static void C_ccall f_1408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_770)
static void C_ccall f_770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_765)
static void C_ccall f_765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_768)
static void C_ccall f_768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_782)
static void C_ccall f_782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_782)
static void C_ccall f_782r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1923)
static void C_fcall f_1923(C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_861)
static void C_ccall f_861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_fcall f_1062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_fcall f_1564(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_841)
static void C_ccall f_841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_844)
static void C_ccall f_844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1082)
static void C_fcall f_1082(C_word t0,C_word t1) C_noret;
C_noret_decl(f_854)
static void C_ccall f_854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_829)
static void C_ccall f_829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_fcall f_831(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_fcall f_1047(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_819)
static void C_ccall f_819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_816)
static void C_ccall f_816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_fcall f_1770(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1128)
static void C_fcall f_1128(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_fcall f_1654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_fcall f_1075(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1119)
static void C_fcall f_1119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_files_toplevel)
C_externexport void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_807)
static void C_ccall f_807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static C_word C_fcall f_1714(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_1874)
static void C_fcall f_1874(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_fcall f_1336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1201)
static void C_fcall f_1201(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1170)
static void C_fcall f_1170(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_fcall f_1780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_fcall f_1249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1231)
static void C_fcall f_1231(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_fcall f_1975(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_993)
static void C_ccall f_993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_fcall f_960(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_936)
static void C_ccall f_936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1819)
static void C_fcall f_1819(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1601)
static void C_fcall trf_1601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1601(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1601(t0,t1);}

C_noret_decl(trf_1851)
static void C_fcall trf_1851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1851(t0,t1);}

C_noret_decl(trf_1923)
static void C_fcall trf_1923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1923(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1923(t0,t1);}

C_noret_decl(trf_1062)
static void C_fcall trf_1062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1062(t0,t1);}

C_noret_decl(trf_1564)
static void C_fcall trf_1564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1564(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1564(t0,t1);}

C_noret_decl(trf_1082)
static void C_fcall trf_1082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1082(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1082(t0,t1);}

C_noret_decl(trf_831)
static void C_fcall trf_831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_831(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_831(t0,t1,t2,t3);}

C_noret_decl(trf_1047)
static void C_fcall trf_1047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1047(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1047(t0,t1);}

C_noret_decl(trf_1770)
static void C_fcall trf_1770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1770(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1770(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1128)
static void C_fcall trf_1128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1128(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1128(t0,t1,t2);}

C_noret_decl(trf_1654)
static void C_fcall trf_1654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1654(t0,t1);}

C_noret_decl(trf_1075)
static void C_fcall trf_1075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1075(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1075(t0,t1,t2);}

C_noret_decl(trf_1119)
static void C_fcall trf_1119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1119(t0,t1);}

C_noret_decl(trf_1874)
static void C_fcall trf_1874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1874(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1874(t0,t1,t2);}

C_noret_decl(trf_1336)
static void C_fcall trf_1336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1336(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1336(t0,t1);}

C_noret_decl(trf_1201)
static void C_fcall trf_1201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1201(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1201(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1170)
static void C_fcall trf_1170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1170(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1170(t0,t1,t2);}

C_noret_decl(trf_1780)
static void C_fcall trf_1780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1780(t0,t1);}

C_noret_decl(trf_1249)
static void C_fcall trf_1249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1249(t0,t1);}

C_noret_decl(trf_1231)
static void C_fcall trf_1231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1231(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1231(t0,t1);}

C_noret_decl(trf_1975)
static void C_fcall trf_1975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1975(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1975(t0,t1);}

C_noret_decl(trf_960)
static void C_fcall trf_960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_960(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_960(t0,t1,t2,t3);}

C_noret_decl(trf_1819)
static void C_fcall trf_1819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1819(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1819(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* pathname-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1444,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1450,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1456,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
/* files.scm:263: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1440 in pathname-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1441,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* loop in k2046 in directory-null? in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static C_word C_fcall f_2050(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:
t2=C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=C_i_car(t1);
if(C_truep((C_truep(C_i_equalp(t3,lf[88]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[89]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
t5=C_u_i_cdr(t4);
t7=t5;
t1=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k1840 in k1837 in k1834 in k1831 in k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1842,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_string_equal_p(((C_word*)t0)[2],((C_word*)t3)[1]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1862,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_a_i_string(&a,1,((C_word*)t0)[6]);
/* files.scm:392: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t5,t6,((C_word*)t3)[1]);}
else{
t5=t4;
f_1851(t5,C_SCHEME_UNDEFINED);}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t3)[1]);}}

/* k977 in loop in k956 in k949 in k946 in k943 in k940 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* files.scm:132: read-string! */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k974 in k971 in k968 in loop in k956 in k949 in k946 in k943 in k940 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1000 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* files.scm:112: ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[17],lf[19],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_939(2,t2,C_SCHEME_UNDEFINED);}}

/* k971 in k968 in loop in k956 in k949 in k946 in k943 in k940 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:128: delete-file */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k968 in loop in k956 in k949 in k946 in k943 in k940 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm:127: close-output-port */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k1831 in k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[7],((C_word*)t0)[8]);
if(C_truep(t3)){
/* files.scm:387: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[81]+1)))(4,*((C_word*)lf[81]+1),t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t4=t2;
f_1836(2,t4,C_SCHEME_UNDEFINED);}}

/* k946 in k943 in k940 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_948,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm:121: make-string */
t4=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1837 in k1834 in k1831 in k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1842,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm:389: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),t3,t2);}

/* k1834 in k1831 in k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* files.scm:388: get-output-string */
t3=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* a1470 in pathname-extension in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1471,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* pathname-strip-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1474,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1480,a[2]=t2,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1486,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* files.scm:273: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* decompose-directory in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2080,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2127,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_i_check_string_2(t4,lf[92]);
/* files.scm:418: string-split */
t6=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,lf[91],C_SCHEME_FALSE);}

/* k940 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* files.scm:119: open-input-file */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[10]);}

/* k943 in k940 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* files.scm:120: open-output-file */
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],lf[10]);}

/* k1860 in k1840 in k1837 in k1834 in k1831 in k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_1851(t3,t2);}

/* a1464 in pathname-extension in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
/* files.scm:269: decompose-pathname */
t2=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k1603 in loop in create-temporary-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1605,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* files.scm:325: file-exists? */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* loop in create-temporary-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_fcall f_1601(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1601,NULL,2,t0,t1);}
t2=C_random_fixnum(C_fix(65536));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1624,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* files.scm:318: tempdir */
t5=((C_word*)t0)[5];
f_1564(t5,t4);}

/* file-move in k766 in k763 in k760 */
static void C_ccall f_911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_911r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_911r(t0,t1,t2,t3,t4);}}

static void C_ccall f_911r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(7);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_fix(1024):C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_check_string_2(t2,lf[17]);
t16=C_i_check_string_2(t3,lf[17]);
t17=C_i_check_number_2(t12,lf[17]);
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_936,a[2]=t2,a[3]=t12,a[4]=t1,a[5]=t3,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_integerp(t12))){
if(C_truep(C_fixnum_greaterp(t12,C_fix(0)))){
t19=t18;
f_936(2,t19,C_SCHEME_UNDEFINED);}
else{
/* files.scm:107: ##sys#error */
t19=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t18,lf[17],lf[20],t12);}}
else{
/* files.scm:107: ##sys#error */
t19=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t18,lf[17],lf[20],t12);}}

/* k1856 in k1849 in k1840 in k1837 in k1834 in k1831 in k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1849 in k1840 in k1837 in k1834 in k1831 in k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_fcall f_1851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1851,NULL,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm:394: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t2,((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}}

/* k1410 in k1406 in k1396 in k1371 in decompose-pathname in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:251: values */
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],t1,C_SCHEME_FALSE);}

/* k1414 in k1396 in k1371 in decompose-pathname in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:252: strip-pds */
f_1336(((C_word*)t0)[3],t1);}

/* k760 */
static void C_ccall f_762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_765,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_2dstructures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1406 in k1396 in k1371 in decompose-pathname in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1408,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1412,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm:253: irregex-match-substring */
t4=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(2));}

/* delete-file* in k766 in k763 in k760 */
static void C_ccall f_770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_770,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_777,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm:67: file-exists? */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1908 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1910,2,t0,t1);}
t2=f_1714(C_a_i(&a,9),t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
f_1780(t4,t3);}

/* k763 in k760 */
static void C_ccall f_765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* files.scm:57: register-feature! */
t3=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[102]);}

/* k766 in k763 in k760 */
static void C_ccall f_768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_768,2,t0,t1);}
t2=C_mutate2((C_word*)lf[0]+1 /* (set! delete-file* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_770,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2((C_word*)lf[3]+1 /* (set! file-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_782,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[17]+1 /* (set! file-move ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_911,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t5=lf[21] /* absolute-pathname-root */ =C_SCHEME_UNDEFINED;;
t6=lf[22] /* root-origin */ =C_SCHEME_UNDEFINED;;
t7=lf[23] /* root-directory */ =C_SCHEME_UNDEFINED;;
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[97]+1))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2165,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* files.scm:146: irregex */
t10=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[99]);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2192,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* files.scm:150: irregex */
t10=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[100]);}}

/* a1434 in pathname-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
/* files.scm:259: decompose-pathname */
t2=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* file-copy in k766 in k763 in k760 */
static void C_ccall f_782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_782r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_782r(t0,t1,t2,t3,t4);}}

static void C_ccall f_782r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(7);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_fix(1024):C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_check_string_2(t2,lf[3]);
t16=C_i_check_string_2(t3,lf[3]);
t17=C_i_check_number_2(t12,lf[3]);
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_807,a[2]=t12,a[3]=t1,a[4]=t3,a[5]=t2,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_integerp(t12))){
if(C_truep(C_fixnum_greaterp(t12,C_fix(0)))){
t19=t18;
f_807(2,t19,C_SCHEME_UNDEFINED);}
else{
/* files.scm:76: ##sys#error */
t19=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t18,lf[3],lf[16],t12);}}
else{
/* files.scm:76: ##sys#error */
t19=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t18,lf[3],lf[16],t12);}}

/* k1921 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_fcall f_1923(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1923,NULL,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t2)){
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* files.scm:400: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1770(t5,((C_word*)t0)[5],t3,t4,((C_word*)((C_word*)t0)[6])[1]);}
else{
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=t3;
t5=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* files.scm:403: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),t7,((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k775 in delete-file* in k766 in k763 in k760 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* files.scm:67: delete-file */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1421 in k1396 in k1371 in decompose-pathname in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:255: values */
C_values(5,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* pathname-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1429,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1435,a[2]=t2,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1441,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
/* files.scm:258: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* k859 in k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* files.scm:87: ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[3],lf[13],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_813(2,t2,C_SCHEME_UNDEFINED);}}

/* k1576 in k1569 in tempdir in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:308: get-environment-variable */
t3=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[56]);}}

/* k1569 in tempdir in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1571,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:307: get-environment-variable */
t3=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}}

/* k865 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
f_810(2,t2,((C_word*)t0)[2]);}
else{
/* files.scm:82: ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[3],lf[15],((C_word*)t0)[4]);}}
else{
t2=((C_word*)t0)[3];
f_810(2,t2,C_SCHEME_FALSE);}}

/* chop-pds in k1045 in k766 in k763 in k760 */
static void C_fcall f_1062(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1062,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1075,a[2]=t5,a[3]=t2,a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1075(t7,t1,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1058 in absolute-pathname? in k1045 in k766 in k763 in k760 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:157: irregex-match-data? */
t2=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* tempdir in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_fcall f_1564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1564,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* files.scm:306: get-environment-variable */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[58]);}}

/* a1539 in pathname-replace-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1540,5,t0,t1,t2,t3,t4);}
/* files.scm:290: make-pathname */
t5=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,((C_word*)t0)[2],t4);}

/* k839 in loop in k827 in k820 in k817 in k814 in k811 in k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:96: close-output-port */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* a1557 in pathname-replace-extension in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1558,5,t0,t1,t2,t3,t4);}
/* files.scm:295: make-pathname */
t5=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,((C_word*)t0)[2]);}

/* k842 in k839 in loop in k827 in k820 in k817 in k814 in k811 in k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1551 in pathname-replace-extension in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
/* files.scm:294: decompose-pathname */
t2=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k845 in loop in k827 in k820 in k817 in k814 in k811 in k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* files.scm:100: read-string! */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k1080 in lp in chop-pds in k1045 in k766 in k763 in k760 */
static void C_fcall f_1082(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
/* files.scm:166: lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1075(t3,((C_word*)t0)[4],t2);}
else{
t2=C_block_size(((C_word*)t0)[5]);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[2],t2))){
/* files.scm:168: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),((C_word*)t0)[4],((C_word*)t0)[5],C_fix(0),((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}}}

/* k852 in k845 in loop in k827 in k820 in k817 in k814 in k811 in k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],((C_word*)t0)[3]);
/* files.scm:100: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_831(t3,((C_word*)t0)[5],t1,t2);}

/* pathname-replace-extension in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1546,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1552,a[2]=t2,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1558,a[2]=t3,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
/* files.scm:293: ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* k820 in k817 in k814 in k811 in k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_822,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm:91: read-string! */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}

/* k1957 in k1921 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1959,2,t0,t1);}
t2=f_1714(C_a_i(&a,9),t1,((C_word*)((C_word*)t0)[3])[1]);
/* files.scm:401: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1770(t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],t2);}

/* k2125 in decompose-directory in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2127,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2130,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm:451: absolute-pathname-root */
t4=lf[21];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* a1533 in pathname-replace-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1534,2,t0,t1);}
/* files.scm:289: decompose-pathname */
t2=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k827 in k820 in k817 in k814 in k811 in k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_829,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li1),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_831(t5,((C_word*)t0)[6],t1,C_fix(0));}

/* pathname-replace-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1510,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1516,a[2]=t2,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1522,a[2]=t3,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
/* files.scm:283: ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* pathname-strip-extension in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1492,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1498,a[2]=t2,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1504,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
/* files.scm:278: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1497 in pathname-strip-extension in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1498,2,t0,t1);}
/* files.scm:279: decompose-pathname */
t2=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* loop in k827 in k820 in k817 in k814 in k811 in k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_fcall f_831(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_831,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_841,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm:95: close-input-port */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_847,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
/* files.scm:99: write-string */
t6=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[6],t2,((C_word*)t0)[2]);}}

/* k2117 in k2138 in k2131 in k2128 in k2125 in decompose-directory in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,t1,((C_word*)t0)[3]));}

/* a1521 in pathname-replace-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1522,5,t0,t1,t2,t3,t4);}
/* files.scm:285: make-pathname */
t5=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* pathname-replace-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1528,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1534,a[2]=t2,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1540,a[2]=t3,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
/* files.scm:288: ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* k2142 in k2138 in k2131 in k2128 in k2125 in decompose-directory in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:453: values */
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* a1479 in pathname-strip-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
/* files.scm:274: decompose-pathname */
t2=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1485 in pathname-strip-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1486,5,t0,t1,t2,t3,t4);}
/* files.scm:275: make-pathname */
t5=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_SCHEME_FALSE,t3,t4);}

/* k2138 in k2131 in k2128 in k2125 in decompose-directory in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_nullp(((C_word*)t0)[4]);
t5=(C_truep(t4)?C_SCHEME_FALSE:((C_word*)t0)[4]);
t6=t3;
if(C_truep(((C_word*)t0)[3])){
t7=C_i_car(t5);
t8=C_block_size(((C_word*)t0)[3]);
if(C_truep(C_substring_compare(((C_word*)t0)[3],t7,C_fix(0),C_fix(0),t8))){
t9=C_u_i_cdr(t5);
t10=C_block_size(t7);
t11=C_block_size(t10);
t12=C_eqp(t8,t11);
if(C_truep(t12)){
t13=t6;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t9);}
else{
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2119,a[2]=t6,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* files.scm:449: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),t13,t7,t8,t10);}}
else{
t9=t6;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t5);}}
else{
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}}

/* k1158 in k1154 in loop in conc-dirs in k1045 in k766 in k763 in k760 */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:184: string-append */
t2=*((C_word*)lf[31]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[32],t1);}

/* a1515 in pathname-replace-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1516,2,t0,t1);}
/* files.scm:284: decompose-pathname */
t2=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k1622 in loop in create-temporary-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1632,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm:321: number->string */
C_number_to_string(4,0,t4,((C_word*)t0)[5],C_fix(16));}

/* k1626 in k1622 in loop in create-temporary-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:317: make-pathname */
t2=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* absolute-pathname? in k1045 in k766 in k763 in k760 */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1049,3,t0,t1,t2);}
t3=C_i_check_string_2(t2,lf[24]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1060,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:157: absolute-pathname-root */
t5=lf[21];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2131 in k2128 in k2125 in decompose-directory in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2133,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* files.scm:453: root-directory */
t4=lf[23];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1045 in k766 in k763 in k760 */
static void C_fcall f_1047(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1047,NULL,2,t0,t1);}
t2=C_mutate2((C_word*)lf[24]+1 /* (set! absolute-pathname? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2(&lf[26] /* (set! chop-pds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1062,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1119,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1170,a[2]=t5,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1201,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2((C_word*)lf[29]+1 /* (set! make-pathname ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1283,a[2]=t9,a[3]=t7,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp));
t14=C_mutate2((C_word*)lf[39]+1 /* (set! make-absolute-pathname ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1302,a[2]=t9,a[3]=t7,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* files.scm:230: irregex */
t16=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,lf[96]);}

/* k2128 in k2125 in decompose-directory in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2130,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* files.scm:452: root-origin */
t4=lf[22];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1154 in loop in conc-dirs in k1045 in k766 in k763 in k760 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1156,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1160,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* files.scm:187: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1128(t6,t3,t5);}

/* k817 in k814 in k811 in k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_819,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_822,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* files.scm:90: make-string */
t4=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* a1503 in pathname-strip-extension in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1504,5,t0,t1,t2,t3,t4);}
/* files.scm:280: make-pathname */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* k814 in k811 in k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_816,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_819,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* files.scm:89: open-output-file */
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[10]);}

/* k811 in k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm:88: open-input-file */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[10]);}

/* a1618 in k1609 in k1603 in loop in create-temporary-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1619,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k808 in k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_861,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* files.scm:86: directory-exists? */
t4=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k1609 in k1603 in loop in create-temporary-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1611,2,t0,t1);}
if(C_truep(t1)){
/* files.scm:326: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1601(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[4],a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
/* files.scm:327: call-with-output-file */
t3=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[4],t2);}}

/* k2163 in k766 in k763 in k760 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=t1;
t3=C_mutate2(&lf[21] /* (set! absolute-pathname-root ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2167,a[2]=t2,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate2(&lf[22] /* (set! root-origin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2173,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2(&lf[23] /* (set! root-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t0)[2];
f_1047(t6,t5);}

/* k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
t2=C_eqp(t1,lf[71]);
t3=(C_truep(t2)?lf[72]:lf[73]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1714,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
t6=C_mutate2((C_word*)lf[77]+1 /* (set! normalize-pathname ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1752,a[2]=t4,a[3]=t5,a[4]=((C_word)li50),tmp=(C_word)a,a+=5,tmp));
t7=C_mutate2((C_word*)lf[87]+1 /* (set! directory-null? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2040,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[92]+1 /* (set! decompose-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2080,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}

/* f_2167 in k2163 in k766 in k763 in k760 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2167,3,t0,t1,t2);}
/* files.scm:147: irregex-match */
t3=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* create-temporary-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1654,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li44),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1654(t5,t1);}

/* loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_fcall f_1770(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1770,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1780,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_fixnum_greaterp(t2,t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1910,a[2]=((C_word*)t0)[6],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* files.scm:371: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),t7,((C_word*)t0)[7],t3,t2);}
else{
t7=t6;
f_1780(t7,C_SCHEME_UNDEFINED);}}
else{
t6=C_i_string_ref(((C_word*)t0)[7],t2);
if(C_truep((C_truep(C_eqp(t6,C_make_character(92)))?C_SCHEME_TRUE:(C_truep(C_eqp(t6,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1923,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_nullp(((C_word*)t5)[1]))){
t8=C_eqp(t2,t3);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t10=t7;
f_1923(t10,t9);}
else{
t9=t7;
f_1923(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t7;
f_1923(t8,C_SCHEME_UNDEFINED);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1975,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_nullp(((C_word*)t5)[1]))){
t8=((C_word*)t0)[7];
t9=t2;
t10=C_subchar(t8,t9);
t11=C_i_char_equalp(t10,C_make_character(58));
t12=t7;
f_1975(t12,(C_truep(t11)?C_eqp(lf[72],((C_word*)t0)[9]):C_SCHEME_FALSE));}
else{
t8=t7;
f_1975(t8,C_SCHEME_FALSE);}}}}

/* k1630 in k1622 in loop in create-temporary-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1632,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_fudge(C_fix(33));
/* files.scm:323: ##sys#number->string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[63]+1)))(3,*((C_word*)lf[63]+1),t3,t4);}

/* k1634 in k1630 in k1622 in loop in create-temporary-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:319: string-append */
t2=*((C_word*)lf[31]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[62],t1);}

/* f_2182 in k2163 in k766 in k763 in k760 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2182,3,t0,t1,t2);}
if(C_truep(t2)){
/* files.scm:149: irregex-match-substring */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_fix(2));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* loop in conc-dirs in k1045 in k766 in k763 in k760 */
static void C_fcall f_1128(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1128,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[30]);}
else{
t3=C_i_car(t2);
t4=C_i_string_length(t3);
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t2;
t7=C_u_i_cdr(t6);
/* files.scm:183: loop */
t12=t1;
t13=t7;
t1=t12;
t2=t13;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1156,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=C_u_i_car(t7);
/* files.scm:185: chop-pds */
f_1062(t6,t8);}}}

/* make-absolute-pathname in k1045 in k766 in k763 in k760 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1302r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1302r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1302r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* files.scm:221: canonicalize-dirs */
t9=((C_word*)((C_word*)t0)[3])[1];
f_1170(t9,t8,t2);}

/* k1662 in k1656 in loop in create-temporary-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1664,2,t0,t1);}
if(C_truep(t1)){
/* files.scm:340: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1654(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1671,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm:341: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[69]+1)))(4,*((C_word*)lf[69]+1),t2,((C_word*)t0)[4],lf[64]);}}

/* normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_1752r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1752r(t0,t1,t2,t3);}}

static void C_ccall f_1752r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a=C_alloc(17);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?((C_word*)t0)[2]:C_i_car(t3));
t6=t5;
t7=C_eqp(t6,lf[72]);
t8=(C_truep(t7)?C_make_character(92):C_make_character(47));
t9=t8;
t10=C_i_check_string_2(t2,lf[77]);
t11=C_block_size(t2);
t12=t11;
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1770,a[2]=t12,a[3]=t16,a[4]=t14,a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=t18,a[9]=t6,a[10]=((C_word)li49),tmp=(C_word)a,a+=11,tmp));
t20=((C_word*)t18)[1];
f_1770(t20,t1,C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* f_2173 in k2163 in k766 in k763 in k760 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2173,3,t0,t1,t2);}
if(C_truep(t2)){
/* files.scm:148: irregex-match-substring */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_fix(1));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-pathname in k1045 in k766 in k763 in k760 */
static void C_ccall f_1283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1283r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1283r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1283r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* files.scm:215: canonicalize-dirs */
t9=((C_word*)((C_word*)t0)[3])[1];
f_1170(t9,t8,t2);}

/* k1656 in loop in create-temporary-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* files.scm:339: directory-exists? */
t4=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* loop in create-temporary-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_fcall f_1654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1654,NULL,2,t0,t1);}
t2=C_random_fixnum(C_fix(65536));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1658,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1692,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* files.scm:333: tempdir */
t5=((C_word*)t0)[4];
f_1564(t5,t4);}

/* lp in chop-pds in k1045 in k766 in k763 in k760 */
static void C_fcall f_1075(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1075,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1082,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(t2,C_fix(1)))){
t4=C_fixnum_difference(t2,C_fix(1));
t5=C_subchar(((C_word*)t0)[3],t4);
t6=t3;
f_1082(t6,C_u_i_memq(t5,lf[28]));}
else{
t4=t3;
f_1082(t4,C_SCHEME_FALSE);}}

/* conc-dirs in k1045 in k766 in k763 in k760 */
static void C_fcall f_1119(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1119,NULL,2,t1,t2);}
t3=C_i_check_list_2(t2,lf[29]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1128,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1128(t7,t1,t2);}

/* absolute-pathname-root in k2190 in k766 in k763 in k760 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2194,3,t0,t1,t2);}
/* files.scm:151: irregex-match */
t3=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k2190 in k766 in k763 in k760 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=t1;
t3=C_mutate2(&lf[21] /* (set! absolute-pathname-root ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2194,a[2]=t2,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate2(&lf[22] /* (set! root-origin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2200,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2(&lf[23] /* (set! root-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2203,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t0)[2];
f_1047(t6,t5);}

/* k1222 in _make-pathname in k1045 in k766 in k763 in k760 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_block_size(((C_word*)t0)[4]);
if(C_truep(C_fixnum_greaterp(t4,C_fix(0)))){
t5=C_subchar(((C_word*)t0)[4],C_fix(0));
t6=C_i_char_equalp(t5,C_make_character(46));
t7=t3;
f_1231(t7,C_i_not(t6));}
else{
t5=t3;
f_1231(t5,C_SCHEME_FALSE);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_files_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("files_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(632)){
C_save(t1);
C_rereclaim2(632*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,103);
lf[0]=C_h_intern(&lf[0],12,"delete-file\052");
lf[1]=C_h_intern(&lf[1],11,"delete-file");
lf[2]=C_h_intern(&lf[2],12,"file-exists\077");
lf[3]=C_h_intern(&lf[3],9,"file-copy");
lf[4]=C_h_intern(&lf[4],17,"close-output-port");
lf[5]=C_h_intern(&lf[5],16,"close-input-port");
lf[6]=C_h_intern(&lf[6],12,"read-string!");
lf[7]=C_h_intern(&lf[7],12,"write-string");
lf[8]=C_h_intern(&lf[8],11,"make-string");
lf[9]=C_h_intern(&lf[9],16,"open-output-file");
lf[10]=C_h_intern(&lf[10],7,"\000binary");
lf[11]=C_h_intern(&lf[11],15,"open-input-file");
lf[12]=C_h_intern(&lf[12],9,"\003syserror");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\030can not copy directories");
lf[14]=C_h_intern(&lf[14],17,"directory-exists\077");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000#newfile exists but clobber is false");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000/invalid blocksize given: not a positive integer");
lf[17]=C_h_intern(&lf[17],9,"file-move");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000#newfile exists but clobber is false");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\030can not move directories");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000/invalid blocksize given: not a positive integer");
lf[24]=C_h_intern(&lf[24],18,"absolute-pathname\077");
lf[25]=C_h_intern(&lf[25],19,"irregex-match-data\077");
lf[27]=C_h_intern(&lf[27],13,"\003syssubstring");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[29]=C_h_intern(&lf[29],13,"make-pathname");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[31]=C_h_intern(&lf[31],13,"string-append");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[39]=C_h_intern(&lf[39],22,"make-absolute-pathname");
lf[40]=C_h_intern(&lf[40],17,"\003sysstring-append");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[42]=C_h_intern(&lf[42],18,"decompose-pathname");
lf[43]=C_h_intern(&lf[43],23,"irregex-match-substring");
lf[44]=C_h_intern(&lf[44],14,"irregex-search");
lf[45]=C_h_intern(&lf[45],18,"pathname-directory");
lf[46]=C_h_intern(&lf[46],13,"pathname-file");
lf[47]=C_h_intern(&lf[47],18,"pathname-extension");
lf[48]=C_h_intern(&lf[48],24,"pathname-strip-directory");
lf[49]=C_h_intern(&lf[49],24,"pathname-strip-extension");
lf[50]=C_h_intern(&lf[50],26,"pathname-replace-directory");
lf[51]=C_h_intern(&lf[51],21,"pathname-replace-file");
lf[52]=C_h_intern(&lf[52],26,"pathname-replace-extension");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\004temp");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\004/tmp");
lf[55]=C_h_intern(&lf[55],24,"get-environment-variable");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[59]=C_h_intern(&lf[59],21,"create-temporary-file");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[61]=C_h_intern(&lf[61],21,"call-with-output-file");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[63]=C_h_intern(&lf[63],18,"\003sysnumber->string");
lf[64]=C_h_intern(&lf[64],26,"create-temporary-directory");
lf[65]=C_h_intern(&lf[65],15,"\003syssignal-hook");
lf[66]=C_h_intern(&lf[66],11,"\000file-error");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000$cannot create temporary directory - ");
lf[68]=C_h_intern(&lf[68],17,"\003syspeek-c-string");
lf[69]=C_h_intern(&lf[69],17,"\003sysmake-c-string");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[71]=C_h_intern(&lf[71],7,"mingw32");
lf[72]=C_h_intern(&lf[72],7,"windows");
lf[73]=C_h_intern(&lf[73],4,"unix");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[77]=C_h_intern(&lf[77],18,"normalize-pathname");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[80]=C_h_intern(&lf[80],7,"display");
lf[81]=C_h_intern(&lf[81],16,"\003syswrite-char-0");
lf[82]=C_h_intern(&lf[82],8,"for-each");
lf[83]=C_h_intern(&lf[83],20,"\003sysexpand-home-path");
lf[84]=C_h_intern(&lf[84],17,"get-output-string");
lf[85]=C_h_intern(&lf[85],16,"\003sysfast-reverse");
lf[86]=C_h_intern(&lf[86],18,"open-output-string");
lf[87]=C_h_intern(&lf[87],15,"directory-null\077");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[90]=C_h_intern(&lf[90],12,"string-split");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[92]=C_h_intern(&lf[92],19,"decompose-directory");
lf[93]=C_h_intern(&lf[93],14,"build-platform");
lf[94]=C_h_intern(&lf[94],7,"irregex");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\034^(.\052[\134/\134\134])\077((\134.)\077[^\134/\134\134]+)$");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000&^(.\052[\134/\134\134])\077([^\134/\134\134]+)(\134.([^\134/\134\134.]+))$");
lf[97]=C_h_intern(&lf[97],20,"\003syswindows-platform");
lf[98]=C_h_intern(&lf[98],13,"irregex-match");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\026([A-Za-z]:)\077([\134/\134\134]).\052");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\012([\134/\134\134]).\052");
lf[101]=C_h_intern(&lf[101],17,"register-feature!");
lf[102]=C_h_intern(&lf[102],5,"files");
C_register_lf2(lf,103,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_762,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_irregex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1669 in k1662 in k1656 in loop in create-temporary-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1671,2,t0,t1);}
t2=C_mkdir(t1);
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1688,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k1582 in k1576 in k1569 in tempdir in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t2=lf[54];
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* create-temporary-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_1589r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1589r(t0,t1,t2);}}

static void C_ccall f_1589r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?lf[60]:C_i_car(t2));
t5=t4;
t6=C_i_check_string_2(t5,lf[59]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1601,a[2]=t8,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li42),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1601(t10,t1);}

/* k805 in file-copy in k766 in k763 in k760 */
static void C_ccall f_807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_867,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm:80: file-exists? */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1690 in loop in create-temporary-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1692,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1700,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:336: number->string */
C_number_to_string(4,0,t4,((C_word*)t0)[4],C_fix(16));}

/* k1694 in k1690 in loop in create-temporary-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:332: make-pathname */
t2=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k1371 in decompose-pathname in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1383,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1395,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* files.scm:246: irregex-match-substring */
t5=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(1));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm:249: irregex-search */
t4=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* addpart in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static C_word C_fcall f_1714(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_overflow_check;
if(C_truep(C_i_string_equal_p(lf[74],t1))){
t3=t2;
return(t3);}
else{
t3=t1;
if(C_truep(C_u_i_string_equal_p(lf[75],t3))){
t4=C_i_nullp(t2);
if(C_truep(t4)){
return((C_truep(t4)?C_a_i_cons(&a,2,t1,t2):C_i_cdr(t2)));}
else{
t5=C_i_car(t2);
t6=C_i_string_equal_p(lf[76],t5);
return((C_truep(t6)?C_a_i_cons(&a,2,t1,t2):C_i_cdr(t2)));}}
else{
return(C_a_i_cons(&a,2,t1,t2));}}}

/* for-each-loop466 in k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_fcall f_1874(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1874,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1884,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* files.scm:382: g467 */
t5=((C_word*)t0)[3];
f_1819(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1702 in k1698 in k1690 in loop in create-temporary-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:334: string-append */
t2=*((C_word*)lf[31]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[70],t1);}

/* k1698 in k1690 in loop in create-temporary-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1700,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_fudge(C_fix(33));
/* files.scm:338: ##sys#number->string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[63]+1)))(3,*((C_word*)lf[63]+1),t3,t4);}

/* decompose-pathname in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1357,3,t0,t1,t2);}
t3=C_i_check_string_2(t2,lf[42]);
t4=C_block_size(t2);
t5=C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* files.scm:242: values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1373,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* files.scm:243: irregex-search */
t7=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],t2);}}

/* k1381 in k1371 in decompose-pathname in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1383,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1387,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* files.scm:247: irregex-match-substring */
t4=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(2));}

/* k1385 in k1381 in k1371 in decompose-pathname in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1387,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* files.scm:248: irregex-match-substring */
t4=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_fix(4));}

/* strip-pds in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_fcall f_1336(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1336,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1343,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm:235: chop-pds */
f_1062(t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1335,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp);
t4=C_mutate2((C_word*)lf[42]+1 /* (set! decompose-pathname ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1357,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp));
t5=C_mutate2((C_word*)lf[45]+1 /* (set! pathname-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1429,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[46]+1 /* (set! pathname-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1444,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[47]+1 /* (set! pathname-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1459,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[48]+1 /* (set! pathname-strip-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1474,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[49]+1 /* (set! pathname-strip-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1492,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[50]+1 /* (set! pathname-replace-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1510,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[51]+1 /* (set! pathname-replace-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1528,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[52]+1 /* (set! pathname-replace-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1546,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[53];
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1564,a[2]=t14,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t17=C_mutate2((C_word*)lf[59]+1 /* (set! create-temporary-file ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1589,a[2]=t15,a[3]=t16,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp));
t18=C_mutate2((C_word*)lf[64]+1 /* (set! create-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1648,a[2]=t15,a[3]=t16,a[4]=((C_word)li45),tmp=(C_word)a,a+=5,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* files.scm:353: build-platform */
t20=*((C_word*)lf[93]+1);
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,t19);}

/* k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1332,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1335,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* files.scm:231: irregex */
t4=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[95]);}

/* _make-pathname in k1045 in k766 in k763 in k760 */
static void C_fcall f_1201(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1201,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?t5:lf[34]);
t7=t6;
t8=(C_truep(t4)?t4:lf[35]);
t9=t8;
t10=C_i_check_string_2(t3,t2);
t11=C_i_check_string_2(t9,t2);
t12=C_i_check_string_2(t7,t2);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1224,a[2]=t1,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1249,a[2]=t9,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t15=C_block_size(t3);
if(C_truep(C_fixnum_greater_or_equal_p(t15,C_fix(1)))){
t16=C_block_size(t9);
if(C_truep(C_fixnum_greater_or_equal_p(t16,C_fix(1)))){
t17=C_subchar(t9,C_fix(0));
t18=t14;
f_1249(t18,C_u_i_memq(t17,lf[38]));}
else{
t17=t14;
f_1249(t17,C_SCHEME_FALSE);}}
else{
t16=t14;
f_1249(t16,C_SCHEME_FALSE);}}

/* k1314 in k1311 in make-absolute-pathname in k1045 in k766 in k763 in k760 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:219: _make-pathname */
f_1201(((C_word*)t0)[3],lf[39],t1,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* root-directory in k2190 in k766 in k763 in k760 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2203,3,t0,t1,t2);}
if(C_truep(t2)){
/* files.scm:153: irregex-match-substring */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_fix(1));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* root-origin in k2190 in k766 in k763 in k760 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2200,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k1311 in make-absolute-pathname in k1045 in k766 in k763 in k760 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* files.scm:222: absolute-pathname? */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* canonicalize-dirs in k1045 in k766 in k763 in k760 */
static void C_fcall f_1170(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1170,NULL,3,t0,t1,t2);}
t3=C_i_not(t2);
t4=(C_truep(t3)?t3:C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[33]);}
else{
if(C_truep(C_i_stringp(t2))){
t5=C_a_i_list1(&a,1,t2);
/* files.scm:191: conc-dirs */
f_1119(t1,t5);}
else{
/* files.scm:192: conc-dirs */
f_1119(t1,t2);}}}

/* k1317 in k1311 in make-absolute-pathname in k1045 in k766 in k763 in k760 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* files.scm:219: _make-pathname */
f_1201(((C_word*)t0)[3],lf[39],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
/* files.scm:224: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),((C_word*)t0)[7],lf[41],((C_word*)t0)[4]);}}

/* k1341 in strip-pds in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_block_size(t1);
if(C_truep(C_fixnum_greaterp(t2,C_fix(0)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* files.scm:238: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),C_fix(1));}}

/* k1882 in for-each-loop466 in k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1874(t3,((C_word*)t0)[4],t2);}

/* k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_fcall f_1780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1780,NULL,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=C_a_i_string(&a,1,((C_word*)t0)[6]);
/* files.scm:374: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t2,t3,lf[78]);}
else{
t3=C_a_i_string(&a,1,((C_word*)t0)[6]);
/* files.scm:375: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t2,lf[79],t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* files.scm:379: open-output-string */
t3=*((C_word*)lf[86]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1787 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* files.scm:377: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}
else{
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1247 in _make-pathname in k1045 in k766 in k763 in k760 */
static void C_fcall f_1249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_block_size(((C_word*)t0)[2]);
/* files.scm:205: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1),t2);}
else{
t2=((C_word*)t0)[3];
f_1224(2,t2,((C_word*)t0)[2]);}}

/* k1229 in k1222 in _make-pathname in k1045 in k766 in k763 in k760 */
static void C_fcall f_1231(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* files.scm:200: string-append */
t2=*((C_word*)lf[31]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[36],((C_word*)t0)[5]);}
else{
/* files.scm:200: string-append */
t2=*((C_word*)lf[31]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[37],((C_word*)t0)[5]);}}

/* k1973 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_fcall f_1975(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1975,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* files.scm:407: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),t2,((C_word*)t0)[6],C_fix(0),t3);}
else{
t2=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* files.scm:409: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1770(t3,((C_word*)t0)[5],t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[8])[1]);}}

/* k1977 in k1973 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* files.scm:408: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1770(t5,((C_word*)t0)[5],t3,t4,C_SCHEME_END_OF_LIST);}

/* k1682 in k1669 in k1662 in k1656 in loop in create-temporary-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:344: ##sys#signal-hook */
t2=*((C_word*)lf[65]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[66],lf[64],t1,((C_word*)t0)[3]);}

/* k1686 in k1669 in k1662 in k1656 in loop in create-temporary-directory in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:346: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),((C_word*)t0)[2],lf[67],t1);}

/* k991 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
f_942(2,t2,((C_word*)t0)[2]);}
else{
/* files.scm:115: ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[17],lf[18],((C_word*)t0)[4]);}}
else{
t2=((C_word*)t0)[3];
f_942(2,t2,C_SCHEME_FALSE);}}

/* k1389 in k1385 in k1381 in k1371 in decompose-pathname in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:245: values */
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k1396 in k1371 in decompose-pathname in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1398,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1408,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1416,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* files.scm:252: irregex-match-substring */
t5=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* files.scm:255: strip-pds */
f_1336(t3,((C_word*)t0)[4]);}}

/* k1393 in k1371 in decompose-pathname in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:246: strip-pds */
f_1336(((C_word*)t0)[3],t1);}

/* loop in k956 in k949 in k946 in k943 in k940 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_fcall f_960(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_960,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_970,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* files.scm:126: close-input-port */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_979,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* files.scm:131: write-string */
t6=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[7],t2,((C_word*)t0)[3]);}}

/* k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_993,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* files.scm:113: file-exists? */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1002,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* files.scm:111: directory-exists? */
t4=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2046 in directory-null? in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2050,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2050(t1));}

/* k1292 in make-pathname in k1045 in k766 in k763 in k760 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:215: _make-pathname */
f_1201(((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k984 in k977 in loop in k956 in k949 in k946 in k943 in k940 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],((C_word*)t0)[3]);
/* files.scm:132: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_960(t3,((C_word*)t0)[5],t1,t2);}

/* directory-null? in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2040,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2048,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_listp(t2))){
t4=t3;
f_2048(2,t4,t2);}
else{
t4=t2;
t5=C_i_check_string_2(t4,lf[87]);
/* files.scm:418: string-split */
t6=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,lf[91],C_SCHEME_TRUE);}}

/* k956 in k949 in k946 in k943 in k940 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_958,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li3),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_960(t5,((C_word*)t0)[7],t1,C_fix(0));}

/* k1821 in g467 in k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:385: display */
t2=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k949 in k946 in k943 in k940 in k937 in k934 in file-move in k766 in k763 in k760 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* files.scm:122: read-string! */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}

/* pathname-extension in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1459,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1465,a[2]=t2,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1471,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
/* files.scm:268: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* g467 in k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_fcall f_1819(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1819,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1823,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm:384: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[81]+1)))(4,*((C_word*)lf[81]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1455 in pathname-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1456,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=C_i_car(t2);
/* files.scm:381: display */
t5=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1449 in pathname-file in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1450,2,t0,t1);}
/* files.scm:264: decompose-pathname */
t2=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k1816 in k1813 in k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t3=C_u_i_cdr(((C_word*)t0)[4]);
t4=C_i_check_list_2(t3,lf[82]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1833,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1874,a[2]=t7,a[3]=t2,a[4]=((C_word)li48),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1874(t9,t5,t3);}

/* k1810 in k1778 in loop in normalize-pathname in k2160 in k1333 in k1330 in k1045 in k766 in k763 in k760 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1812,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1815,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* files.scm:380: ##sys#fast-reverse */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[85]+1)))(3,*((C_word*)lf[85]+1),t3,((C_word*)((C_word*)t0)[8])[1]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[165] = {
{"f_1444:files_2escm",(void*)f_1444},
{"f_1441:files_2escm",(void*)f_1441},
{"f_2050:files_2escm",(void*)f_2050},
{"f_1842:files_2escm",(void*)f_1842},
{"f_979:files_2escm",(void*)f_979},
{"f_976:files_2escm",(void*)f_976},
{"f_1002:files_2escm",(void*)f_1002},
{"f_973:files_2escm",(void*)f_973},
{"f_970:files_2escm",(void*)f_970},
{"f_1833:files_2escm",(void*)f_1833},
{"f_948:files_2escm",(void*)f_948},
{"f_1839:files_2escm",(void*)f_1839},
{"f_1836:files_2escm",(void*)f_1836},
{"f_1471:files_2escm",(void*)f_1471},
{"f_1474:files_2escm",(void*)f_1474},
{"f_2080:files_2escm",(void*)f_2080},
{"f_942:files_2escm",(void*)f_942},
{"f_945:files_2escm",(void*)f_945},
{"f_1862:files_2escm",(void*)f_1862},
{"f_1465:files_2escm",(void*)f_1465},
{"f_1605:files_2escm",(void*)f_1605},
{"f_1601:files_2escm",(void*)f_1601},
{"f_911:files_2escm",(void*)f_911},
{"f_1858:files_2escm",(void*)f_1858},
{"f_1851:files_2escm",(void*)f_1851},
{"f_1412:files_2escm",(void*)f_1412},
{"f_1416:files_2escm",(void*)f_1416},
{"f_762:files_2escm",(void*)f_762},
{"f_1408:files_2escm",(void*)f_1408},
{"f_770:files_2escm",(void*)f_770},
{"f_1910:files_2escm",(void*)f_1910},
{"f_765:files_2escm",(void*)f_765},
{"f_768:files_2escm",(void*)f_768},
{"f_1435:files_2escm",(void*)f_1435},
{"f_782:files_2escm",(void*)f_782},
{"f_1923:files_2escm",(void*)f_1923},
{"f_777:files_2escm",(void*)f_777},
{"f_1423:files_2escm",(void*)f_1423},
{"f_1429:files_2escm",(void*)f_1429},
{"f_861:files_2escm",(void*)f_861},
{"f_1578:files_2escm",(void*)f_1578},
{"f_1571:files_2escm",(void*)f_1571},
{"f_867:files_2escm",(void*)f_867},
{"f_1062:files_2escm",(void*)f_1062},
{"f_1060:files_2escm",(void*)f_1060},
{"f_1564:files_2escm",(void*)f_1564},
{"f_1540:files_2escm",(void*)f_1540},
{"f_841:files_2escm",(void*)f_841},
{"f_1558:files_2escm",(void*)f_1558},
{"f_844:files_2escm",(void*)f_844},
{"f_1552:files_2escm",(void*)f_1552},
{"f_847:files_2escm",(void*)f_847},
{"f_1082:files_2escm",(void*)f_1082},
{"f_854:files_2escm",(void*)f_854},
{"f_1546:files_2escm",(void*)f_1546},
{"f_822:files_2escm",(void*)f_822},
{"f_1959:files_2escm",(void*)f_1959},
{"f_2127:files_2escm",(void*)f_2127},
{"f_1534:files_2escm",(void*)f_1534},
{"f_829:files_2escm",(void*)f_829},
{"f_1510:files_2escm",(void*)f_1510},
{"f_1492:files_2escm",(void*)f_1492},
{"f_1498:files_2escm",(void*)f_1498},
{"f_831:files_2escm",(void*)f_831},
{"f_2119:files_2escm",(void*)f_2119},
{"f_1522:files_2escm",(void*)f_1522},
{"f_1528:files_2escm",(void*)f_1528},
{"f_2144:files_2escm",(void*)f_2144},
{"f_1480:files_2escm",(void*)f_1480},
{"f_1486:files_2escm",(void*)f_1486},
{"f_2140:files_2escm",(void*)f_2140},
{"f_1160:files_2escm",(void*)f_1160},
{"f_1516:files_2escm",(void*)f_1516},
{"f_1624:files_2escm",(void*)f_1624},
{"f_1628:files_2escm",(void*)f_1628},
{"f_1049:files_2escm",(void*)f_1049},
{"f_2133:files_2escm",(void*)f_2133},
{"f_1047:files_2escm",(void*)f_1047},
{"f_2130:files_2escm",(void*)f_2130},
{"f_1156:files_2escm",(void*)f_1156},
{"f_819:files_2escm",(void*)f_819},
{"f_1504:files_2escm",(void*)f_1504},
{"f_816:files_2escm",(void*)f_816},
{"f_813:files_2escm",(void*)f_813},
{"f_1619:files_2escm",(void*)f_1619},
{"f_810:files_2escm",(void*)f_810},
{"f_1611:files_2escm",(void*)f_1611},
{"f_2165:files_2escm",(void*)f_2165},
{"f_2162:files_2escm",(void*)f_2162},
{"f_2167:files_2escm",(void*)f_2167},
{"f_1648:files_2escm",(void*)f_1648},
{"f_1770:files_2escm",(void*)f_1770},
{"f_1632:files_2escm",(void*)f_1632},
{"f_1636:files_2escm",(void*)f_1636},
{"f_2182:files_2escm",(void*)f_2182},
{"f_1128:files_2escm",(void*)f_1128},
{"f_1302:files_2escm",(void*)f_1302},
{"f_1664:files_2escm",(void*)f_1664},
{"f_1752:files_2escm",(void*)f_1752},
{"f_2173:files_2escm",(void*)f_2173},
{"f_1283:files_2escm",(void*)f_1283},
{"f_1658:files_2escm",(void*)f_1658},
{"f_1654:files_2escm",(void*)f_1654},
{"f_1075:files_2escm",(void*)f_1075},
{"f_1119:files_2escm",(void*)f_1119},
{"f_2194:files_2escm",(void*)f_2194},
{"f_2192:files_2escm",(void*)f_2192},
{"f_1224:files_2escm",(void*)f_1224},
{"toplevel:files_2escm",(void*)C_files_toplevel},
{"f_1671:files_2escm",(void*)f_1671},
{"f_1584:files_2escm",(void*)f_1584},
{"f_1589:files_2escm",(void*)f_1589},
{"f_807:files_2escm",(void*)f_807},
{"f_1692:files_2escm",(void*)f_1692},
{"f_1696:files_2escm",(void*)f_1696},
{"f_1373:files_2escm",(void*)f_1373},
{"f_1714:files_2escm",(void*)f_1714},
{"f_1874:files_2escm",(void*)f_1874},
{"f_1704:files_2escm",(void*)f_1704},
{"f_1700:files_2escm",(void*)f_1700},
{"f_1357:files_2escm",(void*)f_1357},
{"f_1383:files_2escm",(void*)f_1383},
{"f_1387:files_2escm",(void*)f_1387},
{"f_1336:files_2escm",(void*)f_1336},
{"f_1335:files_2escm",(void*)f_1335},
{"f_1332:files_2escm",(void*)f_1332},
{"f_1201:files_2escm",(void*)f_1201},
{"f_1316:files_2escm",(void*)f_1316},
{"f_2203:files_2escm",(void*)f_2203},
{"f_2200:files_2escm",(void*)f_2200},
{"f_1313:files_2escm",(void*)f_1313},
{"f_1170:files_2escm",(void*)f_1170},
{"f_1319:files_2escm",(void*)f_1319},
{"f_1343:files_2escm",(void*)f_1343},
{"f_1884:files_2escm",(void*)f_1884},
{"f_1780:files_2escm",(void*)f_1780},
{"f_1789:files_2escm",(void*)f_1789},
{"f_1249:files_2escm",(void*)f_1249},
{"f_1231:files_2escm",(void*)f_1231},
{"f_1975:files_2escm",(void*)f_1975},
{"f_1979:files_2escm",(void*)f_1979},
{"f_1684:files_2escm",(void*)f_1684},
{"f_1688:files_2escm",(void*)f_1688},
{"f_993:files_2escm",(void*)f_993},
{"f_1391:files_2escm",(void*)f_1391},
{"f_1398:files_2escm",(void*)f_1398},
{"f_1395:files_2escm",(void*)f_1395},
{"f_960:files_2escm",(void*)f_960},
{"f_939:files_2escm",(void*)f_939},
{"f_936:files_2escm",(void*)f_936},
{"f_2048:files_2escm",(void*)f_2048},
{"f_1294:files_2escm",(void*)f_1294},
{"f_986:files_2escm",(void*)f_986},
{"f_2040:files_2escm",(void*)f_2040},
{"f_958:files_2escm",(void*)f_958},
{"f_1823:files_2escm",(void*)f_1823},
{"f_951:files_2escm",(void*)f_951},
{"f_1459:files_2escm",(void*)f_1459},
{"f_1819:files_2escm",(void*)f_1819},
{"f_1456:files_2escm",(void*)f_1456},
{"f_1815:files_2escm",(void*)f_1815},
{"f_1450:files_2escm",(void*)f_1450},
{"f_1818:files_2escm",(void*)f_1818},
{"f_1812:files_2escm",(void*)f_1812},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  for-each		1
o|eliminated procedure checks: 41 
o|specializations:
o|  1 (string-ref string fixnum)
o|  1 (string=? string string)
o|  1 (car pair)
o|  5 (cdr pair)
o|  1 (zero? fixnum)
o|  3 (memq * list)
o|dropping redundant toplevel assignment: make-pathname 
o|dropping redundant toplevel assignment: make-absolute-pathname 
o|dropping redundant toplevel assignment: create-temporary-file 
o|dropping redundant toplevel assignment: create-temporary-directory 
o|Removed `not' forms: 3 
o|inlining procedure: k772 
o|inlining procedure: k772 
o|inlining procedure: k833 
o|inlining procedure: k833 
o|inlining procedure: k868 
o|inlining procedure: k868 
o|inlining procedure: k962 
o|inlining procedure: k962 
o|inlining procedure: k994 
o|inlining procedure: k994 
o|inlining procedure: k1064 
o|inlining procedure: k1077 
o|inlining procedure: k1077 
o|contracted procedure: "(files.scm:165) g178179" 
o|substituted constant variable: a1109 
o|inlining procedure: k1064 
o|inlining procedure: k1130 
o|inlining procedure: k1130 
o|inlining procedure: k1172 
o|inlining procedure: k1172 
o|inlining procedure: k1226 
o|inlining procedure: k1226 
o|inlining procedure: k1260 
o|contracted procedure: "(files.scm:204) g215216" 
o|substituted constant variable: a1269 
o|inlining procedure: k1260 
o|inlining procedure: k1314 
o|inlining procedure: k1314 
o|inlining procedure: k1338 
o|inlining procedure: k1338 
o|inlining procedure: k1362 
o|inlining procedure: k1362 
o|inlining procedure: k1399 
o|inlining procedure: k1399 
o|inlining procedure: k1566 
o|inlining procedure: k1566 
o|inlining procedure: k1579 
o|inlining procedure: k1579 
o|inlining procedure: k1606 
o|inlining procedure: k1606 
o|inlining procedure: k1659 
o|inlining procedure: k1659 
o|inlining procedure: k1716 
o|inlining procedure: k1716 
o|substituted constant variable: a1725 
o|inlining procedure: k1727 
o|inlining procedure: k1727 
o|inlining procedure: k1772 
o|inlining procedure: k1790 
o|inlining procedure: k1790 
o|inlining procedure: k1843 
o|inlining procedure: k1843 
o|inlining procedure: k1876 
o|inlining procedure: k1876 
o|inlining procedure: k1772 
o|inlining procedure: k1924 
o|inlining procedure: k1924 
o|inlining procedure: k1960 
o|inlining procedure: k1960 
o|inlining procedure: k1970 
o|inlining procedure: k1970 
o|inlining procedure: k2005 
o|inlining procedure: k2005 
o|contracted procedure: "(files.scm:396) g491492" 
o|substituted constant variable: a1917 
o|inlining procedure: k2055 
o|inlining procedure: k2055 
o|contracted procedure: "(files.scm:453) strip-origin-prefix518" 
o|contracted procedure: k2088 
o|inlining procedure: k2085 
o|contracted procedure: k2100 
o|inlining procedure: k2107 
o|inlining procedure: k2107 
o|inlining procedure: k2085 
o|contracted procedure: k2149 
o|substituted constant variable: patt2255 
o|substituted constant variable: patt1254 
o|inlining procedure: k2175 
o|inlining procedure: k2175 
o|inlining procedure: k2184 
o|inlining procedure: k2184 
o|inlining procedure: k2205 
o|inlining procedure: k2205 
o|replaced variables: 246 
o|removed binding forms: 112 
o|substituted constant variable: r7732212 
o|substituted constant variable: r10652224 
o|substituted constant variable: r11312225 
o|substituted constant variable: r11732227 
o|substituted constant variable: r12272229 
o|substituted constant variable: r12272229 
o|substituted constant variable: r12272231 
o|substituted constant variable: r12272231 
o|substituted constant variable: r12612234 
o|substituted constant variable: r13392240 
o|inlining procedure: k1572 
o|inlining procedure: k1572 
o|inlining procedure: k1572 
o|inlining procedure: k1572 
o|inlining procedure: k1843 
o|inlining procedure: k1843 
o|substituted constant variable: r19612271 
o|substituted constant variable: r20062276 
o|converted assignments to bindings: (addpart427) 
o|converted assignments to bindings: (tempdir386) 
o|substituted constant variable: r21762284 
o|substituted constant variable: r21852286 
o|substituted constant variable: r22062288 
o|simplifications: ((let . 2)) 
o|replaced variables: 15 
o|removed binding forms: 244 
o|removed conditional forms: 1 
o|inlining procedure: k874 
o|inlining procedure: k1006 
o|replaced variables: 8 
o|removed binding forms: 39 
o|substituted constant variable: r8752345 
o|substituted constant variable: r10072348 
o|contracted procedure: k1918 
o|simplifications: ((if . 1) (let . 2)) 
o|removed binding forms: 8 
o|removed conditional forms: 2 
o|replaced variables: 2 
o|removed binding forms: 2 
o|removed binding forms: 1 
o|simplifications: ((if . 20) (##core#call . 141)) 
o|  call simplifications:
o|    list?
o|    member
o|    string-ref
o|    pair?
o|    ##sys#slot	2
o|    string	3
o|    string=?	3
o|    cons	3
o|    number->string	2
o|    ##sys#fudge	2
o|    ##sys#call-with-values	8
o|    values	5
o|    fx>	3
o|    char=?	2
o|    not	2
o|    string?
o|    list
o|    ##sys#check-list	2
o|    string-length
o|    eq?	5
o|    fx>=	4
o|    ##sys#size	12
o|    fx<
o|    fx-	2
o|    car	13
o|    null?	20
o|    cdr	5
o|    ##sys#check-string	12
o|    ##sys#check-number	2
o|    integer?	2
o|    >	2
o|    fx=	7
o|    fx+	10
o|contracted procedure: k904 
o|contracted procedure: k784 
o|contracted procedure: k898 
o|contracted procedure: k787 
o|contracted procedure: k892 
o|contracted procedure: k790 
o|contracted procedure: k886 
o|contracted procedure: k793 
o|contracted procedure: k796 
o|contracted procedure: k799 
o|contracted procedure: k802 
o|contracted procedure: k836 
o|contracted procedure: k856 
o|contracted procedure: k880 
o|contracted procedure: k874 
o|substituted constant variable: g2439 
o|contracted procedure: k1036 
o|contracted procedure: k913 
o|contracted procedure: k1030 
o|contracted procedure: k916 
o|contracted procedure: k1024 
o|contracted procedure: k919 
o|contracted procedure: k1018 
o|contracted procedure: k922 
o|contracted procedure: k925 
o|contracted procedure: k928 
o|contracted procedure: k931 
o|contracted procedure: k965 
o|contracted procedure: k988 
o|contracted procedure: k1012 
o|contracted procedure: k1006 
o|substituted constant variable: g2443 
o|contracted procedure: k1051 
o|contracted procedure: k1071 
o|contracted procedure: k1087 
o|contracted procedure: k1100 
o|contracted procedure: k1093 
o|contracted procedure: k1103 
o|contracted procedure: k1115 
o|contracted procedure: k1121 
o|contracted procedure: k1133 
o|contracted procedure: k1136 
o|contracted procedure: k1166 
o|contracted procedure: k1142 
o|contracted procedure: k1175 
o|contracted procedure: k1178 
o|contracted procedure: k1184 
o|contracted procedure: k1191 
o|contracted procedure: k1203 
o|contracted procedure: k1206 
o|contracted procedure: k1209 
o|contracted procedure: k1212 
o|contracted procedure: k1215 
o|contracted procedure: k1244 
o|contracted procedure: k1232 
o|contracted procedure: k1239 
o|contracted procedure: k1254 
o|contracted procedure: k1279 
o|contracted procedure: k1257 
o|contracted procedure: k1275 
o|contracted procedure: k1263 
o|contracted procedure: k1295 
o|contracted procedure: k1285 
o|contracted procedure: k1323 
o|contracted procedure: k1304 
o|contracted procedure: k1354 
o|contracted procedure: k1347 
o|contracted procedure: k1359 
o|contracted procedure: k1425 
o|contracted procedure: k1365 
o|contracted procedure: k1641 
o|contracted procedure: k1591 
o|contracted procedure: k1594 
o|contracted procedure: k1638 
o|contracted procedure: k1675 
o|contracted procedure: k1706 
o|contracted procedure: k2156 
o|contracted procedure: k1710 
o|contracted procedure: k1719 
o|contracted procedure: k1730 
o|inlining procedure: k1733 
o|contracted procedure: k1746 
o|inlining procedure: k1733 
o|contracted procedure: k2024 
o|contracted procedure: k1754 
o|contracted procedure: k2021 
o|contracted procedure: k1757 
o|contracted procedure: k1760 
o|contracted procedure: k1763 
o|contracted procedure: k1775 
o|contracted procedure: k1784 
o|contracted procedure: k1800 
o|contracted procedure: k1807 
o|contracted procedure: k1828 
o|contracted procedure: k1846 
o|contracted procedure: k1864 
o|contracted procedure: k1867 
o|contracted procedure: k1879 
o|contracted procedure: k1889 
o|contracted procedure: k1893 
o|contracted procedure: k1897 
o|contracted procedure: k1900 
o|contracted procedure: k2018 
o|contracted procedure: k1927 
o|contracted procedure: k1934 
o|contracted procedure: k1938 
o|contracted procedure: k1945 
o|contracted procedure: k1949 
o|contracted procedure: k1964 
o|contracted procedure: k1960 
o|contracted procedure: k1984 
o|contracted procedure: k1988 
o|contracted procedure: k1992 
o|contracted procedure: k1999 
o|contracted procedure: k2002 
o|contracted procedure: k2008 
o|contracted procedure: k2033 
o|contracted procedure: k2052 
o|contracted procedure: k2070 
o|contracted procedure: k2061 
o|contracted procedure: k2073 
o|contracted procedure: k2153 
o|contracted procedure: k2146 
o|contracted procedure: k2091 
o|contracted procedure: k2094 
o|contracted procedure: k2104 
o|contracted procedure: k2121 
o|contracted procedure: k2110 
o|simplifications: ((if . 1) (let . 22)) 
o|replaced variables: 2 
o|removed binding forms: 124 
o|inlining procedure: "(files.scm:424) split-directory" 
o|inlining procedure: "(files.scm:450) split-directory" 
o|replaced variables: 51 
o|removed binding forms: 5 
o|removed side-effect free assignment to unused variable: split-directory 
o|substituted constant variable: loc5032498 
o|substituted constant variable: keep?5052500 
o|substituted constant variable: loc5032503 
o|substituted constant variable: keep?5052505 
o|replaced variables: 2 
o|removed binding forms: 22 
o|removed binding forms: 7 
o|direct leaf routine/allocation: addpart427 9 
o|direct leaf routine/allocation: loop509 0 
o|contracted procedure: "(files.scm:371) k1904" 
o|contracted procedure: "(files.scm:403) k1953" 
o|converted assignments to bindings: (loop509) 
o|simplifications: ((let . 1)) 
o|removed binding forms: 2 
o|customizable procedures: (k1045 k1973 k1921 loop453 k1778 g467474 for-each-loop466478 k1849 loop418 tempdir386 loop412 strip-pds258 canonicalize-dirs185 _make-pathname186 k1247 k1229 conc-dirs184 chop-pds loop188 k1080 lp171 loop133 loop93) 
o|calls to known targets: 64 
o|identified direct recursive calls: f_1128 1 
o|identified direct recursive calls: f_2050 1 
o|fast box initializations: 11 
o|fast global references: 6 
o|fast global assignments: 10 
o|dropping unused closure argument: f_2050 
o|dropping unused closure argument: f_1062 
o|dropping unused closure argument: f_1119 
o|dropping unused closure argument: f_1714 
o|dropping unused closure argument: f_1336 
o|dropping unused closure argument: f_1201 
*/
/* end of file */
