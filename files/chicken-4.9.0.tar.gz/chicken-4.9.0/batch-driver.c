/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:39
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: batch-driver.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[409];
static double C_possibly_force_alignment;


C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_fcall f_2463(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_fcall f_2457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_fcall f_3804(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4138)
static void C_ccall f_4138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_fcall f_4186(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2314)
static void C_fcall f_2314(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4163)
static void C_fcall f_4163(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_fcall f_2339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_fcall f_2367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5022)
static void C_ccall f5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_fcall f_3476(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_fcall f_1737(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_fcall f_3124(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_fcall f_3948(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5525)
static void C_ccall f5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_fcall f_1710(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5559)
static void C_ccall f5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5553)
static void C_ccall f5553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_fcall f_1692(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_fcall f_3633(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_fcall f_1759(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1757)
static void C_ccall f_1757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_fcall f_2076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_fcall f_2073(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3983)
static void C_fcall f_3983(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_fcall f_2007(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2009)
static void C_fcall f_2009(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_fcall f_2565(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_fcall f_4294(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4517)
static void C_fcall f_4517(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2542)
static void C_fcall f_2542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4233)
static void C_fcall f_4233(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_fcall f_3709(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_fcall f_1936(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3254)
static void C_ccall f_3254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_fcall f_1957(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_fcall f_1967(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_fcall f_2248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_fcall f_4578(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_fcall f_1928(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1922)
static void C_fcall f_1922(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1611)
static void C_fcall f_1611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_fcall f_2037(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_fcall f_2032(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3014)
static void C_ccall f_3014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_fcall f_1666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_fcall f_3412(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5451)
static void C_ccall f5451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5443)
static void C_ccall f5443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5431)
static void C_ccall f5431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_fcall f_2200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_fcall f_3744(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5425)
static void C_ccall f5425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2205)
static void C_fcall f_2205(C_word t0,C_word t1) C_noret;
C_noret_decl(f5413)
static void C_ccall f5413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5419)
static void C_ccall f5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5407)
static void C_ccall f5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_fcall f_2163(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_fcall f_2160(C_word t0,C_word t1) C_noret;
C_noret_decl(f5463)
static void C_ccall f5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_fcall f_4006(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2169)
static void C_fcall f_2169(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_fcall f_2166(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_fcall f_2151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_fcall f_2154(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2157)
static void C_fcall f_2157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2184)
static void C_fcall f_2184(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_fcall f_2181(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_fcall f_2187(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_fcall f_2172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_fcall f_2175(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_fcall f_2178(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_fcall f_3546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_fcall f_2190(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_fcall f_2195(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3091)
static void C_fcall f_3091(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5481)
static void C_ccall f5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5487)
static void C_ccall f5487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_fcall f_4651(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_fcall f_3037(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3678)
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_fcall f_3511(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5507)
static void C_ccall f5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5501)
static void C_ccall f5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5535)
static void C_ccall f5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_fcall f_2236(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_fcall f_2239(C_word t0,C_word t1) C_noret;
C_noret_decl(f5519)
static void C_ccall f5519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_fcall f_4039(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5513)
static void C_ccall f5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_fcall f_2245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_fcall f_2242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_fcall f_1832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_fcall f_1809(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5571)
static void C_ccall f5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5577)
static void C_ccall f5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_fcall f_4692(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_fcall f_1786(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5565)
static void C_ccall f5565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_fcall f_3191(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_fcall f_2120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_fcall f_2127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_fcall f_2145(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_fcall f_3312(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2148)
static void C_fcall f_2148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_fcall f_2133(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_fcall f_2962(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_fcall f_2448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_fcall f_3371(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_ccall f_4119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_fcall f_2985(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_2463)
static void C_fcall trf_2463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2463(t0,t1);}

C_noret_decl(trf_2457)
static void C_fcall trf_2457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2457(t0,t1);}

C_noret_decl(trf_3804)
static void C_fcall trf_3804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3804(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3804(t0,t1);}

C_noret_decl(trf_4186)
static void C_fcall trf_4186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4186(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4186(t0,t1,t2);}

C_noret_decl(trf_2314)
static void C_fcall trf_2314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2314(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2314(t0,t1);}

C_noret_decl(trf_4163)
static void C_fcall trf_4163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4163(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4163(t0,t1,t2);}

C_noret_decl(trf_2339)
static void C_fcall trf_2339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2339(t0,t1);}

C_noret_decl(trf_2367)
static void C_fcall trf_2367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2367(t0,t1);}

C_noret_decl(trf_3476)
static void C_fcall trf_3476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3476(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3476(t0,t1,t2);}

C_noret_decl(trf_1737)
static void C_fcall trf_1737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1737(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1737(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3124)
static void C_fcall trf_3124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3124(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3124(t0,t1,t2);}

C_noret_decl(trf_3948)
static void C_fcall trf_3948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3948(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3948(t0,t1,t2);}

C_noret_decl(trf_1710)
static void C_fcall trf_1710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1710(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1710(t0,t1,t2);}

C_noret_decl(trf_1692)
static void C_fcall trf_1692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1692(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1692(t0,t1);}

C_noret_decl(trf_3633)
static void C_fcall trf_3633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3633(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3633(t0,t1,t2);}

C_noret_decl(trf_1759)
static void C_fcall trf_1759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1759(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1759(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2076)
static void C_fcall trf_2076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2076(t0,t1);}

C_noret_decl(trf_2073)
static void C_fcall trf_2073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2073(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2073(t0,t1);}

C_noret_decl(trf_3983)
static void C_fcall trf_3983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3983(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3983(t0,t1,t2);}

C_noret_decl(trf_2007)
static void C_fcall trf_2007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2007(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2007(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2009)
static void C_fcall trf_2009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2009(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2009(t0,t1,t2,t3);}

C_noret_decl(trf_2565)
static void C_fcall trf_2565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2565(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2565(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4294)
static void C_fcall trf_4294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4294(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4294(t0,t1,t2);}

C_noret_decl(trf_4517)
static void C_fcall trf_4517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4517(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4517(t0,t1,t2);}

C_noret_decl(trf_2542)
static void C_fcall trf_2542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2542(t0,t1);}

C_noret_decl(trf_4233)
static void C_fcall trf_4233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4233(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4233(t0,t1,t2);}

C_noret_decl(trf_3709)
static void C_fcall trf_3709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3709(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3709(t0,t1,t2);}

C_noret_decl(trf_1936)
static void C_fcall trf_1936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1936(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1936(t0,t1,t2);}

C_noret_decl(trf_1957)
static void C_fcall trf_1957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1957(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1957(t0,t1);}

C_noret_decl(trf_1967)
static void C_fcall trf_1967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1967(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1967(t0,t1,t2);}

C_noret_decl(trf_2248)
static void C_fcall trf_2248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2248(t0,t1);}

C_noret_decl(trf_4578)
static void C_fcall trf_4578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4578(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4578(t0,t1,t2);}

C_noret_decl(trf_1928)
static void C_fcall trf_1928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1928(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1928(t0,t1,t2);}

C_noret_decl(trf_1922)
static void C_fcall trf_1922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1922(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1922(t0,t1,t2);}

C_noret_decl(trf_1611)
static void C_fcall trf_1611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1611(t0,t1);}

C_noret_decl(trf_2037)
static void C_fcall trf_2037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2037(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2037(t0,t1);}

C_noret_decl(trf_2032)
static void C_fcall trf_2032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2032(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2032(t0,t1,t2);}

C_noret_decl(trf_1666)
static void C_fcall trf_1666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1666(t0,t1);}

C_noret_decl(trf_3412)
static void C_fcall trf_3412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3412(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3412(t0,t1,t2);}

C_noret_decl(trf_2200)
static void C_fcall trf_2200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2200(t0,t1);}

C_noret_decl(trf_3744)
static void C_fcall trf_3744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3744(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3744(t0,t1,t2);}

C_noret_decl(trf_2205)
static void C_fcall trf_2205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2205(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2205(t0,t1);}

C_noret_decl(trf_2163)
static void C_fcall trf_2163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2163(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2163(t0,t1);}

C_noret_decl(trf_2160)
static void C_fcall trf_2160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2160(t0,t1);}

C_noret_decl(trf_4006)
static void C_fcall trf_4006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4006(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4006(t0,t1,t2);}

C_noret_decl(trf_2169)
static void C_fcall trf_2169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2169(t0,t1);}

C_noret_decl(trf_2166)
static void C_fcall trf_2166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2166(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2166(t0,t1);}

C_noret_decl(trf_2151)
static void C_fcall trf_2151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2151(t0,t1);}

C_noret_decl(trf_2154)
static void C_fcall trf_2154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2154(t0,t1);}

C_noret_decl(trf_2157)
static void C_fcall trf_2157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2157(t0,t1);}

C_noret_decl(trf_2184)
static void C_fcall trf_2184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2184(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2184(t0,t1);}

C_noret_decl(trf_2181)
static void C_fcall trf_2181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2181(t0,t1);}

C_noret_decl(trf_2187)
static void C_fcall trf_2187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2187(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2187(t0,t1);}

C_noret_decl(trf_2172)
static void C_fcall trf_2172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2172(t0,t1);}

C_noret_decl(trf_2175)
static void C_fcall trf_2175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2175(t0,t1);}

C_noret_decl(trf_2178)
static void C_fcall trf_2178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2178(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2178(t0,t1);}

C_noret_decl(trf_3546)
static void C_fcall trf_3546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3546(t0,t1,t2);}

C_noret_decl(trf_2190)
static void C_fcall trf_2190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2190(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2190(t0,t1);}

C_noret_decl(trf_2195)
static void C_fcall trf_2195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2195(t0,t1);}

C_noret_decl(trf_3091)
static void C_fcall trf_3091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3091(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3091(t0,t1,t2);}

C_noret_decl(trf_4651)
static void C_fcall trf_4651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4651(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4651(t0,t1,t2);}

C_noret_decl(trf_3037)
static void C_fcall trf_3037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3037(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3037(t0,t1,t2);}

C_noret_decl(trf_3678)
static void C_fcall trf_3678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3678(t0,t1,t2);}

C_noret_decl(trf_3511)
static void C_fcall trf_3511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3511(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3511(t0,t1,t2);}

C_noret_decl(trf_2236)
static void C_fcall trf_2236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2236(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2236(t0,t1);}

C_noret_decl(trf_2239)
static void C_fcall trf_2239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2239(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2239(t0,t1);}

C_noret_decl(trf_4039)
static void C_fcall trf_4039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4039(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4039(t0,t1,t2);}

C_noret_decl(trf_2245)
static void C_fcall trf_2245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2245(t0,t1);}

C_noret_decl(trf_2242)
static void C_fcall trf_2242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2242(t0,t1);}

C_noret_decl(trf_1832)
static void C_fcall trf_1832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1832(t0,t1);}

C_noret_decl(trf_1809)
static void C_fcall trf_1809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1809(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1809(t0,t1,t2);}

C_noret_decl(trf_4692)
static void C_fcall trf_4692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4692(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4692(t0,t1,t2);}

C_noret_decl(trf_1786)
static void C_fcall trf_1786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1786(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1786(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3191)
static void C_fcall trf_3191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3191(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3191(t0,t1,t2);}

C_noret_decl(trf_2120)
static void C_fcall trf_2120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2120(t0,t1);}

C_noret_decl(trf_2127)
static void C_fcall trf_2127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2127(t0,t1);}

C_noret_decl(trf_2145)
static void C_fcall trf_2145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2145(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2145(t0,t1);}

C_noret_decl(trf_3312)
static void C_fcall trf_3312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3312(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3312(t0,t1,t2);}

C_noret_decl(trf_2148)
static void C_fcall trf_2148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2148(t0,t1);}

C_noret_decl(trf_2133)
static void C_fcall trf_2133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2133(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2133(t0,t1);}

C_noret_decl(trf_2962)
static void C_fcall trf_2962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2962(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2962(t0,t1,t2);}

C_noret_decl(trf_2448)
static void C_fcall trf_2448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2448(t0,t1);}

C_noret_decl(trf_3371)
static void C_fcall trf_3371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3371(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3371(t0,t1);}

C_noret_decl(trf_2985)
static void C_fcall trf_2985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2985(t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in ... */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=t2,tmp=(C_word)a,a+=28,tmp);
/* batch-driver.scm:401: collect-options */
t4=((C_word*)((C_word*)t0)[18])[1];
f_1922(t4,t3,lf[255]);}

/* k3045 in for-each-loop1027 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in ... */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3037(t3,((C_word*)t0)[4],t2);}

/* k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in ... */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2433,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=t2,tmp=(C_word)a,a+=29,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3833,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[18],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:403: collect-options */
t5=((C_word*)((C_word*)t0)[18])[1];
f_1922(t5,t4,lf[254]);}

/* k4452 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in ... */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[125] /* ##sys#warnings-enabled */,0,C_SCHEME_FALSE);
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
f_2166(t4,t3);}

/* k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in ... */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2469,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_2472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm:449: gensym */
t4=*((C_word*)lf[233]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2970 in for-each-loop1071 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in ... */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2962(t3,((C_word*)t0)[4],t2);}

/* k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in ... */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_2463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[26])){
t3=C_a_i_list(&a,3,lf[234],lf[235],lf[236]);
t4=C_a_i_cons(&a,2,t3,t1);
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_cons(&a,2,lf[237],t5);
t7=C_a_i_cons(&a,2,lf[238],t6);
t8=t2;
f_2463(t8,C_a_i_list(&a,1,t7));}
else{
t3=t2;
f_2463(t3,t1);}}

/* k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in ... */
static void C_fcall f_2463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2463,NULL,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[55]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3546,a[2]=((C_word*)t0)[23],a[3]=t5,a[4]=((C_word*)t0)[24],a[5]=((C_word*)t0)[25],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3546(t7,t3,t1);}

/* k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in ... */
static void C_fcall f_2457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2457,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[86]+1);
t7=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=t5,a[24]=t3,a[25]=t6,a[26]=((C_word*)t0)[23],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:443: append */
t8=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)((C_word*)t0)[24])[1],((C_word*)((C_word*)t0)[25])[1]);}

/* a3825 in k3781 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in ... */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3826,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[248]+1));
t3=C_mutate2((C_word*)lf[248]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in ... */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:436: begin-time */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1957(t3,t2);}

/* k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in ... */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[26])[1]))){
t3=t2;
f_2457(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[25],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:439: append */
t4=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[239]+1),((C_word*)((C_word*)t0)[26])[1]);}}

/* k2993 in for-each-loop1050 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in ... */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2985(t3,((C_word*)t0)[4],t2);}

/* k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4731,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[11],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[2];
t7=C_u_i_memq(lf[12],t6);
t8=((C_word*)t0)[2];
t9=C_u_i_memq(lf[13],t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t9)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4692,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:62: g72 */
t12=t11;
f_4692(t12,t10,t9);}
else{
t11=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[401],t11))){
t12=t10;
f_1655(2,t12,C_SCHEME_FALSE);}
else{
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4720,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[5])){
/* batch-driver.scm:69: pathname-file */
t13=*((C_word*)lf[403]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t0)[5]);}
else{
/* batch-driver.scm:69: make-pathname */
t13=*((C_word*)lf[169]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t10,C_SCHEME_FALSE,lf[404],lf[402]);}}}}

/* k4404 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in ... */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=C_a_i_string_to_number(&a,2,t1,C_fix(10));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t2)){
t4=C_mutate2((C_word*)lf[348]+1 /* (set! ##compiler#inline-max-size ...) */,t2);
t5=((C_word*)t0)[2];
f_2205(t5,t4);}
else{
/* batch-driver.scm:247: quit */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[349],t1);}}

/* loop in a3797 in k3781 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in ... */
static void C_fcall f_3804(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3804,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3808,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:422: read/source-info */
t3=*((C_word*)lf[250]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3806 in loop in a3797 in k3781 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in ... */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3808,2,t0,t1);}
if(C_truep(C_eofp(t1))){
/* batch-driver.scm:424: close-checked-input-file */
t2=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t2);
/* batch-driver.scm:427: loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3804(t4,((C_word*)t0)[2]);}}

/* k3831 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in ... */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3833,2,t0,t1);}
t2=t1;
t3=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3841,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:405: collect-options */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1922(t6,t5,lf[253]);}

/* k4136 in for-each-loop468 in k4117 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in ... */
static void C_ccall f_4138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],((C_word*)t0)[3],lf[314],C_SCHEME_TRUE);}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],((C_word*)t0)[3],lf[314],t3);}}

/* k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in ... */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2322,2,t0,t1);}
t2=C_mutate2((C_word*)lf[71]+1 /* (set! ##compiler#target-stack-size ...) */,t1);
t3=((C_word*)t0)[2];
t4=C_u_i_memq(lf[72],t3);
t5=C_i_not(t4);
t6=C_mutate2((C_word*)lf[73]+1 /* (set! ##compiler#emit-trace-info ...) */,t5);
t7=((C_word*)t0)[2];
t8=C_mutate2((C_word*)lf[74]+1 /* (set! ##compiler#disable-stack-overflow-checking ...) */,C_u_i_memq(lf[75],t7));
t9=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
/* batch-driver.scm:344: feature? */
t10=*((C_word*)lf[292]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[293]);}

/* k3863 in k3857 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in ... */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[4];
t4=C_a_i_list(&a,1,lf[276]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5507,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t5,*((C_word*)lf[110]+1),lf[277],t4);}
else{
t3=((C_word*)t0)[4];
t4=C_a_i_list(&a,1,lf[278]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5513,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t5,*((C_word*)lf[110]+1),lf[277],t4);}}

/* k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in ... */
static void C_ccall f_2498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=((C_word*)t0)[19];
if(C_truep(C_u_i_memq(lf[199],t3))){
/* batch-driver.scm:496: exit */
t4=*((C_word*)lf[122]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=t2;
f_2501(2,t4,C_SCHEME_UNDEFINED);}}

/* k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in ... */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm:494: print-expr */
t3=((C_word*)((C_word*)t0)[21])[1];
f_1786(t3,t2,lf[200],lf[201],((C_word*)((C_word*)t0)[20])[1]);}

/* k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in ... */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2490,2,t0,t1);}
t2=C_mutate2((C_word*)lf[85]+1 /* (set! ##sys#line-number-database ...) */,*((C_word*)lf[88]+1));
t3=C_set_block_item(lf[88] /* ##compiler#line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm:493: end-time */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1967(t5,t4,lf[202]);}

/* for-each-loop419 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in ... */
static void C_fcall f_4186(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4186,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4196,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4096,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t8))){
/* tweaks.scm:54: ##sys#put! */
t9=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,t6,lf[315],C_SCHEME_TRUE);}
else{
t9=C_i_car(t8);
/* tweaks.scm:54: ##sys#put! */
t10=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t6,lf[315],t9);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in ... */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2311,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_2314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[2],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
t4=((C_word*)t0)[3];
if(C_truep(C_u_i_memq(lf[294],t4))){
t5=C_set_block_item(lf[295] /* ##sys#enable-runtime-macros */,0,C_SCHEME_TRUE);
t6=t3;
f_2314(t6,t5);}
else{
t5=t3;
f_2314(t5,C_SCHEME_UNDEFINED);}}

/* k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in ... */
static void C_fcall f_2314(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2314,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep(((C_word*)t0)[31])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3920,a[2]=((C_word*)t0)[29],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:338: option-arg */
f_1611(t3,((C_word*)t0)[31]);}
else{
t3=t2;
f_2318(2,t3,C_SCHEME_FALSE);}}

/* k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in ... */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=C_mutate2((C_word*)lf[70]+1 /* (set! ##compiler#target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[28])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3913,a[2]=((C_word*)t0)[29],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:341: option-arg */
f_1611(t4,((C_word*)t0)[28]);}
else{
t4=t3;
f_2322(2,t4,C_SCHEME_FALSE);}}

/* k4194 in for-each-loop419 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in ... */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4186(t3,((C_word*)t0)[4],t2);}

/* k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in ... */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:372: load-identifier-database */
t3=*((C_word*)lf[271]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[272]);}

/* k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in ... */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[27])){
t3=C_i_car(((C_word*)t0)[27]);
t4=C_eqp(lf[273],t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3859,a[2]=((C_word*)t0)[24],a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
if(C_truep(((C_word*)t0)[22])){
t7=t6;
f_3859(2,t7,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm:358: quit */
t7=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[281]);}}
else{
t7=t6;
f_3859(2,t7,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2345(2,t3,C_SCHEME_UNDEFINED);}}

/* k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in ... */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2348,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[77],t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:375: print-version */
t4=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=((C_word*)t0)[2];
t4=C_u_i_memq(lf[79],t3);
t5=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(t4)){
t6=t5;
f_2367(t6,t4);}
else{
t6=((C_word*)t0)[2];
t7=C_u_i_memq(lf[268],t6);
if(C_truep(t7)){
t8=t5;
f_2367(t8,t7);}
else{
t8=((C_word*)t0)[2];
t9=C_u_i_memq(lf[269],t8);
if(C_truep(t9)){
t10=t5;
f_2367(t10,t9);}
else{
t10=((C_word*)t0)[2];
t11=t5;
f_2367(t11,C_u_i_memq(lf[270],t10));}}}}}

/* for-each-loop468 in k4117 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in ... */
static void C_fcall f_4163(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4163,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4173,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4138,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t8))){
/* tweaks.scm:54: ##sys#put! */
t9=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,t6,lf[315],C_SCHEME_TRUE);}
else{
t9=C_i_car(t8);
/* tweaks.scm:54: ##sys#put! */
t10=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t6,lf[315],t9);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in ... */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
t2=C_mutate2((C_word*)lf[76]+1 /* (set! ##compiler#bootstrap-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
t4=*((C_word*)lf[28]+1);
if(C_truep(C_u_i_memq(lf[290],*((C_word*)lf[28]+1)))){
/* batch-driver.scm:345: set-gc-report! */
t5=*((C_word*)lf[291]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,C_SCHEME_TRUE);}
else{
t5=t3;
f_2336(2,t5,C_SCHEME_UNDEFINED);}}

/* k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in ... */
static void C_fcall f_2339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2339,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
if(C_truep(*((C_word*)lf[73]+1))){
t3=t2;
t4=C_a_i_list(&a,1,lf[282]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5519,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t5,*((C_word*)lf[110]+1),lf[283],t4);}
else{
t3=t2;
t4=C_a_i_list(&a,1,lf[284]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5525,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t5,*((C_word*)lf[110]+1),lf[283],t4);}}

/* k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in ... */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[285],t3))){
t4=C_set_block_item(((C_word*)t0)[18],0,C_SCHEME_FALSE);
t5=t2;
f_2339(t5,t4);}
else{
t4=C_mutate2((C_word*)lf[286]+1 /* (set! standard-bindings ...) */,*((C_word*)lf[287]+1));
t5=C_mutate2((C_word*)lf[288]+1 /* (set! extended-bindings ...) */,*((C_word*)lf[289]+1));
t6=t2;
f_2339(t6,t5);}}

/* k4171 in for-each-loop468 in k4117 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in ... */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4163(t3,((C_word*)t0)[4],t2);}

/* k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in ... */
static void C_fcall f_2367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2367,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm:378: print-usage */
t2=*((C_word*)lf[80]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
if(C_truep(C_u_i_memq(lf[81],t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2378,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:380: chicken-version */
t5=*((C_word*)lf[83]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=((C_word*)t0)[4];
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[2],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[3],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
t5=t4;
t6=C_a_i_list(&a,1,((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5501,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t7,*((C_word*)lf[110]+1),lf[264],t6);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:383: print-version */
t5=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_TRUE);}}}}

/* k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in ... */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2406,2,t0,t1);}
t2=C_mutate2((C_word*)lf[84]+1 /* (set! ##compiler#source-filename ...) */,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[2],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:392: debugging */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[259],lf[263],((C_word*)t0)[19]);}

/* k2354 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in ... */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:376: newline */
t2=*((C_word*)lf[42]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3911 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in ... */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:341: arg-val */
f_1832(((C_word*)t0)[3],t1);}

/* k2398 in k2395 in k2392 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in ... */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:386: display */
t2=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[265]);}

/* k4417 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in ... */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_2200(t3,t2);}

/* k4410 in k4404 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in ... */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2((C_word*)lf[348]+1 /* (set! ##compiler#inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_2205(t3,t2);}

/* k3935 in map-loop588 in k3938 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in ... */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3937,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[296],t2,C_SCHEME_TRUE));}

/* k4423 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in ... */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_2195(t3,t2);}

/* k3918 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in ... */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:338: arg-val */
f_1832(((C_word*)t0)[3],t1);}

/* f5022 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in ... */
static void C_ccall f5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f5022,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5413,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t3,*((C_word*)lf[110]+1),lf[111],C_SCHEME_END_OF_LIST);}

/* k2395 in k2392 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in ... */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:385: display */
t3=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[266]);}

/* k2392 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in ... */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:384: display */
t3=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[267]);}

/* map-loop830 in k3353 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in ... */
static void C_fcall f_3476(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3476,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,lf[232],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1730 in k1727 in k1724 in k1712 in print-header in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1735,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:110: ##sys#write-char-0 */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k1733 in k1730 in k1727 in k1724 in k1712 in print-header in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 in ... */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* print-node in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1737(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1737,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1744,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:114: print-header */
f_1710(t5,t2,t3);}

/* k3120 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in ... */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:517: concatenate */
t2=*((C_word*)lf[189]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* map-loop980 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in ... */
static void C_fcall f_3124(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3124,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3944 in k3938 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in ... */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:329: append */
t2=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],t1);}

/* map-loop588 in k3938 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in ... */
static void C_fcall f_3948(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3948,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3937,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:331: string->symbol */
t7=*((C_word*)lf[297]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3938 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in ... */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[55]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3948(t7,t3,t1);}

/* k1724 in k1712 in print-header in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:110: ##sys#print */
t3=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k1727 in k1724 in k1712 in print-header in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:110: ##sys#write-char-0 */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(93),((C_word*)t0)[3]);}

/* k1975 in end-time in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:153: ##sys#print */
t3=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in ... */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=(C_truep(*((C_word*)lf[203]+1))?((C_word*)t0)[9]:C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3239,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:488: open-output-string */
t5=*((C_word*)lf[208]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2490(2,t4,C_SCHEME_UNDEFINED);}}

/* k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3257,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:483: debugging */
t4=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[210],lf[211]);}

/* k1773 in k1770 in k1764 in print-db in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:121: ##sys#write-char-0 */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[4]);}

/* k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in ... */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3263,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:481: debugging */
t4=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[213],lf[214]);}

/* k1776 in k1773 in k1770 in k1764 in print-db in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:121: ##sys#write-char-0 */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k1770 in k1764 in print-db in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:121: ##sys#print */
t3=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4]);}

/* k1981 in k1978 in k1975 in end-time in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1997,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:101: current-milliseconds */
t5=*((C_word*)lf[45]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1984 in k1981 in k1978 in k1975 in end-time in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:153: ##sys#write-char-0 */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k1978 in k1975 in end-time in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:153: ##sys#print */
t3=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[47],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in ... */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2303,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm:325: append */
t4=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[299]+1));}

/* k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in ... */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2478,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=t3,a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_i_pairp(*((C_word*)lf[215]+1)))){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3274,tmp=(C_word)a,a+=2,tmp);
/* batch-driver.scm:474: with-debugging-output */
t6=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[221],t5);}
else{
t5=t4;
f_2481(2,t5,C_SCHEME_UNDEFINED);}}

/* k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in ... */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2307,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_2311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3940,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:332: collect-options */
t9=((C_word*)((C_word*)t0)[20])[1];
f_1922(t9,t8,lf[298]);}

/* k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in ... */
static void C_ccall f_2472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2472,2,t0,t1);}
t2=C_i_length(*((C_word*)lf[87]+1));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=*((C_word*)lf[222]+1);
t10=C_i_check_list_2(*((C_word*)lf[222]+1),lf[55]);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3355,a[2]=t4,a[3]=((C_word*)t0)[21],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[22],a[6]=t3,a[7]=((C_word*)t0)[23],tmp=(C_word)a,a+=8,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3511,a[2]=t8,a[3]=t13,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t15=((C_word*)t13)[1];
f_3511(t15,t11,*((C_word*)lf[222]+1));}

/* k1742 in print-node in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1744,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* batch-driver.scm:116: dump-nodes */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1757,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:117: build-expression-tree */
t3=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1995 in k1981 in k1978 in k1975 in end-time in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_inexact_to_exact(t1);
/* batch-driver.scm:153: ##sys#print */
t3=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE,((C_word*)t0)[3]);}

/* f5525 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in ... */
static void C_ccall f5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k1712 in print-header in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1714,2,t0,t1);}
if(C_truep(C_i_memq(((C_word*)t0)[2],*((C_word*)lf[28]+1)))){
t2=*((C_word*)lf[29]+1);
t3=*((C_word*)lf[29]+1);
t4=C_i_check_port_2(*((C_word*)lf[29]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[30]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1726,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:110: ##sys#write-char-0 */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_make_character(91),*((C_word*)lf[29]+1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2651 in k2616 in k2613 in a2610 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in ... */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2653,2,t0,t1);}
t2=C_set_block_item(lf[98] /* ##compiler#inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* batch-driver.scm:624: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2565(t4,((C_word*)t0)[4],t3,((C_word*)t0)[5],C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[6]);}

/* print-header in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1710(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1710,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1714,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:107: debugging */
t5=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[34],lf[35],t2);}

/* k2665 in k2616 in k2613 in a2610 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in ... */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:627: analyze */
t3=((C_word*)((C_word*)t0)[9])[1];
f_2007(t3,t2,lf[103],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* f5559 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in ... */
static void C_ccall f5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k1764 in print-db in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1766,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[29]+1);
t3=*((C_word*)lf[29]+1);
t4=C_i_check_port_2(*((C_word*)lf[29]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[30]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:121: ##sys#print */
t6=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[40],C_SCHEME_FALSE,*((C_word*)lf[29]+1));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* f5553 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in ... */
static void C_ccall f5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1692(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[94],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1692,NULL,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1710,tmp=(C_word)a,a+=2,tmp));
t22=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1737,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t23=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1759,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t24=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1786,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1832,tmp=(C_word)a,a+=2,tmp));
t26=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t27=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp));
t28=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp));
t29=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp));
t30=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=t18,a[13]=t16,a[14]=t20,a[15]=t6,a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=t8,a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=t14,a[25]=t10,a[26]=((C_word*)t0)[22],a[27]=((C_word*)t0)[23],a[28]=((C_word*)t0)[24],a[29]=((C_word*)t0)[25],a[30]=((C_word*)t0)[26],a[31]=t2,a[32]=t12,a[33]=((C_word*)t0)[3],a[34]=((C_word*)t0)[27],a[35]=((C_word*)t0)[28],a[36]=((C_word*)t0)[29],a[37]=((C_word*)t0)[5],tmp=(C_word)a,a+=38,tmp);
if(C_truep(((C_word*)t0)[30])){
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4629,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4633,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4637,a[2]=t32,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:168: option-arg */
f_1611(t33,((C_word*)t0)[30]);}
else{
t31=t30;
f_2073(t31,C_SCHEME_UNDEFINED);}}

/* k3839 in k3831 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in ... */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:402: append */
t2=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* map-loop735 in k3622 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in ... */
static void C_fcall f_3633(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3633,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3662,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:433: g741 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3629 in k3622 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in ... */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_2448(t3,t2);}

/* print-db in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1759(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1759,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1766,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:120: print-header */
f_1710(t6,t2,t3);}

/* k1755 in k1742 in print-node in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:117: pretty-print */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3123)){
C_save(t1);
C_rereclaim2(3123*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,409);
lf[0]=C_h_intern(&lf[0],17,"user-options-pass");
lf[1]=C_h_intern(&lf[1],14,"user-read-pass");
lf[2]=C_h_intern(&lf[2],22,"user-preprocessor-pass");
lf[3]=C_h_intern(&lf[3],9,"user-pass");
lf[4]=C_h_intern(&lf[4],23,"user-post-analysis-pass");
lf[5]=C_h_intern(&lf[5],19,"compile-source-file");
lf[6]=C_h_intern(&lf[6],13,"\010compilerquit");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[9]=C_h_intern(&lf[9],26,"\010compilerexplicit-use-flag");
lf[10]=C_h_intern(&lf[10],12,"explicit-use");
lf[11]=C_h_intern(&lf[11],12,"\004coredeclare");
lf[12]=C_h_intern(&lf[12],7,"verbose");
lf[13]=C_h_intern(&lf[13],11,"output-file");
lf[14]=C_h_intern(&lf[14],23,"\010compilerchop-separator");
lf[15]=C_h_intern(&lf[15],36,"\010compilerdefault-optimization-passes");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[17]=C_h_intern(&lf[17],7,"profile");
lf[18]=C_h_intern(&lf[18],12,"profile-name");
lf[19]=C_h_intern(&lf[19],9,"heap-size");
lf[20]=C_h_intern(&lf[20],13,"keyword-style");
lf[21]=C_h_intern(&lf[21],10,"clustering");
lf[22]=C_h_intern(&lf[22],4,"unit");
lf[23]=C_h_intern(&lf[23],12,"analyze-only");
lf[24]=C_h_intern(&lf[24],7,"dynamic");
lf[25]=C_h_intern(&lf[25],4,"lfa2");
lf[26]=C_h_intern(&lf[26],6,"module");
lf[27]=C_h_intern(&lf[27],7,"nursery");
lf[28]=C_h_intern(&lf[28],26,"\010compilerdebugging-chicken");
lf[29]=C_h_intern(&lf[29],19,"\003sysstandard-output");
lf[30]=C_h_intern(&lf[30],6,"printf");
lf[31]=C_h_intern(&lf[31],16,"\003syswrite-char-0");
lf[32]=C_h_intern(&lf[32],9,"\003sysprint");
lf[33]=C_h_intern(&lf[33],18,"\010compilerdebugging");
lf[34]=C_h_intern(&lf[34],1,"p");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\004pass");
lf[36]=C_h_intern(&lf[36],19,"\010compilerdump-nodes");
lf[37]=C_h_intern(&lf[37],12,"pretty-print");
lf[38]=C_h_intern(&lf[38],30,"\010compilerbuild-expression-tree");
lf[39]=C_h_intern(&lf[39],34,"\010compilerdisplay-analysis-database");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\013(iteration ");
lf[41]=C_h_intern(&lf[41],8,"for-each");
lf[42]=C_h_intern(&lf[42],7,"newline");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[44]=C_h_intern(&lf[44],9,"substring");
lf[45]=C_h_intern(&lf[45],20,"current-milliseconds");
lf[46]=C_h_intern(&lf[46],5,"round");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\003: \011");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\030milliseconds needed for ");
lf[49]=C_h_intern(&lf[49],12,"\010compilerget");
lf[50]=C_h_intern(&lf[50],13,"\010compilerput!");
lf[51]=C_h_intern(&lf[51],27,"\010compileranalyze-expression");
lf[52]=C_h_intern(&lf[52],30,"\010compilerenable-specialization");
lf[53]=C_h_intern(&lf[53],10,"specialize");
lf[54]=C_h_intern(&lf[54],1,"D");
lf[55]=C_h_intern(&lf[55],3,"map");
lf[56]=C_h_intern(&lf[56],25,"\010compilerimport-libraries");
lf[57]=C_h_intern(&lf[57],22,"no-module-registration");
lf[58]=C_h_intern(&lf[58],35,"\010compilerenable-module-registration");
lf[59]=C_h_intern(&lf[59],16,"emit-inline-file");
lf[60]=C_h_intern(&lf[60],14,"emit-type-file");
lf[61]=C_h_intern(&lf[61],12,"inline-limit");
lf[62]=C_h_intern(&lf[62],21,"\010compilerverbose-mode");
lf[63]=C_h_intern(&lf[63],31,"\003sysread-error-with-line-number");
lf[64]=C_h_intern(&lf[64],21,"\003sysinclude-pathnames");
lf[65]=C_h_intern(&lf[65],17,"register-feature!");
lf[66]=C_h_intern(&lf[66],19,"unregister-feature!");
lf[67]=C_h_intern(&lf[67],19,"\000compiler-extension");
lf[68]=C_h_intern(&lf[68],12,"\003sysfeatures");
lf[69]=C_h_intern(&lf[69],10,"\000compiling");
lf[70]=C_h_intern(&lf[70],25,"\010compilertarget-heap-size");
lf[71]=C_h_intern(&lf[71],26,"\010compilertarget-stack-size");
lf[72]=C_h_intern(&lf[72],8,"no-trace");
lf[73]=C_h_intern(&lf[73],24,"\010compileremit-trace-info");
lf[74]=C_h_intern(&lf[74],40,"\010compilerdisable-stack-overflow-checking");
lf[75]=C_h_intern(&lf[75],29,"disable-stack-overflow-checks");
lf[76]=C_h_intern(&lf[76],23,"\010compilerbootstrap-mode");
lf[77]=C_h_intern(&lf[77],7,"version");
lf[78]=C_h_intern(&lf[78],22,"\010compilerprint-version");
lf[79]=C_h_intern(&lf[79],4,"help");
lf[80]=C_h_intern(&lf[80],20,"\010compilerprint-usage");
lf[81]=C_h_intern(&lf[81],7,"release");
lf[82]=C_h_intern(&lf[82],7,"display");
lf[83]=C_h_intern(&lf[83],15,"chicken-version");
lf[84]=C_h_intern(&lf[84],24,"\010compilersource-filename");
lf[85]=C_h_intern(&lf[85],24,"\003sysline-number-database");
lf[86]=C_h_intern(&lf[86],32,"\010compilercanonicalize-expression");
lf[87]=C_h_intern(&lf[87],28,"\010compilerprofile-lambda-list");
lf[88]=C_h_intern(&lf[88],31,"\010compilerline-number-database-2");
lf[89]=C_h_intern(&lf[89],4,"node");
lf[90]=C_h_intern(&lf[90],6,"lambda");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[92]=C_h_intern(&lf[92],23,"\010compilerconstant-table");
lf[93]=C_h_intern(&lf[93],21,"\010compilerinline-table");
lf[94]=C_h_intern(&lf[94],23,"\010compilerfirst-analysis");
lf[95]=C_h_intern(&lf[95],36,"\010compilerdetermine-loop-and-dispatch");
lf[96]=C_h_intern(&lf[96],41,"\010compilerperform-high-level-optimizations");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\022clustering enabled");
lf[98]=C_h_intern(&lf[98],37,"\010compilerinline-substitutions-enabled");
lf[99]=C_h_intern(&lf[99],22,"optimize-leaf-routines");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[101]=C_h_intern(&lf[101],34,"\010compilertransform-direct-lambdas!");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[103]=C_h_intern(&lf[103],4,"leaf");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\022rewritings enabled");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[106]=C_h_intern(&lf[106],1,"5");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[109]=C_h_intern(&lf[109],36,"\010compilerprepare-for-code-generation");
lf[110]=C_h_intern(&lf[110],7,"sprintf");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\025compilation finished.");
lf[112]=C_h_intern(&lf[112],30,"\010compilercompiler-cleanup-hook");
lf[113]=C_h_intern(&lf[113],1,"t");
lf[114]=C_h_intern(&lf[114],17,"\003sysdisplay-times");
lf[115]=C_h_intern(&lf[115],14,"\003sysstop-timer");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[117]=C_h_intern(&lf[117],17,"close-output-port");
lf[118]=C_h_intern(&lf[118],22,"\010compilergenerate-code");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\023generating `~A\047 ...");
lf[120]=C_h_intern(&lf[120],16,"open-output-file");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[122]=C_h_intern(&lf[122],4,"exit");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[124]=C_h_intern(&lf[124],1,"9");
lf[125]=C_h_intern(&lf[125],20,"\003syswarnings-enabled");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[128]=C_h_intern(&lf[128],1,"8");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[130]=C_h_intern(&lf[130],35,"\010compilerperform-closure-conversion");
lf[131]=C_h_intern(&lf[131],28,"\010compilerinsert-timer-checks");
lf[132]=C_h_intern(&lf[132],32,"\010compileremit-global-inline-file");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000&generating global inline file `~a\047 ...");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[135]=C_h_intern(&lf[135],1,"7");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\027secondary flow analysis");
lf[137]=C_h_intern(&lf[137],40,"\010compilerperform-secondary-flow-analysis");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\012doing lfa2");
lf[139]=C_h_intern(&lf[139],1,"s");
lf[140]=C_h_intern(&lf[140],33,"\010compilerprint-program-statistics");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[142]=C_h_intern(&lf[142],1,"4");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[144]=C_h_intern(&lf[144],23,"\010compileremit-type-file");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\035generating type file `~a\047 ...");
lf[146]=C_h_intern(&lf[146],1,"v");
lf[147]=C_h_intern(&lf[147],25,"\010compilerdump-global-refs");
lf[148]=C_h_intern(&lf[148],1,"d");
lf[149]=C_h_intern(&lf[149],29,"\010compilerdump-defined-globals");
lf[150]=C_h_intern(&lf[150],1,"u");
lf[151]=C_h_intern(&lf[151],31,"\010compilerdump-undefined-globals");
lf[152]=C_h_intern(&lf[152],3,"opt");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[154]=C_h_intern(&lf[154],1,"3");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[156]=C_h_intern(&lf[156],31,"\010compilerperform-cps-conversion");
lf[157]=C_h_intern(&lf[157],6,"unsafe");
lf[158]=C_h_intern(&lf[158],34,"\010compilerscan-toplevel-assignments");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\016specialization");
lf[160]=C_h_intern(&lf[160],1,"P");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\010scrutiny");
lf[162]=C_h_intern(&lf[162],19,"\010compilerscrutinize");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\023performing scrutiny");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\027pre-analysis (scrutiny)");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[166]=C_h_intern(&lf[166],1,"0");
lf[167]=C_h_intern(&lf[167],8,"scrutiny");
lf[168]=C_h_intern(&lf[168],27,"\010compilerload-type-database");
lf[169]=C_h_intern(&lf[169],13,"make-pathname");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\005types");
lf[171]=C_h_intern(&lf[171],14,"symbol->string");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\034type-database `~a\047 not found");
lf[173]=C_h_intern(&lf[173],5,"types");
lf[174]=C_h_intern(&lf[174],17,"ignore-repository");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\052default type-database `types.db\047 not found");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\010types.db");
lf[177]=C_h_intern(&lf[177],23,"\010compilerinline-locally");
lf[178]=C_h_intern(&lf[178],25,"\010compilerload-inline-file");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[180]=C_h_intern(&lf[180],19,"consult-inline-file");
lf[181]=C_h_intern(&lf[181],28,"\010compilerenable-inline-files");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[183]=C_h_intern(&lf[183],12,"file-exists\077");
lf[184]=C_h_intern(&lf[184],28,"\003sysresolve-include-filename");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[186]=C_h_intern(&lf[186],2,"pp");
lf[187]=C_h_intern(&lf[187],1,"M");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[189]=C_h_intern(&lf[189],11,"concatenate");
lf[190]=C_h_intern(&lf[190],12,"vector->list");
lf[191]=C_h_intern(&lf[191],26,"\010compilerfile-requirements");
lf[192]=C_h_intern(&lf[192],37,"\010compilerinitialize-analysis-database");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\021initial node tree");
lf[194]=C_h_intern(&lf[194],1,"T");
lf[195]=C_h_intern(&lf[195],25,"\010compilerbuild-node-graph");
lf[196]=C_h_intern(&lf[196],32,"\010compilercanonicalize-begin-body");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\014User pass...");
lf[199]=C_h_intern(&lf[199],12,"check-syntax");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[201]=C_h_intern(&lf[201],1,"2");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[203]=C_h_intern(&lf[203],18,"\010compilerunit-name");
lf[204]=C_h_intern(&lf[204],10,"\003sysnotice");
lf[205]=C_h_intern(&lf[205],17,"get-output-string");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\032\047 compiled in dynamic mode");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\016library unit `");
lf[208]=C_h_intern(&lf[208],18,"open-output-string");
lf[209]=C_h_intern(&lf[209],37,"\010compilerdisplay-line-number-database");
lf[210]=C_h_intern(&lf[210],1,"n");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[212]=C_h_intern(&lf[212],32,"\010compilerdisplay-real-name-table");
lf[213]=C_h_intern(&lf[213],1,"N");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[215]=C_h_intern(&lf[215],35,"\010compilercompiler-syntax-statistics");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\002\011\011");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[218]=C_h_intern(&lf[218],5,"print");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\030applied compiler syntax:");
lf[220]=C_h_intern(&lf[220],30,"\010compilerwith-debugging-output");
lf[221]=C_h_intern(&lf[221],1,"S");
lf[222]=C_h_intern(&lf[222],28,"\010compilerimmutable-constants");
lf[223]=C_h_intern(&lf[223],19,"\010compilerused-units");
lf[224]=C_h_intern(&lf[224],6,"append");
lf[225]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[226]=C_h_intern(&lf[226],5,"quote");
lf[227]=C_h_intern(&lf[227],28,"\003sysset-profile-info-vector!");
lf[228]=C_h_intern(&lf[228],33,"\010compilerprofile-info-vector-name");
lf[229]=C_h_intern(&lf[229],21,"\010compileremit-profile");
lf[230]=C_h_intern(&lf[230],25,"\003sysregister-profile-info");
lf[231]=C_h_intern(&lf[231],4,"set!");
lf[232]=C_h_intern(&lf[232],13,"\004corecallunit");
lf[233]=C_h_intern(&lf[233],6,"gensym");
lf[234]=C_h_intern(&lf[234],6,"import");
lf[235]=C_h_intern(&lf[235],6,"scheme");
lf[236]=C_h_intern(&lf[236],7,"chicken");
lf[237]=C_h_intern(&lf[237],4,"main");
lf[238]=C_h_intern(&lf[238],11,"\004coremodule");
lf[239]=C_h_intern(&lf[239],28,"\003sysexplicit-library-modules");
lf[240]=C_h_intern(&lf[240],4,"uses");
lf[241]=C_h_intern(&lf[241],7,"declare");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[243]=C_h_intern(&lf[243],1,"1");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\032User preprocessing pass...");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\021User read pass...");
lf[246]=C_h_intern(&lf[246],21,"\010compilerstring->expr");
lf[247]=C_h_intern(&lf[247],7,"reverse");
lf[248]=C_h_intern(&lf[248],27,"\003syscurrent-source-filename");
lf[249]=C_h_intern(&lf[249],33,"\010compilerclose-checked-input-file");
lf[250]=C_h_intern(&lf[250],25,"\010compilerread/source-info");
lf[251]=C_h_intern(&lf[251],16,"\003sysdynamic-wind");
lf[252]=C_h_intern(&lf[252],34,"\010compilercheck-and-open-input-file");
lf[253]=C_h_intern(&lf[253],8,"epilogue");
lf[254]=C_h_intern(&lf[254],8,"prologue");
lf[255]=C_h_intern(&lf[255],8,"postlude");
lf[256]=C_h_intern(&lf[256],7,"prelude");
lf[257]=C_h_intern(&lf[257],11,"make-vector");
lf[258]=C_h_intern(&lf[258],34,"\010compilerline-number-database-size");
lf[259]=C_h_intern(&lf[259],1,"r");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\022compiling `~a\047 ...");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\0001\012Run `csi\047 to start the interactive interpreter.\012");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000.or try `csc\047 for a more convenient interface.\012");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000C\012Enter `chicken -help\047 for information on how to use the compiler,\012");
lf[268]=C_h_intern(&lf[268],5,"-help");
lf[269]=C_h_intern(&lf[269],1,"h");
lf[270]=C_h_intern(&lf[270],2,"-h");
lf[271]=C_h_intern(&lf[271],33,"\010compilerload-identifier-database");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[273]=C_h_intern(&lf[273],18,"accumulate-profile");
lf[274]=C_h_intern(&lf[274],28,"\010compilerprofiled-procedures");
lf[275]=C_h_intern(&lf[275],3,"all");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\015accumulative ");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\032generating ~aprofiled code");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[279]=C_h_intern(&lf[279],39,"\010compilerdefault-profiling-declarations");
lf[280]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000Eyou need to specify -profile-name if using accumulated profiling runs");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\022debugging info: ~A");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[285]=C_h_intern(&lf[285],21,"no-usual-integrations");
lf[286]=C_h_intern(&lf[286],17,"standard-bindings");
lf[287]=C_h_intern(&lf[287],34,"\010compilerdefault-standard-bindings");
lf[288]=C_h_intern(&lf[288],17,"extended-bindings");
lf[289]=C_h_intern(&lf[289],34,"\010compilerdefault-extended-bindings");
lf[290]=C_h_intern(&lf[290],1,"m");
lf[291]=C_h_intern(&lf[291],14,"set-gc-report!");
lf[292]=C_h_intern(&lf[292],8,"feature\077");
lf[293]=C_h_intern(&lf[293],18,"\000chicken-bootstrap");
lf[294]=C_h_intern(&lf[294],14,"compile-syntax");
lf[295]=C_h_intern(&lf[295],25,"\003sysenable-runtime-macros");
lf[296]=C_h_intern(&lf[296],22,"\004corerequire-extension");
lf[297]=C_h_intern(&lf[297],14,"string->symbol");
lf[298]=C_h_intern(&lf[298],17,"require-extension");
lf[299]=C_h_intern(&lf[299],28,"\010compilerpostponed-initforms");
lf[300]=C_h_intern(&lf[300],6,"delete");
lf[301]=C_h_intern(&lf[301],3,"eq\077");
lf[302]=C_h_intern(&lf[302],4,"load");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\036Loading compiler extensions...");
lf[304]=C_h_intern(&lf[304],6,"extend");
lf[305]=C_h_intern(&lf[305],12,"string-split");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[307]=C_h_intern(&lf[307],10,"append-map");
lf[308]=C_h_intern(&lf[308],10,"no-feature");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[310]=C_h_intern(&lf[310],7,"feature");
lf[311]=C_h_intern(&lf[311],12,"load-verbose");
lf[312]=C_h_intern(&lf[312],38,"no-procedure-checks-for-usual-bindings");
lf[313]=C_h_intern(&lf[313],8,"\003sysput!");
lf[314]=C_h_intern(&lf[314],21,"\010compileralways-bound");
lf[315]=C_h_intern(&lf[315],34,"\010compileralways-bound-to-procedure");
lf[316]=C_h_intern(&lf[316],41,"no-procedure-checks-for-toplevel-bindings");
lf[317]=C_h_intern(&lf[317],35,"\010compilerno-global-procedure-checks");
lf[318]=C_h_intern(&lf[318],19,"no-procedure-checks");
lf[319]=C_h_intern(&lf[319],28,"\010compilerno-procedure-checks");
lf[320]=C_h_intern(&lf[320],15,"no-bound-checks");
lf[321]=C_h_intern(&lf[321],24,"\010compilerno-bound-checks");
lf[322]=C_h_intern(&lf[322],14,"no-argc-checks");
lf[323]=C_h_intern(&lf[323],23,"\010compilerno-argc-checks");
lf[324]=C_h_intern(&lf[324],20,"keep-shadowed-macros");
lf[325]=C_h_intern(&lf[325],33,"\010compilerundefine-shadowed-macros");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[328]=C_h_intern(&lf[328],12,"include-path");
lf[329]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[330]=C_h_intern(&lf[330],13,"symbol-escape");
lf[331]=C_h_intern(&lf[331],20,"parentheses-synonyms");
lf[332]=C_h_intern(&lf[332],5,"\000none");
lf[333]=C_h_intern(&lf[333],14,"case-sensitive");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000.Disabled the Chicken extensions to R5RS syntax");
lf[335]=C_h_intern(&lf[335],16,"no-symbol-escape");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000$Disabled support for escaped symbols");
lf[337]=C_h_intern(&lf[337],23,"no-parenthesis-synonyms");
lf[338]=C_h_intern(&lf[338],20,"parenthesis-synonyms");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000)Disabled support for parenthesis synonyms");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[341]=C_h_intern(&lf[341],7,"\000prefix");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[344]=C_h_intern(&lf[344],7,"\000suffix");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[346]=C_h_intern(&lf[346],16,"case-insensitive");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000,Identifiers and symbols are case insensitive");
lf[348]=C_h_intern(&lf[348],24,"\010compilerinline-max-size");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[350]=C_h_intern(&lf[350],26,"\010compilerlocal-definitions");
lf[351]=C_h_intern(&lf[351],6,"inline");
lf[352]=C_h_intern(&lf[352],30,"emit-external-prototypes-first");
lf[353]=C_h_intern(&lf[353],30,"\010compilerexternal-protos-first");
lf[354]=C_h_intern(&lf[354],5,"block");
lf[355]=C_h_intern(&lf[355],26,"\010compilerblock-compilation");
lf[356]=C_h_intern(&lf[356],17,"fixnum-arithmetic");
lf[357]=C_h_intern(&lf[357],11,"number-type");
lf[358]=C_h_intern(&lf[358],6,"fixnum");
lf[359]=C_h_intern(&lf[359],18,"disable-interrupts");
lf[360]=C_h_intern(&lf[360],10,"setup-mode");
lf[361]=C_h_intern(&lf[361],14,"\003syssetup-mode");
lf[362]=C_h_intern(&lf[362],11,"no-warnings");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\025Warnings are disabled");
lf[364]=C_h_intern(&lf[364],12,"strict-types");
lf[365]=C_h_intern(&lf[365],30,"\010compilerstrict-variable-types");
lf[366]=C_h_intern(&lf[366],19,"\003sysnotices-enabled");
lf[367]=C_h_intern(&lf[367],13,"inline-global");
lf[368]=C_h_intern(&lf[368],5,"local");
lf[369]=C_h_intern(&lf[369],18,"no-compiler-syntax");
lf[370]=C_h_intern(&lf[370],32,"\010compilercompiler-syntax-enabled");
lf[371]=C_h_intern(&lf[371],14,"no-lambda-info");
lf[372]=C_h_intern(&lf[372],26,"\010compileremit-closure-info");
lf[373]=C_h_intern(&lf[373],3,"raw");
lf[374]=C_h_intern(&lf[374],8,"unboxing");
lf[375]=C_h_intern(&lf[375],7,"warning");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000#obsolete compiler option: -unboxing");
lf[377]=C_h_intern(&lf[377],11,"lambda-lift");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000&obsolete compiler option: -lambda-lift");
lf[379]=C_h_intern(&lf[379],12,"emit-exports");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\047obsolete compiler option: -emit-exports");
lf[381]=C_h_intern(&lf[381],1,"b");
lf[382]=C_h_intern(&lf[382],15,"\003sysstart-timer");
lf[383]=C_h_intern(&lf[383],25,"emit-all-import-libraries");
lf[384]=C_h_intern(&lf[384],29,"\010compilerall-import-libraries");
lf[385]=C_h_intern(&lf[385],17,"\003sysstring-append");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[387]=C_h_intern(&lf[387],19,"emit-import-library");
lf[388]=C_h_intern(&lf[388],28,"\010compilerprint-debug-options");
lf[389]=C_h_intern(&lf[389],16,"\003sysstring->list");
lf[390]=C_h_intern(&lf[390],5,"debug");
lf[391]=C_h_intern(&lf[391],18,"\003sysdload-disabled");
lf[392]=C_h_intern(&lf[392],15,"repository-path");
lf[393]=C_h_intern(&lf[393],30,"\010compilerstandalone-executable");
lf[394]=C_h_intern(&lf[394],29,"\010compilerstring->c-identifier");
lf[395]=C_h_intern(&lf[395],18,"\010compilerstringify");
lf[396]=C_h_intern(&lf[396],10,"stack-size");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[399]=C_h_intern(&lf[399],24,"get-environment-variable");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[401]=C_h_intern(&lf[401],9,"to-stdout");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[403]=C_h_intern(&lf[403],13,"pathname-file");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[405]=C_h_intern(&lf[405],29,"\010compilerdefault-declarations");
lf[406]=C_h_intern(&lf[406],30,"\010compilerunits-used-by-default");
lf[407]=C_h_intern(&lf[407],28,"\010compilerinitialize-compiler");
lf[408]=C_h_intern(&lf[408],14,"make-parameter");
C_register_lf2(lf,409,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1580,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3991 in for-each-loop569 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in ... */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3983(t3,((C_word*)t0)[4],t2);}

/* k3857 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in ... */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3859,2,t0,t1);}
t2=C_set_block_item(lf[229] /* ##compiler#emit-profile */,0,C_SCHEME_TRUE);
t3=C_mutate2((C_word*)lf[274]+1 /* (set! ##compiler#profiled-procedures ...) */,lf[275]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm:363: append */
t5=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[279]+1),lf[280]);}
else{
/* batch-driver.scm:363: append */
t5=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[279]+1),C_SCHEME_END_OF_LIST);}}

/* k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2089,2,t0,t1);}
t2=*((C_word*)lf[28]+1);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_memq(lf[54],*((C_word*)lf[28]+1)));
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|38,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=t7,a[38]=t5,tmp=(C_word)a,a+=39,tmp);
/* batch-driver.scm:189: collect-options */
t9=((C_word*)((C_word*)t0)[24])[1];
f_1922(t9,t8,lf[387]);}

/* k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2086,2,t0,t1);}
t2=C_mutate2((C_word*)lf[28]+1 /* (set! ##compiler#debugging-chicken ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t4=*((C_word*)lf[28]+1);
if(C_truep(C_u_i_memq(lf[269],*((C_word*)lf[28]+1)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4555,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:182: print-debug-options */
t6=*((C_word*)lf[388]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2089(2,t5,C_SCHEME_UNDEFINED);}}

/* k2383 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in ... */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:380: display */
t2=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2079,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_mutate2((C_word*)lf[52]+1 /* (set! ##compiler#enable-specialization ...) */,C_u_i_memq(lf[53],t2));
t4=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_2086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4560,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4615,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:180: collect-options */
t7=((C_word*)((C_word*)t0)[24])[1];
f_1922(t7,t6,lf[390]);}

/* k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_2076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2076,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[174],t3))){
t4=C_set_block_item(lf[391] /* ##sys#dload-disabled */,0,C_SCHEME_TRUE);
/* batch-driver.scm:173: repository-path */
t5=*((C_word*)lf[392]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,C_SCHEME_FALSE);}
else{
t4=t2;
f_2079(2,t4,C_SCHEME_UNDEFINED);}}

/* k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_2073(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2073,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=*((C_word*)lf[203]+1);
if(C_truep(*((C_word*)lf[203]+1))){
t4=*((C_word*)lf[203]+1);
if(C_truep(*((C_word*)lf[203]+1))){
t5=C_set_block_item(lf[393] /* ##compiler#standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_2076(t6,t5);}
else{
t5=t2;
f_2076(t5,C_SCHEME_UNDEFINED);}}
else{
if(C_truep(((C_word*)t0)[17])){
t4=C_set_block_item(lf[393] /* ##compiler#standalone-executable */,0,C_SCHEME_FALSE);
t5=t2;
f_2076(t5,t4);}
else{
t4=t2;
f_2076(t4,C_SCHEME_UNDEFINED);}}}

/* k2635 in k2616 in k2613 in a2610 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in ... */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* batch-driver.scm:620: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2565(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5],C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k2376 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in ... */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:381: newline */
t2=*((C_word*)lf[42]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2026 in k2011 in body228 in analyze in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2027,5,t0,t1,t2,t3,t4);}
t5=*((C_word*)lf[50]+1);
/* batch-driver.scm:163: g263 */
t6=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,((C_word*)t0)[2],t2,t3,t4);}

/* for-each-loop569 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in ... */
static void C_fcall f_3983(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3983,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3993,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2285,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:318: ##sys#resolve-include-filename */
t7=*((C_word*)lf[184]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t4,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a2020 in k2011 in body228 in analyze in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2021,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[49]+1);
/* batch-driver.scm:162: g249 */
t5=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* k3660 in map-loop735 in k3622 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in ... */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3662,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3633(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3633(t6,((C_word*)t0)[5],t5);}}

/* k3667 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in ... */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:410: proc */
t3=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k2680 in k2677 in k2674 in k2671 in k2668 in k2665 in k2616 in k2613 in a2610 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in ... */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* batch-driver.scm:633: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2565(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5],((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[7]);}

/* k2668 in k2665 in k2616 in k2613 in a2610 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in ... */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:628: end-time */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1967(t4,t3,lf[102]);}

/* k2677 in k2674 in k2671 in k2668 in k2665 in k2616 in k2613 in a2610 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in ... */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2679,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:632: end-time */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1967(t4,t3,lf[100]);}

/* k2671 in k2668 in k2665 in k2616 in k2613 in a2610 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in ... */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:629: begin-time */
t3=((C_word*)((C_word*)t0)[9])[1];
f_1957(t3,t2);}

/* k2674 in k2671 in k2668 in k2665 in k2616 in k2613 in a2610 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in ... */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:631: transform-direct-lambdas! */
t3=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[8]);}

/* k3975 in map-loop588 in k3938 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in ... */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3948(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3948(t6,((C_word*)t0)[5],t5);}}

/* a2610 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in ... */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2611,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2615,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:614: end-time */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1967(t5,t4,lf[107]);}

/* k2616 in k2613 in a2610 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in ... */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* batch-driver.scm:617: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2565(t3,((C_word*)t0)[5],t2,((C_word*)t0)[6],C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)t0)[9]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:619: debugging */
t5=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[34],lf[97]);}
else{
t4=*((C_word*)lf[98]+1);
if(C_truep(*((C_word*)lf[98]+1))){
if(C_truep(*((C_word*)lf[99]+1))){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2667,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:626: begin-time */
t6=((C_word*)((C_word*)t0)[11])[1];
f_1957(t6,t5);}
else{
t5=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* batch-driver.scm:639: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2565(t6,((C_word*)t0)[5],t5,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[8]);}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:622: debugging */
t6=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,lf[34],lf[104]);}}}}

/* k2613 in a2610 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in ... */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm:615: print-node */
t3=((C_word*)((C_word*)t0)[13])[1];
f_1737(t3,t2,lf[105],lf[106],((C_word*)t0)[6]);}

/* analyze in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_2007(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2007,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2009,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2037,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t4))){
/* batch-driver.scm:55: def-no230 */
t8=t7;
f_2037(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_u_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* batch-driver.scm:55: def-contf231 */
t10=t6;
f_2032(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_u_i_cdr(t9);
/* batch-driver.scm:55: body228 */
t12=t5;
f_2009(t12,t1,t8,t10);}}}

/* body228 in analyze in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_2009(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2009,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2013,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:159: analyze-expression */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* k2003 in k1981 in k1978 in k1975 in end-time in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=C_a_i_minus(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm:155: round */
t3=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}

/* k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in ... */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2560,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2565,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp));
t5=((C_word*)t3)[1];
f_2565(t5,((C_word*)t0)[16],C_fix(1),((C_word*)t0)[17],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in ... */
static void C_fcall f_2565(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2565,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2569,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=t1,a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],a[21]=((C_word*)t0)[15],a[22]=((C_word*)t0)[16],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:585: begin-time */
t9=((C_word*)((C_word*)t0)[5])[1];
f_1957(t9,t8);}

/* k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in ... */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:587: analyze */
t3=((C_word*)((C_word*)t0)[11])[1];
f_2007(t3,t2,lf[152],((C_word*)((C_word*)t0)[4])[1],C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]));}

/* k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in ... */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm:575: perform-cps-conversion */
t3=*((C_word*)lf[156]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[17]);}

/* k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in ... */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t2,tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm:576: end-time */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1967(t4,t3,lf[155]);}

/* k4260 in map-loop393 in k4226 in a4223 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in ... */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4262,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4233(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4233(t6,((C_word*)t0)[5],t5);}}

/* k2011 in body228 in analyze in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2013,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2021,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2027,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:161: upap */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc9)(void*)(*((C_word*)t6+1)))(9,t6,t3,((C_word*)t0)[4],t2,((C_word*)t0)[5],t4,t5,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k2014 in k2011 in body228 in analyze in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in ... */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm:577: print-node */
t3=((C_word*)((C_word*)t0)[6])[1];
f_1737(t3,t2,lf[153],lf[154],((C_word*)t0)[17]);}

/* k2837 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in ... */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[28]+1);
if(C_truep(C_u_i_memq(lf[148],*((C_word*)lf[28]+1)))){
/* batch-driver.scm:592: dump-defined-globals */
t4=*((C_word*)lf[149]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[4]);}
else{
t4=t2;
f_2842(2,t4,C_SCHEME_UNDEFINED);}}

/* k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in ... */
static void C_ccall f_2501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm:499: user-pass */
t3=*((C_word*)lf[3]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in ... */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3176,a[2]=t2,a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5463,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t6,*((C_word*)lf[110]+1),lf[198],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_2507(2,t4,C_SCHEME_UNDEFINED);}}

/* k4268 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in ... */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:279: append-map */
t2=*((C_word*)lf[307]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in ... */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3173,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:510: canonicalize-begin-body */
t4=*((C_word*)lf[196]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[20])[1]);}

/* k4284 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in ... */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4286,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[55]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4294,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4294(t7,t3,t1);}

/* k3736 in map-loop686 in k3698 in k3694 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in ... */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3738,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3709(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3709(t6,((C_word*)t0)[5],t5);}}

/* k4290 in k4284 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in ... */
static void C_ccall f_4292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:273: append */
t2=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,*((C_word*)lf[64]+1),((C_word*)t0)[3]);}

/* k4544 in map-loop308 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in ... */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4517(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4517(t6,((C_word*)t0)[5],t5);}}

/* map-loop364 in k4284 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in ... */
static void C_fcall f_4294(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4294,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:273: g370 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4226 in a4223 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in ... */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4228,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4233,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4233(t5,((C_word*)t0)[4],t1);}

/* a4223 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in ... */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4224,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4228,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:280: string-split */
t8=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,lf[326]);}

/* map-loop308 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in ... */
static void C_fcall f_4517(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4517,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2102,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:187: string->symbol */
t8=*((C_word*)lf[297]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in ... */
static void C_fcall f_2542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2542,NULL,2,t0,t1);}
t2=C_set_block_item(lf[85] /* ##sys#line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[92] /* ##compiler#constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[93] /* ##compiler#inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(*((C_word*)lf[157]+1))){
t6=t5;
f_2548(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=C_slot(((C_word*)t0)[17],C_fix(3));
t7=C_i_car(t6);
/* batch-driver.scm:571: scan-toplevel-assignments */
t8=*((C_word*)lf[158]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}}

/* map-loop393 in k4226 in a4223 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in ... */
static void C_fcall f_4233(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4233,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4262,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:280: g399 */
t5=*((C_word*)lf[297]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in ... */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm:573: begin-time */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1957(t3,t2);}

/* map-loop686 in k3698 in k3694 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in ... */
static void C_fcall f_3709(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3709,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3738,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:417: g692 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3705 in k3698 in k3694 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in ... */
static void C_ccall f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:415: append */
t2=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k3698 in k3694 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in ... */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[246]+1);
t8=C_i_check_list_2(((C_word*)t0)[2],lf[55]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3707,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3709,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_3709(t13,t9,((C_word*)t0)[2]);}

/* k2826 in k2823 in k2820 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in ... */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:647: end-time */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1967(t2,((C_word*)t0)[3],lf[136]);}

/* k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in ... */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(*((C_word*)lf[181]+1))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3091(t6,t2,((C_word*)t0)[20]);}
else{
t3=t2;
f_2533(2,t3,C_SCHEME_UNDEFINED);}}

/* k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in ... */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:530: collect-options */
t3=((C_word*)((C_word*)t0)[21])[1];
f_1922(t3,t2,lf[180]);}

/* k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in ... */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_i_nullp(t1))){
t3=t2;
f_2539(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(lf[177] /* ##compiler#inline-locally */,0,C_SCHEME_TRUE);
t4=C_i_check_list_2(t1,lf[41]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3037,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3037(t8,t2,t1);}}

/* k2820 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in ... */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:645: debugging */
t3=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[34],lf[138]);}

/* k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in ... */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=((C_word*)((C_word*)t0)[18])[1];
t4=(C_truep(t3)?t3:*((C_word*)lf[52]+1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2891,a[2]=((C_word*)t0)[19],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[18],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[20],a[12]=((C_word*)t0)[21],tmp=(C_word)a,a+=13,tmp);
t6=((C_word*)t0)[22];
if(C_truep(C_u_i_memq(lf[174],t6))){
t7=t5;
f_2891(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3014,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:542: load-type-database */
t8=*((C_word*)lf[168]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[176]);}}
else{
t5=t2;
f_2542(t5,C_SCHEME_UNDEFINED);}}

/* k2823 in k2820 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in ... */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:646: perform-secondary-flow-analysis */
t3=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}

/* k3771 in map-loop660 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in ... */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3773,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3744(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3744(t6,((C_word*)t0)[5],t5);}}

/* k2814 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in ... */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:654: emit-global-inline-file */
t2=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k2808 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in ... */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2810,2,t0,t1);}
t2=C_a_i_minus(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(C_i_greaterp(t2,C_fix(60000)))){
/* batch-driver.scm:662: display */
t3=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],lf[126]);}
else{
t3=((C_word*)t0)[3];
f_2724(2,t3,C_SCHEME_UNDEFINED);}}

/* k4553 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:183: exit */
t2=*((C_word*)lf[122]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in ... */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(*((C_word*)lf[125]+1))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2810,a[2]=((C_word*)t0)[12],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:101: current-milliseconds */
t4=*((C_word*)lf[45]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2724(2,t3,C_SCHEME_UNDEFINED);}}

/* k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in ... */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:663: print-node */
t3=((C_word*)((C_word*)t0)[11])[1];
f_1737(t3,t2,lf[123],lf[124],((C_word*)((C_word*)t0)[2])[1]);}

/* k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in ... */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[10])){
/* batch-driver.scm:664: exit */
t3=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(0));}
else{
t3=t2;
f_2730(2,t3,C_SCHEME_UNDEFINED);}}

/* k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in ... */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2585,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:608: debugging */
t3=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[34],lf[108],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2702,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[20],a[14]=((C_word*)t0)[6],a[15]=((C_word*)t0)[21],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[22])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:644: begin-time */
t4=((C_word*)((C_word*)t0)[11])[1];
f_1957(t4,t3);}
else{
t3=t2;
f_2702(2,t3,C_SCHEME_UNDEFINED);}}}

/* a4559 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4560,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4573,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* string->list */
t8=*((C_word*)lf[389]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in ... */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=*((C_word*)lf[28]+1);
if(C_truep(C_u_i_memq(lf[139],*((C_word*)lf[28]+1)))){
/* batch-driver.scm:604: print-program-statistics */
t4=*((C_word*)lf[140]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[5]);}
else{
t4=t2;
f_2585(2,t4,C_SCHEME_UNDEFINED);}}

/* g208 in loop in collect-options in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1936(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1936,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1944,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:145: option-arg */
f_1611(t3,t2);}

/* k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in ... */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:601: print-db */
t3=((C_word*)((C_word*)t0)[20])[1];
f_1759(t3,t2,lf[141],lf[142],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in ... */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2575,2,t0,t1);}
t2=C_set_block_item(lf[94] /* ##compiler#first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:600: end-time */
t4=((C_word*)((C_word*)t0)[10])[1];
f_1967(t4,t3,lf[143]);}

/* k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in ... */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2572,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(*((C_word*)lf[94]+1))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[22],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[28]+1);
if(C_truep(C_u_i_memq(lf[150],*((C_word*)lf[28]+1)))){
/* batch-driver.scm:590: dump-undefined-globals */
t6=*((C_word*)lf[151]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t2);}
else{
t6=t4;
f_2839(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2575(2,t4,C_SCHEME_UNDEFINED);}}

/* k1942 in g208 in loop in collect-options in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm:145: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1928(t5,t3,t4);}

/* k1946 in k1942 in g208 in loop in collect-options in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in ... */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2524,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=t2,tmp=(C_word)a,a+=23,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3122,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3124,a[2]=t7,a[3]=t10,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3124(t12,t8,t2);}

/* k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in ... */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3161,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:516: vector->list */
t4=*((C_word*)lf[190]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[191]+1));}

/* k3252 in k3249 in k3246 in k3243 in k3237 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in ... */
static void C_ccall f_3254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:487: ##sys#notice */
t2=*((C_word*)lf[204]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3255 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in ... */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm:484: display-line-number-database */
t2=*((C_word*)lf[209]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_2487(2,t2,C_SCHEME_UNDEFINED);}}

/* k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in ... */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2527,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=t2,a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3115,a[2]=t3,a[3]=((C_word*)t0)[22],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:518: debugging */
t5=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[187],lf[188]);}

/* begin-time in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1957(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1957,NULL,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1965,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:101: current-milliseconds */
t3=*((C_word*)lf[45]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3622 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in ... */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3624,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[2];
t7=((C_word*)((C_word*)t0)[3])[1];
t8=C_i_check_list_2(t7,lf[55]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3633,a[2]=t5,a[3]=t11,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_3633(t13,t9,t7);}

/* k3261 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm:482: display-real-name-table */
t2=*((C_word*)lf[212]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_2484(2,t2,C_SCHEME_UNDEFINED);}}

/* k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in ... */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm:513: initialize-analysis-database */
t3=*((C_word*)lf[192]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1963 in begin-time in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* end-time in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1967(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1967,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=*((C_word*)lf[29]+1);
t4=*((C_word*)lf[29]+1);
t5=C_i_check_port_2(*((C_word*)lf[29]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[30]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1977,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:153: ##sys#print */
t7=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[48],C_SCHEME_FALSE,*((C_word*)lf[29]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in ... */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:678: end-time */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1967(t3,t2,lf[116]);}

/* k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in ... */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* batch-driver.scm:677: close-output-port */
t3=*((C_word*)lf[117]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_2763(2,t3,C_SCHEME_UNDEFINED);}}

/* k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in ... */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:681: compiler-cleanup-hook */
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in ... */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2769,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[28]+1);
if(C_truep(C_u_i_memq(lf[113],*((C_word*)lf[28]+1)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2784,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:680: ##sys#stop-timer */
t5=*((C_word*)lf[115]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:681: compiler-cleanup-hook */
t5=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3276 in a3273 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3278,2,t0,t1);}
t2=*((C_word*)lf[215]+1);
t3=C_i_check_list_2(*((C_word*)lf[215]+1),lf[41]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3312,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3312(t7,((C_word*)t0)[2],*((C_word*)lf[215]+1));}

/* a3273 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in ... */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3278,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:477: print */
t3=*((C_word*)lf[218]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[219]);}

/* k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in ... */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2273,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_2276,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5535,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t5,*((C_word*)lf[110]+1),lf[303],C_SCHEME_END_OF_LIST);}

/* k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in ... */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm:657: perform-closure-conversion */
t3=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}

/* k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in ... */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2715,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm:658: end-time */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1967(t4,t3,lf[129]);}

/* k3607 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in ... */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3609,2,t0,t1);}
t2=C_mutate2((C_word*)lf[239]+1 /* (set! ##sys#explicit-library-modules ...) */,t1);
t3=C_a_i_cons(&a,2,lf[240],((C_word*)((C_word*)t0)[2])[1]);
t4=C_a_i_list(&a,2,lf[241],t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[4];
f_2457(t7,t6);}

/* k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in ... */
static void C_fcall f_2248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2248,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[312],t3))){
t4=*((C_word*)lf[287]+1);
t5=C_i_check_list_2(*((C_word*)lf[287]+1),lf[41]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4119,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4186,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=((C_word*)t8)[1];
f_4186(t10,t6,*((C_word*)lf[287]+1));}
else{
t4=t2;
f_2251(2,t4,C_SCHEME_UNDEFINED);}}

/* map-loop280 in k4571 in a4559 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 in ... */
static void C_fcall f_4578(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4578,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_string(&a,1,t4);
/* batch-driver.scm:178: string->symbol */
t6=*((C_word*)lf[297]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t3,t5);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in ... */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm:659: print-db */
t3=((C_word*)((C_word*)t0)[13])[1];
f_1759(t3,t2,lf[127],lf[128],((C_word*)t0)[3],((C_word*)t0)[14]);}

/* k4571 in a4559 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4578(t5,((C_word*)t0)[4],t1);}

/* k3287 in k3284 in for-each-loop898 in k3276 in a3273 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in ... */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:479: ##sys#print */
t3=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[216],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k3284 in for-each-loop898 in k3276 in a3273 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in ... */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm:479: ##sys#print */
t4=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k1899 in arg-val in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=C_a_i_string_to_number(&a,2,t1,C_fix(10));
t3=C_a_i_times(&a,2,t2,C_fix(1024));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* batch-driver.scm:141: quit */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],lf[43],((C_word*)t0)[3]);}}

/* k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in ... */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4006,a[2]=t4,a[3]=((C_word*)t0)[33],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4006(t6,t2,t1);}

/* k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in ... */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2260,2,t0,t1);}
t2=*((C_word*)lf[66]+1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=t2,tmp=(C_word)a,a+=34,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4029,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4037,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:311: collect-options */
t6=((C_word*)((C_word*)t0)[21])[1];
f_1922(t6,t5,lf[308]);}

/* k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in ... */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[15])[1])?*((C_word*)lf[131]+1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[15])[1];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2816,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=t5;
t7=C_a_i_list(&a,1,t4);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5425,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t8,*((C_word*)lf[110]+1),lf[133],t7);}
else{
t4=t2;
f_2708(2,t4,C_SCHEME_UNDEFINED);}}

/* k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in ... */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm:648: print-node */
t3=((C_word*)((C_word*)t0)[11])[1];
f_1737(t3,t2,lf[134],lf[135],((C_word*)((C_word*)t0)[2])[1]);}

/* k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in ... */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm:655: begin-time */
t3=((C_word*)((C_word*)t0)[8])[1];
f_1957(t3,t2);}

/* k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in ... */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2276,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[41]);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3983,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3983(t7,t3,((C_word*)t0)[2]);}

/* k3781 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in ... */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3783,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[2];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3793,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3798,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3826,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:412: ##sys#dynamic-wind */
t11=*((C_word*)lf[251]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}

/* k3784 in k3781 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in ... */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3678(t4,((C_word*)t0)[4],t3);}

/* k3293 in k3290 in k3287 in k3284 in for-each-loop898 in k3276 in a3273 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in ... */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:479: ##sys#write-char-0 */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k3290 in k3287 in k3284 in for-each-loop898 in k3276 in a3273 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in ... */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* batch-driver.scm:479: ##sys#print */
t4=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in ... */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm:320: delete */
t3=*((C_word*)lf[300]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[67],*((C_word*)lf[68]+1),*((C_word*)lf[301]+1));}

/* k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in ... */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:665: begin-time */
t3=((C_word*)((C_word*)t0)[8])[1];
f_1957(t3,t2);}

/* k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in ... */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:667: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[9],t2,t3);}

/* k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in ... */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2266,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[67],*((C_word*)lf[68]+1));
t3=C_mutate2((C_word*)lf[68]+1 /* (set! ##sys#features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm:315: collect-options */
t5=((C_word*)((C_word*)t0)[21])[1];
f_1922(t5,t4,lf[304]);}

/* a2737 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in ... */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2738,2,t0,t1);}
/* batch-driver.scm:669: prepare-for-code-generation */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}

/* a3792 in k3781 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in ... */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3793,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[248]+1));
t3=C_mutate2((C_word*)lf[248]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a3797 in k3781 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in ... */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3798,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3804(t5,t1);}

/* loop in collect-options in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1928(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1928,NULL,3,t0,t1,t2);}
t3=C_i_memq(((C_word*)t0)[2],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:55: g208 */
t5=t4;
f_1936(t5,t1,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* collect-options in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1922(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1922,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1928,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1928(t6,t1,((C_word*)t0)[3]);}

/* option-arg in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1611(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1611,NULL,2,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=C_u_i_car(t4);
/* batch-driver.scm:48: quit */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[7],t5);}
else{
t4=C_i_cadr(t2);
if(C_truep(C_i_symbolp(t4))){
/* batch-driver.scm:51: quit */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[8],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

/* k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in ... */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2295,2,t0,t1);}
t2=C_mutate2((C_word*)lf[68]+1 /* (set! ##sys#features ...) */,t1);
t3=C_a_i_cons(&a,2,lf[69],*((C_word*)lf[68]+1));
t4=C_mutate2((C_word*)lf[68]+1 /* (set! ##sys#features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm:322: user-post-analysis-pass */
t6=*((C_word*)lf[4]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2283 in for-each-loop569 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in ... */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:318: load */
t2=*((C_word*)lf[302]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* def-no230 in analyze in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_2037(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2037,NULL,2,t0,t1);}
/* batch-driver.scm:55: def-contf231 */
t2=((C_word*)t0)[2];
f_2032(t2,t1,C_fix(0));}

/* def-contf231 in analyze in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_2032(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2032,NULL,3,t0,t1,t2);}
/* batch-driver.scm:55: body228 */
t3=((C_word*)t0)[2];
f_2009(t3,t1,t2,C_SCHEME_TRUE);}

/* k1879 in arg-val in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=C_a_i_string_to_number(&a,2,t1,C_fix(10));
t3=C_a_i_times(&a,2,t2,C_fix(1048576));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* batch-driver.scm:141: quit */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],lf[43],((C_word*)t0)[3]);}}

/* a2598 in k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in ... */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2599,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm:612: determine-loop-and-dispatch */
t2=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4]);}
else{
/* batch-driver.scm:613: perform-high-level-optimizations */
t2=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4]);}}

/* k2592 in k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in ... */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:610: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t2,t3);}

/* k2589 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in ... */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:609: begin-time */
t3=((C_word*)((C_word*)t0)[10])[1];
f_1957(t3,t2);}

/* k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4651,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4651(t6,t2,t1);}

/* k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1655,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[14]+1);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t6,a[10]=t4,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4688,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:72: get-environment-variable */
t10=*((C_word*)lf[399]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[400]);}

/* k3012 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in ... */
static void C_ccall f_3014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_2891(2,t3,t2);}
else{
/* batch-driver.scm:543: quit */
t2=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[175]);}}

/* k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1666,NULL,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_memq(lf[18],t3);
t5=(C_truep(t4)?C_i_cadr(t4):C_SCHEME_FALSE);
t6=t5;
t7=((C_word*)t0)[2];
t8=C_u_i_memq(lf[19],t7);
t9=((C_word*)t0)[2];
t10=C_u_i_memq(lf[20],t9);
t11=((C_word*)t0)[2];
t12=C_u_i_memq(lf[21],t11);
t13=C_SCHEME_END_OF_LIST;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=((C_word*)t0)[2];
t16=C_u_i_memq(lf[22],t15);
t17=((C_word*)t0)[2];
t18=C_u_i_memq(lf[23],t17);
t19=((C_word*)t0)[2];
t20=C_u_i_memq(lf[24],t19);
t21=C_SCHEME_TRUE;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=((C_word*)t0)[2];
t24=C_u_i_memq(lf[25],t23);
t25=C_SCHEME_FALSE;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_FALSE;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_FALSE;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=((C_word*)t0)[2];
t32=C_u_i_memq(lf[26],t31);
t33=((C_word*)t0)[2];
t34=C_u_i_memq(lf[27],t33);
t35=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1692,a[2]=t26,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t30,a[8]=((C_word*)t0)[6],a[9]=t14,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=t28,a[14]=t12,a[15]=((C_word*)t0)[10],a[16]=t20,a[17]=t18,a[18]=((C_word*)t0)[11],a[19]=t24,a[20]=((C_word*)t0)[12],a[21]=t22,a[22]=((C_word*)t0)[13],a[23]=t6,a[24]=t32,a[25]=((C_word*)t0)[14],a[26]=t2,a[27]=t8,a[28]=((C_word*)t0)[15],a[29]=t10,a[30]=t16,tmp=(C_word)a,a+=31,tmp);
if(C_truep(t34)){
t36=t35;
f_1692(t36,t34);}
else{
t36=((C_word*)t0)[2];
t37=t35;
f_1692(t37,C_u_i_memq(lf[396],t36));}}

/* map-loop867 in k3369 in k3365 in k3353 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in ... */
static void C_fcall f_3412(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(27);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3412,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_list(&a,2,lf[226],t4);
t6=C_u_i_cdr(t3);
t7=C_a_i_list(&a,2,lf[226],t6);
t8=C_a_i_list(&a,4,lf[227],*((C_word*)lf[228]+1),t5,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t18=t1;
t19=t12;
t1=t18;
t2=t19;
goto loop;}
else{
t10=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t18=t1;
t19=t12;
t1=t18;
t2=t19;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f5451 in k3070 in k3061 in for-each-loop1006 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in ... */
static void C_ccall f5451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1661,2,t0,t1);}
t2=t1;
t3=*((C_word*)lf[15]+1);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=lf[16];
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=((C_word*)t0)[2];
t17=C_u_i_memq(lf[17],t16);
t18=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t11,a[12]=t13,a[13]=t15,a[14]=t9,a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t17)){
t19=t18;
f_1666(t19,t17);}
else{
t19=((C_word*)t0)[2];
t20=C_u_i_memq(lf[273],t19);
if(C_truep(t20)){
t21=t18;
f_1666(t21,t20);}
else{
t21=((C_word*)t0)[2];
t22=C_u_i_memq(lf[18],t21);
t23=t18;
f_1666(t23,t22);}}}

/* f5443 in for-each-loop1027 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in ... */
static void C_ccall f5443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in ... */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=((C_word*)t0)[6];
if(C_truep(C_u_i_memq(lf[337],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4357,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5565,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t6,*((C_word*)lf[110]+1),lf[339],C_SCHEME_END_OF_LIST);}
else{
t4=t2;
f_2214(2,t4,C_SCHEME_UNDEFINED);}}

/* k2843 in k2840 in k2837 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in ... */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2845,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=t2;
t4=C_a_i_list(&a,1,((C_word*)((C_word*)t0)[2])[1]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5431,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t5,*((C_word*)lf[110]+1),lf[145],t4);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_2575(2,t3,t2);}}

/* f5431 in k2843 in k2840 in k2837 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in ... */
static void C_ccall f5431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1602,2,t0,t1);}
t2=C_mutate2((C_word*)lf[3]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1606,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:40: make-parameter */
t4=*((C_word*)lf[408]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_FALSE);}

/* compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1608r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1608r(t0,t1,t2,t3);}}

static void C_ccall f_1608r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1611,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1642,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:53: initialize-compiler */
t6=*((C_word*)lf[407]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1606,2,t0,t1);}
t2=C_mutate2((C_word*)lf[4]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate2((C_word*)lf[5]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1608,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2840 in k2837 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in ... */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[28]+1);
if(C_truep(C_u_i_memq(lf[146],*((C_word*)lf[28]+1)))){
/* batch-driver.scm:594: dump-global-refs */
t4=*((C_word*)lf[147]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[4]);}
else{
t4=t2;
f_2845(2,t4,C_SCHEME_UNDEFINED);}}

/* k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in ... */
static void C_fcall f_2200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2200,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[61],t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2205,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t3)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4406,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:245: option-arg */
f_1611(t5,t3);}
else{
t5=t4;
f_2205(t5,C_SCHEME_FALSE);}}

/* k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in ... */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=((C_word*)t0)[6];
if(C_truep(C_u_i_memq(lf[329],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4332,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5553,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t6,*((C_word*)lf[110]+1),lf[334],C_SCHEME_END_OF_LIST);}
else{
t4=t2;
f_2220(2,t4,C_SCHEME_UNDEFINED);}}

/* k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in ... */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=((C_word*)t0)[6];
if(C_truep(C_u_i_memq(lf[335],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4349,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5559,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t6,*((C_word*)lf[110]+1),lf[336],C_SCHEME_END_OF_LIST);}
else{
t4=t2;
f_2217(2,t4,C_SCHEME_UNDEFINED);}}

/* map-loop660 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in ... */
static void C_fcall f_3744(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3744,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3773,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:415: g666 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f5425 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in ... */
static void C_ccall f5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in ... */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[35])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4363,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:253: option-arg */
f_1611(t3,((C_word*)t0)[35]);}
else{
t3=t2;
f_2211(2,t3,C_SCHEME_UNDEFINED);}}

/* k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in ... */
static void C_fcall f_2205(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2205,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[6];
if(C_truep(C_u_i_memq(lf[346],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4396,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5571,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t6,*((C_word*)lf[110]+1),lf[347],C_SCHEME_END_OF_LIST);}
else{
t4=t2;
f_2208(2,t4,C_SCHEME_UNDEFINED);}}

/* f5413 */
static void C_ccall f5413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k4014 in for-each-loop543 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in ... */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4006(t3,((C_word*)t0)[4],t2);}

/* f5419 in k2752 in k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in ... */
static void C_ccall f5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k2849 in k2843 in k2840 in k2837 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in k2549 in k2546 in k2540 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in ... */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:598: emit-type-file */
t2=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4]);}

/* f5407 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in ... */
static void C_ccall f5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_mutate2((C_word*)lf[9]+1 /* (set! ##compiler#explicit-use-flag ...) */,C_u_i_memq(lf[10],t2));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[9]+1))){
/* batch-driver.scm:56: append */
t5=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[405]+1),C_SCHEME_END_OF_LIST);}
else{
t5=C_a_i_cons(&a,2,lf[240],*((C_word*)lf[406]+1));
t6=C_a_i_list(&a,1,t5);
/* batch-driver.scm:56: append */
t7=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,*((C_word*)lf[405]+1),t6);}}

/* k4355 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in ... */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:260: parenthesis-synonyms */
t2=*((C_word*)lf[338]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in ... */
static void C_fcall f_2163(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2163,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[362],t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[22],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5577,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t6,*((C_word*)lf[110]+1),lf[363],C_SCHEME_END_OF_LIST);}
else{
t4=t2;
f_2166(t4,C_SCHEME_UNDEFINED);}}

/* k3573 in map-loop767 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in ... */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3575,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3546(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3546(t6,((C_word*)t0)[5],t5);}}

/* k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in ... */
static void C_fcall f_2160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2160,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[364],t3))){
t4=C_set_block_item(lf[365] /* ##compiler#strict-variable-types */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[52] /* ##compiler#enable-specialization */,0,C_SCHEME_TRUE);
t6=t2;
f_2163(t6,t5);}
else{
t4=t2;
f_2163(t4,C_SCHEME_UNDEFINED);}}

/* f5463 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in ... */
static void C_ccall f5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* for-each-loop543 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in ... */
static void C_fcall f_4006(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4006,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4016,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:309: g544 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in ... */
static void C_fcall f_2169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2169,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[157],t3))){
t4=C_set_block_item(lf[157] /* unsafe */,0,C_SCHEME_TRUE);
t5=t2;
f_2172(t5,t4);}
else{
t4=t2;
f_2172(t4,C_SCHEME_UNDEFINED);}}

/* k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in ... */
static void C_fcall f_2166(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2166,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[99],t3))){
t4=C_set_block_item(lf[99] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t5=t2;
f_2169(t5,t4);}
else{
t4=t2;
f_2169(t4,C_SCHEME_UNDEFINED);}}

/* k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in ... */
static void C_fcall f_2151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2151,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[368],t3))){
t4=C_set_block_item(lf[350] /* ##compiler#local-definitions */,0,C_SCHEME_TRUE);
t5=t2;
f_2154(t5,t4);}
else{
t4=t2;
f_2154(t4,C_SCHEME_UNDEFINED);}}

/* k4361 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in ... */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_string_equal_p(lf[340],t1))){
/* batch-driver.scm:254: keyword-style */
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[341]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[342],t1))){
/* batch-driver.scm:255: keyword-style */
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[332]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[343],t1))){
/* batch-driver.scm:256: keyword-style */
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[344]);}
else{
/* batch-driver.scm:257: quit */
t2=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[345]);}}}}

/* k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in ... */
static void C_fcall f_2154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2154,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[367],t3))){
t4=C_set_block_item(lf[181] /* ##compiler#enable-inline-files */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[177] /* ##compiler#inline-locally */,0,C_SCHEME_TRUE);
t6=t2;
f_2157(t6,t5);}
else{
t4=t2;
f_2157(t4,C_SCHEME_UNDEFINED);}}

/* k3113 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in ... */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm:519: pp */
t2=*((C_word*)lf[186]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_2530(2,t2,C_SCHEME_UNDEFINED);}}

/* k1578 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1581 in k1578 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in ... */
static void C_fcall f_2157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2157,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=C_set_block_item(lf[366] /* ##sys#notices-enabled */,0,C_SCHEME_TRUE);
t4=t2;
f_2160(t4,t3);}
else{
t3=t2;
f_2160(t3,C_SCHEME_UNDEFINED);}}

/* k1584 in k1581 in k1578 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:36: make-parameter */
t3=*((C_word*)lf[408]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_FALSE);}

/* k2894 in for-each-loop1050 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in ... */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* batch-driver.scm:547: quit */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[172],((C_word*)t0)[3]);}}

/* k4336 in k4333 in k4330 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in ... */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:268: parentheses-synonyms */
t3=*((C_word*)lf[331]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_FALSE);}

/* a4028 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in ... */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4029,3,t0,t1,t2);}
t3=*((C_word*)lf[305]+1);
/* batch-driver.scm:311: g559 */
t4=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[306]);}

/* k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in ... */
static void C_fcall f_2184(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2184,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[352],t3))){
t4=C_set_block_item(lf[353] /* ##compiler#external-protos-first */,0,C_SCHEME_TRUE);
t5=t2;
f_2187(t5,t4);}
else{
t4=t2;
f_2187(t4,C_SCHEME_UNDEFINED);}}

/* k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in ... */
static void C_fcall f_2181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2181,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[354],t3))){
t4=C_set_block_item(lf[355] /* ##compiler#block-compilation */,0,C_SCHEME_TRUE);
t5=t2;
f_2184(t5,t4);}
else{
t4=t2;
f_2184(t4,C_SCHEME_UNDEFINED);}}

/* k4330 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in ... */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:266: case-sensitive */
t3=*((C_word*)lf[333]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_FALSE);}

/* k4333 in k4330 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in ... */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:267: keyword-style */
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[332]);}

/* k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in ... */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm:548: collect-options */
t3=((C_word*)((C_word*)t0)[12])[1];
f_1922(t3,t2,lf[173]);}

/* k3099 in for-each-loop1006 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in ... */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3091(t3,((C_word*)t0)[4],t2);}

/* k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1590,2,t0,t1);}
t2=C_mutate2((C_word*)lf[0]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:37: make-parameter */
t4=*((C_word*)lf[408]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_FALSE);}

/* k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1594,2,t0,t1);}
t2=C_mutate2((C_word*)lf[1]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:38: make-parameter */
t4=*((C_word*)lf[408]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_FALSE);}

/* k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in ... */
static void C_fcall f_2187(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2187,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[351],t3))){
t4=C_set_block_item(lf[177] /* ##compiler#inline-locally */,0,C_SCHEME_TRUE);
t5=t2;
f_2190(t5,t4);}
else{
t4=t2;
f_2190(t4,C_SCHEME_UNDEFINED);}}

/* k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
t2=C_mutate2((C_word*)lf[2]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1602,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:39: make-parameter */
t4=*((C_word*)lf[408]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_FALSE);}

/* k4347 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in ... */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:263: symbol-escape */
t2=*((C_word*)lf[330]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in ... */
static void C_fcall f_2172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2172,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[360],t3))){
t4=C_set_block_item(lf[361] /* ##sys#setup-mode */,0,C_SCHEME_TRUE);
t5=t2;
f_2175(t5,t4);}
else{
t4=t2;
f_2175(t4,C_SCHEME_UNDEFINED);}}

/* k4339 in k4336 in k4333 in k4330 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in ... */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:269: symbol-escape */
t2=*((C_word*)lf[330]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4068 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in ... */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:308: append-map */
t2=*((C_word*)lf[307]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k4627 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2((C_word*)lf[203]+1 /* (set! ##compiler#unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_2073(t3,t2);}

/* k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in ... */
static void C_fcall f_2175(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2175,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[359],t3))){
t4=C_set_block_item(lf[131] /* ##compiler#insert-timer-checks */,0,C_SCHEME_FALSE);
t5=t2;
f_2178(t5,t4);}
else{
t4=t2;
f_2178(t4,C_SCHEME_UNDEFINED);}}

/* k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in ... */
static void C_fcall f_2178(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2178,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[356],t3))){
t4=C_mutate2((C_word*)lf[357]+1 /* (set! number-type ...) */,lf[358]);
t5=t2;
f_2181(t5,t4);}
else{
t4=t2;
f_2181(t4,C_SCHEME_UNDEFINED);}}

/* k4047 in for-each-loop518 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in ... */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4039(t3,((C_word*)t0)[4],t2);}

/* map-loop767 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in ... */
static void C_fcall f_3546(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3546,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3575,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:442: g773 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4635 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:168: stringify */
t2=*((C_word*)lf[395]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4631 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:168: string->c-identifier */
t2=*((C_word*)lf[394]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2752 in k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in ... */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=t3;
t5=C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5419,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t6,*((C_word*)lf[110]+1),lf[119],t5);}

/* k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in ... */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[4])){
/* batch-driver.scm:673: open-output-file */
t3=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t3=t2;
f_2754(2,t3,*((C_word*)lf[29]+1));}}

/* k2755 in k2752 in k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in ... */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:675: generate-code */
t3=*((C_word*)lf[118]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[10],((C_word*)t0)[11]);}

/* k4094 in for-each-loop419 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in ... */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],((C_word*)t0)[3],lf[314],C_SCHEME_TRUE);}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],((C_word*)t0)[3],lf[314],t3);}}

/* k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in ... */
static void C_fcall f_2190(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2190,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[59],t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t3)){
t5=C_set_block_item(lf[177] /* ##compiler#inline-locally */,0,C_SCHEME_TRUE);
t6=C_set_block_item(lf[350] /* ##compiler#local-definitions */,0,C_SCHEME_TRUE);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[19],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:240: option-arg */
f_1611(t7,t3);}
else{
t5=t4;
f_2195(t5,C_SCHEME_FALSE);}}

/* k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in ... */
static void C_fcall f_2195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2195,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[60],t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t3)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[21],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:242: option-arg */
f_1611(t5,t3);}
else{
t5=t4;
f_2200(t5,C_SCHEME_FALSE);}}

/* a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in k2552 in ... */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2744,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2748,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t4,a[7]=t5,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm:670: end-time */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1967(t7,t6,lf[121]);}

/* k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in k2577 in k2573 in k2570 in k2567 in loop in k2558 in k2555 in ... */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:671: begin-time */
t3=((C_word*)((C_word*)t0)[11])[1];
f_1957(t3,t2);}

/* a4061 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in ... */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4062,3,t0,t1,t2);}
t3=*((C_word*)lf[305]+1);
/* batch-driver.scm:308: g534 */
t4=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[309]);}

/* for-each-loop1006 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in ... */
static void C_fcall f_3091(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3091,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3101,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3063,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3086,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:524: symbol->string */
t9=*((C_word*)lf[171]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f5481 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in ... */
static void C_ccall f5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* f5487 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in ... */
static void C_ccall f5487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* map-loop78 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_4651(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4651,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4680,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:70: g84 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in ... */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5407,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t3,*((C_word*)lf[110]+1),lf[111],C_SCHEME_END_OF_LIST);}

/* k3061 in for-each-loop1006 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in ... */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3063,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3072,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:526: file-exists? */
t4=*((C_word*)lf[183]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k3671 in k3667 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in ... */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_2442(2,t3,t2);}

/* for-each-loop1027 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in ... */
static void C_fcall f_3037(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3037,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3047,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3026,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t7;
t9=C_a_i_list(&a,1,t6);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5443,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t10,*((C_word*)lf[110]+1),lf[179],t9);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in ... */
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3678,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=*((C_word*)lf[246]+1);
t9=C_i_check_list_2(((C_word*)t0)[3],lf[55]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3696,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3744,a[2]=t7,a[3]=t12,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_3744(t14,t10,((C_word*)t0)[3]);}
else{
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3783,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:419: check-and-open-input-file */
t6=*((C_word*)lf[252]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}

/* k3084 in for-each-loop1006 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in ... */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:524: make-pathname */
t2=*((C_word*)lf[169]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[185]);}

/* k3080 in for-each-loop1006 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in ... */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:523: ##sys#resolve-include-filename */
t2=*((C_word*)lf[184]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3218 in map-loop942 in k3177 in k3174 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in ... */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3191(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3191(t6,((C_word*)t0)[5],t5);}}

/* k2782 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in a2743 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2709 in k2706 in k2703 in k2700 in k2583 in k2580 in ... */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:680: ##sys#display-times */
t2=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3694 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in ... */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3696,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:416: reverse */
t4=*((C_word*)lf[247]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k2104 in k2100 in map-loop308 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in ... */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2106,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k3687 in doloop655 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in ... */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2100 in map-loop308 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in ... */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2106,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#string-append */
t4=*((C_word*)lf[385]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[386]);}

/* map-loop800 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in ... */
static void C_fcall f_3511(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3511,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_u_i_car(t3);
t6=C_a_i_list(&a,2,lf[226],t5);
t7=C_a_i_list(&a,3,lf[231],t4,t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t9=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t8);
t10=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t8);
t11=C_slot(t2,C_fix(1));
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}
else{
t9=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t8);
t10=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t8);
t11=C_slot(t2,C_fix(1));
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f5507 in k3863 in k3857 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in ... */
static void C_ccall f5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* f5501 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in ... */
static void C_ccall f5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k3073 in k3070 in k3061 in for-each-loop1006 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in ... */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:528: load-inline-file */
t2=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3070 in k3061 in for-each-loop1006 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in ... */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3072,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=t2;
t4=C_a_i_list(&a,1,((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5451,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t5,*((C_word*)lf[110]+1),lf[182],t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3237 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in ... */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[110]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:488: ##sys#print */
t6=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[207],C_SCHEME_FALSE,t3);}

/* k3249 in k3246 in k3243 in k3237 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in ... */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3254,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:488: get-output-string */
t3=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f5535 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in ... */
static void C_ccall f5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in ... */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[2],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t4=((C_word*)t0)[5];
if(C_truep(C_u_i_memq(lf[324],t4))){
t5=C_set_block_item(lf[325] /* ##compiler#undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t6=t3;
f_2236(t6,t5);}
else{
t5=t3;
f_2236(t5,C_SCHEME_UNDEFINED);}}

/* k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in ... */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2905,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[41]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2985,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_2985(t7,t3,t1);}

/* k4321 in map-loop364 in k4284 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in ... */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4323,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4294(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4294(t6,((C_word*)t0)[5],t5);}}

/* k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in ... */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2117,2,t0,t1);}
t2=C_mutate2((C_word*)lf[56]+1 /* (set! ##compiler#import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t4=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[383],t4))){
if(C_truep(((C_word*)t0)[17])){
t5=t3;
f_2120(t5,C_SCHEME_UNDEFINED);}
else{
t5=C_set_block_item(lf[384] /* ##compiler#all-import-libraries */,0,C_SCHEME_TRUE);
t6=t3;
f_2120(t6,t5);}}
else{
t5=t3;
f_2120(t5,C_SCHEME_UNDEFINED);}}

/* k3243 in k3237 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in ... */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:488: ##sys#print */
t3=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[203]+1),C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3246 in k3243 in k3237 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in ... */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:488: ##sys#print */
t3=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[206],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 in ... */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[55]);
t3=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[37],a[3]=t5,a[4]=((C_word*)t0)[38],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4517(t7,t3,t1);}

/* k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in ... */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
t2=C_mutate2((C_word*)lf[62]+1 /* (set! ##compiler#verbose-mode ...) */,((C_word*)t0)[2]);
t3=C_set_block_item(lf[63] /* ##sys#read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=*((C_word*)lf[14]+1);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4286,a[2]=t4,a[3]=((C_word*)t0)[34],a[4]=t8,a[5]=t6,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:273: collect-options */
t11=((C_word*)((C_word*)t0)[23])[1];
f_1922(t11,t10,lf[328]);}

/* k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in ... */
static void C_fcall f_2236(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2236,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[322],t3))){
t4=C_set_block_item(lf[323] /* ##compiler#no-argc-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_2239(t5,t4);}
else{
t4=t2;
f_2239(t4,C_SCHEME_UNDEFINED);}}

/* k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in ... */
static void C_fcall f_2239(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2239,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[320],t3))){
t4=C_set_block_item(lf[321] /* ##compiler#no-bound-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_2242(t5,t4);}
else{
t4=t2;
f_2242(t4,C_SCHEME_UNDEFINED);}}

/* f5519 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in ... */
static void C_ccall f5519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in ... */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=*((C_word*)lf[28]+1);
if(C_truep(C_u_i_memq(lf[34],*((C_word*)lf[28]+1)))){
/* batch-driver.scm:303: load-verbose */
t4=*((C_word*)lf[311]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,C_SCHEME_TRUE);}
else{
t4=t2;
f_2254(2,t4,C_SCHEME_UNDEFINED);}}

/* k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in ... */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2254,2,t0,t1);}
t2=*((C_word*)lf[65]+1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_2257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=t2,tmp=(C_word)a,a+=34,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4062,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4070,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:308: collect-options */
t6=((C_word*)((C_word*)t0)[21])[1];
f_1922(t6,t5,lf[310]);}

/* k2918 in for-each-loop1071 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in ... */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:551: load-type-database */
t2=*((C_word*)lf[168]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2922 in for-each-loop1071 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in ... */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:551: make-pathname */
t2=*((C_word*)lf[169]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[170]);}

/* k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in ... */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2226,2,t0,t1);}
t2=C_mutate2((C_word*)lf[64]+1 /* (set! ##sys#include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[14])){
if(C_truep(((C_word*)t0)[7])){
if(C_truep(C_i_string_equal_p(((C_word*)t0)[14],((C_word*)t0)[7]))){
/* batch-driver.scm:277: quit */
t4=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[327]);}
else{
t4=t3;
f_2229(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2229(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2229(2,t4,C_SCHEME_UNDEFINED);}}

/* k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in ... */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4224,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4270,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:281: collect-options */
t5=((C_word*)((C_word*)t0)[22])[1];
f_1922(t5,t4,lf[240]);}

/* k4035 in k2258 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in ... */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:311: append-map */
t2=*((C_word*)lf[307]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* for-each-loop518 in k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in ... */
static void C_fcall f_4039(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4039,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4049,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:306: g519 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2925 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in ... */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:553: begin-time */
t3=((C_word*)((C_word*)t0)[8])[1];
f_1957(t3,t2);}

/* f5513 in k3863 in k3857 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in k2255 in k2252 in ... */
static void C_ccall f5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in ... */
static void C_fcall f_2245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2245,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[316],t3))){
t4=C_set_block_item(lf[317] /* ##compiler#no-global-procedure-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_2248(t5,t4);}
else{
t4=t2;
f_2248(t4,C_SCHEME_UNDEFINED);}}

/* k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in ... */
static void C_fcall f_2242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2242,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[318],t3))){
t4=C_set_block_item(lf[319] /* ##compiler#no-procedure-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_2245(t5,t4);}
else{
t4=t2;
f_2245(t4,C_SCHEME_UNDEFINED);}}

/* arg-val in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1832(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1832,NULL,2,t1,t2);}
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
if(C_truep(C_fixnum_lessp(t3,C_fix(2)))){
t5=C_a_i_string_to_number(&a,2,t2,C_fix(10));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* batch-driver.scm:141: quit */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[43],t2);}}
else{
t5=C_i_string_ref(t2,t4);
t6=C_eqp(t5,C_make_character(109));
t7=(C_truep(t6)?t6:C_eqp(t5,C_make_character(77)));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1881,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:138: substring */
t9=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,t2,C_fix(0),t4);}
else{
t8=C_eqp(t5,C_make_character(107));
t9=(C_truep(t8)?t8:C_eqp(t5,C_make_character(75)));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1901,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:139: substring */
t11=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t10,t2,C_fix(0),t4);}
else{
t10=C_a_i_string_to_number(&a,2,t2,C_fix(10));
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
/* batch-driver.scm:141: quit */
t11=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[43],t2);}}}}}

/* k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in ... */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2962,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2962(t6,t2,((C_word*)t0)[11]);}

/* k2255 in k2252 in k2249 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in ... */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4039,a[2]=t4,a[3]=((C_word*)t0)[33],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4039(t6,t2,t1);}

/* for-each-loop164 in k1791 in print-expr in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1809(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1809,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1819,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1798,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:128: pretty-print */
t7=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2939 in k2936 in k2933 in k2928 in k2925 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in ... */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:558: begin-time */
t3=((C_word*)((C_word*)t0)[8])[1];
f_1957(t3,t2);}

/* k2942 in k2939 in k2936 in k2933 in k2928 in k2925 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in ... */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:559: debugging */
t3=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[34],lf[163]);}

/* k2945 in k2942 in k2939 in k2936 in k2933 in k2928 in k2925 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in ... */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:560: scrutinize */
t3=*((C_word*)lf[162]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],*((C_word*)lf[52]+1));}

/* f5571 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in ... */
static void C_ccall f5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* f5577 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in ... */
static void C_ccall f5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* k4678 in map-loop78 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4680,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4651(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4651(t6,((C_word*)t0)[5],t5);}}

/* k4686 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* batch-driver.scm:71: string-split */
t3=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[397]);}
else{
/* batch-driver.scm:71: string-split */
t2=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[398],lf[397]);}}

/* k2928 in k2925 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in ... */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2930,2,t0,t1);}
t2=C_set_block_item(lf[94] /* ##compiler#first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:555: analyze */
t4=((C_word*)((C_word*)t0)[10])[1];
f_2007(t4,t3,lf[167],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k2933 in k2928 in k2925 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in ... */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:556: print-db */
t4=((C_word*)((C_word*)t0)[9])[1];
f_1759(t4,t3,lf[165],lf[166],((C_word*)((C_word*)t0)[2])[1],C_fix(0));}

/* k2936 in k2933 in k2928 in k2925 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in ... */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:557: end-time */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1967(t3,t2,lf[164]);}

/* g72 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_4692(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4692,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4696,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:64: option-arg */
f_1611(t3,t2);}

/* k4694 in g72 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_symbolp(t1))){
/* batch-driver.scm:66: symbol->string */
t2=*((C_word*)lf[171]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k4397 in k4394 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in ... */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:251: case-sensitive */
t2=*((C_word*)lf[333]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4394 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in k2140 in k2137 in ... */
static void C_ccall f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:250: register-feature! */
t3=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[346]);}

/* k1779 in k1776 in k1773 in k1770 in k1764 in print-db in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 in ... */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:122: display-analysis-database */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* print-expr in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_fcall f_1786(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1786,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1793,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:125: print-header */
f_1710(t5,t2,t3);}

/* k3177 in k3174 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in ... */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3179,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[2];
t7=((C_word*)((C_word*)t0)[3])[1];
t8=C_i_check_list_2(t7,lf[55]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3191,a[2]=t5,a[3]=t11,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_3191(t13,t9,t7);}

/* k1817 in for-each-loop164 in k1791 in print-expr in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1809(t3,((C_word*)t0)[4],t2);}

/* k3174 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in ... */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:502: begin-time */
t3=((C_word*)((C_word*)t0)[6])[1];
f_1957(t3,t2);}

/* k3171 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in ... */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:509: build-node-graph */
t2=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3395 in k3369 in k3365 in k3353 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in ... */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=*((C_word*)lf[203]+1);
if(C_truep(*((C_word*)lf[203]+1))){
/* batch-driver.scm:451: append */
t3=*((C_word*)lf[224]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1,((C_word*)t0)[6],C_SCHEME_END_OF_LIST,lf[225]);}
else{
if(C_truep(((C_word*)t0)[7])){
/* batch-driver.scm:451: append */
t3=*((C_word*)lf[224]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1,((C_word*)t0)[6],C_SCHEME_END_OF_LIST,lf[225]);}
else{
t3=((C_word*)((C_word*)t0)[8])[1];
/* batch-driver.scm:451: append */
t4=*((C_word*)lf[224]+1);
((C_proc9)(void*)(*((C_word*)t4+1)))(9,t4,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1,((C_word*)t0)[6],t3,lf[225]);}}}

/* f5565 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2170 in k2167 in k2164 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2143 in ... */
static void C_ccall f5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:104: debugging */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[34],t1);}

/* map-loop942 in k3177 in k3174 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in ... */
static void C_fcall f_3191(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3191,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3220,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:503: g948 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in ... */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3169,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=C_a_i_record4(&a,4,lf[89],lf[90],lf[91],t2);
t4=t3;
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t4,a[18]=((C_word*)t0)[17],a[19]=t6,a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm:512: print-node */
t8=((C_word*)((C_word*)t0)[6])[1];
f_1737(t8,t7,lf[193],lf[194],t4);}

/* k3159 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in ... */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:516: concatenate */
t2=*((C_word*)lf[189]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4605 in map-loop280 in k4571 in a4559 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in ... */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4578(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4578(t6,((C_word*)t0)[5],t5);}}

/* k1791 in print-expr in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_check_list_2(t2,lf[41]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1809,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_1809(t7,((C_word*)t0)[3],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4613 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:176: append-map */
t2=*((C_word*)lf[307]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k1796 in for-each-loop164 in k1791 in print-expr in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:129: newline */
t2=*((C_word*)lf[42]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3184 in k3177 in k3174 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in ... */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* batch-driver.scm:504: end-time */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1967(t3,((C_word*)t0)[4],lf[197]);}

/* k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in ... */
static void C_fcall f_2120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2120,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[57],t2);
t4=C_i_not(t3);
t5=C_mutate2((C_word*)lf[58]+1 /* (set! ##compiler#enable-module-registration ...) */,t4);
t6=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep(*((C_word*)lf[52]+1))){
t7=C_set_block_item(((C_word*)t0)[22],0,C_SCHEME_TRUE);
t8=t6;
f_2127(t8,t7);}
else{
t7=t6;
f_2127(t7,C_SCHEME_UNDEFINED);}}

/* k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in ... */
static void C_fcall f_2127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2127,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_2130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=*((C_word*)lf[28]+1);
if(C_truep(C_u_i_memq(lf[113],*((C_word*)lf[28]+1)))){
/* batch-driver.scm:196: ##sys#start-timer */
t4=*((C_word*)lf[382]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=t2;
f_2130(2,t4,C_SCHEME_UNDEFINED);}}

/* k3320 in for-each-loop898 in k3276 in a3273 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in ... */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3312(t3,((C_word*)t0)[4],t2);}

/* k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in ... */
static void C_fcall f_2145(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2145,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[371],t3))){
t4=C_set_block_item(lf[372] /* ##compiler#emit-closure-info */,0,C_SCHEME_FALSE);
t5=t2;
f_2148(t5,t4);}
else{
t4=t2;
f_2148(t4,C_SCHEME_UNDEFINED);}}

/* k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in ... */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2145,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[373],t3))){
t4=C_set_block_item(lf[9] /* ##compiler#explicit-use-flag */,0,C_SCHEME_TRUE);
t5=C_set_block_item(((C_word*)t0)[25],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_END_OF_LIST);
t7=t2;
f_2145(t7,t6);}
else{
t4=t2;
f_2145(t4,C_SCHEME_UNDEFINED);}}

/* for-each-loop898 in k3276 in a3273 in k2476 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in ... */
static void C_fcall f_3312(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3312,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3322,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=*((C_word*)lf[29]+1);
t8=*((C_word*)lf[29]+1);
t9=C_i_check_port_2(*((C_word*)lf[29]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[30]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3286,a[2]=t5,a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:479: ##sys#print */
t11=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t10,lf[217],C_SCHEME_FALSE,*((C_word*)lf[29]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2146 in k2143 in k2140 in k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in ... */
static void C_fcall f_2148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2148,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[369],t3))){
t4=C_set_block_item(lf[370] /* ##compiler#compiler-syntax-enabled */,0,C_SCHEME_FALSE);
t5=t2;
f_2151(t5,t4);}
else{
t4=t2;
f_2151(t4,C_SCHEME_UNDEFINED);}}

/* k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in ... */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=*((C_word*)lf[28]+1);
if(C_truep(C_u_i_memq(lf[381],*((C_word*)lf[28]+1)))){
t4=C_set_block_item(((C_word*)t0)[36],0,C_SCHEME_TRUE);
t5=t2;
f_2133(t5,t4);}
else{
t4=t2;
f_2133(t4,C_SCHEME_UNDEFINED);}}

/* k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in ... */
static void C_fcall f_2133(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2133,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[379],t3))){
/* batch-driver.scm:199: warning */
t4=*((C_word*)lf[375]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,lf[380]);}
else{
t4=t2;
f_2136(2,t4,C_SCHEME_UNDEFINED);}}

/* k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in k1600 in ... */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[377],t3))){
/* batch-driver.scm:201: warning */
t4=*((C_word*)lf[375]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,lf[378]);}
else{
t4=t2;
f_2139(2,t4,C_SCHEME_UNDEFINED);}}

/* k2137 in k2134 in k2131 in k2128 in k2125 in k2118 in k2115 in k2109 in k2087 in k2084 in k2077 in k2074 in k2071 in k1690 in k1664 in k1659 in k1656 in k1653 in k4729 in k1640 in compile-source-file in k1604 in ... */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[374],t3))){
/* batch-driver.scm:203: warning */
t4=*((C_word*)lf[375]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,lf[376]);}
else{
t4=t2;
f_2142(2,t4,C_SCHEME_UNDEFINED);}}

/* k3365 in k3353 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in ... */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3367,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(*((C_word*)lf[229]+1))){
t4=C_a_i_list(&a,2,lf[226],((C_word*)t0)[7]);
t5=*((C_word*)lf[203]+1);
t6=(C_truep(*((C_word*)lf[203]+1))?C_a_i_list(&a,2,lf[226],C_SCHEME_FALSE):(C_truep(((C_word*)t0)[8])?C_a_i_list(&a,2,lf[226],((C_word*)t0)[8]):C_a_i_list(&a,2,lf[226],C_SCHEME_TRUE)));
t7=C_a_i_list(&a,3,lf[230],t4,t6);
t8=C_a_i_list(&a,3,lf[231],*((C_word*)lf[228]+1),t7);
t9=t3;
f_3371(t9,C_a_i_list(&a,1,t8));}
else{
t4=t3;
f_3371(t4,C_SCHEME_END_OF_LIST);}}

/* k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in ... */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2427,2,t0,t1);}
t2=C_mutate2((C_word*)lf[85]+1 /* (set! ##sys#line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:400: collect-options */
t4=((C_word*)((C_word*)t0)[18])[1];
f_1922(t4,t3,lf[256]);}

/* k3353 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in ... */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3355,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[223]+1);
t8=C_i_check_list_2(*((C_word*)lf[223]+1),lf[55]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3476,a[2]=t6,a[3]=t11,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_3476(t13,t9,*((C_word*)lf[223]+1));}

/* k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in ... */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2423,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:399: make-vector */
t4=*((C_word*)lf[257]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[258]+1),C_SCHEME_END_OF_LIST);}

/* k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in ... */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:101: current-milliseconds */
t3=*((C_word*)lf[45]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in ... */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:395: debugging */
t3=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[259],lf[260],*((C_word*)lf[71]+1));}

/* for-each-loop1071 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in ... */
static void C_fcall f_2962(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2962,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2972,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2920,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2924,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:551: symbol->string */
t8=*((C_word*)lf[171]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3024 in for-each-loop1027 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in k2470 in k2467 in ... */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:536: load-inline-file */
t2=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in ... */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:394: debugging */
t3=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[259],lf[261],*((C_word*)lf[70]+1));}

/* k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in k2301 in k2293 in k2289 in k2274 in k2271 in k2264 in k2261 in k2258 in ... */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:393: debugging */
t3=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[259],lf[262],*((C_word*)lf[28]+1));}

/* k4718 in k4729 in k1640 in compile-source-file in k1604 in k1600 in k1596 in k1592 in k1588 in k1584 in k1581 in k1578 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:69: make-pathname */
t2=*((C_word*)lf[169]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[402]);}

/* k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in ... */
static void C_fcall f_2448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2448,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:435: print-expr */
t3=((C_word*)((C_word*)t0)[20])[1];
f_1786(t3,t2,lf[242],lf[243],((C_word*)((C_word*)t0)[25])[1]);}

/* k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2928 in k2925 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in ... */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[52]+1))){
/* batch-driver.scm:563: print-node */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1737(t3,t2,lf[159],lf[160],((C_word*)t0)[4]);}
else{
t3=C_set_block_item(lf[94] /* ##compiler#first-analysis */,0,C_SCHEME_TRUE);
t4=((C_word*)t0)[2];
f_2542(t4,t3);}}

/* k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2928 in k2925 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in ... */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:561: end-time */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1967(t3,t2,lf[161]);}

/* k3369 in k3365 in k3353 in k2470 in k2467 in k2461 in k2458 in k2455 in k2452 in k2449 in k2446 in k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in ... */
static void C_fcall f_3371(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3371,NULL,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[87]+1);
t8=C_i_check_list_2(*((C_word*)lf[87]+1),lf[55]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3412,a[2]=t6,a[3]=t11,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_3412(t13,t9,*((C_word*)lf[87]+1));}

/* k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2928 in k2925 in k2909 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in ... */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[94] /* ##compiler#first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_2542(t3,t2);}

/* k2443 in k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in ... */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2445,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3624,a[2]=t2,a[3]=((C_word*)t0)[25],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5481,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t6,*((C_word*)lf[110]+1),lf[244],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_2448(t4,C_SCHEME_UNDEFINED);}}

/* k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in ... */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:430: user-preprocessor-pass */
t3=*((C_word*)lf[2]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4117 in k2246 in k2243 in k2240 in k2237 in k2234 in k2231 in k2227 in k2224 in k2218 in k2215 in k2212 in k2209 in k2206 in k2203 in k2198 in k2193 in k2188 in k2185 in k2182 in k2179 in k2176 in ... */
static void C_ccall f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4119,2,t0,t1);}
t2=*((C_word*)lf[289]+1);
t3=C_i_check_list_2(*((C_word*)lf[289]+1),lf[41]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4163,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4163(t7,((C_word*)t0)[2],*((C_word*)lf[289]+1));}

/* k2437 in k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in ... */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3669,a[2]=((C_word*)t0)[25],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[27],a[6]=((C_word*)t0)[28],a[7]=((C_word*)t0)[29],tmp=(C_word)a,a+=8,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5487,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t6,*((C_word*)lf[110]+1),lf[245],C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3678,a[2]=((C_word*)t0)[25],a[3]=((C_word*)t0)[27],a[4]=((C_word*)t0)[29],a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3678(t7,t3,((C_word*)t0)[28]);}}

/* k2434 in k2431 in k2428 in k2425 in k2421 in k2417 in k2414 in k2411 in k2408 in k2404 in k2365 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2320 in k2316 in k2312 in k2309 in k2305 in ... */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2436,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=t2,a[29]=((C_word*)t0)[28],tmp=(C_word)a,a+=30,tmp);
/* batch-driver.scm:407: user-read-pass */
t4=*((C_word*)lf[1]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* for-each-loop1050 in k2903 in k2889 in k2537 in k2534 in k2531 in k2528 in k2525 in k2522 in k2519 in k2516 in k3167 in k2505 in k2502 in k2499 in k2496 in k2493 in k2488 in k2485 in k2482 in k2479 in k2476 in ... */
static void C_fcall f_2985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2985,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2995,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2896,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:546: load-type-database */
t8=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t6,C_SCHEME_FALSE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[419] = {
{"f_2430:batch_2ddriver_2escm",(void*)f_2430},
{"f_3047:batch_2ddriver_2escm",(void*)f_3047},
{"f_2433:batch_2ddriver_2escm",(void*)f_2433},
{"f_4454:batch_2ddriver_2escm",(void*)f_4454},
{"f_2469:batch_2ddriver_2escm",(void*)f_2469},
{"f_2972:batch_2ddriver_2escm",(void*)f_2972},
{"f_2460:batch_2ddriver_2escm",(void*)f_2460},
{"f_2463:batch_2ddriver_2escm",(void*)f_2463},
{"f_2457:batch_2ddriver_2escm",(void*)f_2457},
{"f_3826:batch_2ddriver_2escm",(void*)f_3826},
{"f_2451:batch_2ddriver_2escm",(void*)f_2451},
{"f_2454:batch_2ddriver_2escm",(void*)f_2454},
{"f_2995:batch_2ddriver_2escm",(void*)f_2995},
{"f_4731:batch_2ddriver_2escm",(void*)f_4731},
{"f_4406:batch_2ddriver_2escm",(void*)f_4406},
{"f_3804:batch_2ddriver_2escm",(void*)f_3804},
{"f_3808:batch_2ddriver_2escm",(void*)f_3808},
{"f_3833:batch_2ddriver_2escm",(void*)f_3833},
{"f_4138:batch_2ddriver_2escm",(void*)f_4138},
{"f_2322:batch_2ddriver_2escm",(void*)f_2322},
{"f_3865:batch_2ddriver_2escm",(void*)f_3865},
{"f_2498:batch_2ddriver_2escm",(void*)f_2498},
{"f_2495:batch_2ddriver_2escm",(void*)f_2495},
{"f_2490:batch_2ddriver_2escm",(void*)f_2490},
{"f_4186:batch_2ddriver_2escm",(void*)f_4186},
{"f_2311:batch_2ddriver_2escm",(void*)f_2311},
{"f_2314:batch_2ddriver_2escm",(void*)f_2314},
{"f_2318:batch_2ddriver_2escm",(void*)f_2318},
{"f_4196:batch_2ddriver_2escm",(void*)f_4196},
{"f_2345:batch_2ddriver_2escm",(void*)f_2345},
{"f_2342:batch_2ddriver_2escm",(void*)f_2342},
{"f_2348:batch_2ddriver_2escm",(void*)f_2348},
{"f_4163:batch_2ddriver_2escm",(void*)f_4163},
{"f_2333:batch_2ddriver_2escm",(void*)f_2333},
{"f_2339:batch_2ddriver_2escm",(void*)f_2339},
{"f_2336:batch_2ddriver_2escm",(void*)f_2336},
{"f_4173:batch_2ddriver_2escm",(void*)f_4173},
{"f_2367:batch_2ddriver_2escm",(void*)f_2367},
{"f_2406:batch_2ddriver_2escm",(void*)f_2406},
{"f_2356:batch_2ddriver_2escm",(void*)f_2356},
{"f_3913:batch_2ddriver_2escm",(void*)f_3913},
{"f_2400:batch_2ddriver_2escm",(void*)f_2400},
{"f_4419:batch_2ddriver_2escm",(void*)f_4419},
{"f_4412:batch_2ddriver_2escm",(void*)f_4412},
{"f_3937:batch_2ddriver_2escm",(void*)f_3937},
{"f_4425:batch_2ddriver_2escm",(void*)f_4425},
{"f_3920:batch_2ddriver_2escm",(void*)f_3920},
{"f5022:batch_2ddriver_2escm",(void*)f5022},
{"f_2397:batch_2ddriver_2escm",(void*)f_2397},
{"f_2394:batch_2ddriver_2escm",(void*)f_2394},
{"f_3476:batch_2ddriver_2escm",(void*)f_3476},
{"f_1732:batch_2ddriver_2escm",(void*)f_1732},
{"f_1735:batch_2ddriver_2escm",(void*)f_1735},
{"f_1737:batch_2ddriver_2escm",(void*)f_1737},
{"f_3122:batch_2ddriver_2escm",(void*)f_3122},
{"f_3124:batch_2ddriver_2escm",(void*)f_3124},
{"f_3946:batch_2ddriver_2escm",(void*)f_3946},
{"f_3948:batch_2ddriver_2escm",(void*)f_3948},
{"f_3940:batch_2ddriver_2escm",(void*)f_3940},
{"f_1726:batch_2ddriver_2escm",(void*)f_1726},
{"f_1729:batch_2ddriver_2escm",(void*)f_1729},
{"f_1977:batch_2ddriver_2escm",(void*)f_1977},
{"f_2487:batch_2ddriver_2escm",(void*)f_2487},
{"f_2484:batch_2ddriver_2escm",(void*)f_2484},
{"f_1775:batch_2ddriver_2escm",(void*)f_1775},
{"f_2481:batch_2ddriver_2escm",(void*)f_2481},
{"f_1778:batch_2ddriver_2escm",(void*)f_1778},
{"f_1772:batch_2ddriver_2escm",(void*)f_1772},
{"f_1983:batch_2ddriver_2escm",(void*)f_1983},
{"f_1986:batch_2ddriver_2escm",(void*)f_1986},
{"f_1980:batch_2ddriver_2escm",(void*)f_1980},
{"f_2303:batch_2ddriver_2escm",(void*)f_2303},
{"f_2478:batch_2ddriver_2escm",(void*)f_2478},
{"f_2307:batch_2ddriver_2escm",(void*)f_2307},
{"f_2472:batch_2ddriver_2escm",(void*)f_2472},
{"f_1744:batch_2ddriver_2escm",(void*)f_1744},
{"f_1997:batch_2ddriver_2escm",(void*)f_1997},
{"f5525:batch_2ddriver_2escm",(void*)f5525},
{"f_1714:batch_2ddriver_2escm",(void*)f_1714},
{"f_2653:batch_2ddriver_2escm",(void*)f_2653},
{"f_1710:batch_2ddriver_2escm",(void*)f_1710},
{"f_2667:batch_2ddriver_2escm",(void*)f_2667},
{"f5559:batch_2ddriver_2escm",(void*)f5559},
{"f_1766:batch_2ddriver_2escm",(void*)f_1766},
{"f5553:batch_2ddriver_2escm",(void*)f5553},
{"f_1692:batch_2ddriver_2escm",(void*)f_1692},
{"f_3841:batch_2ddriver_2escm",(void*)f_3841},
{"f_3633:batch_2ddriver_2escm",(void*)f_3633},
{"f_3631:batch_2ddriver_2escm",(void*)f_3631},
{"f_1759:batch_2ddriver_2escm",(void*)f_1759},
{"f_1757:batch_2ddriver_2escm",(void*)f_1757},
{"toplevel:batch_2ddriver_2escm",(void*)C_driver_toplevel},
{"f_3993:batch_2ddriver_2escm",(void*)f_3993},
{"f_3859:batch_2ddriver_2escm",(void*)f_3859},
{"f_2089:batch_2ddriver_2escm",(void*)f_2089},
{"f_2086:batch_2ddriver_2escm",(void*)f_2086},
{"f_2385:batch_2ddriver_2escm",(void*)f_2385},
{"f_2079:batch_2ddriver_2escm",(void*)f_2079},
{"f_2076:batch_2ddriver_2escm",(void*)f_2076},
{"f_2073:batch_2ddriver_2escm",(void*)f_2073},
{"f_2637:batch_2ddriver_2escm",(void*)f_2637},
{"f_2378:batch_2ddriver_2escm",(void*)f_2378},
{"f_2027:batch_2ddriver_2escm",(void*)f_2027},
{"f_3983:batch_2ddriver_2escm",(void*)f_3983},
{"f_2021:batch_2ddriver_2escm",(void*)f_2021},
{"f_3662:batch_2ddriver_2escm",(void*)f_3662},
{"f_3669:batch_2ddriver_2escm",(void*)f_3669},
{"f_2682:batch_2ddriver_2escm",(void*)f_2682},
{"f_2670:batch_2ddriver_2escm",(void*)f_2670},
{"f_2679:batch_2ddriver_2escm",(void*)f_2679},
{"f_2673:batch_2ddriver_2escm",(void*)f_2673},
{"f_2676:batch_2ddriver_2escm",(void*)f_2676},
{"f_3977:batch_2ddriver_2escm",(void*)f_3977},
{"f_2611:batch_2ddriver_2escm",(void*)f_2611},
{"f_2618:batch_2ddriver_2escm",(void*)f_2618},
{"f_2615:batch_2ddriver_2escm",(void*)f_2615},
{"f_2007:batch_2ddriver_2escm",(void*)f_2007},
{"f_2009:batch_2ddriver_2escm",(void*)f_2009},
{"f_2005:batch_2ddriver_2escm",(void*)f_2005},
{"f_2560:batch_2ddriver_2escm",(void*)f_2560},
{"f_2565:batch_2ddriver_2escm",(void*)f_2565},
{"f_2569:batch_2ddriver_2escm",(void*)f_2569},
{"f_2551:batch_2ddriver_2escm",(void*)f_2551},
{"f_2554:batch_2ddriver_2escm",(void*)f_2554},
{"f_4262:batch_2ddriver_2escm",(void*)f_4262},
{"f_2013:batch_2ddriver_2escm",(void*)f_2013},
{"f_2016:batch_2ddriver_2escm",(void*)f_2016},
{"f_2557:batch_2ddriver_2escm",(void*)f_2557},
{"f_2839:batch_2ddriver_2escm",(void*)f_2839},
{"f_2501:batch_2ddriver_2escm",(void*)f_2501},
{"f_2504:batch_2ddriver_2escm",(void*)f_2504},
{"f_4270:batch_2ddriver_2escm",(void*)f_4270},
{"f_2507:batch_2ddriver_2escm",(void*)f_2507},
{"f_4286:batch_2ddriver_2escm",(void*)f_4286},
{"f_3738:batch_2ddriver_2escm",(void*)f_3738},
{"f_4292:batch_2ddriver_2escm",(void*)f_4292},
{"f_4546:batch_2ddriver_2escm",(void*)f_4546},
{"f_4294:batch_2ddriver_2escm",(void*)f_4294},
{"f_4228:batch_2ddriver_2escm",(void*)f_4228},
{"f_4224:batch_2ddriver_2escm",(void*)f_4224},
{"f_4517:batch_2ddriver_2escm",(void*)f_4517},
{"f_2542:batch_2ddriver_2escm",(void*)f_2542},
{"f_4233:batch_2ddriver_2escm",(void*)f_4233},
{"f_2548:batch_2ddriver_2escm",(void*)f_2548},
{"f_3709:batch_2ddriver_2escm",(void*)f_3709},
{"f_3707:batch_2ddriver_2escm",(void*)f_3707},
{"f_3700:batch_2ddriver_2escm",(void*)f_3700},
{"f_2828:batch_2ddriver_2escm",(void*)f_2828},
{"f_2530:batch_2ddriver_2escm",(void*)f_2530},
{"f_2533:batch_2ddriver_2escm",(void*)f_2533},
{"f_2536:batch_2ddriver_2escm",(void*)f_2536},
{"f_2822:batch_2ddriver_2escm",(void*)f_2822},
{"f_2539:batch_2ddriver_2escm",(void*)f_2539},
{"f_2825:batch_2ddriver_2escm",(void*)f_2825},
{"f_3773:batch_2ddriver_2escm",(void*)f_3773},
{"f_2816:batch_2ddriver_2escm",(void*)f_2816},
{"f_2810:batch_2ddriver_2escm",(void*)f_2810},
{"f_4555:batch_2ddriver_2escm",(void*)f_4555},
{"f_2721:batch_2ddriver_2escm",(void*)f_2721},
{"f_2724:batch_2ddriver_2escm",(void*)f_2724},
{"f_2727:batch_2ddriver_2escm",(void*)f_2727},
{"f_2585:batch_2ddriver_2escm",(void*)f_2585},
{"f_4560:batch_2ddriver_2escm",(void*)f_4560},
{"f_2582:batch_2ddriver_2escm",(void*)f_2582},
{"f_1936:batch_2ddriver_2escm",(void*)f_1936},
{"f_2579:batch_2ddriver_2escm",(void*)f_2579},
{"f_2575:batch_2ddriver_2escm",(void*)f_2575},
{"f_2572:batch_2ddriver_2escm",(void*)f_2572},
{"f_1944:batch_2ddriver_2escm",(void*)f_1944},
{"f_1948:batch_2ddriver_2escm",(void*)f_1948},
{"f_2524:batch_2ddriver_2escm",(void*)f_2524},
{"f_2521:batch_2ddriver_2escm",(void*)f_2521},
{"f_3254:batch_2ddriver_2escm",(void*)f_3254},
{"f_3257:batch_2ddriver_2escm",(void*)f_3257},
{"f_2527:batch_2ddriver_2escm",(void*)f_2527},
{"f_1957:batch_2ddriver_2escm",(void*)f_1957},
{"f_3624:batch_2ddriver_2escm",(void*)f_3624},
{"f_3263:batch_2ddriver_2escm",(void*)f_3263},
{"f_2518:batch_2ddriver_2escm",(void*)f_2518},
{"f_1965:batch_2ddriver_2escm",(void*)f_1965},
{"f_1967:batch_2ddriver_2escm",(void*)f_1967},
{"f_2763:batch_2ddriver_2escm",(void*)f_2763},
{"f_2760:batch_2ddriver_2escm",(void*)f_2760},
{"f_2769:batch_2ddriver_2escm",(void*)f_2769},
{"f_2766:batch_2ddriver_2escm",(void*)f_2766},
{"f_3278:batch_2ddriver_2escm",(void*)f_3278},
{"f_3274:batch_2ddriver_2escm",(void*)f_3274},
{"f_2273:batch_2ddriver_2escm",(void*)f_2273},
{"f_2711:batch_2ddriver_2escm",(void*)f_2711},
{"f_2715:batch_2ddriver_2escm",(void*)f_2715},
{"f_3609:batch_2ddriver_2escm",(void*)f_3609},
{"f_2248:batch_2ddriver_2escm",(void*)f_2248},
{"f_4578:batch_2ddriver_2escm",(void*)f_4578},
{"f_2718:batch_2ddriver_2escm",(void*)f_2718},
{"f_4573:batch_2ddriver_2escm",(void*)f_4573},
{"f_3289:batch_2ddriver_2escm",(void*)f_3289},
{"f_3286:batch_2ddriver_2escm",(void*)f_3286},
{"f_1901:batch_2ddriver_2escm",(void*)f_1901},
{"f_2263:batch_2ddriver_2escm",(void*)f_2263},
{"f_2260:batch_2ddriver_2escm",(void*)f_2260},
{"f_2705:batch_2ddriver_2escm",(void*)f_2705},
{"f_2702:batch_2ddriver_2escm",(void*)f_2702},
{"f_2708:batch_2ddriver_2escm",(void*)f_2708},
{"f_2276:batch_2ddriver_2escm",(void*)f_2276},
{"f_3783:batch_2ddriver_2escm",(void*)f_3783},
{"f_3786:batch_2ddriver_2escm",(void*)f_3786},
{"f_3295:batch_2ddriver_2escm",(void*)f_3295},
{"f_3292:batch_2ddriver_2escm",(void*)f_3292},
{"f_2291:batch_2ddriver_2escm",(void*)f_2291},
{"f_2730:batch_2ddriver_2escm",(void*)f_2730},
{"f_2733:batch_2ddriver_2escm",(void*)f_2733},
{"f_2266:batch_2ddriver_2escm",(void*)f_2266},
{"f_2738:batch_2ddriver_2escm",(void*)f_2738},
{"f_3793:batch_2ddriver_2escm",(void*)f_3793},
{"f_3798:batch_2ddriver_2escm",(void*)f_3798},
{"f_1928:batch_2ddriver_2escm",(void*)f_1928},
{"f_1922:batch_2ddriver_2escm",(void*)f_1922},
{"f_1611:batch_2ddriver_2escm",(void*)f_1611},
{"f_2295:batch_2ddriver_2escm",(void*)f_2295},
{"f_2285:batch_2ddriver_2escm",(void*)f_2285},
{"f_2037:batch_2ddriver_2escm",(void*)f_2037},
{"f_2032:batch_2ddriver_2escm",(void*)f_2032},
{"f_1881:batch_2ddriver_2escm",(void*)f_1881},
{"f_2599:batch_2ddriver_2escm",(void*)f_2599},
{"f_2594:batch_2ddriver_2escm",(void*)f_2594},
{"f_2591:batch_2ddriver_2escm",(void*)f_2591},
{"f_1658:batch_2ddriver_2escm",(void*)f_1658},
{"f_1655:batch_2ddriver_2escm",(void*)f_1655},
{"f_3014:batch_2ddriver_2escm",(void*)f_3014},
{"f_1666:batch_2ddriver_2escm",(void*)f_1666},
{"f_3412:batch_2ddriver_2escm",(void*)f_3412},
{"f5451:batch_2ddriver_2escm",(void*)f5451},
{"f_1661:batch_2ddriver_2escm",(void*)f_1661},
{"f5443:batch_2ddriver_2escm",(void*)f5443},
{"f_2211:batch_2ddriver_2escm",(void*)f_2211},
{"f_2845:batch_2ddriver_2escm",(void*)f_2845},
{"f5431:batch_2ddriver_2escm",(void*)f5431},
{"f_1602:batch_2ddriver_2escm",(void*)f_1602},
{"f_1608:batch_2ddriver_2escm",(void*)f_1608},
{"f_1606:batch_2ddriver_2escm",(void*)f_1606},
{"f_2842:batch_2ddriver_2escm",(void*)f_2842},
{"f_2200:batch_2ddriver_2escm",(void*)f_2200},
{"f_2217:batch_2ddriver_2escm",(void*)f_2217},
{"f_2214:batch_2ddriver_2escm",(void*)f_2214},
{"f_3744:batch_2ddriver_2escm",(void*)f_3744},
{"f5425:batch_2ddriver_2escm",(void*)f5425},
{"f_2208:batch_2ddriver_2escm",(void*)f_2208},
{"f_2205:batch_2ddriver_2escm",(void*)f_2205},
{"f5413:batch_2ddriver_2escm",(void*)f5413},
{"f_4016:batch_2ddriver_2escm",(void*)f_4016},
{"f5419:batch_2ddriver_2escm",(void*)f5419},
{"f_2851:batch_2ddriver_2escm",(void*)f_2851},
{"f5407:batch_2ddriver_2escm",(void*)f5407},
{"f_1642:batch_2ddriver_2escm",(void*)f_1642},
{"f_4357:batch_2ddriver_2escm",(void*)f_4357},
{"f_2163:batch_2ddriver_2escm",(void*)f_2163},
{"f_3575:batch_2ddriver_2escm",(void*)f_3575},
{"f_2160:batch_2ddriver_2escm",(void*)f_2160},
{"f5463:batch_2ddriver_2escm",(void*)f5463},
{"f_4006:batch_2ddriver_2escm",(void*)f_4006},
{"f_2169:batch_2ddriver_2escm",(void*)f_2169},
{"f_2166:batch_2ddriver_2escm",(void*)f_2166},
{"f_2151:batch_2ddriver_2escm",(void*)f_2151},
{"f_4363:batch_2ddriver_2escm",(void*)f_4363},
{"f_2154:batch_2ddriver_2escm",(void*)f_2154},
{"f_3115:batch_2ddriver_2escm",(void*)f_3115},
{"f_1580:batch_2ddriver_2escm",(void*)f_1580},
{"f_1583:batch_2ddriver_2escm",(void*)f_1583},
{"f_2157:batch_2ddriver_2escm",(void*)f_2157},
{"f_1586:batch_2ddriver_2escm",(void*)f_1586},
{"f_2896:batch_2ddriver_2escm",(void*)f_2896},
{"f_4338:batch_2ddriver_2escm",(void*)f_4338},
{"f_4029:batch_2ddriver_2escm",(void*)f_4029},
{"f_2184:batch_2ddriver_2escm",(void*)f_2184},
{"f_2181:batch_2ddriver_2escm",(void*)f_2181},
{"f_4332:batch_2ddriver_2escm",(void*)f_4332},
{"f_4335:batch_2ddriver_2escm",(void*)f_4335},
{"f_2891:batch_2ddriver_2escm",(void*)f_2891},
{"f_3101:batch_2ddriver_2escm",(void*)f_3101},
{"f_1590:batch_2ddriver_2escm",(void*)f_1590},
{"f_1594:batch_2ddriver_2escm",(void*)f_1594},
{"f_2187:batch_2ddriver_2escm",(void*)f_2187},
{"f_1598:batch_2ddriver_2escm",(void*)f_1598},
{"f_4349:batch_2ddriver_2escm",(void*)f_4349},
{"f_2172:batch_2ddriver_2escm",(void*)f_2172},
{"f_4341:batch_2ddriver_2escm",(void*)f_4341},
{"f_4070:batch_2ddriver_2escm",(void*)f_4070},
{"f_4629:batch_2ddriver_2escm",(void*)f_4629},
{"f_2175:batch_2ddriver_2escm",(void*)f_2175},
{"f_2178:batch_2ddriver_2escm",(void*)f_2178},
{"f_4049:batch_2ddriver_2escm",(void*)f_4049},
{"f_3546:batch_2ddriver_2escm",(void*)f_3546},
{"f_4637:batch_2ddriver_2escm",(void*)f_4637},
{"f_4633:batch_2ddriver_2escm",(void*)f_4633},
{"f_2754:batch_2ddriver_2escm",(void*)f_2754},
{"f_2751:batch_2ddriver_2escm",(void*)f_2751},
{"f_2757:batch_2ddriver_2escm",(void*)f_2757},
{"f_4096:batch_2ddriver_2escm",(void*)f_4096},
{"f_2190:batch_2ddriver_2escm",(void*)f_2190},
{"f_2195:batch_2ddriver_2escm",(void*)f_2195},
{"f_2744:batch_2ddriver_2escm",(void*)f_2744},
{"f_2748:batch_2ddriver_2escm",(void*)f_2748},
{"f_4062:batch_2ddriver_2escm",(void*)f_4062},
{"f_3091:batch_2ddriver_2escm",(void*)f_3091},
{"f5481:batch_2ddriver_2escm",(void*)f5481},
{"f5487:batch_2ddriver_2escm",(void*)f5487},
{"f_4651:batch_2ddriver_2escm",(void*)f_4651},
{"f_2772:batch_2ddriver_2escm",(void*)f_2772},
{"f_3063:batch_2ddriver_2escm",(void*)f_3063},
{"f_3673:batch_2ddriver_2escm",(void*)f_3673},
{"f_3037:batch_2ddriver_2escm",(void*)f_3037},
{"f_3678:batch_2ddriver_2escm",(void*)f_3678},
{"f_3086:batch_2ddriver_2escm",(void*)f_3086},
{"f_3082:batch_2ddriver_2escm",(void*)f_3082},
{"f_3220:batch_2ddriver_2escm",(void*)f_3220},
{"f_2784:batch_2ddriver_2escm",(void*)f_2784},
{"f_3696:batch_2ddriver_2escm",(void*)f_3696},
{"f_2106:batch_2ddriver_2escm",(void*)f_2106},
{"f_3689:batch_2ddriver_2escm",(void*)f_3689},
{"f_2102:batch_2ddriver_2escm",(void*)f_2102},
{"f_3511:batch_2ddriver_2escm",(void*)f_3511},
{"f5507:batch_2ddriver_2escm",(void*)f5507},
{"f5501:batch_2ddriver_2escm",(void*)f5501},
{"f_3075:batch_2ddriver_2escm",(void*)f_3075},
{"f_3072:batch_2ddriver_2escm",(void*)f_3072},
{"f_3239:batch_2ddriver_2escm",(void*)f_3239},
{"f_3251:batch_2ddriver_2escm",(void*)f_3251},
{"f5535:batch_2ddriver_2escm",(void*)f5535},
{"f_2233:batch_2ddriver_2escm",(void*)f_2233},
{"f_2905:batch_2ddriver_2escm",(void*)f_2905},
{"f_4323:batch_2ddriver_2escm",(void*)f_4323},
{"f_2117:batch_2ddriver_2escm",(void*)f_2117},
{"f_3245:batch_2ddriver_2escm",(void*)f_3245},
{"f_3248:batch_2ddriver_2escm",(void*)f_3248},
{"f_2111:batch_2ddriver_2escm",(void*)f_2111},
{"f_2220:batch_2ddriver_2escm",(void*)f_2220},
{"f_2236:batch_2ddriver_2escm",(void*)f_2236},
{"f_2239:batch_2ddriver_2escm",(void*)f_2239},
{"f5519:batch_2ddriver_2escm",(void*)f5519},
{"f_2251:batch_2ddriver_2escm",(void*)f_2251},
{"f_2254:batch_2ddriver_2escm",(void*)f_2254},
{"f_2920:batch_2ddriver_2escm",(void*)f_2920},
{"f_2924:batch_2ddriver_2escm",(void*)f_2924},
{"f_2226:batch_2ddriver_2escm",(void*)f_2226},
{"f_2229:batch_2ddriver_2escm",(void*)f_2229},
{"f_4037:batch_2ddriver_2escm",(void*)f_4037},
{"f_4039:batch_2ddriver_2escm",(void*)f_4039},
{"f_2927:batch_2ddriver_2escm",(void*)f_2927},
{"f5513:batch_2ddriver_2escm",(void*)f5513},
{"f_2245:batch_2ddriver_2escm",(void*)f_2245},
{"f_2242:batch_2ddriver_2escm",(void*)f_2242},
{"f_1832:batch_2ddriver_2escm",(void*)f_1832},
{"f_2911:batch_2ddriver_2escm",(void*)f_2911},
{"f_2257:batch_2ddriver_2escm",(void*)f_2257},
{"f_1809:batch_2ddriver_2escm",(void*)f_1809},
{"f_2941:batch_2ddriver_2escm",(void*)f_2941},
{"f_2944:batch_2ddriver_2escm",(void*)f_2944},
{"f_2947:batch_2ddriver_2escm",(void*)f_2947},
{"f5571:batch_2ddriver_2escm",(void*)f5571},
{"f5577:batch_2ddriver_2escm",(void*)f5577},
{"f_4680:batch_2ddriver_2escm",(void*)f_4680},
{"f_4688:batch_2ddriver_2escm",(void*)f_4688},
{"f_2930:batch_2ddriver_2escm",(void*)f_2930},
{"f_2935:batch_2ddriver_2escm",(void*)f_2935},
{"f_2938:batch_2ddriver_2escm",(void*)f_2938},
{"f_4692:batch_2ddriver_2escm",(void*)f_4692},
{"f_4696:batch_2ddriver_2escm",(void*)f_4696},
{"f_4399:batch_2ddriver_2escm",(void*)f_4399},
{"f_4396:batch_2ddriver_2escm",(void*)f_4396},
{"f_1781:batch_2ddriver_2escm",(void*)f_1781},
{"f_1786:batch_2ddriver_2escm",(void*)f_1786},
{"f_3179:batch_2ddriver_2escm",(void*)f_3179},
{"f_1819:batch_2ddriver_2escm",(void*)f_1819},
{"f_3176:batch_2ddriver_2escm",(void*)f_3176},
{"f_3173:batch_2ddriver_2escm",(void*)f_3173},
{"f_3397:batch_2ddriver_2escm",(void*)f_3397},
{"f5565:batch_2ddriver_2escm",(void*)f5565},
{"f_3191:batch_2ddriver_2escm",(void*)f_3191},
{"f_3169:batch_2ddriver_2escm",(void*)f_3169},
{"f_3161:batch_2ddriver_2escm",(void*)f_3161},
{"f_4607:batch_2ddriver_2escm",(void*)f_4607},
{"f_1793:batch_2ddriver_2escm",(void*)f_1793},
{"f_4615:batch_2ddriver_2escm",(void*)f_4615},
{"f_1798:batch_2ddriver_2escm",(void*)f_1798},
{"f_3186:batch_2ddriver_2escm",(void*)f_3186},
{"f_2120:batch_2ddriver_2escm",(void*)f_2120},
{"f_2127:batch_2ddriver_2escm",(void*)f_2127},
{"f_3322:batch_2ddriver_2escm",(void*)f_3322},
{"f_2145:batch_2ddriver_2escm",(void*)f_2145},
{"f_2142:batch_2ddriver_2escm",(void*)f_2142},
{"f_3312:batch_2ddriver_2escm",(void*)f_3312},
{"f_2148:batch_2ddriver_2escm",(void*)f_2148},
{"f_2130:batch_2ddriver_2escm",(void*)f_2130},
{"f_2133:batch_2ddriver_2escm",(void*)f_2133},
{"f_2136:batch_2ddriver_2escm",(void*)f_2136},
{"f_2139:batch_2ddriver_2escm",(void*)f_2139},
{"f_3367:batch_2ddriver_2escm",(void*)f_3367},
{"f_2427:batch_2ddriver_2escm",(void*)f_2427},
{"f_3355:batch_2ddriver_2escm",(void*)f_3355},
{"f_2423:batch_2ddriver_2escm",(void*)f_2423},
{"f_2419:batch_2ddriver_2escm",(void*)f_2419},
{"f_2416:batch_2ddriver_2escm",(void*)f_2416},
{"f_2962:batch_2ddriver_2escm",(void*)f_2962},
{"f_3026:batch_2ddriver_2escm",(void*)f_3026},
{"f_2413:batch_2ddriver_2escm",(void*)f_2413},
{"f_2410:batch_2ddriver_2escm",(void*)f_2410},
{"f_4720:batch_2ddriver_2escm",(void*)f_4720},
{"f_2448:batch_2ddriver_2escm",(void*)f_2448},
{"f_2953:batch_2ddriver_2escm",(void*)f_2953},
{"f_2950:batch_2ddriver_2escm",(void*)f_2950},
{"f_3371:batch_2ddriver_2escm",(void*)f_3371},
{"f_2956:batch_2ddriver_2escm",(void*)f_2956},
{"f_2445:batch_2ddriver_2escm",(void*)f_2445},
{"f_2442:batch_2ddriver_2escm",(void*)f_2442},
{"f_4119:batch_2ddriver_2escm",(void*)f_4119},
{"f_2439:batch_2ddriver_2escm",(void*)f_2439},
{"f_2436:batch_2ddriver_2escm",(void*)f_2436},
{"f_2985:batch_2ddriver_2escm",(void*)f_2985},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  sprintf		1
S|  for-each		11
S|  printf		4
S|  map		15
o|eliminated procedure checks: 112 
o|specializations:
o|  1 (current-output-port)
o|  2 (string=? string string)
o|  1 (string-append string string)
o|  5 (cdr pair)
o|  4 (eqv? (not float) *)
o|  1 (< fixnum fixnum)
o|  5 (##sys#check-output-port * * *)
o|  8 (##sys#check-list (or pair list) *)
o|  76 (memq * list)
o|  2 (car pair)
o|Removed `not' forms: 5 
o|inlining procedure: k1613 
o|inlining procedure: k1613 
o|substituted constant variable: a1644 
o|substituted constant variable: a1649 
o|substituted constant variable: a1651 
o|substituted constant variable: a1662 
o|substituted constant variable: a1667 
o|substituted constant variable: a1672 
o|substituted constant variable: a1674 
o|substituted constant variable: a1676 
o|substituted constant variable: a1678 
o|substituted constant variable: a1680 
o|substituted constant variable: a1682 
o|substituted constant variable: a1684 
o|substituted constant variable: a1686 
o|substituted constant variable: a1688 
o|merged explicitly consed rest parameter: args127 
o|propagated global variable: out131135 ##sys#standard-output 
o|substituted constant variable: a1722 
o|substituted constant variable: a1723 
o|inlining procedure: k1715 
o|propagated global variable: out131135 ##sys#standard-output 
o|inlining procedure: k1715 
o|inlining procedure: k1739 
o|inlining procedure: k1739 
o|propagated global variable: out149153 ##sys#standard-output 
o|substituted constant variable: a1768 
o|substituted constant variable: a1769 
o|inlining procedure: k1761 
o|propagated global variable: out149153 ##sys#standard-output 
o|inlining procedure: k1761 
o|inlining procedure: k1788 
o|inlining procedure: k1811 
o|contracted procedure: "(batch-driver.scm:126) g165172" 
o|inlining procedure: k1811 
o|inlining procedure: k1788 
o|inlining procedure: k1843 
o|inlining procedure: k1843 
o|inlining procedure: k1858 
o|folded constant expression: (* (quote 1024) (quote 1024)) 
o|inlining procedure: k1858 
o|substituted constant variable: a1909 
o|substituted constant variable: a1911 
o|substituted constant variable: a1916 
o|substituted constant variable: a1918 
o|substituted constant variable: a1920 
o|inlining procedure: k1933 
o|inlining procedure: k1933 
o|inlining procedure: k1959 
o|inlining procedure: "(batch-driver.scm:149) cputime115" 
o|inlining procedure: k1959 
o|propagated global variable: out213217 ##sys#standard-output 
o|substituted constant variable: a1973 
o|substituted constant variable: a1974 
o|inlining procedure: k1969 
o|inlining procedure: "(batch-driver.scm:155) cputime115" 
o|propagated global variable: out213217 ##sys#standard-output 
o|inlining procedure: k1969 
o|merged explicitly consed rest parameter: args225 
o|inlining procedure: k2014 
o|propagated global variable: g249250 ##compiler#get 
o|propagated global variable: g263264 ##compiler#put! 
o|inlining procedure: k2014 
o|inlining procedure: k2042 
o|inlining procedure: k2042 
o|substituted constant variable: a2081 
o|substituted constant variable: a2091 
o|propagated global variable: a2092 ##compiler#debugging-chicken 
o|substituted constant variable: a2191 
o|substituted constant variable: a2196 
o|substituted constant variable: a2201 
o|substituted constant variable: a2328 
o|substituted constant variable: a2352 
o|inlining procedure: k2349 
o|inlining procedure: k2349 
o|substituted constant variable: a2363 
o|substituted constant variable: a2374 
o|inlining procedure: k2371 
o|inlining procedure: k2371 
o|contracted procedure: k2389 
o|inlining procedure: k2586 
o|inlining procedure: k2601 
o|inlining procedure: k2601 
o|inlining procedure: k2619 
o|inlining procedure: k2619 
o|contracted procedure: k2648 
o|propagated global variable: r2649 ##compiler#inline-substitutions-enabled 
o|inlining procedure: k2645 
o|consed rest parameter at call site: "(batch-driver.scm:627) analyze125" 3 
o|inlining procedure: k2645 
o|contracted procedure: k2697 
o|inlining procedure: k2586 
o|consed rest parameter at call site: "(batch-driver.scm:682) dribble116" 2 
o|substituted constant variable: a2776 
o|propagated global variable: a2777 ##compiler#debugging-chicken 
o|consed rest parameter at call site: "(batch-driver.scm:674) dribble116" 2 
o|inlining procedure: "(batch-driver.scm:661) cputime115" 
o|consed rest parameter at call site: "(batch-driver.scm:653) dribble116" 2 
o|substituted constant variable: a2832 
o|propagated global variable: a2833 ##compiler#debugging-chicken 
o|inlining procedure: k2846 
o|consed rest parameter at call site: "(batch-driver.scm:597) dribble116" 2 
o|inlining procedure: k2846 
o|substituted constant variable: a2855 
o|propagated global variable: a2856 ##compiler#debugging-chicken 
o|substituted constant variable: a2860 
o|propagated global variable: a2861 ##compiler#debugging-chicken 
o|substituted constant variable: a2865 
o|propagated global variable: a2866 ##compiler#debugging-chicken 
o|consed rest parameter at call site: "(batch-driver.scm:587) analyze125" 3 
o|contracted procedure: "(batch-driver.scm:571) g11031104" 
o|inlining procedure: k2954 
o|inlining procedure: k2954 
o|consed rest parameter at call site: "(batch-driver.scm:555) analyze125" 3 
o|inlining procedure: k2964 
o|contracted procedure: "(batch-driver.scm:549) g10721079" 
o|inlining procedure: k2964 
o|inlining procedure: k2987 
o|contracted procedure: "(batch-driver.scm:544) g10511058" 
o|inlining procedure: k2897 
o|inlining procedure: k2897 
o|inlining procedure: k2987 
o|substituted constant variable: a3007 
o|inlining procedure: k3009 
o|inlining procedure: k3009 
o|consed rest parameter at call site: "(batch-driver.scm:535) dribble116" 2 
o|inlining procedure: k3039 
o|inlining procedure: k3039 
o|inlining procedure: k3064 
o|consed rest parameter at call site: "(batch-driver.scm:527) dribble116" 2 
o|inlining procedure: k3064 
o|inlining procedure: k3093 
o|inlining procedure: k3093 
o|inlining procedure: k3126 
o|inlining procedure: k3126 
o|contracted procedure: "(batch-driver.scm:507) g971972" 
o|inlining procedure: k3193 
o|inlining procedure: k3193 
o|consed rest parameter at call site: "(batch-driver.scm:501) dribble116" 2 
o|substituted constant variable: a3225 
o|substituted constant variable: a3241 
o|substituted constant variable: a3242 
o|inlining procedure: k3314 
o|contracted procedure: "(batch-driver.scm:478) g899906" 
o|propagated global variable: out909913 ##sys#standard-output 
o|substituted constant variable: a3282 
o|substituted constant variable: a3283 
o|propagated global variable: out909913 ##sys#standard-output 
o|inlining procedure: k3314 
o|propagated global variable: g905907 ##compiler#compiler-syntax-statistics 
o|contracted procedure: k3405 
o|propagated global variable: r3406 ##compiler#unit-name 
o|inlining procedure: k3402 
o|inlining procedure: k3402 
o|inlining procedure: k3414 
o|contracted procedure: "(batch-driver.scm:461) g873882" 
o|inlining procedure: k3414 
o|propagated global variable: g879883 ##compiler#profile-lambda-list 
o|contracted procedure: k3469 
o|propagated global variable: r3470 ##compiler#unit-name 
o|inlining procedure: k3466 
o|inlining procedure: k3466 
o|inlining procedure: k3478 
o|contracted procedure: "(batch-driver.scm:453) g836845" 
o|inlining procedure: k3478 
o|propagated global variable: g842846 ##compiler#used-units 
o|inlining procedure: k3513 
o|contracted procedure: "(batch-driver.scm:452) g806815" 
o|inlining procedure: k3513 
o|propagated global variable: g812816 ##compiler#immutable-constants 
o|inlining procedure: k3548 
o|inlining procedure: k3548 
o|inlining procedure: k3635 
o|inlining procedure: k3635 
o|consed rest parameter at call site: "(batch-driver.scm:432) dribble116" 2 
o|consed rest parameter at call site: "(batch-driver.scm:409) dribble116" 2 
o|inlining procedure: k3680 
o|inlining procedure: k3711 
o|inlining procedure: k3711 
o|inlining procedure: k3746 
o|inlining procedure: k3746 
o|inlining procedure: k3680 
o|inlining procedure: k3809 
o|inlining procedure: k3809 
o|inlining procedure: "(batch-driver.scm:396) cputime115" 
o|consed rest parameter at call site: "(batch-driver.scm:390) dribble116" 2 
o|substituted constant variable: a3842 
o|inlining procedure: k3844 
o|substituted constant variable: a3847 
o|inlining procedure: k3844 
o|substituted constant variable: a3852 
o|consed rest parameter at call site: "(batch-driver.scm:369) dribble116" 2 
o|inlining procedure: k3870 
o|consed rest parameter at call site: "(batch-driver.scm:369) dribble116" 2 
o|inlining procedure: k3870 
o|consed rest parameter at call site: "(batch-driver.scm:369) dribble116" 2 
o|inlining procedure: k3874 
o|inlining procedure: k3874 
o|consed rest parameter at call site: "(batch-driver.scm:351) dribble116" 2 
o|inlining procedure: k3891 
o|consed rest parameter at call site: "(batch-driver.scm:351) dribble116" 2 
o|inlining procedure: k3891 
o|consed rest parameter at call site: "(batch-driver.scm:351) dribble116" 2 
o|substituted constant variable: a3894 
o|substituted constant variable: a3899 
o|propagated global variable: a3900 ##compiler#debugging-chicken 
o|substituted constant variable: a3905 
o|substituted constant variable: a3921 
o|inlining procedure: k3950 
o|contracted procedure: "(batch-driver.scm:331) g594603" 
o|inlining procedure: k3950 
o|inlining procedure: k3985 
o|contracted procedure: "(batch-driver.scm:317) g570577" 
o|inlining procedure: k3985 
o|consed rest parameter at call site: "(batch-driver.scm:316) dribble116" 2 
o|inlining procedure: k4008 
o|inlining procedure: k4008 
o|propagated global variable: g559560 string-split 
o|inlining procedure: k4041 
o|inlining procedure: k4041 
o|propagated global variable: g534535 string-split 
o|substituted constant variable: a4071 
o|propagated global variable: a4072 ##compiler#debugging-chicken 
o|substituted constant variable: a4076 
o|inlining procedure: k4165 
o|contracted procedure: "(batch-driver.scm:298) g469476" 
o|contracted procedure: "(batch-driver.scm:301) g494495" 
o|contracted procedure: "(batch-driver.scm:300) g479480" 
o|inlining procedure: k4165 
o|propagated global variable: g475477 ##compiler#default-extended-bindings 
o|inlining procedure: k4188 
o|contracted procedure: "(batch-driver.scm:293) g420427" 
o|contracted procedure: "(batch-driver.scm:296) g445446" 
o|contracted procedure: "(batch-driver.scm:295) g430431" 
o|inlining procedure: k4188 
o|propagated global variable: g426428 ##compiler#default-standard-bindings 
o|substituted constant variable: a4208 
o|substituted constant variable: a4211 
o|substituted constant variable: a4214 
o|substituted constant variable: a4217 
o|substituted constant variable: a4220 
o|inlining procedure: k4235 
o|inlining procedure: k4235 
o|inlining procedure: k4277 
o|inlining procedure: k4277 
o|inlining procedure: k4296 
o|inlining procedure: k4296 
o|substituted constant variable: a4328 
o|consed rest parameter at call site: "(batch-driver.scm:265) dribble116" 2 
o|substituted constant variable: a4345 
o|consed rest parameter at call site: "(batch-driver.scm:262) dribble116" 2 
o|substituted constant variable: a4353 
o|consed rest parameter at call site: "(batch-driver.scm:259) dribble116" 2 
o|inlining procedure: k4364 
o|inlining procedure: k4364 
o|substituted constant variable: a4376 
o|substituted constant variable: a4384 
o|inlining procedure: k4381 
o|inlining procedure: k4381 
o|substituted constant variable: a4392 
o|consed rest parameter at call site: "(batch-driver.scm:249) dribble116" 2 
o|inlining procedure: k4410 
o|inlining procedure: k4410 
o|substituted constant variable: a4426 
o|substituted constant variable: a4429 
o|substituted constant variable: a4432 
o|substituted constant variable: a4435 
o|substituted constant variable: a4438 
o|substituted constant variable: a4441 
o|substituted constant variable: a4444 
o|substituted constant variable: a4447 
o|substituted constant variable: a4450 
o|consed rest parameter at call site: "(batch-driver.scm:223) dribble116" 2 
o|substituted constant variable: a4457 
o|substituted constant variable: a4462 
o|substituted constant variable: a4466 
o|substituted constant variable: a4469 
o|substituted constant variable: a4472 
o|substituted constant variable: a4475 
o|substituted constant variable: a4480 
o|substituted constant variable: a4485 
o|substituted constant variable: a4490 
o|substituted constant variable: a4495 
o|propagated global variable: a4496 ##compiler#debugging-chicken 
o|substituted constant variable: a4498 
o|propagated global variable: a4499 ##compiler#debugging-chicken 
o|substituted constant variable: a4505 
o|substituted constant variable: a4511 
o|inlining procedure: k4507 
o|inlining procedure: k4507 
o|inlining procedure: k4519 
o|contracted procedure: "(batch-driver.scm:186) g314323" 
o|substituted constant variable: a2108 
o|inlining procedure: k4519 
o|substituted constant variable: a4551 
o|propagated global variable: a4552 ##compiler#debugging-chicken 
o|inlining procedure: k4580 
o|contracted procedure: "(batch-driver.scm:177) g286295" 
o|inlining procedure: k4580 
o|substituted constant variable: a4616 
o|propagated global variable: tmp273275 ##compiler#unit-name 
o|inlining procedure: k4622 
o|propagated global variable: tmp273275 ##compiler#unit-name 
o|inlining procedure: k4622 
o|substituted constant variable: a4638 
o|substituted constant variable: a4643 
o|inlining procedure: k4645 
o|inlining procedure: k4645 
o|substituted constant variable: a4648 
o|inlining procedure: k4653 
o|inlining procedure: k4653 
o|inlining procedure: k4689 
o|inlining procedure: k4689 
o|inlining procedure: k4697 
o|inlining procedure: k4697 
o|substituted constant variable: a4712 
o|inlining procedure: k4709 
o|inlining procedure: k4709 
o|inlining procedure: k4718 
o|inlining procedure: k4718 
o|inlining procedure: k4733 
o|inlining procedure: k4733 
o|replaced variables: 400 
o|removed binding forms: 388 
o|Removed `not' forms: 2 
o|removed side-effect free assignment to unused variable: cputime115 
o|propagated global variable: out131135 ##sys#standard-output 
o|substituted constant variable: r17164745 
o|substituted constant variable: r17164746 
o|propagated global variable: out149153 ##sys#standard-output 
o|contracted procedure: k1875 
o|substituted constant variable: r19344760 
o|propagated global variable: out213217 ##sys#standard-output 
o|substituted constant variable: r30654814 
o|substituted constant variable: c973 
o|substituted constant variable: p974 
o|propagated global variable: out909913 ##sys#standard-output 
o|substituted constant variable: r34034823 
o|contracted procedure: k3402 
o|substituted constant variable: r34674827 
o|substituted constant variable: r34674827 
o|inlining procedure: k3466 
o|inlining procedure: k3466 
o|substituted constant variable: r38714853 
o|substituted constant variable: r38714853 
o|substituted constant variable: r38714855 
o|substituted constant variable: r38714855 
o|substituted constant variable: r38754857 
o|substituted constant variable: r38754857 
o|substituted constant variable: r38754859 
o|substituted constant variable: r38754859 
o|substituted constant variable: r38924861 
o|substituted constant variable: r38924861 
o|substituted constant variable: r38924863 
o|substituted constant variable: r38924863 
o|substituted constant variable: tmp500503 
o|substituted constant variable: mark502 
o|substituted constant variable: tmp485488 
o|substituted constant variable: mark487 
o|substituted constant variable: tmp451454 
o|substituted constant variable: mark453 
o|substituted constant variable: tmp436439 
o|substituted constant variable: mark438 
o|substituted constant variable: r42784880 
o|contracted procedure: k4507 
o|substituted constant variable: r45084893 
o|propagated global variable: r46234899 ##compiler#unit-name 
o|substituted constant variable: r46904909 
o|substituted constant variable: r46904909 
o|substituted constant variable: r47104913 
o|substituted constant variable: r47194917 
o|substituted constant variable: r47194917 
o|substituted constant variable: r47344919 
o|substituted constant variable: r47344919 
o|converted assignments to bindings: (option-arg30) 
o|simplifications: ((let . 1)) 
o|replaced variables: 16 
o|removed binding forms: 523 
o|removed conditional forms: 2 
o|substituted constant variable: r1876 
o|inlining procedure: k2767 
o|inlining procedure: k2794 
o|inlining procedure: k3399 
o|inlining procedure: k3399 
o|inlining procedure: k3399 
o|substituted constant variable: r34674961 
o|inlining procedure: k3877 
o|inlining procedure: k4141 
o|inlining procedure: k4124 
o|inlining procedure: k4099 
o|inlining procedure: k4082 
o|inlining procedure: k4271 
o|inlining procedure: k4271 
o|replaced variables: 14 
o|removed binding forms: 61 
o|Removed `not' forms: 1 
o|substituted constant variable: r27955024 
o|substituted constant variable: r34005041 
o|substituted constant variable: r34005042 
o|contracted procedure: k3877 
o|substituted constant variable: r38785062 
o|substituted constant variable: r41425071 
o|substituted constant variable: r41255072 
o|substituted constant variable: r41005075 
o|substituted constant variable: r40835076 
o|substituted constant variable: r42725081 
o|substituted constant variable: r42725082 
o|replaced variables: 4 
o|removed binding forms: 19 
o|removed conditional forms: 4 
o|replaced variables: 4 
o|removed binding forms: 14 
o|removed binding forms: 2 
o|simplifications: ((if . 9) (##core#call . 231)) 
o|  call simplifications:
o|    string->list
o|    string
o|    string=?	2
o|    not	2
o|    eof-object?
o|    ##sys#cons	7
o|    length
o|    ##sys#list	20
o|    list	2
o|    ##sys#make-structure
o|    ##sys#setslot	15
o|    first
o|    >
o|    ##sys#call-with-values	2
o|    add1	5
o|    car	10
o|    inexact->exact
o|    cddr
o|    cons	21
o|    string-length
o|    -	3
o|    fx<
o|    string-ref
o|    eq?	5
o|    *	2
o|    string->number	5
o|    ##sys#check-list	18
o|    pair?	27
o|    ##sys#slot	53
o|    memq	2
o|    apply
o|    cdr	3
o|    null?	10
o|    cadr	2
o|    symbol?	2
o|contracted procedure: k1637 
o|contracted procedure: k1616 
o|contracted procedure: k1624 
o|contracted procedure: k1630 
o|contracted procedure: k4725 
o|contracted procedure: k1646 
o|contracted procedure: k1669 
o|contracted procedure: k1718 
o|contracted procedure: k1802 
o|contracted procedure: k1814 
o|contracted procedure: k1824 
o|contracted procedure: k1828 
o|contracted procedure: k1834 
o|contracted procedure: k1837 
o|contracted procedure: k1849 
o|inlining procedure: k1840 
o|contracted procedure: k1855 
o|contracted procedure: k1861 
o|contracted procedure: k1864 
o|contracted procedure: k1871 
o|inlining procedure: k1840 
o|contracted procedure: k1885 
o|contracted procedure: k1888 
o|contracted procedure: k1895 
o|inlining procedure: k1840 
o|inlining procedure: k1840 
o|contracted procedure: k1930 
o|contracted procedure: k1950 
o|contracted procedure: k1991 
o|contracted procedure: k1999 
o|contracted procedure: k2045 
o|contracted procedure: k2051 
o|contracted procedure: k2058 
o|contracted procedure: k2064 
o|contracted procedure: k2112 
o|contracted procedure: k2122 
o|contracted procedure: k2268 
o|contracted procedure: k2286 
o|contracted procedure: k2297 
o|contracted procedure: k2324 
o|contracted procedure: k2464 
o|contracted procedure: k2473 
o|contracted procedure: k3163 
o|contracted procedure: k2513 
o|contracted procedure: k2626 
o|contracted procedure: k2632 
o|contracted procedure: k2642 
o|contracted procedure: k2687 
o|contracted procedure: k2694 
o|contracted procedure: k2659 
o|inlining procedure: "(batch-driver.scm:682) dribble116" 
o|inlining procedure: "(batch-driver.scm:682) dribble116" 
o|inlining procedure: "(batch-driver.scm:674) dribble116" 
o|contracted procedure: k2804 
o|contracted procedure: k2794 
o|contracted procedure: k2811 
o|inlining procedure: "(batch-driver.scm:653) dribble116" 
o|inlining procedure: "(batch-driver.scm:597) dribble116" 
o|contracted procedure: k2883 
o|contracted procedure: k2874 
o|contracted procedure: k2886 
o|contracted procedure: k2906 
o|contracted procedure: k2967 
o|contracted procedure: k2977 
o|contracted procedure: k2981 
o|contracted procedure: k2990 
o|contracted procedure: k3000 
o|contracted procedure: k3004 
o|contracted procedure: k3018 
o|inlining procedure: "(batch-driver.scm:535) dribble116" 
o|contracted procedure: k3030 
o|contracted procedure: k3042 
o|contracted procedure: k3052 
o|contracted procedure: k3056 
o|inlining procedure: "(batch-driver.scm:527) dribble116" 
o|contracted procedure: k3096 
o|contracted procedure: k3106 
o|contracted procedure: k3110 
o|contracted procedure: k3129 
o|contracted procedure: k3155 
o|contracted procedure: k3151 
o|contracted procedure: k3132 
o|contracted procedure: k3143 
o|contracted procedure: k3181 
o|contracted procedure: k3196 
o|contracted procedure: k3199 
o|contracted procedure: k3210 
o|contracted procedure: k3222 
o|inlining procedure: "(batch-driver.scm:501) dribble116" 
o|contracted procedure: k3230 
o|contracted procedure: k3267 
o|contracted procedure: k3305 
o|contracted procedure: k3317 
o|contracted procedure: k3327 
o|contracted procedure: k3331 
o|contracted procedure: k3302 
o|propagated global variable: g905907 ##compiler#compiler-syntax-statistics 
o|contracted procedure: k3350 
o|contracted procedure: k3362 
o|contracted procedure: k3392 
o|contracted procedure: k3417 
o|contracted procedure: k3420 
o|contracted procedure: k3431 
o|contracted procedure: k3443 
o|contracted procedure: k3389 
o|contracted procedure: k3379 
o|contracted procedure: k3383 
o|propagated global variable: g879883 ##compiler#profile-lambda-list 
o|contracted procedure: k3458 
o|contracted procedure: k3462 
o|contracted procedure: k3454 
o|contracted procedure: k3450 
o|contracted procedure: k3481 
o|contracted procedure: k3507 
o|contracted procedure: k3503 
o|contracted procedure: k3484 
o|contracted procedure: k3495 
o|propagated global variable: g842846 ##compiler#used-units 
o|contracted procedure: k3516 
o|contracted procedure: k3519 
o|contracted procedure: k3530 
o|contracted procedure: k3542 
o|contracted procedure: k3341 
o|contracted procedure: k3345 
o|propagated global variable: g812816 ##compiler#immutable-constants 
o|contracted procedure: k3551 
o|contracted procedure: k3554 
o|contracted procedure: k3565 
o|contracted procedure: k3577 
o|contracted procedure: k3600 
o|contracted procedure: k3596 
o|contracted procedure: k3592 
o|contracted procedure: k3588 
o|contracted procedure: k3584 
o|contracted procedure: k3603 
o|contracted procedure: k3619 
o|contracted procedure: k3615 
o|contracted procedure: k3611 
o|contracted procedure: k3626 
o|contracted procedure: k3638 
o|contracted procedure: k3641 
o|contracted procedure: k3652 
o|contracted procedure: k3664 
o|inlining procedure: "(batch-driver.scm:432) dribble116" 
o|inlining procedure: "(batch-driver.scm:409) dribble116" 
o|contracted procedure: k3683 
o|contracted procedure: k3691 
o|contracted procedure: k3702 
o|contracted procedure: k3714 
o|contracted procedure: k3717 
o|contracted procedure: k3728 
o|contracted procedure: k3740 
o|contracted procedure: k3749 
o|contracted procedure: k3752 
o|contracted procedure: k3763 
o|contracted procedure: k3775 
o|contracted procedure: k3778 
o|contracted procedure: k3812 
o|contracted procedure: k3819 
o|contracted procedure: k3835 
o|inlining procedure: "(batch-driver.scm:390) dribble116" 
o|contracted procedure: k3887 
o|contracted procedure: k3854 
o|inlining procedure: "(batch-driver.scm:369) dribble116" 
o|inlining procedure: "(batch-driver.scm:369) dribble116" 
o|inlining procedure: "(batch-driver.scm:351) dribble116" 
o|inlining procedure: "(batch-driver.scm:351) dribble116" 
o|contracted procedure: k3941 
o|contracted procedure: k3953 
o|contracted procedure: k3956 
o|contracted procedure: k3967 
o|contracted procedure: k3979 
o|contracted procedure: k3931 
o|contracted procedure: k3988 
o|contracted procedure: k3998 
o|contracted procedure: k4002 
o|inlining procedure: "(batch-driver.scm:316) dribble116" 
o|contracted procedure: k4011 
o|contracted procedure: k4021 
o|contracted procedure: k4025 
o|contracted procedure: k4044 
o|contracted procedure: k4054 
o|contracted procedure: k4058 
o|contracted procedure: k4114 
o|contracted procedure: k4156 
o|contracted procedure: k4168 
o|contracted procedure: k4178 
o|contracted procedure: k4182 
o|contracted procedure: k4147 
o|contracted procedure: k4141 
o|contracted procedure: k4130 
o|contracted procedure: k4124 
o|propagated global variable: g475477 ##compiler#default-extended-bindings 
o|contracted procedure: k4191 
o|contracted procedure: k4201 
o|contracted procedure: k4205 
o|contracted procedure: k4105 
o|contracted procedure: k4099 
o|contracted procedure: k4088 
o|contracted procedure: k4082 
o|propagated global variable: g426428 ##compiler#default-standard-bindings 
o|contracted procedure: k4238 
o|contracted procedure: k4241 
o|contracted procedure: k4252 
o|contracted procedure: k4264 
o|contracted procedure: k4271 
o|contracted procedure: k4287 
o|contracted procedure: k4299 
o|contracted procedure: k4302 
o|contracted procedure: k4313 
o|contracted procedure: k4325 
o|inlining procedure: "(batch-driver.scm:265) dribble116" 
o|inlining procedure: "(batch-driver.scm:262) dribble116" 
o|inlining procedure: "(batch-driver.scm:259) dribble116" 
o|contracted procedure: k4367 
o|inlining procedure: "(batch-driver.scm:249) dribble116" 
o|contracted procedure: k4407 
o|inlining procedure: "(batch-driver.scm:223) dribble116" 
o|contracted procedure: k4522 
o|contracted procedure: k4525 
o|contracted procedure: k4536 
o|contracted procedure: k4548 
o|contracted procedure: k4583 
o|contracted procedure: k4586 
o|contracted procedure: k4597 
o|contracted procedure: k4609 
o|contracted procedure: k4568 
o|contracted procedure: k4656 
o|contracted procedure: k4659 
o|contracted procedure: k4670 
o|contracted procedure: k4682 
o|contracted procedure: k4700 
o|contracted procedure: k4740 
o|contracted procedure: k4733 
o|simplifications: ((let . 45)) 
o|removed binding forms: 203 
o|removed side-effect free assignment to unused variable: dribble116 
o|substituted constant variable: fstr1265404 
o|substituted constant variable: args1275405 
o|substituted constant variable: fstr1265410 
o|substituted constant variable: args1275411 
o|substituted constant variable: fstr1265416 
o|substituted constant variable: fstr1265422 
o|substituted constant variable: fstr1265428 
o|contracted procedure: "(batch-driver.scm:533) g10281035" 
o|substituted constant variable: fstr1265440 
o|contracted procedure: "(batch-driver.scm:521) g10071014" 
o|substituted constant variable: fstr1265448 
o|inlining procedure: k3135 
o|inlining procedure: k3135 
o|inlining procedure: k3202 
o|inlining procedure: k3202 
o|substituted constant variable: fstr1265460 
o|substituted constant variable: args1275461 
o|inlining procedure: k3423 
o|inlining procedure: k3423 
o|inlining procedure: k3487 
o|inlining procedure: k3487 
o|inlining procedure: k3522 
o|inlining procedure: k3522 
o|inlining procedure: k3557 
o|inlining procedure: k3557 
o|inlining procedure: k3644 
o|inlining procedure: k3644 
o|substituted constant variable: fstr1265478 
o|substituted constant variable: args1275479 
o|substituted constant variable: fstr1265484 
o|substituted constant variable: args1275485 
o|inlining procedure: k3720 
o|inlining procedure: k3720 
o|inlining procedure: k3755 
o|inlining procedure: k3755 
o|substituted constant variable: fstr1265498 
o|substituted constant variable: fstr1265504 
o|substituted constant variable: fstr1265510 
o|substituted constant variable: fstr1265516 
o|substituted constant variable: fstr1265522 
o|inlining procedure: k3959 
o|inlining procedure: k3959 
o|substituted constant variable: fstr1265532 
o|substituted constant variable: args1275533 
o|inlining procedure: k4244 
o|inlining procedure: k4244 
o|inlining procedure: k4305 
o|inlining procedure: k4305 
o|substituted constant variable: fstr1265550 
o|substituted constant variable: args1275551 
o|substituted constant variable: fstr1265556 
o|substituted constant variable: args1275557 
o|substituted constant variable: fstr1265562 
o|substituted constant variable: args1275563 
o|substituted constant variable: fstr1265568 
o|substituted constant variable: args1275569 
o|substituted constant variable: fstr1265574 
o|substituted constant variable: args1275575 
o|inlining procedure: k4528 
o|inlining procedure: k4528 
o|inlining procedure: k4589 
o|inlining procedure: k4589 
o|inlining procedure: k4662 
o|inlining procedure: k4662 
o|replaced variables: 80 
o|removed binding forms: 3 
o|replaced variables: 1 
o|removed binding forms: 106 
o|contracted procedure: k3439 
o|contracted procedure: k3538 
o|replaced variables: 60 
o|removed binding forms: 3 
o|removed binding forms: 15 
o|customizable procedures: (g7273 map-loop7898 k1664 k1690 k2071 k2074 map-loop280298 map-loop308326 k2118 k2125 k2131 k2143 k2146 k2149 k2152 k2155 k2158 k2161 k2164 k2167 k2170 k2173 k2176 k2179 k2182 k2185 k2188 k2193 k2198 k2203 map-loop364381 map-loop393410 k2234 k2237 k2240 k2243 k2246 for-each-loop419461 for-each-loop468510 for-each-loop518536 for-each-loop543561 for-each-loop569580 map-loop588609 k2312 arg-val121 k2337 k2365 loop720 doloop655656 map-loop660677 map-loop686703 map-loop735752 k2446 k2455 k2461 map-loop767788 map-loop800821 map-loop830851 k3369 map-loop867888 for-each-loop898919 print-expr120 map-loop942959 map-loop980997 for-each-loop10061019 for-each-loop10271039 collect-options122 for-each-loop10501064 for-each-loop10711082 k2540 print-db119 print-node118 analyze125 begin-time123 end-time124 loop1107 def-no230268 def-contf231266 body228236 g208209 option-arg30 loop200 for-each-loop164176 print-header117) 
o|calls to known targets: 289 
o|identified direct recursive calls: f_3124 2 
o|identified direct recursive calls: f_3412 2 
o|identified direct recursive calls: f_3476 2 
o|identified direct recursive calls: f_3511 2 
o|fast box initializations: 39 
o|dropping unused closure argument: f_1710 
o|dropping unused closure argument: f_1611 
o|dropping unused closure argument: f_1832 
*/
/* end of file */
