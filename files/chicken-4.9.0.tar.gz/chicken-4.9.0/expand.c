/* Generated from expand.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:38
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: expand.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file expand.c
   unit: expand
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[356];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,14),40,108,111,111,107,117,112,32,115,101,50,52,55,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,26),40,109,97,99,114,111,45,97,108,105,97,115,32,118,97,114,50,54,50,32,115,101,50,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,51,51,49,32,105,51,51,51,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,11),40,119,97,108,107,32,120,51,48,50,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,27),40,35,35,115,121,115,35,115,116,114,105,112,45,115,121,110,116,97,120,32,101,120,112,50,57,57,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,52,49,56,32,103,52,51,48,52,52,48,32,103,52,51,49,52,52,49,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,34),40,102,111,114,45,101,97,99,104,45,108,111,111,112,51,56,49,32,103,51,56,56,52,48,57,32,103,51,56,57,52,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,51,53,53,32,103,51,54,55,51,55,51,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,101,120,116,101,110,100,45,115,101,32,115,101,51,52,53,32,118,97,114,115,51,52,54,32,46,32,116,109,112,51,52,52,51,52,55,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,11),40,103,52,54,53,32,97,52,54,55,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,101,52,54,57,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,49,32,115,121,109,52,53,52,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,103,108,111,98,97,108,105,122,101,32,115,121,109,52,53,49,32,115,101,52,53,50,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,101,110,115,117,114,101,45,116,114,97,110,115,102,111,114,109,101,114,32,116,52,56,54,32,46,32,116,109,112,52,56,53,52,56,55,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,6),40,103,53,48,57,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,61),40,35,35,115,121,115,35,101,120,116,101,110,100,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,110,97,109,101,52,57,56,32,115,101,52,57,57,32,116,114,97,110,115,102,111,114,109,101,114,53,48,48,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,99,111,112,121,45,109,97,99,114,111,32,111,108,100,53,49,55,32,110,101,119,53,49,56,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,109,97,99,114,111,63,32,115,121,109,53,50,54,32,46,32,116,109,112,53,50,53,53,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,109,101,53,52,49,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,109,97,99,114,111,32,110,97,109,101,53,51,57,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,117,110,100,101,102,105,110,101,45,109,97,99,114,111,33,32,110,97,109,101,53,52,57,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,112,115,53,55,53,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,52,51,49,52,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,13),40,97,52,51,48,56,32,101,120,53,55,50,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,17),40,102,95,52,52,52,51,32,105,110,112,117,116,53,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,7),40,97,52,52,52,56,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,7),40,97,52,52,53,51,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,52,52,53,57,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,10),40,116,109,112,49,51,48,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,52,52,55,50,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,21),40,116,109,112,50,51,48,56,52,32,97,114,103,115,53,54,54,53,57,56,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,52,52,48,57,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,97,52,51,48,50,32,107,53,54,53,53,55,49,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,52),40,99,97,108,108,45,104,97,110,100,108,101,114,32,110,97,109,101,53,53,54,32,104,97,110,100,108,101,114,53,53,55,32,101,120,112,53,53,56,32,115,101,53,53,57,32,99,115,53,54,48,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,31),40,101,120,112,97,110,100,32,104,101,97,100,54,48,49,32,101,120,112,54,48,50,32,109,100,101,102,54,48,51,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,54,54,53,32,103,54,55,55,54,56,51,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,54,51,56,32,103,54,53,48,54,53,55,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,103,54,57,56,32,99,115,55,48,48,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,54,49,50,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,101,120,112,97,110,100,45,48,32,101,120,112,53,53,49,32,100,115,101,53,53,50,32,99,115,63,53,53,51,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,52,56,48,49,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,32),40,97,52,56,48,55,32,101,120,112,50,55,51,51,55,51,52,55,51,55,32,109,55,51,53,55,51,54,55,51,56,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,55,51,50,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,101,120,112,97,110,100,32,101,120,112,55,49,57,32,46,32,116,109,112,55,49,56,55,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,108,105,115,116,55,52,54,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,63,32,108,108,105,115,116,55,52,52,41,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,12),40,101,114,114,32,109,115,103,55,54,57,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,11),40,103,56,48,48,32,107,56,49,49,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,55,57,52,32,103,56,48,54,56,50,51,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,109,111,100,101,55,55,57,32,114,101,113,55,56,48,32,111,112,116,55,56,49,32,107,101,121,55,56,50,32,108,108,105,115,116,55,56,51,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,67),40,35,35,115,121,115,35,101,120,112,97,110,100,45,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,32,108,108,105,115,116,48,55,54,51,32,98,111,100,121,55,54,52,32,101,114,114,104,55,54,53,32,115,101,55,54,54,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,100,101,102,106,97,109,45,101,114,114,111,114,32,102,111,114,109,56,57,49,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,12),40,99,111,109,112,32,105,100,57,49,56,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,98,111,100,121,50,57,51,54,32,101,120,112,115,57,51,55,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,34),40,109,97,112,45,108,111,111,112,49,48,54,57,32,103,49,48,56,49,49,48,57,52,32,103,49,48,56,50,49,48,57,53,41,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,52,48,32,103,49,48,53,50,49,48,53,56,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,34),40,109,97,112,45,108,111,111,112,49,48,49,54,32,103,49,48,50,56,49,49,48,52,32,103,49,48,50,57,49,49,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,31),40,109,97,112,45,108,111,111,112,57,56,48,32,103,57,57,50,49,48,48,53,32,103,57,57,51,49,48,48,54,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,57,53,51,32,103,57,54,53,57,55,50,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,48),40,102,105,110,105,32,118,97,114,115,57,50,57,32,118,97,108,115,57,51,48,32,109,118,97,114,115,57,51,49,32,109,118,97,108,115,57,51,50,32,98,111,100,121,57,51,51,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,51,52,32,103,49,49,52,54,49,49,53,50,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,33),40,108,111,111,112,32,98,111,100,121,49,49,50,50,32,100,101,102,115,49,49,50,51,32,100,111,110,101,49,49,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,60),40,102,105,110,105,47,115,121,110,116,97,120,32,118,97,114,115,49,49,49,54,32,118,97,108,115,49,49,49,55,32,109,118,97,114,115,49,49,49,56,32,109,118,97,108,115,49,49,49,57,32,98,111,100,121,49,49,50,48,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,50,32,120,49,49,56,57,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,53),40,108,111,111,112,32,98,111,100,121,49,49,55,50,32,118,97,114,115,49,49,55,51,32,118,97,108,115,49,49,55,52,32,109,118,97,114,115,49,49,55,53,32,109,118,97,108,115,49,49,55,54,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,17),40,101,120,112,97,110,100,32,98,111,100,121,49,49,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,99,97,110,111,110,105,99,97,108,105,122,101,45,98,111,100,121,32,98,111,100,121,57,48,49,32,46,32,116,109,112,57,48,48,57,48,50,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,7),40,103,49,50,51,52,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,19),40,109,119,97,108,107,32,120,49,50,50,50,32,112,49,50,50,51,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,43),40,109,97,116,99,104,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,49,50,49,54,32,112,97,116,49,50,49,55,32,118,97,114,115,49,50,49,56,41,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,104,101,97,100,49,50,52,54,32,98,111,100,121,49,50,52,55,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,101,120,112,97,110,100,45,99,117,114,114,105,101,100,45,100,101,102,105,110,101,32,104,101,97,100,49,50,52,49,32,98,111,100,121,49,50,52,50,32,115,101,49,50,52,51,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,45,104,111,111,107,32,46,32,97,114,103,115,49,50,54,49,41,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,16),40,111,117,116,115,116,114,32,115,116,114,49,50,55,57,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,49,50,57,56,41,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,100,101,102,115,49,50,54,56,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,99,120,49,50,56,49,41,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,47,99,111,110,116,101,120,116,32,109,115,103,49,50,54,51,32,97,114,103,49,50,54,52,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,115,121,110,116,97,120,45,114,117,108,101,115,45,109,105,115,109,97,116,99,104,32,105,110,112,117,116,49,51,49,50,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,7),40,103,49,51,50,53,41,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,26),40,103,101,116,45,108,105,110,101,45,110,117,109,98,101,114,32,115,101,120,112,49,51,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,29),40,116,101,115,116,32,120,49,51,53,52,32,112,114,101,100,49,51,53,53,32,109,115,103,49,51,53,54,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,13),40,101,114,114,32,109,115,103,49,51,53,55,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,49,51,54,53,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,20),40,108,97,109,98,100,97,45,108,105,115,116,63,32,120,49,51,54,48,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,20),40,112,114,111,112,101,114,45,108,105,115,116,63,32,120,49,51,55,55,41,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,52,48,51,32,120,49,52,48,53,32,110,49,52,48,54,41};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,13),40,97,55,50,51,51,32,121,49,52,49,57,41,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,51,56,57,32,112,49,51,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,99,104,101,99,107,45,115,121,110,116,97,120,32,105,100,49,51,51,54,32,101,120,112,49,51,51,55,32,112,97,116,49,51,51,56,32,46,32,116,109,112,49,51,51,53,49,51,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,13),40,103,49,52,53,55,32,97,49,52,53,57,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,16),40,114,101,110,97,109,101,32,115,121,109,49,52,52,51,41};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,53,49,48,32,105,49,53,49,50,32,102,49,53,49,51,41};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,7),40,103,49,53,54,53,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,7),40,103,49,53,55,52,41,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,23),40,99,111,109,112,97,114,101,32,115,49,49,52,57,56,32,115,50,49,52,57,57,41,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,20),40,97,115,115,113,45,114,101,118,101,114,115,101,32,108,49,53,56,56,41,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,23),40,109,105,114,114,111,114,45,114,101,110,97,109,101,32,115,121,109,49,53,57,51,41,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,31),40,97,55,51,52,57,32,102,111,114,109,49,52,51,50,32,115,101,49,52,51,51,32,100,115,101,49,52,51,52,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,59),40,109,97,107,101,45,101,114,47,105,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,52,51,48,32,101,120,112,108,105,99,105,116,45,114,101,110,97,109,105,110,103,63,49,52,51,49,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,101,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,54,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,105,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,54,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,54,52,56,32,103,49,54,53,53,49,54,54,53,41,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,109,97,114,107,45,112,114,105,109,105,116,105,118,101,32,112,114,105,109,115,49,54,52,53,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,33),40,108,111,111,112,32,98,115,49,56,49,52,32,115,101,101,110,49,56,49,53,32,119,97,114,110,101,100,49,56,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,59),40,99,104,101,99,107,45,102,111,114,45,109,117,108,116,105,112,108,101,45,98,105,110,100,105,110,103,115,32,98,105,110,100,105,110,103,115,49,56,49,48,32,102,111,114,109,49,56,49,49,32,108,111,99,49,56,49,50,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,14),40,102,95,56,50,52,51,32,120,50,52,55,57,41,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,52,56,54,32,103,50,52,57,56,50,53,48,52,41};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,18),40,102,95,56,50,52,57,32,114,117,108,101,115,50,52,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,13),40,97,56,51,55,56,32,120,50,53,49,56,41,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,17),40,102,95,56,51,52,49,32,114,117,108,101,50,53,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,48),40,102,95,56,52,48,55,32,105,110,112,117,116,50,53,49,57,32,112,97,116,116,101,114,110,50,53,50,48,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,53,50,49,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,30),40,102,95,56,53,56,56,32,105,110,112,117,116,50,53,53,57,32,112,97,116,116,101,114,110,50,53,54,48,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,13),40,97,56,55,55,51,32,120,50,53,56,49,41,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,57),40,102,95,56,55,49,53,32,112,97,116,116,101,114,110,50,53,54,56,32,112,97,116,104,50,53,54,57,32,109,97,112,105,116,50,53,55,48,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,53,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,50,54,50,48,32,100,50,54,50,50,32,103,101,110,50,54,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,37),40,102,95,56,56,53,53,32,116,101,109,112,108,97,116,101,50,53,57,55,32,100,105,109,50,53,57,56,32,101,110,118,50,53,57,57,41,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,55),40,102,95,57,48,52,55,32,112,97,116,116,101,114,110,50,54,52,48,32,100,105,109,50,54,52,49,32,118,97,114,115,50,54,52,50,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,54,52,51,41,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,46),40,102,95,57,49,50,52,32,116,101,109,112,108,97,116,101,50,54,52,56,32,100,105,109,50,54,52,57,32,101,110,118,50,54,53,48,32,102,114,101,101,50,54,53,49,41,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,32),40,102,95,57,50,49,51,32,112,50,54,53,57,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,54,54,48,41};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,20),40,102,95,57,50,52,49,32,112,97,116,116,101,114,110,50,54,54,54,41,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,20),40,102,95,57,50,54,53,32,112,97,116,116,101,114,110,50,54,54,57,41,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,97,116,116,101,114,110,50,54,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,20),40,102,95,57,50,56,53,32,112,97,116,116,101,114,110,50,54,55,48,41,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,79),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,115,121,110,116,97,120,45,114,117,108,101,115,32,101,108,108,105,112,115,105,115,50,52,50,50,32,114,117,108,101,115,50,52,50,51,32,115,117,98,107,101,121,119,111,114,100,115,50,52,50,52,32,114,50,52,50,53,32,99,50,52,50,54,41,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,50,55,52,51,41,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,109,97,99,114,111,45,115,117,98,115,101,116,32,109,101,48,50,55,51,52,32,46,32,116,109,112,50,55,51,51,50,55,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,16),40,103,50,55,54,53,32,115,100,101,102,50,55,55,52,41};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,50,55,54,52,32,103,50,55,55,49,50,55,55,54,41,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,52),40,35,35,115,121,115,35,102,105,120,117,112,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,115,101,50,55,53,52,32,46,32,116,109,112,50,55,53,51,50,55,53,53,41,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,27),40,97,57,52,55,50,32,101,120,112,50,52,49,48,32,114,50,52,49,49,32,99,50,52,49,50,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,25),40,97,57,53,48,56,32,120,50,52,48,52,32,114,50,52,48,53,32,99,50,52,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,25),40,97,57,53,51,53,32,120,50,51,57,51,32,114,50,51,57,52,32,99,50,51,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,25),40,97,57,53,54,53,32,120,50,51,53,53,32,114,50,51,53,54,32,99,50,51,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,25),40,97,57,55,52,53,32,120,50,51,52,57,32,114,50,51,53,48,32,99,50,51,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,25),40,97,57,55,55,49,32,120,50,51,52,50,32,114,50,51,52,51,32,99,50,51,52,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,25),40,97,57,55,56,52,32,120,50,51,51,53,32,114,50,51,51,54,32,99,50,51,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,11),40,101,114,114,32,120,50,50,53,57,41,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,13),40,116,101,115,116,32,102,120,50,50,54,48,41,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,50,57,51,32,103,50,51,48,53,50,51,49,50,41};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,99,108,115,50,50,56,54,41};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,28),40,97,57,55,57,55,32,102,111,114,109,50,50,52,57,32,114,50,50,53,48,32,99,50,50,53,49,41,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,29),40,97,49,48,48,56,55,32,102,111,114,109,50,50,52,50,32,114,50,50,52,51,32,99,50,50,52,52,41,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,29),40,97,49,48,49,48,56,32,102,111,114,109,50,50,51,53,32,114,50,50,51,54,32,99,50,50,51,55,41,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,50,49,54,48,32,110,50,49,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,19),40,119,97,108,107,49,32,120,50,49,54,50,32,110,50,49,54,51,41,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,15),40,103,50,50,49,51,32,101,110,118,50,50,49,53,41,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,15),40,103,50,50,50,48,32,101,110,118,50,50,50,50,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,16),40,115,105,109,112,108,105,102,121,32,120,50,50,48,54,41};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,29),40,97,49,48,49,52,49,32,102,111,114,109,50,49,53,49,32,114,50,49,53,50,32,99,50,49,53,51,41,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,49,50,53,32,103,50,49,51,55,50,49,52,52,41};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,48,57,49,32,103,50,49,48,51,50,49,49,48,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,29),40,97,49,48,52,51,52,32,102,111,114,109,50,48,55,57,32,114,50,48,56,48,32,99,50,48,56,49,41,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,15),40,101,120,112,97,110,100,32,98,115,50,48,55,48,41,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,29),40,97,49,48,54,50,54,32,102,111,114,109,50,48,54,52,32,114,50,48,54,53,32,99,50,48,54,54,41,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,7),40,103,50,48,51,50,41,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,48,50,54,32,103,50,48,51,56,50,48,52,56,41};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,30),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,50,48,48,51,32,101,108,115,101,63,50,48,48,52,41,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,29),40,97,49,48,54,55,55,32,102,111,114,109,49,57,56,57,32,114,49,57,57,48,32,99,49,57,57,49,41,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,30),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,57,49,54,32,101,108,115,101,63,49,57,49,55,41,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,29),40,97,49,48,57,48,48,32,102,111,114,109,49,57,48,56,32,114,49,57,48,57,32,99,49,57,49,48,41,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,29),40,97,49,49,50,52,49,32,102,111,114,109,49,56,57,56,32,114,49,56,57,57,32,99,49,57,48,48,41,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,29),40,97,49,49,50,57,51,32,102,111,114,109,49,56,56,57,32,114,49,56,57,48,32,99,49,56,57,49,41,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,26),40,97,49,49,51,51,48,32,120,49,56,55,51,32,114,49,56,55,52,32,99,49,56,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,26),40,97,49,49,51,55,52,32,120,49,56,54,53,32,114,49,56,54,54,32,99,49,56,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,26),40,97,49,49,51,57,54,32,120,49,56,53,55,32,114,49,56,53,56,32,99,49,56,53,57,41,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,26),40,97,49,49,52,49,56,32,120,49,56,52,57,32,114,49,56,53,48,32,99,49,56,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,26),40,97,49,49,52,52,48,32,120,49,56,52,49,32,114,49,56,52,50,32,99,49,56,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,26),40,97,49,49,52,54,50,32,120,49,56,50,55,32,114,49,56,50,56,32,99,49,56,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,29),40,97,49,49,53,49,52,32,102,111,114,109,49,55,55,57,32,114,49,55,56,48,32,99,49,55,56,49,41,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,102,111,114,109,49,55,53,49,41,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,26),40,97,49,49,54,49,55,32,120,49,55,52,55,32,114,49,55,52,56,32,99,49,55,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,51,54,32,120,49,55,52,48,32,114,49,55,52,49,32,99,49,55,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,53,51,32,120,49,55,51,51,32,114,49,55,51,52,32,99,49,55,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,55,48,32,120,49,55,50,54,32,114,49,55,50,55,32,99,49,55,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,56,55,32,120,49,55,49,57,32,114,49,55,50,48,32,99,49,55,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,26),40,97,49,49,56,48,52,32,120,49,55,49,50,32,114,49,55,49,51,32,99,49,55,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,50),40,97,49,49,56,50,49,32,103,49,55,48,48,49,55,48,49,49,55,48,54,32,103,49,55,48,50,49,55,48,51,49,55,48,55,32,103,49,55,48,52,49,55,48,53,49,55,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,50),40,97,49,49,56,51,49,32,103,49,54,56,54,49,54,56,55,49,54,57,50,32,103,49,54,56,56,49,54,56,57,49,54,57,51,32,103,49,54,57,48,49,54,57,49,49,54,57,52,41,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,50),40,97,49,49,56,52,49,32,103,49,54,55,50,49,54,55,51,49,54,55,56,32,103,49,54,55,52,49,54,55,53,49,54,55,57,32,103,49,54,55,54,49,54,55,55,49,54,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_11417)
static void C_ccall f_11417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11419)
static void C_ccall f_11419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8241)
static void C_ccall f_8241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8555)
static void C_fcall f_8555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11404)
static void C_ccall f_11404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11401)
static void C_ccall f_11401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8542)
static void C_ccall f_8542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_expand_toplevel)
C_externexport void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5771)
static void C_fcall f_5771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8534)
static void C_ccall f_8534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9736)
static void C_ccall f_9736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8207)
static void C_ccall f_8207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6689)
static void C_ccall f_6689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8203)
static void C_ccall f_8203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9722)
static void C_ccall f_9722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11515)
static void C_ccall f_11515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11513)
static void C_ccall f_11513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8298)
static void C_fcall f_8298(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6889)
static void C_ccall f_6889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6889)
static void C_ccall f_6889r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5758)
static void C_fcall f_5758(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8228)
static void C_ccall f_8228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4288)
static void C_fcall f_4288(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8224)
static void C_ccall f_8224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11382)
static void C_ccall f_11382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8820)
static void C_ccall f_8820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11395)
static void C_ccall f_11395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11397)
static void C_ccall f_11397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8284)
static void C_ccall f_8284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8824)
static void C_ccall f_8824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6844)
static void C_ccall f_6844(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11379)
static void C_ccall f_11379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7672)
static C_word C_fcall f_7672(C_word t0,C_word t1);
C_noret_decl(f_11375)
static void C_ccall f_11375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11373)
static void C_ccall f_11373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6874)
static C_word C_fcall f_6874(C_word t0,C_word t1);
C_noret_decl(f_11358)
static void C_ccall f_11358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11325)
static void C_ccall f_11325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11329)
static void C_ccall f_11329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11335)
static void C_ccall f_11335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11331)
static void C_ccall f_11331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7687)
static void C_ccall f_7687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_fcall f_3656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5146)
static void C_fcall f_5146(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8118)
static void C_ccall f_8118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8115)
static void C_ccall f_8115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_fcall f_6178(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4666)
static void C_fcall f_4666(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11786)
static void C_ccall f_11786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11788)
static void C_ccall f_11788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5227)
static void C_fcall f_5227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11792)
static void C_ccall f_11792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11769)
static void C_ccall f_11769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_fcall f_5240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6184)
static void C_fcall f_6184(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_11775)
static void C_ccall f_11775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11771)
static void C_ccall f_11771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11533)
static void C_ccall f_11533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11741)
static void C_ccall f_11741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11530)
static void C_ccall f_11530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11758)
static void C_ccall f_11758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11754)
static void C_ccall f_11754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11547)
static void C_ccall f_11547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11544)
static void C_ccall f_11544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11752)
static void C_ccall f_11752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7535)
static void C_ccall f_7535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10178)
static void C_ccall f_10178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11737)
static void C_ccall f_11737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11735)
static void C_ccall f_11735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10182)
static void C_ccall f_10182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11574)
static void C_ccall f_11574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11577)
static void C_ccall f_11577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11571)
static void C_ccall f_11571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6707)
static void C_fcall f_6707(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6705)
static void C_ccall f_6705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6736)
static void C_ccall f_6736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6726)
static void C_ccall f_6726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6723)
static void C_ccall f_6723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6720)
static void C_ccall f_6720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10149)
static void C_ccall f_10149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10146)
static void C_ccall f_10146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7593)
static void C_ccall f_7593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10140)
static void C_ccall f_10140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10142)
static void C_ccall f_10142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10154)
static void C_fcall f_10154(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10152)
static void C_ccall f_10152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9338)
static void C_fcall f_9338(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9336)
static void C_ccall f_9336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_fcall f_3809(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5277)
static void C_fcall f_5277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5274)
static void C_fcall f_5274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_fcall f_4412(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10162)
static void C_ccall f_10162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10164)
static void C_fcall f_10164(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7572)
static void C_fcall f_7572(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10120)
static void C_ccall f_10120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11700)
static void C_ccall f_11700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11557)
static void C_ccall f_11557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11115)
static void C_ccall f_11115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11568)
static void C_ccall f_11568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11564)
static void C_ccall f_11564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11018)
static void C_ccall f_11018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11012)
static void C_ccall f_11012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11021)
static void C_ccall f_11021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9396)
static void C_ccall f_9396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9329)
static void C_ccall f_9329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9322)
static void C_ccall f_9322(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9322)
static void C_ccall f_9322r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6019)
static void C_ccall f_6019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9372)
static void C_ccall f_9372(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9372)
static void C_ccall f_9372r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9379)
static void C_ccall f_9379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9177)
static void C_ccall f_9177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6000)
static void C_fcall f_6000(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9380)
static void C_fcall f_9380(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9359)
static void C_ccall f_9359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7398)
static void C_ccall f_7398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7394)
static void C_ccall f_7394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9166)
static void C_ccall f_9166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7715)
static void C_ccall f_7715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8085)
static void C_ccall f_8085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8088)
static void C_ccall f_8088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9606)
static void C_ccall f_9606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9603)
static void C_ccall f_9603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11809)
static void C_ccall f_11809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11805)
static void C_ccall f_11805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11803)
static void C_ccall f_11803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11088)
static void C_ccall f_11088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11061)
static void C_ccall f_11061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9302)
static void C_ccall f_9302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6743)
static void C_ccall f_6743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11058)
static void C_ccall f_11058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11820)
static void C_ccall f_11820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11822)
static void C_ccall f_11822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11040)
static void C_ccall f_11040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6764)
static void C_ccall f_6764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_fcall f_5617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7700)
static C_word C_fcall f_7700(C_word t0,C_word t1);
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8001)
static void C_ccall f_8001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6783)
static void C_ccall f_6783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8013)
static void C_fcall f_8013(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6492)
static C_word C_fcall f_6492(C_word t0,C_word t1);
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5807)
static void C_fcall f_5807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9196)
static void C_ccall f_9196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9637)
static void C_ccall f_9637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7357)
static void C_ccall f_7357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_fcall f_4486(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7350)
static void C_ccall f_7350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9124)
static void C_ccall f_9124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10357)
static void C_ccall f_10357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11627)
static void C_fcall f_11627(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11622)
static void C_ccall f_11622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8046)
static void C_ccall f_8046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10327)
static void C_fcall f_10327(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11618)
static void C_ccall f_11618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11616)
static void C_ccall f_11616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8091)
static void C_ccall f_8091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8094)
static void C_ccall f_8094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8029)
static void C_ccall f_8029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8026)
static void C_fcall f_8026(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6798)
static void C_ccall f_6798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8097)
static void C_ccall f_8097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6975)
static void C_ccall f_6975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8715)
static void C_ccall f_8715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10361)
static void C_fcall f_10361(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10796)
static void C_fcall f_10796(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10331)
static void C_ccall f_10331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10335)
static void C_fcall f_10335(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10451)
static void C_ccall f_10451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10439)
static void C_ccall f_10439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8921)
static void C_ccall f_8921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10435)
static void C_ccall f_10435(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10433)
static void C_ccall f_10433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11488)
static void C_ccall f_11488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10899)
static void C_ccall f_10899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_fcall f_6955(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8903)
static void C_ccall f_8903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10497)
static void C_fcall f_10497(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11467)
static void C_ccall f_11467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11463)
static void C_ccall f_11463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11461)
static void C_ccall f_11461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6941)
static void C_ccall f_6941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6943)
static void C_ccall f_6943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6947)
static void C_ccall f_6947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8938)
static void C_ccall f_8938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8934)
static void C_ccall f_8934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10422)
static void C_ccall f_10422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11478)
static void C_ccall f_11478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11475)
static void C_fcall f_11475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10313)
static void C_ccall f_10313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10476)
static void C_ccall f_10476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11445)
static void C_ccall f_11445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11448)
static void C_ccall f_11448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8918)
static void C_fcall f_8918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8915)
static void C_ccall f_8915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_fcall f_4039(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11423)
static void C_ccall f_11423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11426)
static void C_ccall f_11426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10309)
static void C_ccall f_10309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10933)
static void C_ccall f_10933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11439)
static void C_ccall f_11439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_fcall f_4057(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10939)
static void C_ccall f_10939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7496)
static void C_ccall f_7496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4467)
static void C_fcall f_4467(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_ccall f_8739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11441)
static void C_ccall f_11441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5900)
static void C_fcall f_5900(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6620)
static void C_ccall f_6620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6478)
static void C_fcall f_6478(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5913)
static void C_fcall f_5913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10908)
static void C_ccall f_10908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6475)
static void C_fcall f_6475(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10901)
static void C_ccall f_10901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4023)
static void C_fcall f_4023(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10911)
static void C_ccall f_10911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10914)
static void C_ccall f_10914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10404)
static void C_ccall f_10404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10919)
static void C_fcall f_10919(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6638)
static void C_fcall f_6638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6916)
static void C_fcall f_6916(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6911)
static void C_ccall f_6911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_fcall f_4326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7750)
static C_word C_fcall f_7750(C_word t0,C_word t1);
C_noret_decl(f_9295)
static void C_fcall f_9295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6904)
static void C_fcall f_6904(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4926)
static void C_fcall f_4926(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4073)
static void C_fcall f_4073(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10201)
static void C_ccall f_10201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7775)
static void C_fcall f_7775(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11832)
static void C_ccall f_11832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11830)
static void C_ccall f_11830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7446)
static void C_fcall f_7446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9017)
static void C_ccall f_9017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11842)
static void C_ccall f_11842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11840)
static void C_ccall f_11840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7449)
static void C_ccall f_7449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_fcall f_3884(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7793)
static void C_ccall f_7793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11642)
static void C_ccall f_11642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_fcall f_3897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11697)
static void C_ccall f_11697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11690)
static void C_ccall f_11690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6802)
static void C_ccall f_6802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6804)
static void C_fcall f_6804(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10735)
static void C_ccall f_10735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10738)
static void C_ccall f_10738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11677)
static void C_ccall f_11677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5081)
static void C_fcall f_5081(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11670)
static void C_ccall f_11670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10742)
static void C_ccall f_10742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10748)
static void C_ccall f_10748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4599)
static void C_fcall f_4599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11681)
static void C_ccall f_11681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_fcall f_4709(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4705)
static void C_fcall f_4705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10751)
static void C_ccall f_10751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10757)
static void C_ccall f_10757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9783)
static void C_ccall f_9783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9785)
static void C_ccall f_9785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6934)
static void C_ccall f_6934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9798)
static void C_ccall f_9798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9796)
static void C_ccall f_9796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6920)
static void C_ccall f_6920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7789)
static void C_ccall f_7789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9241)
static void C_ccall f_9241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9762)
static void C_ccall f_9762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9772)
static void C_ccall f_9772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9770)
static void C_ccall f_9770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9962)
static void C_fcall f_9962(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10850)
static void C_fcall f_10850(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9744)
static void C_ccall f_9744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9746)
static void C_ccall f_9746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9220)
static void C_ccall f_9220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9754)
static void C_ccall f_9754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9946)
static void C_ccall f_9946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10833)
static C_word C_fcall f_10833(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_8855)
static void C_ccall f_8855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8341)
static void C_ccall f_8341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5864)
static void C_fcall f_5864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8348)
static void C_fcall f_8348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10848)
static void C_ccall f_10848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9573)
static void C_ccall f_9573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9579)
static void C_ccall f_9579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7428)
static void C_fcall f_7428(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8849)
static void C_ccall f_8849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11656)
static void C_ccall f_11656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11653)
static void C_ccall f_11653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9582)
static void C_ccall f_9582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5849)
static void C_ccall f_5849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9986)
static void C_fcall f_9986(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9984)
static void C_ccall f_9984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11206)
static void C_ccall f_11206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5851)
static void C_fcall f_5851(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3933)
static void C_fcall f_3933(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8894)
static void C_ccall f_8894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8481)
static void C_ccall f_8481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8485)
static void C_ccall f_8485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8897)
static void C_ccall f_8897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7918)
static void C_ccall f_7918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8477)
static void C_ccall f_8477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11190)
static void C_ccall f_11190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10803)
static void C_ccall f_10803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_fcall f_5949(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10800)
static void C_ccall f_10800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9519)
static void C_ccall f_9519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9516)
static void C_ccall f_9516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9513)
static void C_ccall f_9513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9285)
static void C_ccall f_9285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9526)
static void C_ccall f_9526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11178)
static void C_ccall f_11178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9211)
static void C_ccall f_9211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9213)
static void C_ccall f_9213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4343)
static void C_fcall f_4343(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9107)
static void C_ccall f_9107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9265)
static void C_ccall f_9265(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9272)
static void C_ccall f_9272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9279)
static void C_ccall f_9279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9073)
static void C_ccall f_9073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9564)
static void C_ccall f_9564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9566)
static void C_ccall f_9566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8384)
static void C_ccall f_8384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9536)
static void C_ccall f_9536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8407)
static void C_ccall f_8407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9534)
static void C_ccall f_9534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8373)
static void C_ccall f_8373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8191)
static void C_ccall f_8191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8379)
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8377)
static void C_ccall f_8377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8199)
static void C_ccall f_8199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8195)
static void C_ccall f_8195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9543)
static void C_ccall f_9543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9540)
static void C_ccall f_9540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7926)
static void C_ccall f_7926(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10109)
static void C_ccall f_10109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10107)
static void C_ccall f_10107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8172)
static void C_ccall f_8172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9939)
static void C_ccall f_9939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8441)
static void C_ccall f_8441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10113)
static void C_ccall f_10113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10625)
static void C_ccall f_10625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10627)
static void C_ccall f_10627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9912)
static void C_ccall f_9912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8109)
static void C_ccall f_8109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8103)
static void C_ccall f_8103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8106)
static void C_ccall f_8106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4530)
static void C_fcall f_4530(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8100)
static void C_ccall f_8100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4944)
static void C_fcall f_4944(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9826)
static void C_fcall f_9826(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5998)
static void C_ccall f_5998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9042)
static void C_ccall f_9042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9047)
static void C_ccall f_9047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9021)
static void C_ccall f_9021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5990)
static void C_fcall f_5990(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4554)
static void C_fcall f_4554(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static C_word C_fcall f_4156(C_word t0,C_word t1);
C_noret_decl(f_7005)
static void C_ccall f_7005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7003)
static void C_ccall f_7003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4956)
static void C_fcall f_4956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8145)
static void C_ccall f_8145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7011)
static C_word C_fcall f_7011(C_word t0);
C_noret_decl(f_8148)
static void C_ccall f_8148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9088)
static void C_ccall f_9088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10255)
static void C_ccall f_10255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8121)
static void C_ccall f_8121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8124)
static void C_ccall f_8124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10588)
static void C_fcall f_10588(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10224)
static void C_ccall f_10224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8150)
static void C_ccall f_8150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8157)
static void C_ccall f_8157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10234)
static void C_ccall f_10234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8181)
static void C_ccall f_8181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_fcall f_4360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8187)
static void C_ccall f_8187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10535)
static void C_ccall f_10535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10693)
static void C_ccall f_10693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10690)
static void C_ccall f_10690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10537)
static void C_fcall f_10537(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10696)
static void C_ccall f_10696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10699)
static void C_ccall f_10699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8139)
static void C_ccall f_8139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10294)
static void C_ccall f_10294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10264)
static void C_ccall f_10264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10676)
static void C_ccall f_10676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10678)
static void C_ccall f_10678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6532)
static void C_ccall f_6532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10275)
static void C_ccall f_10275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4768)
static void C_ccall f_4768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10050)
static void C_ccall f_10050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10682)
static void C_ccall f_10682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10066)
static void C_ccall f_10066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10245)
static void C_ccall f_10245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_fcall f_4796(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3979)
static void C_fcall f_3979(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9816)
static void C_fcall f_9816(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9814)
static void C_ccall f_9814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9811)
static void C_ccall f_9811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9808)
static void C_ccall f_9808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9805)
static void C_ccall f_9805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10092)
static void C_ccall f_10092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10286)
static void C_ccall f_10286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5316)
static void C_fcall f_5316(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10210)
static void C_ccall f_10210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_fcall f_5403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6299)
static void C_ccall f_6299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8007)
static void C_fcall f_8007(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8005)
static void C_ccall f_8005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10086)
static void C_ccall f_10086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10088)
static void C_ccall f_10088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6557)
static void C_ccall f_6557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_fcall f_6204(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7972)
static void C_ccall f_7972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7978)
static void C_ccall f_7978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6560)
static void C_fcall f_6560(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_fcall f_6227(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7982)
static void C_ccall f_7982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6222)
static void C_ccall f_6222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7988)
static void C_ccall f_7988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7985)
static void C_ccall f_7985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7991)
static void C_ccall f_7991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7997)
static void C_ccall f_7997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7994)
static void C_ccall f_7994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10971)
static void C_ccall f_10971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10977)
static void C_ccall f_10977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10974)
static void C_ccall f_10974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_fcall f_6024(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6243)
static void C_ccall f_6243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10566)
static void C_fcall f_10566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10995)
static void C_ccall f_10995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5505)
static void C_ccall f_5505(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5505)
static void C_ccall f_5505r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_fcall f_7948(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6072)
static void C_fcall f_6072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5520)
static C_word C_fcall f_5520(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static C_word C_fcall f_3629(C_word t0,C_word t1);
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7291)
static void C_ccall f_7291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10666)
static void C_ccall f_10666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7632)
static void C_fcall f_7632(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8671)
static void C_ccall f_8671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10631)
static void C_ccall f_10631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9688)
static void C_fcall f_9688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3710)
static void C_fcall f_3710(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10641)
static void C_fcall f_10641(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9840)
static void C_ccall f_9840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9877)
static void C_ccall f_9877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7624)
static void C_fcall f_7624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8647)
static void C_ccall f_8647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8965)
static void C_fcall f_8965(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9644)
static void C_ccall f_9644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9647)
static void C_ccall f_9647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9859)
static void C_ccall f_9859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9641)
static void C_ccall f_9641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9659)
static void C_ccall f_9659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9494)
static void C_ccall f_9494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9471)
static void C_ccall f_9471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8944)
static void C_fcall f_8944(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8774)
static void C_ccall f_8774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8762)
static void C_ccall f_8762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7032)
static void C_fcall f_7032(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7037)
static void C_fcall f_7037(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7234)
static void C_ccall f_7234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9473)
static void C_ccall f_9473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9477)
static void C_ccall f_9477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5496)
static void C_ccall f_5496(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8758)
static void C_ccall f_8758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10942)
static void C_ccall f_10942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10946)
static void C_ccall f_10946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9507)
static void C_ccall f_9507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9509)
static void C_ccall f_9509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9897)
static void C_ccall f_9897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8745)
static void C_ccall f_8745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7056)
static void C_fcall f_7056(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10952)
static void C_ccall f_10952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10955)
static void C_ccall f_10955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10958)
static void C_ccall f_10958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11242)
static void C_ccall f_11242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11240)
static void C_ccall f_11240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7814)
static void C_ccall f_7814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7810)
static void C_ccall f_7810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7061)
static void C_fcall f_7061(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5598)
static void C_fcall f_5598(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10961)
static void C_ccall f_10961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10965)
static void C_ccall f_10965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8592)
static void C_ccall f_8592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10702)
static void C_ccall f_10702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10713)
static void C_ccall f_10713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10715)
static void C_fcall f_10715(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8588)
static void C_ccall f_8588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10729)
static void C_ccall f_10729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9419)
static void C_ccall f_9419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11284)
static void C_ccall f_11284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_fcall f_5586(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_9421)
static void C_fcall f_9421(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6662)
static void C_ccall f_6662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11265)
static void C_ccall f_11265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4895)
static void C_fcall f_4895(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9455)
static void C_ccall f_9455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9459)
static void C_ccall f_9459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8236)
static void C_ccall f_8236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6677)
static void C_ccall f_6677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9463)
static void C_ccall f_9463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11294)
static void C_ccall f_11294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9467)
static void C_ccall f_9467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11292)
static void C_ccall f_11292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8232)
static void C_ccall f_8232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4870)
static void C_fcall f_4870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9431)
static void C_ccall f_9431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_fcall f_4248(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_fcall f_3646(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8219)
static void C_ccall f_8219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static void C_fcall f_6691(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6698)
static void C_ccall f_6698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8249)
static void C_ccall f_8249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4851)
static void C_fcall f_4851(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_8555)
static void C_fcall trf_8555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8555(t0,t1);}

C_noret_decl(trf_5771)
static void C_fcall trf_5771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5771(t0,t1);}

C_noret_decl(trf_8298)
static void C_fcall trf_8298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8298(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8298(t0,t1,t2);}

C_noret_decl(trf_5758)
static void C_fcall trf_5758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5758(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5758(t0,t1,t2,t3);}

C_noret_decl(trf_4288)
static void C_fcall trf_4288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4288(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4288(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3656)
static void C_fcall trf_3656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3656(t0,t1);}

C_noret_decl(trf_5146)
static void C_fcall trf_5146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5146(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5146(t0,t1,t2);}

C_noret_decl(trf_6178)
static void C_fcall trf_6178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6178(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6178(t0,t1,t2);}

C_noret_decl(trf_4666)
static void C_fcall trf_4666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4666(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4666(t0,t1,t2);}

C_noret_decl(trf_5227)
static void C_fcall trf_5227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5227(t0,t1);}

C_noret_decl(trf_5240)
static void C_fcall trf_5240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5240(t0,t1);}

C_noret_decl(trf_6184)
static void C_fcall trf_6184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6184(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6184(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6707)
static void C_fcall trf_6707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6707(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6707(t0,t1,t2);}

C_noret_decl(trf_10154)
static void C_fcall trf_10154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10154(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10154(t0,t1,t2,t3);}

C_noret_decl(trf_9338)
static void C_fcall trf_9338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9338(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9338(t0,t1,t2);}

C_noret_decl(trf_3809)
static void C_fcall trf_3809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3809(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3809(t0,t1,t2);}

C_noret_decl(trf_5277)
static void C_fcall trf_5277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5277(t0,t1);}

C_noret_decl(trf_5274)
static void C_fcall trf_5274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5274(t0,t1);}

C_noret_decl(trf_4412)
static void C_fcall trf_4412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4412(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4412(t0,t1);}

C_noret_decl(trf_10164)
static void C_fcall trf_10164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10164(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10164(t0,t1,t2,t3);}

C_noret_decl(trf_7572)
static void C_fcall trf_7572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7572(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7572(t0,t1,t2,t3);}

C_noret_decl(trf_6000)
static void C_fcall trf_6000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6000(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6000(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9380)
static void C_fcall trf_9380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9380(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9380(t0,t1,t2);}

C_noret_decl(trf_5617)
static void C_fcall trf_5617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5617(t0,t1);}

C_noret_decl(trf_8013)
static void C_fcall trf_8013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8013(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8013(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5807)
static void C_fcall trf_5807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5807(t0,t1,t2);}

C_noret_decl(trf_4486)
static void C_fcall trf_4486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4486(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4486(t0,t1,t2,t3,t4);}

C_noret_decl(trf_11627)
static void C_fcall trf_11627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11627(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11627(t0,t1,t2);}

C_noret_decl(trf_10327)
static void C_fcall trf_10327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10327(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10327(t0,t1,t2);}

C_noret_decl(trf_8026)
static void C_fcall trf_8026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8026(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8026(t0,t1);}

C_noret_decl(trf_10361)
static void C_fcall trf_10361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10361(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10361(t0,t1,t2);}

C_noret_decl(trf_10796)
static void C_fcall trf_10796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10796(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10796(t0,t1);}

C_noret_decl(trf_10335)
static void C_fcall trf_10335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10335(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10335(t0,t1,t2);}

C_noret_decl(trf_6955)
static void C_fcall trf_6955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6955(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6955(t0,t1,t2);}

C_noret_decl(trf_10497)
static void C_fcall trf_10497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10497(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10497(t0,t1);}

C_noret_decl(trf_11475)
static void C_fcall trf_11475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11475(t0,t1);}

C_noret_decl(trf_8918)
static void C_fcall trf_8918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8918(t0,t1);}

C_noret_decl(trf_4039)
static void C_fcall trf_4039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4039(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4039(t0,t1,t2);}

C_noret_decl(trf_4057)
static void C_fcall trf_4057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4057(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4057(t0,t1,t2);}

C_noret_decl(trf_4467)
static void C_fcall trf_4467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4467(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4467(t0,t1,t2);}

C_noret_decl(trf_5900)
static void C_fcall trf_5900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5900(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5900(t0,t1,t2,t3);}

C_noret_decl(trf_6478)
static void C_fcall trf_6478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6478(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6478(t0,t1,t2,t3);}

C_noret_decl(trf_5913)
static void C_fcall trf_5913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5913(t0,t1);}

C_noret_decl(trf_6475)
static void C_fcall trf_6475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6475(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6475(t0,t1,t2,t3);}

C_noret_decl(trf_4023)
static void C_fcall trf_4023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4023(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4023(t0,t1,t2);}

C_noret_decl(trf_10919)
static void C_fcall trf_10919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10919(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10919(t0,t1,t2,t3);}

C_noret_decl(trf_6638)
static void C_fcall trf_6638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6638(t0,t1,t2);}

C_noret_decl(trf_6916)
static void C_fcall trf_6916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6916(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6916(t0,t1,t2);}

C_noret_decl(trf_4326)
static void C_fcall trf_4326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4326(t0,t1);}

C_noret_decl(trf_9295)
static void C_fcall trf_9295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9295(t0,t1,t2);}

C_noret_decl(trf_6904)
static void C_fcall trf_6904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6904(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6904(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4926)
static void C_fcall trf_4926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4926(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4926(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4073)
static void C_fcall trf_4073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4073(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4073(t0,t1);}

C_noret_decl(trf_7775)
static void C_fcall trf_7775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7775(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7775(t0,t1,t2);}

C_noret_decl(trf_7446)
static void C_fcall trf_7446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7446(t0,t1);}

C_noret_decl(trf_3884)
static void C_fcall trf_3884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3884(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3884(t0,t1,t2,t3);}

C_noret_decl(trf_3897)
static void C_fcall trf_3897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3897(t0,t1);}

C_noret_decl(trf_6804)
static void C_fcall trf_6804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6804(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6804(t0,t1,t2);}

C_noret_decl(trf_5081)
static void C_fcall trf_5081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5081(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5081(t0,t1,t2);}

C_noret_decl(trf_4599)
static void C_fcall trf_4599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4599(t0,t1,t2);}

C_noret_decl(trf_4709)
static void C_fcall trf_4709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4709(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4709(t0,t1,t2);}

C_noret_decl(trf_4705)
static void C_fcall trf_4705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4705(t0,t1);}

C_noret_decl(trf_9962)
static void C_fcall trf_9962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9962(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9962(t0,t1,t2);}

C_noret_decl(trf_10850)
static void C_fcall trf_10850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10850(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10850(t0,t1,t2);}

C_noret_decl(trf_5864)
static void C_fcall trf_5864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5864(t0,t1);}

C_noret_decl(trf_8348)
static void C_fcall trf_8348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8348(t0,t1);}

C_noret_decl(trf_7428)
static void C_fcall trf_7428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7428(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7428(t0,t1,t2);}

C_noret_decl(trf_9986)
static void C_fcall trf_9986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9986(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9986(t0,t1,t2);}

C_noret_decl(trf_5851)
static void C_fcall trf_5851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5851(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5851(t0,t1,t2,t3);}

C_noret_decl(trf_3933)
static void C_fcall trf_3933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3933(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3933(t0,t1,t2,t3);}

C_noret_decl(trf_5949)
static void C_fcall trf_5949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5949(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5949(t0,t1,t2);}

C_noret_decl(trf_4343)
static void C_fcall trf_4343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4343(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4343(t0,t1,t2);}

C_noret_decl(trf_4530)
static void C_fcall trf_4530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4530(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4530(t0,t1,t2);}

C_noret_decl(trf_4944)
static void C_fcall trf_4944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4944(t0,t1);}

C_noret_decl(trf_9826)
static void C_fcall trf_9826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9826(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9826(t0,t1,t2);}

C_noret_decl(trf_5990)
static void C_fcall trf_5990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5990(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5990(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4554)
static void C_fcall trf_4554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4554(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4554(t0,t1);}

C_noret_decl(trf_4956)
static void C_fcall trf_4956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4956(t0,t1);}

C_noret_decl(trf_10588)
static void C_fcall trf_10588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10588(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10588(t0,t1,t2);}

C_noret_decl(trf_4360)
static void C_fcall trf_4360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4360(t0,t1);}

C_noret_decl(trf_10537)
static void C_fcall trf_10537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10537(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10537(t0,t1,t2);}

C_noret_decl(trf_4796)
static void C_fcall trf_4796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4796(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4796(t0,t1,t2);}

C_noret_decl(trf_3979)
static void C_fcall trf_3979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3979(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3979(t0,t1,t2);}

C_noret_decl(trf_9816)
static void C_fcall trf_9816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9816(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9816(t0,t1,t2);}

C_noret_decl(trf_5316)
static void C_fcall trf_5316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5316(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5316(t0,t1);}

C_noret_decl(trf_5403)
static void C_fcall trf_5403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5403(t0,t1);}

C_noret_decl(trf_8007)
static void C_fcall trf_8007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8007(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8007(t0,t1,t2,t3);}

C_noret_decl(trf_6204)
static void C_fcall trf_6204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6204(t0,t1);}

C_noret_decl(trf_6560)
static void C_fcall trf_6560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6560(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6560(t0,t1,t2,t3);}

C_noret_decl(trf_6227)
static void C_fcall trf_6227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6227(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6227(t0,t1,t2);}

C_noret_decl(trf_6024)
static void C_fcall trf_6024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6024(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6024(t0,t1,t2);}

C_noret_decl(trf_10566)
static void C_fcall trf_10566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10566(t0,t1);}

C_noret_decl(trf_7948)
static void C_fcall trf_7948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7948(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7948(t0,t1,t2);}

C_noret_decl(trf_6072)
static void C_fcall trf_6072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6072(t0,t1);}

C_noret_decl(trf_7632)
static void C_fcall trf_7632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7632(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7632(t0,t1);}

C_noret_decl(trf_9688)
static void C_fcall trf_9688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9688(t0,t1);}

C_noret_decl(trf_3710)
static void C_fcall trf_3710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3710(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3710(t0,t1,t2);}

C_noret_decl(trf_10641)
static void C_fcall trf_10641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10641(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10641(t0,t1,t2);}

C_noret_decl(trf_7624)
static void C_fcall trf_7624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7624(t0,t1);}

C_noret_decl(trf_8965)
static void C_fcall trf_8965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8965(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8965(t0,t1);}

C_noret_decl(trf_8944)
static void C_fcall trf_8944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8944(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8944(t0,t1,t2,t3);}

C_noret_decl(trf_7032)
static void C_fcall trf_7032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7032(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7032(t0,t1);}

C_noret_decl(trf_7037)
static void C_fcall trf_7037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7037(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7037(t0,t1,t2,t3);}

C_noret_decl(trf_7056)
static void C_fcall trf_7056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7056(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7056(t0,t1);}

C_noret_decl(trf_7061)
static void C_fcall trf_7061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7061(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7061(t0,t1,t2,t3);}

C_noret_decl(trf_5598)
static void C_fcall trf_5598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5598(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5598(t0,t1,t2,t3);}

C_noret_decl(trf_10715)
static void C_fcall trf_10715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10715(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10715(t0,t1,t2,t3);}

C_noret_decl(trf_5586)
static void C_fcall trf_5586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5586(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5586(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_9421)
static void C_fcall trf_9421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9421(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9421(t0,t1,t2);}

C_noret_decl(trf_4895)
static void C_fcall trf_4895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4895(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4895(t0,t1,t2);}

C_noret_decl(trf_4870)
static void C_fcall trf_4870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4870(t0,t1);}

C_noret_decl(trf_4248)
static void C_fcall trf_4248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4248(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4248(t0,t1,t2);}

C_noret_decl(trf_3646)
static void C_fcall trf_3646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3646(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3646(t0,t1,t2);}

C_noret_decl(trf_6691)
static void C_fcall trf_6691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6691(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6691(t0,t1,t2);}

C_noret_decl(trf_4851)
static void C_fcall trf_4851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4851(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4851(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

/* k11415 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1063: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[323],C_SCHEME_END_OF_LIST,t1);}

/* a11418 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11419,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11423,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1068: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[323],t2,lf[326]);}

/* f_8243 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_8243(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8243,3,t0,t1,t2);}
/* synrules.scm:104: c */
t3=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in ... */
static void C_ccall f_8241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[119],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8241,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8243,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word)li107),tmp=(C_word)a,a+=5,tmp));
t4=C_mutate2(((C_word *)((C_word*)t0)[5])+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8249,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word)li109),tmp=(C_word)a,a+=13,tmp));
t5=C_mutate2(((C_word *)((C_word*)t0)[14])+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8341,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[19],a[6]=((C_word*)t0)[20],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[21],a[9]=((C_word)li111),tmp=(C_word)a,a+=10,tmp));
t6=C_mutate2(((C_word *)((C_word*)t0)[21])+1,(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8407,a[2]=((C_word*)t0)[22],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[23],a[6]=((C_word*)t0)[24],a[7]=((C_word*)t0)[25],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[26],a[13]=((C_word*)t0)[27],a[14]=((C_word*)t0)[28],a[15]=((C_word*)t0)[29],a[16]=((C_word*)t0)[30],a[17]=((C_word*)t0)[31],a[18]=((C_word)li112),tmp=(C_word)a,a+=19,tmp));
t7=C_mutate2(((C_word *)((C_word*)t0)[23])+1,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8588,a[2]=((C_word*)t0)[32],a[3]=((C_word*)t0)[33],a[4]=((C_word*)t0)[34],a[5]=((C_word*)t0)[35],a[6]=((C_word*)t0)[36],a[7]=((C_word*)t0)[37],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[38],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[39],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[26],a[17]=((C_word)li113),tmp=(C_word)a,a+=18,tmp));
t8=C_mutate2(((C_word *)((C_word*)t0)[20])+1,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8715,a[2]=((C_word*)t0)[22],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[24],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[40],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[26],a[9]=((C_word*)t0)[28],a[10]=((C_word*)t0)[31],a[11]=((C_word)li115),tmp=(C_word)a,a+=12,tmp));
t9=C_mutate2(((C_word *)((C_word*)t0)[18])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8855,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[18],a[4]=((C_word*)t0)[41],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[42],a[7]=((C_word*)t0)[43],a[8]=((C_word*)t0)[44],a[9]=((C_word*)t0)[45],a[10]=((C_word*)t0)[46],a[11]=((C_word*)t0)[47],a[12]=((C_word*)t0)[48],a[13]=((C_word)li117),tmp=(C_word)a,a+=14,tmp));
t10=C_mutate2(((C_word *)((C_word*)t0)[19])+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9047,a[2]=((C_word*)t0)[22],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[31],a[5]=((C_word)li118),tmp=(C_word)a,a+=6,tmp));
t11=C_mutate2(((C_word *)((C_word*)t0)[43])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9124,a[2]=((C_word*)t0)[43],a[3]=((C_word*)t0)[48],a[4]=((C_word)li119),tmp=(C_word)a,a+=5,tmp));
t12=C_mutate2(((C_word *)((C_word*)t0)[31])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9213,a[2]=((C_word*)t0)[48],a[3]=((C_word)li120),tmp=(C_word)a,a+=4,tmp));
t13=C_mutate2(((C_word *)((C_word*)t0)[48])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9241,a[2]=((C_word*)t0)[3],a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate2(((C_word *)((C_word*)t0)[44])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9265,a[2]=((C_word*)t0)[44],a[3]=((C_word*)t0)[48],a[4]=((C_word)li122),tmp=(C_word)a,a+=5,tmp));
t15=C_mutate2(((C_word *)((C_word*)t0)[41])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9285,a[2]=((C_word*)t0)[3],a[3]=((C_word)li124),tmp=(C_word)a,a+=4,tmp));
/* synrules.scm:314: make-transformer */
t16=((C_word*)((C_word*)t0)[5])[1];
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,((C_word*)t0)[49],((C_word*)t0)[50]);}

/* k8553 in k8439 */
static void C_fcall f_8555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8555,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list(&a,2,lf[207],((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,1,t3));}
else{
t2=C_a_i_list(&a,2,lf[207],((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,1,t3));}}

/* ##sys#extended-lambda-list? in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4845(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4845,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4851,a[2]=t4,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4851(t6,t1,t2);}

/* k11402 in k11399 in a11396 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 in ... */
static void C_ccall f_11404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11404,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[320],t3));}

/* k11399 in a11396 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1078: check-for-multiple-bindings */
f_8007(t2,t3,((C_word*)t0)[2],lf[321]);}

/* k8540 in k8439 */
static void C_ccall f_8542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:146: process-match */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc5)C_fast_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],t1,C_SCHEME_FALSE);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_expand_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("expand_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4355)){
C_save(t1);
C_rereclaim2(4355*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,356);
lf[0]=C_h_intern(&lf[0],12,"\003sysfeatures");
lf[1]=C_h_intern(&lf[1],23,"\003syscurrent-environment");
lf[2]=C_h_intern(&lf[2],28,"\003syscurrent-meta-environment");
lf[3]=C_h_intern(&lf[3],27,"\003sysactive-eval-environment");
lf[5]=C_h_intern(&lf[5],16,"\004coremacro-alias");
lf[7]=C_h_intern(&lf[7],14,"\004corereal-name");
lf[8]=C_h_intern(&lf[8],6,"gensym");
lf[9]=C_h_intern(&lf[9],21,"\003sysqualified-symbol\077");
lf[10]=C_h_intern(&lf[10],16,"\003sysstrip-syntax");
lf[11]=C_h_intern(&lf[11],11,"make-vector");
lf[12]=C_h_intern(&lf[12],12,"strip-syntax");
lf[13]=C_h_intern(&lf[13],13,"\003sysextend-se");
lf[14]=C_h_intern(&lf[14],8,"for-each");
lf[15]=C_h_intern(&lf[15],6,"append");
lf[16]=C_h_intern(&lf[16],3,"map");
lf[17]=C_h_intern(&lf[17],13,"\003sysglobalize");
lf[18]=C_h_intern(&lf[18],21,"\003sysalias-global-hook");
lf[19]=C_h_intern(&lf[19],21,"\003sysmacro-environment");
lf[20]=C_h_intern(&lf[20],29,"\003syschicken-macro-environment");
lf[21]=C_h_intern(&lf[21],33,"\003syschicken-ffi-macro-environment");
lf[22]=C_h_intern(&lf[22],22,"\003sysensure-transformer");
lf[23]=C_h_intern(&lf[23],18,"\003syser-transformer");
lf[24]=C_h_intern(&lf[24],11,"transformer");
lf[25]=C_h_intern(&lf[25],9,"\003syserror");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000$expected syntax-transformer, but got");
lf[27]=C_h_intern(&lf[27],28,"\003sysextend-macro-environment");
lf[28]=C_h_intern(&lf[28],14,"\003syscopy-macro");
lf[29]=C_h_intern(&lf[29],10,"\003sysmacro\077");
lf[30]=C_h_intern(&lf[30],20,"\003sysunregister-macro");
lf[31]=C_h_intern(&lf[31],19,"\003sysundefine-macro!");
lf[32]=C_h_intern(&lf[32],12,"\003sysexpand-0");
lf[33]=C_h_intern(&lf[33],9,"condition");
lf[34]=C_h_intern(&lf[34],9,"\003sysabort");
lf[35]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[36]=C_h_intern(&lf[36],13,"string-append");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[39]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[40]=C_h_intern(&lf[40],3,"exn");
lf[41]=C_h_intern(&lf[41],21,"\003syssyntax-error-hook");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\030syntax transformer for `");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000@\047 returns original form, which would result in endless expansion");
lf[44]=C_h_intern(&lf[44],14,"symbol->string");
lf[45]=C_h_intern(&lf[45],25,"\003syssyntax-rules-mismatch");
lf[46]=C_h_intern(&lf[46],16,"\003sysdynamic-wind");
lf[47]=C_h_intern(&lf[47],22,"with-exception-handler");
lf[48]=C_h_intern(&lf[48],30,"call-with-current-continuation");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[50]=C_h_intern(&lf[50],8,"\004corelet");
lf[51]=C_h_intern(&lf[51],16,"\004coreloop-lambda");
lf[52]=C_h_intern(&lf[52],12,"\004coreletrec\052");
lf[53]=C_h_intern(&lf[53],8,"\004coreapp");
lf[54]=C_h_intern(&lf[54],16,"\003syscheck-syntax");
lf[55]=C_h_intern(&lf[55],3,"let");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[57]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[58]=C_h_intern(&lf[58],24,"\003syscompiler-syntax-hook");
lf[59]=C_h_intern(&lf[59],24,"\010compilercompiler-syntax");
lf[60]=C_h_intern(&lf[60],25,"\003sysenable-runtime-macros");
lf[61]=C_h_intern(&lf[61],10,"\003sysexpand");
lf[62]=C_h_intern(&lf[62],6,"expand");
lf[63]=C_h_intern(&lf[63],25,"\003sysextended-lambda-list\077");
lf[64]=C_h_intern(&lf[64],6,"#!rest");
lf[65]=C_h_intern(&lf[65],10,"#!optional");
lf[66]=C_h_intern(&lf[66],5,"#!key");
lf[67]=C_h_intern(&lf[67],31,"\003sysexpand-extended-lambda-list");
lf[68]=C_h_intern(&lf[68],5,"cadar");
lf[69]=C_h_intern(&lf[69],7,"reverse");
lf[70]=C_h_intern(&lf[70],10,"\003sysappend");
lf[71]=C_h_intern(&lf[71],10,"\004corequote");
lf[72]=C_h_intern(&lf[72],11,"\004corelambda");
lf[73]=C_h_intern(&lf[73],15,"\003sysget-keyword");
lf[74]=C_h_intern(&lf[74],15,"string->keyword");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[77]=C_h_intern(&lf[77],3,"tmp");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[86]=C_h_intern(&lf[86],14,"let-optionals\052");
lf[87]=C_h_intern(&lf[87],8,"optional");
lf[88]=C_h_intern(&lf[88],4,"let\052");
lf[89]=C_h_intern(&lf[89],16,"\003sysdefjam-error");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000,redefinition of currently used defining form");
lf[91]=C_h_intern(&lf[91],21,"\003sysdefine-definition");
lf[92]=C_h_intern(&lf[92],28,"\003sysdefine-syntax-definition");
lf[93]=C_h_intern(&lf[93],28,"\003sysdefine-values-definition");
lf[94]=C_h_intern(&lf[94],21,"\003syscanonicalize-body");
lf[95]=C_h_intern(&lf[95],6,"define");
lf[96]=C_h_intern(&lf[96],13,"define-syntax");
lf[97]=C_h_intern(&lf[97],13,"define-values");
lf[98]=C_h_intern(&lf[98],10,"\004corebegin");
lf[99]=C_h_intern(&lf[99],20,"\003syscall-with-values");
lf[100]=C_h_intern(&lf[100],9,"\004coreset!");
lf[101]=C_h_intern(&lf[101],14,"\004coreundefined");
lf[102]=C_h_intern(&lf[102],18,"\004coreletrec-syntax");
lf[103]=C_h_intern(&lf[103],5,"caadr");
lf[104]=C_h_intern(&lf[104],25,"\003sysexpand-curried-define");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[106]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[109]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[110]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[111]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[113]=C_h_intern(&lf[113],24,"\003sysline-number-database");
lf[114]=C_h_intern(&lf[114],24,"\003syssyntax-error-culprit");
lf[115]=C_h_intern(&lf[115],18,"\003syssyntax-context");
lf[116]=C_h_intern(&lf[116],15,"\003syssignal-hook");
lf[117]=C_h_intern(&lf[117],13,"\000syntax-error");
lf[118]=C_h_intern(&lf[118],24,"\003syssyntax-error/context");
lf[119]=C_h_intern(&lf[119],9,"\003sysprint");
lf[120]=C_h_intern(&lf[120],17,"get-output-string");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\006 ...)\047");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\025\012inside expression `(");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\027  Suggesting: `(import ");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\002)\047");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\025  Suggesting one of:\012");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\017\012      (import ");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\002)\047");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000# ...)\047 without importing it first.\012");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000-\012\012  Perhaps you intended to use the syntax `(");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[133]=C_h_intern(&lf[133],6,"syntax");
lf[134]=C_h_intern(&lf[134],7,"\003sysget");
lf[135]=C_h_intern(&lf[135],7,"\004coredb");
lf[136]=C_h_intern(&lf[136],18,"open-output-string");
lf[137]=C_h_intern(&lf[137],12,"syntax-error");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[139]=C_h_intern(&lf[139],15,"get-line-number");
lf[140]=C_h_intern(&lf[140],18,"\003syshash-table-ref");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\006) in `");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\004\047 - ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\004in `");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004\047 - ");
lf[146]=C_h_intern(&lf[146],8,"keyword\077");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[151]=C_h_intern(&lf[151],1,"_");
lf[152]=C_h_intern(&lf[152],4,"pair");
lf[153]=C_h_intern(&lf[153],5,"pair\077");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[155]=C_h_intern(&lf[155],8,"variable");
lf[156]=C_h_intern(&lf[156],7,"symbol\077");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[158]=C_h_intern(&lf[158],6,"symbol");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[160]=C_h_intern(&lf[160],4,"list");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[162]=C_h_intern(&lf[162],6,"number");
lf[163]=C_h_intern(&lf[163],7,"number\077");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[165]=C_h_intern(&lf[165],6,"string");
lf[166]=C_h_intern(&lf[166],7,"string\077");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[168]=C_h_intern(&lf[168],11,"lambda-list");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[173]=C_h_intern(&lf[173],22,"make-er/ir-transformer");
lf[174]=C_h_intern(&lf[174],12,"list->vector");
lf[175]=C_h_intern(&lf[175],12,"vector->list");
lf[176]=C_h_intern(&lf[176],12,"\004corealiased");
lf[177]=C_h_intern(&lf[177],14,"\004coreprimitive");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\033(expand.scm:780) not a list");
lf[179]=C_h_intern(&lf[179],18,"\003sysir-transformer");
lf[180]=C_h_intern(&lf[180],20,"er-macro-transformer");
lf[181]=C_h_intern(&lf[181],20,"ir-macro-transformer");
lf[182]=C_h_intern(&lf[182],18,"\003sysmark-primitive");
lf[183]=C_h_intern(&lf[183],29,"\003sysinitial-macro-environment");
lf[185]=C_h_intern(&lf[185],8,"\003syswarn");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000!variable bound multiple times in ");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\012 construct");
lf[188]=C_h_intern(&lf[188],24,"\003sysprocess-syntax-rules");
lf[189]=C_h_intern(&lf[189],7,"\003syscar");
lf[190]=C_h_intern(&lf[190],7,"\003syscdr");
lf[191]=C_h_intern(&lf[191],10,"\003syslength");
lf[192]=C_h_intern(&lf[192],11,"\003sysvector\077");
lf[193]=C_h_intern(&lf[193],16,"\003sysvector->list");
lf[194]=C_h_intern(&lf[194],16,"\003syslist->vector");
lf[195]=C_h_intern(&lf[195],6,"\003sys>=");
lf[196]=C_h_intern(&lf[196],5,"\003sys=");
lf[197]=C_h_intern(&lf[197],5,"\003sys+");
lf[198]=C_h_intern(&lf[198],8,"\003syscons");
lf[199]=C_h_intern(&lf[199],7,"\003syseq\077");
lf[200]=C_h_intern(&lf[200],10,"\003sysequal\077");
lf[201]=C_h_intern(&lf[201],9,"\003syslist\077");
lf[202]=C_h_intern(&lf[202],7,"\003sysmap");
lf[203]=C_h_intern(&lf[203],9,"\003sysmap-n");
lf[204]=C_h_intern(&lf[204],9,"\003syspair\077");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\026ill-formed syntax rule");
lf[206]=C_h_intern(&lf[206],11,"\004coresyntax");
lf[207]=C_h_intern(&lf[207],5,"quote");
lf[208]=C_h_intern(&lf[208],14,"\003sysdrop-right");
lf[209]=C_h_intern(&lf[209],14,"\003systake-right");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000,template dimension error (too few ellipses\077)");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\021too many ellipses");
lf[212]=C_h_intern(&lf[212],9,"\003sysapply");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000%Only one segment per level is allowed");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\047Cannot combine dotted tail and ellipsis");
lf[215]=C_h_intern(&lf[215],4,"temp");
lf[216]=C_h_intern(&lf[216],4,"tail");
lf[217]=C_h_intern(&lf[217],6,"rename");
lf[218]=C_h_intern(&lf[218],2,"or");
lf[219]=C_h_intern(&lf[219],4,"loop");
lf[220]=C_h_intern(&lf[220],6,"lambda");
lf[221]=C_h_intern(&lf[221],3,"len");
lf[222]=C_h_intern(&lf[222],1,"l");
lf[223]=C_h_intern(&lf[223],5,"input");
lf[224]=C_h_intern(&lf[224],4,"else");
lf[225]=C_h_intern(&lf[225],4,"cond");
lf[226]=C_h_intern(&lf[226],7,"compare");
lf[227]=C_h_intern(&lf[227],3,"and");
lf[228]=C_h_intern(&lf[228],16,"\003sysmacro-subset");
lf[229]=C_h_intern(&lf[229],27,"\003sysfixup-macro-environment");
lf[230]=C_h_intern(&lf[230],29,"\003sysdefault-macro-environment");
lf[231]=C_h_intern(&lf[231],26,"\003sysmeta-macro-environment");
lf[232]=C_h_intern(&lf[232],14,"make-parameter");
lf[233]=C_h_intern(&lf[233],12,"syntax-rules");
lf[234]=C_h_intern(&lf[234],3,"...");
lf[235]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[236]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[237]=C_h_intern(&lf[237],6,"export");
lf[238]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[239]=C_h_intern(&lf[239],22,"\003sysadd-to-export-list");
lf[240]=C_h_intern(&lf[240],18,"\003syscurrent-module");
lf[241]=C_h_intern(&lf[241],20,"\003sysvalidate-exports");
lf[242]=C_h_intern(&lf[242],16,"begin-for-syntax");
lf[243]=C_h_intern(&lf[243],24,"\004coreelaborationtimeonly");
lf[244]=C_h_intern(&lf[244],28,"\003sysregister-meta-expression");
lf[245]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[246]=C_h_intern(&lf[246],6,"module");
lf[247]=C_h_intern(&lf[247],1,"\052");
lf[248]=C_h_intern(&lf[248],1,"=");
lf[249]=C_h_intern(&lf[249],14,"string->symbol");
lf[250]=C_h_intern(&lf[250],17,"\003sysstring-append");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[252]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[253]=C_h_intern(&lf[253],25,"\003sysregister-module-alias");
lf[254]=C_h_intern(&lf[254],23,"\003sysinstantiate-functor");
lf[255]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\016"
);
lf[256]=C_h_intern(&lf[256],12,"\004coreinclude");
lf[257]=C_h_intern(&lf[257],11,"\004coremodule");
lf[258]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[259]=C_h_intern(&lf[259],28,"require-extension-for-syntax");
lf[260]=C_h_intern(&lf[260],17,"require-extension");
lf[261]=C_h_intern(&lf[261],22,"\004corerequire-extension");
lf[262]=C_h_intern(&lf[262],15,"require-library");
lf[263]=C_h_intern(&lf[263],11,"cond-expand");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[265]=C_h_intern(&lf[265],12,"\003sysfeature\077");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[267]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[268]=C_h_intern(&lf[268],3,"not");
lf[269]=C_h_intern(&lf[269],11,"delay-force");
lf[270]=C_h_intern(&lf[270],16,"\003sysmake-promise");
lf[271]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[272]=C_h_intern(&lf[272],5,"delay");
lf[273]=C_h_intern(&lf[273],8,"\003syslist");
lf[274]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[275]=C_h_intern(&lf[275],10,"quasiquote");
lf[276]=C_h_intern(&lf[276],7,"unquote");
lf[277]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[278]=C_h_intern(&lf[278],16,"unquote-splicing");
lf[279]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[280]=C_h_intern(&lf[280],1,"a");
lf[281]=C_h_intern(&lf[281],1,"b");
lf[282]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\004corequote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[283]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[284]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[285]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[286]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\004corequote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[287]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[288]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[289]=C_h_intern(&lf[289],2,"do");
lf[290]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[291]=C_h_intern(&lf[291],7,"\004coreif");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[293]=C_h_intern(&lf[293],6,"doloop");
lf[294]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001"
"\000\000\000\001");
lf[295]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[296]=C_h_intern(&lf[296],4,"case");
lf[297]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corebegin\376\377\016");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000(clause following `else\047 clause in `case\047");
lf[299]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[300]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[301]=C_h_intern(&lf[301],4,"eqv\077");
lf[302]=C_h_intern(&lf[302],2,"=>");
lf[303]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[304]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corebegin\376\377\016");
lf[305]=C_h_intern(&lf[305],7,"sprintf");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\022\047 clause in `cond\047");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\022clause following `");
lf[308]=C_h_intern(&lf[308],2,"if");
lf[309]=C_h_intern(&lf[309],18,"\003syssrfi-4-vector\077");
lf[310]=C_h_intern(&lf[310],5,"blob\077");
lf[311]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[312]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[313]=C_h_intern(&lf[313],4,"set!");
lf[314]=C_h_intern(&lf[314],10,"\003syssetter");
lf[315]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[316]=C_h_intern(&lf[316],13,"letrec-syntax");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\015letrec-syntax");
lf[318]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[319]=C_h_intern(&lf[319],10,"let-syntax");
lf[320]=C_h_intern(&lf[320],15,"\004corelet-syntax");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\012let-syntax");
lf[322]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[323]=C_h_intern(&lf[323],6,"letrec");
lf[324]=C_h_intern(&lf[324],11,"\004coreletrec");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\006letrec");
lf[326]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[327]=C_h_intern(&lf[327],7,"letrec\052");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\007letrec\052");
lf[329]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\003let");
lf[331]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\003let");
lf[333]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[334]=C_h_intern(&lf[334],18,"\004coredefine-syntax");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000@redefinition of `define-syntax\047 not allowed in syntax-definition");
lf[336]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[337]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[338]=C_h_intern(&lf[338],19,"\003sysregister-export");
lf[339]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[340]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[341]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[342]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[343]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[344]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[345]=C_h_intern(&lf[345],5,"begin");
lf[346]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[347]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[351]=C_h_intern(&lf[351],8,"reexport");
lf[352]=C_h_intern(&lf[352],17,"\003sysexpand-import");
lf[353]=C_h_intern(&lf[353],17,"import-for-syntax");
lf[354]=C_h_intern(&lf[354],6,"import");
lf[355]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\020\000hygienic-macros\376\003\000\000\002\376\001\000\000\015\000syntax-rules\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\007\000srf"
"i-2\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-46\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001"
"\000\000\010\000srfi-61\376\377\016");
C_register_lf2(lf,356,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3615,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:55: append */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[355],*((C_word*)lf[0]+1));}

/* k4199 in macro? in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=f_3629(((C_word*)t0)[2],t1);
t3=C_i_pairp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:186: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5769 in map-loop1069 in k5727 in map-loop1016 in k5844 in k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_5758(t5,((C_word*)t0)[7],t3,t4);}

/* k8532 in k8439 */
static void C_ccall f_8534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8534,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],t3);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,1,t4));}

/* k9734 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_9736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_caddr(((C_word*)t0)[2]);
/* expand.scm:1430: c */
t3=((C_word*)t0)[3];
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t1,t2);}

/* k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in ... */
static void C_ccall f_8207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8207,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[201]);
t4=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8212,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=((C_word*)t0)[22],a[21]=((C_word*)t0)[23],a[22]=((C_word*)t0)[24],a[23]=((C_word*)t0)[2],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[3],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:90: r */
t5=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t4,lf[219]);}

/* k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6689,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6691,a[2]=t2,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6698,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6707,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word)li76),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_6707(t8,t4,*((C_word*)lf[115]+1));}

/* k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in ... */
static void C_ccall f_8203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8203,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[2],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:88: r */
t4=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[88]);}

/* k9720 in k9577 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1470: ##sys#validate-exports */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[241]+1)))(4,*((C_word*)lf[241]+1),((C_word*)t0)[2],t1,lf[246]);}

/* a11514 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11515,5,t0,t1,t2,t3,t4);}
t5=C_i_cadr(t2);
t6=t5;
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
if(C_truep(C_i_pairp(t6))){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11571,a[2]=t6,a[3]=t9,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1018: ##sys#check-syntax */
t11=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t10,lf[96],t6,lf[337]);}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11530,a[2]=t6,a[3]=t9,a[4]=t1,a[5]=t2,a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1010: ##sys#check-syntax */
t11=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t10,lf[96],t6,lf[158]);}}

/* k11511 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1002: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[96],C_SCHEME_END_OF_LIST,t1);}

/* map-loop2486 */
static void C_fcall f_8298(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8298,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8327,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* synrules.scm:110: g2492 */
t5=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6899,2,t0,t1);}
t2=t1;
t3=C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6904,a[2]=t8,a[3]=((C_word)li81),tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li82),tmp=(C_word)a,a+=5,tmp));
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6943,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7005,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7032,a[2]=t8,a[3]=t6,a[4]=t12,a[5]=t10,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
t18=C_mutate2((C_word*)lf[114]+1 /* (set! ##sys#syntax-error-culprit ...) */,((C_word*)t0)[7]);
t19=t17;
f_7032(t19,t18);}
else{
t18=t17;
f_7032(t18,C_SCHEME_UNDEFINED);}}

/* k5754 in k5727 in map-loop1016 in k5844 in k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5756,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[72],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[99],((C_word*)t0)[4],t3));}

/* k8275 */
static void C_ccall f_8277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8277,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6],t3);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,2,lf[23],t4));}

/* k4269 in loop in k4244 in unregister-macro in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4271,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* ##sys#undefine-macro! in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4279,3,t0,t1,t2);}
/* expand.scm:198: ##sys#unregister-macro */
t3=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* ##sys#check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_6889r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6889r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6889r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t6=C_i_nullp(t5);
t7=(C_truep(t6)?C_SCHEME_FALSE:C_i_car(t5));
t8=t7;
t9=C_i_nullp(t5);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:C_i_cdr(t5));
t11=t10;
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6899,a[2]=t11,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nullp(t11))){
/* expand.scm:694: ##sys#current-environment */
t13=*((C_word*)lf[1]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t13=t12;
f_6899(2,t13,C_i_car(t11));}}

/* map-loop1069 in k5727 in map-loop1016 in k5844 in k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5758(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5758,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[100],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5771,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_5771(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_5771(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in ... */
static void C_ccall f_8228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8228,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[2],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:98: r */
t4=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[216]);}

/* ##sys#expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4285,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4288,a[2]=t3,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4486,a[2]=t6,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4530,a[2]=t3,a[3]=t8,a[4]=t12,a[5]=t6,a[6]=t4,a[7]=((C_word)li38),tmp=(C_word)a,a+=8,tmp));
t14=((C_word*)t12)[1];
f_4530(t14,t1,t2);}

/* call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4288(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4288,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4298,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4303,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=t3,a[6]=t5,a[7]=((C_word*)t0)[2],a[8]=((C_word)li32),tmp=(C_word)a,a+=9,tmp);
/* expand.scm:207: call-with-current-continuation */
t9=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k3780 in walk in strip-syntax in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3782,2,t0,t1);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(0),t1);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3775,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
/* expand.scm:117: walk */
t7=((C_word*)((C_word*)t0)[6])[1];
f_3710(t7,t4,t6);}

/* k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in ... */
static void C_ccall f_8224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8224,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8228,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[44],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[47],a[47]=((C_word*)t0)[2],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:97: r */
t4=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[217]);}

/* k11380 in k11377 in a11374 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in ... */
static void C_ccall f_11382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11382,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[102],t3));}

/* k8818 in k8743 */
static void C_ccall f_8820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8820,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8824,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);
/* synrules.scm:193: process-pattern */
t7=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_fast_retrieve_proc(t7))(6,t7,t3,t5,t6,((C_word*)t0)[7],C_SCHEME_FALSE);}

/* k4296 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:207: g569 */
t2=t1;
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k11393 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1072: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[319],C_SCHEME_END_OF_LIST,t1);}

/* a11396 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11397,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11401,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1077: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[319],t2,lf[322]);}

/* get-line-number in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6850,3,t0,t1,t2);}
if(C_truep(*((C_word*)lf[113]+1))){
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
if(C_truep(C_i_symbolp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6870,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:685: ##sys#hash-table-ref */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[140]+1)))(4,*((C_word*)lf[140]+1),t5,*((C_word*)lf[113]+1),t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k8282 */
static void C_ccall f_8284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8284,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[45],((C_word*)((C_word*)t0)[2])[1]);
t3=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,1,t3);
/* synrules.scm:61: ##sys#append */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],t1,t4);}

/* k8822 in k8818 in k8743 */
static void C_ccall f_8824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:192: append */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* ##sys#syntax-rules-mismatch in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6844(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6844,3,t0,t1,t2);}
/* expand.scm:678: ##sys#syntax-error-hook */
t3=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[138],t2);}

/* k3773 in k3780 in walk in strip-syntax in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* k11377 in a11374 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 in ... */
static void C_ccall f_11379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1087: check-for-multiple-bindings */
f_8007(t2,t3,((C_word*)t0)[2],lf[317]);}

/* g1565 in k7685 in k7630 in k7622 in compare in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static C_word C_fcall f_7672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
t2=C_i_cdr(t1);
return(C_eqp(t2,((C_word*)t0)[2]));}

/* a11374 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11375,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11379,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1086: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[316],t2,lf[318]);}

/* k11371 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1081: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[316],C_SCHEME_END_OF_LIST,t1);}

/* k6868 in get-line-number in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6870,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6874,a[2]=((C_word*)t0)[2],a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:680: g1325 */
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_6874(t2,t1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* g1325 in k6868 in get-line-number in k4099 in k3625 in k3621 in k3617 in k3613 */
static C_word C_fcall f_6874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
t2=C_i_assq(((C_word*)t0)[2],t1);
return((C_truep(t2)?C_i_cdr(t2):C_SCHEME_FALSE));}

/* k11356 in k11333 in a11330 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in ... */
static void C_ccall f_11358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11358,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k11323 in a11293 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in ... */
static void C_ccall f_11325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11325,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,4,lf[291],((C_word*)t0)[4],t2,C_SCHEME_FALSE));}

/* k11327 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 in ... */
static void C_ccall f_11329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1090: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[313],C_SCHEME_END_OF_LIST,t1);}

/* k11333 in a11330 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in ... */
static void C_ccall f_11335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11335,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t2))){
t4=C_u_i_car(t2);
t5=C_a_i_list(&a,2,lf[314],t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11358,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_u_i_cdr(t2);
t9=C_a_i_list(&a,1,t3);
/* expand.scm:1090: ##sys#append */
t10=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[100],t2,t3));}}

/* a11330 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 in ... */
static void C_ccall f_11331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11331,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11335,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1095: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[313],t2,lf[315]);}

/* k6385 in k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:571: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6184(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k7685 in k7630 in k7622 in compare in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7687,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7672,a[2]=((C_word*)t0)[3],a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:837: g1565 */
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_7672(t3,t2));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k3654 in k3651 in macro-alias in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_3656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3656,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:91: gensym */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3651 in macro-alias in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3656(t3,t1);}
else{
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_block_size(t3);
if(C_truep(C_fixnum_greaterp(t4,C_fix(0)))){
t5=C_subchar(t3,C_fix(0));
t6=t2;
f_3656(t6,C_i_char_equalp(C_make_character(35),t5));}
else{
t5=t2;
f_3656(t5,C_SCHEME_FALSE);}}}

/* k3657 in k3654 in k3651 in macro-alias in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3659,2,t0,t1);}
t2=f_3629(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
t4=((C_word*)t0)[2];
t5=C_i_getprop(t4,lf[7],C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_a_i_putprop(&a,3,t1,lf[5],t3);
t7=C_a_i_putprop(&a,3,t1,lf[7],t5);
t8=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}
else{
t6=((C_word*)t0)[2];
t7=C_a_i_putprop(&a,3,t1,lf[5],t3);
t8=C_a_i_putprop(&a,3,t1,lf[7],t6);
t9=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t1);}}

/* k5136 in g800 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(t1,C_fix(1));
/* expand.scm:342: string->keyword */
t3=*((C_word*)lf[74]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k5132 in g800 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5134,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[71],t1);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_truep(t3)?t3:((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
if(C_truep(C_i_pairp(t6))){
t7=((C_word*)t0)[4];
t8=C_u_i_cdr(t7);
t9=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t8);
t10=C_a_i_cons(&a,2,lf[72],t9);
t11=C_a_i_list(&a,1,t10);
t12=C_a_i_cons(&a,2,t4,t11);
t13=C_a_i_cons(&a,2,t2,t12);
t14=C_a_i_cons(&a,2,lf[73],t13);
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_a_i_list(&a,2,((C_word*)t0)[6],t14));}
else{
t7=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t2,t7);
t9=C_a_i_cons(&a,2,lf[73],t8);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_list(&a,2,((C_word*)t0)[6],t9));}}

/* map-loop794 in k5139 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5146(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5146,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5175,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:362: g800 */
t5=((C_word*)t0)[5];
f_5081(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5139 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5146,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5146(t6,t2,t1);}

/* k5142 in k5139 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5144,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
f_4944(t4,C_a_i_list(&a,1,t3));}

/* k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in ... */
static void C_ccall f_8118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8121,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10107,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10109,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1331: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in ... */
static void C_ccall f_8115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10140,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10142,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1279: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in ... */
static void C_ccall f_8112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8115,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10433,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10435,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1250: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4658 in k4573 in k4561 in k4552 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4660,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,lf[51],t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=C_a_i_list(&a,1,t5);
t7=C_a_i_list(&a,3,lf[52],t6,((C_word*)t0)[3]);
t8=t7;
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4597,a[2]=t8,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4599,a[2]=t12,a[3]=t15,a[4]=t10,a[5]=((C_word)li35),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_4599(t17,t13,((C_word*)t0)[5]);}

/* expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6178(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6178,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li64),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_6184(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* map-loop638 in k4573 in k4561 in k4552 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4666(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4666,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11784 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:943: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[207],C_SCHEME_END_OF_LIST,t1);}

/* a11787 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11788,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11792,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:948: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[207],t2,lf[349]);}

/* k5225 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5227,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_eqp(t2,lf[65]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5240,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t4,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t7=t6;
f_5240(t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5256,a[2]=((C_word*)t0)[9],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:398: macro-alias */
f_3646(t7,lf[77],((C_word*)t0)[10]);}}
else{
t6=C_eqp(t2,lf[64]);
if(C_truep(t6)){
if(C_truep(C_fixnum_less_or_equal_p(((C_word*)t0)[4],C_fix(1)))){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5274,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_pairp(t4))){
t8=C_u_i_car(t4);
t9=t7;
f_5274(t9,C_i_symbolp(t8));}
else{
t8=t7;
f_5274(t8,C_SCHEME_FALSE);}}
else{
/* expand.scm:410: err */
t7=((C_word*)t0)[8];
f_4895(t7,((C_word*)t0)[6],lf[79]);}}
else{
t7=C_eqp(t2,lf[66]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5316,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[12],a[7]=t4,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t9=((C_word*)((C_word*)t0)[9])[1];
if(C_truep(t9)){
t10=t8;
f_5316(t10,C_SCHEME_UNDEFINED);}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5335,a[2]=((C_word*)t0)[9],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:412: macro-alias */
f_3646(t10,lf[77],((C_word*)t0)[10]);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
t8=((C_word*)t0)[4];
switch(t8){
case C_fix(0):
t9=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[7]);
/* expand.scm:419: loop */
t10=((C_word*)((C_word*)t0)[5])[1];
f_4926(t10,((C_word*)t0)[6],C_fix(0),t9,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t4);
case C_fix(1):
t9=C_a_i_list2(&a,2,((C_word*)t0)[2],C_SCHEME_FALSE);
t10=C_a_i_cons(&a,2,t9,((C_word*)t0)[12]);
/* expand.scm:420: loop */
t11=((C_word*)((C_word*)t0)[5])[1];
f_4926(t11,((C_word*)t0)[6],C_fix(1),((C_word*)t0)[7],t10,C_SCHEME_END_OF_LIST,t4);
case C_fix(2):
/* expand.scm:421: err */
t9=((C_word*)t0)[8];
f_4895(t9,((C_word*)t0)[6],lf[81]);
default:
t9=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t10=C_a_i_cons(&a,2,t9,((C_word*)t0)[13]);
/* expand.scm:422: loop */
t11=((C_word*)((C_word*)t0)[5])[1];
f_4926(t11,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[7],((C_word*)t0)[12],t10,t4);}}
else{
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5403,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t9=C_u_i_length(((C_word*)t0)[2]);
t10=C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=C_i_car(((C_word*)t0)[2]);
t12=t8;
f_5403(t12,C_i_symbolp(t11));}
else{
t11=t8;
f_5403(t11,C_SCHEME_FALSE);}}
else{
t9=t8;
f_5403(t9,C_SCHEME_FALSE);}}}}}}

/* k11790 in a11787 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11792,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,lf[71],t2));}

/* k11767 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:951: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[133],C_SCHEME_END_OF_LIST,t1);}

/* k5238 in k5225 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5240(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
/* expand.scm:400: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4926(t3,((C_word*)t0)[4],C_fix(1),((C_word*)t0)[5],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[6]);}
else{
/* expand.scm:401: err */
t3=((C_word*)t0)[7];
f_4895(t3,((C_word*)t0)[4],lf[76]);}}

/* loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6184(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6184,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep(C_i_pairp(t2))){
t7=C_i_car(t2);
t8=t7;
t9=t2;
t10=C_u_i_cdr(t9);
t11=C_i_pairp(t8);
t12=(C_truep(t11)?C_u_i_car(t8):C_SCHEME_FALSE);
t13=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=t10,a[8]=t5,a[9]=t6,a[10]=t1,a[11]=t8,a[12]=((C_word*)t0)[5],a[13]=t2,a[14]=((C_word*)t0)[6],a[15]=((C_word*)t0)[7],tmp=(C_word)a,a+=16,tmp);
if(C_truep(t12)){
t14=C_i_symbolp(t12);
t15=t13;
f_6204(t15,(C_truep(t14)?t12:C_SCHEME_FALSE));}
else{
t14=t13;
f_6204(t14,C_SCHEME_FALSE);}}
else{
/* expand.scm:528: fini */
t7=((C_word*)((C_word*)t0)[6])[1];
f_5586(t7,t1,t3,t4,t5,t6,t2);}}

/* k11773 in a11770 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11775,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,lf[206],t2));}

/* k5254 in k5225 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_5240(t3,t2);}

/* a11770 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11771,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11775,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:956: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[133],t2,lf[348]);}

/* compare in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word *a;
loop:
a=C_alloc(10);
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr4,(void*)f_7513,4,t0,t1,t2,t3);}
if(C_truep(C_i_pairp(t2))){
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7535,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=t2;
t6=C_u_i_car(t5);
t7=t3;
t8=C_u_i_car(t7);
/* expand.scm:820: compare */
t28=t4;
t29=t6;
t30=t8;
t1=t28;
t2=t29;
t3=t30;
c=4;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
if(C_truep(C_i_vectorp(t2))){
if(C_truep(C_i_vectorp(t3))){
t4=t2;
t5=C_block_size(t4);
t6=t5;
t7=t3;
t8=C_block_size(t7);
t9=C_eqp(t6,t8);
if(C_truep(t9)){
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7572,a[2]=t6,a[3]=t11,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word)li93),tmp=(C_word)a,a+=8,tmp));
t13=((C_word*)t11)[1];
f_7572(t13,t1,C_fix(0),C_SCHEME_TRUE);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=C_i_symbolp(t2);
t5=(C_truep(t4)?C_i_symbolp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t2;
t7=C_i_getprop(t6,lf[5],C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7624,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t9=t8;
f_7624(t9,t7);}
else{
t9=t2;
t10=((C_word*)t0)[3];
t11=f_3629(t9,t10);
if(C_truep(t11)){
t12=t8;
f_7624(t12,t11);}
else{
t12=t2;
t13=t8;
f_7624(t13,t12);}}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_eqp(t2,t3));}}}}

/* k11531 in k11528 in a11514 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11533,2,t0,t1);}
t2=C_i_getprop(((C_word*)t0)[2],lf[5],C_SCHEME_FALSE);
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11568,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1013: ##sys#current-module */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[240]+1)))(2,*((C_word*)lf[240]+1),t6);}

/* k11739 in a11736 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11741,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[98],t2));}

/* k11528 in a11514 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1011: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[96],((C_word*)t0)[3],lf[339]);}

/* k6341 in k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:565: fini/syntax */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5990(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k11756 in a11753 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11758,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[291],t2));}

/* a11753 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11754,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11758,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:964: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[308],t2,lf[347]);}

/* k11545 in k11542 in k11531 in k11528 in a11514 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11547,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[334],((C_word*)t0)[4],t2));}

/* k11542 in k11531 in k11528 in a11514 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11557,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11564,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1014: r */
t5=((C_word*)t0)[7];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t4,lf[96]);}

/* k11750 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:959: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[308],C_SCHEME_END_OF_LIST,t1);}

/* k7533 in compare in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:821: compare */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7513(4,t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10176 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_10178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10178,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,lf[194],t1));}

/* k5173 in map-loop794 in k5139 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5175,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5146(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5146(t6,((C_word*)t0)[5],t5);}}

/* a11736 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11737,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11741,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:972: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[345],t2,lf[346]);}

/* k11733 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:967: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[345],C_SCHEME_END_OF_LIST,t1);}

/* k6353 in k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6355,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
/* expand.scm:569: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_6184(t6,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],t3,t5);}

/* k10180 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_10182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1287: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k5184 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:357: ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)((C_word*)t0)[3])[1]);}

/* k11572 in k11569 in a11514 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
t4=C_u_i_car(t3);
t5=C_i_car(((C_word*)t0)[2]);
t6=C_eqp(t4,t5);
if(C_truep(t6)){
/* expand.scm:1021: ##sys#syntax-error-hook */
t7=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,lf[335],((C_word*)t0)[5]);}
else{
t7=t2;
f_11577(2,t7,C_SCHEME_UNDEFINED);}}

/* k11575 in k11572 in k11569 in a11514 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11577,2,t0,t1);}
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,lf[72],t4);
t6=C_a_i_list(&a,2,lf[23],t5);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[334],t2,t6));}

/* k11569 in a11514 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1019: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[96],((C_word*)t0)[3],lf[336]);}

/* loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6707(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6707,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6717,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:641: outstr */
t4=((C_word*)t0)[2];
f_6691(t4,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6743,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=C_i_car(t2);
/* expand.scm:648: ##sys#strip-syntax */
t5=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k6703 in k6696 in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:673: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6734 in k6724 in k6721 in k6718 in k6715 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:645: ##sys#print */
t2=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE,((C_word*)t0)[3]);}

/* k6727 in k6724 in k6721 in k6718 in k6715 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:646: outstr */
t2=((C_word*)t0)[2];
f_6691(t2,((C_word*)t0)[3],lf[121]);}

/* k6724 in k6721 in k6718 in k6715 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6736,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(*((C_word*)lf[115]+1));
/* expand.scm:645: ##sys#strip-syntax */
t5=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k6721 in k6718 in k6715 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:644: outstr */
t3=((C_word*)t0)[2];
f_6691(t3,t2,lf[122]);}

/* k6718 in k6715 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:643: ##sys#print */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4]);}

/* k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in ... */
static void C_ccall f_10149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10149,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10152,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1283: r */
t4=((C_word*)t0)[6];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[278]);}

/* k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in ... */
static void C_ccall f_10146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10146,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10149,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1282: r */
t4=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[276]);}

/* k7591 in doloop1510 in compare in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
f_7572(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k10138 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in ... */
static void C_ccall f_10140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1276: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[275],C_SCHEME_END_OF_LIST,t1);}

/* a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in ... */
static void C_ccall f_10142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10142,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10146,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1281: r */
t6=t3;
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,lf[275]);}

/* walk in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_fcall f_10154(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10154,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10162,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1284: walk1 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_10164(t5,t4,t2,t3);}

/* k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_ccall f_10152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10152,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10154,a[2]=t8,a[3]=t6,a[4]=((C_word)li145),tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10164,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word)li146),tmp=(C_word)a,a+=8,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10327,a[2]=t8,a[3]=((C_word)li149),tmp=(C_word)a,a+=4,tmp));
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10422,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1325: ##sys#check-syntax */
t13=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t12,lf[275],((C_word*)t0)[5],lf[288]);}

/* loop in k9334 in macro-subset in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in ... */
static void C_fcall f_9338(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9338,NULL,3,t0,t1,t2);}
t3=C_i_nullp(t2);
t4=(C_truep(t3)?t3:C_eqp(t2,((C_word*)t0)[2]));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=C_i_car(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9359,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t2;
t9=C_u_i_cdr(t8);
/* expand.scm:1519: loop */
t11=t7;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* k9334 in macro-subset in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in ... */
static void C_ccall f_9336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9336,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9338,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li126),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_9338(t5,((C_word*)t0)[3],t1);}

/* doloop331 in k3798 in walk in strip-syntax in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_3809(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3809,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3830,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[5],t2);
/* expand.scm:125: walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3710(t5,t3,t4);}}

/* k5275 in k5272 in k5225 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_car(((C_word*)t0)[2]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=C_u_i_cdr(((C_word*)t0)[2]);
/* expand.scm:408: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4926(t5,((C_word*)t0)[5],C_fix(2),((C_word*)t0)[6],((C_word*)t0)[7],C_SCHEME_END_OF_LIST,t4);}

/* k5272 in k5225 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5274(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5274,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t3)){
t4=t2;
f_5277(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_i_car(((C_word*)t0)[2]);
t5=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t4);
t6=t2;
f_5277(t6,t5);}}
else{
/* expand.scm:409: err */
t2=((C_word*)t0)[9];
f_4895(t2,((C_word*)t0)[5],lf[78]);}}

/* k3798 in walk in strip-syntax in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
t2=t1;
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3809,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word)li2),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_3809(t9,((C_word*)t0)[6],C_fix(0));}

/* a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li28),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4467,a[2]=((C_word*)t0)[8],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4484,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tmp13083 */
t5=t2;
f_4412(t5,t4);}

/* tmp13083 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4412(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4412,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4416,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[3],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4449,a[2]=t6,a[3]=t4,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li26),tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4460,a[2]=t4,a[3]=t6,a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:237: ##sys#dynamic-wind */
t10=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t2,t7,t8,t9);}
else{
/* expand.scm:239: handler */
t3=((C_word*)t0)[5];
((C_proc5)C_fast_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* k10160 in walk in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_10162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1284: simplify */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10327(t2,((C_word*)t0)[3],t1);}

/* walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_fcall f_10164(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10164,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10178,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10182,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1287: vector->list */
t6=*((C_word*)lf[175]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10201,a[2]=t3,a[3]=t1,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[4],a[9]=t5,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* expand.scm:1292: c */
t9=((C_word*)t0)[6];
((C_proc4)C_fast_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[3],t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,lf[71],t2));}}}

/* k4417 in k4414 in tmp13083 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k4414 in tmp13083 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4416,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=(C_truep(t4)?C_SCHEME_FALSE:C_eqp(((C_word*)t0)[4],t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4432,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4436,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:243: symbol->string */
t8=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[5]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k6715 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:642: outstr */
t3=((C_word*)t0)[2];
f_6691(t3,t2,lf[123]);}

/* doloop1510 in compare in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_7572(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7572,NULL,4,t0,t1,t2,t3);}
t4=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:C_i_not(t3));
if(C_truep(t5)){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_fixnum_plus(t2,C_fix(1));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7593,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=C_i_vector_ref(((C_word*)t0)[4],t2);
t10=C_i_vector_ref(((C_word*)t0)[5],t2);
/* expand.scm:827: compare */
t11=((C_word*)((C_word*)t0)[6])[1];
f_7513(4,t11,t8,t9,t10);}}

/* k10118 in k10111 in a10108 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_ccall f_10120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10120,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,t2);
t4=C_a_i_list(&a,3,lf[99],t3,lf[273]);
t5=C_a_i_list(&a,2,lf[270],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,2,t1,t5));}

/* k11698 in loop in k11620 in a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11700,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_u_i_car(((C_word*)t0)[3]);
t4=C_u_i_cdr(((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=C_a_i_cons(&a,2,lf[72],t5);
t7=C_a_i_list3(&a,3,t2,t3,t6);
/* expand.scm:999: loop */
t8=((C_word*)((C_word*)t0)[5])[1];
f_11627(t8,((C_word*)t0)[6],t7);}

/* k11555 in k11542 in k11531 in k11528 in a11514 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11557,2,t0,t1);}
if(C_truep(t1)){
/* expand.scm:1015: ##sys#defjam-error */
t2=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=C_i_car(((C_word*)t0)[4]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[334],((C_word*)t0)[6],t2));}}

/* k11113 in k11056 in k11016 in k10972 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_11115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11115,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,4,lf[291],((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k11566 in k11531 in k11528 in a11514 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1013: ##sys#register-export */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[338]+1)))(4,*((C_word*)lf[338]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k11562 in k11542 in k11531 in k11528 in a11514 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1014: c */
t2=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k11016 in k10972 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_11018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11018,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1173: r */
t3=((C_word*)t0)[6];
((C_proc3)C_fast_retrieve_proc(t3))(3,t3,t2,lf[77]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_u_i_length(((C_word*)t0)[2]);
t4=C_eqp(t3,C_fix(4));
if(C_truep(t4)){
t5=C_i_caddr(((C_word*)t0)[2]);
/* expand.scm:1179: c */
t6=((C_word*)t0)[7];
((C_proc4)C_fast_retrieve_proc(t6))(4,t6,t2,((C_word*)t0)[8],t5);}
else{
t5=t2;
f_11058(2,t5,C_SCHEME_FALSE);}}}

/* k11010 in k10972 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_11012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11012,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k11019 in k11016 in k10972 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_11021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11021,2,t0,t1);}
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=C_i_caddr(((C_word*)t0)[2]);
t8=C_a_i_list(&a,2,t7,t2);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11040,a[2]=t2,a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1177: expand */
t11=((C_word*)((C_word*)t0)[4])[1];
f_10919(t11,t10,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k9394 in g2765 in k9377 in fixup-macro-environment in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in ... */
static void C_ccall f_9396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_car(((C_word*)t0)[3],t1));}

/* k9327 in macro-subset in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in ... */
static void C_ccall f_9329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1520: ##sys#fixup-macro-environment */
t2=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* ##sys#macro-subset in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9322(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_9322r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9322r(t0,t1,t2,t3);}}

static void C_ccall f_9322r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(8);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9329,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9336,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1516: ##sys#macro-environment */
t9=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k3828 in doloop331 in k3798 in walk in strip-syntax in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3809(t4,((C_word*)t0)[5],t3);}

/* k6017 in loop in fini/syntax in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6024,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_6024(t6,t2,t1);}

/* ##sys#fixup-macro-environment in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9372(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_9372r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9372r(t0,t1,t2,t3);}}

static void C_ccall f_9372r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9379,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
/* expand.scm:1523: ##sys#append */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t5);}
else{
t7=t6;
f_9379(2,t7,t2);}}

/* k9377 in fixup-macro-environment in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in ... */
static void C_ccall f_9379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9379,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9380,a[2]=t2,a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=C_i_check_list_2(t4,lf[14]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9419,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9421,a[2]=t8,a[3]=t3,a[4]=((C_word)li129),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_9421(t10,t6,t4);}

/* k9175 in k9164 */
static void C_ccall f_9177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:271: free-meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_fast_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t1);}

/* k7371 in rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7373,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7377,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:783: rename */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7359(3,t6,t3,t5);}

/* k7375 in k7371 in rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7377,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* loop in fini/syntax in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6000(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6000,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6019,a[2]=t2,a[3]=t1,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:503: reverse */
t10=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t3);}
else{
if(C_truep(C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6072,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t2);
if(C_truep(C_i_listp(t6))){
t7=t2;
t8=C_u_i_car(t7);
t9=C_i_length(t8);
if(C_truep(C_fixnum_greater_or_equal_p(C_fix(3),t9))){
t10=C_i_caar(t2);
if(C_truep(C_i_symbolp(t10))){
t11=t2;
t12=C_u_i_car(t11);
t13=C_u_i_car(t12);
/* expand.scm:508: comp */
t14=t5;
f_6072(t14,f_5520(((C_word*)((C_word*)t0)[3])[1],lf[96],t13));}
else{
t11=t5;
f_6072(t11,C_SCHEME_FALSE);}}
else{
t10=t5;
f_6072(t10,C_SCHEME_FALSE);}}
else{
t7=t5;
f_6072(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm:504: loop */
t20=t1;
t21=t2;
t22=t3;
t23=C_SCHEME_TRUE;
t1=t20;
t2=t21;
t3=t22;
t4=t23;
goto loop;}}}

/* g2765 in k9377 in fixup-macro-environment in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in ... */
static void C_fcall f_9380(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9380,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9396,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(t2);
if(C_truep(C_i_nullp(t7))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_i_set_car(t5,((C_word*)t0)[2]));}
else{
t8=t2;
t9=C_u_i_cdr(t8);
t10=C_u_i_car(t9);
/* expand.scm:1531: ##sys#append */
t11=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t6,t10,((C_word*)t0)[2]);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k9357 in loop in k9334 in macro-subset in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in ... */
static void C_ccall f_9359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9359,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k7396 in rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:785: rename */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7359(3,t2,((C_word*)t0)[3],t1);}

/* k7392 in rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:785: list->vector */
t2=*((C_word*)lf[174]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9164 */
static void C_ccall f_9166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9166,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=C_i_cddr(((C_word*)t0)[2]);
/* synrules.scm:273: free-meta-variables */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc6)C_fast_retrieve_proc(t6))(6,t6,t4,t5,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* synrules.scm:278: free-meta-variables */
t7=((C_word*)((C_word*)t0)[3])[1];
((C_proc6)C_fast_retrieve_proc(t7))(6,t7,t4,t6,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9211,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* synrules.scm:281: vector->list */
t3=*((C_word*)lf[175]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}}}}

/* k7713 in k7630 in k7622 in compare in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7715,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7700,a[2]=((C_word*)t0)[3],a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:844: g1574 */
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_7700(t3,t2));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_8085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11417,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11419,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1066: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_8088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8091,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11395,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11397,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1075: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k9604 in k9601 in k9580 in k9577 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in ... */
static void C_ccall f_9606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9606,2,t0,t1);}
t2=C_i_cddddr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,lf[247],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=C_a_i_cons(&a,2,t1,t4);
t6=C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t7=C_a_i_list(&a,4,t1,((C_word*)t0)[5],lf[248],t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,3,lf[98],t5,t7));}

/* k9601 in k9580 in k9577 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9603,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9606,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1453: r */
t4=((C_word*)t0)[6];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[246]);}

/* k11807 in a11804 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11809,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[72],t2));}

/* a11804 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11805,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11809,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:940: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[220],t2,lf[350]);}

/* k11801 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:935: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[220],C_SCHEME_END_OF_LIST,t1);}

/* k11086 in k11059 in k11056 in k11016 in k10972 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_11088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11088,2,t0,t1);}
t2=C_a_i_list(&a,4,lf[308],((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_a_i_list(&a,3,lf[72],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[99],((C_word*)t0)[6],t3));}

/* k11059 in k11056 in k11016 in k10972 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_11061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11061,2,t0,t1);}
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,t3);
t5=t4;
t6=C_i_cadr(((C_word*)t0)[2]);
t7=C_a_i_list(&a,3,lf[212],t6,t2);
t8=t7;
t9=C_i_cadddr(((C_word*)t0)[2]);
t10=C_a_i_list(&a,3,lf[212],t9,t2);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11088,a[2]=t8,a[3]=t11,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1187: expand */
t13=((C_word*)((C_word*)t0)[4])[1];
f_10919(t13,t12,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k9300 in loop */
static void C_ccall f_9302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
/* synrules.scm:311: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9295(t3,((C_word*)t0)[4],t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6743,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6633,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6677,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:629: ##sys#strip-syntax */
t7=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6746,2,t0,t1);}
t2=t1;
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6755,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:651: outstr */
t4=((C_word*)t0)[2];
f_6691(t4,t3,((C_word*)t0)[7]);}
else{
t3=((C_word*)t0)[8];
t4=C_u_i_cdr(t3);
/* expand.scm:672: loop */
t5=((C_word*)((C_word*)t0)[9])[1];
f_6707(t5,((C_word*)t0)[3],t4);}}

/* k11056 in k11016 in k10972 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_11058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11058,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1180: r */
t3=((C_word*)t0)[6];
((C_proc3)C_fast_retrieve_proc(t3))(3,t3,t2,lf[77]);}
else{
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_u_i_cdr(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,lf[98],t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11115,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1190: expand */
t8=((C_word*)((C_word*)t0)[4])[1];
f_10919(t8,t7,((C_word*)t0)[5],C_SCHEME_FALSE);}}

/* a4472 in tmp23084 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4473,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* k11818 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:926: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[351],C_SCHEME_END_OF_LIST,t1);}

/* a11821 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11822,5,t0,t1,t2,t3,t4);}
t5=*((C_word*)lf[352]+1);
/* expand.scm:929: g1709 */
((C_proc10)C_fast_retrieve_proc(*((C_word*)lf[352]+1)))(10,*((C_word*)lf[352]+1),t1,t2,t3,t4,*((C_word*)lf[1]+1),*((C_word*)lf[19]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[351]);}

/* k6768 in k6765 in k6762 in k6759 in k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6770,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6787,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_i_car(((C_word*)t0)[2]);
/* expand.scm:661: symbol->string */
t7=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6802,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6804,a[2]=t7,a[3]=((C_word)li74),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6804(t9,t5,((C_word*)t0)[2]);}}

/* k11038 in k11019 in k11016 in k10972 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_11040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11040,2,t0,t1);}
t2=C_a_i_list(&a,4,lf[291],((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[50],((C_word*)t0)[5],t2));}

/* k6759 in k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:654: outstr */
t3=((C_word*)t0)[3];
f_6691(t3,t2,lf[131]);}

/* k6762 in k6759 in k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:655: ##sys#print */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[6]);}

/* k6765 in k6762 in k6759 in k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:656: outstr */
t3=((C_word*)t0)[3];
f_6691(t3,t2,lf[130]);}

/* k5615 in loop in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5617,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5628,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:475: reverse */
t4=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
/* expand.scm:476: loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5598(t5,((C_word*)t0)[2],t3,t4);}}

/* g1574 in k7713 in k7630 in k7622 in compare in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static C_word C_fcall f_7700(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
t2=C_i_cdr(t1);
return(C_eqp(((C_word*)t0)[2],t2));}

/* k5622 in k5615 in loop in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5624,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[98],t1));}

/* k5626 in k5615 in loop in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5628,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:475: expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6178(t4,t3,((C_word*)t0)[4]);}

/* k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_8001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8001,2,t0,t1);}
t2=C_mutate2((C_word*)lf[91]+1 /* (set! ##sys#define-definition ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8005,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11513,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11515,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1005: ##sys#er-transformer */
t6=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6781 in k6768 in k6765 in k6762 in k6759 in k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:658: outstr */
t2=((C_word*)t0)[2];
f_6691(t2,((C_word*)t0)[3],t1);}

/* loop in check-for-multiple-bindings in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_8013(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8013,NULL,5,t0,t1,t2,t3,t4);}
t5=C_i_nullp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8026,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t7=C_i_caar(t2);
if(C_truep(C_i_memq(t7,t3))){
t8=t2;
t9=C_u_i_car(t8);
t10=C_u_i_car(t9);
t11=C_i_memq(t10,t4);
t12=t6;
f_8026(t12,C_i_not(t11));}
else{
t8=t6;
f_8026(t8,C_SCHEME_FALSE);}}}

/* k4430 in k4414 in tmp13083 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:241: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k6785 in k6768 in k6765 in k6762 in k6759 in k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:659: string-append */
t2=*((C_word*)lf[36]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[124],t1,lf[125]);}

/* k4434 in k4414 in tmp13083 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:242: string-append */
t2=*((C_word*)lf[36]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[42],t1,lf[43]);}

/* g1234 in mwalk in match-expression in k4099 in k3625 in k3621 in k3617 in k3613 */
static C_word C_fcall f_6492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
t2=C_i_cdr(t1);
return(C_i_equalp(((C_word*)t0)[2],t2));}

/* make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7344,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7350,a[2]=t3,a[3]=t2,a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record2(&a,2,lf[24],t4));}

/* map-loop1040 in map-loop1016 in k5844 in k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5807,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5836,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:485: g1046 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9194 in k9164 */
static void C_ccall f_9196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:276: free-meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_fast_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t1);}

/* k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:652: outstr */
t3=((C_word*)t0)[3];
f_6691(t3,t2,lf[132]);}

/* k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:653: ##sys#print */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[7],C_SCHEME_TRUE,((C_word*)t0)[6]);}

/* rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_7359,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7373,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* expand.scm:783: rename */
t15=t3;
t16=t5;
t1=t15;
t2=t16;
c=3;
goto loop;}
else{
if(C_truep(C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7394,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7398,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:785: vector->list */
t5=*((C_word*)lf[175]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
if(C_truep(C_i_symbolp(t2))){
t3=C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=t1;
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_cdr(t3));}
else{
t4=f_3629(t2,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7428,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li91),tmp=(C_word)a,a+=6,tmp);
/* expand.scm:778: g1457 */
t6=t5;
f_7428(t6,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7496,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:812: macro-alias */
f_3646(t5,t2,((C_word*)t0)[4]);}}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}}

/* k9635 in k9580 in k9577 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1449: string->symbol */
t2=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7357,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7359,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li92),tmp=(C_word)a,a+=6,tmp));
t11=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7513,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word)li96),tmp=(C_word)a,a+=5,tmp));
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7750,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7775,a[2]=t9,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=((C_word)li98),tmp=(C_word)a,a+=8,tmp));
if(C_truep(((C_word*)t0)[5])){
/* expand.scm:891: handler */
t14=((C_word*)t0)[6];
((C_proc5)C_fast_retrieve_proc(t14))(5,t14,((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t3)[1],((C_word*)t5)[1]);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7903,a[2]=t9,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7907,a[2]=((C_word*)t0)[6],a[3]=t14,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:897: rename */
t16=((C_word*)t3)[1];
f_7359(3,t16,t15,((C_word*)t0)[8]);}}

/* k4482 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4484,2,t0,t1);}
/* tmp23084 */
t2=((C_word*)t0)[2];
f_4467(t2,((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* expand in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4486(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4486,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_listp(t3))){
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4512,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cadr(t4);
t7=t4;
t8=C_u_i_car(t7);
/* expand.scm:263: call-handler */
t9=((C_word*)((C_word*)t0)[2])[1];
f_4288(t9,t5,t2,t6,t3,t8,C_SCHEME_FALSE);}
else{
/* expand.scm:265: values */
C_values(4,0,t1,t3,C_SCHEME_FALSE);}}
else{
/* expand.scm:259: ##sys#syntax-error-hook */
t5=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[49],t3);}}

/* a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7350,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_listp(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7357,a[2]=t6,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t7)){
t9=t8;
f_7357(2,t9,t7);}
else{
/* expand.scm:778: ##sys#error */
t9=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,lf[178],t3);}}

/* f_9124 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_9124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9124,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_symbolp(t2))){
if(C_truep(C_i_memq(t2,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_i_assq(t2,t4);
if(C_truep(t6)){
t7=C_i_cdr(t6);
t8=t3;
t9=C_fixnum_greater_or_equal_p(t7,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?C_a_i_cons(&a,2,t2,t5):t5));}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9166,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=t4,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* synrules.scm:270: segment-template? */
t7=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_fast_retrieve_proc(t7))(3,t7,t6,t2);}}

/* k9120 in k9071 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:258: meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_fast_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k10355 in k10329 in simplify in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_10357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10357,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li148),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1280: g2220 */
t3=t2;
f_10361(t3,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10404,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1322: match-expression */
f_6475(t2,((C_word*)t0)[3],lf[282],lf[283]);}}

/* loop in k11620 in a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_11627(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11627,NULL,3,t0,t1,t2);}
t3=C_i_cadr(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
if(C_truep(C_i_pairp(t4))){
t8=C_i_car(t4);
if(C_truep(C_i_pairp(t8))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11690,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:995: ##sys#check-syntax */
t10=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[95],t2,lf[340]);}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11700,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:998: ##sys#check-syntax */
t10=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[95],t2,lf[341]);}}
else{
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11642,a[2]=t4,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:986: ##sys#check-syntax */
t9=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[95],t2,lf[343]);}}

/* k11620 in a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11622,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11627,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li171),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_11627(t5,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k8044 in k8024 in loop in check-for-multiple-bindings in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_8046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_u_i_car(t3);
/* expand.scm:1034: ##sys#warn */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[185]+1)))(5,*((C_word*)lf[185]+1),((C_word*)t0)[3],t1,t4,((C_word*)t0)[4]);}

/* simplify in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_fcall f_10327(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10327,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10331,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1313: match-expression */
f_6475(t3,t2,lf[286],lf[287]);}

/* a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11618,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11622,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:981: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[95],t2,lf[344]);}

/* k11614 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:976: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[95],C_SCHEME_END_OF_LIST,t1);}

/* k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_8091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8094,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11373,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11375,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1084: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_8094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11329,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11331,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1093: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k8027 in k8024 in loop in check-for-multiple-bindings in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_8029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8029,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_caar(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
/* expand.scm:1038: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8013(t6,((C_word*)t0)[5],t3,((C_word*)t0)[6],t5);}

/* k8024 in loop in check-for-multiple-bindings in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_8026(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8026,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8046,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1035: string-append */
t4=*((C_word*)lf[36]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[186],((C_word*)t0)[8],lf[187]);}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_caar(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm:1039: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8013(t6,((C_word*)t0)[5],t3,t5,((C_word*)t0)[3]);}}

/* k6796 in k6768 in k6765 in k6762 in k6759 in k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:663: outstr */
t2=((C_word*)t0)[2];
f_6691(t2,((C_word*)t0)[3],t1);}

/* k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_8082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11439,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11441,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1057: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3868 in k3843 in extend-se in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3884,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3884(t11,t7,t6,((C_word*)t0)[5]);}

/* k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 in ... */
static void C_ccall f_8097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11292,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11294,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1105: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k6973 in loop in k6945 in lambda-list? in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_not(t1));}

/* f_8715 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_8715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8715,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_symbolp(t2))){
if(C_truep(C_i_memq(t2,((C_word*)t0)[2]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8739,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* synrules.scm:174: mapit */
t7=t4;
((C_proc3)C_fast_retrieve_proc(t7))(3,t7,t6,t3);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8745,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* synrules.scm:175: segment-pattern? */
t7=((C_word*)((C_word*)t0)[10])[1];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t6,t2,t5);}}

/* g2220 in k10355 in k10329 in simplify in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_fcall f_10361(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10361,NULL,3,t0,t1,t2);}
t3=C_i_assq(lf[281],t2);
t4=C_i_length(t3);
if(C_truep(C_fixnum_lessp(t4,C_fix(32)))){
t5=C_i_assq(lf[280],t2);
t6=C_i_cdr(t5);
t7=C_i_cdr(t3);
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,lf[273],t8);
/* expand.scm:1319: simplify */
t10=((C_word*)((C_word*)t0)[2])[1];
f_10327(t10,t1,t9);}
else{
t5=((C_word*)t0)[3];
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k10794 in k10846 in k10746 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_fcall f_10796(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10796,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1232: expand */
t4=((C_word*)((C_word*)t0)[4])[1];
f_10715(t4,t3,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k10329 in simplify in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_10331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10331,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10335,a[2]=((C_word*)t0)[2],a[3]=((C_word)li147),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1280: g2213 */
t3=t2;
f_10335(t3,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1315: match-expression */
f_6475(t2,((C_word*)t0)[4],lf[284],lf[285]);}}

/* g2213 in k10329 in simplify in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_fcall f_10335(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10335,NULL,3,t0,t1,t2);}
t3=C_i_assq(lf[280],t2);
t4=C_i_cdr(t3);
t5=C_a_i_list(&a,2,lf[273],t4);
/* expand.scm:1314: simplify */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10327(t6,t1,t5);}

/* k10449 in k10437 in a10434 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in ... */
static void C_ccall f_10451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10451,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[16]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10476,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10588,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=((C_word)li152),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_10588(t12,t8,((C_word*)t0)[2]);}

/* k10437 in a10434 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in ... */
static void C_ccall f_10439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10439,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10451,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1256: r */
t11=((C_word*)t0)[4];
((C_proc3)C_fast_retrieve_proc(t11))(3,t11,t10,lf[293]);}

/* k8919 in k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_ccall f_8921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8921,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8942,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* synrules.scm:231: segment-tail */
t4=((C_word*)((C_word*)t0)[6])[1];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[7]);}

/* a10434 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in ... */
static void C_ccall f_10435(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10435,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10439,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1252: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[289],t2,lf[294]);}

/* k10431 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in ... */
static void C_ccall f_10433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1247: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[289],C_SCHEME_END_OF_LIST,t1);}

/* ##sys#extend-se in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_3841r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3841r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3841r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3845,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=*((C_word*)lf[8]+1);
t11=t3;
t12=C_i_check_list_2(t11,lf[16]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3979,a[2]=t9,a[3]=t14,a[4]=t7,a[5]=t10,a[6]=((C_word)li7),tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_3979(t16,t5,t11);}
else{
t6=t5;
f_3845(2,t6,C_i_car(t4));}}

/* k11486 in k11473 in a11462 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1051: check-for-multiple-bindings */
f_8007(((C_word*)t0)[3],t2,((C_word*)t0)[2],lf[332]);}

/* k3843 in extend-se in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[2];
t4=C_i_check_list_2(t2,lf[14]);
t5=C_i_check_list_2(t3,lf[14]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3933,a[2]=t8,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_3933(t10,t6,t2,t3);}

/* k4510 in expand in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:261: values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k10897 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in ... */
static void C_ccall f_10899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1132: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[225],C_SCHEME_END_OF_LIST,t1);}

/* loop in k6945 in lambda-list? in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6955(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6955,NULL,3,t0,t1,t2);}
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6975,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:712: keyword? */
t5=*((C_word*)lf[146]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_car(t4);
if(C_truep(C_i_symbolp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7003,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:715: keyword? */
t7=*((C_word*)lf[146]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k8901 in k8895 in k8892 */
static void C_ccall f_8903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8903,2,t0,t1);}
t2=t1;
if(C_truep(C_i_nullp(t2))){
/* synrules.scm:216: ##sys#syntax-error-hook */
t3=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[211],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_car(t4);
/* synrules.scm:217: process-template */
t6=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_fast_retrieve_proc(t6))(5,t6,t3,t5,((C_word*)t0)[11],((C_word*)t0)[6]);}}

/* k10495 in k10474 in k10449 in k10437 in a10434 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_fcall f_10497(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10497,NULL,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10535,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10537,a[2]=t6,a[3]=t9,a[4]=t4,a[5]=((C_word)li151),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_10537(t11,t7,((C_word*)t0)[7]);}

/* k11465 in a11462 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11467,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[50],t3));}

/* a11462 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11463,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11467,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11475,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(t2);
if(C_truep(C_i_pairp(t7))){
t8=C_i_cadr(t2);
t9=t6;
f_11475(t9,C_i_symbolp(t8));}
else{
t8=t6;
f_11475(t8,C_SCHEME_FALSE);}}

/* k11459 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1041: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[55],C_SCHEME_END_OF_LIST,t1);}

/* k6404 in k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6406,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[2],t1);
if(C_truep(t2)){
/* expand.scm:577: fini */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5586(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9]);}
else{
t3=C_a_i_cons(&a,2,t1,((C_word*)t0)[10]);
/* expand.scm:578: loop */
t4=((C_word*)((C_word*)t0)[11])[1];
f_6184(t4,((C_word*)t0)[4],t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8]);}}

/* k6939 in k6918 in err in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:705: string-append */
t2=*((C_word*)lf[36]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[144],t1,lf[145],((C_word*)t0)[3]);}

/* lambda-list? in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6943,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6947,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:709: ##sys#extended-lambda-list? */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6945 in lambda-list? in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6947,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6955,a[2]=t3,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6955(t5,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k8936 in k8940 in k8919 in k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_ccall f_8938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:233: process-template */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc5)C_fast_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k8932 in k8940 in k8919 in k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_ccall f_8934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8934,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[70],((C_word*)t0)[3],t1));}

/* k10420 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_10422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1326: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10154(t3,((C_word*)t0)[4],t2,C_fix(0));}

/* k11476 in k11473 in a11462 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_caddr(((C_word*)t0)[2]);
/* expand.scm:1048: check-for-multiple-bindings */
f_8007(((C_word*)t0)[3],t2,((C_word*)t0)[2],lf[330]);}

/* k11473 in a11462 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_11475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11475,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1047: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[55],((C_word*)t0)[2],lf[331]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1050: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[55],((C_word*)t0)[2],lf[333]);}}

/* k10311 in k10307 in k10253 in k10232 in k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_10313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10313,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[198],((C_word*)t0)[3],t1));}

/* k10474 in k10449 in k10437 in a10434 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in ... */
static void C_ccall f_10476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10476,2,t0,t1);}
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_eqp(t5,C_SCHEME_END_OF_LIST);
t7=(C_truep(t6)?lf[290]:C_a_i_cons(&a,2,lf[98],t5));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10497,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t10=C_eqp(((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
if(C_truep(t10)){
t11=t9;
f_10497(t11,lf[292]);}
else{
t11=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[6]);
t12=t9;
f_10497(t12,C_a_i_cons(&a,2,lf[50],t11));}}

/* k11443 in a11440 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1060: check-for-multiple-bindings */
f_8007(t2,t3,((C_word*)t0)[2],lf[328]);}

/* k11446 in k11443 in a11440 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11448,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[52],t3));}

/* k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_fcall f_8918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8918,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8944,a[2]=t4,a[3]=((C_word)li116),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8944(t6,t2,((C_word*)t0)[8],t1);}

/* k8913 in k8901 in k8895 in k8892 */
static void C_ccall f_8915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8915,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8965,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[10]))){
t5=C_u_i_cdr(((C_word*)t0)[10]);
if(C_truep(C_i_nullp(t5))){
if(C_truep(C_i_symbolp(t2))){
t6=C_u_i_car(((C_word*)t0)[10]);
t7=t4;
f_8965(t7,C_eqp(t2,t6));}
else{
t6=t4;
f_8965(t6,C_SCHEME_FALSE);}}
else{
t6=t4;
f_8965(t6,C_SCHEME_FALSE);}}
else{
t5=t4;
f_8965(t5,C_SCHEME_FALSE);}}

/* k5834 in map-loop1040 in map-loop1016 in k5844 in k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5836,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5807(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5807(t6,((C_word*)t0)[5],t5);}}

/* g465 in loop1 in globalize in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4039(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4039,NULL,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
/* expand.scm:145: loop1 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4023(t3,t1,t2);}
else{
t3=((C_word*)t0)[3];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11421 in a11418 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1069: check-for-multiple-bindings */
f_8007(t2,t3,((C_word*)t0)[2],lf[325]);}

/* k11424 in k11421 in a11418 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11426,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[324],t3));}

/* k10307 in k10253 in k10232 in k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_ccall f_10309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10309,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10313,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1311: walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10154(t4,t3,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in ... */
static void C_ccall f_10933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10933,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10946,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1149: open-output-string */
t4=*((C_word*)lf[136]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10971,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=C_i_car(((C_word*)t0)[6]);
/* expand.scm:1153: c */
t4=((C_word*)t0)[9];
((C_proc4)C_fast_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[11],t3);}}

/* k11437 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1054: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[327],C_SCHEME_END_OF_LIST,t1);}

/* loop in loop1 in globalize in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4057(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4057,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* expand.scm:149: ##sys#alias-global-hook */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[18]+1)))(5,*((C_word*)lf[18]+1),t1,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4073,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_caar(t2);
t5=C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=t2;
t7=C_u_i_car(t6);
t8=C_u_i_cdr(t7);
t9=t3;
f_4073(t9,C_i_symbolp(t8));}
else{
t6=t3;
f_4073(t6,C_SCHEME_FALSE);}}}

/* k10937 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in ... */
static void C_ccall f_10939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10942,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1151: expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10919(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k7494 in rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7496,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* a4459 in tmp13083 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4460,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[45]+1));
t3=C_mutate2((C_word*)lf[45]+1 /* (set! ##sys#syntax-rules-mismatch ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* tmp23084 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4467(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4467,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4473,a[2]=t2,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:207: k565 */
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5694,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[16]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5949,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[9],a[5]=((C_word)li58),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5949(t7,t3,t1);}

/* k8737 */
static void C_ccall f_8739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8739,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list1(&a,1,t2));}

/* a4453 in tmp13083 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
/* expand.scm:238: handler */
t2=((C_word*)t0)[2];
((C_proc5)C_fast_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k4006 in map-loop355 in extend-se in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3979(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3979(t6,((C_word*)t0)[5],t5);}}

/* a11440 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11441,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11445,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1059: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[327],t2,lf[329]);}

/* k5033 in k4954 in k4942 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5035,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,t2);
/* expand.scm:381: ##sys#append */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t1,t3);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=C_a_i_list1(&a,1,t3);
/* expand.scm:381: ##sys#append */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t1,t4);}}

/* k5029 in k4954 in k4942 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5031,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,1,t4);
/* expand.scm:356: values */
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[6],t5);}

/* map-loop980 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5900(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5900,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[100],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5913,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_5913(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_5913(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* a4448 in tmp13083 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[45]+1));
t3=C_mutate2((C_word*)lf[45]+1 /* (set! ##sys#syntax-rules-mismatch ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* f_4443 in tmp13083 in a4409 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4443,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* ##sys#syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6622,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(*((C_word*)lf[115]+1)))){
/* expand.scm:635: ##sys#syntax-error-hook */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6689,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:636: open-output-string */
t5=*((C_word*)lf[136]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k6618 in syntax-error-hook in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[116]+1),lf[117],t1);}

/* ##sys#globalize in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4017,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4023,a[2]=t5,a[3]=t3,a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4023(t7,t1,t2);}

/* mwalk in match-expression in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6478(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6478,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_pairp(t3))){
if(C_truep(C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6532,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=t2;
t6=C_u_i_car(t5);
t7=C_i_car(t3);
/* expand.scm:596: mwalk */
t14=t4;
t15=t6;
t16=t7;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=C_i_assq(t3,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6492,a[2]=t2,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:590: g1234 */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6492(t5,t4));}
else{
if(C_truep(C_i_memq(t3,((C_word*)t0)[4]))){
t5=C_a_i_cons(&a,2,t3,t2);
t6=C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_eqp(t2,t3));}}}}

/* k5911 in map-loop980 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_5900(t5,((C_word*)t0)[7],t3,t4);}

/* k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5671,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5694,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t6,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
C_apply(5,0,t7,*((C_word*)lf[70]+1),t2,((C_word*)t0)[5]);}

/* k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in ... */
static void C_ccall f_10908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10908,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1139: r */
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[218]);}

/* match-expression in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6475(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6475,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6478,a[2]=t8,a[3]=t6,a[4]=t4,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6555,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:599: mwalk */
t11=((C_word*)t8)[1];
f_6478(t11,t10,t2,t3);}

/* a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in ... */
static void C_ccall f_10901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10901,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10908,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1138: r */
t8=t3;
((C_proc3)C_fast_retrieve_proc(t8))(3,t8,t7,lf[302]);}

/* ##sys#syntax-error-hook in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6612(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6612r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6612r(t0,t1,t2);}}

static void C_ccall f_6612r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6620,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:624: ##sys#strip-syntax */
t4=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* loop1 in globalize in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4023(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4023,NULL,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=C_i_getprop(t3,lf[5],C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4039,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:141: g465 */
t6=t5;
f_4039(t6,t1,t4);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4057,a[2]=t2,a[3]=t6,a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4057(t8,t1,((C_word*)t0)[3]);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4303,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word)li31),tmp=(C_word)a,a+=10,tmp);
/* expand.scm:207: with-exception-handler */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in ... */
static void C_ccall f_10911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10911,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10914,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1140: r */
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[224]);}

/* k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in ... */
static void C_ccall f_10914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10914,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10919,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word)li160),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_10919(t6,((C_word*)t0)[6],((C_word*)t0)[7],C_SCHEME_FALSE);}

/* k10402 in k10355 in k10329 in simplify in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_10404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_assq(lf[280],t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_cdr(t4));}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in ... */
static void C_fcall f_10919(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10919,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10933,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t5,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
/* expand.scm:1146: ##sys#check-syntax */
t9=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[225],t5,lf[311]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[312]);}}

/* a4308 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4309,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4315,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li22),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:207: k565 */
t4=((C_word*)t0)[3];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* loop in k6631 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6638,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_caar(t2);
t4=C_eqp(lf[133],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6658,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:632: cadar */
t6=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t5=t2;
t6=C_u_i_cdr(t5);
/* expand.scm:633: loop */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}

/* k6631 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6633,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6638,a[2]=t4,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6638(t6,((C_word*)t0)[2],t2);}

/* a4314 in a4308 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_structurep(((C_word*)t0)[2],lf[33]))){
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=t2;
f_4326(t4,C_i_memq(lf[40],t3));}
else{
t3=t2;
f_4326(t3,C_SCHEME_FALSE);}}

/* err in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6916(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6916,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[114]+1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6920,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:701: get-line-number */
t5=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,*((C_word*)lf[114]+1));}

/* k6909 in test in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* expand.scm:697: err */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6916(t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k4324 in a4314 in a4308 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4326,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4337,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_slot(((C_word*)t0)[2],C_fix(2));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[4],a[3]=t7,a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4343(t9,t4,t5);}
else{
t2=((C_word*)t0)[2];
/* expand.scm:210: ##sys#abort */
t3=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}}

/* assq-reverse in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static C_word C_fcall f_7750(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_overflow_check;
loop:
if(C_truep(C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=C_i_cdar(t2);
t4=C_eqp(t3,t1);
if(C_truep(t4)){
t5=t2;
return(C_u_i_car(t5));}
else{
t5=t2;
t6=C_u_i_cdr(t5);
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}

/* loop */
static void C_fcall f_9295(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9295,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9302,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_car(t4);
/* synrules.scm:310: ellipsis? */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t3,t5);}
else{
t4=t3;
f_9302(2,t4,C_SCHEME_FALSE);}}

/* k5010 in k4954 in k4942 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5012,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,1,t4);
/* expand.scm:356: values */
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[6],t5);}

/* test in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6904(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6904,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6911,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:697: pred */
t6=t3;
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,t2);}

/* k6602 in expand-curried-define in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6604,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list3(&a,3,lf[95],((C_word*)((C_word*)t0)[3])[1],t1));}

/* loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4926(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4926,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep(C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4940,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5186,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:357: reverse */
t9=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
/* expand.scm:357: reverse */
t8=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}
else{
if(C_truep(C_i_symbolp(t6))){
if(C_truep(C_fixnum_greaterp(t2,C_fix(2)))){
/* expand.scm:385: err */
t7=((C_word*)t0)[9];
f_4895(t7,t1,lf[75]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t7=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t6);
/* expand.scm:389: loop */
t17=t1;
t18=C_fix(4);
t19=t3;
t20=t4;
t21=C_SCHEME_END_OF_LIST;
t22=C_SCHEME_END_OF_LIST;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
t5=t21;
t6=t22;
goto loop;}
else{
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t6);
/* expand.scm:389: loop */
t17=t1;
t18=C_fix(4);
t19=t3;
t20=t4;
t21=C_SCHEME_END_OF_LIST;
t22=C_SCHEME_END_OF_LIST;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
t5=t21;
t6=t22;
goto loop;}}}
else{
if(C_truep(C_i_pairp(t6))){
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5227,a[2]=t8,a[3]=t6,a[4]=t2,a[5]=((C_word*)t0)[10],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[5],a[12]=t4,a[13]=t5,tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_i_symbolp(t8))){
t10=C_eqp(C_fix(3),t2);
t11=t9;
f_5227(t11,(C_truep(t10)?C_SCHEME_FALSE:f_3629(t8,((C_word*)t0)[11])));}
else{
t10=t9;
f_5227(t10,C_SCHEME_FALSE);}}
else{
/* expand.scm:391: err */
t7=((C_word*)t0)[9];
f_4895(t7,t1,lf[85]);}}}}

/* k4071 in loop in loop1 in globalize in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4073(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_cdr(t3));}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* expand.scm:151: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4057(t4,((C_word*)t0)[3],t3);}}

/* k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4921,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t4,a[11]=((C_word*)t0)[9],a[12]=((C_word)li49),tmp=(C_word)a,a+=13,tmp));
t6=((C_word*)t4)[1];
f_4926(t6,((C_word*)t0)[10],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[11]);}

/* k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_10201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10201,2,t0,t1);}
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1294: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[276],((C_word*)t0)[5],lf[277]);}
else{
t3=C_a_i_list(&a,2,lf[71],((C_word*)t0)[6]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10224,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
/* expand.scm:1297: walk */
t7=((C_word*)((C_word*)t0)[7])[1];
f_10154(t7,t5,((C_word*)t0)[4],t6);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10234,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:1298: c */
t3=((C_word*)t0)[11];
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],((C_word*)t0)[9]);}}

/* k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4918,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm:349: macro-alias */
f_3646(t3,lf[55],((C_word*)t0)[8]);}

/* k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4915,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4918,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm:348: macro-alias */
f_3646(t3,lf[86],((C_word*)t0)[7]);}

/* mirror-rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_7775(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7775,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7789,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* expand.scm:866: mirror-rename */
t16=t3;
t17=t5;
t1=t16;
t2=t17;
goto loop;}
else{
if(C_truep(C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7810,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7814,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:868: vector->list */
t5=*((C_word*)lf[175]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
if(C_truep(C_i_symbolp(t2))){
t3=f_3629(t2,((C_word*)t0)[3]);
t4=f_7750(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t4)){
t5=t1;
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_car(t4));}
else{
if(C_truep(t3)){
if(C_truep(C_i_pairp(t3))){
/* expand.scm:878: rename */
t5=((C_word*)((C_word*)t0)[6])[1];
f_7359(3,t5,t1,t2);}
else{
t5=t2;
t6=C_i_getprop(t5,lf[7],C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t1;
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t6);}
else{
/* expand.scm:885: rename */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7359(3,t7,t1,t2);}}}
else{
/* expand.scm:876: rename */
t5=((C_word*)((C_word*)t0)[6])[1];
f_7359(3,t5,t1,t2);}}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}}

/* k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4912,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:347: macro-alias */
f_3646(t3,lf[87],((C_word*)t0)[6]);}

/* a11831 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11832,5,t0,t1,t2,t3,t4);}
t5=*((C_word*)lf[352]+1);
/* expand.scm:922: g1695 */
((C_proc10)C_fast_retrieve_proc(*((C_word*)lf[352]+1)))(10,*((C_word*)lf[352]+1),t1,t2,t3,t4,*((C_word*)lf[2]+1),*((C_word*)lf[231]+1),C_SCHEME_TRUE,C_SCHEME_FALSE,lf[353]);}

/* k11828 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:919: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[353],C_SCHEME_END_OF_LIST,t1);}

/* k7444 in g1457 in rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_7446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7446,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:799: macro-alias */
f_3646(t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* k9015 in k8892 */
static void C_ccall f_9017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9017,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
/* synrules.scm:237: process-template */
t6=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_fast_retrieve_proc(t6))(5,t6,t3,t5,((C_word*)t0)[6],((C_word*)t0)[7]);}

/* a11841 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11842,5,t0,t1,t2,t3,t4);}
t5=*((C_word*)lf[352]+1);
/* expand.scm:916: g1681 */
((C_proc10)C_fast_retrieve_proc(*((C_word*)lf[352]+1)))(10,*((C_word*)lf[352]+1),t1,t2,t3,t4,*((C_word*)lf[1]+1),*((C_word*)lf[19]+1),C_SCHEME_FALSE,C_SCHEME_FALSE,lf[354]);}

/* k11838 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:913: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[354],C_SCHEME_END_OF_LIST,t1);}

/* k7447 in k7444 in g1457 in rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7449,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* map-loop418 in k3868 in k3843 in extend-se in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_3884(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3884,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_3897(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_3897(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3880 in k3868 in k3843 in extend-se in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:136: append */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k7791 in k7787 in mirror-rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7793,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k11640 in loop in k11620 in a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11642,2,t0,t1);}
t2=C_i_getprop(((C_word*)t0)[2],lf[5],C_SCHEME_FALSE);
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11681,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:988: ##sys#current-module */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[240]+1)))(2,*((C_word*)lf[240]+1),t6);}

/* k6816 in loop in k6768 in k6765 in k6762 in k6759 in k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6818,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6822,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:671: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6804(t6,t3,t5);}

/* k3895 in map-loop418 in k3868 in k3843 in extend-se in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_3897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_3884(t5,((C_word*)t0)[7],t3,t4);}

/* k11695 in k11688 in loop in k11620 in a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:996: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_11627(t2,((C_word*)t0)[3],t1);}

/* k11688 in loop in k11620 in a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:996: ##sys#expand-curried-define */
t3=*((C_word*)lf[104]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k6800 in k6768 in k6765 in k6762 in k6759 in k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:664: string-append */
t2=*((C_word*)lf[36]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[126],t1);}

/* loop in k6768 in k6765 in k6762 in k6759 in k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6804(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6804,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[127]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6818,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* expand.scm:670: symbol->string */
t5=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k4573 in k4561 in k4552 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4575,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_check_list_2(t3,lf[16]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4666,a[2]=t7,a[3]=t11,a[4]=t5,a[5]=((C_word)li36),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_4666(t13,t9,t3);}

/* k4711 in g698 in k4703 in k4552 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
t2=t1;
t3=C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
/* expand.scm:293: expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4486(t4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4725,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[58]+1))){
/* expand.scm:296: ##sys#compiler-syntax-hook */
t5=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],t2);}
else{
/* expand.scm:297: loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_4530(t5,((C_word*)t0)[4],t2);}}}

/* k10733 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_10735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10738,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1216: expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10715(t3,t2,((C_word*)t0)[4],C_SCHEME_TRUE);}

/* k10736 in k10733 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_10738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[297]);}

/* k11675 in k11651 in k11640 in loop in k11620 in a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:989: c */
t2=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* g800 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5081(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5081,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5138,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:365: ##sys#strip-syntax */
t7=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}

/* k11668 in k11651 in k11640 in loop in k11620 in a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* expand.scm:990: ##sys#defjam-error */
t2=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_11656(2,t2,C_SCHEME_UNDEFINED);}}

/* k10740 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_10742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1213: ##sys#warn */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[185]+1)))(4,*((C_word*)lf[185]+1),((C_word*)t0)[2],lf[298],t1);}

/* k10746 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_10748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10748,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1219: expand */
t3=((C_word*)((C_word*)t0)[7])[1];
f_10715(t3,t2,((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10833,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=((C_word)li156),tmp=(C_word)a,a+=5,tmp);
t7=C_u_i_car(((C_word*)t0)[2]);
t8=C_i_check_list_2(t7,lf[16]);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10848,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10850,a[2]=t6,a[3]=t5,a[4]=t11,a[5]=t3,a[6]=((C_word)li157),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_10850(t13,t9,t7);}}

/* k4595 in k4658 in k4573 in k4561 in k4552 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4597,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[53],t2);
/* expand.scm:280: values */
C_values(4,0,((C_word*)t0)[3],t3,C_SCHEME_TRUE);}

/* map-loop665 in k4658 in k4573 in k4561 in k4552 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4599,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11679 in k11640 in loop in k11620 in a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:988: ##sys#register-export */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[338]+1)))(4,*((C_word*)lf[338]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* g698 in k4703 in k4552 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4709(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4709,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_i_car(t2);
t5=t2;
t6=C_u_i_cdr(t5);
/* expand.scm:292: call-handler */
t7=((C_word*)((C_word*)t0)[7])[1];
f_4288(t7,t3,((C_word*)t0)[4],t4,((C_word*)t0)[2],t6,C_SCHEME_TRUE);}

/* k4703 in k4552 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4705,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li37),tmp=(C_word)a,a+=9,tmp);
/* expand.scm:274: g698 */
t3=t2;
f_4709(t3,((C_word*)t0)[8],t1);}
else{
/* expand.scm:298: expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4486(t2,((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}}

/* k10749 in k10746 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_10751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_length(((C_word*)t0)[2]);
t4=C_eqp(t3,C_fix(3));
if(C_truep(t4)){
t5=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1221: c */
t6=((C_word*)t0)[5];
((C_proc4)C_fast_retrieve_proc(t6))(4,t6,t2,((C_word*)t0)[6],t5);}
else{
t5=t2;
f_10757(2,t5,C_SCHEME_FALSE);}}

/* k10755 in k10749 in k10746 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_ccall f_10757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10757,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,t2,((C_word*)t0)[4]));}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[98],t2));}}

/* k9781 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_9783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1400: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[262],C_SCHEME_END_OF_LIST,t1);}

/* a9784 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_9785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9785,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,3,lf[261],t5,C_SCHEME_FALSE));}

/* k6932 in k6918 in err in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:704: string-append */
t2=*((C_word*)lf[36]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[2],lf[141],((C_word*)t0)[3],lf[142],t1,lf[143],((C_word*)t0)[4]);}

/* a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_ccall f_9798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9798,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9805,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1352: r */
t8=t3;
((C_proc3)C_fast_retrieve_proc(t8))(3,t8,t7,lf[218]);}

/* k9794 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_ccall f_9796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1346: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[263],C_SCHEME_END_OF_LIST,t1);}

/* k6925 in k6918 in err in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:702: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k6918 in err in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6920,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6934,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:704: symbol->string */
t5=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6941,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:705: symbol->string */
t5=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}

/* k7787 in mirror-rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7789,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7793,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:866: mirror-rename */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7775(t6,t3,t5);}

/* f_9241 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_9241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9241,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_cdr(t3);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cadr(t2);
/* synrules.scm:296: ellipsis? */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t1,t5);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k9760 in k9752 in a9745 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_ccall f_9762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9762,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,((C_word*)t0)[4],t3));}

/* a9771 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_9772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9772,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,3,lf[261],t5,C_SCHEME_TRUE));}

/* k9768 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_9770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1408: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[260],C_SCHEME_END_OF_LIST,t1);}

/* expand in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_fcall f_9962(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9962,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_check_list_2(((C_word*)t0)[2],lf[16]);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9984,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9986,a[2]=t7,a[3]=t11,a[4]=t5,a[5]=((C_word)li140),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_9986(t13,t9,((C_word*)t0)[2]);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
if(C_truep(C_i_pairp(t5))){
t8=C_i_car(t5);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10050,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t9,tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1392: c */
t11=((C_word*)t0)[5];
((C_proc4)C_fast_retrieve_proc(t11))(4,t11,t10,t9,((C_word*)t0)[6]);}
else{
/* expand.scm:1390: err */
t8=((C_word*)((C_word*)t0)[7])[1];
f_9816(t8,t1,t5);}}
else{
/* expand.scm:1385: err */
t4=((C_word*)((C_word*)t0)[7])[1];
f_9816(t4,t1,t2);}}}

/* map-loop2026 in k10746 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_fcall f_10850(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10850,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_10833(C_a_i(&a,15),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[5])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9742 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_9744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1416: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[259],C_SCHEME_END_OF_LIST,t1);}

/* a9745 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_9746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9746,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9754,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1421: r */
t6=t3;
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,lf[242]);}

/* k9218 */
static void C_ccall f_9220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
/* synrules.scm:288: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[213],((C_word*)t0)[4]);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
/* synrules.scm:290: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[214],((C_word*)t0)[4]);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5882 in map-loop1016 in k5844 in k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5884,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=t4;
f_5864(t5,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t3));}
else{
t5=C_mutate2(((C_word *)((C_word*)t0)[7])+1,t3);
t6=t4;
f_5864(t6,t5);}}

/* k7477 in g1457 in rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7479,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* k9752 in a9745 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_9754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9754,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1421: r */
t4=((C_word*)t0)[4];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[260]);}

/* k9944 in k9937 in k9895 in k9857 in test in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in ... */
static void C_ccall f_9946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_not(t1));}

/* g2032 in k10746 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static C_word C_fcall f_10833(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
t2=C_a_i_list(&a,2,lf[207],t1);
return(C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t2));}

/* f_8855 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_8855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8855,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_symbolp(t2))){
t5=C_i_assq(t2,t4);
if(C_truep(t5)){
t6=C_i_cdr(t5);
t7=t3;
if(C_truep(C_fixnum_less_or_equal_p(t6,t7))){
t8=t2;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
/* synrules.scm:207: ##sys#syntax-error-hook */
t8=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[210],t2);}}
else{
t6=C_a_i_list(&a,2,lf[206],t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t6));}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8894,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
/* synrules.scm:210: segment-template? */
t6=((C_word*)((C_word*)t0)[12])[1];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,t2);}}

/* f_8341 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_8341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8341,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8348,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_cdr(t4);
if(C_truep(C_i_pairp(t5))){
t6=C_i_cddr(t2);
t7=t3;
f_8348(t7,C_i_nullp(t6));}
else{
t6=t3;
f_8348(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8348(t4,C_SCHEME_FALSE);}}

/* k5862 in k5882 in map-loop1016 in k5844 in k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_5851(t5,((C_word*)t0)[7],t3,t4);}

/* k6820 in k6816 in loop in k6768 in k6765 in k6762 in k6759 in k6756 in k6753 in k6744 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:669: string-append */
t2=*((C_word*)lf[36]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[128],((C_word*)t0)[3],lf[129],t1);}

/* k8346 */
static void C_fcall f_8348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8348,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdar(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* synrules.scm:120: process-match */
t7=((C_word*)((C_word*)t0)[10])[1];
((C_proc5)C_fast_retrieve_proc(t7))(5,t7,t6,((C_word*)((C_word*)t0)[9])[1],t3,C_SCHEME_FALSE);}
else{
/* synrules.scm:127: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[205],((C_word*)t0)[2]);}}

/* k10846 in k10746 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_10848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10848,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10796,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10803,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=C_i_length(((C_word*)t0)[6]);
t7=C_eqp(t6,C_fix(3));
if(C_truep(t7)){
t8=C_i_cadr(((C_word*)t0)[6]);
/* expand.scm:1229: c */
t9=((C_word*)t0)[8];
((C_proc4)C_fast_retrieve_proc(t9))(4,t9,t5,((C_word*)t0)[9],t8);}
else{
t8=t5;
f_10803(2,t8,C_SCHEME_FALSE);}}

/* k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_ccall f_9573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(4)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9736,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1430: r */
t4=((C_word*)t0)[4];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[248]);}
else{
t3=t2;
f_9579(2,t3,C_SCHEME_FALSE);}}

/* k9577 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_9579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9579,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1431: ##sys#strip-syntax */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9659,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9722,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_caddr(((C_word*)t0)[5]);
/* expand.scm:1471: ##sys#strip-syntax */
t5=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* g1457 in rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_7428(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7428,NULL,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=C_i_getprop(t3,lf[176],C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_7446(t6,t4);}
else{
t6=t2;
t7=t5;
f_7446(t7,C_i_getprop(t6,lf[177],C_SCHEME_FALSE));}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:807: macro-alias */
f_3646(t3,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k8847 in k8743 */
static void C_ccall f_8849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8849,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);
/* synrules.scm:195: process-pattern */
t3=((C_word*)((C_word*)t0)[4])[1];
((C_proc6)C_fast_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],t1,t2,((C_word*)t0)[6],C_SCHEME_FALSE);}

/* k11654 in k11651 in k11640 in loop in k11620 in a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11656,2,t0,t1);}
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[100],((C_word*)t0)[4],t2));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[100],((C_word*)t0)[4],lf[342]));}}

/* k11651 in k11640 in loop in k11620 in a11617 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_11653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11670,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11677,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:989: r */
t5=((C_word*)t0)[7];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t4,lf[95]);}

/* k9580 in k9577 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9582,2,t0,t1);}
t2=t1;
t3=C_i_cadr(t2);
t4=t3;
t5=C_i_cadddr(t2);
t6=t5;
if(C_truep(C_i_symbolp(t6))){
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[2],C_fix(4)))){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9603,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9637,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9641,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1452: symbol->string */
t10=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9644,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1458: ##sys#register-module-alias */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[253]+1)))(4,*((C_word*)lf[253]+1),t7,t4,t6);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9647,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1461: ##sys#check-syntax */
t8=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[246],t2,lf[255]);}}

/* k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5843,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:494: reverse */
t4=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* k5844 in k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5851,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word)li56),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5851(t6,t2,((C_word*)t0)[6],t1);}

/* k5847 in k5844 in k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:450: ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k8325 in map-loop2486 */
static void C_ccall f_8327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8327,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8298(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8298(t6,((C_word*)t0)[5],t5);}}

/* map-loop2293 in expand in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_fcall f_9986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9986,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9982 in expand in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_9984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[25]+1),lf[266],t1);}

/* k11204 in k11188 in k11176 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_11206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_caar(((C_word*)t0)[2]);
/* expand.scm:1164: c */
t3=((C_word*)t0)[3];
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t1,t2);}

/* map-loop1016 in k5844 in k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5851(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5851,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5884,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
t9=t6;
t10=t7;
t11=t8;
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=*((C_word*)lf[8]+1);
t17=C_i_check_list_2(t10,lf[16]);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5729,a[2]=t11,a[3]=t9,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5807,a[2]=t15,a[3]=t20,a[4]=t13,a[5]=t16,a[6]=((C_word)li55),tmp=(C_word)a,a+=7,tmp));
t22=((C_word*)t20)[1];
f_5807(t22,t18,t10);}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* for-each-loop381 in k3843 in extend-se in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_3933(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3933,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_i_getprop(t7,lf[7],C_SCHEME_FALSE);
t9=(C_truep(t8)?C_a_i_putprop(&a,3,t6,lf[7],t8):C_a_i_putprop(&a,3,t6,lf[7],t7));
t10=C_slot(t2,C_fix(1));
t11=C_slot(t3,C_fix(1));
t14=t1;
t15=t10;
t16=t11;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4723 in k4711 in g698 in k4703 in k4552 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:297: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4530(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k8892 */
static void C_ccall f_8894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8894,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* synrules.scm:211: segment-depth */
t3=((C_word*)((C_word*)t0)[11])[1];
((C_proc3)C_fast_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_car(t3);
/* synrules.scm:236: process-template */
t5=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_fast_retrieve_proc(t5))(5,t5,t2,t4,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9038,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9042,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:240: vector->list */
t4=*((C_word*)lf[175]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)((C_word*)t0)[14])[1],((C_word*)t0)[4]));}}}}

/* k8479 in k8439 */
static void C_ccall f_8481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8481,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8485,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
/* synrules.scm:142: process-match */
t7=((C_word*)((C_word*)t0)[6])[1];
((C_proc5)C_fast_retrieve_proc(t7))(5,t7,t3,t4,t6,C_SCHEME_FALSE);}

/* k8483 in k8479 in k8439 */
static void C_ccall f_8485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1510: ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k7901 in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:897: mirror-rename */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7775(t2,((C_word*)t0)[3],t1);}

/* k7905 in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:897: handler */
t2=((C_word*)t0)[2];
((C_proc5)C_fast_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[5])[1]);}

/* k8895 in k8892 */
static void C_ccall f_8897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8897,2,t0,t1);}
t2=t1;
t3=C_fixnum_plus(((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t6=C_i_car(((C_word*)t0)[4]);
/* synrules.scm:214: free-meta-variables */
t7=((C_word*)((C_word*)t0)[10])[1];
((C_proc6)C_fast_retrieve_proc(t7))(6,t7,t5,t6,t4,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* ##sys#er-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7912,3,t0,t1,t2);}
/* expand.scm:899: make-er/ir-transformer */
t3=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_TRUE);}

/* ##sys#ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7918,3,t0,t1,t2);}
/* expand.scm:900: make-er/ir-transformer */
t3=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* k4369 in k4358 in copy in k4324 in a4314 in a4308 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4371,2,t0,t1);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[35],t3));}

/* k8475 in k8439 */
static void C_ccall f_8477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8477,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],t3);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,1,t4));}

/* k11188 in k11176 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_11190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11190,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_10974(2,t2,t1);}
else{
t2=C_u_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1164: r */
t4=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[207]);}
else{
t3=((C_word*)t0)[2];
f_10974(2,t3,C_SCHEME_FALSE);}}}

/* k10801 in k10846 in k10746 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_ccall f_10803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10803,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10796(t3,C_a_i_list(&a,2,t2,((C_word*)t0)[4]));}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10796(t3,C_a_i_cons(&a,2,lf[98],t2));}}

/* map-loop953 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5949(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5949,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,1,lf[101]);
t5=C_a_i_list(&a,2,t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10798 in k10794 in k10846 in k10746 in k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_10800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10800,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,4,lf[291],((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k9517 in k9514 in k9511 in a9508 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in ... */
static void C_ccall f_9519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[238]);}

/* k9514 in k9511 in a9508 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* expand.scm:1504: ##sys#add-to-export-list */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[239]+1)))(4,*((C_word*)lf[239]+1),t2,t1,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[238]);}}

/* k9511 in a9508 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9513,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9516,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1502: ##sys#current-module */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[240]+1)))(2,*((C_word*)lf[240]+1),t3);}

/* f_9285 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_9285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9285,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9295,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li123),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9295(t7,t1,t3);}

/* k5634 in k5626 in k5615 in loop in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5636,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* expand.scm:475: ##sys#append */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],t2);}

/* k9524 in a9508 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1499: ##sys#validate-exports */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[241]+1)))(4,*((C_word*)lf[241]+1),((C_word*)t0)[2],t1,lf[237]);}

/* k11176 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_ccall f_11178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11178,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_10974(2,t2,t1);}
else{
t2=C_u_i_car(((C_word*)t0)[3]);
t3=C_i_vectorp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
f_10974(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=C_u_i_car(((C_word*)t0)[3]);
/* expand.scm:1162: ##sys#srfi-4-vector? */
t6=*((C_word*)lf[309]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}}

/* k9209 in k9164 */
static void C_ccall f_9211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:281: free-meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_fast_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* f_9213 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_9213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9213,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9220,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:285: segment-template? */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t4,t2);}

/* copy in k4324 in a4314 in a4308 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4343(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4343,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
t4=t2;
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4360,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_equalp(lf[39],t3))){
if(C_truep(C_i_pairp(t5))){
t7=C_u_i_car(t5);
t8=t6;
f_4360(t8,C_i_stringp(t7));}
else{
t7=t6;
f_4360(t7,C_SCHEME_FALSE);}}
else{
t7=t6;
f_4360(t7,C_SCHEME_FALSE);}}}

/* k4193 in copy-macro in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_3629(((C_word*)t0)[2],t1);
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[27]+1),((C_word*)t0)[4],t2);}

/* ##sys#macro? in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4197r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4197r(t0,t1,t2,t3);}}

static void C_ccall f_4197r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4201,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* expand.scm:183: ##sys#current-environment */
t5=*((C_word*)lf[1]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t4;
f_4201(2,t5,C_i_car(t3));}}

/* k9105 in k9071 */
static void C_ccall f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:255: meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_fast_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1,C_SCHEME_FALSE);}

/* f_9265 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_9265(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9265,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9272,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:301: segment-template? */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4335 in k4324 in a4314 in a4308 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4337,2,t0,t1);}
t2=C_a_i_record3(&a,3,lf[33],((C_word*)t0)[2],t1);
/* expand.scm:210: ##sys#abort */
t3=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}

/* k9270 */
static void C_ccall f_9272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9272,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9279,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* synrules.scm:302: segment-depth */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* k9277 in k9270 */
static void C_ccall f_9279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fixnum_plus(C_fix(1),t1));}

/* k9071 */
static void C_ccall f_9073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9073,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9088,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_cddr(((C_word*)t0)[2]);
/* synrules.scm:253: meta-variables */
t8=((C_word*)((C_word*)t0)[4])[1];
((C_proc6)C_fast_retrieve_proc(t8))(6,t8,t6,t7,((C_word*)t0)[3],((C_word*)t0)[6],C_SCHEME_TRUE);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9107,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* synrules.scm:256: meta-variables */
t7=((C_word*)((C_word*)t0)[4])[1];
((C_proc6)C_fast_retrieve_proc(t7))(6,t7,t4,t6,((C_word*)t0)[3],((C_word*)t0)[6],C_SCHEME_FALSE);}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:258: vector->list */
t3=*((C_word*)lf[175]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}}}

/* k4172 in k4147 in k4144 in extend-macro-environment in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k9562 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_9564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1423: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[246],C_SCHEME_END_OF_LIST,t1);}

/* a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_9566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9566,5,t0,t1,t2,t3,t4);}
t5=C_i_length(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9573,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1429: ##sys#check-syntax */
t8=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[246],t2,lf[258]);}

/* k8382 in k8346 */
static void C_ccall f_8384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8384,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8379,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp);
/* synrules.scm:121: process-pattern */
t6=((C_word*)((C_word*)t0)[9])[1];
((C_proc6)C_fast_retrieve_proc(t6))(6,t6,t4,((C_word*)t0)[8],((C_word*)((C_word*)t0)[10])[1],t5,C_SCHEME_FALSE);}

/* ##sys#copy-macro in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4184,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4195,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:180: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a9535 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_ccall f_9536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9536,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9540,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1489: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[242],t2,lf[245]);}

/* f_8407 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_8407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8407,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_symbolp(t3))){
if(C_truep(C_i_memq(t3,((C_word*)t0)[2]))){
t5=C_a_i_list(&a,2,lf[206],t3);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],t2,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,1,t7));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}
else{
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8441,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* synrules.scm:136: segment-pattern? */
t6=((C_word*)((C_word*)t0)[17])[1];
((C_proc4)C_fast_retrieve_proc(t6))(4,t6,t5,t3,t4);}}

/* k9532 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_ccall f_9534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1484: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[242],C_SCHEME_END_OF_LIST,t1);}

/* k8371 in k8367 in k8382 in k8346 */
static void C_ccall f_8373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8373,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,((C_word*)t0)[5],t2));}

/* k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in ... */
static void C_ccall f_8191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8191,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[2],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:85: r */
t4=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[221]);}

/* a8378 in k8382 in k8346 */
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8379,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8375 in k8367 in k8382 in k8346 */
static void C_ccall f_8377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:124: process-template */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc5)C_fast_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],C_fix(0),t1);}

/* k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in ... */
static void C_ccall f_8199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8199,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[2],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:87: r */
t4=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[55]);}

/* k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in ... */
static void C_ccall f_8195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8195,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[2],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:86: r */
t4=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[220]);}

/* k9541 in k9538 in a9535 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9543,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,lf[98],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,2,lf[243],t4));}

/* k9538 in a9535 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_9540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,lf[98],t3);
/* expand.scm:1490: ##sys#register-meta-expression */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[244]+1)))(3,*((C_word*)lf[244]+1),t2,t4);}

/* ##sys#mark-primitive in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7926(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7926,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[14]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7948,a[2]=t5,a[3]=((C_word)li103),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7948(t7,t1,t2);}

/* k8367 in k8382 in k8346 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8369,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8373,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8377,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:126: meta-variables */
t5=((C_word*)((C_word*)t0)[7])[1];
((C_proc6)C_fast_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[8],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* a10108 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in ... */
static void C_ccall f_10109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10109,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10113,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1333: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[272],t2,lf[274]);}

/* k10105 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in ... */
static void C_ccall f_10107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1328: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[272],C_SCHEME_END_OF_LIST,t1);}

/* k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in ... */
static void C_ccall f_8172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8172,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[2],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:78: r */
t4=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[225]);}

/* k9937 in k9895 in k9857 in test in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9939,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9946,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* expand.scm:1378: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9826(t4,t2,t3);}
else{
/* expand.scm:1379: err */
t2=((C_word*)((C_word*)t0)[5])[1];
f_9816(t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k8439 */
static void C_ccall f_8441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8441,2,t0,t1);}
if(C_truep(t1)){
/* synrules.scm:137: process-segment-match */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_fast_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t2=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8477,a[2]=t6,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t4,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8481,a[2]=t7,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t9=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[12])[1],((C_word*)((C_word*)t0)[6])[1]);
t10=((C_word*)t0)[5];
t11=C_u_i_car(t10);
/* synrules.scm:141: process-match */
t12=((C_word*)((C_word*)t0)[11])[1];
((C_proc5)C_fast_retrieve_proc(t12))(5,t12,t8,t9,t11,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[5]))){
t2=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[13])[1],((C_word*)((C_word*)t0)[6])[1]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8534,a[2]=t6,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t4,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[14])[1],((C_word*)((C_word*)t0)[6])[1]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8542,a[2]=((C_word*)t0)[11],a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:147: vector->list */
t11=*((C_word*)lf[175]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,((C_word*)t0)[5]);}
else{
t2=C_i_nullp(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8555,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8555(t4,t2);}
else{
t4=C_booleanp(((C_word*)t0)[5]);
t5=t3;
f_8555(t5,(C_truep(t4)?t4:C_charp(((C_word*)t0)[5])));}}}}}

/* k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in ... */
static void C_ccall f_8176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8176,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[198]);
t4=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8181,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=((C_word*)t0)[22],a[21]=((C_word*)t0)[23],a[22]=((C_word*)t0)[24],a[23]=((C_word*)t0)[25],a[24]=((C_word*)t0)[26],a[25]=((C_word*)t0)[27],a[26]=((C_word*)t0)[2],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[44],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[3],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:80: r */
t5=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t4,lf[224]);}

/* k10111 in a10108 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in ... */
static void C_ccall f_10113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1334: r */
t3=((C_word*)t0)[4];
((C_proc3)C_fast_retrieve_proc(t3))(3,t3,t2,lf[269]);}

/* k10623 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in ... */
static void C_ccall f_10625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1234: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[88],C_SCHEME_END_OF_LIST,t1);}

/* a10626 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in ... */
static void C_ccall f_10627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10627,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10631,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1239: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[88],t2,lf[295]);}

/* k9910 in k9895 in k9857 in test in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9912,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_u_i_cdr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
/* expand.scm:1376: test */
t4=((C_word*)((C_word*)t0)[5])[1];
f_9826(t4,((C_word*)t0)[2],t3);}}

/* k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in ... */
static void C_ccall f_8109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8112,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10625,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10627,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1237: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in ... */
static void C_ccall f_8103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8106,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10899,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10901,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1135: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in ... */
static void C_ccall f_8106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8109,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10676,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10678,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1195: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4530(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4530,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
t5=t2;
t6=C_u_i_cdr(t5);
if(C_truep(C_i_symbolp(t4))){
t7=f_3629(t4,((C_word*)t0)[2]);
t8=(C_truep(t7)?t7:t4);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4554,a[2]=t10,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_pairp(((C_word*)t10)[1]))){
t12=t11;
f_4554(t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4768,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:273: ##sys#macro-environment */
t13=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}
else{
/* expand.scm:299: values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* expand.scm:300: values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in ... */
static void C_ccall f_8100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11240,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11242,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1119: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4940,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[8]))){
t4=t3;
f_4944(t4,((C_word*)t0)[10]);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5081,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5141,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t3,a[5]=t7,a[6]=t5,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* expand.scm:369: reverse */
t10=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,((C_word*)t0)[8]);}}

/* k4942 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4944,NULL,2,t0,t1);}
t2=t1;
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
/* expand.scm:356: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[4],t2);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t4)){
t5=t3;
f_4956(t5,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[9]))){
t5=C_i_cdr(((C_word*)t0)[2]);
t6=t3;
f_4956(t6,C_i_nullp(t5));}
else{
t5=t3;
f_4956(t5,C_SCHEME_FALSE);}}}}

/* test in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_fcall f_9826(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9826,NULL,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9840,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1361: ##sys#strip-syntax */
t4=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9859,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* expand.scm:1366: c */
t8=((C_word*)t0)[6];
((C_proc4)C_fast_retrieve_proc(t8))(4,t8,t7,((C_word*)t0)[2],t4);}
else{
/* expand.scm:1362: err */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9816(t3,t1,t2);}}}

/* k5996 in fini/syntax in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:499: fini */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5586(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],t1);}

/* k4561 in k4552 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4575,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:278: ##sys#check-syntax */
t5=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t4,lf[55],((C_word*)t0)[2],lf[56],C_SCHEME_FALSE,((C_word*)t0)[4]);}
else{
/* expand.scm:289: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[5],C_SCHEME_FALSE);}}

/* k9040 in k8892 */
static void C_ccall f_9042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:240: process-template */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc5)C_fast_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* f_9047 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_9047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9047,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_symbolp(t2))){
if(C_truep(C_i_memq(t2,((C_word*)t0)[2]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}
else{
t6=C_a_i_cons(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,t6,t4));}}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9073,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* synrules.scm:251: segment-pattern? */
t7=((C_word*)((C_word*)t0)[4])[1];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t6,t2,t5);}}

/* k9019 in k9015 in k8892 */
static void C_ccall f_9021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9021,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],t1));}

/* k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[78],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4101,2,t0,t1);}
t2=C_mutate2((C_word*)lf[19]+1 /* (set! ##sys#macro-environment ...) */,t1);
t3=C_set_block_item(lf[20] /* ##sys#chicken-macro-environment */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[21] /* ##sys#chicken-ffi-macro-environment */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate2((C_word*)lf[22]+1 /* (set! ##sys#ensure-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4105,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[27]+1 /* (set! ##sys#extend-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4142,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[28]+1 /* (set! ##sys#copy-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4184,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[29]+1 /* (set! ##sys#macro? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4197,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[30]+1 /* (set! ##sys#unregister-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4234,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[31]+1 /* (set! ##sys#undefine-macro! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4279,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[32]+1 /* (set! ##sys#expand-0 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4285,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t12=C_set_block_item(lf[58] /* ##sys#compiler-syntax-hook */,0,C_SCHEME_FALSE);
t13=C_set_block_item(lf[60] /* ##sys#enable-runtime-macros */,0,C_SCHEME_FALSE);
t14=C_mutate2((C_word*)lf[61]+1 /* (set! ##sys#expand ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4778,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[62]+1 /* (set! expand ...) */,*((C_word*)lf[61]+1));
t16=C_mutate2((C_word*)lf[63]+1 /* (set! ##sys#extended-lambda-list? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4845,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[67]+1 /* (set! ##sys#expand-extended-lambda-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4892,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[89]+1 /* (set! ##sys#defjam-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5496,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(lf[91] /* ##sys#define-definition */,0,C_SCHEME_UNDEFINED);
t20=C_set_block_item(lf[92] /* ##sys#define-syntax-definition */,0,C_SCHEME_UNDEFINED);
t21=C_set_block_item(lf[93] /* ##sys#define-values-definition */,0,C_SCHEME_UNDEFINED);
t22=C_mutate2((C_word*)lf[94]+1 /* (set! ##sys#canonicalize-body ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5505,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2(&lf[112] /* (set! match-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6475,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate2((C_word*)lf[104]+1 /* (set! ##sys#expand-curried-define ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6557,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(lf[113] /* ##sys#line-number-database */,0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[114] /* ##sys#syntax-error-culprit */,0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[115] /* ##sys#syntax-context */,0,C_SCHEME_END_OF_LIST);
t28=C_mutate2((C_word*)lf[41]+1 /* (set! ##sys#syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6612,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate2((C_word*)lf[118]+1 /* (set! ##sys#syntax-error/context ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6622,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate2((C_word*)lf[137]+1 /* (set! syntax-error ...) */,*((C_word*)lf[41]+1));
t31=C_mutate2((C_word*)lf[45]+1 /* (set! ##sys#syntax-rules-mismatch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6844,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate2((C_word*)lf[139]+1 /* (set! get-line-number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6850,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate2((C_word*)lf[54]+1 /* (set! ##sys#check-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6889,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate2((C_word*)lf[173]+1 /* (set! make-er/ir-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7344,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate2((C_word*)lf[23]+1 /* (set! ##sys#er-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7912,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate2((C_word*)lf[179]+1 /* (set! ##sys#ir-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7918,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate2((C_word*)lf[180]+1 /* (set! er-macro-transformer ...) */,*((C_word*)lf[23]+1));
t38=C_mutate2((C_word*)lf[181]+1 /* (set! ir-macro-transformer ...) */,*((C_word*)lf[179]+1));
t39=C_mutate2((C_word*)lf[182]+1 /* (set! ##sys#mark-primitive ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7926,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7972,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t41=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11840,a[2]=t40,tmp=(C_word)a,a+=3,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11842,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:915: ##sys#er-transformer */
t43=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t43+1)))(3,t43,t41,t42);}

/* fini/syntax in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5990(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5990,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5998,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6000,a[2]=t9,a[3]=((C_word*)t0)[3],a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_6000(t11,t7,t6,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* ##sys#ensure-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_4105r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4105r(t0,t1,t2,t3);}}

static void C_ccall f_4105r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
if(C_truep(C_i_closurep(t2))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4122,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:161: ##sys#er-transformer */
t7=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep(C_i_structurep(t2,lf[24]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_slot(t2,C_fix(1)));}
else{
/* expand.scm:163: ##sys#error */
t6=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,lf[26],t2);}}}

/* k4552 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4554(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4554,NULL,2,t0,t1);}
t2=C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[50]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:275: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t3,lf[55],((C_word*)t0)[3],lf[57],C_SCHEME_FALSE,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4705,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[11])){
if(C_truep(C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t4=((C_word*)((C_word*)t0)[2])[1];
t5=t3;
f_4705(t5,C_i_getprop(t4,lf[59],C_SCHEME_FALSE));}
else{
t4=t3;
f_4705(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4705(t4,C_SCHEME_FALSE);}}}

/* g509 in k4147 in k4144 in extend-macro-environment in k4099 in k3625 in k3621 in k3617 in k3613 */
static C_word C_fcall f_4156(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
t2=C_i_set_car(t1,((C_word*)t0)[2]);
t3=t1;
t4=C_u_i_cdr(t3);
t5=C_i_set_car(t4,((C_word*)t0)[3]);
return(t1);}

/* proper-list? in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7005,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7011,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_7011(t2));}

/* k7001 in loop in k6945 in lambda-list? in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* expand.scm:716: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_6955(t4,((C_word*)t0)[2],t3);}}

/* k4954 in k4942 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4956,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caar(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm:374: cadar */
t5=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:C_i_nullp(((C_word*)t0)[10]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:378: reverse */
t5=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5031,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5035,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:381: reverse */
t6=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}}

/* k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_ccall f_8142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8145,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9507,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9509,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1496: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_8145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8148,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9471,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9473,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp);
/* synrules.scm:47: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* loop in proper-list? in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static C_word C_fcall f_7011(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:
t2=C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep(C_i_pairp(t1))){
t3=t1;
t4=C_u_i_cdr(t3);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_8148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8148,2,t0,t1);}
t2=C_mutate2((C_word*)lf[188]+1 /* (set! ##sys#process-syntax-rules ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8150,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2((C_word*)lf[228]+1 /* (set! ##sys#macro-subset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9322,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[229]+1 /* (set! ##sys#fixup-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9372,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9455,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9467,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1536: ##sys#macro-environment */
t7=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k9036 in k8892 */
static void C_ccall f_9038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9038,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t1));}

/* k9086 in k9071 */
static void C_ccall f_9088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:252: meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_fast_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1,C_SCHEME_FALSE);}

/* k4147 in k4144 in extend-macro-environment in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4149,2,t0,t1);}
t2=t1;
t3=f_3629(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4156,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:165: g509 */
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4156(t4,t3));}
else{
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
/* expand.scm:175: ##sys#macro-environment */
t9=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t6,t8);}}

/* k4144 in extend-macro-environment in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4146,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4149,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:167: ##sys#ensure-transformer */
t4=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* ##sys#extend-macro-environment in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4142,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4146,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:166: ##sys#macro-environment */
t6=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k10253 in k10232 in k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_10255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10255,2,t0,t1);}
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10264,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1303: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[278],((C_word*)t0)[3],lf[279]);}
else{
t3=C_a_i_list(&a,2,lf[71],((C_word*)t0)[7]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10294,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t6=C_i_cdr(((C_word*)t0)[3]);
t7=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
/* expand.scm:1308: walk */
t8=((C_word*)((C_word*)t0)[5])[1];
f_10154(t8,t5,t6,t7);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10309,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1311: walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10154(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in ... */
static void C_ccall f_8121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10086,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10088,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1341: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in ... */
static void C_ccall f_8124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9796,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9798,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1349: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* map-loop2091 in k10449 in k10437 in a10434 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in ... */
static void C_fcall f_10588(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10588,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_u_i_cdr(t3);
t6=C_i_car(t5);
t7=C_a_i_list2(&a,2,t4,t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t9=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t8);
t10=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t8);
t11=C_slot(t2,C_fix(1));
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}
else{
t9=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t8);
t10=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t8);
t11=C_slot(t2,C_fix(1));
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9783,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9785,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1403: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k10222 in k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_10224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10224,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list3(&a,3,lf[198],((C_word*)t0)[3],t1));}

/* ##sys#process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_8150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word ab[143],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_8150,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_SCHEME_UNDEFINED;
t42=(*a=C_VECTOR_TYPE|1,a[1]=t41,tmp=(C_word)a,a+=2,tmp);
t43=C_SCHEME_UNDEFINED;
t44=(*a=C_VECTOR_TYPE|1,a[1]=t43,tmp=(C_word)a,a+=2,tmp);
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_SCHEME_UNDEFINED;
t56=(*a=C_VECTOR_TYPE|1,a[1]=t55,tmp=(C_word)a,a+=2,tmp);
t57=C_SCHEME_UNDEFINED;
t58=(*a=C_VECTOR_TYPE|1,a[1]=t57,tmp=(C_word)a,a+=2,tmp);
t59=C_SCHEME_UNDEFINED;
t60=(*a=C_VECTOR_TYPE|1,a[1]=t59,tmp=(C_word)a,a+=2,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_SCHEME_UNDEFINED;
t64=(*a=C_VECTOR_TYPE|1,a[1]=t63,tmp=(C_word)a,a+=2,tmp);
t65=C_SCHEME_UNDEFINED;
t66=(*a=C_VECTOR_TYPE|1,a[1]=t65,tmp=(C_word)a,a+=2,tmp);
t67=C_SCHEME_UNDEFINED;
t68=(*a=C_VECTOR_TYPE|1,a[1]=t67,tmp=(C_word)a,a+=2,tmp);
t69=C_SCHEME_UNDEFINED;
t70=(*a=C_VECTOR_TYPE|1,a[1]=t69,tmp=(C_word)a,a+=2,tmp);
t71=C_SCHEME_UNDEFINED;
t72=(*a=C_VECTOR_TYPE|1,a[1]=t71,tmp=(C_word)a,a+=2,tmp);
t73=C_SCHEME_UNDEFINED;
t74=(*a=C_VECTOR_TYPE|1,a[1]=t73,tmp=(C_word)a,a+=2,tmp);
t75=C_SCHEME_UNDEFINED;
t76=(*a=C_VECTOR_TYPE|1,a[1]=t75,tmp=(C_word)a,a+=2,tmp);
t77=C_SCHEME_UNDEFINED;
t78=(*a=C_VECTOR_TYPE|1,a[1]=t77,tmp=(C_word)a,a+=2,tmp);
t79=C_SCHEME_UNDEFINED;
t80=(*a=C_VECTOR_TYPE|1,a[1]=t79,tmp=(C_word)a,a+=2,tmp);
t81=C_SCHEME_UNDEFINED;
t82=(*a=C_VECTOR_TYPE|1,a[1]=t81,tmp=(C_word)a,a+=2,tmp);
t83=C_SCHEME_UNDEFINED;
t84=(*a=C_VECTOR_TYPE|1,a[1]=t83,tmp=(C_word)a,a+=2,tmp);
t85=C_SCHEME_UNDEFINED;
t86=(*a=C_VECTOR_TYPE|1,a[1]=t85,tmp=(C_word)a,a+=2,tmp);
t87=C_SCHEME_UNDEFINED;
t88=(*a=C_VECTOR_TYPE|1,a[1]=t87,tmp=(C_word)a,a+=2,tmp);
t89=C_SCHEME_UNDEFINED;
t90=(*a=C_VECTOR_TYPE|1,a[1]=t89,tmp=(C_word)a,a+=2,tmp);
t91=C_SCHEME_UNDEFINED;
t92=(*a=C_VECTOR_TYPE|1,a[1]=t91,tmp=(C_word)a,a+=2,tmp);
t93=C_SCHEME_UNDEFINED;
t94=(*a=C_VECTOR_TYPE|1,a[1]=t93,tmp=(C_word)a,a+=2,tmp);
t95=C_SCHEME_UNDEFINED;
t96=(*a=C_VECTOR_TYPE|1,a[1]=t95,tmp=(C_word)a,a+=2,tmp);
t97=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8157,a[2]=t8,a[3]=t10,a[4]=t12,a[5]=t14,a[6]=t16,a[7]=t18,a[8]=t20,a[9]=t22,a[10]=t24,a[11]=t26,a[12]=t28,a[13]=t30,a[14]=t32,a[15]=t34,a[16]=t36,a[17]=t38,a[18]=t40,a[19]=t42,a[20]=t44,a[21]=t46,a[22]=t48,a[23]=t50,a[24]=t52,a[25]=t54,a[26]=t56,a[27]=t58,a[28]=t60,a[29]=t62,a[30]=t64,a[31]=t66,a[32]=t68,a[33]=t70,a[34]=t72,a[35]=t6,a[36]=t74,a[37]=t76,a[38]=t84,a[39]=t86,a[40]=t82,a[41]=t78,a[42]=t4,a[43]=t80,a[44]=t90,a[45]=t96,a[46]=t88,a[47]=t94,a[48]=t92,a[49]=t1,a[50]=t3,a[51]=t5,a[52]=t2,tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:65: r */
t98=t5;
((C_proc3)C_fast_retrieve_proc(t98))(3,t98,t97,lf[227]);}

/* k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in ... */
static void C_ccall f_8157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8157,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[189]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,lf[190]);
t5=C_mutate2(((C_word *)((C_word*)t0)[5])+1,lf[191]);
t6=C_mutate2(((C_word *)((C_word*)t0)[6])+1,lf[192]);
t7=C_mutate2(((C_word *)((C_word*)t0)[7])+1,lf[193]);
t8=C_mutate2(((C_word *)((C_word*)t0)[8])+1,lf[194]);
t9=C_mutate2(((C_word *)((C_word*)t0)[9])+1,lf[195]);
t10=C_mutate2(((C_word *)((C_word*)t0)[10])+1,lf[196]);
t11=C_mutate2(((C_word *)((C_word*)t0)[11])+1,lf[197]);
t12=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8172,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[18],a[9]=((C_word*)t0)[19],a[10]=((C_word*)t0)[20],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[22],a[13]=((C_word*)t0)[23],a[14]=((C_word*)t0)[24],a[15]=((C_word*)t0)[25],a[16]=((C_word*)t0)[26],a[17]=((C_word*)t0)[27],a[18]=((C_word*)t0)[28],a[19]=((C_word*)t0)[29],a[20]=((C_word*)t0)[30],a[21]=((C_word*)t0)[31],a[22]=((C_word*)t0)[32],a[23]=((C_word*)t0)[33],a[24]=((C_word*)t0)[34],a[25]=((C_word*)t0)[35],a[26]=((C_word*)t0)[36],a[27]=((C_word*)t0)[4],a[28]=((C_word*)t0)[37],a[29]=((C_word*)t0)[2],a[30]=((C_word*)t0)[38],a[31]=((C_word*)t0)[39],a[32]=((C_word*)t0)[40],a[33]=((C_word*)t0)[41],a[34]=((C_word*)t0)[42],a[35]=((C_word*)t0)[43],a[36]=((C_word*)t0)[3],a[37]=((C_word*)t0)[6],a[38]=((C_word*)t0)[7],a[39]=((C_word*)t0)[44],a[40]=((C_word*)t0)[5],a[41]=((C_word*)t0)[9],a[42]=((C_word*)t0)[10],a[43]=((C_word*)t0)[11],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[47],a[47]=((C_word*)t0)[8],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:77: r */
t13=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t13))(3,t13,t12,lf[226]);}

/* k4120 in ensure-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(t1,C_fix(1)));}

/* k10232 in k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_10234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10234,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list(&a,2,lf[71],((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10245,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* expand.scm:1300: walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_10154(t6,t4,((C_word*)t0)[6],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10255,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[7]))){
t3=C_u_i_car(((C_word*)t0)[7]);
/* expand.scm:1301: c */
t4=((C_word*)t0)[9];
((C_proc4)C_fast_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[8],t3);}
else{
t3=t2;
f_10255(2,t3,C_SCHEME_FALSE);}}}

/* k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in ... */
static void C_ccall f_8181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8181,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[199]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,lf[200]);
t5=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8187,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[2],a[26]=((C_word*)t0)[28],a[27]=((C_word*)t0)[29],a[28]=((C_word*)t0)[30],a[29]=((C_word*)t0)[31],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[33],a[32]=((C_word*)t0)[34],a[33]=((C_word*)t0)[35],a[34]=((C_word*)t0)[36],a[35]=((C_word*)t0)[37],a[36]=((C_word*)t0)[3],a[37]=((C_word*)t0)[4],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:83: r */
t6=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,lf[223]);}

/* k4358 in copy in k4324 in a4314 in a4308 in a4302 in call-handler in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4360,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_i_car(((C_word*)t0)[2]);
/* expand.scm:226: string-append */
t5=*((C_word*)lf[36]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,lf[37],t3,lf[38],t4);}
else{
/* expand.scm:232: copy */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4343(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in ... */
static void C_ccall f_8187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8187,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8191,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[2],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:84: r */
t4=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[222]);}

/* k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_8130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9770,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9772,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1411: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k10533 in k10495 in k10474 in k10449 in k10437 in a10434 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_10535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10535,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[53],t2);
t4=C_a_i_list(&a,3,lf[98],((C_word*)t0)[3],t3);
t5=C_a_i_list(&a,4,lf[291],((C_word*)t0)[4],((C_word*)t0)[5],t4);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,4,lf[50],((C_word*)t0)[2],((C_word*)t0)[7],t5));}

/* k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9744,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9746,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1419: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in ... */
static void C_ccall f_10693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10693,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm:1202: r */
t4=((C_word*)t0)[7];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[302]);}

/* k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in ... */
static void C_ccall f_10690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10690,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10693,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1201: r */
t4=((C_word*)t0)[6];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[218]);}

/* map-loop2125 in k10495 in k10474 in k10449 in k10437 in a10434 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_fcall f_10537(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10537,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10566,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_cdr(t4);
t6=C_i_cdr(t5);
t7=C_eqp(t6,C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=C_u_i_car(t4);
t9=t3;
f_10566(t9,t8);}
else{
t8=C_u_i_cdr(t4);
t9=C_i_cdr(t8);
t10=t3;
f_10566(t10,C_i_car(t9));}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in ... */
static void C_ccall f_10696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10696,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:1203: r */
t4=((C_word*)t0)[8];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[301]);}

/* k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in ... */
static void C_ccall f_10699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10699,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:1204: r */
t4=((C_word*)t0)[9];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[224]);}

/* k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_8139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8142,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9534,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9536,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1487: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_8136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9564,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9566,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1426: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k10292 in k10253 in k10232 in k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_ccall f_10294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10294,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[198],((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10286,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1309: walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10154(t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k10262 in k10253 in k10232 in k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_ccall f_10264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10264,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10275,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1304: walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10154(t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k10674 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in ... */
static void C_ccall f_10676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1192: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[296],C_SCHEME_END_OF_LIST,t1);}

/* a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in ... */
static void C_ccall f_10678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10678,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10682,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1197: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[296],t2,lf[303]);}

/* k6530 in mwalk in match-expression in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:597: mwalk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6478(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10273 in k10262 in k10253 in k10232 in k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_10275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10275,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[70],((C_word*)t0)[3],t1));}

/* k4766 in loop in expand-0 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=f_3629(((C_word*)((C_word*)t0)[2])[1],t1);
if(C_truep(t2)){
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
f_4554(t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t3);
t5=((C_word*)t0)[3];
f_4554(t5,t4);}}

/* k10048 in expand in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_10050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10050,2,t0,t1);}
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_eqp(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?lf[267]:C_a_i_cons(&a,2,lf[98],t2)));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1397: test */
t3=((C_word*)((C_word*)t0)[6])[1];
f_9826(t3,t2,((C_word*)t0)[7]);}}

/* k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in ... */
static void C_ccall f_10682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10682,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10690,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1200: r */
t8=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t8))(3,t8,t7,lf[77]);}

/* k10064 in k10048 in expand in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_10066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10066,2,t0,t1);}
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[98],t2));}
else{
/* expand.scm:1398: expand */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9962(t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k10243 in k10232 in k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_10245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10245,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list3(&a,3,lf[198],((C_word*)t0)[3],t1));}

/* loop in k4780 in expand in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4796(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4796,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4802,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[4],a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:309: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* map-loop355 in extend-se in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_3979(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3979,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4008,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:130: g361 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4780 in expand in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4782,2,t0,t1);}
t2=t1;
t3=C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4796,a[2]=t2,a[3]=t7,a[4]=t11,a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_4796(t13,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* err in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in ... */
static void C_fcall f_9816(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9816,NULL,3,t0,t1,t2);}
t3=C_a_i_cons(&a,2,lf[263],((C_word*)t0)[2]);
/* expand.scm:1357: ##sys#error */
t4=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[264],t2,t3);}

/* k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_9814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9814,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9816,a[2]=((C_word*)t0)[2],a[3]=((C_word)li138),tmp=(C_word)a,a+=4,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9826,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li139),tmp=(C_word)a,a+=9,tmp));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9962,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word)li141),tmp=(C_word)a,a+=9,tmp));
t12=((C_word*)t10)[1];
f_9962(t12,((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_9811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9811,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1355: r */
t4=((C_word*)t0)[7];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[227]);}

/* k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_9808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9808,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1354: r */
t4=((C_word*)t0)[6];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[224]);}

/* k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_9805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9805,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9808,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1353: r */
t4=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[268]);}

/* k6283 in loop2 in k6220 in k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cddr(((C_word*)t0)[4]);
/* expand.scm:554: ##sys#expand-curried-define */
t4=*((C_word*)lf[104]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[5],t3,((C_word*)t0)[6]);}

/* k10090 in a10087 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_ccall f_10092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10092,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,lf[270],t3));}

/* k10284 in k10292 in k10253 in k10232 in k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_10286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10286,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[198],((C_word*)t0)[3],t1));}

/* a4801 in loop in k4780 in expand in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4802,2,t0,t1);}
/* expand.scm:311: ##sys#expand-0 */
t2=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a4807 in loop in k4780 in expand in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4808,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* expand.scm:313: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4796(t4,t1,t2);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5314 in k5225 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_fixnum_less_or_equal_p(((C_word*)t0)[2],C_fix(2)))){
/* expand.scm:414: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4926(t2,((C_word*)t0)[4],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[6],C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);}
else{
/* expand.scm:415: err */
t2=((C_word*)t0)[8];
f_4895(t2,((C_word*)t0)[4],lf[80]);}}

/* k10208 in k10199 in walk1 in k10150 in k10147 in k10144 in a10141 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_10210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_car(((C_word*)t0)[3]));}

/* k6290 in k6283 in loop2 in k6220 in k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:553: loop2 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6227(t2,((C_word*)t0)[3],t1);}

/* k5401 in k5225 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5403,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
switch(t2){
case C_fix(0):
/* expand.scm:425: err */
t3=((C_word*)t0)[3];
f_4895(t3,((C_word*)t0)[4],lf[82]);
case C_fix(1):
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* expand.scm:426: loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4926(t4,((C_word*)t0)[4],C_fix(1),((C_word*)t0)[8],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[9]);
case C_fix(2):
/* expand.scm:427: err */
t3=((C_word*)t0)[3];
f_4895(t3,((C_word*)t0)[4],lf[83]);
default:
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[10]);
/* expand.scm:428: loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4926(t4,((C_word*)t0)[4],C_fix(3),((C_word*)t0)[8],((C_word*)t0)[6],t3,((C_word*)t0)[9]);}}
else{
/* expand.scm:429: err */
t2=((C_word*)t0)[3];
f_4895(t2,((C_word*)t0)[4],lf[84]);}}

/* k6297 in loop2 in k6220 in k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6299,2,t0,t1);}
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_u_i_cdr(((C_word*)t0)[2]);
t5=C_i_cddr(((C_word*)t0)[4]);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,lf[72],t6);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[5]);
/* expand.scm:559: loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_6184(t9,((C_word*)t0)[7],((C_word*)t0)[8],t3,t8,((C_word*)t0)[9],((C_word*)t0)[10]);}

/* check-for-multiple-bindings in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_8007(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8007,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8013,a[2]=t6,a[3]=t3,a[4]=t4,a[5]=((C_word)li105),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8013(t8,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_8005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8005,2,t0,t1);}
t2=C_mutate2((C_word*)lf[92]+1 /* (set! ##sys#define-syntax-definition ...) */,t1);
t3=C_mutate2(&lf[184] /* (set! check-for-multiple-bindings ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8007,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8082,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11461,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11463,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1044: ##sys#er-transformer */
t7=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k10084 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in ... */
static void C_ccall f_10086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1338: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[269],C_SCHEME_END_OF_LIST,t1);}

/* a10087 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in ... */
static void C_ccall f_10088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10088,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10092,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1343: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[269],t2,lf[271]);}

/* ##sys#expand in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4778r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4778r(t0,t1,t2,t3);}}

static void C_ccall f_4778r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4782,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
/* expand.scm:309: ##sys#current-environment */
t6=*((C_word*)lf[1]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=t5;
f_4782(2,t6,C_i_car(t4));}}

/* k4985 in k4954 in k4942 in k4938 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4987,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_list(&a,1,t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=C_a_i_list(&a,1,t6);
/* expand.scm:356: values */
C_values(4,0,((C_word*)t0)[7],((C_word*)t0)[8],t7);}

/* ##sys#expand-curried-define in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6557,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6560,a[2]=t6,a[3]=t8,a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6604,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:612: loop */
t11=((C_word*)t8)[1];
f_6560(t11,t10,t2,t3);}

/* k6553 in match-expression in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6204(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6204,NULL,2,t0,t1);}
if(C_truep(C_i_symbolp(t1))){
t2=f_5520(((C_word*)((C_word*)t0)[2])[1],lf[95],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm:537: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t3,lf[95],((C_word*)t0)[11],lf[109],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t3=f_5520(((C_word*)((C_word*)t0)[2])[1],lf[96],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6343,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* expand.scm:564: ##sys#check-syntax */
t5=*((C_word*)lf[54]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[96],((C_word*)t0)[11],lf[110],((C_word*)t0)[3]);}
else{
t4=f_5520(((C_word*)((C_word*)t0)[2])[1],lf[97],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6355,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:568: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,t5,lf[97],((C_word*)t0)[11],lf[111],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t5=f_5520(((C_word*)((C_word*)t0)[2])[1],lf[98],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t7=C_i_cdr(((C_word*)t0)[11]);
/* expand.scm:571: ##sys#append */
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[7]);}
else{
t6=C_i_memq(t1,((C_word*)t0)[4]);
t7=(C_truep(t6)?t6:C_i_memq(t1,((C_word*)t0)[8]));
if(C_truep(t7)){
/* expand.scm:574: fini */
t8=((C_word*)((C_word*)t0)[14])[1];
f_5586(t8,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[9],((C_word*)t0)[13]);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6406,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* expand.scm:575: ##sys#expand-0 */
t9=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,((C_word*)t0)[11],((C_word*)t0)[3],((C_word*)t0)[15]);}}}}}}
else{
/* expand.scm:534: fini */
t2=((C_word*)((C_word*)t0)[14])[1];
f_5586(t2,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[9],((C_word*)t0)[13]);}}

/* k6094 in k6070 in loop in fini/syntax in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6096,2,t0,t1);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_u_i_car(t2);
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,t4,t6);
t8=C_a_i_cons(&a,2,lf[72],t7);
t9=C_a_i_list(&a,2,lf[23],t8);
t10=C_a_i_list(&a,3,lf[96],t1,t9);
t11=C_a_i_cons(&a,2,t10,((C_word*)t0)[3]);
/* expand.scm:510: loop */
t12=((C_word*)((C_word*)t0)[4])[1];
f_6000(t12,((C_word*)t0)[5],((C_word*)t0)[6],t11,C_SCHEME_FALSE);}

/* k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5700,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5704,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[3];
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5713,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t7,a[7]=t5,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* expand.scm:483: reverse */
t10=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,((C_word*)t0)[7]);}

/* k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7975,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11830,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11832,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:921: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11820,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11822,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:928: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7982,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:933: ##sys#macro-environment */
t3=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* loop in expand-curried-define in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6560(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6560,NULL,4,t0,t1,t2,t3);}
t4=C_i_car(t2);
if(C_truep(C_i_symbolp(t4))){
t5=t2;
t6=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_car(t5));
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_a_i_cons(&a,2,t8,t3);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[72],t9));}
else{
t5=t2;
t6=C_u_i_car(t5);
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_a_i_cons(&a,2,t8,t3);
t10=C_a_i_cons(&a,2,lf[72],t9);
t11=C_a_i_list(&a,1,t10);
/* expand.scm:611: loop */
t18=t1;
t19=t6;
t20=t11;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}

/* k6084 in k6070 in loop in fini/syntax in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6086,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* expand.scm:510: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6000(t3,((C_word*)t0)[4],((C_word*)t0)[5],t2,C_SCHEME_FALSE);}

/* loop2 in k6220 in k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6227(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6227,NULL,3,t0,t1,t2);}
t3=C_i_cadr(t2);
t4=t3;
if(C_truep(C_i_pairp(t4))){
t5=C_i_car(t4);
if(C_truep(C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6285,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:551: ##sys#check-syntax */
t7=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t6,lf[95],t2,lf[105],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6299,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm:556: ##sys#check-syntax */
t7=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t6,lf[95],t2,lf[106],C_SCHEME_FALSE,((C_word*)t0)[3]);}}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6240,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm:541: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,t5,lf[95],t2,lf[108],C_SCHEME_FALSE,((C_word*)t0)[3]);}}

/* k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7982,2,t0,t1);}
t2=C_mutate2((C_word*)lf[183]+1 /* (set! ##sys#initial-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7985,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11803,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11805,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:938: ##sys#er-transformer */
t6=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6220 in k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6222,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6227,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word)li63),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6227(t5,((C_word*)t0)[9],((C_word*)t0)[10]);}

/* k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11769,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11771,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:954: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7988,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11786,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11788,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:946: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k5702 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5704,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[50],t2));}

/* k5718 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:450: ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7994,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11752,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11754,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:962: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8001,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11616,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11618,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:979: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7997,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11735,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11737,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:970: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in ... */
static void C_ccall f_10971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_10974(2,t3,t1);}
else{
t3=C_u_i_car(((C_word*)t0)[2]);
t4=C_eqp(C_SCHEME_TRUE,t3);
if(C_truep(t4)){
t5=t2;
f_10974(2,t5,t4);}
else{
t5=C_u_i_car(((C_word*)t0)[2]);
t6=C_i_numberp(t5);
if(C_truep(t6)){
t7=t2;
f_10974(2,t7,t6);}
else{
t7=C_u_i_car(((C_word*)t0)[2]);
t8=C_charp(t7);
if(C_truep(t8)){
t9=t2;
f_10974(2,t9,t8);}
else{
t9=C_u_i_car(((C_word*)t0)[2]);
t10=C_i_stringp(t9);
if(C_truep(t10)){
t11=t2;
f_10974(2,t11,t10);}
else{
t11=C_u_i_car(((C_word*)t0)[2]);
t12=C_eofp(t11);
if(C_truep(t12)){
t13=t2;
f_10974(2,t13,t12);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11178,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t14=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1160: blob? */
t15=*((C_word*)lf[310]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}}}}}}}

/* k10975 in k10972 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_10977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10977,2,t0,t1);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_car(((C_word*)t0)[2]));}
else{
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[98],t3));}}

/* k10972 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_ccall f_10974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10974,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10995,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1165: strip-syntax */
t5=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t2=C_u_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t2))){
t3=C_u_i_car(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1170: expand */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10919(t5,t4,((C_word*)t0)[5],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=C_i_length(((C_word*)t0)[2]);
t5=C_eqp(t4,C_fix(3));
if(C_truep(t5)){
t6=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1172: c */
t7=((C_word*)t0)[8];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t3,((C_word*)t0)[9],t6);}
else{
t6=t3;
f_11018(2,t6,C_SCHEME_FALSE);}}}}

/* k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5716,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5720,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5843,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t5,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:493: reverse */
t9=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[5]);}

/* k6020 in k6017 in loop in fini/syntax in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6022,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,lf[102],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,1,t3));}

/* map-loop1134 in k6017 in loop in fini/syntax in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6024(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6024,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5900,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[7],a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5900(t6,t2,((C_word*)t0)[8],t1);}

/* k6241 in k6238 in loop2 in k6220 in k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6243,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_i_cddr(((C_word*)t0)[4]);
if(C_truep(C_i_pairp(t3))){
t4=C_i_caddr(((C_word*)t0)[4]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
/* expand.scm:544: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_6184(t6,((C_word*)t0)[7],((C_word*)t0)[8],t2,t5,((C_word*)t0)[9],((C_word*)t0)[10]);}
else{
t4=C_a_i_cons(&a,2,lf[107],((C_word*)t0)[5]);
/* expand.scm:544: loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_6184(t5,((C_word*)t0)[7],((C_word*)t0)[8],t2,t4,((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k6238 in loop2 in k6220 in k6202 in loop in expand in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_car(t3);
t5=C_eqp(t4,((C_word*)t0)[2]);
if(C_truep(t5)){
/* expand.scm:543: ##sys#defjam-error */
t6=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t2,((C_word*)t0)[4]);}
else{
t6=t2;
f_6243(2,t6,C_SCHEME_UNDEFINED);}}

/* k10564 in map-loop2125 in k10495 in k10474 in k10449 in k10437 in a10434 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_fcall f_10566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10566,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10537(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10537(t6,((C_word*)t0)[5],t5);}}

/* k10993 in k10972 in k10969 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_10995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1165: expand */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10919(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* ##sys#canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5505(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5505r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5505r(t0,t1,t2,t3);}}

static void C_ccall f_5505r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5509,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
/* expand.scm:451: ##sys#current-environment */
t6=*((C_word*)lf[1]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=t5;
f_5509(2,t6,C_i_car(t4));}}

/* k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5509,2,t0,t1);}
t2=t1;
t3=C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5520,a[2]=t2,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp));
t19=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5586,a[2]=t17,a[3]=t11,a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp));
t20=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5990,a[2]=t13,a[3]=t11,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp));
t21=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6178,a[2]=t11,a[3]=t2,a[4]=t15,a[5]=t13,a[6]=t7,a[7]=((C_word)li65),tmp=(C_word)a,a+=8,tmp));
/* expand.scm:580: expand */
t22=((C_word*)t17)[1];
f_6178(t22,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* for-each-loop1648 in mark-primitive in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_7948(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7948,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_u_i_car(t3);
t6=C_a_i_putprop(&a,3,t4,lf[177],t5);
t7=C_slot(t2,C_fix(1));
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6070 in loop in fini/syntax in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6072,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_cadr(t3);
if(C_truep(C_i_pairp(t7))){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6096,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:514: caadr */
t9=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t8=C_u_i_car(t3);
t9=C_u_i_cdr(t3);
t10=C_u_i_car(t9);
t11=C_eqp(t8,t10);
if(C_truep(t11)){
/* expand.scm:520: ##sys#defjam-error */
t12=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t6,t3);}
else{
t12=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* expand.scm:510: loop */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6000(t13,((C_word*)t0)[5],t5,t12,C_SCHEME_FALSE);}}}
else{
/* expand.scm:524: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6000(t2,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_TRUE);}}

/* ##sys#strip-syntax in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3704,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3710,a[2]=t4,a[3]=t6,a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3710(t8,t1,t2);}

/* comp in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static C_word C_fcall f_5520(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_overflow_check;
t3=f_3629(t2,((C_word*)t0)[2]);
t4=C_eqp(t1,t3);
if(C_truep(t4)){
return(t4);}
else{
t5=t1;
t6=C_eqp(t5,lf[95]);
if(C_truep(t6)){
return((C_truep(t3)?C_eqp(t3,*((C_word*)lf[91]+1)):C_eqp(t1,t2)));}
else{
t7=C_eqp(t5,lf[96]);
if(C_truep(t7)){
return((C_truep(t3)?C_eqp(t3,*((C_word*)lf[92]+1)):C_eqp(t1,t2)));}
else{
t8=C_eqp(t5,lf[97]);
return((C_truep(t8)?(C_truep(t3)?C_eqp(t3,*((C_word*)lf[93]+1)):C_eqp(t1,t2)):C_eqp(t1,t2)));}}}}

/* k3621 in k3617 in k3613 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3623,2,t0,t1);}
t2=C_mutate2((C_word*)lf[2]+1 /* (set! ##sys#current-meta-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3627,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:77: make-parameter */
t4=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[1]+1));}

/* lookup in k3625 in k3621 in k3617 in k3613 */
static C_word C_fcall f_3629(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
t3=C_u_i_assq(t1,t2);
if(C_truep(t3)){
return(C_i_cdr(t3));}
else{
t4=t1;
t5=C_i_getprop(t4,lf[5],C_SCHEME_FALSE);
return((C_truep(t5)?t5:C_SCHEME_FALSE));}}

/* k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3627,2,t0,t1);}
t2=C_mutate2((C_word*)lf[3]+1 /* (set! ##sys#active-eval-environment ...) */,t1);
t3=C_mutate2(&lf[4] /* (set! lookup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3629,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2(&lf[6] /* (set! macro-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3646,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[10]+1 /* (set! ##sys#strip-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3704,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[12]+1 /* (set! strip-syntax ...) */,*((C_word*)lf[10]+1));
t7=C_mutate2((C_word*)lf[13]+1 /* (set! ##sys#extend-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3841,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[17]+1 /* (set! ##sys#globalize ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4017,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4101,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:156: make-parameter */
t10=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,C_SCHEME_END_OF_LIST);}

/* k5727 in map-loop1016 in k5844 in k5841 in k5714 in k5711 in k5698 in k5692 in k5669 in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5729,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t4=t3;
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_i_check_list_2(t2,lf[16]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5756,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5758,a[2]=t8,a[3]=t12,a[4]=t6,a[5]=((C_word)li54),tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_5758(t14,t10,((C_word*)t0)[4],t2);}

/* k3613 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3615,2,t0,t1);}
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##sys#features ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3619,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:73: make-parameter */
t4=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_END_OF_LIST);}

/* k3617 in k3613 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3619,2,t0,t1);}
t2=C_mutate2((C_word*)lf[1]+1 /* (set! ##sys#current-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3623,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:74: make-parameter */
t4=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_END_OF_LIST);}

/* k7289 in walk in k7030 in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:770: walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7037(t6,((C_word*)t0)[5],t3,t5);}

/* k10664 in expand in k10629 in a10626 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in ... */
static void C_ccall f_10666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10666,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[50],((C_word*)t0)[3],t1));}

/* k7630 in k7622 in compare in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_7632(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7632,NULL,2,t0,t1);}
t2=t1;
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
if(C_truep(C_i_symbolp(t2))){
t3=C_i_getprop(((C_word*)t0)[2],lf[177],C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=C_i_getprop(t2,lf[177],C_SCHEME_FALSE);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_eqp(t4,t5):C_eqp(t4,t2)));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7687,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:840: ##sys#macro-environment */
t4=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7715,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:844: ##sys#macro-environment */
t4=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_eqp(((C_word*)t0)[2],t2));}}}

/* k8669 in k8590 */
static void C_ccall f_8671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8671,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8647,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[13])[1],((C_word*)((C_word*)t0)[14])[1]);
t6=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[15])[1],((C_word*)((C_word*)t0)[16])[1],C_fix(-1));
t7=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[7])[1],t5,t6);
t8=C_a_i_list(&a,1,t7);
/* synrules.scm:61: ##sys#append */
t9=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t4,((C_word*)t0)[17],t8);}

/* k10629 in a10626 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in ... */
static void C_ccall f_10631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10631,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10641,a[2]=t5,a[3]=t7,a[4]=((C_word)li154),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_10641(t9,((C_word*)t0)[3],t2);}

/* k9686 in k9657 in k9577 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_fcall f_9688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9688,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,lf[256],t2);
t4=C_a_i_list(&a,1,t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,lf[257],t6));}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[257],t3));}}

/* walk in strip-syntax in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_3710(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3710,NULL,3,t0,t1,t2);}
t3=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_cdr(t3));}
else{
if(C_truep(C_i_symbolp(t2))){
t4=t2;
t5=C_i_getprop(t4,lf[5],C_SCHEME_FALSE);
t6=t2;
t7=C_i_getprop(t6,lf[7],C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep(t5)){
if(C_truep(C_i_pairp(t5))){
t8=t2;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t5);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}}}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_FALSE);
t5=t4;
t6=C_a_i_cons(&a,2,t2,t5);
t7=C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[2])[1]);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t7);
t9=t5;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3782,a[2]=t9,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=C_u_i_car(t11);
/* expand.scm:116: walk */
t22=t10;
t23=t12;
t1=t22;
t2=t23;
goto loop;}
else{
if(C_truep(C_i_vectorp(t2))){
t4=C_block_size(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3800,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:121: make-vector */
t7=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}}}

/* expand in k10629 in a10626 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in ... */
static void C_fcall f_10641(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10641,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[50],t4));}
else{
t4=C_i_car(t2);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10666,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t2;
t9=C_u_i_cdr(t8);
/* expand.scm:1245: expand */
t12=t7;
t13=t9;
t1=t12;
t2=t13;
goto loop;}}

/* k9838 in test in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_9840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1361: ##sys#feature? */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[265]+1)))(3,*((C_word*)lf[265]+1),((C_word*)t0)[2],t1);}

/* k9875 in k9857 in test in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9877,2,t0,t1);}
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
/* expand.scm:1370: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9826(t4,((C_word*)t0)[5],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7622 in compare in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_7624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7624,NULL,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[2];
t4=C_i_getprop(t3,lf[5],C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7632,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7632(t6,t4);}
else{
t6=((C_word*)t0)[2];
t7=((C_word*)t0)[4];
t8=f_3629(t6,t7);
if(C_truep(t8)){
t9=t5;
f_7632(t9,t8);}
else{
t9=((C_word*)t0)[2];
t10=t5;
f_7632(t10,t9);}}}

/* k5333 in k5225 in loop in k4919 in k4916 in k4913 in k4910 in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_5316(t3,t2);}

/* k8645 in k8669 in k8590 */
static void C_ccall f_8647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8647,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t3=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],t3);
t5=C_a_i_list(&a,4,((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[8],t4);
t6=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[9],t5);
t7=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[10],t6);
t8=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[11],t7);
t9=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_list(&a,1,t8));}

/* k8963 in k8913 in k8901 in k8895 in k8892 */
static void C_fcall f_8965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8965,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_8918(t2,((C_word*)t0)[3]);}
else{
t2=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_8918(t4,C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t3));}}

/* k7078 in doloop1403 in k7054 in walk in k7030 in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_7061(t4,((C_word*)t0)[5],t2,t3);}

/* k9642 in k9580 in k9577 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[252]);}

/* k9645 in k9580 in k9577 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_car(((C_word*)t0)[2]);
t3=C_u_i_cdr(((C_word*)t0)[2]);
/* expand.scm:1463: ##sys#instantiate-functor */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[254]+1)))(5,*((C_word*)lf[254]+1),((C_word*)t0)[3],((C_word*)t0)[4],t2,t3);}

/* k9857 in test in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_9859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9859,2,t0,t1);}
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1369: test */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9826(t5,t3,t4);}
else{
/* expand.scm:1371: err */
t3=((C_word*)((C_word*)t0)[6])[1];
f_9816(t3,((C_word*)t0)[3],((C_word*)t0)[7]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm:1372: c */
t3=((C_word*)t0)[9];
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],((C_word*)t0)[11]);}}

/* k9639 in k9580 in k9577 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1450: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[250]+1)))(4,*((C_word*)lf[250]+1),((C_word*)t0)[2],lf[251],t1);}

/* k9657 in k9577 in k9571 in a9565 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9659,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_eqp(lf[247],t1);
t5=(C_truep(t4)?C_SCHEME_TRUE:t1);
t6=t5;
t7=C_i_cdddr(((C_word*)t0)[2]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9688,a[2]=t8,a[3]=t6,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t8))){
t10=C_u_i_cdr(t8);
if(C_truep(C_i_nullp(t10))){
t11=C_u_i_car(t8);
t12=t9;
f_9688(t12,C_i_stringp(t11));}
else{
t11=t9;
f_9688(t11,C_SCHEME_FALSE);}}
else{
t10=t9;
f_9688(t10,C_SCHEME_FALSE);}}

/* k9492 in k9475 in a9472 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in ... */
static void C_ccall f_9494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
/* synrules.scm:58: ##sys#process-syntax-rules */
t7=*((C_word*)lf[188]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,((C_word*)t0)[5],((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k9469 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:44: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[233],C_SCHEME_END_OF_LIST,t1);}

/* k8940 in k8919 in k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8942,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8938,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:233: segment-tail */
t4=((C_word*)((C_word*)t0)[7])[1];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}}

/* doloop2620 in k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_fcall f_8944(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8944,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_eqp(t4,C_fix(1));
if(C_truep(t5)){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_fixnum_difference(t2,C_fix(1));
t7=C_a_i_list(&a,3,lf[212],lf[70],t3);
t10=t1;
t11=t6;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* a8773 in k8743 */
static void C_ccall f_8774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8774,3,t0,t1,t2);}
t3=C_eqp(((C_word*)((C_word*)t0)[2])[1],t2);
if(C_truep(t3)){
/* synrules.scm:184: mapit */
t4=((C_word*)t0)[3];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,((C_word*)t0)[4]);}
else{
t4=C_a_i_list(&a,1,((C_word*)((C_word*)t0)[2])[1]);
t5=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[5])[1],t4,t2);
t6=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[6])[1],t5,((C_word*)t0)[4]);
/* synrules.scm:184: mapit */
t7=((C_word*)t0)[3];
((C_proc3)C_fast_retrieve_proc(t7))(3,t7,t1,t6);}}

/* k8760 in k8756 in k8743 */
static void C_ccall f_8762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* synrules.scm:180: append */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k7030 in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_7032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7032,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7037,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li89),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7037(t5,((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9]);}

/* walk in k7030 in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_7037(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7037,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_vectorp(t3))){
t4=C_i_vector_ref(t3,C_fix(0));
t5=t4;
t6=C_block_size(t3);
t7=C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?C_i_vector_ref(t3,C_fix(1)):C_fix(0));
t9=t8;
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7056,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=C_eqp(t6,C_fix(1));
if(C_truep(t11)){
t12=t10;
f_7056(t12,C_fix(1));}
else{
t12=C_fixnum_greaterp(t6,C_fix(2));
t13=t10;
f_7056(t13,(C_truep(t12)?C_i_vector_ref(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep(C_immp(t3))){
t4=C_eqp(t3,t2);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* expand.scm:747: err */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6916(t5,t1,lf[150]);}}
else{
if(C_truep(C_i_symbolp(t3))){
t4=t3;
t5=C_eqp(t4,lf[151]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=C_eqp(t4,lf[152]);
if(C_truep(t6)){
/* expand.scm:751: test */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6904(t7,t1,t2,*((C_word*)lf[153]+1),lf[154]);}
else{
t7=C_eqp(t4,lf[155]);
if(C_truep(t7)){
/* expand.scm:752: test */
t8=((C_word*)((C_word*)t0)[4])[1];
f_6904(t8,t1,t2,*((C_word*)lf[156]+1),lf[157]);}
else{
t8=C_eqp(t4,lf[158]);
if(C_truep(t8)){
/* expand.scm:753: test */
t9=((C_word*)((C_word*)t0)[4])[1];
f_6904(t9,t1,t2,*((C_word*)lf[156]+1),lf[159]);}
else{
t9=C_eqp(t4,lf[160]);
if(C_truep(t9)){
/* expand.scm:754: test */
t10=((C_word*)((C_word*)t0)[4])[1];
f_6904(t10,t1,t2,((C_word*)((C_word*)t0)[5])[1],lf[161]);}
else{
t10=C_eqp(t4,lf[162]);
if(C_truep(t10)){
/* expand.scm:755: test */
t11=((C_word*)((C_word*)t0)[4])[1];
f_6904(t11,t1,t2,*((C_word*)lf[163]+1),lf[164]);}
else{
t11=C_eqp(t4,lf[165]);
if(C_truep(t11)){
/* expand.scm:756: test */
t12=((C_word*)((C_word*)t0)[4])[1];
f_6904(t12,t1,t2,*((C_word*)lf[166]+1),lf[167]);}
else{
t12=C_eqp(t4,lf[168]);
if(C_truep(t12)){
/* expand.scm:757: test */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6904(t13,t1,t2,((C_word*)((C_word*)t0)[6])[1],lf[169]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7234,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word)li88),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:759: test */
t14=((C_word*)((C_word*)t0)[4])[1];
f_6904(t14,t1,t2,t13,lf[170]);}}}}}}}}}
else{
if(C_truep(C_i_pairp(t3))){
if(C_truep(C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7291,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* expand.scm:769: walk */
t29=t4;
t30=t5;
t31=t6;
t1=t29;
t2=t30;
t3=t31;
goto loop;}
else{
/* expand.scm:767: err */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6916(t4,t1,lf[171]);}}
else{
/* expand.scm:766: err */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6916(t4,t1,lf[172]);}}}}}

/* a7233 in walk in k7030 in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7234,3,t0,t1,t2);}
t3=(C_truep(C_i_symbolp(t2))?f_3629(t2,((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(C_i_symbolp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(t3,((C_word*)t0)[3]));}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_eqp(t4,((C_word*)t0)[3]));}}

/* a9472 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9473,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9477,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:49: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[233],t2,lf[236]);}

/* k9475 in a9472 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9477,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[234];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_symbolp(((C_word*)t4)[1]))){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9494,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* synrules.scm:54: ##sys#check-syntax */
t12=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t11,lf[233],((C_word*)t0)[2],lf[235]);}
else{
/* synrules.scm:58: ##sys#process-syntax-rules */
t11=*((C_word*)lf[188]+1);
((C_proc7)(void*)(*((C_word*)t11+1)))(7,t11,((C_word*)t0)[3],((C_word*)t10)[1],((C_word*)t8)[1],((C_word*)t4)[1],((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* ##sys#defjam-error in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_5496(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5496,3,t0,t1,t2);}
/* expand.scm:437: ##sys#syntax-error-hook */
t3=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[90],t2);}

/* k8756 in k8743 */
static void C_ccall f_8758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8758,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8762,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
t5=C_a_i_list(&a,3,lf[209],((C_word*)t0)[4],((C_word*)t0)[5]);
/* synrules.scm:189: process-pattern */
t6=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_fast_retrieve_proc(t6))(6,t6,t3,t4,t5,((C_word*)t0)[7],C_SCHEME_TRUE);}

/* k10940 in k10937 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_ccall f_10942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[304]);}

/* k10944 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in ... */
static void C_ccall f_10946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10946,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[305]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1149: ##sys#print */
t6=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[307],C_SCHEME_FALSE,t3);}

/* k9505 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_9507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1493: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[237],C_SCHEME_END_OF_LIST,t1);}

/* a9508 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_9509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9509,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9513,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9526,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_i_cdr(t2);
/* expand.scm:1500: ##sys#strip-syntax */
t8=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k9895 in k9857 in test in k9812 in k9809 in k9806 in k9803 in a9797 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9897,2,t0,t1);}
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1375: test */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9826(t5,t3,t4);}
else{
/* expand.scm:1377: err */
t3=((C_word*)((C_word*)t0)[6])[1];
f_9816(t3,((C_word*)t0)[3],((C_word*)t0)[7]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1378: c */
t3=((C_word*)t0)[8];
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k8743 */
static void C_ccall f_8745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8745,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cddr(((C_word*)t0)[2]);
t3=C_i_length(t2);
t4=t3;
t5=C_eqp(t4,C_fix(0));
t6=(C_truep(t5)?((C_word*)t0)[3]:C_a_i_list(&a,3,lf[208],((C_word*)t0)[3],t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8758,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t9=((C_word*)t0)[2];
t10=C_u_i_car(t9);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8774,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t7,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word)li114),tmp=(C_word)a,a+=8,tmp);
/* synrules.scm:181: process-pattern */
t12=((C_word*)((C_word*)t0)[5])[1];
((C_proc6)C_fast_retrieve_proc(t12))(6,t12,t8,t10,((C_word*)((C_word*)t0)[7])[1],t11,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8820,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[11])[1],((C_word*)t0)[3]);
/* synrules.scm:192: process-pattern */
t6=((C_word*)((C_word*)t0)[5])[1];
((C_proc6)C_fast_retrieve_proc(t6))(6,t6,t2,t4,t5,((C_word*)t0)[6],C_SCHEME_FALSE);}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8849,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* synrules.scm:195: vector->list */
t3=*((C_word*)lf[175]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}}}

/* k7054 in walk in k7030 in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_7056(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7056,NULL,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li87),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_7061(t6,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(0));}

/* k10950 in k10944 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_ccall f_10952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1149: ##sys#print */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5]);}

/* k10953 in k10950 in k10944 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_10955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1149: ##sys#print */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[306],C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k10956 in k10953 in k10950 in k10944 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_10958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1149: get-output-string */
t3=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* a11241 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in ... */
static void C_ccall f_11242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11242,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
if(C_truep(C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t5);
t7=t6;
t8=C_u_i_car(t5);
if(C_truep(C_i_nullp(t7))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11265,a[2]=t8,a[3]=t7,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1128: r */
t10=t3;
((C_proc3)C_fast_retrieve_proc(t10))(3,t10,t9,lf[77]);}}}

/* k11238 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in ... */
static void C_ccall f_11240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1116: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[218],C_SCHEME_END_OF_LIST,t1);}

/* k7812 in mirror-rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:868: mirror-rename */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7775(t2,((C_word*)t0)[3],t1);}

/* k7808 in mirror-rename in k7355 in a7349 in make-er/ir-transformer in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_7810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:868: list->vector */
t2=*((C_word*)lf[174]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* doloop1403 in k7054 in walk in k7030 in k6897 in check-syntax in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_7061(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7061,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep(C_fixnum_lessp(t3,((C_word*)t0)[2]))){
/* expand.scm:740: err */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6916(t5,t1,lf[147]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7080,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
/* expand.scm:742: err */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6916(t6,t5,lf[148]);}
else{
if(C_truep(C_i_pairp(t2))){
t6=C_i_car(t2);
/* expand.scm:745: walk */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7037(t7,t5,t6,((C_word*)t0)[7]);}
else{
/* expand.scm:744: err */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6916(t6,t5,lf[149]);}}}}

/* loop in fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5598(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5598,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5617,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,a[6]=t5,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t5))){
t7=C_u_i_car(t5);
if(C_truep(C_i_symbolp(t7))){
t8=f_5520(((C_word*)((C_word*)t0)[4])[1],lf[95],t7);
t9=t6;
f_5617(t9,(C_truep(t8)?t8:f_5520(((C_word*)((C_word*)t0)[4])[1],lf[97],t7)));}
else{
t8=t6;
f_5617(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_5617(t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[98],((C_word*)t0)[5]));}}

/* k10959 in k10956 in k10953 in k10950 in k10944 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in ... */
static void C_ccall f_10961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10961,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10965,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1150: ##sys#strip-syntax */
t4=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k10963 in k10959 in k10956 in k10953 in k10950 in k10944 in k10931 in expand in k10912 in k10909 in k10906 in a10900 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in ... */
static void C_ccall f_10965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1148: ##sys#warn */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[185]+1)))(4,*((C_word*)lf[185]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k8590 */
static void C_ccall f_8592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[75],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8592,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[5])[1],t5);
t7=C_a_i_list(&a,1,t6);
t8=t7;
t9=C_i_cddr(((C_word*)t0)[6]);
t10=C_i_length(t9);
t11=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[5])[1],t10);
t12=t11;
t13=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[3]);
t14=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[5])[1]);
t15=C_a_i_list(&a,2,t13,t14);
t16=t15;
t17=((C_word*)t0)[6];
t18=C_u_i_cdr(t17);
t19=C_u_i_cdr(t18);
t20=C_i_length(t19);
t21=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[5])[1],t20);
t22=t21;
t23=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8671,a[2]=t22,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=t16,a[9]=t12,a[10]=t8,a[11]=t4,a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[5],a[17]=t2,tmp=(C_word)a,a+=18,tmp);
t24=((C_word*)t0)[6];
t25=C_u_i_cdr(t24);
t26=C_u_i_cdr(t25);
/* synrules.scm:162: process-match */
t27=((C_word*)((C_word*)t0)[18])[1];
((C_proc5)C_fast_retrieve_proc(t27))(5,t27,t23,((C_word*)((C_word*)t0)[8])[1],t26,C_SCHEME_TRUE);}

/* k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in ... */
static void C_ccall f_10702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10702,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10713,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10715,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word)li158),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_10715(t10,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}

/* k10711 in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_ccall f_10713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10713,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[55],((C_word*)t0)[3],t1));}

/* expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in ... */
static void C_fcall f_10715(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10715,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10729,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t5,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* expand.scm:1211: ##sys#check-syntax */
t9=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[296],t5,lf[299]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[300]);}}

/* f_8588 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_8588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8588,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8592,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[15],tmp=(C_word)a,a+=19,tmp);
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[16])[1],((C_word*)((C_word*)t0)[6])[1]);
t6=C_i_car(t3);
/* synrules.scm:154: process-match */
t7=((C_word*)((C_word*)t0)[15])[1];
((C_proc5)C_fast_retrieve_proc(t7))(5,t7,t4,t5,t6,C_SCHEME_FALSE);}

/* k10727 in expand in k10700 in k10697 in k10694 in k10691 in k10688 in k10680 in a10677 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in ... */
static void C_ccall f_10729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10729,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10735,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10742,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1215: ##sys#strip-syntax */
t4=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10748,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=C_i_car(((C_word*)t0)[6]);
/* expand.scm:1218: c */
t4=((C_word*)t0)[8];
((C_proc4)C_fast_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[12],t3);}}

/* k9417 in k9377 in fixup-macro-environment in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in ... */
static void C_ccall f_9419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k11282 in k11263 in a11241 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in ... */
static void C_ccall f_11284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11284,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,4,lf[291],((C_word*)t0)[3],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[50],((C_word*)t0)[5],t3));}

/* fini in k5507 in canonicalize-body in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_5586(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5586,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_i_nullp(t2);
t8=(C_truep(t7)?C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word)li53),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_5598(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5671,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:477: reverse */
t10=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}}

/* for-each-loop2764 in k9377 in fixup-macro-environment in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in ... */
static void C_fcall f_9421(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9421,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9431,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:1522: g2765 */
t5=((C_word*)t0)[3];
f_9380(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6660 in k6656 in loop in k6631 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6662,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k11263 in a11241 in k8098 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in ... */
static void C_ccall f_11265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11265,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11284,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1130: r */
t7=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t7))(3,t7,t6,lf[218]);}

/* k6656 in loop in k6631 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6658,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6662,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:632: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6638(t6,t3,t5);}

/* ##sys#expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4892,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4895,a[2]=t4,a[3]=t2,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4912,a[2]=t8,a[3]=t10,a[4]=t3,a[5]=t6,a[6]=t5,a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* expand.scm:345: macro-alias */
f_3646(t11,lf[88],t5);}

/* err in expand-extended-lambda-list in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4895(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4895,NULL,3,t0,t1,t2);}
/* expand.scm:341: errh */
t3=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[3]);}

/* k9453 in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9455,2,t0,t1);}
t2=C_mutate2((C_word*)lf[230]+1 /* (set! ##sys#default-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9459,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9463,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1538: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k9457 in k9453 in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in ... */
static void C_ccall f_9459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2((C_word*)lf[231]+1 /* (set! ##sys#meta-macro-environment ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* k4221 in k4199 in macro? in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_3629(((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_i_pairp(t2):C_SCHEME_FALSE));}

/* k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in ... */
static void C_ccall f_8236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8236,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|50,a[1]=(C_word)f_8241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[2],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],tmp=(C_word)a,a+=51,tmp);
/* synrules.scm:101: r */
t4=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[52]);}

/* k6675 in k6741 in loop in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:629: ##sys#get */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[134]+1)))(4,*((C_word*)lf[134]+1),((C_word*)t0)[2],t1,lf[135]);}

/* k9461 in k9453 in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in ... */
static void C_ccall f_9463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1538: make-parameter */
t2=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* a11293 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in ... */
static void C_ccall f_11294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11294,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
if(C_truep(C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=C_i_cdr(t5);
t7=t6;
t8=C_u_i_car(t5);
if(C_truep(C_i_nullp(t7))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11325,a[2]=t7,a[3]=t1,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1114: r */
t10=t3;
((C_proc3)C_fast_retrieve_proc(t10))(3,t10,t9,lf[227]);}}}

/* k9465 in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in k8092 in k8089 in k8086 in ... */
static void C_ccall f_9467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1536: ##sys#fixup-macro-environment */
t2=*((C_word*)lf[229]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11290 in k8095 in k8092 in k8089 in k8086 in k8083 in k8080 in k8003 in k7999 in k7995 in k7992 in k7989 in k7986 in k7983 in k7980 in k7976 in k7973 in k7970 in k4099 in k3625 in k3621 in k3617 in ... */
static void C_ccall f_11292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:1102: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[227],C_SCHEME_END_OF_LIST,t1);}

/* ##sys#unregister-macro in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4234,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4242,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4246,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:192: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in ... */
static void C_ccall f_8232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8232,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:99: r */
t4=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[215]);}

/* k4868 in loop in extended-lambda-list? in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* expand.scm:336: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4851(t4,((C_word*)t0)[2],t3);}}

/* k9429 in for-each-loop2764 in k9377 in fixup-macro-environment in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in k8116 in k8113 in k8110 in k8107 in k8104 in k8101 in k8098 in k8095 in ... */
static void C_ccall f_9431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9421(t3,((C_word*)t0)[4],t2);}

/* k4244 in unregister-macro in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4248,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4248(t5,((C_word*)t0)[3],t1);}

/* loop in k4244 in unregister-macro in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4248(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4248,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_caar(t2);
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_u_i_cdr(t5));}
else{
t5=t2;
t6=C_u_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4271,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t2;
t9=C_u_i_cdr(t8);
/* expand.scm:195: loop */
t12=t7;
t13=t9;
t1=t12;
t2=t13;
goto loop;}}}

/* k4240 in unregister-macro in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm:190: ##sys#macro-environment */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* macro-alias in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_3646(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3646,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3653,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:85: ##sys#qualified-symbol? */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t4,t2);}

/* k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in ... */
static void C_ccall f_8219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8219,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,lf[204]);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8224,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[2],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:96: r */
t4=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[207]);}

/* outstr in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_6691(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6691,NULL,3,t0,t1,t2);}
/* expand.scm:638: ##sys#print */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6696 in k6687 in syntax-error/context in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_ccall f_6698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6705,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:673: get-output-string */
t3=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in k8137 in k8134 in k8131 in k8128 in k8125 in k8122 in k8119 in ... */
static void C_ccall f_8212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8212,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[202]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,lf[203]);
t5=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8219,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[28],a[26]=((C_word*)t0)[29],a[27]=((C_word*)t0)[30],a[28]=((C_word*)t0)[31],a[29]=((C_word*)t0)[32],a[30]=((C_word*)t0)[33],a[31]=((C_word*)t0)[34],a[32]=((C_word*)t0)[35],a[33]=((C_word*)t0)[36],a[34]=((C_word*)t0)[37],a[35]=((C_word*)t0)[38],a[36]=((C_word*)t0)[39],a[37]=((C_word*)t0)[40],a[38]=((C_word*)t0)[41],a[39]=((C_word*)t0)[2],a[40]=((C_word*)t0)[42],a[41]=((C_word*)t0)[3],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[4],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:94: r */
t6=((C_word*)t0)[51];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,lf[218]);}

/* f_8249 in k8239 in k8234 in k8230 in k8226 in k8222 in k8217 in k8210 in k8205 in k8201 in k8197 in k8193 in k8189 in k8185 in k8179 in k8174 in k8170 in k8155 in process-syntax-rules in k8146 in k8143 in k8140 in ... */
static void C_ccall f_8249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[50],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8249,3,t0,t1,t2);}
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[2])[1]);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[6])[1],t5);
t7=C_a_i_list(&a,1,t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8277,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t8,a[5]=((C_word*)t0)[9],a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)((C_word*)t0)[10])[1];
t15=C_i_check_list_2(t2,lf[16]);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8298,a[2]=t13,a[3]=t18,a[4]=t11,a[5]=t14,a[6]=((C_word)li108),tmp=(C_word)a,a+=7,tmp));
t20=((C_word*)t18)[1];
f_8298(t20,t16,t2);}

/* loop in extended-lambda-list? in k4099 in k3625 in k3621 in k3617 in k3613 */
static void C_fcall f_4851(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4851,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_eqp(t3,lf[64]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4870,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4870(t6,t4);}
else{
t6=C_eqp(t3,lf[65]);
t7=t5;
f_4870(t7,(C_truep(t6)?t6:C_eqp(t3,lf[66])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[669] = {
{"f_11417:expand_2escm",(void*)f_11417},
{"f_11419:expand_2escm",(void*)f_11419},
{"f_8243:expand_2escm",(void*)f_8243},
{"f_8241:expand_2escm",(void*)f_8241},
{"f_8555:expand_2escm",(void*)f_8555},
{"f_4845:expand_2escm",(void*)f_4845},
{"f_11404:expand_2escm",(void*)f_11404},
{"f_11401:expand_2escm",(void*)f_11401},
{"f_8542:expand_2escm",(void*)f_8542},
{"toplevel:expand_2escm",(void*)C_expand_toplevel},
{"f_4201:expand_2escm",(void*)f_4201},
{"f_5771:expand_2escm",(void*)f_5771},
{"f_8534:expand_2escm",(void*)f_8534},
{"f_9736:expand_2escm",(void*)f_9736},
{"f_8207:expand_2escm",(void*)f_8207},
{"f_6689:expand_2escm",(void*)f_6689},
{"f_8203:expand_2escm",(void*)f_8203},
{"f_9722:expand_2escm",(void*)f_9722},
{"f_11515:expand_2escm",(void*)f_11515},
{"f_11513:expand_2escm",(void*)f_11513},
{"f_8298:expand_2escm",(void*)f_8298},
{"f_6899:expand_2escm",(void*)f_6899},
{"f_5756:expand_2escm",(void*)f_5756},
{"f_8277:expand_2escm",(void*)f_8277},
{"f_4271:expand_2escm",(void*)f_4271},
{"f_4279:expand_2escm",(void*)f_4279},
{"f_6889:expand_2escm",(void*)f_6889},
{"f_5758:expand_2escm",(void*)f_5758},
{"f_8228:expand_2escm",(void*)f_8228},
{"f_4285:expand_2escm",(void*)f_4285},
{"f_4288:expand_2escm",(void*)f_4288},
{"f_3782:expand_2escm",(void*)f_3782},
{"f_8224:expand_2escm",(void*)f_8224},
{"f_11382:expand_2escm",(void*)f_11382},
{"f_8820:expand_2escm",(void*)f_8820},
{"f_4298:expand_2escm",(void*)f_4298},
{"f_11395:expand_2escm",(void*)f_11395},
{"f_11397:expand_2escm",(void*)f_11397},
{"f_6850:expand_2escm",(void*)f_6850},
{"f_8284:expand_2escm",(void*)f_8284},
{"f_8824:expand_2escm",(void*)f_8824},
{"f_6844:expand_2escm",(void*)f_6844},
{"f_3775:expand_2escm",(void*)f_3775},
{"f_11379:expand_2escm",(void*)f_11379},
{"f_7672:expand_2escm",(void*)f_7672},
{"f_11375:expand_2escm",(void*)f_11375},
{"f_11373:expand_2escm",(void*)f_11373},
{"f_6870:expand_2escm",(void*)f_6870},
{"f_6874:expand_2escm",(void*)f_6874},
{"f_11358:expand_2escm",(void*)f_11358},
{"f_11325:expand_2escm",(void*)f_11325},
{"f_11329:expand_2escm",(void*)f_11329},
{"f_11335:expand_2escm",(void*)f_11335},
{"f_11331:expand_2escm",(void*)f_11331},
{"f_6387:expand_2escm",(void*)f_6387},
{"f_7687:expand_2escm",(void*)f_7687},
{"f_3656:expand_2escm",(void*)f_3656},
{"f_3653:expand_2escm",(void*)f_3653},
{"f_3659:expand_2escm",(void*)f_3659},
{"f_5138:expand_2escm",(void*)f_5138},
{"f_5134:expand_2escm",(void*)f_5134},
{"f_5146:expand_2escm",(void*)f_5146},
{"f_5141:expand_2escm",(void*)f_5141},
{"f_5144:expand_2escm",(void*)f_5144},
{"f_8118:expand_2escm",(void*)f_8118},
{"f_8115:expand_2escm",(void*)f_8115},
{"f_8112:expand_2escm",(void*)f_8112},
{"f_4660:expand_2escm",(void*)f_4660},
{"f_6178:expand_2escm",(void*)f_6178},
{"f_4666:expand_2escm",(void*)f_4666},
{"f_11786:expand_2escm",(void*)f_11786},
{"f_11788:expand_2escm",(void*)f_11788},
{"f_5227:expand_2escm",(void*)f_5227},
{"f_11792:expand_2escm",(void*)f_11792},
{"f_11769:expand_2escm",(void*)f_11769},
{"f_5240:expand_2escm",(void*)f_5240},
{"f_6184:expand_2escm",(void*)f_6184},
{"f_11775:expand_2escm",(void*)f_11775},
{"f_5256:expand_2escm",(void*)f_5256},
{"f_11771:expand_2escm",(void*)f_11771},
{"f_7513:expand_2escm",(void*)f_7513},
{"f_11533:expand_2escm",(void*)f_11533},
{"f_11741:expand_2escm",(void*)f_11741},
{"f_11530:expand_2escm",(void*)f_11530},
{"f_6343:expand_2escm",(void*)f_6343},
{"f_11758:expand_2escm",(void*)f_11758},
{"f_11754:expand_2escm",(void*)f_11754},
{"f_11547:expand_2escm",(void*)f_11547},
{"f_11544:expand_2escm",(void*)f_11544},
{"f_11752:expand_2escm",(void*)f_11752},
{"f_7535:expand_2escm",(void*)f_7535},
{"f_10178:expand_2escm",(void*)f_10178},
{"f_5175:expand_2escm",(void*)f_5175},
{"f_11737:expand_2escm",(void*)f_11737},
{"f_11735:expand_2escm",(void*)f_11735},
{"f_6355:expand_2escm",(void*)f_6355},
{"f_10182:expand_2escm",(void*)f_10182},
{"f_5186:expand_2escm",(void*)f_5186},
{"f_11574:expand_2escm",(void*)f_11574},
{"f_11577:expand_2escm",(void*)f_11577},
{"f_11571:expand_2escm",(void*)f_11571},
{"f_6707:expand_2escm",(void*)f_6707},
{"f_6705:expand_2escm",(void*)f_6705},
{"f_6736:expand_2escm",(void*)f_6736},
{"f_6729:expand_2escm",(void*)f_6729},
{"f_6726:expand_2escm",(void*)f_6726},
{"f_6723:expand_2escm",(void*)f_6723},
{"f_6720:expand_2escm",(void*)f_6720},
{"f_10149:expand_2escm",(void*)f_10149},
{"f_10146:expand_2escm",(void*)f_10146},
{"f_7593:expand_2escm",(void*)f_7593},
{"f_10140:expand_2escm",(void*)f_10140},
{"f_10142:expand_2escm",(void*)f_10142},
{"f_10154:expand_2escm",(void*)f_10154},
{"f_10152:expand_2escm",(void*)f_10152},
{"f_9338:expand_2escm",(void*)f_9338},
{"f_9336:expand_2escm",(void*)f_9336},
{"f_3809:expand_2escm",(void*)f_3809},
{"f_5277:expand_2escm",(void*)f_5277},
{"f_5274:expand_2escm",(void*)f_5274},
{"f_3800:expand_2escm",(void*)f_3800},
{"f_4410:expand_2escm",(void*)f_4410},
{"f_4412:expand_2escm",(void*)f_4412},
{"f_10162:expand_2escm",(void*)f_10162},
{"f_10164:expand_2escm",(void*)f_10164},
{"f_4419:expand_2escm",(void*)f_4419},
{"f_4416:expand_2escm",(void*)f_4416},
{"f_6717:expand_2escm",(void*)f_6717},
{"f_7572:expand_2escm",(void*)f_7572},
{"f_10120:expand_2escm",(void*)f_10120},
{"f_11700:expand_2escm",(void*)f_11700},
{"f_11557:expand_2escm",(void*)f_11557},
{"f_11115:expand_2escm",(void*)f_11115},
{"f_11568:expand_2escm",(void*)f_11568},
{"f_11564:expand_2escm",(void*)f_11564},
{"f_11018:expand_2escm",(void*)f_11018},
{"f_11012:expand_2escm",(void*)f_11012},
{"f_11021:expand_2escm",(void*)f_11021},
{"f_9396:expand_2escm",(void*)f_9396},
{"f_9329:expand_2escm",(void*)f_9329},
{"f_9322:expand_2escm",(void*)f_9322},
{"f_3830:expand_2escm",(void*)f_3830},
{"f_6019:expand_2escm",(void*)f_6019},
{"f_9372:expand_2escm",(void*)f_9372},
{"f_9379:expand_2escm",(void*)f_9379},
{"f_9177:expand_2escm",(void*)f_9177},
{"f_7373:expand_2escm",(void*)f_7373},
{"f_7377:expand_2escm",(void*)f_7377},
{"f_6000:expand_2escm",(void*)f_6000},
{"f_9380:expand_2escm",(void*)f_9380},
{"f_9359:expand_2escm",(void*)f_9359},
{"f_7398:expand_2escm",(void*)f_7398},
{"f_7394:expand_2escm",(void*)f_7394},
{"f_9166:expand_2escm",(void*)f_9166},
{"f_7715:expand_2escm",(void*)f_7715},
{"f_8085:expand_2escm",(void*)f_8085},
{"f_8088:expand_2escm",(void*)f_8088},
{"f_9606:expand_2escm",(void*)f_9606},
{"f_9603:expand_2escm",(void*)f_9603},
{"f_11809:expand_2escm",(void*)f_11809},
{"f_11805:expand_2escm",(void*)f_11805},
{"f_11803:expand_2escm",(void*)f_11803},
{"f_11088:expand_2escm",(void*)f_11088},
{"f_11061:expand_2escm",(void*)f_11061},
{"f_9302:expand_2escm",(void*)f_9302},
{"f_6743:expand_2escm",(void*)f_6743},
{"f_6746:expand_2escm",(void*)f_6746},
{"f_11058:expand_2escm",(void*)f_11058},
{"f_4473:expand_2escm",(void*)f_4473},
{"f_11820:expand_2escm",(void*)f_11820},
{"f_11822:expand_2escm",(void*)f_11822},
{"f_6770:expand_2escm",(void*)f_6770},
{"f_11040:expand_2escm",(void*)f_11040},
{"f_6761:expand_2escm",(void*)f_6761},
{"f_6764:expand_2escm",(void*)f_6764},
{"f_6767:expand_2escm",(void*)f_6767},
{"f_5617:expand_2escm",(void*)f_5617},
{"f_7700:expand_2escm",(void*)f_7700},
{"f_5624:expand_2escm",(void*)f_5624},
{"f_5628:expand_2escm",(void*)f_5628},
{"f_8001:expand_2escm",(void*)f_8001},
{"f_6783:expand_2escm",(void*)f_6783},
{"f_8013:expand_2escm",(void*)f_8013},
{"f_4432:expand_2escm",(void*)f_4432},
{"f_6787:expand_2escm",(void*)f_6787},
{"f_4436:expand_2escm",(void*)f_4436},
{"f_6492:expand_2escm",(void*)f_6492},
{"f_7344:expand_2escm",(void*)f_7344},
{"f_5807:expand_2escm",(void*)f_5807},
{"f_9196:expand_2escm",(void*)f_9196},
{"f_6755:expand_2escm",(void*)f_6755},
{"f_6758:expand_2escm",(void*)f_6758},
{"f_7359:expand_2escm",(void*)f_7359},
{"f_9637:expand_2escm",(void*)f_9637},
{"f_7357:expand_2escm",(void*)f_7357},
{"f_4484:expand_2escm",(void*)f_4484},
{"f_4486:expand_2escm",(void*)f_4486},
{"f_7350:expand_2escm",(void*)f_7350},
{"f_9124:expand_2escm",(void*)f_9124},
{"f_9122:expand_2escm",(void*)f_9122},
{"f_10357:expand_2escm",(void*)f_10357},
{"f_11627:expand_2escm",(void*)f_11627},
{"f_11622:expand_2escm",(void*)f_11622},
{"f_8046:expand_2escm",(void*)f_8046},
{"f_10327:expand_2escm",(void*)f_10327},
{"f_11618:expand_2escm",(void*)f_11618},
{"f_11616:expand_2escm",(void*)f_11616},
{"f_8091:expand_2escm",(void*)f_8091},
{"f_8094:expand_2escm",(void*)f_8094},
{"f_8029:expand_2escm",(void*)f_8029},
{"f_8026:expand_2escm",(void*)f_8026},
{"f_6798:expand_2escm",(void*)f_6798},
{"f_8082:expand_2escm",(void*)f_8082},
{"f_3870:expand_2escm",(void*)f_3870},
{"f_8097:expand_2escm",(void*)f_8097},
{"f_6975:expand_2escm",(void*)f_6975},
{"f_8715:expand_2escm",(void*)f_8715},
{"f_10361:expand_2escm",(void*)f_10361},
{"f_10796:expand_2escm",(void*)f_10796},
{"f_10331:expand_2escm",(void*)f_10331},
{"f_10335:expand_2escm",(void*)f_10335},
{"f_10451:expand_2escm",(void*)f_10451},
{"f_10439:expand_2escm",(void*)f_10439},
{"f_8921:expand_2escm",(void*)f_8921},
{"f_10435:expand_2escm",(void*)f_10435},
{"f_10433:expand_2escm",(void*)f_10433},
{"f_3841:expand_2escm",(void*)f_3841},
{"f_11488:expand_2escm",(void*)f_11488},
{"f_3845:expand_2escm",(void*)f_3845},
{"f_4512:expand_2escm",(void*)f_4512},
{"f_10899:expand_2escm",(void*)f_10899},
{"f_6955:expand_2escm",(void*)f_6955},
{"f_8903:expand_2escm",(void*)f_8903},
{"f_10497:expand_2escm",(void*)f_10497},
{"f_11467:expand_2escm",(void*)f_11467},
{"f_11463:expand_2escm",(void*)f_11463},
{"f_11461:expand_2escm",(void*)f_11461},
{"f_6406:expand_2escm",(void*)f_6406},
{"f_6941:expand_2escm",(void*)f_6941},
{"f_6943:expand_2escm",(void*)f_6943},
{"f_6947:expand_2escm",(void*)f_6947},
{"f_8938:expand_2escm",(void*)f_8938},
{"f_8934:expand_2escm",(void*)f_8934},
{"f_10422:expand_2escm",(void*)f_10422},
{"f_11478:expand_2escm",(void*)f_11478},
{"f_11475:expand_2escm",(void*)f_11475},
{"f_10313:expand_2escm",(void*)f_10313},
{"f_10476:expand_2escm",(void*)f_10476},
{"f_11445:expand_2escm",(void*)f_11445},
{"f_11448:expand_2escm",(void*)f_11448},
{"f_8918:expand_2escm",(void*)f_8918},
{"f_8915:expand_2escm",(void*)f_8915},
{"f_5836:expand_2escm",(void*)f_5836},
{"f_4039:expand_2escm",(void*)f_4039},
{"f_11423:expand_2escm",(void*)f_11423},
{"f_11426:expand_2escm",(void*)f_11426},
{"f_10309:expand_2escm",(void*)f_10309},
{"f_10933:expand_2escm",(void*)f_10933},
{"f_11439:expand_2escm",(void*)f_11439},
{"f_4057:expand_2escm",(void*)f_4057},
{"f_10939:expand_2escm",(void*)f_10939},
{"f_7496:expand_2escm",(void*)f_7496},
{"f_4460:expand_2escm",(void*)f_4460},
{"f_4467:expand_2escm",(void*)f_4467},
{"f_5694:expand_2escm",(void*)f_5694},
{"f_8739:expand_2escm",(void*)f_8739},
{"f_4454:expand_2escm",(void*)f_4454},
{"f_4008:expand_2escm",(void*)f_4008},
{"f_11441:expand_2escm",(void*)f_11441},
{"f_5035:expand_2escm",(void*)f_5035},
{"f_5031:expand_2escm",(void*)f_5031},
{"f_5900:expand_2escm",(void*)f_5900},
{"f_4449:expand_2escm",(void*)f_4449},
{"f_4443:expand_2escm",(void*)f_4443},
{"f_6622:expand_2escm",(void*)f_6622},
{"f_6620:expand_2escm",(void*)f_6620},
{"f_4017:expand_2escm",(void*)f_4017},
{"f_6478:expand_2escm",(void*)f_6478},
{"f_5913:expand_2escm",(void*)f_5913},
{"f_5671:expand_2escm",(void*)f_5671},
{"f_10908:expand_2escm",(void*)f_10908},
{"f_6475:expand_2escm",(void*)f_6475},
{"f_10901:expand_2escm",(void*)f_10901},
{"f_6612:expand_2escm",(void*)f_6612},
{"f_4023:expand_2escm",(void*)f_4023},
{"f_4303:expand_2escm",(void*)f_4303},
{"f_10911:expand_2escm",(void*)f_10911},
{"f_10914:expand_2escm",(void*)f_10914},
{"f_10404:expand_2escm",(void*)f_10404},
{"f_10919:expand_2escm",(void*)f_10919},
{"f_4309:expand_2escm",(void*)f_4309},
{"f_6638:expand_2escm",(void*)f_6638},
{"f_6633:expand_2escm",(void*)f_6633},
{"f_4315:expand_2escm",(void*)f_4315},
{"f_6916:expand_2escm",(void*)f_6916},
{"f_6911:expand_2escm",(void*)f_6911},
{"f_4326:expand_2escm",(void*)f_4326},
{"f_7750:expand_2escm",(void*)f_7750},
{"f_9295:expand_2escm",(void*)f_9295},
{"f_5012:expand_2escm",(void*)f_5012},
{"f_6904:expand_2escm",(void*)f_6904},
{"f_6604:expand_2escm",(void*)f_6604},
{"f_4926:expand_2escm",(void*)f_4926},
{"f_4073:expand_2escm",(void*)f_4073},
{"f_4921:expand_2escm",(void*)f_4921},
{"f_10201:expand_2escm",(void*)f_10201},
{"f_4918:expand_2escm",(void*)f_4918},
{"f_4915:expand_2escm",(void*)f_4915},
{"f_7775:expand_2escm",(void*)f_7775},
{"f_4912:expand_2escm",(void*)f_4912},
{"f_11832:expand_2escm",(void*)f_11832},
{"f_11830:expand_2escm",(void*)f_11830},
{"f_7446:expand_2escm",(void*)f_7446},
{"f_9017:expand_2escm",(void*)f_9017},
{"f_11842:expand_2escm",(void*)f_11842},
{"f_11840:expand_2escm",(void*)f_11840},
{"f_7449:expand_2escm",(void*)f_7449},
{"f_3884:expand_2escm",(void*)f_3884},
{"f_3882:expand_2escm",(void*)f_3882},
{"f_7793:expand_2escm",(void*)f_7793},
{"f_11642:expand_2escm",(void*)f_11642},
{"f_6818:expand_2escm",(void*)f_6818},
{"f_3897:expand_2escm",(void*)f_3897},
{"f_11697:expand_2escm",(void*)f_11697},
{"f_11690:expand_2escm",(void*)f_11690},
{"f_6802:expand_2escm",(void*)f_6802},
{"f_6804:expand_2escm",(void*)f_6804},
{"f_4575:expand_2escm",(void*)f_4575},
{"f_4713:expand_2escm",(void*)f_4713},
{"f_10735:expand_2escm",(void*)f_10735},
{"f_10738:expand_2escm",(void*)f_10738},
{"f_11677:expand_2escm",(void*)f_11677},
{"f_5081:expand_2escm",(void*)f_5081},
{"f_11670:expand_2escm",(void*)f_11670},
{"f_10742:expand_2escm",(void*)f_10742},
{"f_10748:expand_2escm",(void*)f_10748},
{"f_4597:expand_2escm",(void*)f_4597},
{"f_4599:expand_2escm",(void*)f_4599},
{"f_11681:expand_2escm",(void*)f_11681},
{"f_4709:expand_2escm",(void*)f_4709},
{"f_4705:expand_2escm",(void*)f_4705},
{"f_10751:expand_2escm",(void*)f_10751},
{"f_10757:expand_2escm",(void*)f_10757},
{"f_9783:expand_2escm",(void*)f_9783},
{"f_9785:expand_2escm",(void*)f_9785},
{"f_6934:expand_2escm",(void*)f_6934},
{"f_9798:expand_2escm",(void*)f_9798},
{"f_9796:expand_2escm",(void*)f_9796},
{"f_6927:expand_2escm",(void*)f_6927},
{"f_6920:expand_2escm",(void*)f_6920},
{"f_7789:expand_2escm",(void*)f_7789},
{"f_9241:expand_2escm",(void*)f_9241},
{"f_9762:expand_2escm",(void*)f_9762},
{"f_9772:expand_2escm",(void*)f_9772},
{"f_9770:expand_2escm",(void*)f_9770},
{"f_9962:expand_2escm",(void*)f_9962},
{"f_10850:expand_2escm",(void*)f_10850},
{"f_9744:expand_2escm",(void*)f_9744},
{"f_9746:expand_2escm",(void*)f_9746},
{"f_9220:expand_2escm",(void*)f_9220},
{"f_5884:expand_2escm",(void*)f_5884},
{"f_7479:expand_2escm",(void*)f_7479},
{"f_9754:expand_2escm",(void*)f_9754},
{"f_9946:expand_2escm",(void*)f_9946},
{"f_10833:expand_2escm",(void*)f_10833},
{"f_8855:expand_2escm",(void*)f_8855},
{"f_8341:expand_2escm",(void*)f_8341},
{"f_5864:expand_2escm",(void*)f_5864},
{"f_6822:expand_2escm",(void*)f_6822},
{"f_8348:expand_2escm",(void*)f_8348},
{"f_10848:expand_2escm",(void*)f_10848},
{"f_9573:expand_2escm",(void*)f_9573},
{"f_9579:expand_2escm",(void*)f_9579},
{"f_7428:expand_2escm",(void*)f_7428},
{"f_8849:expand_2escm",(void*)f_8849},
{"f_11656:expand_2escm",(void*)f_11656},
{"f_11653:expand_2escm",(void*)f_11653},
{"f_9582:expand_2escm",(void*)f_9582},
{"f_5843:expand_2escm",(void*)f_5843},
{"f_5846:expand_2escm",(void*)f_5846},
{"f_5849:expand_2escm",(void*)f_5849},
{"f_8327:expand_2escm",(void*)f_8327},
{"f_9986:expand_2escm",(void*)f_9986},
{"f_9984:expand_2escm",(void*)f_9984},
{"f_11206:expand_2escm",(void*)f_11206},
{"f_5851:expand_2escm",(void*)f_5851},
{"f_3933:expand_2escm",(void*)f_3933},
{"f_4725:expand_2escm",(void*)f_4725},
{"f_8894:expand_2escm",(void*)f_8894},
{"f_8481:expand_2escm",(void*)f_8481},
{"f_8485:expand_2escm",(void*)f_8485},
{"f_7903:expand_2escm",(void*)f_7903},
{"f_7907:expand_2escm",(void*)f_7907},
{"f_8897:expand_2escm",(void*)f_8897},
{"f_7912:expand_2escm",(void*)f_7912},
{"f_7918:expand_2escm",(void*)f_7918},
{"f_4371:expand_2escm",(void*)f_4371},
{"f_8477:expand_2escm",(void*)f_8477},
{"f_11190:expand_2escm",(void*)f_11190},
{"f_10803:expand_2escm",(void*)f_10803},
{"f_5949:expand_2escm",(void*)f_5949},
{"f_10800:expand_2escm",(void*)f_10800},
{"f_9519:expand_2escm",(void*)f_9519},
{"f_9516:expand_2escm",(void*)f_9516},
{"f_9513:expand_2escm",(void*)f_9513},
{"f_9285:expand_2escm",(void*)f_9285},
{"f_5636:expand_2escm",(void*)f_5636},
{"f_9526:expand_2escm",(void*)f_9526},
{"f_11178:expand_2escm",(void*)f_11178},
{"f_9211:expand_2escm",(void*)f_9211},
{"f_9213:expand_2escm",(void*)f_9213},
{"f_4343:expand_2escm",(void*)f_4343},
{"f_4195:expand_2escm",(void*)f_4195},
{"f_4197:expand_2escm",(void*)f_4197},
{"f_9107:expand_2escm",(void*)f_9107},
{"f_9265:expand_2escm",(void*)f_9265},
{"f_4337:expand_2escm",(void*)f_4337},
{"f_9272:expand_2escm",(void*)f_9272},
{"f_9279:expand_2escm",(void*)f_9279},
{"f_9073:expand_2escm",(void*)f_9073},
{"f_4174:expand_2escm",(void*)f_4174},
{"f_9564:expand_2escm",(void*)f_9564},
{"f_9566:expand_2escm",(void*)f_9566},
{"f_8384:expand_2escm",(void*)f_8384},
{"f_4184:expand_2escm",(void*)f_4184},
{"f_9536:expand_2escm",(void*)f_9536},
{"f_8407:expand_2escm",(void*)f_8407},
{"f_9534:expand_2escm",(void*)f_9534},
{"f_8373:expand_2escm",(void*)f_8373},
{"f_8191:expand_2escm",(void*)f_8191},
{"f_8379:expand_2escm",(void*)f_8379},
{"f_8377:expand_2escm",(void*)f_8377},
{"f_8199:expand_2escm",(void*)f_8199},
{"f_8195:expand_2escm",(void*)f_8195},
{"f_9543:expand_2escm",(void*)f_9543},
{"f_9540:expand_2escm",(void*)f_9540},
{"f_7926:expand_2escm",(void*)f_7926},
{"f_8369:expand_2escm",(void*)f_8369},
{"f_10109:expand_2escm",(void*)f_10109},
{"f_10107:expand_2escm",(void*)f_10107},
{"f_8172:expand_2escm",(void*)f_8172},
{"f_9939:expand_2escm",(void*)f_9939},
{"f_8441:expand_2escm",(void*)f_8441},
{"f_8176:expand_2escm",(void*)f_8176},
{"f_10113:expand_2escm",(void*)f_10113},
{"f_10625:expand_2escm",(void*)f_10625},
{"f_10627:expand_2escm",(void*)f_10627},
{"f_9912:expand_2escm",(void*)f_9912},
{"f_8109:expand_2escm",(void*)f_8109},
{"f_8103:expand_2escm",(void*)f_8103},
{"f_8106:expand_2escm",(void*)f_8106},
{"f_4530:expand_2escm",(void*)f_4530},
{"f_8100:expand_2escm",(void*)f_8100},
{"f_4940:expand_2escm",(void*)f_4940},
{"f_4944:expand_2escm",(void*)f_4944},
{"f_9826:expand_2escm",(void*)f_9826},
{"f_5998:expand_2escm",(void*)f_5998},
{"f_4563:expand_2escm",(void*)f_4563},
{"f_9042:expand_2escm",(void*)f_9042},
{"f_9047:expand_2escm",(void*)f_9047},
{"f_9021:expand_2escm",(void*)f_9021},
{"f_4101:expand_2escm",(void*)f_4101},
{"f_5990:expand_2escm",(void*)f_5990},
{"f_4105:expand_2escm",(void*)f_4105},
{"f_4554:expand_2escm",(void*)f_4554},
{"f_4156:expand_2escm",(void*)f_4156},
{"f_7005:expand_2escm",(void*)f_7005},
{"f_7003:expand_2escm",(void*)f_7003},
{"f_4956:expand_2escm",(void*)f_4956},
{"f_8142:expand_2escm",(void*)f_8142},
{"f_8145:expand_2escm",(void*)f_8145},
{"f_7011:expand_2escm",(void*)f_7011},
{"f_8148:expand_2escm",(void*)f_8148},
{"f_9038:expand_2escm",(void*)f_9038},
{"f_9088:expand_2escm",(void*)f_9088},
{"f_4149:expand_2escm",(void*)f_4149},
{"f_4146:expand_2escm",(void*)f_4146},
{"f_4142:expand_2escm",(void*)f_4142},
{"f_10255:expand_2escm",(void*)f_10255},
{"f_8121:expand_2escm",(void*)f_8121},
{"f_8124:expand_2escm",(void*)f_8124},
{"f_10588:expand_2escm",(void*)f_10588},
{"f_8127:expand_2escm",(void*)f_8127},
{"f_10224:expand_2escm",(void*)f_10224},
{"f_8150:expand_2escm",(void*)f_8150},
{"f_8157:expand_2escm",(void*)f_8157},
{"f_4122:expand_2escm",(void*)f_4122},
{"f_10234:expand_2escm",(void*)f_10234},
{"f_8181:expand_2escm",(void*)f_8181},
{"f_4360:expand_2escm",(void*)f_4360},
{"f_8187:expand_2escm",(void*)f_8187},
{"f_8130:expand_2escm",(void*)f_8130},
{"f_10535:expand_2escm",(void*)f_10535},
{"f_8133:expand_2escm",(void*)f_8133},
{"f_10693:expand_2escm",(void*)f_10693},
{"f_10690:expand_2escm",(void*)f_10690},
{"f_10537:expand_2escm",(void*)f_10537},
{"f_10696:expand_2escm",(void*)f_10696},
{"f_10699:expand_2escm",(void*)f_10699},
{"f_8139:expand_2escm",(void*)f_8139},
{"f_8136:expand_2escm",(void*)f_8136},
{"f_10294:expand_2escm",(void*)f_10294},
{"f_10264:expand_2escm",(void*)f_10264},
{"f_10676:expand_2escm",(void*)f_10676},
{"f_10678:expand_2escm",(void*)f_10678},
{"f_6532:expand_2escm",(void*)f_6532},
{"f_10275:expand_2escm",(void*)f_10275},
{"f_4768:expand_2escm",(void*)f_4768},
{"f_10050:expand_2escm",(void*)f_10050},
{"f_10682:expand_2escm",(void*)f_10682},
{"f_10066:expand_2escm",(void*)f_10066},
{"f_10245:expand_2escm",(void*)f_10245},
{"f_4796:expand_2escm",(void*)f_4796},
{"f_3979:expand_2escm",(void*)f_3979},
{"f_4782:expand_2escm",(void*)f_4782},
{"f_9816:expand_2escm",(void*)f_9816},
{"f_9814:expand_2escm",(void*)f_9814},
{"f_9811:expand_2escm",(void*)f_9811},
{"f_9808:expand_2escm",(void*)f_9808},
{"f_9805:expand_2escm",(void*)f_9805},
{"f_6285:expand_2escm",(void*)f_6285},
{"f_10092:expand_2escm",(void*)f_10092},
{"f_10286:expand_2escm",(void*)f_10286},
{"f_4802:expand_2escm",(void*)f_4802},
{"f_4808:expand_2escm",(void*)f_4808},
{"f_5316:expand_2escm",(void*)f_5316},
{"f_10210:expand_2escm",(void*)f_10210},
{"f_6292:expand_2escm",(void*)f_6292},
{"f_5403:expand_2escm",(void*)f_5403},
{"f_6299:expand_2escm",(void*)f_6299},
{"f_8007:expand_2escm",(void*)f_8007},
{"f_8005:expand_2escm",(void*)f_8005},
{"f_10086:expand_2escm",(void*)f_10086},
{"f_10088:expand_2escm",(void*)f_10088},
{"f_4778:expand_2escm",(void*)f_4778},
{"f_4987:expand_2escm",(void*)f_4987},
{"f_6557:expand_2escm",(void*)f_6557},
{"f_6555:expand_2escm",(void*)f_6555},
{"f_6204:expand_2escm",(void*)f_6204},
{"f_6096:expand_2escm",(void*)f_6096},
{"f_5700:expand_2escm",(void*)f_5700},
{"f_7972:expand_2escm",(void*)f_7972},
{"f_7975:expand_2escm",(void*)f_7975},
{"f_7978:expand_2escm",(void*)f_7978},
{"f_6560:expand_2escm",(void*)f_6560},
{"f_6086:expand_2escm",(void*)f_6086},
{"f_6227:expand_2escm",(void*)f_6227},
{"f_7982:expand_2escm",(void*)f_7982},
{"f_6222:expand_2escm",(void*)f_6222},
{"f_7988:expand_2escm",(void*)f_7988},
{"f_7985:expand_2escm",(void*)f_7985},
{"f_5704:expand_2escm",(void*)f_5704},
{"f_5720:expand_2escm",(void*)f_5720},
{"f_7991:expand_2escm",(void*)f_7991},
{"f_7997:expand_2escm",(void*)f_7997},
{"f_7994:expand_2escm",(void*)f_7994},
{"f_10971:expand_2escm",(void*)f_10971},
{"f_10977:expand_2escm",(void*)f_10977},
{"f_10974:expand_2escm",(void*)f_10974},
{"f_5716:expand_2escm",(void*)f_5716},
{"f_6022:expand_2escm",(void*)f_6022},
{"f_6024:expand_2escm",(void*)f_6024},
{"f_5713:expand_2escm",(void*)f_5713},
{"f_6243:expand_2escm",(void*)f_6243},
{"f_6240:expand_2escm",(void*)f_6240},
{"f_10566:expand_2escm",(void*)f_10566},
{"f_10995:expand_2escm",(void*)f_10995},
{"f_5505:expand_2escm",(void*)f_5505},
{"f_5509:expand_2escm",(void*)f_5509},
{"f_7948:expand_2escm",(void*)f_7948},
{"f_6072:expand_2escm",(void*)f_6072},
{"f_3704:expand_2escm",(void*)f_3704},
{"f_5520:expand_2escm",(void*)f_5520},
{"f_3623:expand_2escm",(void*)f_3623},
{"f_3629:expand_2escm",(void*)f_3629},
{"f_3627:expand_2escm",(void*)f_3627},
{"f_5729:expand_2escm",(void*)f_5729},
{"f_3615:expand_2escm",(void*)f_3615},
{"f_3619:expand_2escm",(void*)f_3619},
{"f_7291:expand_2escm",(void*)f_7291},
{"f_10666:expand_2escm",(void*)f_10666},
{"f_7632:expand_2escm",(void*)f_7632},
{"f_8671:expand_2escm",(void*)f_8671},
{"f_10631:expand_2escm",(void*)f_10631},
{"f_9688:expand_2escm",(void*)f_9688},
{"f_3710:expand_2escm",(void*)f_3710},
{"f_10641:expand_2escm",(void*)f_10641},
{"f_9840:expand_2escm",(void*)f_9840},
{"f_9877:expand_2escm",(void*)f_9877},
{"f_7624:expand_2escm",(void*)f_7624},
{"f_5335:expand_2escm",(void*)f_5335},
{"f_8647:expand_2escm",(void*)f_8647},
{"f_8965:expand_2escm",(void*)f_8965},
{"f_7080:expand_2escm",(void*)f_7080},
{"f_9644:expand_2escm",(void*)f_9644},
{"f_9647:expand_2escm",(void*)f_9647},
{"f_9859:expand_2escm",(void*)f_9859},
{"f_9641:expand_2escm",(void*)f_9641},
{"f_9659:expand_2escm",(void*)f_9659},
{"f_9494:expand_2escm",(void*)f_9494},
{"f_9471:expand_2escm",(void*)f_9471},
{"f_8942:expand_2escm",(void*)f_8942},
{"f_8944:expand_2escm",(void*)f_8944},
{"f_8774:expand_2escm",(void*)f_8774},
{"f_8762:expand_2escm",(void*)f_8762},
{"f_7032:expand_2escm",(void*)f_7032},
{"f_7037:expand_2escm",(void*)f_7037},
{"f_7234:expand_2escm",(void*)f_7234},
{"f_9473:expand_2escm",(void*)f_9473},
{"f_9477:expand_2escm",(void*)f_9477},
{"f_5496:expand_2escm",(void*)f_5496},
{"f_8758:expand_2escm",(void*)f_8758},
{"f_10942:expand_2escm",(void*)f_10942},
{"f_10946:expand_2escm",(void*)f_10946},
{"f_9507:expand_2escm",(void*)f_9507},
{"f_9509:expand_2escm",(void*)f_9509},
{"f_9897:expand_2escm",(void*)f_9897},
{"f_8745:expand_2escm",(void*)f_8745},
{"f_7056:expand_2escm",(void*)f_7056},
{"f_10952:expand_2escm",(void*)f_10952},
{"f_10955:expand_2escm",(void*)f_10955},
{"f_10958:expand_2escm",(void*)f_10958},
{"f_11242:expand_2escm",(void*)f_11242},
{"f_11240:expand_2escm",(void*)f_11240},
{"f_7814:expand_2escm",(void*)f_7814},
{"f_7810:expand_2escm",(void*)f_7810},
{"f_7061:expand_2escm",(void*)f_7061},
{"f_5598:expand_2escm",(void*)f_5598},
{"f_10961:expand_2escm",(void*)f_10961},
{"f_10965:expand_2escm",(void*)f_10965},
{"f_8592:expand_2escm",(void*)f_8592},
{"f_10702:expand_2escm",(void*)f_10702},
{"f_10713:expand_2escm",(void*)f_10713},
{"f_10715:expand_2escm",(void*)f_10715},
{"f_8588:expand_2escm",(void*)f_8588},
{"f_10729:expand_2escm",(void*)f_10729},
{"f_9419:expand_2escm",(void*)f_9419},
{"f_11284:expand_2escm",(void*)f_11284},
{"f_5586:expand_2escm",(void*)f_5586},
{"f_9421:expand_2escm",(void*)f_9421},
{"f_6662:expand_2escm",(void*)f_6662},
{"f_11265:expand_2escm",(void*)f_11265},
{"f_6658:expand_2escm",(void*)f_6658},
{"f_4892:expand_2escm",(void*)f_4892},
{"f_4895:expand_2escm",(void*)f_4895},
{"f_9455:expand_2escm",(void*)f_9455},
{"f_9459:expand_2escm",(void*)f_9459},
{"f_4223:expand_2escm",(void*)f_4223},
{"f_8236:expand_2escm",(void*)f_8236},
{"f_6677:expand_2escm",(void*)f_6677},
{"f_9463:expand_2escm",(void*)f_9463},
{"f_11294:expand_2escm",(void*)f_11294},
{"f_9467:expand_2escm",(void*)f_9467},
{"f_11292:expand_2escm",(void*)f_11292},
{"f_4234:expand_2escm",(void*)f_4234},
{"f_8232:expand_2escm",(void*)f_8232},
{"f_4870:expand_2escm",(void*)f_4870},
{"f_9431:expand_2escm",(void*)f_9431},
{"f_4246:expand_2escm",(void*)f_4246},
{"f_4248:expand_2escm",(void*)f_4248},
{"f_4242:expand_2escm",(void*)f_4242},
{"f_3646:expand_2escm",(void*)f_3646},
{"f_8219:expand_2escm",(void*)f_8219},
{"f_6691:expand_2escm",(void*)f_6691},
{"f_6698:expand_2escm",(void*)f_6698},
{"f_8212:expand_2escm",(void*)f_8212},
{"f_8249:expand_2escm",(void*)f_8249},
{"f_4851:expand_2escm",(void*)f_4851},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  sprintf		1
S|  ##sys#map		6
S|  for-each		3
S|  map		10
o|eliminated procedure checks: 549 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|specializations:
o|  1 (zero? fixnum)
o|  1 (cdddr (pair * (pair * pair)))
o|  1 (##sys#check-output-port * * *)
o|  2 (vector-length vector)
o|  8 (eqv? (not float) *)
o|  2 (cadr (pair * pair))
o|  8 (cddr (pair * pair))
o|  1 (cdadr (pair * (pair pair *)))
o|  3 (caar (pair pair *))
o|  1 (>= fixnum fixnum)
o|  2 (length list)
o|  15 (eqv? * (not float))
o|  1 (##sys#call-with-values (procedure () *) *)
o|  2 (cdar (pair pair *))
o|  11 (##sys#check-list (or pair list) *)
o|  1 (set-cdr! pair *)
o|  75 (cdr pair)
o|  1 (set-car! pair *)
o|  58 (car pair)
o|Removed `not' forms: 35 
o|inlining procedure: k3631 
o|inlining procedure: k3631 
o|contracted procedure: "(expand.scm:81) g257258" 
o|inlining procedure: k3648 
o|inlining procedure: k3648 
o|contracted procedure: "(expand.scm:95) g288289" 
o|contracted procedure: "(expand.scm:94) g283284" 
o|contracted procedure: "(expand.scm:93) g279280" 
o|inlining procedure: k3693 
o|inlining procedure: k3693 
o|inlining procedure: k3715 
o|inlining procedure: k3715 
o|inlining procedure: k3737 
o|inlining procedure: k3737 
o|contracted procedure: k3743 
o|inlining procedure: k3746 
o|inlining procedure: k3746 
o|contracted procedure: "(expand.scm:109) g321322" 
o|contracted procedure: "(expand.scm:108) g310311" 
o|inlining procedure: k3752 
o|inlining procedure: k3752 
o|inlining procedure: k3811 
o|inlining procedure: k3811 
o|inlining procedure: k3886 
o|contracted procedure: "(expand.scm:136) g424434" 
o|inlining procedure: k3886 
o|inlining procedure: k3935 
o|contracted procedure: "(expand.scm:130) g382390" 
o|contracted procedure: "(expand.scm:134) g400401" 
o|contracted procedure: "(expand.scm:133) g396397" 
o|inlining procedure: k3935 
o|inlining procedure: k3981 
o|inlining procedure: k3981 
o|contracted procedure: k4028 
o|inlining procedure: k4025 
o|inlining procedure: k4041 
o|inlining procedure: k4041 
o|inlining procedure: k4059 
o|inlining procedure: k4059 
o|contracted procedure: "(expand.scm:144) g461462" 
o|inlining procedure: k4025 
o|inlining procedure: k4110 
o|inlining procedure: k4110 
o|inlining procedure: k4153 
o|inlining procedure: k4153 
o|inlining procedure: k4208 
o|inlining procedure: k4208 
o|removed unused formal parameters: (me2542) 
o|inlining procedure: k4250 
o|inlining procedure: k4250 
o|removed unused parameter to known procedure: me2542 loop540 
o|inlining procedure: k4321 
o|inlining procedure: k4345 
o|inlining procedure: k4345 
o|inlining procedure: k4388 
o|inlining procedure: k4388 
o|inlining procedure: k4321 
o|inlining procedure: k4417 
o|inlining procedure: k4417 
o|contracted procedure: k4437 
o|merged explicitly consed rest parameter: args566598 
o|consed rest parameter at call site: tmp23084 1 
o|contracted procedure: k4494 
o|inlining procedure: k4491 
o|inlining procedure: k4491 
o|inlining procedure: k4532 
o|inlining procedure: k4555 
o|inlining procedure: k4601 
o|inlining procedure: k4601 
o|inlining procedure: k4668 
o|contracted procedure: "(expand.scm:285) g644653" 
o|inlining procedure: k4668 
o|inlining procedure: k4555 
o|inlining procedure: k4714 
o|inlining procedure: k4714 
o|inlining procedure: k4744 
o|contracted procedure: "(expand.scm:290) g694695" 
o|inlining procedure: k4744 
o|inlining procedure: k4762 
o|inlining procedure: k4762 
o|inlining procedure: k4532 
o|inlining procedure: k4810 
o|inlining procedure: k4810 
o|inlining procedure: k4853 
o|inlining procedure: k4879 
o|inlining procedure: k4879 
o|substituted constant variable: a4886 
o|substituted constant variable: a4888 
o|substituted constant variable: a4890 
o|inlining procedure: k4853 
o|inlining procedure: k4928 
o|inlining procedure: k4945 
o|inlining procedure: k4945 
o|inlining procedure: k4988 
o|inlining procedure: k4988 
o|inlining procedure: k5041 
o|inlining procedure: k5041 
o|contracted procedure: k5044 
o|contracted procedure: k5050 
o|inlining procedure: k5053 
o|inlining procedure: k5053 
o|inlining procedure: k5110 
o|substituted constant variable: %lambda774 
o|inlining procedure: k5110 
o|contracted procedure: "(expand.scm:365) ->keyword768" 
o|inlining procedure: k5148 
o|inlining procedure: k5148 
o|inlining procedure: k4928 
o|inlining procedure: k5196 
o|inlining procedure: k5196 
o|contracted procedure: k5216 
o|inlining procedure: k5213 
o|inlining procedure: k5241 
o|inlining procedure: k5241 
o|inlining procedure: k5257 
o|inlining procedure: k5269 
o|contracted procedure: k5287 
o|inlining procedure: k5269 
o|inlining procedure: k5257 
o|inlining procedure: k5317 
o|inlining procedure: k5317 
o|contracted procedure: k5329 
o|inlining procedure: k5336 
o|inlining procedure: k5355 
o|inlining procedure: k5355 
o|substituted constant variable: a5393 
o|substituted constant variable: a5395 
o|substituted constant variable: a5397 
o|inlining procedure: k5336 
o|inlining procedure: k5404 
o|inlining procedure: k5404 
o|inlining procedure: k5426 
o|inlining procedure: k5426 
o|substituted constant variable: a5443 
o|substituted constant variable: a5445 
o|substituted constant variable: a5447 
o|inlining procedure: k5454 
o|inlining procedure: k5454 
o|substituted constant variable: a5470 
o|substituted constant variable: a5472 
o|substituted constant variable: a5474 
o|contracted procedure: k5481 
o|inlining procedure: k5478 
o|inlining procedure: k5478 
o|inlining procedure: k5213 
o|inlining procedure: k5528 
o|inlining procedure: k5528 
o|inlining procedure: k5537 
o|inlining procedure: k5537 
o|inlining procedure: k5546 
o|inlining procedure: k5546 
o|inlining procedure: k5567 
o|inlining procedure: k5567 
o|substituted constant variable: a5580 
o|substituted constant variable: a5582 
o|substituted constant variable: a5584 
o|inlining procedure: k5588 
o|contracted procedure: k5603 
o|inlining procedure: k5600 
o|inlining procedure: k5650 
o|inlining procedure: k5650 
o|inlining procedure: k5600 
o|inlining procedure: k5588 
o|inlining procedure: k5853 
o|contracted procedure: "(expand.scm:484) g10221032" 
o|inlining procedure: k5760 
o|contracted procedure: "(expand.scm:490) g10751085" 
o|inlining procedure: k5760 
o|inlining procedure: k5809 
o|inlining procedure: k5809 
o|inlining procedure: k5853 
o|inlining procedure: k5902 
o|contracted procedure: "(expand.scm:483) g986996" 
o|inlining procedure: k5902 
o|inlining procedure: k5951 
o|contracted procedure: "(expand.scm:480) g959968" 
o|inlining procedure: k5951 
o|inlining procedure: k6002 
o|inlining procedure: k6026 
o|inlining procedure: k6026 
o|inlining procedure: k6002 
o|contracted procedure: k6061 
o|inlining procedure: k6067 
o|inlining procedure: k6084 
o|inlining procedure: k6084 
o|inlining procedure: k6067 
o|inlining procedure: k6140 
o|inlining procedure: k6140 
o|substituted constant variable: a6162 
o|contracted procedure: k6189 
o|inlining procedure: k6186 
o|contracted procedure: k6208 
o|inlining procedure: k6214 
o|contracted procedure: k6235 
o|inlining procedure: k6232 
o|inlining procedure: k6232 
o|inlining procedure: k6256 
o|inlining procedure: k6256 
o|inlining procedure: k6214 
o|inlining procedure: k6347 
o|inlining procedure: k6347 
o|inlining procedure: k6392 
o|inlining procedure: k6392 
o|inlining procedure: k6430 
o|inlining procedure: k6430 
o|inlining procedure: k6186 
o|contracted procedure: k6483 
o|inlining procedure: k6480 
o|inlining procedure: k6527 
o|inlining procedure: k6527 
o|inlining procedure: k6480 
o|inlining procedure: k6504 
o|inlining procedure: k6504 
o|inlining procedure: k6550 
o|inlining procedure: k6550 
o|inlining procedure: k6562 
o|inlining procedure: k6562 
o|inlining procedure: k6678 
o|inlining procedure: k6678 
o|inlining procedure: k6709 
o|inlining procedure: k6709 
o|inlining procedure: k6771 
o|inlining procedure: k6771 
o|inlining procedure: k6806 
o|inlining procedure: k6806 
o|contracted procedure: "(expand.scm:649) syntax-imports1265" 
o|inlining procedure: k6640 
o|inlining procedure: k6640 
o|inlining procedure: k6852 
o|inlining procedure: k6862 
o|inlining procedure: k6879 
o|inlining procedure: k6879 
o|inlining procedure: k6862 
o|inlining procedure: k6852 
o|inlining procedure: k6906 
o|inlining procedure: k6906 
o|inlining procedure: k6925 
o|inlining procedure: k6925 
o|propagated global variable: sexp1358 ##sys#syntax-error-culprit 
o|inlining procedure: k6948 
o|inlining procedure: k6948 
o|inlining procedure: k6960 
o|inlining procedure: k6960 
o|inlining procedure: k6976 
o|contracted procedure: k6992 
o|inlining procedure: k6989 
o|inlining procedure: k6989 
o|inlining procedure: k6976 
o|inlining procedure: k7016 
o|inlining procedure: k7016 
o|inlining procedure: k7039 
o|inlining procedure: k7063 
o|inlining procedure: k7063 
o|contracted procedure: k7101 
o|inlining procedure: k7098 
o|inlining procedure: k7098 
o|inlining procedure: k7121 
o|inlining procedure: k7121 
o|inlining procedure: k7039 
o|contracted procedure: k7145 
o|inlining procedure: k7142 
o|inlining procedure: k7142 
o|inlining procedure: k7155 
o|inlining procedure: k7167 
o|inlining procedure: k7167 
o|inlining procedure: k7185 
o|inlining procedure: k7185 
o|inlining procedure: k7203 
o|inlining procedure: k7203 
o|inlining procedure: k7221 
o|inlining procedure: k7221 
o|inlining procedure: k7243 
o|inlining procedure: k7243 
o|substituted constant variable: a7256 
o|substituted constant variable: a7258 
o|substituted constant variable: a7260 
o|substituted constant variable: a7262 
o|substituted constant variable: a7264 
o|substituted constant variable: a7266 
o|substituted constant variable: a7268 
o|substituted constant variable: a7270 
o|inlining procedure: k7155 
o|contracted procedure: k7274 
o|contracted procedure: k7283 
o|inlining procedure: k7280 
o|inlining procedure: k7280 
o|inlining procedure: k7361 
o|inlining procedure: k7361 
o|contracted procedure: k7402 
o|inlining procedure: k7399 
o|contracted procedure: "(expand.scm:778) g14501451" 
o|inlining procedure: k7430 
o|contracted procedure: "(expand.scm:798) g14751476" 
o|contracted procedure: "(expand.scm:797) g14711472" 
o|inlining procedure: k7430 
o|inlining procedure: k7425 
o|inlining procedure: k7425 
o|inlining procedure: k7399 
o|inlining procedure: k7515 
o|inlining procedure: k7530 
o|inlining procedure: k7530 
o|inlining procedure: k7515 
o|inlining procedure: k7553 
o|inlining procedure: k7574 
o|inlining procedure: k7574 
o|inlining procedure: k7553 
o|inlining procedure: k7611 
o|inlining procedure: k7639 
o|inlining procedure: k7663 
o|inlining procedure: k7663 
o|contracted procedure: "(expand.scm:839) g15601561" 
o|contracted procedure: "(expand.scm:838) g15531554" 
o|inlining procedure: k7639 
o|inlining procedure: k7688 
o|inlining procedure: k7688 
o|inlining procedure: k7722 
o|inlining procedure: k7722 
o|removed unused parameter to known procedure: n1580 "(expand.scm:834) lookup21440" 
o|contracted procedure: "(expand.scm:833) g15341535" 
o|inlining procedure: k7728 
o|inlining procedure: k7728 
o|removed unused parameter to known procedure: n1580 "(expand.scm:831) lookup21440" 
o|contracted procedure: "(expand.scm:830) g15241525" 
o|inlining procedure: k7611 
o|removed unused formal parameters: (n1580) 
o|inlining procedure: k7752 
o|inlining procedure: k7752 
o|inlining procedure: k7777 
o|inlining procedure: k7777 
o|contracted procedure: k7818 
o|inlining procedure: k7815 
o|contracted procedure: "(expand.scm:871) g16051606" 
o|contracted procedure: k7844 
o|inlining procedure: k7841 
o|inlining procedure: k7870 
o|contracted procedure: "(expand.scm:871) g16221623" 
o|inlining procedure: k7870 
o|contracted procedure: "(expand.scm:879) g16181619" 
o|inlining procedure: k7841 
o|inlining procedure: k7815 
o|inlining procedure: k7891 
o|inlining procedure: k7891 
o|inlining procedure: k7950 
o|contracted procedure: "(expand.scm:908) g16491656" 
o|contracted procedure: "(expand.scm:910) g16591660" 
o|inlining procedure: k7950 
o|inlining procedure: k8018 
o|inlining procedure: k8018 
o|removed side-effect free assignment to unused variable: %vector-length2434 
o|removed side-effect free assignment to unused variable: %vector-ref2435 
o|removed side-effect free assignment to unused variable: %null?2457 
o|removed side-effect free assignment to unused variable: %or2458 
o|removed side-effect free assignment to unused variable: %syntax-error2464 
o|inlining procedure: k8300 
o|inlining procedure: k8300 
o|inlining procedure: k8343 
o|inlining procedure: k8343 
o|inlining procedure: k8391 
o|inlining procedure: k8391 
o|inlining procedure: k8409 
o|inlining procedure: k8409 
o|inlining procedure: k8445 
o|inlining procedure: k8445 
o|inlining procedure: k8547 
o|inlining procedure: k8547 
o|inlining procedure: k8581 
o|inlining procedure: k8581 
o|inlining procedure: k8717 
o|inlining procedure: k8717 
o|inlining procedure: k8780 
o|inlining procedure: k8780 
o|inlining procedure: k8808 
o|inlining procedure: k8808 
o|inlining procedure: k8857 
o|inlining procedure: k8869 
o|inlining procedure: k8869 
o|inlining procedure: k8857 
o|inlining procedure: k8904 
o|inlining procedure: k8904 
o|substituted constant variable: %append2427 
o|inlining procedure: k8946 
o|inlining procedure: k8946 
o|substituted constant variable: %apply2428 
o|substituted constant variable: %append2427 
o|inlining procedure: k8980 
o|inlining procedure: k8980 
o|inlining procedure: k9005 
o|inlining procedure: k9005 
o|inlining procedure: k9049 
o|inlining procedure: k9049 
o|inlining procedure: k9093 
o|inlining procedure: k9093 
o|inlining procedure: k9126 
o|contracted procedure: k9141 
o|inlining procedure: k9147 
o|inlining procedure: k9147 
o|inlining procedure: k9126 
o|inlining procedure: k9182 
o|inlining procedure: k9182 
o|inlining procedure: k9215 
o|contracted procedure: k9230 
o|inlining procedure: k9227 
o|inlining procedure: k9227 
o|inlining procedure: k9215 
o|inlining procedure: k9243 
o|inlining procedure: k9243 
o|inlining procedure: k9267 
o|inlining procedure: k9267 
o|inlining procedure: k9297 
o|inlining procedure: k9297 
o|inlining procedure: k9340 
o|inlining procedure: k9340 
o|inlining procedure: k9382 
o|inlining procedure: k9394 
o|inlining procedure: k9394 
o|inlining procedure: k9382 
o|inlining procedure: k9423 
o|inlining procedure: k9423 
o|inlining procedure: k9517 
o|inlining procedure: k9517 
o|inlining procedure: k9574 
o|inlining procedure: k9595 
o|inlining procedure: k9595 
o|inlining procedure: k9574 
o|inlining procedure: k9683 
o|inlining procedure: k9683 
o|inlining procedure: k9703 
o|inlining procedure: k9703 
o|inlining procedure: k9828 
o|inlining procedure: k9828 
o|contracted procedure: k9844 
o|inlining procedure: k9854 
o|inlining procedure: k9866 
o|inlining procedure: k9866 
o|inlining procedure: k9854 
o|contracted procedure: k9901 
o|inlining procedure: k9898 
o|inlining procedure: k9898 
o|inlining procedure: k9913 
o|inlining procedure: k9913 
o|inlining procedure: k9934 
o|inlining procedure: k9934 
o|inlining procedure: k9964 
o|inlining procedure: k9988 
o|contracted procedure: "(expand.scm:1384) g22992308" 
o|inlining procedure: k9988 
o|inlining procedure: k9964 
o|contracted procedure: k10023 
o|contracted procedure: k10036 
o|inlining procedure: k10033 
o|inlining procedure: k10052 
o|inlining procedure: k10052 
o|inlining procedure: k10061 
o|inlining procedure: k10061 
o|inlining procedure: k10033 
o|inlining procedure: k10166 
o|inlining procedure: k10166 
o|contracted procedure: k10186 
o|inlining procedure: k10196 
o|inlining procedure: k10196 
o|inlining procedure: k10250 
o|inlining procedure: k10250 
o|inlining procedure: k10332 
o|inlining procedure: k10332 
o|inlining procedure: k10366 
o|inlining procedure: k10366 
o|inlining procedure: k10405 
o|contracted procedure: "(expand.scm:1280) g22282229" 
o|inlining procedure: k10405 
o|inlining procedure: k10539 
o|contracted procedure: "(expand.scm:1270) g21312140" 
o|inlining procedure: k10509 
o|inlining procedure: k10509 
o|inlining procedure: k10539 
o|inlining procedure: k10590 
o|contracted procedure: "(expand.scm:1259) g20972106" 
o|inlining procedure: k10590 
o|inlining procedure: k10643 
o|inlining procedure: k10643 
o|contracted procedure: k10720 
o|inlining procedure: k10717 
o|inlining procedure: k10743 
o|inlining procedure: k10743 
o|inlining procedure: k10852 
o|inlining procedure: k10852 
o|inlining procedure: k10717 
o|contracted procedure: k10924 
o|inlining procedure: k10921 
o|substituted constant variable: a10948 
o|substituted constant variable: a10949 
o|inlining procedure: k10966 
o|inlining procedure: k10966 
o|inlining procedure: k11013 
o|inlining procedure: k11013 
o|inlining procedure: k11149 
o|inlining procedure: k11149 
o|inlining procedure: k11161 
o|inlining procedure: k11161 
o|inlining procedure: k11173 
o|inlining procedure: k11173 
o|inlining procedure: k11185 
o|inlining procedure: k11185 
o|inlining procedure: k11194 
o|inlining procedure: k11194 
o|inlining procedure: k10921 
o|inlining procedure: k11247 
o|inlining procedure: k11247 
o|inlining procedure: k11299 
o|inlining procedure: k11299 
o|inlining procedure: k11342 
o|inlining procedure: k11342 
o|contracted procedure: k11525 
o|inlining procedure: k11522 
o|inlining procedure: k11522 
o|contracted procedure: "(expand.scm:1012) g17921793" 
o|contracted procedure: k11637 
o|inlining procedure: k11634 
o|inlining procedure: k11634 
o|inlining procedure: k11661 
o|inlining procedure: k11661 
o|contracted procedure: "(expand.scm:987) g17621763" 
o|propagated global variable: g17091710 ##sys#expand-import 
o|propagated global variable: g16951696 ##sys#expand-import 
o|propagated global variable: g16811682 ##sys#expand-import 
o|replaced variables: 1613 
o|removed binding forms: 496 
o|substituted constant variable: prop260 
o|removed call to pure procedure with unused result: "(expand.scm:96) void" 
o|substituted constant variable: prop291 
o|substituted constant variable: prop286 
o|substituted constant variable: prop282 
o|substituted constant variable: r369411852 
o|substituted constant variable: prop324 
o|substituted constant variable: prop313 
o|substituted constant variable: prop403 
o|inlining procedure: k3859 
o|inlining procedure: k3859 
o|substituted constant variable: prop399 
o|substituted constant variable: prop464 
o|substituted constant variable: r425111881 
o|substituted constant variable: r434611885 
o|substituted constant variable: r438911888 
o|removed call to pure procedure with unused result: "(expand.scm:246) void" 
o|removed call to pure procedure with unused result: "(expand.scm:206) void" 
o|removed call to pure procedure with unused result: "(expand.scm:203) void" 
o|removed call to pure procedure with unused result: "(expand.scm:203) void" 
o|inlining procedure: k4723 
o|substituted constant variable: prop697 
o|substituted constant variable: r474511915 
o|substituted constant variable: r485411926 
o|substituted constant variable: r505411939 
o|substituted constant variable: r511111942 
o|substituted constant variable: r511111942 
o|substituted constant variable: r545511967 
o|substituted constant variable: r547911968 
o|converted assignments to bindings: (err767) 
o|substituted constant variable: r565111982 
o|removed call to pure procedure with unused result: "(expand.scm:477) void" 
o|inlining procedure: k6084 
o|substituted constant variable: r614112006 
o|substituted constant variable: r625712013 
o|substituted constant variable: r625712013 
o|substituted constant variable: r643112021 
o|substituted constant variable: r652812025 
o|substituted constant variable: r650512027 
o|substituted constant variable: r655112030 
o|substituted constant variable: r680712039 
o|substituted constant variable: r664112041 
o|converted assignments to bindings: (outstr1278) 
o|substituted constant variable: r688012046 
o|substituted constant variable: r686312047 
o|substituted constant variable: r685312048 
o|substituted constant variable: r699012060 
o|substituted constant variable: r697712062 
o|substituted constant variable: r712212071 
o|removed call to pure procedure with unused result: "(expand.scm:788) void" 
o|removed call to pure procedure with unused result: "(expand.scm:799) void" 
o|removed call to pure procedure with unused result: "(expand.scm:803) void" 
o|substituted constant variable: prop1478 
o|substituted constant variable: prop1474 
o|removed call to pure procedure with unused result: "(expand.scm:807) void" 
o|removed call to pure procedure with unused result: "(expand.scm:812) void" 
o|removed call to pure procedure with unused result: "(expand.scm:778) void" 
o|inlining procedure: k7515 
o|substituted constant variable: r753112106 
o|inlining procedure: k7515 
o|inlining procedure: k7515 
o|inlining procedure: k7515 
o|substituted constant variable: r755412116 
o|substituted constant variable: prop1563 
o|substituted constant variable: prop1556 
o|inlining procedure: k7515 
o|inlining procedure: k7515 
o|substituted constant variable: prop1537 
o|substituted constant variable: prop1527 
o|removed call to pure procedure with unused result: "(expand.scm:778) void" 
o|substituted constant variable: r775312131 
o|removed call to pure procedure with unused result: "(expand.scm:873) void" 
o|removed call to pure procedure with unused result: "(expand.scm:878) void" 
o|removed call to pure procedure with unused result: "(expand.scm:880) void" 
o|removed call to pure procedure with unused result: "(expand.scm:885) void" 
o|substituted constant variable: prop1621 
o|removed call to pure procedure with unused result: "(expand.scm:876) void" 
o|substituted constant variable: prop1662 
o|removed side-effect free assignment to unused variable: %append2427 
o|removed side-effect free assignment to unused variable: %apply2428 
o|substituted constant variable: r839212152 
o|substituted constant variable: r898112178 
o|substituted constant variable: r914812187 
o|substituted constant variable: r922812192 
o|substituted constant variable: r921612194 
o|substituted constant variable: r924412196 
o|substituted constant variable: r926812198 
o|substituted constant variable: r934112201 
o|substituted constant variable: r959612217 
o|substituted constant variable: r970412224 
o|substituted constant variable: r989912231 
o|substituted constant variable: r1005312242 
o|substituted constant variable: r1071812272 
o|substituted constant variable: r1119512287 
o|substituted constant variable: r1092212288 
o|substituted constant variable: r1124812289 
o|substituted constant variable: r1130012291 
o|substituted constant variable: prop1795 
o|substituted constant variable: r1166212301 
o|substituted constant variable: r1166212301 
o|substituted constant variable: prop1765 
o|simplifications: ((let . 2)) 
o|replaced variables: 70 
o|removed binding forms: 1504 
o|inlining procedure: k3639 
o|contracted procedure: k3684 
o|substituted constant variable: prop40312317 
o|substituted constant variable: prop40312323 
o|contracted procedure: k4290 
o|contracted procedure: k4293 
o|contracted procedure: k4420 
o|removed call to pure procedure with unused result: "(expand.scm:246) void" 
o|contracted procedure: k4488 
o|inlining procedure: k5205 
o|inlining procedure: k5205 
o|contracted procedure: k5675 
o|contracted procedure: k7413 
o|contracted procedure: k7450 
o|contracted procedure: k7461 
o|contracted procedure: k7480 
o|contracted procedure: k7497 
o|contracted procedure: k7518 
o|substituted constant variable: r751612432 
o|removed call to pure procedure with unused result: "(expand.scm:778) void" 
o|substituted constant variable: r751612437 
o|removed call to pure procedure with unused result: "(expand.scm:778) void" 
o|substituted constant variable: r751612446 
o|removed call to pure procedure with unused result: "(expand.scm:778) void" 
o|substituted constant variable: r751612451 
o|removed call to pure procedure with unused result: "(expand.scm:778) void" 
o|substituted constant variable: r751612456 
o|removed call to pure procedure with unused result: "(expand.scm:778) void" 
o|substituted constant variable: r751612461 
o|removed call to pure procedure with unused result: "(expand.scm:778) void" 
o|contracted procedure: k7746 
o|contracted procedure: k7832 
o|contracted procedure: k7859 
o|contracted procedure: k7875 
o|contracted procedure: k7884 
o|contracted procedure: k7847 
o|inlining procedure: k9135 
o|inlining procedure: k9135 
o|inlining procedure: k9483 
o|inlining procedure: k9483 
o|replaced variables: 48 
o|removed binding forms: 166 
o|contracted procedure: k3668 
o|contracted procedure: k3676 
o|contracted procedure: k3681 
o|contracted procedure: k3729 
o|contracted procedure: k3734 
o|contracted procedure: k3850 
o|contracted procedure: k4033 
o|contracted procedure: k442011902 
o|contracted procedure: k7441 
o|contracted procedure: k751812436 
o|substituted constant variable: result150012433 
o|contracted procedure: k751812441 
o|substituted constant variable: result150012438 
o|contracted procedure: k751812450 
o|substituted constant variable: result150012447 
o|contracted procedure: k751812455 
o|substituted constant variable: result150012452 
o|contracted procedure: k7619 
o|contracted procedure: k7627 
o|contracted procedure: k7651 
o|contracted procedure: k7660 
o|contracted procedure: k751812460 
o|substituted constant variable: result150012457 
o|contracted procedure: k751812465 
o|substituted constant variable: result150012462 
o|inlining procedure: "(expand.scm:834) lookup21440" 
o|inlining procedure: "(expand.scm:831) lookup21440" 
o|contracted procedure: k7867 
o|substituted constant variable: r913612599 
o|substituted constant variable: r913612600 
o|contracted procedure: k11536 
o|contracted procedure: k11645 
o|replaced variables: 4 
o|removed binding forms: 103 
o|removed conditional forms: 2 
o|removed side-effect free assignment to unused variable: lookup21440 
o|replaced variables: 15 
o|removed binding forms: 20 
o|replaced variables: 10 
o|removed binding forms: 13 
o|inlining procedure: k3671 
o|inlining procedure: k3671 
o|replaced variables: 2 
o|removed binding forms: 3 
o|replaced variables: 1 
o|removed binding forms: 3 
o|replaced variables: 4 
o|removed binding forms: 1 
o|removed binding forms: 3 
o|simplifications: ((if . 50) (##core#call . 986)) 
o|  call simplifications:
o|    number?
o|    eof-object?
o|    fx-	2
o|    cdddr
o|    cadddr	2
o|    cddddr
o|    >=
o|    +	3
o|    =
o|    -
o|    <=
o|    boolean?
o|    char?	2
o|    cdar	2
o|    ##sys#immediate?
o|    vector-ref	5
o|    fx<	2
o|    not	4
o|    fx=	6
o|    memq	9
o|    caddr	11
o|    length	10
o|    fx<=	2
o|    ##sys#call-with-values
o|    cddr	10
o|    ##sys#list	161
o|    ##sys#cons	87
o|    list?	5
o|    cadr	35
o|    values	8
o|    ##sys#apply	2
o|    memv
o|    equal?	2
o|    string?	3
o|    ##sys#make-structure	2
o|    apply	3
o|    list	13
o|    set-car!	4
o|    procedure?
o|    ##sys#structure?	2
o|    caar	9
o|    eq?	74
o|    null?	49
o|    car	65
o|    ##sys#check-list	13
o|    assq	12
o|    symbol?	41
o|    vector?	13
o|    fx>=	5
o|    fx+	4
o|    cons	65
o|    ##sys#setslot	19
o|    pair?	88
o|    ##sys#slot	58
o|    ##sys#size	5
o|    fx>	5
o|    char=?
o|    cdr	50
o|contracted procedure: k3663 
o|contracted procedure: k3687 
o|contracted procedure: k3690 
o|contracted procedure: k3696 
o|contracted procedure: k3712 
o|contracted procedure: k3724 
o|contracted procedure: k3749 
o|contracted procedure: k3755 
o|contracted procedure: k3758 
o|contracted procedure: k3786 
o|contracted procedure: k3762 
o|contracted procedure: k3765 
o|contracted procedure: k3768 
o|contracted procedure: k3792 
o|contracted procedure: k3795 
o|contracted procedure: k3836 
o|contracted procedure: k3802 
o|contracted procedure: k3814 
o|contracted procedure: k3817 
o|contracted procedure: k3824 
o|contracted procedure: k3832 
o|contracted procedure: k3862 
o|contracted procedure: k3865 
o|contracted procedure: k3926 
o|contracted procedure: k3889 
o|contracted procedure: k3919 
o|contracted procedure: k3923 
o|contracted procedure: k3915 
o|contracted procedure: k3892 
o|contracted procedure: k3903 
o|contracted procedure: k3907 
o|contracted procedure: k3963 
o|contracted procedure: k3938 
o|contracted procedure: k3956 
o|contracted procedure: k3960 
o|contracted procedure: k3941 
o|contracted procedure: k3948 
o|contracted procedure: k3952 
o|contracted procedure: k3969 
o|contracted procedure: k3972 
o|contracted procedure: k3984 
o|contracted procedure: k3987 
o|contracted procedure: k3998 
o|contracted procedure: k4010 
o|contracted procedure: k4095 
o|contracted procedure: k4044 
o|contracted procedure: k4062 
o|contracted procedure: k4091 
o|contracted procedure: k4081 
o|contracted procedure: k4135 
o|contracted procedure: k4107 
o|contracted procedure: k4113 
o|contracted procedure: k4126 
o|contracted procedure: k4158 
o|contracted procedure: k4161 
o|contracted procedure: k4169 
o|contracted procedure: k4180 
o|contracted procedure: k4176 
o|contracted procedure: k4205 
o|contracted procedure: k4224 
o|contracted procedure: k4253 
o|contracted procedure: k4275 
o|contracted procedure: k4259 
o|contracted procedure: k4331 
o|contracted procedure: k4321 
o|contracted procedure: k4339 
o|contracted procedure: k4348 
o|contracted procedure: k4351 
o|contracted procedure: k4365 
o|contracted procedure: k4375 
o|contracted procedure: k4379 
o|contracted procedure: k4385 
o|contracted procedure: k4391 
o|contracted procedure: k4399 
o|contracted procedure: k4406 
o|contracted procedure: k4423 
o|contracted procedure: k4523 
o|contracted procedure: k4503 
o|contracted procedure: k4514 
o|contracted procedure: k4535 
o|contracted procedure: k4543 
o|contracted procedure: k4549 
o|contracted procedure: k4558 
o|contracted procedure: k4564 
o|contracted procedure: k4570 
o|contracted procedure: k4576 
o|contracted procedure: k4655 
o|contracted procedure: k4662 
o|contracted procedure: k4646 
o|contracted procedure: k4642 
o|contracted procedure: k4638 
o|contracted procedure: k4634 
o|contracted procedure: k4591 
o|contracted procedure: k4587 
o|contracted procedure: k4583 
o|contracted procedure: k4604 
o|contracted procedure: k4630 
o|contracted procedure: k4626 
o|contracted procedure: k4607 
o|contracted procedure: k4618 
o|contracted procedure: k4671 
o|contracted procedure: k4697 
o|contracted procedure: k4693 
o|contracted procedure: k4674 
o|contracted procedure: k4685 
o|contracted procedure: k4717 
o|contracted procedure: k4733 
o|contracted procedure: k4747 
o|contracted procedure: k4755 
o|contracted procedure: k4828 
o|contracted procedure: k4783 
o|contracted procedure: k4822 
o|contracted procedure: k4786 
o|contracted procedure: k4816 
o|contracted procedure: k4789 
o|contracted procedure: k4834 
o|contracted procedure: k4856 
o|contracted procedure: k4859 
o|contracted procedure: k4865 
o|contracted procedure: k4876 
o|contracted procedure: k4931 
o|contracted procedure: k4948 
o|contracted procedure: k4977 
o|contracted procedure: k4981 
o|contracted procedure: k4973 
o|contracted procedure: k4969 
o|contracted procedure: k4965 
o|contracted procedure: k4961 
o|inlining procedure: k4945 
o|contracted procedure: k4991 
o|contracted procedure: k5006 
o|contracted procedure: k5002 
o|contracted procedure: k4998 
o|inlining procedure: k4945 
o|contracted procedure: k5025 
o|contracted procedure: k5021 
o|contracted procedure: k5017 
o|inlining procedure: k4945 
o|inlining procedure: k5037 
o|inlining procedure: k5037 
o|contracted procedure: k5056 
o|contracted procedure: k5063 
o|contracted procedure: k5066 
o|contracted procedure: k5083 
o|contracted procedure: k5098 
o|contracted procedure: k5094 
o|contracted procedure: k5090 
o|contracted procedure: k5106 
o|contracted procedure: k5113 
o|contracted procedure: k5124 
o|contracted procedure: k5120 
o|contracted procedure: k5110 
o|contracted procedure: k4907 
o|contracted procedure: k5077 
o|contracted procedure: k5073 
o|contracted procedure: k5151 
o|contracted procedure: k5154 
o|contracted procedure: k5165 
o|contracted procedure: k5177 
o|contracted procedure: k5193 
o|contracted procedure: k5199 
o|contracted procedure: k5492 
o|contracted procedure: k5222 
o|contracted procedure: k5228 
o|contracted procedure: k5235 
o|contracted procedure: k5244 
o|contracted procedure: k5260 
o|contracted procedure: k5266 
o|contracted procedure: k5279 
o|contracted procedure: k5291 
o|contracted procedure: k5297 
o|contracted procedure: k5311 
o|contracted procedure: k5320 
o|contracted procedure: k5339 
o|contracted procedure: k5345 
o|contracted procedure: k5352 
o|contracted procedure: k5358 
o|contracted procedure: k5369 
o|contracted procedure: k5365 
o|contracted procedure: k5375 
o|contracted procedure: k5389 
o|contracted procedure: k5385 
o|contracted procedure: k5407 
o|contracted procedure: k5416 
o|contracted procedure: k5423 
o|contracted procedure: k5429 
o|contracted procedure: k5439 
o|contracted procedure: k5451 
o|contracted procedure: k5457 
o|contracted procedure: k5464 
o|contracted procedure: k5475 
o|contracted procedure: k5488 
o|contracted procedure: k6459 
o|contracted procedure: k5510 
o|contracted procedure: k6453 
o|contracted procedure: k5513 
o|contracted procedure: k6447 
o|contracted procedure: k5516 
o|contracted procedure: k5525 
o|contracted procedure: k5534 
o|contracted procedure: k5549 
o|contracted procedure: k5564 
o|contracted procedure: k5983 
o|contracted procedure: k5591 
o|contracted procedure: k5666 
o|contracted procedure: k5609 
o|contracted procedure: k5630 
o|contracted procedure: k5643 
o|contracted procedure: k5646 
o|contracted procedure: k5653 
o|contracted procedure: k5695 
o|contracted procedure: k5679 
o|contracted procedure: k5893 
o|contracted procedure: k5856 
o|contracted procedure: k5859 
o|contracted procedure: k5870 
o|contracted procedure: k5874 
o|contracted procedure: k5886 
o|contracted procedure: k5890 
o|contracted procedure: k5724 
o|contracted procedure: k5734 
o|contracted procedure: k5751 
o|contracted procedure: k5742 
o|contracted procedure: k5738 
o|contracted procedure: k5800 
o|contracted procedure: k5763 
o|contracted procedure: k5793 
o|contracted procedure: k5797 
o|contracted procedure: k5789 
o|contracted procedure: k5766 
o|contracted procedure: k5777 
o|contracted procedure: k5781 
o|contracted procedure: k5812 
o|contracted procedure: k5815 
o|contracted procedure: k5826 
o|contracted procedure: k5838 
o|contracted procedure: k5942 
o|contracted procedure: k5905 
o|contracted procedure: k5935 
o|contracted procedure: k5939 
o|contracted procedure: k5931 
o|contracted procedure: k5908 
o|contracted procedure: k5919 
o|contracted procedure: k5923 
o|contracted procedure: k5954 
o|contracted procedure: k5957 
o|contracted procedure: k5968 
o|contracted procedure: k5980 
o|contracted procedure: k5689 
o|contracted procedure: k6013 
o|contracted procedure: k6009 
o|contracted procedure: k6029 
o|contracted procedure: k6055 
o|contracted procedure: k6051 
o|contracted procedure: k6032 
o|contracted procedure: k6043 
o|contracted procedure: k6174 
o|inlining procedure: k6080 
o|contracted procedure: k6131 
o|contracted procedure: k6087 
o|contracted procedure: k6106 
o|contracted procedure: k6102 
o|contracted procedure: k6098 
o|contracted procedure: k6119 
o|inlining procedure: k6080 
o|contracted procedure: k6170 
o|contracted procedure: k6137 
o|contracted procedure: k6164 
o|contracted procedure: k6143 
o|contracted procedure: k6159 
o|contracted procedure: k6149 
o|contracted procedure: k6441 
o|contracted procedure: k6195 
o|contracted procedure: k6436 
o|contracted procedure: k6199 
o|contracted procedure: k6427 
o|contracted procedure: k6229 
o|contracted procedure: k6332 
o|contracted procedure: k6328 
o|contracted procedure: k6280 
o|contracted procedure: k6294 
o|contracted procedure: k6304 
o|contracted procedure: k6322 
o|contracted procedure: k6316 
o|contracted procedure: k6312 
o|contracted procedure: k6308 
o|contracted procedure: k6248 
o|contracted procedure: k6266 
o|contracted procedure: k6259 
o|contracted procedure: k6256 
o|inlining procedure: k6252 
o|inlining procedure: k6252 
o|contracted procedure: k6269 
o|contracted procedure: k6372 
o|contracted procedure: k6360 
o|contracted procedure: k6368 
o|contracted procedure: k6364 
o|contracted procedure: k6389 
o|contracted procedure: k6395 
o|contracted procedure: k6398 
o|contracted procedure: k6410 
o|contracted procedure: k6420 
o|contracted procedure: k6433 
o|contracted procedure: k6465 
o|contracted procedure: k6547 
o|contracted procedure: k6524 
o|contracted procedure: k6543 
o|contracted procedure: k6486 
o|contracted procedure: k6498 
o|contracted procedure: k6507 
o|contracted procedure: k6515 
o|contracted procedure: k6511 
o|contracted procedure: k6599 
o|contracted procedure: k6565 
o|contracted procedure: k6574 
o|contracted procedure: k6593 
o|contracted procedure: k6589 
o|contracted procedure: k6585 
o|contracted procedure: k6681 
o|contracted procedure: k6712 
o|contracted procedure: k6738 
o|contracted procedure: k6750 
o|contracted procedure: k6830 
o|contracted procedure: k6774 
o|contracted procedure: k6789 
o|contracted procedure: k6809 
o|contracted procedure: k6826 
o|contracted procedure: k6634 
o|contracted procedure: k6643 
o|contracted procedure: k6671 
o|contracted procedure: k6649 
o|contracted procedure: k6839 
o|contracted procedure: k6858 
o|contracted procedure: k6865 
o|contracted procedure: k6876 
o|contracted procedure: k7337 
o|contracted procedure: k6891 
o|contracted procedure: k7331 
o|contracted procedure: k6894 
o|contracted procedure: k7316 
o|contracted procedure: k6900 
o|contracted procedure: k6957 
o|contracted procedure: k6966 
o|contracted procedure: k6979 
o|contracted procedure: k6986 
o|contracted procedure: k7013 
o|contracted procedure: k7022 
o|contracted procedure: k7042 
o|contracted procedure: k7045 
o|contracted procedure: k7048 
o|contracted procedure: k7130 
o|contracted procedure: k7051 
o|contracted procedure: k7066 
o|contracted procedure: k7072 
o|contracted procedure: k7085 
o|contracted procedure: k7089 
o|contracted procedure: k7092 
o|contracted procedure: k7115 
o|contracted procedure: k7111 
o|contracted procedure: k7118 
o|contracted procedure: k7124 
o|contracted procedure: k7139 
o|contracted procedure: k7152 
o|contracted procedure: k7158 
o|contracted procedure: k7164 
o|contracted procedure: k7170 
o|contracted procedure: k7179 
o|contracted procedure: k7188 
o|contracted procedure: k7197 
o|contracted procedure: k7206 
o|contracted procedure: k7215 
o|contracted procedure: k7224 
o|contracted procedure: k7246 
o|contracted procedure: k7249 
o|contracted procedure: k7312 
o|contracted procedure: k7308 
o|contracted procedure: k7300 
o|contracted procedure: k7304 
o|contracted procedure: k7322 
o|contracted procedure: k7352 
o|contracted procedure: k7364 
o|contracted procedure: k7385 
o|contracted procedure: k7509 
o|contracted procedure: k7405 
o|contracted procedure: k7433 
o|contracted procedure: k7458 
o|contracted procedure: k7454 
o|contracted procedure: k7469 
o|contracted procedure: k7465 
o|contracted procedure: k7488 
o|contracted procedure: k7484 
o|contracted procedure: k7505 
o|contracted procedure: k7501 
o|contracted procedure: k7521 
o|contracted procedure: k7527 
o|contracted procedure: k7550 
o|contracted procedure: k7556 
o|contracted procedure: k7559 
o|contracted procedure: k7606 
o|contracted procedure: k7565 
o|contracted procedure: k7577 
o|contracted procedure: k7580 
o|contracted procedure: k7587 
o|contracted procedure: k7595 
o|contracted procedure: k7599 
o|contracted procedure: k7734 
o|contracted procedure: k7614 
o|contracted procedure: k7636 
o|contracted procedure: k7642 
o|contracted procedure: k7654 
o|contracted procedure: k7666 
o|contracted procedure: k7678 
o|contracted procedure: k7691 
o|contracted procedure: k7694 
o|contracted procedure: k7706 
o|contracted procedure: k7755 
o|contracted procedure: k7771 
o|contracted procedure: k7761 
o|contracted procedure: k7780 
o|contracted procedure: k7801 
o|contracted procedure: k7888 
o|contracted procedure: k7856 
o|contracted procedure: k7941 
o|contracted procedure: k7953 
o|contracted procedure: k7963 
o|contracted procedure: k7967 
o|contracted procedure: k7936 
o|contracted procedure: k8015 
o|contracted procedure: k8040 
o|contracted procedure: k8036 
o|contracted procedure: k8060 
o|contracted procedure: k8056 
o|contracted procedure: k8077 
o|contracted procedure: k8063 
o|contracted procedure: k8070 
o|contracted procedure: k8259 
o|contracted procedure: k8337 
o|contracted procedure: k8333 
o|contracted procedure: k8267 
o|contracted procedure: k8271 
o|contracted procedure: k8263 
o|contracted procedure: k8255 
o|contracted procedure: k8279 
o|contracted procedure: k8294 
o|contracted procedure: k8290 
o|contracted procedure: k8286 
o|contracted procedure: k8303 
o|contracted procedure: k8306 
o|contracted procedure: k8317 
o|contracted procedure: k8329 
o|contracted procedure: k8349 
o|contracted procedure: k8352 
o|contracted procedure: k8359 
o|contracted procedure: k8363 
o|contracted procedure: k8388 
o|contracted procedure: k8394 
o|contracted procedure: k8401 
o|contracted procedure: k8412 
o|contracted procedure: k8418 
o|contracted procedure: k8433 
o|contracted procedure: k8429 
o|contracted procedure: k8425 
o|contracted procedure: k8448 
o|contracted procedure: k8499 
o|contracted procedure: k8459 
o|contracted procedure: k8471 
o|contracted procedure: k8467 
o|contracted procedure: k8463 
o|contracted procedure: k8455 
o|contracted procedure: k8487 
o|contracted procedure: k8493 
o|contracted procedure: k8505 
o|contracted procedure: k8544 
o|contracted procedure: k8516 
o|contracted procedure: k8528 
o|contracted procedure: k8524 
o|contracted procedure: k8520 
o|contracted procedure: k8512 
o|contracted procedure: k8536 
o|contracted procedure: k8550 
o|contracted procedure: k8564 
o|contracted procedure: k8560 
o|contracted procedure: k8575 
o|contracted procedure: k8571 
o|contracted procedure: k8578 
o|contracted procedure: k8601 
o|contracted procedure: k8703 
o|contracted procedure: k8699 
o|contracted procedure: k8609 
o|contracted procedure: k8695 
o|contracted procedure: k8691 
o|contracted procedure: k8617 
o|contracted procedure: k8683 
o|contracted procedure: k8687 
o|contracted procedure: k8625 
o|contracted procedure: k8676 
o|contracted procedure: k8665 
o|contracted procedure: k8633 
o|contracted procedure: k8641 
o|contracted procedure: k8637 
o|contracted procedure: k8629 
o|contracted procedure: k8621 
o|contracted procedure: k8613 
o|contracted procedure: k8605 
o|contracted procedure: k8597 
o|contracted procedure: k8657 
o|contracted procedure: k8661 
o|contracted procedure: k8653 
o|contracted procedure: k8649 
o|contracted procedure: k8707 
o|contracted procedure: k8711 
o|contracted procedure: k8720 
o|contracted procedure: k8726 
o|contracted procedure: k8733 
o|contracted procedure: k8805 
o|contracted procedure: k8746 
o|contracted procedure: k8797 
o|contracted procedure: k8749 
o|contracted procedure: k8764 
o|contracted procedure: k8768 
o|contracted procedure: k8783 
o|contracted procedure: k8794 
o|contracted procedure: k8790 
o|contracted procedure: k8780 
o|contracted procedure: k8811 
o|contracted procedure: k8828 
o|contracted procedure: k8834 
o|contracted procedure: k8840 
o|contracted procedure: k8851 
o|contracted procedure: k8860 
o|contracted procedure: k8863 
o|contracted procedure: k8879 
o|contracted procedure: k8872 
o|contracted procedure: k8886 
o|contracted procedure: k8898 
o|contracted procedure: k8907 
o|contracted procedure: k8925 
o|contracted procedure: k8949 
o|substituted constant variable: g13562 
o|contracted procedure: k8956 
o|contracted procedure: k8960 
o|contracted procedure: k8974 
o|contracted procedure: k8970 
o|contracted procedure: k8977 
o|contracted procedure: k8983 
o|contracted procedure: k8989 
o|contracted procedure: k9002 
o|contracted procedure: k9008 
o|contracted procedure: k9029 
o|contracted procedure: k9052 
o|contracted procedure: k9058 
o|contracted procedure: k9065 
o|contracted procedure: k9078 
o|contracted procedure: k9082 
o|contracted procedure: k9090 
o|contracted procedure: k9096 
o|contracted procedure: k9113 
o|contracted procedure: k9129 
o|contracted procedure: k9158 
o|contracted procedure: k9144 
o|contracted procedure: k9154 
o|contracted procedure: k9135 
o|contracted procedure: k9171 
o|contracted procedure: k9179 
o|contracted procedure: k9185 
o|contracted procedure: k9202 
o|contracted procedure: k9237 
o|contracted procedure: k9246 
o|contracted procedure: k9252 
o|contracted procedure: k9259 
o|contracted procedure: k9281 
o|contracted procedure: k9291 
o|contracted procedure: k9307 
o|contracted procedure: k9310 
o|contracted procedure: k9365 
o|contracted procedure: k9324 
o|contracted procedure: k9343 
o|contracted procedure: k9346 
o|contracted procedure: k9353 
o|contracted procedure: k9446 
o|contracted procedure: k9374 
o|contracted procedure: k9411 
o|contracted procedure: k9385 
o|contracted procedure: k9407 
o|contracted procedure: k9397 
o|contracted procedure: k9414 
o|contracted procedure: k9426 
o|contracted procedure: k9436 
o|contracted procedure: k9440 
o|contracted procedure: k9478 
o|contracted procedure: k9489 
o|contracted procedure: k9497 
o|contracted procedure: k9501 
o|contracted procedure: k9528 
o|contracted procedure: k9548 
o|contracted procedure: k9558 
o|contracted procedure: k9554 
o|contracted procedure: k9568 
o|contracted procedure: k9583 
o|contracted procedure: k9586 
o|contracted procedure: k9592 
o|contracted procedure: k9598 
o|contracted procedure: k9631 
o|contracted procedure: k9627 
o|contracted procedure: k9623 
o|contracted procedure: k9611 
o|contracted procedure: k9619 
o|contracted procedure: k9615 
o|contracted procedure: k9652 
o|contracted procedure: k9668 
o|contracted procedure: k9664 
o|contracted procedure: k9716 
o|contracted procedure: k9676 
o|contracted procedure: k9680 
o|contracted procedure: k9697 
o|contracted procedure: k9693 
o|contracted procedure: k9683 
o|contracted procedure: k9700 
o|contracted procedure: k9706 
o|contracted procedure: k9724 
o|contracted procedure: k9727 
o|contracted procedure: k9738 
o|contracted procedure: k9764 
o|contracted procedure: k9756 
o|contracted procedure: k9774 
o|contracted procedure: k9787 
o|contracted procedure: k9800 
o|contracted procedure: k9822 
o|contracted procedure: k9831 
o|contracted procedure: k9955 
o|contracted procedure: k9850 
o|contracted procedure: k9860 
o|contracted procedure: k9869 
o|contracted procedure: k9882 
o|contracted procedure: k9931 
o|contracted procedure: k9907 
o|contracted procedure: k9920 
o|contracted procedure: k9948 
o|contracted procedure: k9967 
o|contracted procedure: k9979 
o|contracted procedure: k9991 
o|contracted procedure: k10017 
o|contracted procedure: k10013 
o|contracted procedure: k9994 
o|contracted procedure: k10005 
o|contracted procedure: k10080 
o|contracted procedure: k10029 
o|contracted procedure: k10076 
o|contracted procedure: k10042 
o|contracted procedure: k10055 
o|contracted procedure: k10101 
o|contracted procedure: k10097 
o|contracted procedure: k10134 
o|contracted procedure: k10130 
o|contracted procedure: k10126 
o|contracted procedure: k10122 
o|contracted procedure: k10169 
o|contracted procedure: k10323 
o|contracted procedure: k10192 
o|contracted procedure: k10205 
o|contracted procedure: k10218 
o|contracted procedure: k10226 
o|contracted procedure: k10239 
o|contracted procedure: k10247 
o|contracted procedure: k10259 
o|contracted procedure: k10269 
o|contracted procedure: k10288 
o|contracted procedure: k10280 
o|contracted procedure: k10296 
o|contracted procedure: k10300 
o|contracted procedure: k10314 
o|contracted procedure: k10349 
o|contracted procedure: k10345 
o|contracted procedure: k10341 
o|contracted procedure: k10363 
o|contracted procedure: k10396 
o|contracted procedure: k10369 
o|contracted procedure: k10392 
o|contracted procedure: k10384 
o|contracted procedure: k10388 
o|contracted procedure: k10380 
o|contracted procedure: k10376 
o|contracted procedure: k10414 
o|contracted procedure: k10427 
o|contracted procedure: k10440 
o|contracted procedure: k10443 
o|contracted procedure: k10471 
o|contracted procedure: k10482 
o|contracted procedure: k10581 
o|contracted procedure: k10487 
o|contracted procedure: k10503 
o|contracted procedure: k10499 
o|contracted procedure: k10491 
o|contracted procedure: k10478 
o|contracted procedure: k10542 
o|contracted procedure: k10545 
o|contracted procedure: k10556 
o|contracted procedure: k10568 
o|contracted procedure: k10530 
o|contracted procedure: k10526 
o|contracted procedure: k10512 
o|contracted procedure: k10520 
o|contracted procedure: k10571 
o|contracted procedure: k10578 
o|contracted procedure: k10593 
o|contracted procedure: k10596 
o|contracted procedure: k10607 
o|contracted procedure: k10619 
o|contracted procedure: k10462 
o|contracted procedure: k10466 
o|contracted procedure: k10632 
o|contracted procedure: k10646 
o|contracted procedure: k10653 
o|contracted procedure: k10670 
o|contracted procedure: k10660 
o|contracted procedure: k10683 
o|contracted procedure: k10893 
o|contracted procedure: k10707 
o|contracted procedure: k10889 
o|contracted procedure: k10723 
o|contracted procedure: k10762 
o|contracted procedure: k10769 
o|contracted procedure: k10783 
o|contracted procedure: k10772 
o|contracted procedure: k10779 
o|contracted procedure: k10839 
o|contracted procedure: k10843 
o|contracted procedure: k10790 
o|contracted procedure: k10808 
o|contracted procedure: k10815 
o|contracted procedure: k10829 
o|contracted procedure: k10818 
o|contracted procedure: k10825 
o|contracted procedure: k10855 
o|contracted procedure: k10858 
o|contracted procedure: k10869 
o|contracted procedure: k10881 
o|contracted procedure: k10885 
o|contracted procedure: k10903 
o|contracted procedure: k11234 
o|contracted procedure: k10927 
o|contracted procedure: k10981 
o|contracted procedure: k11001 
o|contracted procedure: k11050 
o|contracted procedure: k11046 
o|contracted procedure: k11026 
o|contracted procedure: k11042 
o|contracted procedure: k11034 
o|contracted procedure: k11030 
o|contracted procedure: k11098 
o|contracted procedure: k11066 
o|contracted procedure: k11094 
o|contracted procedure: k11078 
o|contracted procedure: k11090 
o|contracted procedure: k11082 
o|contracted procedure: k11074 
o|contracted procedure: k11070 
o|contracted procedure: k11105 
o|contracted procedure: k11109 
o|contracted procedure: k11118 
o|contracted procedure: k11125 
o|contracted procedure: k11141 
o|contracted procedure: k11130 
o|contracted procedure: k11137 
o|contracted procedure: k11146 
o|contracted procedure: k11152 
o|contracted procedure: k11158 
o|contracted procedure: k11164 
o|contracted procedure: k11170 
o|contracted procedure: k11182 
o|contracted procedure: k11197 
o|contracted procedure: k11208 
o|contracted procedure: k11230 
o|contracted procedure: k11244 
o|contracted procedure: k11250 
o|contracted procedure: k11253 
o|contracted procedure: k11260 
o|contracted procedure: k11286 
o|contracted procedure: k11270 
o|contracted procedure: k11278 
o|contracted procedure: k11274 
o|contracted procedure: k11296 
o|contracted procedure: k11302 
o|contracted procedure: k11305 
o|contracted procedure: k11312 
o|contracted procedure: k11319 
o|contracted procedure: k11336 
o|contracted procedure: k11339 
o|contracted procedure: k11345 
o|contracted procedure: k11352 
o|contracted procedure: k11362 
o|contracted procedure: k11389 
o|contracted procedure: k11411 
o|contracted procedure: k11433 
o|contracted procedure: k11455 
o|contracted procedure: k11483 
o|contracted procedure: k11493 
o|contracted procedure: k11507 
o|contracted procedure: k11496 
o|contracted procedure: k11503 
o|contracted procedure: k11517 
o|contracted procedure: k11610 
o|contracted procedure: k11592 
o|contracted procedure: k11588 
o|contracted procedure: k11584 
o|contracted procedure: k11606 
o|contracted procedure: k11597 
o|contracted procedure: k11539 
o|contracted procedure: k11552 
o|contracted procedure: k11629 
o|contracted procedure: k11729 
o|contracted procedure: k11725 
o|contracted procedure: k11685 
o|contracted procedure: k11709 
o|contracted procedure: k11719 
o|contracted procedure: k11715 
o|contracted procedure: k11705 
o|contracted procedure: k11648 
o|contracted procedure: k11664 
o|contracted procedure: k11746 
o|contracted procedure: k11763 
o|contracted procedure: k11780 
o|contracted procedure: k11797 
o|contracted procedure: k11814 
o|simplifications: ((let . 180)) 
o|replaced variables: 2 
o|removed binding forms: 814 
o|inlining procedure: k3990 
o|inlining procedure: k3990 
o|inlining procedure: k4610 
o|inlining procedure: k4610 
o|inlining procedure: k4677 
o|inlining procedure: k4677 
o|inlining procedure: k5102 
o|inlining procedure: k5102 
o|inlining procedure: k5157 
o|inlining procedure: k5157 
o|inlining procedure: k5818 
o|inlining procedure: k5818 
o|inlining procedure: k5960 
o|inlining procedure: k5960 
o|inlining procedure: k6035 
o|inlining procedure: k6035 
o|inlining procedure: k6084 
o|inlining procedure: k8309 
o|inlining procedure: k8309 
o|inlining procedure: k9672 
o|inlining procedure: k9672 
o|inlining procedure: k9997 
o|inlining procedure: k9997 
o|inlining procedure: k10548 
o|inlining procedure: k10548 
o|inlining procedure: k10599 
o|inlining procedure: k10599 
o|inlining procedure: k10861 
o|inlining procedure: k10861 
o|inlining procedure: k11545 
o|replaced variables: 157 
o|removed binding forms: 7 
o|inlining procedure: k7956 
o|simplifications: ((if . 2)) 
o|replaced variables: 4 
o|removed binding forms: 121 
o|contracted procedure: k5976 
o|contracted procedure: k10615 
o|replaced variables: 50 
o|removed binding forms: 5 
o|removed binding forms: 13 
o|direct leaf routine/allocation: lookup 0 
o|direct leaf routine/allocation: g509510 0 
o|direct leaf routine/allocation: g12341235 0 
o|direct leaf routine/allocation: g13251326 0 
o|direct leaf routine/allocation: loop1378 0 
o|direct leaf routine/allocation: g15651566 0 
o|direct leaf routine/allocation: g15741575 0 
o|direct leaf routine/allocation: assq-reverse1441 0 
o|direct leaf routine/allocation: g20322041 15 
o|contracted procedure: "(expand.scm:92) k3660" 
o|contracted procedure: "(expand.scm:168) k4150" 
o|contracted procedure: "(expand.scm:180) k4186" 
o|contracted procedure: "(expand.scm:184) k4202" 
o|contracted procedure: "(expand.scm:186) k4211" 
o|contracted procedure: "(expand.scm:271) k4546" 
o|contracted procedure: "(expand.scm:273) k4759" 
o|contracted procedure: "(expand.scm:453) k5522" 
o|converted assignments to bindings: (loop1378) 
o|contracted procedure: "(expand.scm:791) k7422" 
o|contracted procedure: "(expand.scm:852) k7719" 
o|contracted procedure: "(expand.scm:852) k7725" 
o|contracted procedure: "(expand.scm:871) k7821" 
o|contracted procedure: "(expand.scm:872) k7824" 
o|contracted procedure: "(expand.scm:1225) k10877" 
o|simplifications: ((let . 1) (if . 2)) 
o|removed binding forms: 14 
o|contracted procedure: "(expand.scm:762) k7236" 
o|replaced variables: 12 
o|removed binding forms: 1 
o|removed binding forms: 6 
o|direct leaf routine/allocation: comp913 0 
o|contracted procedure: "(expand.scm:471) k5656" 
o|contracted procedure: "(expand.scm:536) k6217" 
o|contracted procedure: "(expand.scm:563) k6338" 
o|contracted procedure: "(expand.scm:566) k6350" 
o|contracted procedure: "(expand.scm:570) k6378" 
o|simplifications: ((if . 1)) 
o|removed binding forms: 5 
o|replaced variables: 7 
o|removed binding forms: 1 
o|customizable procedures: (loop1750 k11473 check-for-multiple-bindings expand1915 map-loop20262047 k10794 expand2002 expand2069 map-loop20912109 k10495 k10564 map-loop21252143 match-expression g22202221 g22132214 walk2157 walk12158 simplify2159 expand2285 map-loop22932311 err2257 test2258 k9686 g27652772 for-each-loop27642775 loop2742 loop2671 k8963 k8916 doloop26202621 k8553 k8346 map-loop24862503 k8024 loop1813 for-each-loop16481664 mirror-rename1442 k7622 k7630 doloop15101511 g14571458 k7444 k7030 test1350 k7054 walk1388 doloop14031404 loop1364 err1351 loop1267 loop1280 loop1297 outstr1278 loop1245 mwalk1221 k6202 fini/syntax915 loop1171 loop21188 k6070 loop1121 map-loop11341151 fini914 map-loop953971 k5911 map-loop9801004 map-loop10401057 k5769 map-loop10691093 k5862 map-loop10161103 k5615 loop935 expand916 k5225 k5401 k5314 k5272 k5275 macro-alias k5238 loop778 err767 g800809 map-loop794822 k4942 k4954 k4868 loop745 loop731 k4552 k4703 g698699 loop611 expand555 map-loop638656 map-loop665682 call-handler554 tmp13083 tmp23084 k4324 k4358 copy574 loop540 k4071 loop468 g465466 loop1453 map-loop355372 for-each-loop381408 k3895 map-loop418439 doloop331332 walk301 k3654) 
o|calls to known targets: 377 
o|identified direct recursive calls: f_3710 1 
o|identified direct recursive calls: f_3933 1 
o|identified direct recursive calls: f_4248 1 
o|identified direct recursive calls: f_4599 2 
o|identified direct recursive calls: f_4666 2 
o|identified direct recursive calls: f_4926 2 
o|identified direct recursive calls: f_5949 2 
o|identified direct recursive calls: f_6024 2 
o|identified direct recursive calls: f_6000 1 
o|identified direct recursive calls: f_6478 1 
o|identified direct recursive calls: f_6560 1 
o|identified direct recursive calls: f_6638 1 
o|identified direct recursive calls: f_7011 1 
o|identified direct recursive calls: f_7037 1 
o|identified direct recursive calls: f_7359 1 
o|identified direct recursive calls: f_7513 1 
o|identified direct recursive calls: f_7750 1 
o|identified direct recursive calls: f_7775 1 
o|identified direct recursive calls: f_7948 1 
o|identified direct recursive calls: f_8944 1 
o|identified direct recursive calls: f_9338 1 
o|identified direct recursive calls: f_9986 2 
o|identified direct recursive calls: f_10588 2 
o|identified direct recursive calls: f_10641 1 
o|identified direct recursive calls: f_10850 2 
o|fast box initializations: 70 
o|fast global references: 32 
o|fast global assignments: 4 
o|dropping unused closure argument: f_6475 
o|dropping unused closure argument: f_7750 
o|dropping unused closure argument: f_7011 
o|dropping unused closure argument: f_8007 
o|dropping unused closure argument: f_3629 
o|dropping unused closure argument: f_3646 
*/
/* end of file */
