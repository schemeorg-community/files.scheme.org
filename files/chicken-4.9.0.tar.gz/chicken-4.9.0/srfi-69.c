/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:38
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: srfi-69.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file srfi-69.c -extend ./private-namespace.scm
   unit: srfi_2d69
*/

#include "chicken.h"

#define C_rnd_fix() (C_fix(rand()))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[124];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,110,117,109,98,101,114,45,104,97,115,104,45,104,111,111,107,32,111,98,106,49,48,48,32,114,110,100,49,48,49,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,32),40,110,117,109,98,101,114,45,104,97,115,104,32,111,98,106,49,48,56,32,46,32,116,109,112,49,48,55,49,48,57,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,36),40,111,98,106,101,99,116,45,117,105,100,45,104,97,115,104,32,111,98,106,49,57,50,32,46,32,116,109,112,49,57,49,49,57,51,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,32),40,115,121,109,98,111,108,45,104,97,115,104,32,111,98,106,50,50,51,32,46,32,116,109,112,50,50,50,50,50,52,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,99,104,101,99,107,45,107,101,121,119,111,114,100,32,120,50,53,52,32,46,32,121,50,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,33),40,107,101,121,119,111,114,100,45,104,97,115,104,32,111,98,106,50,54,51,32,46,32,116,109,112,50,54,50,50,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,101,113,63,45,104,97,115,104,32,111,98,106,51,50,49,32,46,32,116,109,112,51,50,48,51,50,50,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,30),40,101,113,118,63,45,104,97,115,104,32,111,98,106,52,49,57,32,46,32,116,109,112,52,49,56,52,50,48,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,104,115,104,52,54,50,32,105,52,54,51,32,108,101,110,52,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,53),40,118,101,99,116,111,114,45,104,97,115,104,32,111,98,106,52,53,53,32,115,101,101,100,52,53,54,32,100,101,112,116,104,52,53,55,32,115,116,97,114,116,52,53,56,32,114,110,100,52,53,57,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,20),40,103,53,51,57,32,111,98,106,53,52,49,32,114,110,100,53,52,50,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,20),40,103,53,53,51,32,111,98,106,53,53,53,32,114,110,100,53,53,54,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,20),40,103,53,53,55,32,111,98,106,53,53,57,32,114,110,100,53,54,48,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,39),40,114,101,99,117,114,115,105,118,101,45,104,97,115,104,32,111,98,106,52,54,54,32,100,101,112,116,104,52,54,55,32,114,110,100,52,54,56,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,28),40,42,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,52,53,49,32,114,110,100,52,53,50,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,32),40,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,53,54,57,32,46,32,116,109,112,53,54,56,53,55,48,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,104,97,115,104,32,115,116,114,53,57,55,32,46,32,116,109,112,53,57,54,53,57,56,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,35),40,115,116,114,105,110,103,45,99,105,45,104,97,115,104,32,115,116,114,54,52,48,32,46,32,116,109,112,54,51,57,54,52,49,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,43),40,104,97,115,104,45,116,97,98,108,101,45,99,97,110,111,110,105,99,97,108,45,108,101,110,103,116,104,32,116,97,98,54,57,51,32,114,101,113,54,57,52,41,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,27),40,102,95,51,53,55,53,32,111,98,106,101,99,116,55,49,54,32,98,111,117,110,100,55,49,55,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,27),40,102,95,51,53,56,48,32,111,98,106,101,99,116,55,49,56,32,98,111,117,110,100,55,49,57,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,27),40,102,95,51,53,56,53,32,111,98,106,101,99,116,55,50,48,32,98,111,117,110,100,55,50,49,41,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,38),40,42,109,97,107,101,45,104,97,115,104,45,102,117,110,99,116,105,111,110,32,117,115,101,114,45,102,117,110,99,116,105,111,110,55,49,52,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,86),40,42,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,116,101,115,116,55,51,50,32,104,97,115,104,55,51,51,32,108,101,110,55,51,52,32,109,105,110,45,108,111,97,100,55,51,53,32,109,97,120,45,108,111,97,100,55,51,54,32,105,110,105,116,105,97,108,55,51,57,32,116,109,112,55,51,49,55,52,48,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,19),40,105,110,118,97,114,103,45,101,114,114,32,109,115,103,56,48,57,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,8),40,102,95,51,56,51,51,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,97,114,103,115,56,48,54,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,46,32,97,114,103,117,109,101,110,116,115,48,55,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,20),40,104,97,115,104,45,116,97,98,108,101,63,32,111,98,106,56,52,50,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,115,105,122,101,32,104,116,56,52,52,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,39),40,104,97,115,104,45,116,97,98,108,101,45,101,113,117,105,118,97,108,101,110,99,101,45,102,117,110,99,116,105,111,110,32,104,116,56,52,55,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,104,45,102,117,110,99,116,105,111,110,32,104,116,56,53,48,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,105,110,45,108,111,97,100,32,104,116,56,53,51,41,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,97,120,45,108,111,97,100,32,104,116,56,53,54,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,28),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,107,101,121,115,32,104,116,56,53,57,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,30),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,118,97,108,117,101,115,32,104,116,56,54,50,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,31),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,45,105,110,105,116,105,97,108,63,32,104,116,56,54,53,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,105,110,105,116,105,97,108,32,104,116,56,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,56,56,50,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,55,56,32,105,56,56,48,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,40),40,104,97,115,104,45,116,97,98,108,101,45,114,101,115,105,122,101,33,32,104,116,56,57,49,32,118,101,99,56,57,50,32,108,101,110,56,57,51,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,21),40,99,111,112,121,45,108,111,111,112,32,98,117,99,107,101,116,57,48,57,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,57,48,53,32,105,57,48,55,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,24),40,42,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,57,48,48,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,57,49,55,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,54,53,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,55,52,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,8),40,102,95,52,53,57,53,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,53),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,32,104,116,57,50,54,32,107,101,121,57,50,55,32,102,117,110,99,57,50,56,32,46,32,116,109,112,57,50,53,57,50,57,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,57),40,42,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,57,56,56,32,107,101,121,57,56,57,32,102,117,110,99,57,57,48,32,100,101,102,57,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,60),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,49,48,51,55,32,107,101,121,49,48,51,56,32,102,117,110,99,49,48,51,57,32,100,101,102,49,48,52,48,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,40),40,104,97,115,104,45,116,97,98,108,101,45,115,101,116,33,32,104,116,49,48,52,53,32,107,101,121,49,48,52,54,32,118,97,108,49,48,52,55,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,47),40,104,97,115,104,45,116,97,98,108,101,45,114,101,102,47,100,101,102,97,117,108,116,32,104,116,49,49,49,55,32,107,101,121,49,49,49,56,32,100,101,102,49,49,49,57,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,101,120,105,115,116,115,63,32,104,116,49,49,51,53,32,107,101,121,49,49,51,54,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,49,55,57,32,98,117,99,107,101,116,49,49,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,100,101,108,101,116,101,33,32,104,116,49,49,54,48,32,107,101,121,49,49,54,49,41,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,49,57,56,32,98,117,99,107,101,116,49,49,57,57,41,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,49,57,52,32,105,49,49,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,36),40,104,97,115,104,45,116,97,98,108,101,45,114,101,109,111,118,101,33,32,104,116,49,49,56,57,32,102,117,110,99,49,49,57,48,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,99,108,101,97,114,33,32,104,116,49,50,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,13),40,97,53,53,55,57,32,120,49,50,50,54,41,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,20),40,100,111,108,111,111,112,49,50,50,50,32,108,115,116,49,50,50,52,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,50,49,57,32,105,49,50,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,36),40,42,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,50,49,53,32,104,116,50,49,50,49,54,41,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,50,51,50,32,104,116,50,49,50,51,51,41,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,34),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,32,104,116,49,49,50,51,55,32,104,116,50,49,50,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,50,52,57,32,108,115,116,49,50,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,50,52,54,32,108,115,116,49,50,52,55,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,62,97,108,105,115,116,32,104,116,49,50,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,97,53,55,48,56,32,120,49,50,55,50,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,13),40,103,49,50,54,50,32,120,49,50,55,49,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,50,54,49,32,103,49,50,54,56,49,50,55,53,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,40),40,97,108,105,115,116,45,62,104,97,115,104,45,116,97,98,108,101,32,97,108,105,115,116,49,50,53,54,32,46,32,114,101,115,116,49,50,53,55,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,50,56,57,32,108,115,116,49,50,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,50,56,54,32,108,115,116,49,50,56,55,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,24),40,104,97,115,104,45,116,97,98,108,101,45,107,101,121,115,32,104,116,49,50,56,50,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,51,48,51,32,108,115,116,49,51,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,51,48,48,32,108,115,116,49,51,48,49,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,118,97,108,117,101,115,32,104,116,49,50,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,18),40,103,49,51,50,48,32,98,117,99,107,101,116,49,51,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,51,49,57,32,103,49,51,50,54,49,51,51,49,41,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,51,49,52,32,105,49,51,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,38),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,51,49,48,32,112,114,111,99,49,51,49,49,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,26),40,102,111,108,100,50,32,98,117,99,107,101,116,49,51,52,55,32,97,99,99,49,51,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,51,52,52,32,97,99,99,49,51,52,53,41,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,43),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,51,51,56,32,102,117,110,99,49,51,51,57,32,105,110,105,116,49,51,52,48,41,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,42),40,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,51,53,51,32,102,117,110,99,49,51,53,52,32,105,110,105,116,49,51,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,37),40,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,51,53,57,32,112,114,111,99,49,51,54,48,41,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,33),40,104,97,115,104,45,116,97,98,108,101,45,119,97,108,107,32,104,116,49,51,54,52,32,112,114,111,99,49,51,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,25),40,97,54,48,53,56,32,107,49,51,55,49,32,118,49,51,55,50,32,97,49,51,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,109,97,112,32,104,116,49,51,54,57,32,102,117,110,99,49,51,55,48,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,23),40,97,54,48,55,49,32,104,116,49,51,55,54,32,112,111,114,116,49,51,55,55,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,8),40,102,95,54,50,48,56,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,36),40,97,54,48,56,55,32,104,116,49,48,57,51,32,107,101,121,49,48,57,52,32,46,32,116,109,112,49,48,57,50,49,48,57,53,41,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,12),40,97,54,50,49,54,32,120,52,52,55,41,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,12),40,97,54,50,51,48,32,120,52,52,50,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4295)
static void C_fcall f_4295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5554)
static void C_fcall f_5554(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_fcall f_3156(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5199)
static C_word C_fcall f_5199(C_word t0,C_word t1);
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4343)
static void C_fcall f_4343(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4233)
static void C_fcall f_4233(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_fcall f_5132(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3144)
static void C_fcall f_3144(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2736)
static void C_fcall f_2736(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2733)
static void C_fcall f_2733(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(C_srfi_2d69_toplevel)
C_externexport void C_ccall C_srfi_2d69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_fcall f_6125(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5719)
static void C_fcall f_5719(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5717)
static void C_ccall f_5717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5184)
static void C_ccall f_5184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_fcall f_4650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5709)
static void C_ccall f_5709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4644)
static void C_fcall f_4644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4111)
static void C_fcall f_4111(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5359)
static void C_fcall f_5359(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_fcall f_4523(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5615)
static void C_ccall f_5615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4772)
static void C_fcall f_4772(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_fcall f_4460(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6035)
static void C_ccall f_6035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_fcall f_5630(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6054)
static void C_ccall f_6054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5093)
static C_word C_fcall f_5093(C_word t0,C_word t1);
C_noret_decl(f_6079)
static void C_ccall f_6079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6072)
static void C_ccall f_6072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6042)
static void C_ccall f_6042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6067)
static void C_ccall f_6067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5454)
static void C_fcall f_5454(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5441)
static void C_ccall f_5441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4893)
static void C_fcall f_4893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_fcall f_5945(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5892)
static void C_fcall f_5892(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5884)
static void C_fcall f_5884(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4887)
static void C_fcall f_4887(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5922)
static void C_fcall f_5922(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3636)
static C_word C_fcall f_3636(C_word t0);
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5932)
static void C_ccall f_5932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static C_word C_fcall f_3533(C_word t0,C_word t1);
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_fcall f_3527(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2809)
static void C_fcall f_2809(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4876)
static void C_fcall f_4876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_fcall f_5872(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4633)
static void C_fcall f_4633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5531)
static void C_fcall f_5531(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4604)
static void C_fcall f_4604(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5519)
static void C_fcall f_5519(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3609)
static void C_fcall f_3609(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_fcall f_4380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6167)
static void C_fcall f_6167(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5757)
static void C_fcall f_5757(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_fcall f_2753(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5838)
static void C_fcall f_5838(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5822)
static void C_fcall f_5822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static C_word C_fcall f_5312(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6238)
static void C_fcall f_6238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_fcall f_4391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_fcall f_4397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_fcall f_4134(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3753)
static void C_fcall f_3753(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_fcall f_3065(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3764)
static void C_fcall f_3764(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_ccall f_3774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3089)
static void C_ccall f_3089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_fcall f_5428(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5773)
static void C_fcall f_5773(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_fcall f_4713(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5957)
static void C_fcall f_5957(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5696)
static void C_fcall f_5696(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6217)
static void C_ccall f_6217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_fcall f_3718(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6224)
static void C_fcall f_6224(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_fcall f_4204(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_fcall f_3712(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_fcall f_3715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_fcall f_5646(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5008)
static void C_fcall f_5008(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5973)
static void C_fcall f_5973(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5239)
static void C_fcall f_5239(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4959)
static void C_fcall f_4959(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;

C_noret_decl(trf_4295)
static void C_fcall trf_4295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4295(t0,t1,t2);}

C_noret_decl(trf_5554)
static void C_fcall trf_5554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5554(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5554(t0,t1,t2);}

C_noret_decl(trf_3156)
static void C_fcall trf_3156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3156(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3156(t0,t1,t2,t3);}

C_noret_decl(trf_4343)
static void C_fcall trf_4343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4343(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4343(t0,t1);}

C_noret_decl(trf_4233)
static void C_fcall trf_4233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4233(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4233(t0,t1,t2);}

C_noret_decl(trf_5132)
static void C_fcall trf_5132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5132(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5132(t0,t1,t2);}

C_noret_decl(trf_3144)
static void C_fcall trf_3144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3144(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3144(t0,t1,t2,t3);}

C_noret_decl(trf_2736)
static void C_fcall trf_2736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2736(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2736(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2733)
static void C_fcall trf_2733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2733(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2733(t0,t1,t2);}

C_noret_decl(trf_6125)
static void C_fcall trf_6125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6125(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6125(t0,t1,t2);}

C_noret_decl(trf_5719)
static void C_fcall trf_5719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5719(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5719(t0,t1,t2);}

C_noret_decl(trf_4650)
static void C_fcall trf_4650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4650(t0,t1);}

C_noret_decl(trf_4644)
static void C_fcall trf_4644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4644(t0,t1);}

C_noret_decl(trf_4111)
static void C_fcall trf_4111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4111(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4111(t0,t1,t2);}

C_noret_decl(trf_5359)
static void C_fcall trf_5359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5359(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5359(t0,t1,t2,t3);}

C_noret_decl(trf_4523)
static void C_fcall trf_4523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4523(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4523(t0,t1,t2);}

C_noret_decl(trf_4772)
static void C_fcall trf_4772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4772(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4772(t0,t1,t2);}

C_noret_decl(trf_4460)
static void C_fcall trf_4460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4460(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4460(t0,t1,t2);}

C_noret_decl(trf_5630)
static void C_fcall trf_5630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5630(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5630(t0,t1,t2,t3);}

C_noret_decl(trf_5454)
static void C_fcall trf_5454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5454(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5454(t0,t1,t2,t3);}

C_noret_decl(trf_4893)
static void C_fcall trf_4893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4893(t0,t1);}

C_noret_decl(trf_5945)
static void C_fcall trf_5945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5945(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5945(t0,t1,t2,t3);}

C_noret_decl(trf_5892)
static void C_fcall trf_5892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5892(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5892(t0,t1,t2);}

C_noret_decl(trf_5884)
static void C_fcall trf_5884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5884(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5884(t0,t1,t2);}

C_noret_decl(trf_4887)
static void C_fcall trf_4887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4887(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4887(t0,t1);}

C_noret_decl(trf_5922)
static void C_fcall trf_5922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5922(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5922(t0,t1,t2);}

C_noret_decl(trf_3527)
static void C_fcall trf_3527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3527(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3527(t0,t1,t2);}

C_noret_decl(trf_2809)
static void C_fcall trf_2809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2809(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2809(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4876)
static void C_fcall trf_4876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4876(t0,t1);}

C_noret_decl(trf_5872)
static void C_fcall trf_5872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5872(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5872(t0,t1,t2);}

C_noret_decl(trf_4633)
static void C_fcall trf_4633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4633(t0,t1);}

C_noret_decl(trf_5531)
static void C_fcall trf_5531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5531(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5531(t0,t1,t2);}

C_noret_decl(trf_4604)
static void C_fcall trf_4604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4604(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4604(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5519)
static void C_fcall trf_5519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5519(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5519(t0,t1,t2);}

C_noret_decl(trf_3609)
static void C_fcall trf_3609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3609(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3609(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_4380)
static void C_fcall trf_4380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4380(t0,t1);}

C_noret_decl(trf_6167)
static void C_fcall trf_6167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6167(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6167(t0,t1,t2);}

C_noret_decl(trf_5757)
static void C_fcall trf_5757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5757(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5757(t0,t1,t2,t3);}

C_noret_decl(trf_2753)
static void C_fcall trf_2753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2753(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2753(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5838)
static void C_fcall trf_5838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5838(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5838(t0,t1,t2,t3);}

C_noret_decl(trf_5822)
static void C_fcall trf_5822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5822(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5822(t0,t1,t2,t3);}

C_noret_decl(trf_6238)
static void C_fcall trf_6238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6238(t0,t1);}

C_noret_decl(trf_4391)
static void C_fcall trf_4391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4391(t0,t1);}

C_noret_decl(trf_4397)
static void C_fcall trf_4397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4397(t0,t1);}

C_noret_decl(trf_4134)
static void C_fcall trf_4134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4134(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4134(t0,t1,t2);}

C_noret_decl(trf_3753)
static void C_fcall trf_3753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3753(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3753(t0,t1,t2);}

C_noret_decl(trf_3065)
static void C_fcall trf_3065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3065(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3065(t0,t1,t2,t3);}

C_noret_decl(trf_3764)
static void C_fcall trf_3764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3764(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3764(t0,t1,t2);}

C_noret_decl(trf_5428)
static void C_fcall trf_5428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5428(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5428(t0,t1,t2);}

C_noret_decl(trf_5773)
static void C_fcall trf_5773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5773(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5773(t0,t1,t2,t3);}

C_noret_decl(trf_4713)
static void C_fcall trf_4713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4713(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4713(t0,t1,t2);}

C_noret_decl(trf_5957)
static void C_fcall trf_5957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5957(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5957(t0,t1,t2,t3);}

C_noret_decl(trf_5696)
static void C_fcall trf_5696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5696(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5696(t0,t1,t2);}

C_noret_decl(trf_3718)
static void C_fcall trf_3718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3718(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3718(t0,t1);}

C_noret_decl(trf_6224)
static void C_fcall trf_6224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6224(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6224(t0,t1);}

C_noret_decl(trf_4204)
static void C_fcall trf_4204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4204(t0,t1);}

C_noret_decl(trf_3712)
static void C_fcall trf_3712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3712(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3712(t0,t1);}

C_noret_decl(trf_3715)
static void C_fcall trf_3715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3715(t0,t1);}

C_noret_decl(trf_5646)
static void C_fcall trf_5646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5646(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5646(t0,t1,t2,t3);}

C_noret_decl(trf_5008)
static void C_fcall trf_5008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5008(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5008(t0,t1,t2);}

C_noret_decl(trf_5973)
static void C_fcall trf_5973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5973(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5973(t0,t1,t2,t3);}

C_noret_decl(trf_5239)
static void C_fcall trf_5239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5239(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5239(t0,t1,t2);}

C_noret_decl(trf_4959)
static void C_fcall trf_4959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4959(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4959(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* k5290 in hash-table-delete! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5292,2,t0,t1);}
t2=t1;
t3=C_slot(((C_word*)t0)[2],C_fix(3));
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(2));
t6=C_fixnum_difference(t5,C_fix(1));
t7=t6;
t8=C_slot(((C_word*)t0)[3],t2);
t9=C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5312,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t7,a[7]=((C_word)li63),tmp=(C_word)a,a+=8,tmp);
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,f_5312(t10,C_SCHEME_FALSE,t8));}
else{
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5359,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t11,a[7]=t4,a[8]=((C_word*)t0)[5],a[9]=((C_word)li64),tmp=(C_word)a,a+=10,tmp));
t13=((C_word*)t11)[1];
f_5359(t13,((C_word*)t0)[6],C_SCHEME_FALSE,t8);}}

/* a5579 in doloop1222 in doloop1219 in *hash-table-merge! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5580,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* hash-table-merge in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5599,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[37],lf[102]);
t5=C_i_check_structure_2(t3,lf[37],lf[102]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5613,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:1012: *hash-table-copy */
f_4204(t6,t2);}

/* k5565 in doloop1222 in doloop1219 in *hash-table-merge! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5554(t3,((C_word*)t0)[4],t2);}

/* k4422 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4380(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4380(t3,t2);}}

/* k4414 in k4378 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4391(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4391(t3,t2);}}

/* k5250 in loop in k5182 in hash-table-exists? in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm:919: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5239(t3,((C_word*)t0)[2],t2);}}

/* k2695 in eqv?-hash in k1720 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t4=C_fixnum_lessp(t1,C_fix(0));
t5=(C_truep(t4)?C_fixnum_negate(t1):t1);
t6=C_fixnum_and(t3,t5);
t7=t2;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_fixnum_modulo(t6,((C_word*)t0)[3]));}

/* k5539 in doloop1219 in *hash-table-merge! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5531(t3,((C_word*)t0)[4],t2);}

/* string-ci-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3384r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3384r(t0,t1,t2,t3);}}

static void C_ccall f_3384r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word *a=C_alloc(11);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_FALSE:C_i_car(t13));
t16=C_i_nullp(t13);
t17=(C_truep(t16)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t18=C_i_nullp(t17);
t19=(C_truep(t18)?lf[0]:C_i_car(t17));
t20=t19;
t21=C_i_nullp(t17);
t22=(C_truep(t21)?C_SCHEME_END_OF_LIST:C_i_cdr(t17));
t23=C_i_check_string_2(t2,lf[27]);
t24=C_i_check_exact_2(t6,lf[27]);
t25=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3418,a[2]=t20,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t11)){
t26=(C_truep(t15)?t15:C_block_size(t2));
t27=t26;
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3458,a[2]=t25,a[3]=t2,a[4]=t11,a[5]=t27,tmp=(C_word)a,a+=6,tmp);
t29=C_block_size(t2);
/* srfi-69.scm:372: ##sys#check-range */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t28,t11,C_fix(0),t29,lf[24]);}
else{
t26=t25;
f_3418(2,t26,t2);}}

/* copy-loop in doloop905 in k4212 in *hash-table-copy in k2729 in k2724 in k1720 */
static void C_fcall f_4295(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4295,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=C_a_i_cons(&a,2,t4,t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4316,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=C_slot(t2,C_fix(1));
/* srfi-69.scm:692: copy-loop */
t11=t8;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* doloop1222 in doloop1219 in *hash-table-merge! in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5554(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5554,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5567,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t3,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5580,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
t7=C_slot(t3,C_fix(1));
/* srfi-69.scm:1002: *hash-table-update!/default */
t8=lf[89];
f_4604(t8,t4,((C_word*)t0)[3],t5,t6,t7);}}

/* k5146 in loop in k5076 in hash-table-ref/default in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(((C_word*)t0)[3],C_fix(1)));}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:897: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5132(t3,((C_word*)t0)[2],t2);}}

/* k1745 in number-hash in k1720 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1747,2,t0,t1);}
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
if(C_truep(C_fixnump(t4))){
t5=t3;
f_1920(2,t5,C_fixnum_xor(t4,((C_word*)t0)[5]));}
else{
t5=t3;
if(C_truep(C_i_flonump(t4))){
t6=C_subbyte(t4,C_fix(7));
t7=C_subbyte(t4,C_fix(6));
t8=C_subbyte(t4,C_fix(5));
t9=C_subbyte(t4,C_fix(4));
t10=C_subbyte(t4,C_fix(3));
t11=C_subbyte(t4,C_fix(2));
t12=C_subbyte(t4,C_fix(1));
t13=C_subbyte(t4,C_fix(0));
t14=C_fixnum_shift_left(t13,C_fix(1));
t15=C_fixnum_plus(t12,t14);
t16=C_fixnum_shift_left(t15,C_fix(1));
t17=C_fixnum_plus(t11,t16);
t18=C_fixnum_shift_left(t17,C_fix(1));
t19=C_fixnum_plus(t10,t18);
t20=C_fixnum_shift_left(t19,C_fix(1));
t21=C_fixnum_plus(t9,t20);
t22=C_fixnum_shift_left(t21,C_fix(1));
t23=C_fixnum_plus(t8,t22);
t24=C_fixnum_shift_left(t23,C_fix(1));
t25=C_fixnum_plus(t7,t24);
t26=C_fixnum_shift_left(t25,C_fix(1));
t27=C_fixnum_plus(t6,t26);
t28=t5;
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,C_fixnum_times(C_fix(331804471),t27));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1914,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:148: ##sys#number-hash-hook */
t7=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,((C_word*)t0)[5]);}}}

/* g557 in recursive-hash in *equal?-hash in k2729 in k2724 in k1720 */
static void C_fcall f_3156(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3156,NULL,4,t0,t1,t2,t3);}
/* srfi-69.scm:303: vector-hash */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2736(t4,t1,t2,C_fix(0),((C_word*)t0)[3],C_fix(0),t3);}

/* loop in k5182 in hash-table-exists? in k5058 in k2729 in k2724 in k1720 */
static C_word C_fcall f_5199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:
if(C_truep(C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=C_slot(t1,C_fix(0));
t3=C_slot(t2,C_fix(0));
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t4);}
else{
t5=C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* equal?-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3168r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3168r(t0,t1,t2,t3);}}

static void C_ccall f_3168r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(4);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_check_exact_2(t6,lf[23]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3216,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:348: *equal?-hash */
f_2733(t14,t2,t10);}

/* k4837 in hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:801: *hash-table-update!/default */
t2=lf[89];
f_4604(t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_ccall f_4832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4832,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_check_structure_2(t2,lf[37],lf[90]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4839,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:800: ##sys#check-closure */
t8=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[90]);}

/* k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_fcall f_4343(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4343,NULL,2,t0,t1);}
t2=t1;
t3=C_i_check_structure_2(((C_word*)t0)[2],lf[37],lf[85]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm:721: ##sys#check-closure */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],lf[85]);}

/* k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm:722: ##sys#check-closure */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[6],lf[85]);}

/* hash-table-copy in k2729 in k2724 in k1720 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4330,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[84]);
/* srfi-69.scm:701: *hash-table-copy */
f_4204(t1,t2);}

/* hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr5r,(void*)f_4339r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4339r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4339r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(12);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4343,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nullp(t5))){
t7=C_slot(t2,C_fix(9));
if(C_truep(t7)){
t8=t6;
f_4343(t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4595,a[2]=t3,a[3]=t2,a[4]=((C_word)li48),tmp=(C_word)a,a+=5,tmp);
t9=t6;
f_4343(t9,t8);}}
else{
t7=t6;
f_4343(t7,C_i_car(t5));}}

/* hash-table-delete! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5276,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[37],lf[96]);
t5=C_slot(t2,C_fix(1));
t6=t5;
t7=C_block_size(t6);
t8=C_slot(t2,C_fix(10));
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5292,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:930: hash */
t10=t8;
((C_proc4)C_fast_retrieve_proc(t10))(4,t10,t9,t3,t7);}

/* k4806 in k4803 in loop in k4697 in k4682 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4803 in loop in k4697 in k4682 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4805,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:793: func */
t4=((C_word*)t0)[4];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:796: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4772(t3,((C_word*)t0)[3],t2);}}

/* doloop905 in k4212 in *hash-table-copy in k2729 in k2724 in k1720 */
static void C_fcall f_4233(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4233,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_slot(((C_word*)t0)[3],C_fix(3));
t4=C_slot(((C_word*)t0)[3],C_fix(4));
t5=C_slot(((C_word*)t0)[3],C_fix(2));
t6=C_slot(((C_word*)t0)[3],C_fix(5));
t7=C_slot(((C_word*)t0)[3],C_fix(6));
t8=C_slot(((C_word*)t0)[3],C_fix(9));
/* srfi-69.scm:680: *make-hash-table */
f_3609(t1,t3,t4,t5,t6,t7,t8,C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[6],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4295,a[2]=t6,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4295(t8,t3,t4);}}

/* object-uid-hash in k1720 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1952r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1952r(t0,t1,t2,t3);}}

static void C_ccall f_1952r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(4);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_check_exact_2(t6,lf[7]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2005,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:168: *equal?-hash */
f_2733(t14,t2,t10);}

/* hash-table-exists? in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5168,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[37],lf[95]);
t5=C_slot(t2,C_fix(1));
t6=t5;
t7=C_slot(t2,C_fix(3));
t8=t7;
t9=C_slot(t2,C_fix(10));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5184,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t6,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t11=C_block_size(t6);
/* srfi-69.scm:906: hash */
t12=t9;
((C_proc4)C_fast_retrieve_proc(t12))(4,t12,t10,t3,t11);}

/* k3122 in recursive-hash in *equal?-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_fixnum_plus(((C_word*)t0)[3],C_fix(260)):C_fixnum_plus(((C_word*)t0)[3],C_fix(261))));}

/* loop in k5076 in hash-table-ref/default in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5132(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5132,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[2];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5148,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=C_slot(t4,C_fix(0));
/* srfi-69.scm:895: test */
t7=((C_word*)t0)[4];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[5],t6);}}

/* g553 in recursive-hash in *equal?-hash in k2729 in k2724 in k1720 */
static void C_fcall f_3144(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3144,NULL,4,t0,t1,t2,t3);}
t4=C_peek_fixnum(t2,C_fix(0));
/* srfi-69.scm:300: vector-hash */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2736(t5,t1,t2,t4,((C_word*)t0)[3],C_fix(1),t3);}

/* k4697 in k4682 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4699,2,t0,t1);}
t2=t1;
t3=C_slot(((C_word*)t0)[2],t2);
t4=t3;
t5=C_eqp(((C_word*)t0)[3],((C_word*)t0)[4]);
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4713,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t7,a[11]=((C_word)li50),tmp=(C_word)a,a+=12,tmp));
t9=((C_word*)t7)[1];
f_4713(t9,((C_word*)t0)[10],t4);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4772,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t7,a[11]=((C_word*)t0)[4],a[12]=((C_word)li51),tmp=(C_word)a,a+=13,tmp));
t9=((C_word*)t7)[1];
f_4772(t9,((C_word*)t0)[10],t4);}}

/* vector-hash in *equal?-hash in k2729 in k2724 in k1720 */
static void C_fcall f_2736(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2736,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_block_size(t2);
t8=C_fixnum_xor(t3,t6);
t9=C_fixnum_plus(t7,t8);
t10=C_i_fixnum_min(*((C_word*)lf[19]+1),t7);
t11=C_i_fixnum_max(t5,t10);
t12=C_fixnum_difference(t11,t5);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2753,a[2]=t14,a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t6,a[7]=((C_word)li8),tmp=(C_word)a,a+=8,tmp));
t16=((C_word*)t14)[1];
f_2753(t16,t1,t9,t5,t12);}

/* *equal?-hash in k2729 in k2724 in k1720 */
static void C_fcall f_2733(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2733,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2736,a[2]=t7,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2809,a[2]=t7,a[3]=t5,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
/* srfi-69.scm:343: recursive-hash */
t10=((C_word*)t7)[1];
f_2809(t10,t1,t2,C_fix(0),t3);}

/* k2729 in k2724 in k1720 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[107],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2731,2,t0,t1);}
t2=C_mutate2((C_word*)lf[20]+1 /* (set! recursive-hash-max-length ...) */,t1);
t3=C_mutate2(&lf[2] /* (set! *equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2733,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[22]+1 /* (set! equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3168,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[23]+1 /* (set! hash ...) */,*((C_word*)lf[22]+1));
t6=C_mutate2((C_word*)lf[24]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3243,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[27]+1 /* (set! string-ci-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3384,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[28]+1 /* (set! string-hash-ci ...) */,*((C_word*)lf[27]+1));
t9=C_mutate2(&lf[29] /* (set! constant690 ...) */,lf[30]);
t10=C_mutate2(&lf[31] /* (set! hash-table-canonical-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3527,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[14]+1);
t12=*((C_word*)lf[16]+1);
t13=*((C_word*)lf[22]+1);
t14=*((C_word*)lf[23]+1);
t15=*((C_word*)lf[24]+1);
t16=*((C_word*)lf[28]+1);
t17=*((C_word*)lf[3]+1);
t18=*((C_word*)lf[7]+1);
t19=*((C_word*)lf[8]+1);
t20=*((C_word*)lf[13]+1);
t21=C_mutate2((C_word*)lf[32]+1 /* (set! *make-hash-function ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3557,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t14,a[6]=t15,a[7]=t16,a[8]=t17,a[9]=t18,a[10]=t19,a[11]=t20,a[12]=((C_word)li23),tmp=(C_word)a,a+=13,tmp));
t22=C_mutate2(&lf[36] /* (set! *make-hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t23=*((C_word*)lf[39]+1);
t24=*((C_word*)lf[40]+1);
t25=*((C_word*)lf[41]+1);
t26=*((C_word*)lf[42]+1);
t27=*((C_word*)lf[43]+1);
t28=*((C_word*)lf[44]+1);
t29=*((C_word*)lf[14]+1);
t30=*((C_word*)lf[16]+1);
t31=*((C_word*)lf[22]+1);
t32=*((C_word*)lf[23]+1);
t33=*((C_word*)lf[24]+1);
t34=*((C_word*)lf[28]+1);
t35=*((C_word*)lf[3]+1);
t36=C_mutate2((C_word*)lf[45]+1 /* (set! make-hash-table ...) */,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3634,a[2]=t23,a[3]=t29,a[4]=t24,a[5]=t30,a[6]=t25,a[7]=t31,a[8]=t26,a[9]=t33,a[10]=t27,a[11]=t34,a[12]=t28,a[13]=t35,a[14]=((C_word)li28),tmp=(C_word)a,a+=15,tmp));
t37=C_mutate2((C_word*)lf[72]+1 /* (set! hash-table? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4003,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate2((C_word*)lf[73]+1 /* (set! hash-table-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate2((C_word*)lf[74]+1 /* (set! hash-table-equivalence-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4018,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate2((C_word*)lf[75]+1 /* (set! hash-table-hash-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4027,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate2((C_word*)lf[76]+1 /* (set! hash-table-min-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4036,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate2((C_word*)lf[77]+1 /* (set! hash-table-max-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4045,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate2((C_word*)lf[78]+1 /* (set! hash-table-weak-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4054,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate2((C_word*)lf[79]+1 /* (set! hash-table-weak-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4063,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate2((C_word*)lf[80]+1 /* (set! hash-table-has-initial? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4072,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate2((C_word*)lf[81]+1 /* (set! hash-table-initial ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4084,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate2((C_word*)lf[82]+1 /* (set! hash-table-resize! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4178,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate2(&lf[83] /* (set! *hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4204,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate2((C_word*)lf[84]+1 /* (set! hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4330,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t50=*((C_word*)lf[39]+1);
t51=C_mutate2((C_word*)lf[85]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4339,a[2]=t50,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp));
t52=*((C_word*)lf[39]+1);
t53=C_mutate2(&lf[89] /* (set! *hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4604,a[2]=t52,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate2((C_word*)lf[90]+1 /* (set! hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4832,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t55=*((C_word*)lf[39]+1);
t56=C_mutate2((C_word*)lf[91]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4844,a[2]=t55,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5060,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t58=*((C_word*)lf[39]+1);
t59=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6088,a[2]=t58,a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:841: getter-with-setter */
t60=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t60+1)))(5,t60,t57,t59,*((C_word*)lf[91]+1),lf[120]);}

/* k4682 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(10));
t3=C_slot(((C_word*)t0)[2],C_fix(3));
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(1));
t6=t5;
t7=C_block_size(t6);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4699,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm:768: hash */
t9=t2;
((C_proc4)C_fast_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[4],t7);}

/* string-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3243r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3243r(t0,t1,t2,t3);}}

static void C_ccall f_3243r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word *a=C_alloc(11);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_FALSE:C_i_car(t13));
t16=C_i_nullp(t13);
t17=(C_truep(t16)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t18=C_i_nullp(t17);
t19=(C_truep(t18)?lf[0]:C_i_car(t17));
t20=t19;
t21=C_i_nullp(t17);
t22=(C_truep(t21)?C_SCHEME_END_OF_LIST:C_i_cdr(t17));
t23=C_i_check_string_2(t2,lf[24]);
t24=C_i_check_exact_2(t6,lf[24]);
t25=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3277,a[2]=t20,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t11)){
t26=(C_truep(t15)?t15:C_block_size(t2));
t27=t26;
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3317,a[2]=t25,a[3]=t2,a[4]=t11,a[5]=t27,tmp=(C_word)a,a+=6,tmp);
t29=C_block_size(t2);
/* srfi-69.scm:360: ##sys#check-range */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t28,t11,C_fix(0),t29,lf[24]);}
else{
t26=t25;
f_3277(2,t26,t2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_2d69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_2d69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_2d69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1005)){
C_save(t1);
C_rereclaim2(1005*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,124);
lf[1]=C_h_intern(&lf[1],20,"\003sysnumber-hash-hook");
lf[3]=C_h_intern(&lf[3],11,"number-hash");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_h_intern(&lf[5],5,"\000type");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[7]=C_h_intern(&lf[7],15,"object-uid-hash");
lf[8]=C_h_intern(&lf[8],11,"symbol-hash");
lf[9]=C_h_intern(&lf[9],17,"\003syscheck-keyword");
lf[10]=C_h_intern(&lf[10],11,"\000type-error");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[12]=C_h_intern(&lf[12],8,"keyword\077");
lf[13]=C_h_intern(&lf[13],12,"keyword-hash");
lf[14]=C_h_intern(&lf[14],8,"eq\077-hash");
lf[15]=C_h_intern(&lf[15],16,"hash-by-identity");
lf[16]=C_h_intern(&lf[16],9,"eqv\077-hash");
lf[17]=C_h_intern(&lf[17],26,"\052recursive-hash-max-depth\052");
lf[18]=C_h_intern(&lf[18],24,"recursive-hash-max-depth");
lf[19]=C_h_intern(&lf[19],27,"\052recursive-hash-max-length\052");
lf[20]=C_h_intern(&lf[20],25,"recursive-hash-max-length");
lf[21]=C_h_intern(&lf[21],11,"input-port\077");
lf[22]=C_h_intern(&lf[22],11,"equal\077-hash");
lf[23]=C_h_intern(&lf[23],4,"hash");
lf[24]=C_h_intern(&lf[24],11,"string-hash");
lf[25]=C_h_intern(&lf[25],13,"\003syssubstring");
lf[26]=C_h_intern(&lf[26],15,"\003syscheck-range");
lf[27]=C_h_intern(&lf[27],14,"string-ci-hash");
lf[28]=C_h_intern(&lf[28],14,"string-hash-ci");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[32]=C_h_intern(&lf[32],19,"\052make-hash-function");
lf[33]=C_h_intern(&lf[33],13,"\000bounds-error");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\030Hash value out of bounds");
lf[35]=C_h_intern(&lf[35],15,"\003syscheck-exact");
lf[37]=C_h_intern(&lf[37],10,"hash-table");
lf[38]=C_h_intern(&lf[38],11,"make-vector");
lf[39]=C_h_intern(&lf[39],3,"eq\077");
lf[40]=C_h_intern(&lf[40],4,"eqv\077");
lf[41]=C_h_intern(&lf[41],6,"equal\077");
lf[42]=C_h_intern(&lf[42],8,"string=\077");
lf[43]=C_h_intern(&lf[43],11,"string-ci=\077");
lf[44]=C_h_intern(&lf[44],1,"=");
lf[45]=C_h_intern(&lf[45],15,"make-hash-table");
lf[46]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[47]=C_decode_literal(C_heaptop,"\376U0.8000000000000000444089209850062616169452667236328125\000");
lf[48]=C_h_intern(&lf[48],7,"warning");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[50]=C_h_intern(&lf[50],5,"error");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[52]=C_h_intern(&lf[52],3,"fp<");
lf[53]=C_h_intern(&lf[53],5,"\000test");
lf[54]=C_h_intern(&lf[54],17,"\003syscheck-closure");
lf[55]=C_h_intern(&lf[55],5,"\000hash");
lf[56]=C_h_intern(&lf[56],5,"\000size");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[58]=C_h_intern(&lf[58],8,"\000initial");
lf[59]=C_h_intern(&lf[59],9,"\000min-load");
lf[60]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[61]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[63]=C_h_intern(&lf[63],17,"\003syscheck-inexact");
lf[64]=C_h_intern(&lf[64],9,"\000max-load");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[66]=C_h_intern(&lf[66],10,"\000weak-keys");
lf[67]=C_h_intern(&lf[67],12,"\000weak-values");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[72]=C_h_intern(&lf[72],11,"hash-table\077");
lf[73]=C_h_intern(&lf[73],15,"hash-table-size");
lf[74]=C_h_intern(&lf[74],31,"hash-table-equivalence-function");
lf[75]=C_h_intern(&lf[75],24,"hash-table-hash-function");
lf[76]=C_h_intern(&lf[76],19,"hash-table-min-load");
lf[77]=C_h_intern(&lf[77],19,"hash-table-max-load");
lf[78]=C_h_intern(&lf[78],20,"hash-table-weak-keys");
lf[79]=C_h_intern(&lf[79],22,"hash-table-weak-values");
lf[80]=C_h_intern(&lf[80],23,"hash-table-has-initial\077");
lf[81]=C_h_intern(&lf[81],18,"hash-table-initial");
lf[82]=C_h_intern(&lf[82],18,"hash-table-resize!");
lf[84]=C_h_intern(&lf[84],15,"hash-table-copy");
lf[85]=C_h_intern(&lf[85],18,"hash-table-update!");
lf[86]=C_h_intern(&lf[86],5,"floor");
lf[87]=C_h_intern(&lf[87],13,"\000access-error");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[90]=C_h_intern(&lf[90],26,"hash-table-update!/default");
lf[91]=C_h_intern(&lf[91],15,"hash-table-set!");
lf[92]=C_h_intern(&lf[92],19,"\003sysundefined-value");
lf[93]=C_h_intern(&lf[93],14,"hash-table-ref");
lf[94]=C_h_intern(&lf[94],22,"hash-table-ref/default");
lf[95]=C_h_intern(&lf[95],18,"hash-table-exists\077");
lf[96]=C_h_intern(&lf[96],18,"hash-table-delete!");
lf[97]=C_h_intern(&lf[97],18,"hash-table-remove!");
lf[98]=C_h_intern(&lf[98],17,"hash-table-clear!");
lf[99]=C_h_intern(&lf[99],12,"vector-fill!");
lf[101]=C_h_intern(&lf[101],17,"hash-table-merge!");
lf[102]=C_h_intern(&lf[102],16,"hash-table-merge");
lf[103]=C_h_intern(&lf[103],17,"hash-table->alist");
lf[104]=C_h_intern(&lf[104],17,"alist->hash-table");
lf[105]=C_h_intern(&lf[105],15,"hash-table-keys");
lf[106]=C_h_intern(&lf[106],17,"hash-table-values");
lf[108]=C_h_intern(&lf[108],8,"for-each");
lf[110]=C_h_intern(&lf[110],15,"hash-table-fold");
lf[111]=C_h_intern(&lf[111],19,"hash-table-for-each");
lf[112]=C_h_intern(&lf[112],15,"hash-table-walk");
lf[113]=C_h_intern(&lf[113],14,"hash-table-map");
lf[114]=C_h_intern(&lf[114],9,"\003sysprint");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\002)>");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\016#<hash-table (");
lf[117]=C_h_intern(&lf[117],27,"\003sysregister-record-printer");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[119]=C_h_intern(&lf[119],18,"getter-with-setter");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\035(hash-table-ref ht key . def)");
lf[121]=C_h_intern(&lf[121],14,"make-parameter");
lf[122]=C_h_intern(&lf[122],17,"register-feature!");
lf[123]=C_h_intern(&lf[123],7,"srfi-69");
C_register_lf2(lf,124,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1722,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:40: register-feature! */
t3=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[123]);}

/* k5727 in for-each-loop1261 in k5693 in alist->hash-table in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5719(t3,((C_word*)t0)[4],t2);}

/* k4675 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4633(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4633(t3,t2);}}

/* loop in k6108 in k6096 in a6087 in k2729 in k2724 in k1720 */
static void C_fcall f_6125(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6125,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* srfi-69.scm:857: def */
t3=((C_word*)t0)[2];
((C_proc2)C_fast_retrieve_proc(t3))(2,t3,t1);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_slot(t3,C_fix(1)));}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm:861: loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4667 in k4631 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4644(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4644(t3,t2);}}

/* k4287 in doloop905 in k4212 in *hash-table-copy in k2729 in k2724 in k1720 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_4233(t4,((C_word*)t0)[5],t3);}

/* for-each-loop1261 in k5693 in alist->hash-table in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5719(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5719,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5729,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* srfi-69.scm:1034: g1262 */
t5=((C_word*)t0)[3];
f_5696(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5715 in k5693 in alist->hash-table in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k5182 in hash-table-exists? in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5184,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[5],a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5199(t4,t3));}
else{
t3=C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5239,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5239(t7,((C_word*)t0)[6],t3);}}

/* k4648 in k4642 in k4631 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_fcall f_4650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm:668: hash-table-resize! */
t2=*((C_word*)lf[82]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* a5708 in g1262 in k5693 in alist->hash-table in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5709,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4642 in k4631 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_fcall f_4644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4644,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(1073741823)))){
t3=C_fixnum_less_or_equal_p(((C_word*)t0)[6],((C_word*)t0)[7]);
t4=t2;
f_4650(t4,(C_truep(t3)?C_fixnum_less_or_equal_p(((C_word*)t0)[7],t1):C_SCHEME_FALSE));}
else{
t3=t2;
f_4650(t3,C_SCHEME_FALSE);}}

/* k3214 in equal?-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t4=C_fixnum_lessp(t1,C_fix(0));
t5=(C_truep(t4)?C_fixnum_negate(t1):t1);
t6=C_fixnum_and(t3,t5);
t7=t2;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_fixnum_modulo(t6,((C_word*)t0)[3]));}

/* k4119 in doloop878 in k4186 in k4183 in hash-table-resize! in k2729 in k2724 in k1720 */
static void C_ccall f_4121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4111(t3,((C_word*)t0)[4],t2);}

/* ##sys#number-hash-hook in k1720 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1725,4,t0,t1,t2,t3);}
/* srfi-69.scm:144: *equal?-hash */
f_2733(t1,t2,t3);}

/* doloop878 in k4186 in k4183 in hash-table-resize! in k2729 in k2724 in k1720 */
static void C_fcall f_4111(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4111,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4121,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4134,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_4134(t8,t3,t4);}}

/* k1720 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1722,2,t0,t1);}
t2=C_mutate2(&lf[0] /* (set! hash-default-randomization ...) */,C_rnd_fix());
t3=C_mutate2((C_word*)lf[1]+1 /* (set! ##sys#number-hash-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1725,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[3]+1 /* (set! number-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1731,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[7]+1 /* (set! object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1952,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[8]+1 /* (set! symbol-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2031,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[9]+1 /* (set! ##sys#check-keyword ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2119,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[13]+1 /* (set! keyword-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2145,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[14]+1 /* (set! eq?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2337,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[15]+1 /* (set! hash-by-identity ...) */,*((C_word*)lf[14]+1));
t11=C_mutate2((C_word*)lf[16]+1 /* (set! eqv?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2649,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t12=C_set_block_item(lf[17] /* *recursive-hash-max-depth* */,0,C_fix(4));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2726,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6231,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:270: make-parameter */
t15=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,C_fix(4),t14);}

/* k5376 in loop in k5290 in hash-table-delete! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[2])?C_i_setslot(((C_word*)t0)[2],C_fix(1),((C_word*)t0)[3]):C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3]));
t3=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[7]);
t4=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm:960: loop */
t2=((C_word*)((C_word*)t0)[9])[1];
f_5359(t2,((C_word*)t0)[8],((C_word*)t0)[10],((C_word*)t0)[3]);}}

/* k2724 in k1720 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2726,2,t0,t1);}
t2=C_mutate2((C_word*)lf[18]+1 /* (set! recursive-hash-max-depth ...) */,t1);
t3=C_set_block_item(lf[19] /* *recursive-hash-max-length* */,0,C_fix(4));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6217,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:279: make-parameter */
t6=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_fix(4),t5);}

/* k3275 in string-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=C_u_i_string_hash(t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t5=C_fixnum_lessp(t2,C_fix(0));
t6=(C_truep(t5)?C_fixnum_negate(t2):t2);
t7=C_fixnum_and(t4,t6);
t8=t3;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fixnum_modulo(t7,((C_word*)t0)[4]));}

/* k4314 in copy-loop in doloop905 in k4212 in *hash-table-copy in k2729 in k2724 in k1720 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4316,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k4531 in loop in k4444 in k4429 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[7]);
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k5290 in hash-table-delete! in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5359(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5359,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5378,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t8=C_slot(t4,C_fix(0));
/* srfi-69.scm:953: test */
t9=((C_word*)t0)[7];
((C_proc4)C_fast_retrieve_proc(t9))(4,t9,t7,((C_word*)t0)[8],t8);}}

/* k4747 in loop in k4697 in k4682 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4468 in loop in k4444 in k4429 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4470,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[7]);
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k4444 in k4429 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_fcall f_4523(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4523,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4551,a[2]=((C_word*)t0)[8],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:748: thunk */
t5=((C_word*)t0)[9];
((C_proc2)C_fast_retrieve_proc(t5))(2,t5,t4);}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4560,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=t2,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t6=C_slot(t4,C_fix(0));
/* srfi-69.scm:753: test */
t7=((C_word*)t0)[11];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k4486 in loop in k4444 in k4429 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:735: func */
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}

/* hash-table->alist in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5615,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[103]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=C_block_size(t5);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5630,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word)li77),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_5630(t11,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* k5611 in hash-table-merge in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:1012: *hash-table-merge! */
f_5519(((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* loop in k4697 in k4682 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_fcall f_4772(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4772,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm:787: func */
t4=((C_word*)t0)[8];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4805,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=t2,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t6=C_slot(t4,C_fix(0));
/* srfi-69.scm:792: test */
t7=((C_word*)t0)[11];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k6028 in hash-table-for-each in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:1112: *hash-table-for-each */
f_5872(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* loop in k4444 in k4429 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_fcall f_4460(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4460,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[8],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:735: thunk */
t5=((C_word*)t0)[9];
((C_proc2)C_fast_retrieve_proc(t5))(2,t5,t4);}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_slot(t4,C_fix(0));
t6=C_eqp(((C_word*)t0)[2],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4500,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=C_slot(t4,C_fix(1));
/* srfi-69.scm:741: func */
t9=((C_word*)t0)[8];
((C_proc3)C_fast_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t7=C_slot(t2,C_fix(1));
/* srfi-69.scm:744: loop */
t13=t1;
t14=t7;
t1=t13;
t2=t14;
goto loop;}}}

/* hash-table-walk in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6035,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[37],lf[112]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6042,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1116: ##sys#check-closure */
t6=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[112]);}

/* k3991 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3712(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:510: ##sys#check-closure */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[45]);}}

/* k3994 in k3991 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t3);
t5=((C_word*)t0)[5];
f_3712(t5,t4);}

/* k4498 in loop in k4444 in k4429 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* loop in hash-table->alist in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5630(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5630,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5646,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word)li76),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5646(t8,t1,t4,t3);}}

/* k5036 in loop in k4940 in k4925 in hash-table-set! in k2729 in k2724 in k1720 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[4]));}
else{
t2=C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:835: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_5008(t3,((C_word*)t0)[2],t2);}}

/* a6058 in k6052 in hash-table-map in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6059,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6067,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:1122: func */
t6=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k4444 in k4429 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=t1;
t3=C_slot(((C_word*)t0)[2],t2);
t4=t3;
t5=C_eqp(((C_word*)t0)[3],((C_word*)t0)[4]);
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4460,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t7,a[11]=((C_word)li46),tmp=(C_word)a,a+=12,tmp));
t9=((C_word*)t7)[1];
f_4460(t9,((C_word*)t0)[10],t4);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t7,a[11]=((C_word*)t0)[4],a[12]=((C_word)li47),tmp=(C_word)a,a+=13,tmp));
t9=((C_word*)t7)[1];
f_4523(t9,((C_word*)t0)[10],t4);}}

/* eq?-hash in k1720 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2337r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2337r(t0,t1,t2,t3);}}

static void C_ccall f_2337r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(4);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_check_exact_2(t6,lf[14]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2385,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t15=t14;
f_2385(2,t15,C_fixnum_xor(t2,t10));}
else{
if(C_truep(C_charp(t2))){
t15=C_fix(C_character_code(t2));
t16=t14;
f_2385(2,t16,C_fixnum_xor(t15,t10));}
else{
switch(t2){
case C_SCHEME_TRUE:
t15=t14;
f_2385(2,t15,C_fixnum_xor(C_fix(256),t10));
case C_SCHEME_FALSE:
t15=t14;
f_2385(2,t15,C_fixnum_xor(C_fix(257),t10));
default:
if(C_truep(C_i_nullp(t2))){
t15=t14;
f_2385(2,t15,C_fixnum_xor(C_fix(258),t10));}
else{
if(C_truep(C_eofp(t2))){
t15=t14;
f_2385(2,t15,C_fixnum_xor(C_fix(259),t10));}
else{
if(C_truep(C_i_symbolp(t2))){
t15=C_slot(t2,C_fix(1));
t16=t14;
f_2385(2,t16,C_u_i_string_hash(t15,t10));}
else{
if(C_truep(C_blockp(t2))){
/* srfi-69.scm:168: *equal?-hash */
f_2733(t14,t2,t10);}
else{
t15=t14;
f_2385(2,t15,C_fixnum_xor(C_fix(262),t10));}}}}}}}}

/* k6052 in hash-table-map in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6059,a[2]=((C_word*)t0)[2],a[3]=((C_word)li99),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:1122: *hash-table-fold */
f_5945(((C_word*)t0)[3],((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST);}

/* k4780 in loop in k4697 in k4682 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4782,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[7]);
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[63],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5060,2,t0,t1);}
t2=C_mutate2((C_word*)lf[93]+1 /* (set! hash-table-ref ...) */,t1);
t3=*((C_word*)lf[39]+1);
t4=C_mutate2((C_word*)lf[94]+1 /* (set! hash-table-ref/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5062,a[2]=t3,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[39]+1);
t6=C_mutate2((C_word*)lf[95]+1 /* (set! hash-table-exists? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5168,a[2]=t5,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[39]+1);
t8=C_mutate2((C_word*)lf[96]+1 /* (set! hash-table-delete! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5276,a[2]=t7,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate2((C_word*)lf[97]+1 /* (set! hash-table-remove! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5407,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[98]+1 /* (set! hash-table-clear! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5503,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2(&lf[100] /* (set! *hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5519,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[101]+1 /* (set! hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5587,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2((C_word*)lf[102]+1 /* (set! hash-table-merge ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5599,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate2((C_word*)lf[103]+1 /* (set! hash-table->alist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5615,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[104]+1 /* (set! alist->hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5688,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[105]+1 /* (set! hash-table-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5742,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[106]+1 /* (set! hash-table-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5807,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2(&lf[107] /* (set! *hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5872,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2(&lf[109] /* (set! *hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5945,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate2((C_word*)lf[110]+1 /* (set! hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6011,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate2((C_word*)lf[111]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6023,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate2((C_word*)lf[112]+1 /* (set! hash-table-walk ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6035,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2((C_word*)lf[113]+1 /* (set! hash-table-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6047,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6070,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6072,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:1127: ##sys#register-record-printer */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t24,lf[37],t25);}

/* hash-table-for-each in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6023,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[37],lf[111]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6030,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1111: ##sys#check-closure */
t6=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[111]);}

/* loop in k5076 in hash-table-ref/default in k5058 in k2729 in k2724 in k1720 */
static C_word C_fcall f_5093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_overflow_check;
loop:
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];
return(t2);}
else{
t2=C_slot(t1,C_fix(0));
t3=C_slot(t2,C_fix(0));
t4=C_eqp(((C_word*)t0)[3],t3);
if(C_truep(t4)){
return(C_slot(t2,C_fix(1)));}
else{
t5=C_slot(t1,C_fix(1));
t8=t5;
t1=t8;
goto loop;}}}

/* k6077 in k6074 in a6071 in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:1132: ##sys#print */
t2=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[115],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k6074 in a6071 in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[4],C_fix(2));
/* srfi-69.scm:1131: ##sys#print */
t4=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k3939 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3718(t3,t2);}
else{
t2=C_i_check_exact_2(((C_word*)t0)[3],lf[45]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(C_fix(0),((C_word*)t0)[3]))){
t4=t3;
f_3947(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm:524: error */
t4=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[45],lf[71],((C_word*)t0)[3]);}}}

/* a6071 in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6072,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6076,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1130: ##sys#print */
t5=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[116],C_SCHEME_FALSE,t3);}

/* k3945 in k3939 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_fixnum_min(C_fix(1073741823),((C_word*)t0)[2]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t4);
t6=((C_word*)t0)[5];
f_3718(t6,t5);}

/* k6068 in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* hash-table-ref/default in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5062,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[37],lf[94]);
t6=C_slot(t2,C_fix(1));
t7=t6;
t8=C_slot(t2,C_fix(3));
t9=t8;
t10=C_slot(t2,C_fix(10));
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5078,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t7,a[5]=t4,a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t12=C_block_size(t7);
/* srfi-69.scm:880: hash */
t13=t10;
((C_proc4)C_fast_retrieve_proc(t13))(4,t13,t11,t3,t12);}

/* hash-table-map in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6047,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[37],lf[113]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6054,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1121: ##sys#check-closure */
t6=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[113]);}

/* k6040 in hash-table-walk in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:1117: *hash-table-for-each */
f_5872(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k5076 in hash-table-ref/default in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5078,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5093,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5093(t4,t3));}
else{
t3=C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5132,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_5132(t7,((C_word*)t0)[7],t3);}}

/* k6096 in a6087 in k2729 in k2724 in k1720 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6098,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=C_slot(((C_word*)t0)[2],C_fix(3));
t5=t4;
t6=C_slot(((C_word*)t0)[2],C_fix(10));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6110,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t8=C_block_size(t3);
/* srfi-69.scm:852: hash */
t9=t6;
((C_proc4)C_fast_retrieve_proc(t9))(4,t9,t7,((C_word*)t0)[5],t8);}

/* k6065 in a6058 in k6052 in hash-table-map in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6067,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,t1,((C_word*)t0)[3]));}

/* eqv?-hash in k1720 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2649r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2649r(t0,t1,t2,t3);}}

static void C_ccall f_2649r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word *a=C_alloc(7);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_check_exact_2(t6,lf[16]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2697,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t15=t14;
f_2697(2,t15,C_fixnum_xor(t2,t10));}
else{
if(C_truep(C_charp(t2))){
t15=C_fix(C_character_code(t2));
t16=t14;
f_2697(2,t16,C_fixnum_xor(t15,t10));}
else{
switch(t2){
case C_SCHEME_TRUE:
t15=t14;
f_2697(2,t15,C_fixnum_xor(C_fix(256),t10));
case C_SCHEME_FALSE:
t15=t14;
f_2697(2,t15,C_fixnum_xor(C_fix(257),t10));
default:
if(C_truep(C_i_nullp(t2))){
t15=t14;
f_2697(2,t15,C_fixnum_xor(C_fix(258),t10));}
else{
if(C_truep(C_eofp(t2))){
t15=t14;
f_2697(2,t15,C_fixnum_xor(C_fix(259),t10));}
else{
if(C_truep(C_i_symbolp(t2))){
t15=C_slot(t2,C_fix(1));
t16=t14;
f_2697(2,t16,C_u_i_string_hash(t15,t10));}
else{
if(C_truep(C_i_numberp(t2))){
t15=t14;
if(C_truep(C_i_flonump(t2))){
t16=C_subbyte(t2,C_fix(7));
t17=C_subbyte(t2,C_fix(6));
t18=C_subbyte(t2,C_fix(5));
t19=C_subbyte(t2,C_fix(4));
t20=C_subbyte(t2,C_fix(3));
t21=C_subbyte(t2,C_fix(2));
t22=C_subbyte(t2,C_fix(1));
t23=C_subbyte(t2,C_fix(0));
t24=C_fixnum_shift_left(t23,C_fix(1));
t25=C_fixnum_plus(t22,t24);
t26=C_fixnum_shift_left(t25,C_fix(1));
t27=C_fixnum_plus(t21,t26);
t28=C_fixnum_shift_left(t27,C_fix(1));
t29=C_fixnum_plus(t20,t28);
t30=C_fixnum_shift_left(t29,C_fix(1));
t31=C_fixnum_plus(t19,t30);
t32=C_fixnum_shift_left(t31,C_fix(1));
t33=C_fixnum_plus(t18,t32);
t34=C_fixnum_shift_left(t33,C_fix(1));
t35=C_fixnum_plus(t17,t34);
t36=C_fixnum_shift_left(t35,C_fix(1));
t37=C_fixnum_plus(t16,t36);
t38=t15;
((C_proc2)(void*)(*((C_word*)t38+1)))(2,t38,C_fixnum_times(C_fix(331804471),t37));}
else{
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2621,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:148: ##sys#number-hash-hook */
t17=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t16,t2,t10);}}
else{
if(C_truep(C_blockp(t2))){
/* srfi-69.scm:168: *equal?-hash */
f_2733(t14,t2,t10);}
else{
t15=t14;
f_2697(2,t15,C_fixnum_xor(C_fix(262),t10));}}}}}}}}}

/* loop in doloop1194 in k5412 in hash-table-remove! in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5454(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5454,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5473,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
t8=C_slot(t4,C_fix(0));
t9=C_slot(t4,C_fix(1));
/* srfi-69.scm:976: func */
t10=((C_word*)t0)[6];
((C_proc4)C_fast_retrieve_proc(t10))(4,t10,t7,t8,t9);}}

/* k3590 in k3587 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_lessp(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(C_truep(t2)?C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
/* srfi-69.scm:442: ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,((C_word*)t0)[4],lf[33],lf[23],lf[34],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k5439 in doloop1194 in k5412 in hash-table-remove! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5428(t3,((C_word*)t0)[4],t2);}

/* hash-table-set! in k2729 in k2724 in k1720 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[23],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4844,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[37],lf[91]);
t6=C_slot(t2,C_fix(2));
t7=C_fixnum_plus(t6,C_fix(1));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4927,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t4,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t10=t9;
t11=t2;
t12=t8;
t13=C_slot(t11,C_fix(1));
t14=t13;
t15=C_slot(t11,C_fix(5));
t16=C_slot(t11,C_fix(6));
t17=t16;
t18=C_block_size(t14);
t19=t18;
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4876,a[2]=t10,a[3]=t11,a[4]=t14,a[5]=t19,a[6]=t12,a[7]=t17,tmp=(C_word)a,a+=8,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4920,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=C_a_i_times(&a,2,t19,t15);
/* srfi-69.scm:664: floor */
t23=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t23+1)))(3,t23,t21,t22);}

/* a6087 in k2729 in k2724 in k1720 */
static void C_ccall f_6088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_6088r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6088r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6088r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6208,a[2]=t3,a[3]=t2,a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp):C_i_car(t4));
t7=t6;
t8=C_i_check_structure_2(t2,lf[37],lf[93]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6098,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:848: ##sys#check-closure */
t10=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t7,lf[93]);}

/* k2159 in keyword-hash in k1720 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[13]);
t3=((C_word*)t0)[3];
t4=C_slot(t3,C_fix(1));
t5=C_u_i_string_hash(t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[5];
t7=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t8=C_fixnum_lessp(t5,C_fix(0));
t9=(C_truep(t8)?C_fixnum_negate(t5):t5);
t10=C_fixnum_and(t7,t9);
t11=t6;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_fixnum_modulo(t10,((C_word*)t0)[2]));}

/* k5911 in doloop1314 in *hash-table-for-each in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5884(t3,((C_word*)t0)[4],t2);}

/* k4891 in k4885 in k4874 in hash-table-set! in k2729 in k2724 in k1720 */
static void C_fcall f_4893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm:668: hash-table-resize! */
t2=*((C_word*)lf[82]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* *hash-table-fold in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5945(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5945,NULL,4,t1,t2,t3,t4);}
t5=C_slot(t2,C_fix(1));
t6=t5;
t7=C_block_size(t6);
t8=t7;
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5957,a[2]=t8,a[3]=t6,a[4]=t10,a[5]=t3,a[6]=((C_word)li94),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_5957(t12,t1,C_fix(0),t4);}

/* g1320 in doloop1314 in *hash-table-for-each in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5892(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5892,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
/* srfi-69.scm:1087: proc */
t5=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* k5471 in loop in doloop1194 in k5412 in hash-table-remove! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[2])?C_i_setslot(((C_word*)t0)[2],C_fix(1),((C_word*)t0)[3]):C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3]));
t3=C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t3);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm:983: loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5454(t2,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[3]);}}

/* *make-hash-function in k2729 in k2724 in k1720 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[41],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3557,3,t0,t1,t2);}
t3=t2;
t4=C_a_i_list(&a,10,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],((C_word*)t0)[10],((C_word*)t0)[11]);
if(C_truep(C_u_i_memq(t3,t4))){
t5=C_rnd_fix();
t6=t2;
t7=C_a_i_list2(&a,2,((C_word*)t0)[6],((C_word*)t0)[7]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_truep(C_u_i_memq(t6,t7))?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3575,a[2]=t2,a[3]=t5,a[4]=((C_word)li20),tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3580,a[2]=t2,a[3]=t5,a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3585,a[2]=t2,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* doloop1314 in *hash-table-for-each in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5884(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5884,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5892,a[2]=((C_word*)t0)[3],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
t5=C_i_check_list_2(t4,lf[108]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5913,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5922,a[2]=t8,a[3]=t3,a[4]=((C_word)li90),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_5922(t10,t6,t4);}}

/* k4885 in k4874 in hash-table-set! in k2729 in k2724 in k1720 */
static void C_fcall f_4887(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4887,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(1073741823)))){
t3=C_fixnum_less_or_equal_p(((C_word*)t0)[6],((C_word*)t0)[7]);
t4=t2;
f_4893(t4,(C_truep(t3)?C_fixnum_less_or_equal_p(((C_word*)t0)[7],t1):C_SCHEME_FALSE));}
else{
t3=t2;
f_4893(t3,C_SCHEME_FALSE);}}

/* for-each-loop1319 in doloop1314 in *hash-table-for-each in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5922(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5922,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5932,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* srfi-69.scm:1081: g1320 */
t5=((C_word*)t0)[3];
f_5892(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* hash-table-fold in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6011,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[37],lf[110]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6018,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:1106: ##sys#check-closure */
t7=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[110]);}

/* hash-for-test in make-hash-table in k2729 in k2724 in k1720 */
static C_word C_fcall f_3636(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_stack_overflow_check;
t1=C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t2=(C_truep(t1)?t1:C_eqp(*((C_word*)lf[39]+1),((C_word*)((C_word*)t0)[3])[1]));
if(C_truep(t2)){
return(((C_word*)t0)[4]);}
else{
t3=C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);
t4=(C_truep(t3)?t3:C_eqp(*((C_word*)lf[40]+1),((C_word*)((C_word*)t0)[3])[1]));
if(C_truep(t4)){
return(((C_word*)t0)[6]);}
else{
t5=C_eqp(((C_word*)t0)[7],((C_word*)((C_word*)t0)[3])[1]);
t6=(C_truep(t5)?t5:C_eqp(*((C_word*)lf[41]+1),((C_word*)((C_word*)t0)[3])[1]));
if(C_truep(t6)){
return(((C_word*)t0)[8]);}
else{
t7=C_eqp(((C_word*)t0)[9],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_truep(t7)?t7:C_eqp(*((C_word*)lf[42]+1),((C_word*)((C_word*)t0)[3])[1]));
if(C_truep(t8)){
return(((C_word*)t0)[10]);}
else{
t9=C_eqp(((C_word*)t0)[11],((C_word*)((C_word*)t0)[3])[1]);
t10=(C_truep(t9)?t9:C_eqp(*((C_word*)lf[43]+1),((C_word*)((C_word*)t0)[3])[1]));
if(C_truep(t10)){
return(((C_word*)t0)[12]);}
else{
t11=C_eqp(((C_word*)t0)[13],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t11)){
return((C_truep(t11)?((C_word*)t0)[14]:C_SCHEME_FALSE));}
else{
t12=C_eqp(*((C_word*)lf[44]+1),((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t12)?((C_word*)t0)[14]:C_SCHEME_FALSE));}}}}}}}

/* k6016 in hash-table-fold in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:1107: *hash-table-fold */
f_5945(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+48)){
C_save_and_reclaim((void*)tr2r,(void*)f_3634r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3634r(t0,t1,t2);}}

static void C_ccall f_3634r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a=C_alloc(48);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[41]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[46];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[47];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3636,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3712,a[2]=t10,a[3]=t8,a[4]=t1,a[5]=t6,a[6]=t14,a[7]=t16,a[8]=t12,a[9]=t17,a[10]=((C_word*)t0)[7],a[11]=t2,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_nullp(((C_word*)t4)[1]))){
t19=t18;
f_3712(t19,C_SCHEME_UNDEFINED);}
else{
t19=C_i_car(((C_word*)t4)[1]);
t20=t19;
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3993,a[2]=t18,a[3]=t6,a[4]=t20,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:509: keyword? */
t22=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t22+1)))(3,t22,t21,t20);}}

/* f_3575 in *make-hash-function in k2729 in k2724 in k1720 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3575,4,t0,t1,t2,t3);}
/* srfi-69.scm:434: user-function */
t4=((C_word*)t0)[2];
((C_proc7)C_fast_retrieve_proc(t4))(7,t4,t1,t2,t3,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k2124 in check-keyword in k1720 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
/* srfi-69.scm:194: ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[10],C_SCHEME_FALSE,lf[11],((C_word*)t0)[4]);}
else{
t2=C_i_car(((C_word*)t0)[3]);
/* srfi-69.scm:194: ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[10],t2,lf[11],((C_word*)t0)[4]);}}}

/* k4212 in *hash-table-copy in k2729 in k2724 in k1720 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4214,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4233,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word)li43),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_4233(t7,t3,C_fix(0));}

/* k4215 in k4212 in *hash-table-copy in k2729 in k2724 in k1720 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_i_setslot(t1,C_fix(2),t2);
t4=C_slot(((C_word*)t0)[2],C_fix(10));
t5=C_i_setslot(t1,C_fix(10),t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k3971 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3973,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3715(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:516: ##sys#check-closure */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[45]);}}

/* k3974 in k3971 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t3);
t5=((C_word*)t0)[5];
f_3715(t5,t4);}

/* f_3580 in *make-hash-function in k2729 in k2724 in k1720 */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3580,4,t0,t1,t2,t3);}
/* srfi-69.scm:436: user-function */
t4=((C_word*)t0)[2];
((C_proc5)C_fast_retrieve_proc(t4))(5,t4,t1,t2,t3,((C_word*)t0)[3]);}

/* ##sys#check-keyword in k1720 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2119r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2119r(t0,t1,t2,t3);}}

static void C_ccall f_2119r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2126,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:193: keyword? */
t5=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3587 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3592,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:439: ##sys#check-exact */
t4=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[23],((C_word*)t0)[4]);}

/* f_3585 in *make-hash-function in k2729 in k2724 in k1720 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3585,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3589,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:438: user-function */
t5=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* keyword-hash in k1720 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_2145r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2145r(t0,t1,t2,t3);}}

static void C_ccall f_2145r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(6);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2161,a[2]=t6,a[3]=t2,a[4]=t11,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:207: ##sys#check-keyword */
t15=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,t2,lf[13]);}

/* k5930 in for-each-loop1319 in doloop1314 in *hash-table-for-each in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5922(t3,((C_word*)t0)[4],t2);}

/* k5999 in fold2 in loop in *hash-table-fold in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_6001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:1101: fold2 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5973(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* loop in hash-table-canonical-length in k2729 in k2724 in k1720 */
static C_word C_fcall f_3533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:
t2=C_slot(t1,C_fix(0));
t3=C_slot(t1,C_fix(1));
t4=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
if(C_truep(t4)){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}
else{
if(C_truep(C_i_nullp(t3))){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}}

/* k6108 in k6096 in a6087 in k2729 in k2724 in k1720 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6110,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6125,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word)li103),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6125(t7,((C_word*)t0)[7],t3);}
else{
t3=C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6167,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word)li104),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_6167(t7,((C_word*)t0)[7],t3);}}

/* hash-table-canonical-length in k2729 in k2724 in k1720 */
static void C_fcall f_3527(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3527,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3533,a[2]=t3,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3533(t4,t2));}

/* recursive-hash in *equal?-hash in k2729 in k2724 in k1720 */
static void C_fcall f_2809(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2809,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_fixnum_greater_or_equal_p(t3,*((C_word*)lf[17]+1)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fixnum_xor(C_fix(99),t4));}
else{
if(C_truep(C_fixnump(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fixnum_xor(t2,t4));}
else{
if(C_truep(C_charp(t2))){
t5=C_fix(C_character_code(t2));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_fixnum_xor(t5,t4));}
else{
switch(t2){
case C_SCHEME_TRUE:
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fixnum_xor(C_fix(256),t4));
case C_SCHEME_FALSE:
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fixnum_xor(C_fix(257),t4));
default:
if(C_truep(C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fixnum_xor(C_fix(258),t4));}
else{
if(C_truep(C_eofp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fixnum_xor(C_fix(259),t4));}
else{
if(C_truep(C_i_symbolp(t2))){
t5=t1;
t6=t2;
t7=t4;
t8=C_slot(t6,C_fix(1));
t9=t5;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_u_i_string_hash(t8,t7));}
else{
if(C_truep(C_i_numberp(t2))){
t5=t1;
t6=t2;
t7=t4;
if(C_truep(C_i_flonump(t6))){
t8=C_subbyte(t6,C_fix(7));
t9=C_subbyte(t6,C_fix(6));
t10=C_subbyte(t6,C_fix(5));
t11=C_subbyte(t6,C_fix(4));
t12=C_subbyte(t6,C_fix(3));
t13=C_subbyte(t6,C_fix(2));
t14=C_subbyte(t6,C_fix(1));
t15=C_subbyte(t6,C_fix(0));
t16=C_fixnum_shift_left(t15,C_fix(1));
t17=C_fixnum_plus(t14,t16);
t18=C_fixnum_shift_left(t17,C_fix(1));
t19=C_fixnum_plus(t13,t18);
t20=C_fixnum_shift_left(t19,C_fix(1));
t21=C_fixnum_plus(t12,t20);
t22=C_fixnum_shift_left(t21,C_fix(1));
t23=C_fixnum_plus(t11,t22);
t24=C_fixnum_shift_left(t23,C_fix(1));
t25=C_fixnum_plus(t10,t24);
t26=C_fixnum_shift_left(t25,C_fix(1));
t27=C_fixnum_plus(t9,t26);
t28=C_fixnum_shift_left(t27,C_fix(1));
t29=C_fixnum_plus(t8,t28);
t30=t5;
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,C_fixnum_times(C_fix(331804471),t29));}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3027,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:148: ##sys#number-hash-hook */
t9=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t6,t7);}}
else{
t5=t2;
if(C_truep(C_blockp(t5))){
t6=t2;
if(C_truep(C_byteblockp(t6))){
t7=t1;
t8=t2;
t9=t4;
t10=t7;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_u_i_string_hash(t8,t9));}
else{
if(C_truep(C_i_pairp(t2))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3065,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:337: g539 */
t8=t7;
f_3065(t8,t1,t2,t4);}
else{
t7=t2;
if(C_truep(C_portp(t7))){
t8=t1;
t9=t2;
t10=t4;
t11=C_peek_fixnum(t9,C_fix(0));
t12=C_fixnum_shift_left(t11,C_fix(4));
t13=C_fixnum_xor(t12,t10);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3124,a[2]=t8,a[3]=t14,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:295: input-port? */
t16=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,t9);}
else{
t8=t2;
if(C_truep(C_specialp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:339: g553 */
t10=t9;
f_3144(t10,t1,t2,t4);}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3156,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:340: g557 */
t10=t9;
f_3156(t10,t1,t2,t4);}}}}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_fixnum_xor(C_fix(262),t4));}}}}}}}}}}

/* k4874 in hash-table-set! in k2729 in k2724 in k1720 */
static void C_fcall f_4876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4876,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4912,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_a_i_times(&a,2,((C_word*)t0)[5],((C_word*)t0)[7]);
/* srfi-69.scm:665: floor */
t6=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k2619 in eqv?-hash in k1720 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(t1));}

/* *hash-table-for-each in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5872(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5872,NULL,3,t1,t2,t3);}
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=C_block_size(t5);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5884,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t9,a[6]=((C_word)li91),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5884(t11,t1,C_fix(0));}

/* k4631 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_fcall f_4633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4633,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4669,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_a_i_times(&a,2,((C_word*)t0)[5],((C_word*)t0)[7]);
/* srfi-69.scm:665: floor */
t6=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k3800 in k3776 in k3772 in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3753(t4,((C_word*)t0)[6],t3);}

/* doloop1219 in *hash-table-merge! in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5531(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5531,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=((C_word*)t0)[3];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5541,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5554,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5554(t8,t3,t4);}}

/* *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_fcall f_4604(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4604,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_slot(t2,C_fix(2));
t7=C_fixnum_plus(t6,C_fix(1));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4684,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t10=t9;
t11=t2;
t12=t8;
t13=C_slot(t11,C_fix(1));
t14=t13;
t15=C_slot(t11,C_fix(5));
t16=C_slot(t11,C_fix(6));
t17=t16;
t18=C_block_size(t14);
t19=t18;
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4633,a[2]=t10,a[3]=t11,a[4]=t14,a[5]=t19,a[6]=t12,a[7]=t17,tmp=(C_word)a,a+=8,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4677,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=C_a_i_times(&a,2,t19,t15);
/* srfi-69.scm:664: floor */
t23=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t23+1)))(3,t23,t21,t22);}

/* *hash-table-merge! in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5519(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5519,NULL,3,t1,t2,t3);}
t4=C_slot(t3,C_fix(1));
t5=t4;
t6=C_block_size(t5);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5531,a[2]=t7,a[3]=t2,a[4]=t9,a[5]=t5,a[6]=((C_word)li72),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5531(t11,t1,C_fix(0));}

/* k5508 in hash-table-clear! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_fix(0)));}

/* hash-table-clear! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5503,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[98]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5510,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(1));
/* srfi-69.scm:989: vector-fill! */
t6=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* *make-hash-table in k2729 in k2724 in k1720 */
static void C_fcall f_3609(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3609,NULL,8,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3613,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nullp(t8))){
/* srfi-69.scm:451: make-vector */
t10=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t4,C_SCHEME_END_OF_LIST);}
else{
t10=t9;
f_3613(2,t10,C_i_car(t8));}}

/* k3611 in *make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
t2=C_a_i_record(&a,11,lf[37],t1,C_fix(0),((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[6],C_SCHEME_FALSE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3623,a[2]=t3,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:454: *make-hash-function */
t5=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* k3621 in k3611 in *make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[2],C_fix(10),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k4918 in hash-table-set! in k2729 in k2724 in k1720 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4876(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4876(t3,t2);}}

/* k4925 in hash-table-set! in k2729 in k2724 in k1720 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(10));
t3=C_slot(((C_word*)t0)[2],C_fix(3));
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(1));
t6=t5;
t7=C_block_size(t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4942,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm:813: hash */
t9=t2;
((C_proc4)C_fast_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[5],t7);}

/* k4910 in k4874 in hash-table-set! in k2729 in k2724 in k1720 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4887(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4887(t3,t2);}}

/* k4378 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_fcall f_4380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4380,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4416,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_a_i_times(&a,2,((C_word*)t0)[5],((C_word*)t0)[7]);
/* srfi-69.scm:665: floor */
t6=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* hash-table-weak-keys in k2729 in k2724 in k1720 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4054,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[78]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(7)));}

/* loop in k6108 in k6096 in a6087 in k2729 in k2724 in k1720 */
static void C_fcall f_6167(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6167,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* srfi-69.scm:865: def */
t3=((C_word*)t0)[2];
((C_proc2)C_fast_retrieve_proc(t3))(2,t3,t1);}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6186,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=C_slot(t4,C_fix(0));
/* srfi-69.scm:867: test */
t7=((C_word*)t0)[4];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[5],t6);}}

/* loop in hash-table-keys in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5757(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5757,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5773,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5773(t8,t1,t4,t3);}}

/* hash-table-max-load in k2729 in k2724 in k1720 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4045,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[77]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(6)));}

/* k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4352,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_fixnum_plus(t2,C_fix(1));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=t5;
t7=((C_word*)t0)[2];
t8=t4;
t9=C_slot(t7,C_fix(1));
t10=t9;
t11=C_slot(t7,C_fix(5));
t12=C_slot(t7,C_fix(6));
t13=t12;
t14=C_block_size(t10);
t15=t14;
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4380,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t15,a[6]=t8,a[7]=t13,tmp=(C_word)a,a+=8,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4424,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=C_a_i_times(&a,2,t15,t11);
/* srfi-69.scm:664: floor */
t19=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t17,t18);}

/* hash-table-values in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5807,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[106]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=C_block_size(t5);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5822,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word)li87),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_5822(t11,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* hash-table-min-load in k2729 in k2724 in k1720 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4036,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[76]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(5)));}

/* k3841 in k3776 in k3772 in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(C_flonum_lessp(lf[60],((C_word*)t0)[3]))?C_flonum_lessp(((C_word*)t0)[3],lf[61]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t5=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3753(t6,((C_word*)t0)[6],t5);}
else{
/* srfi-69.scm:556: error */
t4=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[45],lf[62],((C_word*)t0)[3]);}}

/* k3844 in k3841 in k3776 in k3772 in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3753(t4,((C_word*)t0)[6],t3);}

/* loop in vector-hash in *equal?-hash in k2729 in k2724 in k1720 */
static void C_fcall f_2753(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2753,NULL,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_fixnum_shift_left(t2,C_fix(4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2787,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t9=C_slot(((C_word*)t0)[3],t3);
t10=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:317: recursive-hash */
t11=((C_word*)((C_word*)t0)[5])[1];
f_2809(t11,t8,t9,t10,((C_word*)t0)[6]);}}

/* hash-table-keys in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5742,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[105]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=C_block_size(t5);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5757,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_5757(t11,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* k4940 in k4925 in hash-table-set! in k2729 in k2724 in k1720 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
t2=t1;
t3=C_slot(((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4948,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t6)){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4959,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t8,a[10]=((C_word)li54),tmp=(C_word)a,a+=11,tmp));
t10=((C_word*)t8)[1];
f_4959(t10,t5,t4);}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t8,a[10]=((C_word*)t0)[5],a[11]=((C_word)li55),tmp=(C_word)a,a+=12,tmp));
t10=((C_word*)t8)[1];
f_5008(t10,t5,t4);}}

/* loop2 in loop in hash-table-values in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5838(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5838,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:1069: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5822(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(1));
t7=C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm:1070: loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k4946 in k4940 in k4925 in hash-table-set! in k2729 in k2724 in k1720 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[92]+1));}

/* k3813 in k3776 in k3772 in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_fixnum_min(C_fix(1073741823),((C_word*)t0)[2]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3753(t5,((C_word*)t0)[6],t4);}

/* hash-table-hash-function in k2729 in k2724 in k1720 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4027,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(4)));}

/* k2785 in loop in vector-hash in *equal?-hash in k2729 in k2724 in k1720 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],t1);
t3=C_fixnum_plus(((C_word*)t0)[3],t2);
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:315: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2753(t6,((C_word*)t0)[7],t3,t4,t5);}

/* hash-table-initial in k2729 in k2724 in k1720 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4084,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[81]);
t4=C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm:630: thunk */
t5=t4;
((C_proc2)C_fast_retrieve_proc(t5))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* loop in hash-table-values in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5822(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5822,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5838,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word)li86),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5838(t8,t1,t4,t3);}}

/* k3867 in k3864 in k3776 in k3772 in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3753(t4,((C_word*)t0)[6],t3);}

/* k3864 in k3776 in k3772 in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(C_flonum_lessp(lf[60],((C_word*)t0)[3]))?C_flonum_lessp(((C_word*)t0)[3],lf[61]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t5=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3753(t6,((C_word*)t0)[6],t5);}
else{
/* srfi-69.scm:561: error */
t4=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[45],lf[65],((C_word*)t0)[3]);}}

/* loop in k5290 in hash-table-delete! in k5058 in k2729 in k2724 in k1720 */
static C_word C_fcall f_5312(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_stack_overflow_check;
loop:
if(C_truep(C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
t5=C_slot(t3,C_fix(0));
t6=C_eqp(((C_word*)t0)[2],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?C_i_setslot(t1,C_fix(1),t4):C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[4],t4));
t8=C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[6]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* a6230 in k1720 */
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6231,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6238,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t4=t2;
t5=t3;
f_6238(t5,C_fixnum_greaterp(t4,C_fix(0)));}
else{
t4=t3;
f_6238(t4,C_SCHEME_FALSE);}}

/* k6236 in a6230 in k1720 */
static void C_fcall f_6238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=C_mutate2((C_word*)lf[17]+1 /* (set! *recursive-hash-max-depth* ...) */,((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=*((C_word*)lf[17]+1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[17]+1));}}

/* hash-table-has-initial? in k2729 in k2724 in k1720 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4072,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[80]);
t4=C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* k6184 in loop in k6108 in k6096 in a6087 in k2729 in k2724 in k1720 */
static void C_ccall f_6186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(((C_word*)t0)[3],C_fix(1)));}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:869: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6167(t3,((C_word*)t0)[2],t2);}}

/* f_3833 in k3776 in k3772 in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3833,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4389 in k4378 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_fcall f_4391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4391,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(1073741823)))){
t3=C_fixnum_less_or_equal_p(((C_word*)t0)[6],((C_word*)t0)[7]);
t4=t2;
f_4397(t4,(C_truep(t3)?C_fixnum_less_or_equal_p(((C_word*)t0)[7],t1):C_SCHEME_FALSE));}
else{
t3=t2;
f_4397(t3,C_SCHEME_FALSE);}}

/* k1918 in k1745 in number-hash in k1720 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t4=C_fixnum_lessp(t1,C_fix(0));
t5=(C_truep(t4)?C_fixnum_negate(t1):t1);
t6=C_fixnum_and(t3,t5);
t7=t2;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_fixnum_modulo(t6,((C_word*)t0)[3]));}

/* k4395 in k4389 in k4378 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_fcall f_4397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm:668: hash-table-resize! */
t2=*((C_word*)lf[82]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* hash-table-weak-values in k2729 in k2724 in k1720 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4063,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[79]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(8)));}

/* k3746 in k3719 in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm:573: error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[45],lf[51],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=((C_word*)t0)[2];
f_3724(2,t2,C_SCHEME_UNDEFINED);}}

/* k3742 in k3726 in k3722 in k3719 in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
/* srfi-69.scm:585: *make-hash-table */
f_3609(((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);}

/* loop in doloop878 in k4186 in k4183 in hash-table-resize! in k2729 in k2724 in k1720 */
static void C_fcall f_4134(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4134,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_slot(t4,C_fix(0));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4150,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm:643: hash */
t8=((C_word*)t0)[4];
((C_proc4)C_fast_retrieve_proc(t8))(4,t8,t7,t6,((C_word*)t0)[5]);}}

/* symbol-hash in k1720 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2031r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2031r(t0,t1,t2,t3);}}

static void C_ccall f_2031r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_nullp(t7);
t9=(C_truep(t8)?lf[0]:C_i_car(t7));
t10=C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:C_i_cdr(t7));
t12=C_i_check_symbol_2(t2,lf[8]);
t13=C_i_check_exact_2(t5,lf[8]);
t14=t2;
t15=C_slot(t14,C_fix(1));
t16=C_u_i_string_hash(t15,t9);
t17=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t18=C_fixnum_lessp(t16,C_fix(0));
t19=(C_truep(t18)?C_fixnum_negate(t16):t16);
t20=C_fixnum_and(t17,t19);
t21=t1;
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,C_fixnum_modulo(t20,t5));}

/* loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_fcall f_3753(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3753,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3764,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3774,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t5,tmp=(C_word)a,a+=13,tmp);
/* srfi-69.scm:534: keyword? */
t7=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k4189 in k4186 in k4183 in hash-table-resize! in k2729 in k2724 in k1720 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[4]));}

/* g539 in recursive-hash in *equal?-hash in k2729 in k2724 in k1720 */
static void C_fcall f_3065(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3065,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3089,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
t6=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:290: recursive-hash */
t7=((C_word*)((C_word*)t0)[3])[1];
f_2809(t7,t4,t5,t6,t3);}

/* invarg-err in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_fcall f_3764(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3764,NULL,3,t0,t1,t2);}
/* srfi-69.scm:533: error */
t3=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[45],t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4721 in loop in k4697 in k4682 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4723,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[7]);
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k3416 in string-ci-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=C_u_i_string_ci_hash(t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t5=C_fixnum_lessp(t2,C_fix(0));
t6=(C_truep(t5)?C_fixnum_negate(t2):t2);
t7=C_fixnum_and(t4,t6);
t8=t3;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fixnum_modulo(t7,((C_word*)t0)[4]));}

/* hash-table-remove! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5407,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[37],lf[97]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5414,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:966: ##sys#check-closure */
t6=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[97]);}

/* k4183 in hash-table-resize! in k2729 in k2724 in k1720 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:653: make-vector */
t3=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_SCHEME_END_OF_LIST);}

/* k4186 in k4183 in hash-table-resize! in k2729 in k2724 in k1720 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[3],C_fix(10));
t5=((C_word*)t0)[4];
t6=t2;
t7=t4;
t8=C_block_size(t5);
t9=t8;
t10=C_block_size(t6);
t11=t10;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4111,a[2]=t9,a[3]=t13,a[4]=t5,a[5]=t6,a[6]=t7,a[7]=t11,a[8]=((C_word)li40),tmp=(C_word)a,a+=9,tmp));
t15=((C_word*)t13)[1];
f_4111(t15,t3,C_fix(0));}

/* k3772 in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3774,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3778,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_pairp(t3))){
t5=t4;
f_3778(2,t5,C_u_i_car(t3));}
else{
/* srfi-69.scm:538: invarg-err */
t5=((C_word*)t0)[12];
f_3764(t5,t4,lf[69]);}}
else{
/* srfi-69.scm:570: invarg-err */
t2=((C_word*)t0)[12];
f_3764(t2,((C_word*)t0)[4],lf[70]);}}

/* k3776 in k3772 in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3778,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_eqp(((C_word*)t0)[5],lf[53]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:541: ##sys#check-closure */
t6=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[45]);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[55]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3802,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:544: ##sys#check-closure */
t7=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,lf[45]);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[56]);
if(C_truep(t6)){
t7=C_i_check_exact_2(t2,lf[45]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3815,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_lessp(C_fix(0),t2))){
t9=t8;
f_3815(2,t9,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm:549: error */
t9=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[45],lf[57],t2);}}
else{
t7=C_eqp(((C_word*)t0)[5],lf[58]);
if(C_truep(t7)){
t8=C_mutate2(((C_word *)((C_word*)t0)[9])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3833,a[2]=t2,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp));
t9=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t10=((C_word*)((C_word*)t0)[3])[1];
f_3753(t10,((C_word*)t0)[4],t9);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[59]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3843,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:554: ##sys#check-inexact */
t10=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,lf[45]);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[64]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[11],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:559: ##sys#check-inexact */
t11=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,lf[45]);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[66]);
if(C_truep(t10)){
if(C_truep(t2)){
t11=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t12=((C_word*)((C_word*)t0)[3])[1];
f_3753(t12,((C_word*)t0)[4],t11);}
else{
t11=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t12=((C_word*)((C_word*)t0)[3])[1];
f_3753(t12,((C_word*)t0)[4],t11);}}
else{
t11=C_eqp(((C_word*)t0)[5],lf[67]);
if(C_truep(t11)){
if(C_truep(t2)){
t12=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t13=((C_word*)((C_word*)t0)[3])[1];
f_3753(t13,((C_word*)t0)[4],t12);}
else{
t12=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t13=((C_word*)((C_word*)t0)[3])[1];
f_3753(t13,((C_word*)t0)[4],t12);}}
else{
/* srfi-69.scm:568: invarg-err */
t12=((C_word*)t0)[12];
f_3764(t12,t3,lf[68]);}}}}}}}}}

/* k4429 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4431,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(10));
t3=C_slot(((C_word*)t0)[2],C_fix(3));
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(1));
t6=t5;
t7=C_block_size(t6);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4446,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm:729: hash */
t9=t2;
((C_proc4)C_fast_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[4],t7);}

/* k3087 in g539 in recursive-hash in *equal?-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3089,2,t0,t1);}
t2=C_fixnum_shift_left(t1,C_fix(16));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3077,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:291: recursive-hash */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2809(t7,t4,t5,t6,((C_word*)t0)[6]);}

/* k3779 in k3776 in k3772 in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_u_i_cdr(((C_word*)t0)[2]);
/* srfi-69.scm:569: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3753(t3,((C_word*)t0)[4],t2);}

/* doloop1194 in k5412 in hash-table-remove! in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5428(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5428,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)((C_word*)t0)[4])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5441,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[6],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5454,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[7],a[7]=((C_word)li66),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_5454(t8,t3,C_SCHEME_FALSE,t4);}}

/* k5412 in hash-table-remove! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5414,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=C_block_size(t3);
t5=t4;
t6=C_slot(((C_word*)t0)[2],C_fix(2));
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5428,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t8,a[5]=t10,a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t12=((C_word*)t10)[1];
f_5428(t12,((C_word*)t0)[4],C_fix(0));}

/* k3790 in k3776 in k3772 in loop in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:569: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3753(t4,((C_word*)t0)[6],t3);}

/* hash-table-equivalence-function in k2729 in k2724 in k1720 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4018,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[74]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(3)));}

/* k3025 in recursive-hash in *equal?-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(t1));}

/* k3456 in string-ci-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* srfi-69.scm:373: ##sys#check-range */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t2,((C_word*)t0)[5],C_fix(0),t3,lf[24]);}

/* k4148 in loop in doloop878 in k4186 in k4183 in hash-table-resize! in k2729 in k2724 in k1720 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4150,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_slot(((C_word*)t0)[4],t1);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_i_setslot(((C_word*)t0)[4],t1,t5);
t7=C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:646: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_4134(t8,((C_word*)t0)[7],t7);}

/* k1912 in k1745 in number-hash in k1720 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(t1));}

/* hash-table-size in k2729 in k2724 in k1720 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4009,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[73]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(2)));}

/* hash-table? in k2729 in k2724 in k1720 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4003,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[37]));}

/* k3459 in k3456 in string-ci-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:374: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3075 in k3087 in g539 in recursive-hash in *equal?-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fixnum_plus(((C_word*)t0)[3],t1));}

/* loop2 in loop in hash-table-keys in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5773(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5773,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:1054: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5757(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(0));
t7=C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm:1055: loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k2383 in eq?-hash in k1720 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t4=C_fixnum_lessp(t1,C_fix(0));
t5=(C_truep(t4)?C_fixnum_negate(t1):t1);
t6=C_fixnum_and(t3,t5);
t7=t2;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_fixnum_modulo(t6,((C_word*)t0)[3]));}

/* loop in k4697 in k4682 in *hash-table-update!/default in k2729 in k2724 in k1720 */
static void C_fcall f_4713(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4713,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm:774: func */
t4=((C_word*)t0)[8];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_slot(t4,C_fix(0));
t6=C_eqp(((C_word*)t0)[2],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4749,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=C_slot(t4,C_fix(1));
/* srfi-69.scm:780: func */
t9=((C_word*)t0)[8];
((C_proc3)C_fast_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t7=C_slot(t2,C_fix(1));
/* srfi-69.scm:783: loop */
t12=t1;
t13=t7;
t1=t12;
t2=t13;
goto loop;}}}

/* k2003 in object-uid-hash in k1720 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM);
t4=C_fixnum_lessp(t1,C_fix(0));
t5=(C_truep(t4)?C_fixnum_negate(t1):t1);
t6=C_fixnum_and(t3,t5);
t7=t2;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_fixnum_modulo(t6,((C_word*)t0)[3]));}

/* f_4595 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
/* srfi-69.scm:716: ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[87],lf[85],lf[88],((C_word*)t0)[2],((C_word*)t0)[3]);}

/* loop in *hash-table-fold in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5957(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5957,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5973,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word)li93),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5973(t8,t1,t4,t3);}}

/* alist->hash-table in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5688r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5688r(t0,t1,t2,t3);}}

static void C_ccall f_5688r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=C_i_check_list_2(t2,lf[104]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5695,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,*((C_word*)lf[45]+1),t3);}

/* f_6208 in a6087 in k2729 in k2724 in k1720 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6208,2,t0,t1);}
/* srfi-69.scm:844: ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[87],lf[93],lf[118],((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3318 in k3315 in string-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:362: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[25]+1)))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* g1262 in k5693 in alist->hash-table in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5696(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5696,NULL,3,t0,t1,t2);}
t3=C_i_check_pair_2(t2,lf[104]);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5709,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp);
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm:1038: *hash-table-update!/default */
t7=lf[89];
f_4604(t7,t1,((C_word*)t0)[2],t4,t5,t6);}

/* k5693 in alist->hash-table in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5695,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5696,a[2]=t2,a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5717,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5719,a[2]=t7,a[3]=t3,a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_5719(t9,t5,t4);}

/* a6216 in k2724 in k1720 */
static void C_ccall f_6217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6217,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6224,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t4=t2;
t5=t3;
f_6224(t5,C_fixnum_greaterp(t4,C_fix(0)));}
else{
t4=t3;
f_6224(t4,C_SCHEME_FALSE);}}

/* hash-table-resize! in k2729 in k2724 in k1720 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4178,5,t0,t1,t2,t3,t4);}
t5=C_fixnum_times(t4,C_fix(2));
t6=C_i_fixnum_min(C_fix(1073741823),t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4185,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:652: hash-table-canonical-length */
f_3527(t7,lf[29],t6);}

/* k4561 in k4558 in loop in k4444 in k4429 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4558 in loop in k4444 in k4429 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4560,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:754: func */
t4=((C_word*)t0)[4];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:757: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4523(t3,((C_word*)t0)[3],t2);}}

/* k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_fcall f_3718(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3718,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[11],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word)li27),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_3753(t6,t2,((C_word*)((C_word*)t0)[12])[1]);}

/* k6222 in a6216 in k2724 in k1720 */
static void C_fcall f_6224(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=C_mutate2((C_word*)lf[19]+1 /* (set! *recursive-hash-max-length* ...) */,((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=*((C_word*)lf[19]+1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[19]+1));}}

/* *hash-table-copy in k2729 in k2724 in k1720 */
static void C_fcall f_4204(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4204,NULL,2,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=t3;
t5=C_block_size(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4214,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:677: make-vector */
t8=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t6,C_SCHEME_END_OF_LIST);}

/* k4549 in loop in k4444 in k4429 in k4350 in k4347 in k4341 in hash-table-update! in k2729 in k2724 in k1720 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:748: func */
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}

/* k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_fcall f_3712(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3712,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[12])[1]))){
t3=t2;
f_3715(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_i_car(((C_word*)((C_word*)t0)[12])[1]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3973,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:515: keyword? */
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}

/* k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_fcall f_3715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3715,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[12])[1]))){
t3=t2;
f_3718(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_i_car(((C_word*)((C_word*)t0)[12])[1]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3941,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:521: keyword? */
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}

/* k3315 in string-hash in k2729 in k2724 in k1720 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* srfi-69.scm:361: ##sys#check-range */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t2,((C_word*)t0)[5],C_fix(0),t3,lf[24]);}

/* k3726 in k3722 in k3719 in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3728,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
/* srfi-69.scm:585: *make-hash-table */
f_3609(((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t3=f_3636(((C_word*)t0)[9]);
if(C_truep(t3)){
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
/* srfi-69.scm:585: *make-hash-table */
f_3609(((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3744,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm:582: warning */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[45],lf[49]);}}}

/* k3719 in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3748,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:572: fp< */
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]);}

/* k3722 in k3719 in k3716 in k3713 in k3710 in make-hash-table in k2729 in k2724 in k1720 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm:575: hash-table-canonical-length */
f_3527(t2,lf[29],((C_word*)((C_word*)t0)[2])[1]);}

/* loop2 in loop in hash-table->alist in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5646(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5646,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:1026: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5630(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(0));
t7=C_slot(t5,C_fix(1));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm:1027: loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* loop in k4940 in k4925 in hash-table-set! in k2729 in k2724 in k1720 */
static void C_fcall f_5008(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5008,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[6],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_set_i_slot(((C_word*)t0)[7],C_fix(2),((C_word*)t0)[8]));}
else{
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5038,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t6=C_slot(t4,C_fix(0));
/* srfi-69.scm:833: test */
t7=((C_word*)t0)[10];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* fold2 in loop in *hash-table-fold in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5973(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5973,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* srfi-69.scm:1099: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5957(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(0));
t5=C_slot(t2,C_fix(1));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6001,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_slot(t4,C_fix(0));
t9=C_slot(t4,C_fix(1));
/* srfi-69.scm:1102: func */
t10=((C_word*)t0)[5];
((C_proc5)C_fast_retrieve_proc(t10))(5,t10,t7,t8,t9,t3);}}

/* loop in k5182 in hash-table-exists? in k5058 in k2729 in k2724 in k1720 */
static void C_fcall f_5239(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5239,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5252,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm:918: test */
t6=((C_word*)t0)[3];
((C_proc4)C_fast_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[4],t5);}}

/* number-hash in k1720 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1731r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1731r(t0,t1,t2,t3);}}

static void C_ccall f_1731r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(6);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[0]:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1747,a[2]=t6,a[3]=t1,a[4]=t2,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_numberp(t2))){
t15=t14;
f_1747(2,t15,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm:157: ##sys#signal-hook */
t15=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t15+1)))(6,t15,t14,lf[5],lf[3],lf[6],t2);}}

/* loop in k4940 in k4925 in hash-table-set! in k2729 in k2724 in k1720 */
static void C_fcall f_4959(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4959,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[6],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_set_i_slot(((C_word*)t0)[7],C_fix(2),((C_word*)t0)[8]));}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_setslot(t3,C_fix(1),((C_word*)t0)[3]));}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm:825: loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* hash-table-merge! in k5058 in k2729 in k2724 in k1720 */
static void C_ccall f_5587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5587,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[37],lf[101]);
t5=C_i_check_structure_2(t3,lf[37],lf[101]);
/* srfi-69.scm:1007: *hash-table-merge! */
f_5519(t1,t2,t3);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[244] = {
{"f_5292:srfi_2d69_2escm",(void*)f_5292},
{"f_5580:srfi_2d69_2escm",(void*)f_5580},
{"f_5599:srfi_2d69_2escm",(void*)f_5599},
{"f_5567:srfi_2d69_2escm",(void*)f_5567},
{"f_4424:srfi_2d69_2escm",(void*)f_4424},
{"f_4416:srfi_2d69_2escm",(void*)f_4416},
{"f_5252:srfi_2d69_2escm",(void*)f_5252},
{"f_2697:srfi_2d69_2escm",(void*)f_2697},
{"f_5541:srfi_2d69_2escm",(void*)f_5541},
{"f_3384:srfi_2d69_2escm",(void*)f_3384},
{"f_4295:srfi_2d69_2escm",(void*)f_4295},
{"f_5554:srfi_2d69_2escm",(void*)f_5554},
{"f_5148:srfi_2d69_2escm",(void*)f_5148},
{"f_1747:srfi_2d69_2escm",(void*)f_1747},
{"f_3156:srfi_2d69_2escm",(void*)f_3156},
{"f_5199:srfi_2d69_2escm",(void*)f_5199},
{"f_3168:srfi_2d69_2escm",(void*)f_3168},
{"f_4839:srfi_2d69_2escm",(void*)f_4839},
{"f_4832:srfi_2d69_2escm",(void*)f_4832},
{"f_4343:srfi_2d69_2escm",(void*)f_4343},
{"f_4349:srfi_2d69_2escm",(void*)f_4349},
{"f_4330:srfi_2d69_2escm",(void*)f_4330},
{"f_4339:srfi_2d69_2escm",(void*)f_4339},
{"f_5276:srfi_2d69_2escm",(void*)f_5276},
{"f_4808:srfi_2d69_2escm",(void*)f_4808},
{"f_4805:srfi_2d69_2escm",(void*)f_4805},
{"f_4233:srfi_2d69_2escm",(void*)f_4233},
{"f_1952:srfi_2d69_2escm",(void*)f_1952},
{"f_5168:srfi_2d69_2escm",(void*)f_5168},
{"f_3124:srfi_2d69_2escm",(void*)f_3124},
{"f_5132:srfi_2d69_2escm",(void*)f_5132},
{"f_3144:srfi_2d69_2escm",(void*)f_3144},
{"f_4699:srfi_2d69_2escm",(void*)f_4699},
{"f_2736:srfi_2d69_2escm",(void*)f_2736},
{"f_2733:srfi_2d69_2escm",(void*)f_2733},
{"f_2731:srfi_2d69_2escm",(void*)f_2731},
{"f_4684:srfi_2d69_2escm",(void*)f_4684},
{"f_3243:srfi_2d69_2escm",(void*)f_3243},
{"toplevel:srfi_2d69_2escm",(void*)C_srfi_2d69_toplevel},
{"f_5729:srfi_2d69_2escm",(void*)f_5729},
{"f_4677:srfi_2d69_2escm",(void*)f_4677},
{"f_6125:srfi_2d69_2escm",(void*)f_6125},
{"f_4669:srfi_2d69_2escm",(void*)f_4669},
{"f_4289:srfi_2d69_2escm",(void*)f_4289},
{"f_5719:srfi_2d69_2escm",(void*)f_5719},
{"f_5717:srfi_2d69_2escm",(void*)f_5717},
{"f_5184:srfi_2d69_2escm",(void*)f_5184},
{"f_4650:srfi_2d69_2escm",(void*)f_4650},
{"f_5709:srfi_2d69_2escm",(void*)f_5709},
{"f_4644:srfi_2d69_2escm",(void*)f_4644},
{"f_3216:srfi_2d69_2escm",(void*)f_3216},
{"f_4121:srfi_2d69_2escm",(void*)f_4121},
{"f_1725:srfi_2d69_2escm",(void*)f_1725},
{"f_4111:srfi_2d69_2escm",(void*)f_4111},
{"f_1722:srfi_2d69_2escm",(void*)f_1722},
{"f_5378:srfi_2d69_2escm",(void*)f_5378},
{"f_2726:srfi_2d69_2escm",(void*)f_2726},
{"f_3277:srfi_2d69_2escm",(void*)f_3277},
{"f_4316:srfi_2d69_2escm",(void*)f_4316},
{"f_4533:srfi_2d69_2escm",(void*)f_4533},
{"f_5359:srfi_2d69_2escm",(void*)f_5359},
{"f_4749:srfi_2d69_2escm",(void*)f_4749},
{"f_4470:srfi_2d69_2escm",(void*)f_4470},
{"f_4523:srfi_2d69_2escm",(void*)f_4523},
{"f_4488:srfi_2d69_2escm",(void*)f_4488},
{"f_5615:srfi_2d69_2escm",(void*)f_5615},
{"f_5613:srfi_2d69_2escm",(void*)f_5613},
{"f_4772:srfi_2d69_2escm",(void*)f_4772},
{"f_6030:srfi_2d69_2escm",(void*)f_6030},
{"f_4460:srfi_2d69_2escm",(void*)f_4460},
{"f_6035:srfi_2d69_2escm",(void*)f_6035},
{"f_3993:srfi_2d69_2escm",(void*)f_3993},
{"f_3996:srfi_2d69_2escm",(void*)f_3996},
{"f_4500:srfi_2d69_2escm",(void*)f_4500},
{"f_5630:srfi_2d69_2escm",(void*)f_5630},
{"f_5038:srfi_2d69_2escm",(void*)f_5038},
{"f_6059:srfi_2d69_2escm",(void*)f_6059},
{"f_4446:srfi_2d69_2escm",(void*)f_4446},
{"f_2337:srfi_2d69_2escm",(void*)f_2337},
{"f_6054:srfi_2d69_2escm",(void*)f_6054},
{"f_4782:srfi_2d69_2escm",(void*)f_4782},
{"f_5060:srfi_2d69_2escm",(void*)f_5060},
{"f_6023:srfi_2d69_2escm",(void*)f_6023},
{"f_5093:srfi_2d69_2escm",(void*)f_5093},
{"f_6079:srfi_2d69_2escm",(void*)f_6079},
{"f_6076:srfi_2d69_2escm",(void*)f_6076},
{"f_3941:srfi_2d69_2escm",(void*)f_3941},
{"f_6072:srfi_2d69_2escm",(void*)f_6072},
{"f_3947:srfi_2d69_2escm",(void*)f_3947},
{"f_6070:srfi_2d69_2escm",(void*)f_6070},
{"f_5062:srfi_2d69_2escm",(void*)f_5062},
{"f_6047:srfi_2d69_2escm",(void*)f_6047},
{"f_6042:srfi_2d69_2escm",(void*)f_6042},
{"f_5078:srfi_2d69_2escm",(void*)f_5078},
{"f_6098:srfi_2d69_2escm",(void*)f_6098},
{"f_6067:srfi_2d69_2escm",(void*)f_6067},
{"f_2649:srfi_2d69_2escm",(void*)f_2649},
{"f_5454:srfi_2d69_2escm",(void*)f_5454},
{"f_3592:srfi_2d69_2escm",(void*)f_3592},
{"f_5441:srfi_2d69_2escm",(void*)f_5441},
{"f_4844:srfi_2d69_2escm",(void*)f_4844},
{"f_6088:srfi_2d69_2escm",(void*)f_6088},
{"f_2161:srfi_2d69_2escm",(void*)f_2161},
{"f_5913:srfi_2d69_2escm",(void*)f_5913},
{"f_4893:srfi_2d69_2escm",(void*)f_4893},
{"f_5945:srfi_2d69_2escm",(void*)f_5945},
{"f_5892:srfi_2d69_2escm",(void*)f_5892},
{"f_5473:srfi_2d69_2escm",(void*)f_5473},
{"f_3557:srfi_2d69_2escm",(void*)f_3557},
{"f_5884:srfi_2d69_2escm",(void*)f_5884},
{"f_4887:srfi_2d69_2escm",(void*)f_4887},
{"f_5922:srfi_2d69_2escm",(void*)f_5922},
{"f_6011:srfi_2d69_2escm",(void*)f_6011},
{"f_3636:srfi_2d69_2escm",(void*)f_3636},
{"f_6018:srfi_2d69_2escm",(void*)f_6018},
{"f_3634:srfi_2d69_2escm",(void*)f_3634},
{"f_3575:srfi_2d69_2escm",(void*)f_3575},
{"f_2126:srfi_2d69_2escm",(void*)f_2126},
{"f_4214:srfi_2d69_2escm",(void*)f_4214},
{"f_4217:srfi_2d69_2escm",(void*)f_4217},
{"f_3973:srfi_2d69_2escm",(void*)f_3973},
{"f_3976:srfi_2d69_2escm",(void*)f_3976},
{"f_3580:srfi_2d69_2escm",(void*)f_3580},
{"f_2119:srfi_2d69_2escm",(void*)f_2119},
{"f_3589:srfi_2d69_2escm",(void*)f_3589},
{"f_3585:srfi_2d69_2escm",(void*)f_3585},
{"f_2145:srfi_2d69_2escm",(void*)f_2145},
{"f_5932:srfi_2d69_2escm",(void*)f_5932},
{"f_6001:srfi_2d69_2escm",(void*)f_6001},
{"f_3533:srfi_2d69_2escm",(void*)f_3533},
{"f_6110:srfi_2d69_2escm",(void*)f_6110},
{"f_3527:srfi_2d69_2escm",(void*)f_3527},
{"f_2809:srfi_2d69_2escm",(void*)f_2809},
{"f_4876:srfi_2d69_2escm",(void*)f_4876},
{"f_2621:srfi_2d69_2escm",(void*)f_2621},
{"f_5872:srfi_2d69_2escm",(void*)f_5872},
{"f_4633:srfi_2d69_2escm",(void*)f_4633},
{"f_3802:srfi_2d69_2escm",(void*)f_3802},
{"f_5531:srfi_2d69_2escm",(void*)f_5531},
{"f_4604:srfi_2d69_2escm",(void*)f_4604},
{"f_5519:srfi_2d69_2escm",(void*)f_5519},
{"f_5510:srfi_2d69_2escm",(void*)f_5510},
{"f_5503:srfi_2d69_2escm",(void*)f_5503},
{"f_3609:srfi_2d69_2escm",(void*)f_3609},
{"f_3613:srfi_2d69_2escm",(void*)f_3613},
{"f_3623:srfi_2d69_2escm",(void*)f_3623},
{"f_4920:srfi_2d69_2escm",(void*)f_4920},
{"f_4927:srfi_2d69_2escm",(void*)f_4927},
{"f_4912:srfi_2d69_2escm",(void*)f_4912},
{"f_4380:srfi_2d69_2escm",(void*)f_4380},
{"f_4054:srfi_2d69_2escm",(void*)f_4054},
{"f_6167:srfi_2d69_2escm",(void*)f_6167},
{"f_5757:srfi_2d69_2escm",(void*)f_5757},
{"f_4045:srfi_2d69_2escm",(void*)f_4045},
{"f_4352:srfi_2d69_2escm",(void*)f_4352},
{"f_5807:srfi_2d69_2escm",(void*)f_5807},
{"f_4036:srfi_2d69_2escm",(void*)f_4036},
{"f_3843:srfi_2d69_2escm",(void*)f_3843},
{"f_3846:srfi_2d69_2escm",(void*)f_3846},
{"f_2753:srfi_2d69_2escm",(void*)f_2753},
{"f_5742:srfi_2d69_2escm",(void*)f_5742},
{"f_4942:srfi_2d69_2escm",(void*)f_4942},
{"f_5838:srfi_2d69_2escm",(void*)f_5838},
{"f_4948:srfi_2d69_2escm",(void*)f_4948},
{"f_3815:srfi_2d69_2escm",(void*)f_3815},
{"f_4027:srfi_2d69_2escm",(void*)f_4027},
{"f_2787:srfi_2d69_2escm",(void*)f_2787},
{"f_4084:srfi_2d69_2escm",(void*)f_4084},
{"f_5822:srfi_2d69_2escm",(void*)f_5822},
{"f_3869:srfi_2d69_2escm",(void*)f_3869},
{"f_3866:srfi_2d69_2escm",(void*)f_3866},
{"f_5312:srfi_2d69_2escm",(void*)f_5312},
{"f_6231:srfi_2d69_2escm",(void*)f_6231},
{"f_6238:srfi_2d69_2escm",(void*)f_6238},
{"f_4072:srfi_2d69_2escm",(void*)f_4072},
{"f_6186:srfi_2d69_2escm",(void*)f_6186},
{"f_3833:srfi_2d69_2escm",(void*)f_3833},
{"f_4391:srfi_2d69_2escm",(void*)f_4391},
{"f_1920:srfi_2d69_2escm",(void*)f_1920},
{"f_4397:srfi_2d69_2escm",(void*)f_4397},
{"f_4063:srfi_2d69_2escm",(void*)f_4063},
{"f_3748:srfi_2d69_2escm",(void*)f_3748},
{"f_3744:srfi_2d69_2escm",(void*)f_3744},
{"f_4134:srfi_2d69_2escm",(void*)f_4134},
{"f_2031:srfi_2d69_2escm",(void*)f_2031},
{"f_3753:srfi_2d69_2escm",(void*)f_3753},
{"f_4191:srfi_2d69_2escm",(void*)f_4191},
{"f_3065:srfi_2d69_2escm",(void*)f_3065},
{"f_3764:srfi_2d69_2escm",(void*)f_3764},
{"f_4723:srfi_2d69_2escm",(void*)f_4723},
{"f_3418:srfi_2d69_2escm",(void*)f_3418},
{"f_5407:srfi_2d69_2escm",(void*)f_5407},
{"f_4185:srfi_2d69_2escm",(void*)f_4185},
{"f_4188:srfi_2d69_2escm",(void*)f_4188},
{"f_3774:srfi_2d69_2escm",(void*)f_3774},
{"f_3778:srfi_2d69_2escm",(void*)f_3778},
{"f_4431:srfi_2d69_2escm",(void*)f_4431},
{"f_3089:srfi_2d69_2escm",(void*)f_3089},
{"f_3781:srfi_2d69_2escm",(void*)f_3781},
{"f_5428:srfi_2d69_2escm",(void*)f_5428},
{"f_5414:srfi_2d69_2escm",(void*)f_5414},
{"f_3792:srfi_2d69_2escm",(void*)f_3792},
{"f_4018:srfi_2d69_2escm",(void*)f_4018},
{"f_3027:srfi_2d69_2escm",(void*)f_3027},
{"f_3458:srfi_2d69_2escm",(void*)f_3458},
{"f_4150:srfi_2d69_2escm",(void*)f_4150},
{"f_1914:srfi_2d69_2escm",(void*)f_1914},
{"f_4009:srfi_2d69_2escm",(void*)f_4009},
{"f_4003:srfi_2d69_2escm",(void*)f_4003},
{"f_3461:srfi_2d69_2escm",(void*)f_3461},
{"f_3077:srfi_2d69_2escm",(void*)f_3077},
{"f_5773:srfi_2d69_2escm",(void*)f_5773},
{"f_2385:srfi_2d69_2escm",(void*)f_2385},
{"f_4713:srfi_2d69_2escm",(void*)f_4713},
{"f_2005:srfi_2d69_2escm",(void*)f_2005},
{"f_4595:srfi_2d69_2escm",(void*)f_4595},
{"f_5957:srfi_2d69_2escm",(void*)f_5957},
{"f_5688:srfi_2d69_2escm",(void*)f_5688},
{"f_6208:srfi_2d69_2escm",(void*)f_6208},
{"f_3320:srfi_2d69_2escm",(void*)f_3320},
{"f_5696:srfi_2d69_2escm",(void*)f_5696},
{"f_5695:srfi_2d69_2escm",(void*)f_5695},
{"f_6217:srfi_2d69_2escm",(void*)f_6217},
{"f_4178:srfi_2d69_2escm",(void*)f_4178},
{"f_4563:srfi_2d69_2escm",(void*)f_4563},
{"f_4560:srfi_2d69_2escm",(void*)f_4560},
{"f_3718:srfi_2d69_2escm",(void*)f_3718},
{"f_6224:srfi_2d69_2escm",(void*)f_6224},
{"f_4204:srfi_2d69_2escm",(void*)f_4204},
{"f_4551:srfi_2d69_2escm",(void*)f_4551},
{"f_3712:srfi_2d69_2escm",(void*)f_3712},
{"f_3715:srfi_2d69_2escm",(void*)f_3715},
{"f_3317:srfi_2d69_2escm",(void*)f_3317},
{"f_3728:srfi_2d69_2escm",(void*)f_3728},
{"f_3721:srfi_2d69_2escm",(void*)f_3721},
{"f_3724:srfi_2d69_2escm",(void*)f_3724},
{"f_5646:srfi_2d69_2escm",(void*)f_5646},
{"f_5008:srfi_2d69_2escm",(void*)f_5008},
{"f_5973:srfi_2d69_2escm",(void*)f_5973},
{"f_5239:srfi_2d69_2escm",(void*)f_5239},
{"f_1731:srfi_2d69_2escm",(void*)f_1731},
{"f_4959:srfi_2d69_2escm",(void*)f_4959},
{"f_5587:srfi_2d69_2escm",(void*)f_5587},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  ##sys#for-each		1
S|  for-each		1
o|eliminated procedure checks: 243 
o|specializations:
o|  1 (##sys#check-list (or pair list) *)
o|  4 (fp< float float)
o|  8 (eqv? * (not float))
o|  1 (car pair)
o|  2 (cdr pair)
o|  2 (memq * list)
o|  2 (positive? fixnum)
o|Removed `not' forms: 6 
o|contracted procedure: "(srfi-69.scm:159) g120121" 
o|contracted procedure: "(srfi-69.scm:120) g125126" 
o|inlining procedure: k1764 
o|inlining procedure: k1764 
o|contracted procedure: "(srfi-69.scm:159) g128129" 
o|inlining procedure: k1782 
o|inlining procedure: k1782 
o|contracted procedure: "(srfi-69.scm:152) g136137" 
o|inlining procedure: k1793 
o|contracted procedure: "(srfi-69.scm:147) g177178" 
o|contracted procedure: "(srfi-69.scm:147) g173174" 
o|contracted procedure: "(srfi-69.scm:147) g169170" 
o|contracted procedure: "(srfi-69.scm:147) g165166" 
o|contracted procedure: "(srfi-69.scm:147) g161162" 
o|contracted procedure: "(srfi-69.scm:147) g157158" 
o|contracted procedure: "(srfi-69.scm:147) g153154" 
o|contracted procedure: "(srfi-69.scm:147) g149150" 
o|inlining procedure: k1793 
o|contracted procedure: "(srfi-69.scm:148) g181182" 
o|contracted procedure: "(srfi-69.scm:173) g204205" 
o|contracted procedure: "(srfi-69.scm:120) g209210" 
o|inlining procedure: k1982 
o|inlining procedure: k1982 
o|contracted procedure: "(srfi-69.scm:173) g212213" 
o|contracted procedure: "(srfi-69.scm:188) g235236" 
o|contracted procedure: "(srfi-69.scm:120) g240241" 
o|inlining procedure: k2064 
o|inlining procedure: k2064 
o|contracted procedure: "(srfi-69.scm:188) g243244" 
o|contracted procedure: "(srfi-69.scm:182) g247248" 
o|inlining procedure: k2121 
o|inlining procedure: k2121 
o|contracted procedure: k2134 
o|inlining procedure: k2131 
o|inlining procedure: k2131 
o|contracted procedure: "(srfi-69.scm:209) g275276" 
o|contracted procedure: "(srfi-69.scm:120) g280281" 
o|inlining procedure: k2178 
o|inlining procedure: k2178 
o|contracted procedure: "(srfi-69.scm:209) g283284" 
o|contracted procedure: "(srfi-69.scm:203) g287288" 
o|contracted procedure: "(srfi-69.scm:235) g333334" 
o|contracted procedure: "(srfi-69.scm:120) g338339" 
o|inlining procedure: k2367 
o|inlining procedure: k2367 
o|contracted procedure: "(srfi-69.scm:235) *eq?-hash" 
o|inlining procedure: k2235 
o|inlining procedure: k2235 
o|inlining procedure: k2257 
o|inlining procedure: k2257 
o|inlining procedure: k2275 
o|inlining procedure: k2275 
o|inlining procedure: k2293 
o|contracted procedure: "(srfi-69.scm:226) g300301" 
o|contracted procedure: "(srfi-69.scm:182) g304305" 
o|inlining procedure: k2293 
o|contracted procedure: "(srfi-69.scm:230) g311312" 
o|contracted procedure: "(srfi-69.scm:229) g308309" 
o|contracted procedure: "(srfi-69.scm:262) g431432" 
o|contracted procedure: "(srfi-69.scm:120) g436437" 
o|inlining procedure: k2679 
o|inlining procedure: k2679 
o|contracted procedure: "(srfi-69.scm:262) *eqv?-hash" 
o|inlining procedure: k2414 
o|inlining procedure: k2414 
o|inlining procedure: k2436 
o|inlining procedure: k2436 
o|inlining procedure: k2454 
o|inlining procedure: k2454 
o|inlining procedure: k2472 
o|contracted procedure: "(srfi-69.scm:252) g350351" 
o|contracted procedure: "(srfi-69.scm:182) g354355" 
o|inlining procedure: k2472 
o|contracted procedure: "(srfi-69.scm:255) g358359" 
o|inlining procedure: k2500 
o|contracted procedure: "(srfi-69.scm:147) g399400" 
o|contracted procedure: "(srfi-69.scm:147) g395396" 
o|contracted procedure: "(srfi-69.scm:147) g391392" 
o|contracted procedure: "(srfi-69.scm:147) g387388" 
o|contracted procedure: "(srfi-69.scm:147) g383384" 
o|contracted procedure: "(srfi-69.scm:147) g379380" 
o|contracted procedure: "(srfi-69.scm:147) g375376" 
o|contracted procedure: "(srfi-69.scm:147) g371372" 
o|inlining procedure: k2500 
o|contracted procedure: "(srfi-69.scm:148) g403404" 
o|inlining procedure: k2625 
o|inlining procedure: k2625 
o|contracted procedure: "(srfi-69.scm:257) g409410" 
o|contracted procedure: "(srfi-69.scm:256) g406407" 
o|inlining procedure: k2755 
o|inlining procedure: k2755 
o|inlining procedure: k2811 
o|inlining procedure: k2811 
o|inlining procedure: k2829 
o|inlining procedure: k2829 
o|inlining procedure: k2851 
o|inlining procedure: k2851 
o|inlining procedure: k2869 
o|inlining procedure: k2869 
o|contracted procedure: "(srfi-69.scm:331) g473474" 
o|contracted procedure: "(srfi-69.scm:182) g477478" 
o|inlining procedure: k2898 
o|contracted procedure: "(srfi-69.scm:334) g481482" 
o|inlining procedure: k2906 
o|contracted procedure: "(srfi-69.scm:147) g522523" 
o|contracted procedure: "(srfi-69.scm:147) g518519" 
o|contracted procedure: "(srfi-69.scm:147) g514515" 
o|contracted procedure: "(srfi-69.scm:147) g510511" 
o|contracted procedure: "(srfi-69.scm:147) g506507" 
o|contracted procedure: "(srfi-69.scm:147) g502503" 
o|contracted procedure: "(srfi-69.scm:147) g498499" 
o|contracted procedure: "(srfi-69.scm:147) g494495" 
o|inlining procedure: k2906 
o|contracted procedure: "(srfi-69.scm:148) g526527" 
o|inlining procedure: k2898 
o|inlining procedure: k3046 
o|contracted procedure: "(srfi-69.scm:336) g535536" 
o|inlining procedure: k3046 
o|inlining procedure: k3101 
o|contracted procedure: "(srfi-69.scm:338) g546547" 
o|inlining procedure: k3119 
o|inlining procedure: k3119 
o|inlining procedure: k3101 
o|contracted procedure: "(srfi-69.scm:339) g550551" 
o|contracted procedure: "(srfi-69.scm:338) g543544" 
o|contracted procedure: "(srfi-69.scm:336) g532533" 
o|contracted procedure: "(srfi-69.scm:335) g529530" 
o|contracted procedure: "(srfi-69.scm:348) g581582" 
o|contracted procedure: "(srfi-69.scm:120) g586587" 
o|inlining procedure: k3198 
o|inlining procedure: k3198 
o|contracted procedure: "(srfi-69.scm:364) g620621" 
o|contracted procedure: "(srfi-69.scm:120) g625626" 
o|inlining procedure: k3291 
o|inlining procedure: k3291 
o|contracted procedure: "(srfi-69.scm:364) g628629" 
o|contracted procedure: "(srfi-69.scm:376) g663664" 
o|contracted procedure: "(srfi-69.scm:120) g668669" 
o|inlining procedure: k3432 
o|inlining procedure: k3432 
o|contracted procedure: "(srfi-69.scm:376) g671672" 
o|inlining procedure: k3541 
o|inlining procedure: k3541 
o|inlining procedure: k3559 
o|inlining procedure: k3559 
o|inlining procedure: k3593 
o|inlining procedure: k3593 
o|merged explicitly consed rest parameter: tmp731740 
o|inlining procedure: k3638 
o|inlining procedure: k3638 
o|inlining procedure: k3656 
o|inlining procedure: k3656 
o|inlining procedure: k3674 
o|inlining procedure: k3674 
o|inlining procedure: k3689 
o|inlining procedure: k3689 
o|consed rest parameter at call site: "(srfi-69.scm:585) *make-hash-table" 9 
o|inlining procedure: k3738 
o|inlining procedure: k3738 
o|inlining procedure: k3755 
o|inlining procedure: k3755 
o|inlining procedure: k3794 
o|inlining procedure: k3794 
o|inlining procedure: k3826 
o|inlining procedure: k3826 
o|inlining procedure: k3844 
o|inlining procedure: k3844 
o|substituted constant variable: a3854 
o|substituted constant variable: a3857 
o|inlining procedure: k3858 
o|substituted constant variable: a3877 
o|substituted constant variable: a3880 
o|inlining procedure: k3858 
o|inlining procedure: k3888 
o|inlining procedure: k3888 
o|inlining procedure: k3891 
o|inlining procedure: k3891 
o|substituted constant variable: a3905 
o|substituted constant variable: a3907 
o|substituted constant variable: a3909 
o|substituted constant variable: a3911 
o|substituted constant variable: a3913 
o|substituted constant variable: a3915 
o|substituted constant variable: a3917 
o|substituted constant variable: a3919 
o|inlining procedure: k3936 
o|inlining procedure: k3936 
o|inlining procedure: k3968 
o|inlining procedure: k3968 
o|inlining procedure: k3988 
o|inlining procedure: k3988 
o|inlining procedure: k4077 
o|inlining procedure: k4077 
o|inlining procedure: k4092 
o|inlining procedure: k4092 
o|contracted procedure: "(srfi-69.scm:654) hash-table-rehash!" 
o|inlining procedure: k4113 
o|inlining procedure: k4113 
o|inlining procedure: k4136 
o|inlining procedure: k4136 
o|inlining procedure: k4235 
o|consed rest parameter at call site: "(srfi-69.scm:680) *make-hash-table" 9 
o|inlining procedure: k4235 
o|inlining procedure: k4297 
o|inlining procedure: k4297 
o|inlining procedure: k4450 
o|inlining procedure: k4462 
o|inlining procedure: k4462 
o|inlining procedure: k4450 
o|inlining procedure: k4525 
o|inlining procedure: k4525 
o|contracted procedure: "(srfi-69.scm:724) g940941" 
o|inlining procedure: k4392 
o|inlining procedure: k4392 
o|inlining procedure: k4404 
o|inlining procedure: k4404 
o|contracted procedure: "(srfi-69.scm:665) g953954" 
o|inlining procedure: k4383 
o|inlining procedure: k4383 
o|contracted procedure: "(srfi-69.scm:664) g950951" 
o|inlining procedure: k4372 
o|inlining procedure: k4372 
o|inlining procedure: k4592 
o|inlining procedure: k4592 
o|inlining procedure: k4703 
o|inlining procedure: k4715 
o|inlining procedure: k4715 
o|inlining procedure: k4703 
o|inlining procedure: k4774 
o|inlining procedure: k4774 
o|contracted procedure: "(srfi-69.scm:763) g993994" 
o|inlining procedure: k4645 
o|inlining procedure: k4645 
o|inlining procedure: k4657 
o|inlining procedure: k4657 
o|contracted procedure: "(srfi-69.scm:665) g10061007" 
o|inlining procedure: k4636 
o|inlining procedure: k4636 
o|contracted procedure: "(srfi-69.scm:664) g10031004" 
o|inlining procedure: k4625 
o|inlining procedure: k4625 
o|inlining procedure: k4946 
o|inlining procedure: k4961 
o|inlining procedure: k4961 
o|inlining procedure: k4946 
o|inlining procedure: k5010 
o|inlining procedure: k5010 
o|contracted procedure: "(srfi-69.scm:808) g10491050" 
o|inlining procedure: k4888 
o|inlining procedure: k4888 
o|inlining procedure: k4900 
o|inlining procedure: k4900 
o|contracted procedure: "(srfi-69.scm:665) g10621063" 
o|inlining procedure: k4879 
o|inlining procedure: k4879 
o|contracted procedure: "(srfi-69.scm:664) g10591060" 
o|inlining procedure: k4868 
o|inlining procedure: k4868 
o|inlining procedure: k5079 
o|inlining procedure: k5095 
o|inlining procedure: k5095 
o|inlining procedure: k5079 
o|inlining procedure: k5134 
o|inlining procedure: k5134 
o|inlining procedure: k5185 
o|contracted procedure: k5204 
o|inlining procedure: k5201 
o|inlining procedure: k5201 
o|inlining procedure: k5185 
o|contracted procedure: k5244 
o|inlining procedure: k5241 
o|inlining procedure: k5241 
o|inlining procedure: k5302 
o|contracted procedure: k5317 
o|inlining procedure: k5314 
o|inlining procedure: k5314 
o|inlining procedure: k5302 
o|contracted procedure: k5364 
o|inlining procedure: k5361 
o|inlining procedure: k5361 
o|inlining procedure: k5430 
o|inlining procedure: k5430 
o|contracted procedure: k5459 
o|inlining procedure: k5456 
o|inlining procedure: k5456 
o|inlining procedure: k5533 
o|inlining procedure: k5533 
o|inlining procedure: k5556 
o|inlining procedure: k5556 
o|inlining procedure: k5632 
o|inlining procedure: k5632 
o|inlining procedure: k5648 
o|inlining procedure: k5648 
o|inlining procedure: k5721 
o|inlining procedure: k5721 
o|inlining procedure: k5759 
o|inlining procedure: k5759 
o|inlining procedure: k5775 
o|inlining procedure: k5775 
o|inlining procedure: k5824 
o|inlining procedure: k5824 
o|inlining procedure: k5840 
o|inlining procedure: k5840 
o|inlining procedure: k5886 
o|inlining procedure: k5886 
o|inlining procedure: k5924 
o|inlining procedure: k5924 
o|inlining procedure: k5959 
o|inlining procedure: k5959 
o|inlining procedure: k5975 
o|inlining procedure: k5975 
o|inlining procedure: k6111 
o|inlining procedure: k6127 
o|inlining procedure: k6127 
o|inlining procedure: k6111 
o|inlining procedure: k6169 
o|inlining procedure: k6169 
o|inlining procedure: k6219 
o|inlining procedure: k6219 
o|propagated global variable: r62206475 *recursive-hash-max-length* 
o|inlining procedure: k6233 
o|inlining procedure: k6233 
o|propagated global variable: r62346477 *recursive-hash-max-depth* 
o|replaced variables: 690 
o|removed binding forms: 330 
o|substituted constant variable: i180 
o|substituted constant variable: i176 
o|substituted constant variable: i172 
o|substituted constant variable: i168 
o|substituted constant variable: i164 
o|substituted constant variable: i160 
o|substituted constant variable: i156 
o|substituted constant variable: i152 
o|substituted constant variable: r21326256 
o|substituted constant variable: r21326256 
o|substituted constant variable: i402 
o|substituted constant variable: i398 
o|substituted constant variable: i394 
o|substituted constant variable: i390 
o|substituted constant variable: i386 
o|substituted constant variable: i382 
o|substituted constant variable: i378 
o|substituted constant variable: i374 
o|substituted constant variable: i525 
o|substituted constant variable: i521 
o|substituted constant variable: i517 
o|substituted constant variable: i513 
o|substituted constant variable: i509 
o|substituted constant variable: i505 
o|substituted constant variable: i501 
o|substituted constant variable: i497 
o|substituted constant variable: r31206303 
o|substituted constant variable: r31206303 
o|substituted constant variable: r31206305 
o|substituted constant variable: r31206305 
o|removed unused formal parameters: (weak-keys737 weak-values738) 
o|removed unused parameter to known procedure: weak-keys737 "(srfi-69.scm:585) *make-hash-table" 
o|removed unused parameter to known procedure: weak-values738 "(srfi-69.scm:585) *make-hash-table" 
o|inlining procedure: k3867 
o|substituted constant variable: r38896344 
o|substituted constant variable: r38896346 
o|inlining procedure: k3898 
o|inlining procedure: k3898 
o|substituted constant variable: r40786356 
o|substituted constant variable: r40786357 
o|substituted constant variable: r40936359 
o|removed unused parameter to known procedure: weak-keys737 "(srfi-69.scm:680) *make-hash-table" 
o|removed unused parameter to known procedure: weak-values738 "(srfi-69.scm:680) *make-hash-table" 
o|substituted constant variable: r42986366 
o|substituted constant variable: r44056377 
o|substituted constant variable: r46586393 
o|substituted constant variable: r49016415 
o|substituted constant variable: r52026427 
o|substituted constant variable: r52426430 
o|substituted constant variable: r53156433 
o|substituted constant variable: r53626436 
o|substituted constant variable: r54576440 
o|replaced variables: 110 
o|removed binding forms: 711 
o|inlining procedure: k1903 
o|inlining procedure: k2610 
o|inlining procedure: k3016 
o|inlining procedure: k3547 
o|inlining procedure: k3729 
o|inlining procedure: k3729 
o|inlining procedure: k3729 
o|inlining procedure: k3779 
o|inlining procedure: k3779 
o|inlining procedure: k3779 
o|inlining procedure: k3779 
o|inlining procedure: k3779 
o|inlining procedure: k3779 
o|inlining procedure: k3779 
o|inlining procedure: k3779 
o|removed side-effect free assignment to unused variable: weak-keys770 
o|inlining procedure: k3779 
o|removed side-effect free assignment to unused variable: weak-keys770 
o|inlining procedure: k3779 
o|removed side-effect free assignment to unused variable: weak-values771 
o|inlining procedure: k3779 
o|removed side-effect free assignment to unused variable: weak-values771 
o|inlining procedure: k3779 
o|replaced variables: 34 
o|removed binding forms: 158 
o|contracted procedure: k1809 
o|contracted procedure: k1823 
o|contracted procedure: k1837 
o|contracted procedure: k1851 
o|contracted procedure: k1865 
o|contracted procedure: k1879 
o|contracted procedure: k1893 
o|contracted procedure: k2516 
o|contracted procedure: k2530 
o|contracted procedure: k2544 
o|contracted procedure: k2558 
o|contracted procedure: k2572 
o|contracted procedure: k2586 
o|contracted procedure: k2600 
o|contracted procedure: k2922 
o|contracted procedure: k2936 
o|contracted procedure: k2950 
o|contracted procedure: k2964 
o|contracted procedure: k2978 
o|contracted procedure: k2992 
o|contracted procedure: k3006 
o|contracted procedure: k3051 
o|contracted procedure: k3106 
o|contracted procedure: k3141 
o|contracted procedure: k3309 
o|contracted procedure: k3450 
o|removed call to pure procedure with unused result: "(srfi-69.scm:684) slot" 
o|removed call to pure procedure with unused result: "(srfi-69.scm:684) slot" 
o|simplifications: ((let . 3)) 
o|removed binding forms: 84 
o|Removed `not' forms: 3 
o|contracted procedure: k2322 
o|contracted procedure: k2634 
o|contracted procedure: k3040 
o|contracted procedure: k4265 
o|contracted procedure: k4269 
o|removed binding forms: 9 
o|replaced variables: 3 
o|removed binding forms: 2 
o|removed binding forms: 3 
o|simplifications: ((let . 3)) 
o|simplifications: ((if . 75) (##core#call . 698)) 
o|  call simplifications:
o|    ##sys#check-list	2
o|    apply
o|    ##sys#check-pair
o|    void
o|    *	6
o|    ##sys#immediate?	6
o|    fx<=	6
o|    ##sys#setislot	10
o|    cons	21
o|    ##sys#check-structure	30
o|    ##sys#structure?
o|    ##sys#make-structure
o|    ##sys#setslot	24
o|    list	2
o|    ##sys#check-string	2
o|    fx>=	12
o|    pair?	4
o|    ##sys#peek-fixnum	2
o|    ##sys#size	27
o|    fxmin	4
o|    fxmax
o|    fx=
o|    fx-	4
o|    char?	3
o|    eq?	40
o|    eof-object?	3
o|    symbol?	3
o|    char->integer	3
o|    ##sys#check-symbol
o|    ##sys#slot	182
o|    car	30
o|    null?	78
o|    cdr	25
o|    number?	3
o|    ##sys#check-exact	11
o|    fixnum?	6
o|    flonum?	3
o|    fxshl	24
o|    fx+	43
o|    fx*	4
o|    fxxor	25
o|    fx<	15
o|    fxneg	9
o|    fxand	9
o|    fxmod	9
o|contracted procedure: k1945 
o|contracted procedure: k1733 
o|contracted procedure: k1939 
o|contracted procedure: k1736 
o|contracted procedure: k1933 
o|contracted procedure: k1739 
o|contracted procedure: k1927 
o|contracted procedure: k1742 
o|contracted procedure: k1748 
o|contracted procedure: k1757 
o|contracted procedure: k1767 
o|contracted procedure: k1785 
o|contracted procedure: k1796 
o|contracted procedure: k1897 
o|contracted procedure: k1887 
o|contracted procedure: k1883 
o|contracted procedure: k1873 
o|contracted procedure: k1869 
o|contracted procedure: k1859 
o|contracted procedure: k1855 
o|contracted procedure: k1845 
o|contracted procedure: k1841 
o|contracted procedure: k1831 
o|contracted procedure: k1827 
o|contracted procedure: k1817 
o|contracted procedure: k1813 
o|contracted procedure: k1803 
o|contracted procedure: k1921 
o|contracted procedure: k2024 
o|contracted procedure: k1954 
o|contracted procedure: k2018 
o|contracted procedure: k1957 
o|contracted procedure: k2012 
o|contracted procedure: k1960 
o|contracted procedure: k2006 
o|contracted procedure: k1963 
o|contracted procedure: k1966 
o|contracted procedure: k1975 
o|contracted procedure: k1985 
o|contracted procedure: k2112 
o|contracted procedure: k2033 
o|contracted procedure: k2106 
o|contracted procedure: k2036 
o|contracted procedure: k2100 
o|contracted procedure: k2039 
o|contracted procedure: k2094 
o|contracted procedure: k2042 
o|contracted procedure: k2045 
o|contracted procedure: k2048 
o|contracted procedure: k2057 
o|contracted procedure: k2067 
o|contracted procedure: k2088 
o|contracted procedure: k2141 
o|contracted procedure: k2131 
o|contracted procedure: k2226 
o|contracted procedure: k2147 
o|contracted procedure: k2220 
o|contracted procedure: k2150 
o|contracted procedure: k2214 
o|contracted procedure: k2153 
o|contracted procedure: k2208 
o|contracted procedure: k2156 
o|contracted procedure: k2162 
o|contracted procedure: k2171 
o|contracted procedure: k2181 
o|contracted procedure: k2202 
o|contracted procedure: k2404 
o|contracted procedure: k2339 
o|contracted procedure: k2398 
o|contracted procedure: k2342 
o|contracted procedure: k2392 
o|contracted procedure: k2345 
o|contracted procedure: k2386 
o|contracted procedure: k2348 
o|contracted procedure: k2351 
o|contracted procedure: k2360 
o|contracted procedure: k2370 
o|contracted procedure: k2238 
o|contracted procedure: k2247 
o|contracted procedure: k2254 
o|contracted procedure: k2260 
o|contracted procedure: k2269 
o|contracted procedure: k2278 
o|contracted procedure: k2287 
o|contracted procedure: k2296 
o|contracted procedure: k2307 
o|contracted procedure: k2716 
o|contracted procedure: k2651 
o|contracted procedure: k2710 
o|contracted procedure: k2654 
o|contracted procedure: k2704 
o|contracted procedure: k2657 
o|contracted procedure: k2698 
o|contracted procedure: k2660 
o|contracted procedure: k2663 
o|contracted procedure: k2672 
o|contracted procedure: k2682 
o|contracted procedure: k2417 
o|contracted procedure: k2426 
o|contracted procedure: k2433 
o|contracted procedure: k2439 
o|contracted procedure: k2448 
o|contracted procedure: k2457 
o|contracted procedure: k2466 
o|contracted procedure: k2475 
o|contracted procedure: k2486 
o|contracted procedure: k2495 
o|contracted procedure: k2503 
o|contracted procedure: k2604 
o|contracted procedure: k2594 
o|contracted procedure: k2590 
o|contracted procedure: k2580 
o|contracted procedure: k2576 
o|contracted procedure: k2566 
o|contracted procedure: k2562 
o|contracted procedure: k2552 
o|contracted procedure: k2548 
o|contracted procedure: k2538 
o|contracted procedure: k2534 
o|contracted procedure: k2524 
o|contracted procedure: k2520 
o|contracted procedure: k2510 
o|contracted procedure: k2738 
o|contracted procedure: k2805 
o|contracted procedure: k2745 
o|contracted procedure: k2801 
o|contracted procedure: k2797 
o|contracted procedure: k2749 
o|contracted procedure: k2758 
o|contracted procedure: k2781 
o|contracted procedure: k2777 
o|contracted procedure: k2765 
o|contracted procedure: k2769 
o|contracted procedure: k2773 
o|contracted procedure: k2789 
o|contracted procedure: k2793 
o|contracted procedure: k2814 
o|contracted procedure: k2823 
o|contracted procedure: k2832 
o|contracted procedure: k2839 
o|contracted procedure: k2845 
o|contracted procedure: k2854 
o|contracted procedure: k2863 
o|contracted procedure: k2872 
o|contracted procedure: k2881 
o|contracted procedure: k2892 
o|contracted procedure: k2901 
o|contracted procedure: k2909 
o|contracted procedure: k3010 
o|contracted procedure: k3000 
o|contracted procedure: k2996 
o|contracted procedure: k2986 
o|contracted procedure: k2982 
o|contracted procedure: k2972 
o|contracted procedure: k2968 
o|contracted procedure: k2958 
o|contracted procedure: k2954 
o|contracted procedure: k2944 
o|contracted procedure: k2940 
o|contracted procedure: k2930 
o|contracted procedure: k2926 
o|contracted procedure: k2916 
o|contracted procedure: k3062 
o|contracted procedure: k3071 
o|contracted procedure: k3079 
o|contracted procedure: k3083 
o|contracted procedure: k3091 
o|contracted procedure: k3095 
o|contracted procedure: k3130 
o|contracted procedure: k3126 
o|contracted procedure: k3115 
o|contracted procedure: k3150 
o|contracted procedure: k3235 
o|contracted procedure: k3170 
o|contracted procedure: k3229 
o|contracted procedure: k3173 
o|contracted procedure: k3223 
o|contracted procedure: k3176 
o|contracted procedure: k3217 
o|contracted procedure: k3179 
o|contracted procedure: k3182 
o|contracted procedure: k3191 
o|contracted procedure: k3201 
o|contracted procedure: k3377 
o|contracted procedure: k3245 
o|contracted procedure: k3371 
o|contracted procedure: k3248 
o|contracted procedure: k3365 
o|contracted procedure: k3251 
o|contracted procedure: k3359 
o|contracted procedure: k3254 
o|contracted procedure: k3353 
o|contracted procedure: k3257 
o|contracted procedure: k3347 
o|contracted procedure: k3260 
o|contracted procedure: k3341 
o|contracted procedure: k3263 
o|contracted procedure: k3335 
o|contracted procedure: k3266 
o|contracted procedure: k3269 
o|contracted procedure: k3272 
o|contracted procedure: k3284 
o|contracted procedure: k3294 
o|contracted procedure: k3312 
o|contracted procedure: k3325 
o|contracted procedure: k3329 
o|contracted procedure: k3518 
o|contracted procedure: k3386 
o|contracted procedure: k3512 
o|contracted procedure: k3389 
o|contracted procedure: k3506 
o|contracted procedure: k3392 
o|contracted procedure: k3500 
o|contracted procedure: k3395 
o|contracted procedure: k3494 
o|contracted procedure: k3398 
o|contracted procedure: k3488 
o|contracted procedure: k3401 
o|contracted procedure: k3482 
o|contracted procedure: k3404 
o|contracted procedure: k3476 
o|contracted procedure: k3407 
o|contracted procedure: k3410 
o|contracted procedure: k3413 
o|contracted procedure: k3425 
o|contracted procedure: k3435 
o|contracted procedure: k3453 
o|contracted procedure: k3466 
o|contracted procedure: k3470 
o|contracted procedure: k3535 
o|contracted procedure: k3538 
o|contracted procedure: k3544 
o|contracted procedure: k3547 
o|contracted procedure: k3564 
o|contracted procedure: k3572 
o|contracted procedure: k3602 
o|contracted procedure: k3596 
o|contracted procedure: k3614 
o|contracted procedure: k3617 
o|contracted procedure: k3624 
o|contracted procedure: k3641 
o|contracted procedure: k3644 
o|contracted procedure: k3650 
o|contracted procedure: k3653 
o|contracted procedure: k3659 
o|contracted procedure: k3662 
o|contracted procedure: k3668 
o|contracted procedure: k3671 
o|contracted procedure: k3677 
o|contracted procedure: k3680 
o|contracted procedure: k3686 
o|contracted procedure: k3689 
o|contracted procedure: k3758 
o|contracted procedure: k3761 
o|contracted procedure: k3787 
o|contracted procedure: k3797 
o|contracted procedure: k3807 
o|contracted procedure: k3810 
o|contracted procedure: k3817 
o|contracted procedure: k3820 
o|contracted procedure: k3829 
o|contracted procedure: k3838 
o|contracted procedure: k3848 
o|contracted procedure: k3861 
o|contracted procedure: k3871 
o|contracted procedure: k3884 
o|contracted procedure: k3894 
o|contracted procedure: k3920 
o|contracted procedure: k3930 
o|contracted procedure: k3933 
o|contracted procedure: k3942 
o|contracted procedure: k3949 
o|contracted procedure: k3953 
o|contracted procedure: k3956 
o|contracted procedure: k3962 
o|contracted procedure: k3965 
o|contracted procedure: k3979 
o|contracted procedure: k3982 
o|contracted procedure: k3985 
o|contracted procedure: k3999 
o|contracted procedure: k4011 
o|contracted procedure: k4020 
o|contracted procedure: k4029 
o|contracted procedure: k4038 
o|contracted procedure: k4047 
o|contracted procedure: k4056 
o|contracted procedure: k4065 
o|contracted procedure: k4074 
o|contracted procedure: k4080 
o|contracted procedure: k4086 
o|contracted procedure: k4089 
o|contracted procedure: k4200 
o|contracted procedure: k4180 
o|contracted procedure: k4196 
o|contracted procedure: k4101 
o|contracted procedure: k4104 
o|contracted procedure: k4116 
o|contracted procedure: k4126 
o|contracted procedure: k4130 
o|contracted procedure: k4139 
o|contracted procedure: k4142 
o|contracted procedure: k4145 
o|contracted procedure: k4174 
o|contracted procedure: k4166 
o|contracted procedure: k4170 
o|contracted procedure: k4162 
o|contracted procedure: k4151 
o|contracted procedure: k4158 
o|contracted procedure: k4206 
o|contracted procedure: k4209 
o|contracted procedure: k4229 
o|contracted procedure: k4218 
o|contracted procedure: k4225 
o|contracted procedure: k4221 
o|contracted procedure: k4238 
o|contracted procedure: k4245 
o|contracted procedure: k4249 
o|contracted procedure: k4253 
o|contracted procedure: k4257 
o|contracted procedure: k4261 
o|contracted procedure: k4273 
o|contracted procedure: k4276 
o|contracted procedure: k4283 
o|contracted procedure: k4291 
o|contracted procedure: k4300 
o|contracted procedure: k4303 
o|contracted procedure: k4322 
o|contracted procedure: k4326 
o|contracted procedure: k4310 
o|contracted procedure: k4318 
o|contracted procedure: k4332 
o|contracted procedure: k4344 
o|contracted procedure: k4583 
o|contracted procedure: k4353 
o|contracted procedure: k4432 
o|contracted procedure: k4435 
o|contracted procedure: k4438 
o|contracted procedure: k4441 
o|contracted procedure: k4447 
o|contracted procedure: k4453 
o|contracted procedure: k4465 
o|contracted procedure: k4482 
o|contracted procedure: k4478 
o|contracted procedure: k4471 
o|contracted procedure: k4474 
o|contracted procedure: k4489 
o|contracted procedure: k4516 
o|contracted procedure: k4495 
o|contracted procedure: k4501 
o|contracted procedure: k4505 
o|contracted procedure: k4512 
o|contracted procedure: k4528 
o|contracted procedure: k4545 
o|contracted procedure: k4541 
o|contracted procedure: k4534 
o|contracted procedure: k4537 
o|contracted procedure: k4552 
o|contracted procedure: k4564 
o|contracted procedure: k4568 
o|contracted procedure: k4575 
o|contracted procedure: k4579 
o|contracted procedure: k4358 
o|contracted procedure: k4361 
o|contracted procedure: k4364 
o|contracted procedure: k4367 
o|contracted procedure: k4401 
o|contracted procedure: k4407 
o|contracted procedure: k4386 
o|contracted procedure: k4418 
o|contracted procedure: k4375 
o|contracted procedure: k4426 
o|contracted procedure: k4586 
o|contracted procedure: k4589 
o|contracted procedure: k4828 
o|contracted procedure: k4606 
o|contracted procedure: k4685 
o|contracted procedure: k4688 
o|contracted procedure: k4691 
o|contracted procedure: k4694 
o|contracted procedure: k4700 
o|contracted procedure: k4706 
o|contracted procedure: k4718 
o|contracted procedure: k4735 
o|contracted procedure: k4731 
o|contracted procedure: k4724 
o|contracted procedure: k4727 
o|contracted procedure: k4738 
o|contracted procedure: k4765 
o|contracted procedure: k4744 
o|contracted procedure: k4750 
o|contracted procedure: k4754 
o|contracted procedure: k4761 
o|contracted procedure: k4777 
o|contracted procedure: k4794 
o|contracted procedure: k4790 
o|contracted procedure: k4783 
o|contracted procedure: k4786 
o|contracted procedure: k4797 
o|contracted procedure: k4809 
o|contracted procedure: k4813 
o|contracted procedure: k4820 
o|contracted procedure: k4824 
o|contracted procedure: k4611 
o|contracted procedure: k4614 
o|contracted procedure: k4617 
o|contracted procedure: k4620 
o|contracted procedure: k4654 
o|contracted procedure: k4660 
o|contracted procedure: k4639 
o|contracted procedure: k4671 
o|contracted procedure: k4628 
o|contracted procedure: k4679 
o|contracted procedure: k4834 
o|contracted procedure: k4846 
o|contracted procedure: k5054 
o|contracted procedure: k4849 
o|contracted procedure: k4928 
o|contracted procedure: k4931 
o|contracted procedure: k4934 
o|contracted procedure: k4937 
o|contracted procedure: k4943 
o|contracted procedure: k4952 
o|contracted procedure: k4964 
o|contracted procedure: k4978 
o|contracted procedure: k4974 
o|contracted procedure: k4967 
o|contracted procedure: k4981 
o|contracted procedure: k5001 
o|contracted procedure: k4987 
o|contracted procedure: k4997 
o|contracted procedure: k5013 
o|contracted procedure: k5027 
o|contracted procedure: k5023 
o|contracted procedure: k5016 
o|contracted procedure: k5030 
o|contracted procedure: k5046 
o|contracted procedure: k5050 
o|contracted procedure: k4854 
o|contracted procedure: k4857 
o|contracted procedure: k4860 
o|contracted procedure: k4863 
o|contracted procedure: k4897 
o|contracted procedure: k4903 
o|contracted procedure: k4882 
o|contracted procedure: k4914 
o|contracted procedure: k4871 
o|contracted procedure: k4922 
o|contracted procedure: k5064 
o|contracted procedure: k5067 
o|contracted procedure: k5070 
o|contracted procedure: k5073 
o|contracted procedure: k5082 
o|contracted procedure: k5089 
o|contracted procedure: k5098 
o|contracted procedure: k5101 
o|contracted procedure: k5121 
o|contracted procedure: k5107 
o|contracted procedure: k5117 
o|contracted procedure: k5128 
o|contracted procedure: k5137 
o|contracted procedure: k5140 
o|contracted procedure: k5156 
o|contracted procedure: k5160 
o|contracted procedure: k5164 
o|contracted procedure: k5170 
o|contracted procedure: k5173 
o|contracted procedure: k5176 
o|contracted procedure: k5179 
o|contracted procedure: k5188 
o|contracted procedure: k5195 
o|contracted procedure: k5228 
o|contracted procedure: k5207 
o|contracted procedure: k5224 
o|contracted procedure: k5210 
o|contracted procedure: k5220 
o|contracted procedure: k5235 
o|contracted procedure: k5268 
o|contracted procedure: k5247 
o|contracted procedure: k5260 
o|contracted procedure: k5264 
o|contracted procedure: k5272 
o|contracted procedure: k5278 
o|contracted procedure: k5281 
o|contracted procedure: k5284 
o|contracted procedure: k5287 
o|contracted procedure: k5293 
o|contracted procedure: k5403 
o|contracted procedure: k5296 
o|contracted procedure: k5299 
o|contracted procedure: k5305 
o|contracted procedure: k5352 
o|contracted procedure: k5320 
o|contracted procedure: k5323 
o|contracted procedure: k5348 
o|contracted procedure: k5329 
o|contracted procedure: k5332 
o|contracted procedure: k5335 
o|contracted procedure: k5399 
o|contracted procedure: k5367 
o|contracted procedure: k5370 
o|contracted procedure: k5379 
o|contracted procedure: k5382 
o|contracted procedure: k5395 
o|contracted procedure: k5409 
o|contracted procedure: k5415 
o|contracted procedure: k5418 
o|contracted procedure: k5421 
o|contracted procedure: k5433 
o|contracted procedure: k5446 
o|contracted procedure: k5450 
o|contracted procedure: k5499 
o|contracted procedure: k5462 
o|contracted procedure: k5465 
o|contracted procedure: k5474 
o|contracted procedure: k5478 
o|contracted procedure: k5491 
o|contracted procedure: k5495 
o|contracted procedure: k5505 
o|contracted procedure: k5515 
o|contracted procedure: k5521 
o|contracted procedure: k5524 
o|contracted procedure: k5536 
o|contracted procedure: k5546 
o|contracted procedure: k5550 
o|contracted procedure: k5559 
o|contracted procedure: k5562 
o|contracted procedure: k5572 
o|contracted procedure: k5576 
o|contracted procedure: k5583 
o|contracted procedure: k5589 
o|contracted procedure: k5592 
o|contracted procedure: k5601 
o|contracted procedure: k5604 
o|contracted procedure: k5617 
o|contracted procedure: k5620 
o|contracted procedure: k5623 
o|contracted procedure: k5635 
o|contracted procedure: k5642 
o|contracted procedure: k5651 
o|contracted procedure: k5658 
o|contracted procedure: k5665 
o|contracted procedure: k5669 
o|contracted procedure: k5680 
o|contracted procedure: k5684 
o|contracted procedure: k5676 
o|contracted procedure: k5672 
o|contracted procedure: k5690 
o|contracted procedure: k5698 
o|contracted procedure: k5705 
o|contracted procedure: k5712 
o|contracted procedure: k5724 
o|contracted procedure: k5734 
o|contracted procedure: k5738 
o|contracted procedure: k5744 
o|contracted procedure: k5747 
o|contracted procedure: k5750 
o|contracted procedure: k5762 
o|contracted procedure: k5769 
o|contracted procedure: k5778 
o|contracted procedure: k5785 
o|contracted procedure: k5792 
o|contracted procedure: k5796 
o|contracted procedure: k5803 
o|contracted procedure: k5799 
o|contracted procedure: k5809 
o|contracted procedure: k5812 
o|contracted procedure: k5815 
o|contracted procedure: k5827 
o|contracted procedure: k5834 
o|contracted procedure: k5843 
o|contracted procedure: k5850 
o|contracted procedure: k5857 
o|contracted procedure: k5861 
o|contracted procedure: k5868 
o|contracted procedure: k5864 
o|contracted procedure: k5874 
o|contracted procedure: k5877 
o|contracted procedure: k5889 
o|contracted procedure: k5898 
o|contracted procedure: k5902 
o|contracted procedure: k5905 
o|contracted procedure: k5908 
o|contracted procedure: k5918 
o|contracted procedure: k5927 
o|contracted procedure: k5937 
o|contracted procedure: k5941 
o|contracted procedure: k5947 
o|contracted procedure: k5950 
o|contracted procedure: k5962 
o|contracted procedure: k5969 
o|contracted procedure: k5978 
o|contracted procedure: k5985 
o|contracted procedure: k5988 
o|contracted procedure: k5995 
o|contracted procedure: k6003 
o|contracted procedure: k6007 
o|contracted procedure: k6013 
o|contracted procedure: k6025 
o|contracted procedure: k6037 
o|contracted procedure: k6049 
o|contracted procedure: k6084 
o|contracted procedure: k6205 
o|contracted procedure: k6090 
o|contracted procedure: k6093 
o|contracted procedure: k6099 
o|contracted procedure: k6102 
o|contracted procedure: k6105 
o|contracted procedure: k6114 
o|contracted procedure: k6121 
o|contracted procedure: k6130 
o|contracted procedure: k6136 
o|contracted procedure: k6156 
o|contracted procedure: k6142 
o|contracted procedure: k6152 
o|contracted procedure: k6163 
o|contracted procedure: k6172 
o|contracted procedure: k6178 
o|contracted procedure: k6194 
o|contracted procedure: k6198 
o|contracted procedure: k6202 
o|contracted procedure: k6226 
o|contracted procedure: k6240 
o|simplifications: ((let . 82)) 
o|removed binding forms: 622 
o|replaced variables: 394 
o|inlining procedure: k1773 
o|inlining procedure: k1991 
o|inlining procedure: k2073 
o|inlining procedure: k2187 
o|inlining procedure: k2376 
o|inlining procedure: k2688 
o|inlining procedure: k3207 
o|inlining procedure: k3300 
o|inlining procedure: k3441 
o|removed binding forms: 173 
o|contracted procedure: k2091 
o|contracted procedure: k2205 
o|removed binding forms: 11 
o|replaced variables: 12 
o|removed binding forms: 11 
o|direct leaf routine/allocation: loop695 0 
o|direct leaf routine/allocation: hash-for-test772 0 
o|direct leaf routine/allocation: loop1124 0 
o|direct leaf routine/allocation: loop1141 0 
o|direct leaf routine/allocation: loop1169 0 
o|converted assignments to bindings: (loop695) 
o|contracted procedure: "(srfi-69.scm:578) k3735" 
o|converted assignments to bindings: (loop1124) 
o|converted assignments to bindings: (loop1141) 
o|converted assignments to bindings: (loop1169) 
o|simplifications: ((let . 4)) 
o|removed binding forms: 1 
o|customizable procedures: (k6236 k6222 loop1109 loop1105 *hash-table-for-each *hash-table-fold fold21346 loop1343 g13201327 for-each-loop13191330 doloop13141315 loop21302 loop1299 loop21288 loop1285 g12621269 for-each-loop12611274 loop21248 loop1245 *hash-table-merge! doloop12221223 doloop12191220 loop1197 doloop11941195 loop1178 loop1149 loop1128 k4874 k4885 k4891 loop1078 loop1073 *hash-table-update!/default k4631 k4642 k4648 loop1026 loop1017 k4341 k4378 k4389 k4395 loop973 loop964 *hash-table-copy copy-loop908 doloop905906 loop881 doloop878879 k3710 k3713 k3716 invarg-err808 loop805 hash-table-canonical-length *make-hash-table g557558 g553554 vector-hash453 g539540 recursive-hash454 loop461 *equal?-hash) 
o|calls to known targets: 171 
o|identified direct recursive calls: f_3533 2 
o|identified direct recursive calls: f_4295 1 
o|identified direct recursive calls: f_4460 1 
o|identified direct recursive calls: f_4713 1 
o|identified direct recursive calls: f_4959 1 
o|identified direct recursive calls: f_5093 1 
o|identified direct recursive calls: f_5199 1 
o|identified direct recursive calls: f_5312 1 
o|identified direct recursive calls: f_5646 1 
o|identified direct recursive calls: f_5773 1 
o|identified direct recursive calls: f_5838 1 
o|identified direct recursive calls: f_6125 1 
o|fast box initializations: 34 
o|fast global references: 33 
o|fast global assignments: 10 
o|dropping unused closure argument: f_2733 
o|dropping unused closure argument: f_5945 
o|dropping unused closure argument: f_3527 
o|dropping unused closure argument: f_5872 
o|dropping unused closure argument: f_5519 
o|dropping unused closure argument: f_3609 
o|dropping unused closure argument: f_4204 
*/
/* end of file */
