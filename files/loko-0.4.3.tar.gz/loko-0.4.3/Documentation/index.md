# Loko Scheme documentation

* [Roadmap](roadmap.md)

The manual is provided in Texinfo format. You can build the manual
with `make manual` in the root of the project.
