#!/bin/sh

echo '(+ 2 2) (print "hello")' | $@ -q

