#define C_BUILD_TAG "compiled 2017-12-11 on yves.more-magic.net (Linux)"
