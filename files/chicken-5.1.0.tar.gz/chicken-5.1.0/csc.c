/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-cc.org
   Version 5.1.0rc1 (prerelease) (rev 7358d2e5)
   linux-unix-gnu-x86-64 [ 64bit dload ptables ]
   command line: csc.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -consult-types-file ./types.db -no-lambda-info -no-trace -output-file csc.c
   uses: library eval expand file extras pathname posix data-structures
*/
#include "chicken.h"

#ifndef STATICBUILD
# define STATIC_CHICKEN 0
#else
# define STATIC_CHICKEN 1
#endif
#ifndef DEBUGBUILD
# define DEBUG_CHICKEN 0
#else
# define DEBUG_CHICKEN 1
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_file_toplevel)
C_externimport void C_ccall C_file_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_pathname_toplevel)
C_externimport void C_ccall C_pathname_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[442];
static double C_possibly_force_alignment;


C_noret_decl(f8584)
static void C_ccall f8584(C_word c,C_word *av) C_noret;
C_noret_decl(f8590)
static void C_ccall f8590(C_word c,C_word *av) C_noret;
C_noret_decl(f8594)
static void C_ccall f8594(C_word c,C_word *av) C_noret;
C_noret_decl(f8616)
static void C_ccall f8616(C_word c,C_word *av) C_noret;
C_noret_decl(f8662)
static void C_ccall f8662(C_word c,C_word *av) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word *av) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word *av) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word *av) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word *av) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word *av) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word *av) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word *av) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word *av) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word *av) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word *av) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word *av) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word *av) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word *av) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word *av) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word *av) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word *av) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word *av) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word *av) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word *av) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word *av) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word *av) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word *av) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word *av) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word *av) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word *av) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word *av) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word *av) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word *av) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word *av) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word *av) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word *av) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word *av) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word *av) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word *av) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word *av) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word *av) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word *av) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word *av) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word *av) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word *av) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word *av) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word *av) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word *av) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word *av) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word *av) C_noret;
C_noret_decl(f_2941)
static void C_fcall f_2941(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2947)
static void C_fcall f_2947(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word *av) C_noret;
C_noret_decl(f_3003)
static void C_fcall f_3003(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word *av) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word *av) C_noret;
C_noret_decl(f_3078)
static void C_fcall f_3078(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word *av) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word *av) C_noret;
C_noret_decl(f_3126)
static void C_fcall f_3126(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3134)
static void C_fcall f_3134(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word *av) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word *av) C_noret;
C_noret_decl(f_3170)
static void C_fcall f_3170(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3178)
static void C_fcall f_3178(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word *av) C_noret;
C_noret_decl(f_3186)
static C_word C_fcall f_3186(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word *av) C_noret;
C_noret_decl(f_3283)
static C_word C_fcall f_3283(C_word t0);
C_noret_decl(f_3383)
static void C_fcall f_3383(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word *av) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word *av) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word *av) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word *av) C_noret;
C_noret_decl(f_3817)
static void C_fcall f_3817(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word *av) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word *av) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word *av) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word *av) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word *av) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word *av) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word *av) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word *av) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word *av) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word *av) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word *av) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word *av) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word *av) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word *av) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word *av) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word *av) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word *av) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word *av) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word *av) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word *av) C_noret;
C_noret_decl(f_3938)
static void C_fcall f_3938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_fcall f_3941(C_word t0) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word *av) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word *av) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word *av) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word *av) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word *av) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word *av) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word *av) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word *av) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word *av) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word *av) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word *av) C_noret;
C_noret_decl(f_4103)
static void C_fcall f_4103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4107)
static void C_fcall f_4107(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word *av) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word *av) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word *av) C_noret;
C_noret_decl(f_4132)
static void C_fcall f_4132(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word *av) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word *av) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word *av) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word *av) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word *av) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word *av) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word *av) C_noret;
C_noret_decl(f_4226)
static void C_fcall f_4226(C_word t0) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word *av) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word *av) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word *av) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word *av) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word *av) C_noret;
C_noret_decl(f_4254)
static void C_ccall f_4254(C_word c,C_word *av) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word *av) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266(C_word c,C_word *av) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word *av) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word *av) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word *av) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word *av) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word *av) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word *av) C_noret;
C_noret_decl(f_4350)
static void C_fcall f_4350(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word *av) C_noret;
C_noret_decl(f_4357)
static void C_fcall f_4357(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4383)
static void C_fcall f_4383(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word *av) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word *av) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word *av) C_noret;
C_noret_decl(f_4413)
static void C_fcall f_4413(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4429)
static void C_fcall f_4429(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word *av) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word *av) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word *av) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word *av) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word *av) C_noret;
C_noret_decl(f_4462)
static void C_fcall f_4462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word *av) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word *av) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word *av) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word *av) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word *av) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word *av) C_noret;
C_noret_decl(f_4492)
static void C_ccall f_4492(C_word c,C_word *av) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word *av) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word *av) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word *av) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word *av) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word *av) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word *av) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word *av) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word *av) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word *av) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word *av) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word *av) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word *av) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word *av) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word *av) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word *av) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word *av) C_noret;
C_noret_decl(f_4606)
static void C_fcall f_4606(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4609)
static void C_fcall f_4609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word *av) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word *av) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word *av) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word *av) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word *av) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word *av) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word *av) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word *av) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word *av) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word *av) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word *av) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692(C_word c,C_word *av) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word *av) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word *av) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word *av) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word *av) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word *av) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word *av) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word *av) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word *av) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word *av) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word *av) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word *av) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word *av) C_noret;
C_noret_decl(f_4858)
static void C_fcall f_4858(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word *av) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word *av) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word *av) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word *av) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word *av) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word *av) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word *av) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word *av) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word *av) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word *av) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word *av) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word *av) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word *av) C_noret;
C_noret_decl(f_5131)
static void C_ccall f_5131(C_word c,C_word *av) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word *av) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word *av) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word *av) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word *av) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word *av) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word *av) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word *av) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word *av) C_noret;
C_noret_decl(f_5232)
static void C_ccall f_5232(C_word c,C_word *av) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word *av) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word *av) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word *av) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word *av) C_noret;
C_noret_decl(f_5293)
static void C_fcall f_5293(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5317)
static void C_ccall f_5317(C_word c,C_word *av) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word *av) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word *av) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word *av) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word *av) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word *av) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word *av) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word *av) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word *av) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word *av) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word *av) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word *av) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word *av) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word *av) C_noret;
C_noret_decl(f_5484)
static void C_fcall f_5484(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word *av) C_noret;
C_noret_decl(f_5496)
static void C_ccall f_5496(C_word c,C_word *av) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word *av) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word *av) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word *av) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word *av) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word *av) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word *av) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word *av) C_noret;
C_noret_decl(f_5576)
static void C_fcall f_5576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_fcall f_5579(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static C_word C_fcall f_5586(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word *av) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word *av) C_noret;
C_noret_decl(f_5633)
static void C_fcall f_5633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static void C_fcall f_5642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word *av) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word *av) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word *av) C_noret;
C_noret_decl(f_5683)
static void C_ccall f_5683(C_word c,C_word *av) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word *av) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word *av) C_noret;
C_noret_decl(f_5734)
static void C_fcall f_5734(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5738)
static void C_ccall f_5738(C_word c,C_word *av) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word *av) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word *av) C_noret;
C_noret_decl(f_5780)
static void C_fcall f_5780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word *av) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word *av) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word *av) C_noret;
C_noret_decl(f_5840)
static void C_ccall f_5840(C_word c,C_word *av) C_noret;
C_noret_decl(f_5852)
static void C_ccall f_5852(C_word c,C_word *av) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857(C_word c,C_word *av) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word *av) C_noret;
C_noret_decl(f_5874)
static void C_ccall f_5874(C_word c,C_word *av) C_noret;
C_noret_decl(f_5888)
static void C_ccall f_5888(C_word c,C_word *av) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word *av) C_noret;
C_noret_decl(f_5915)
static void C_fcall f_5915(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word *av) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word *av) C_noret;
C_noret_decl(f_5951)
static void C_fcall f_5951(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word *av) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word *av) C_noret;
C_noret_decl(f_5972)
static void C_ccall f_5972(C_word c,C_word *av) C_noret;
C_noret_decl(f_5978)
static void C_ccall f_5978(C_word c,C_word *av) C_noret;
C_noret_decl(f_6008)
static void C_ccall f_6008(C_word c,C_word *av) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215(C_word c,C_word *av) C_noret;
C_noret_decl(f_6218)
static void C_ccall f_6218(C_word c,C_word *av) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word *av) C_noret;
C_noret_decl(f_6224)
static void C_fcall f_6224(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6228)
static void C_ccall f_6228(C_word c,C_word *av) C_noret;
C_noret_decl(f_6232)
static void C_ccall f_6232(C_word c,C_word *av) C_noret;
C_noret_decl(f_6251)
static void C_ccall f_6251(C_word c,C_word *av) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word *av) C_noret;
C_noret_decl(f_6259)
static void C_ccall f_6259(C_word c,C_word *av) C_noret;
C_noret_decl(f_6263)
static void C_ccall f_6263(C_word c,C_word *av) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word *av) C_noret;
C_noret_decl(f_6271)
static void C_fcall f_6271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word *av) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word *av) C_noret;
C_noret_decl(f_6290)
static void C_fcall f_6290(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word *av) C_noret;
C_noret_decl(f_6326)
static void C_fcall f_6326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6336)
static void C_fcall f_6336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word *av) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word *av) C_noret;
C_noret_decl(f_6386)
static void C_fcall f_6386(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word *av) C_noret;
C_noret_decl(f_6411)
static void C_fcall f_6411(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6415)
static void C_ccall f_6415(C_word c,C_word *av) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word *av) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word *av) C_noret;
C_noret_decl(f_6433)
static void C_ccall f_6433(C_word c,C_word *av) C_noret;
C_noret_decl(f_6445)
static void C_ccall f_6445(C_word c,C_word *av) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word *av) C_noret;
C_noret_decl(f_6453)
static void C_fcall f_6453(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word *av) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word *av) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word *av) C_noret;
C_noret_decl(f_6500)
static void C_fcall f_6500(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6501)
static void C_fcall f_6501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505(C_word c,C_word *av) C_noret;
C_noret_decl(f_6508)
static void C_ccall f_6508(C_word c,C_word *av) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word *av) C_noret;
C_noret_decl(f_6528)
static void C_ccall f_6528(C_word c,C_word *av) C_noret;
C_noret_decl(f_6532)
static void C_ccall f_6532(C_word c,C_word *av) C_noret;
C_noret_decl(f_6538)
static void C_ccall f_6538(C_word c,C_word *av) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542(C_word c,C_word *av) C_noret;
C_noret_decl(f_6551)
static void C_ccall f_6551(C_word c,C_word *av) C_noret;
C_noret_decl(f_6559)
static void C_fcall f_6559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word *av) C_noret;
C_noret_decl(f_6582)
static void C_fcall f_6582(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6592)
static void C_ccall f_6592(C_word c,C_word *av) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word *av) C_noret;
C_noret_decl(f_6609)
static void C_fcall f_6609(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6619)
static void C_ccall f_6619(C_word c,C_word *av) C_noret;
C_noret_decl(f_6633)
static void C_fcall f_6633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word *av) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word *av) C_noret;
C_noret_decl(f_6651)
static void C_ccall f_6651(C_word c,C_word *av) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word *av) C_noret;
C_noret_decl(f_6660)
static void C_fcall f_6660(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6670)
static void C_ccall f_6670(C_word c,C_word *av) C_noret;
C_noret_decl(f_6683)
static void C_fcall f_6683(C_word t0) C_noret;
C_noret_decl(f_6694)
static void C_ccall f_6694(C_word c,C_word *av) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word *av) C_noret;
C_noret_decl(f_6702)
static void C_fcall f_6702(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word *av) C_noret;
C_noret_decl(f_6741)
static void C_ccall f_6741(C_word c,C_word *av) C_noret;
C_noret_decl(f_6750)
static void C_ccall f_6750(C_word c,C_word *av) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word *av) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word *av) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word *av) C_noret;
C_noret_decl(f_6765)
static void C_ccall f_6765(C_word c,C_word *av) C_noret;
C_noret_decl(f_6773)
static void C_fcall f_6773(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6783)
static void C_ccall f_6783(C_word c,C_word *av) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word *av) C_noret;
C_noret_decl(f_6810)
static void C_ccall f_6810(C_word c,C_word *av) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word *av) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word *av) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word *av) C_noret;
C_noret_decl(f_6826)
static void C_ccall f_6826(C_word c,C_word *av) C_noret;
C_noret_decl(f_6829)
static void C_ccall f_6829(C_word c,C_word *av) C_noret;
C_noret_decl(f_6839)
static void C_ccall f_6839(C_word c,C_word *av) C_noret;
C_noret_decl(f_6846)
static void C_ccall f_6846(C_word c,C_word *av) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word *av) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word *av) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863(C_word c,C_word *av) C_noret;
C_noret_decl(f_6871)
static void C_ccall f_6871(C_word c,C_word *av) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word *av) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879(C_word c,C_word *av) C_noret;
C_noret_decl(f_6884)
static void C_ccall f_6884(C_word c,C_word *av) C_noret;
C_noret_decl(f_6886)
static void C_fcall f_6886(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6911)
static void C_ccall f_6911(C_word c,C_word *av) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word *av) C_noret;
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word *av) C_noret;
C_noret_decl(f_6937)
static void C_ccall f_6937(C_word c,C_word *av) C_noret;
C_noret_decl(f_6951)
static void C_ccall f_6951(C_word c,C_word *av) C_noret;
C_noret_decl(f_6966)
static void C_ccall f_6966(C_word c,C_word *av) C_noret;
C_noret_decl(f_6974)
static void C_fcall f_6974(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word *av) C_noret;
C_noret_decl(f_7008)
static void C_fcall f_7008(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word *av) C_noret;
C_noret_decl(f_7045)
static void C_fcall f_7045(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word *av) C_noret;
C_noret_decl(f_7065)
static void C_fcall f_7065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7068)
static void C_ccall f_7068(C_word c,C_word *av) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word *av) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word *av) C_noret;
C_noret_decl(f_7082)
static void C_ccall f_7082(C_word c,C_word *av) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word *av) C_noret;
C_noret_decl(f_7170)
static void C_fcall f_7170(C_word t0) C_noret;
C_noret_decl(f_7181)
static void C_ccall f_7181(C_word c,C_word *av) C_noret;
C_noret_decl(f_7187)
static void C_ccall f_7187(C_word c,C_word *av) C_noret;
C_noret_decl(f_7189)
static void C_fcall f_7189(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7214)
static void C_ccall f_7214(C_word c,C_word *av) C_noret;
C_noret_decl(f_7223)
static void C_fcall f_7223(C_word t0) C_noret;
C_noret_decl(f_7231)
static void C_ccall f_7231(C_word c,C_word *av) C_noret;
C_noret_decl(f_7235)
static void C_ccall f_7235(C_word c,C_word *av) C_noret;
C_noret_decl(f_7258)
static void C_ccall f_7258(C_word c,C_word *av) C_noret;
C_noret_decl(f_7268)
static void C_ccall f_7268(C_word c,C_word *av) C_noret;
C_noret_decl(f_7272)
static void C_ccall f_7272(C_word c,C_word *av) C_noret;
C_noret_decl(f_7276)
static void C_ccall f_7276(C_word c,C_word *av) C_noret;
C_noret_decl(f_7278)
static void C_fcall f_7278(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7301)
static void C_ccall f_7301(C_word c,C_word *av) C_noret;
C_noret_decl(f_7306)
static void C_fcall f_7306(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7313)
static void C_ccall f_7313(C_word c,C_word *av) C_noret;
C_noret_decl(f_7321)
static void C_fcall f_7321(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7330)
static void C_fcall f_7330(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word *av) C_noret;
C_noret_decl(f_7355)
static void C_ccall f_7355(C_word c,C_word *av) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word *av) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word *av) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word *av) C_noret;
C_noret_decl(f_7385)
static void C_ccall f_7385(C_word c,C_word *av) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word *av) C_noret;
C_noret_decl(f_7399)
static void C_ccall f_7399(C_word c,C_word *av) C_noret;
C_noret_decl(f_7402)
static void C_ccall f_7402(C_word c,C_word *av) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word *av) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word *av) C_noret;
C_noret_decl(f_7425)
static void C_ccall f_7425(C_word c,C_word *av) C_noret;
C_noret_decl(f_7428)
static void C_ccall f_7428(C_word c,C_word *av) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word *av) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word *av) C_noret;
C_noret_decl(f_7451)
static void C_fcall f_7451(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7459)
static void C_ccall f_7459(C_word c,C_word *av) C_noret;
C_noret_decl(f_7467)
static void C_fcall f_7467(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word *av) C_noret;
C_noret_decl(f_7480)
static void C_ccall f_7480(C_word c,C_word *av) C_noret;
C_noret_decl(f_7484)
static void C_ccall f_7484(C_word c,C_word *av) C_noret;
C_noret_decl(f_7503)
static void C_ccall f_7503(C_word c,C_word *av) C_noret;
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word *av) C_noret;
C_noret_decl(f_7512)
static void C_ccall f_7512(C_word c,C_word *av) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word *av) C_noret;
C_noret_decl(f_7518)
static void C_ccall f_7518(C_word c,C_word *av) C_noret;
C_noret_decl(f_7521)
static void C_ccall f_7521(C_word c,C_word *av) C_noret;
C_noret_decl(f_7525)
static void C_ccall f_7525(C_word c,C_word *av) C_noret;
C_noret_decl(f_7529)
static void C_ccall f_7529(C_word c,C_word *av) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word *av) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word *av) C_noret;
C_noret_decl(f_7544)
static void C_ccall f_7544(C_word c,C_word *av) C_noret;
C_noret_decl(f_7552)
static void C_ccall f_7552(C_word c,C_word *av) C_noret;
C_noret_decl(f_7570)
static void C_ccall f_7570(C_word c,C_word *av) C_noret;
C_noret_decl(f_7576)
static void C_ccall f_7576(C_word c,C_word *av) C_noret;
C_noret_decl(f_7580)
static void C_ccall f_7580(C_word c,C_word *av) C_noret;
C_noret_decl(f_7584)
static void C_ccall f_7584(C_word c,C_word *av) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word *av) C_noret;
C_noret_decl(f_7595)
static void C_fcall f_7595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7599)
static void C_ccall f_7599(C_word c,C_word *av) C_noret;
C_noret_decl(f_7602)
static void C_ccall f_7602(C_word c,C_word *av) C_noret;
C_noret_decl(f_7618)
static void C_ccall f_7618(C_word c,C_word *av) C_noret;
C_noret_decl(f_7621)
static void C_ccall f_7621(C_word c,C_word *av) C_noret;
C_noret_decl(f_7629)
static void C_fcall f_7629(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7654)
static void C_ccall f_7654(C_word c,C_word *av) C_noret;
C_noret_decl(f_7663)
static void C_fcall f_7663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7688)
static void C_ccall f_7688(C_word c,C_word *av) C_noret;
C_noret_decl(f_7705)
static void C_ccall f_7705(C_word c,C_word *av) C_noret;
C_noret_decl(f_7725)
static void C_ccall f_7725(C_word c,C_word *av) C_noret;
C_noret_decl(f_7729)
static void C_ccall f_7729(C_word c,C_word *av) C_noret;
C_noret_decl(f_7754)
static void C_ccall f_7754(C_word c,C_word *av) C_noret;
C_noret_decl(f_7772)
static void C_ccall f_7772(C_word c,C_word *av) C_noret;
C_noret_decl(f_7776)
static void C_ccall f_7776(C_word c,C_word *av) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word *av) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word *av) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word *av) C_noret;
C_noret_decl(f_7795)
static void C_ccall f_7795(C_word c,C_word *av) C_noret;
C_noret_decl(f_7806)
static void C_ccall f_7806(C_word c,C_word *av) C_noret;
C_noret_decl(f_7809)
static void C_ccall f_7809(C_word c,C_word *av) C_noret;
C_noret_decl(f_7816)
static void C_ccall f_7816(C_word c,C_word *av) C_noret;
C_noret_decl(f_7821)
static void C_ccall f_7821(C_word c,C_word *av) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word *av) C_noret;
C_noret_decl(f_7830)
static void C_ccall f_7830(C_word c,C_word *av) C_noret;
C_noret_decl(f_7834)
static void C_ccall f_7834(C_word c,C_word *av) C_noret;
C_noret_decl(f_7841)
static void C_ccall f_7841(C_word c,C_word *av) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word *av) C_noret;

C_noret_decl(trf_2941)
static void C_ccall trf_2941(C_word c,C_word *av) C_noret;
static void C_ccall trf_2941(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2941(t0,t1,t2);}

C_noret_decl(trf_2947)
static void C_ccall trf_2947(C_word c,C_word *av) C_noret;
static void C_ccall trf_2947(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2947(t0,t1,t2,t3);}

C_noret_decl(trf_3003)
static void C_ccall trf_3003(C_word c,C_word *av) C_noret;
static void C_ccall trf_3003(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3003(t0,t1,t2);}

C_noret_decl(trf_3078)
static void C_ccall trf_3078(C_word c,C_word *av) C_noret;
static void C_ccall trf_3078(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3078(t0,t1,t2);}

C_noret_decl(trf_3126)
static void C_ccall trf_3126(C_word c,C_word *av) C_noret;
static void C_ccall trf_3126(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3126(t0,t1,t2);}

C_noret_decl(trf_3134)
static void C_ccall trf_3134(C_word c,C_word *av) C_noret;
static void C_ccall trf_3134(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3134(t0,t1,t2,t3);}

C_noret_decl(trf_3170)
static void C_ccall trf_3170(C_word c,C_word *av) C_noret;
static void C_ccall trf_3170(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3170(t0,t1,t2);}

C_noret_decl(trf_3178)
static void C_ccall trf_3178(C_word c,C_word *av) C_noret;
static void C_ccall trf_3178(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3178(t0,t1,t2,t3);}

C_noret_decl(trf_3383)
static void C_ccall trf_3383(C_word c,C_word *av) C_noret;
static void C_ccall trf_3383(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3383(t0,t1,t2,t3);}

C_noret_decl(trf_3817)
static void C_ccall trf_3817(C_word c,C_word *av) C_noret;
static void C_ccall trf_3817(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3817(t0,t1,t2);}

C_noret_decl(trf_3938)
static void C_ccall trf_3938(C_word c,C_word *av) C_noret;
static void C_ccall trf_3938(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3938(t0,t1);}

C_noret_decl(trf_3941)
static void C_ccall trf_3941(C_word c,C_word *av) C_noret;
static void C_ccall trf_3941(C_word c,C_word *av){
C_word t0=av[0];
f_3941(t0);}

C_noret_decl(trf_4103)
static void C_ccall trf_4103(C_word c,C_word *av) C_noret;
static void C_ccall trf_4103(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4103(t0,t1);}

C_noret_decl(trf_4107)
static void C_ccall trf_4107(C_word c,C_word *av) C_noret;
static void C_ccall trf_4107(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4107(t0,t1);}

C_noret_decl(trf_4132)
static void C_ccall trf_4132(C_word c,C_word *av) C_noret;
static void C_ccall trf_4132(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4132(t0,t1,t2);}

C_noret_decl(trf_4226)
static void C_ccall trf_4226(C_word c,C_word *av) C_noret;
static void C_ccall trf_4226(C_word c,C_word *av){
C_word t0=av[0];
f_4226(t0);}

C_noret_decl(trf_4350)
static void C_ccall trf_4350(C_word c,C_word *av) C_noret;
static void C_ccall trf_4350(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4350(t0,t1);}

C_noret_decl(trf_4357)
static void C_ccall trf_4357(C_word c,C_word *av) C_noret;
static void C_ccall trf_4357(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4357(t0,t1,t2,t3);}

C_noret_decl(trf_4383)
static void C_ccall trf_4383(C_word c,C_word *av) C_noret;
static void C_ccall trf_4383(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4383(t0,t1);}

C_noret_decl(trf_4413)
static void C_ccall trf_4413(C_word c,C_word *av) C_noret;
static void C_ccall trf_4413(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4413(t0,t1);}

C_noret_decl(trf_4429)
static void C_ccall trf_4429(C_word c,C_word *av) C_noret;
static void C_ccall trf_4429(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4429(t0,t1,t2);}

C_noret_decl(trf_4462)
static void C_ccall trf_4462(C_word c,C_word *av) C_noret;
static void C_ccall trf_4462(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4462(t0,t1);}

C_noret_decl(trf_4606)
static void C_ccall trf_4606(C_word c,C_word *av) C_noret;
static void C_ccall trf_4606(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4606(t0,t1);}

C_noret_decl(trf_4609)
static void C_ccall trf_4609(C_word c,C_word *av) C_noret;
static void C_ccall trf_4609(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4609(t0,t1);}

C_noret_decl(trf_4858)
static void C_ccall trf_4858(C_word c,C_word *av) C_noret;
static void C_ccall trf_4858(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4858(t0,t1);}

C_noret_decl(trf_5293)
static void C_ccall trf_5293(C_word c,C_word *av) C_noret;
static void C_ccall trf_5293(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5293(t0,t1);}

C_noret_decl(trf_5484)
static void C_ccall trf_5484(C_word c,C_word *av) C_noret;
static void C_ccall trf_5484(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5484(t0,t1);}

C_noret_decl(trf_5576)
static void C_ccall trf_5576(C_word c,C_word *av) C_noret;
static void C_ccall trf_5576(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5576(t0,t1);}

C_noret_decl(trf_5579)
static void C_ccall trf_5579(C_word c,C_word *av) C_noret;
static void C_ccall trf_5579(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5579(t0,t1);}

C_noret_decl(trf_5633)
static void C_ccall trf_5633(C_word c,C_word *av) C_noret;
static void C_ccall trf_5633(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5633(t0,t1);}

C_noret_decl(trf_5642)
static void C_ccall trf_5642(C_word c,C_word *av) C_noret;
static void C_ccall trf_5642(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5642(t0,t1);}

C_noret_decl(trf_5734)
static void C_ccall trf_5734(C_word c,C_word *av) C_noret;
static void C_ccall trf_5734(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5734(t0,t1);}

C_noret_decl(trf_5780)
static void C_ccall trf_5780(C_word c,C_word *av) C_noret;
static void C_ccall trf_5780(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5780(t0,t1,t2);}

C_noret_decl(trf_5915)
static void C_ccall trf_5915(C_word c,C_word *av) C_noret;
static void C_ccall trf_5915(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5915(t0,t1);}

C_noret_decl(trf_5951)
static void C_ccall trf_5951(C_word c,C_word *av) C_noret;
static void C_ccall trf_5951(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5951(t0,t1);}

C_noret_decl(trf_6224)
static void C_ccall trf_6224(C_word c,C_word *av) C_noret;
static void C_ccall trf_6224(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6224(t0,t1);}

C_noret_decl(trf_6271)
static void C_ccall trf_6271(C_word c,C_word *av) C_noret;
static void C_ccall trf_6271(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6271(t0,t1);}

C_noret_decl(trf_6290)
static void C_ccall trf_6290(C_word c,C_word *av) C_noret;
static void C_ccall trf_6290(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6290(t0,t1,t2);}

C_noret_decl(trf_6326)
static void C_ccall trf_6326(C_word c,C_word *av) C_noret;
static void C_ccall trf_6326(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6326(t0,t1);}

C_noret_decl(trf_6336)
static void C_ccall trf_6336(C_word c,C_word *av) C_noret;
static void C_ccall trf_6336(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6336(t0,t1);}

C_noret_decl(trf_6386)
static void C_ccall trf_6386(C_word c,C_word *av) C_noret;
static void C_ccall trf_6386(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6386(t0,t1,t2);}

C_noret_decl(trf_6411)
static void C_ccall trf_6411(C_word c,C_word *av) C_noret;
static void C_ccall trf_6411(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6411(t0,t1,t2);}

C_noret_decl(trf_6453)
static void C_ccall trf_6453(C_word c,C_word *av) C_noret;
static void C_ccall trf_6453(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6453(t0,t1);}

C_noret_decl(trf_6500)
static void C_ccall trf_6500(C_word c,C_word *av) C_noret;
static void C_ccall trf_6500(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6500(t0,t1);}

C_noret_decl(trf_6501)
static void C_ccall trf_6501(C_word c,C_word *av) C_noret;
static void C_ccall trf_6501(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6501(t0,t1,t2);}

C_noret_decl(trf_6559)
static void C_ccall trf_6559(C_word c,C_word *av) C_noret;
static void C_ccall trf_6559(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6559(t0,t1,t2);}

C_noret_decl(trf_6582)
static void C_ccall trf_6582(C_word c,C_word *av) C_noret;
static void C_ccall trf_6582(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6582(t0,t1,t2);}

C_noret_decl(trf_6609)
static void C_ccall trf_6609(C_word c,C_word *av) C_noret;
static void C_ccall trf_6609(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6609(t0,t1,t2);}

C_noret_decl(trf_6633)
static void C_ccall trf_6633(C_word c,C_word *av) C_noret;
static void C_ccall trf_6633(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6633(t0,t1);}

C_noret_decl(trf_6660)
static void C_ccall trf_6660(C_word c,C_word *av) C_noret;
static void C_ccall trf_6660(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6660(t0,t1,t2);}

C_noret_decl(trf_6683)
static void C_ccall trf_6683(C_word c,C_word *av) C_noret;
static void C_ccall trf_6683(C_word c,C_word *av){
C_word t0=av[0];
f_6683(t0);}

C_noret_decl(trf_6702)
static void C_ccall trf_6702(C_word c,C_word *av) C_noret;
static void C_ccall trf_6702(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6702(t0,t1,t2);}

C_noret_decl(trf_6773)
static void C_ccall trf_6773(C_word c,C_word *av) C_noret;
static void C_ccall trf_6773(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6773(t0,t1,t2);}

C_noret_decl(trf_6886)
static void C_ccall trf_6886(C_word c,C_word *av) C_noret;
static void C_ccall trf_6886(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6886(t0,t1,t2);}

C_noret_decl(trf_6974)
static void C_ccall trf_6974(C_word c,C_word *av) C_noret;
static void C_ccall trf_6974(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6974(t0,t1,t2);}

C_noret_decl(trf_7008)
static void C_ccall trf_7008(C_word c,C_word *av) C_noret;
static void C_ccall trf_7008(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7008(t0,t1,t2);}

C_noret_decl(trf_7045)
static void C_ccall trf_7045(C_word c,C_word *av) C_noret;
static void C_ccall trf_7045(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7045(t0,t1,t2,t3);}

C_noret_decl(trf_7065)
static void C_ccall trf_7065(C_word c,C_word *av) C_noret;
static void C_ccall trf_7065(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7065(t0,t1);}

C_noret_decl(trf_7170)
static void C_ccall trf_7170(C_word c,C_word *av) C_noret;
static void C_ccall trf_7170(C_word c,C_word *av){
C_word t0=av[0];
f_7170(t0);}

C_noret_decl(trf_7189)
static void C_ccall trf_7189(C_word c,C_word *av) C_noret;
static void C_ccall trf_7189(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7189(t0,t1,t2);}

C_noret_decl(trf_7223)
static void C_ccall trf_7223(C_word c,C_word *av) C_noret;
static void C_ccall trf_7223(C_word c,C_word *av){
C_word t0=av[0];
f_7223(t0);}

C_noret_decl(trf_7278)
static void C_ccall trf_7278(C_word c,C_word *av) C_noret;
static void C_ccall trf_7278(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7278(t0,t1,t2);}

C_noret_decl(trf_7306)
static void C_ccall trf_7306(C_word c,C_word *av) C_noret;
static void C_ccall trf_7306(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7306(t0,t1);}

C_noret_decl(trf_7321)
static void C_ccall trf_7321(C_word c,C_word *av) C_noret;
static void C_ccall trf_7321(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7321(t0,t1,t2);}

C_noret_decl(trf_7330)
static void C_ccall trf_7330(C_word c,C_word *av) C_noret;
static void C_ccall trf_7330(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7330(t0,t1,t2);}

C_noret_decl(trf_7451)
static void C_ccall trf_7451(C_word c,C_word *av) C_noret;
static void C_ccall trf_7451(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7451(t0,t1,t2);}

C_noret_decl(trf_7467)
static void C_ccall trf_7467(C_word c,C_word *av) C_noret;
static void C_ccall trf_7467(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7467(t0,t1);}

C_noret_decl(trf_7595)
static void C_ccall trf_7595(C_word c,C_word *av) C_noret;
static void C_ccall trf_7595(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7595(t0,t1);}

C_noret_decl(trf_7629)
static void C_ccall trf_7629(C_word c,C_word *av) C_noret;
static void C_ccall trf_7629(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7629(t0,t1,t2);}

C_noret_decl(trf_7663)
static void C_ccall trf_7663(C_word c,C_word *av) C_noret;
static void C_ccall trf_7663(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7663(t0,t1,t2);}

/* f8584 in k6925 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f8584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f8584,2,av);}
/* csc.scm:998: chicken.file#file-exists? */
t2=C_fast_retrieve(lf[131]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* f8590 in k4506 in k4503 in k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in ... */
static void C_ccall f8590(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f8590,2,av);}
/* csc.scm:598: ##sys#print */
t2=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* f8594 in k4506 in k4503 in k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in ... */
static void C_ccall f8594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f8594,2,av);}
/* csc.scm:598: ##sys#print */
t2=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* f8616 in k4634 in k4631 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f8616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f8616,2,av);}
/* csc.scm:567: chicken.base#exit */
t2=C_fast_retrieve(lf[41]);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* f8662 in k4506 in k4503 in k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in ... */
static void C_ccall f8662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f8662,2,av);}
/* csc.scm:92: chicken.process#qs */
t2=C_fast_retrieve(lf[51]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2264 */
static void C_ccall f_2266(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2266,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2269,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k2267 in k2264 */
static void C_ccall f_2269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2269,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2272,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_expand_toplevel(2,av2);}}

/* k2270 in k2267 in k2264 */
static void C_ccall f_2272(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2272,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2275,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_file_toplevel(2,av2);}}

/* k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2275,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2278,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2278,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_pathname_toplevel(2,av2);}}

/* k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2281(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2281,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_posix_toplevel(2,av2);}}

/* k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2284,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_data_2dstructures_toplevel(2,av2);}}

/* k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,7)))){
C_save_and_reclaim((void *)f_2287,2,av);}
a=C_alloc(11);
t2=C_a_i_provide(&a,1,lf[0]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2290,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:28: ##sys#register-compiled-module */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[440]);
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=*((C_word*)lf[440]+1);
av2[1]=t3;
av2[2]=lf[441];
av2[3]=lf[441];
av2[4]=C_SCHEME_END_OF_LIST;
av2[5]=C_SCHEME_END_OF_LIST;
av2[6]=C_SCHEME_END_OF_LIST;
av2[7]=C_SCHEME_END_OF_LIST;
tp(8,av2);}}

/* k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2290,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[1] /* (set! main#staticbuild ...) */,C_mk_bool(STATIC_CHICKEN));
t3=C_mutate(&lf[2] /* (set! main#debugbuild ...) */,C_mk_bool(DEBUG_CHICKEN));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* egg-environment.scm:43: chicken.platform#feature? */
t5=C_fast_retrieve(lf[428]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[429];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2296(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2296,2,av);}
a=C_alloc(6);
t2=lf[3] /* main#cross-chicken */ =t1;;
t3=lf[4] /* main#binary-version */ =C_fix((C_word)C_BINARY_VERSION);;
t4=lf[5] /* main#major-version */ =C_fix((C_word)C_MAJOR_VERSION);;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2302,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_mpointer(&a,(void*)C_TARGET_CC);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2302(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2302,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[6] /* (set! main#default-cc ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_CXX);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2306(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2306,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[7] /* (set! main#default-cxx ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_INSTALL_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2310(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2310,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_TARGET_CFLAGS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2314,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[8] /* (set! main#default-cflags ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_LDFLAGS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2318(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2318,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_TARGET_INSTALL_PROGRAM_EXECUTABLE_OPTIONS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2322,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_TARGET_INSTALL_PROGRAM_FILE_OPTIONS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2326(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2326,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_TARGET_MORE_LIBS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2330,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[9] /* (set! main#default-libs ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_LIB_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2334,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[10] /* (set! main#default-libdir ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2338(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2338,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[11] /* (set! main#default-runlibdir ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_STATIC_LIB_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 */
static void C_ccall f_2342(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2342,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in k2264 in ... */
static void C_ccall f_2346(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2346,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[12] /* (set! main#default-incdir ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_BIN_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in k2267 in ... */
static void C_ccall f_2350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2350,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[13] /* (set! main#default-bindir ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_SHARE_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in k2270 in ... */
static void C_ccall f_2354(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2354,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[14] /* (set! main#default-sharedir ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7841,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* egg-environment.scm:63: chicken.platform#software-type */
t4=C_fast_retrieve(lf[219]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in ... */
static void C_ccall f_2362(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2362,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_BIN_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in ... */
static void C_ccall f_2366(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2366,2,av);}
a=C_alloc(9);
t2=C_mutate(&lf[13] /* (set! main#default-bindir ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7834,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_mpointer(&a,(void*)C_CSC_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in ... */
static void C_ccall f_2370(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2370,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7830,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_CSI_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in ... */
static void C_ccall f_2374(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2374,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2378,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7826,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_CHICKEN_DO_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in ... */
static void C_ccall f_2378(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2378,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_TARGET_LIBRARIAN);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in ... */
static void C_ccall f_2382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2382,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_TARGET_LIBRARIAN_FLAGS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in ... */
static void C_ccall f_2386(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2386,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_EGG_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in ... */
static void C_ccall f_2390(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2390,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_LIB_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in ... */
static void C_ccall f_2394(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2394,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[17] /* (set! main#host-libdir ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_BIN_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in ... */
static void C_ccall f_2398(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2398,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[18] /* (set! main#host-bindir ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in ... */
static void C_ccall f_2402(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2402,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[19] /* (set! main#host-incdir ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in ... */
static void C_ccall f_2406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2406,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[20] /* (set! main#host-sharedir ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in ... */
static void C_ccall f_2410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2410,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[21] /* (set! main#host-libs ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_CFLAGS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in ... */
static void C_ccall f_2414(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2414,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[22] /* (set! main#host-cflags ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_LDFLAGS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in ... */
static void C_ccall f_2418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2418,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_CC);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in ... */
static void C_ccall f_2422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2422,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[23] /* (set! main#host-cc ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2426,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_CXX);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in ... */
static void C_ccall f_2426(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2426,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[24] /* (set! main#host-cxx ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7821,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_retrieve2(lf[4],C_text("main#binary-version"));
/* ##sys#fixnum->string */
t6=C_fast_retrieve(lf[436]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=C_retrieve2(lf[4],C_text("main#binary-version"));
av2[3]=C_fix(10);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in ... */
static void C_ccall f_2430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_2430,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[25] /* (set! main#target-repo ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7816,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_retrieve2(lf[4],C_text("main#binary-version"));
/* ##sys#fixnum->string */
t6=C_fast_retrieve(lf[436]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=C_retrieve2(lf[4],C_text("main#binary-version"));
av2[3]=C_fix(10);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in ... */
static void C_ccall f_2434(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2434,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[26] /* (set! main#target-run-repo ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* egg-environment.scm:120: chicken.process-context#get-environment-variable */
t4=C_fast_retrieve(lf[162]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[434];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in ... */
static void C_ccall f_2503(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_2503,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=t1;
f_2506(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7806,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* egg-environment.scm:121: chicken.platform#system-cache-directory */
t4=C_fast_retrieve(lf[433]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in ... */
static void C_ccall f_2506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_2506,2,av);}
a=C_alloc(8);
t2=C_mutate(&lf[27] /* (set! main#cons* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2941,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* main#cons* in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in ... */
static void C_fcall f_2941(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_2941,3,t1,t2,t3);}
a=C_alloc(5);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_2947(t7,t1,t2,t3);}

/* loop in main#cons* in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in ... */
static void C_fcall f_2947(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_2947,4,t0,t1,t2,t3);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2961,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(t3);
t6=t3;
t7=C_u_i_cdr(t6);
/* mini-srfi-1.scm:95: loop */
t9=t4;
t10=t5;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k2959 in loop in main#cons* in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in ... */
static void C_ccall f_2961(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_2961,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in loop in k7057 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_fcall f_3003(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_3003,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3016,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* mini-srfi-1.scm:106: test */
t5=((C_word*)t0)[3];{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=t4;
((C_proc)C_fast_retrieve_proc(t5))(4,av2);}}}

/* k3014 in loop in loop in k7057 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_3016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3016,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* mini-srfi-1.scm:107: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3003(t4,((C_word*)t0)[4],t3);}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* mini-srfi-1.scm:109: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_3003(t7,t4,t6);}}

/* k3028 in k3014 in loop in loop in k7057 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in ... */
static void C_ccall f_3030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3030,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k7057 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_fcall f_3078(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(17,0,3)))){
C_save_and_reclaim_args((void *)trf_3078,3,t0,t1,t2);}
a=C_alloc(17);
if(C_truep(C_i_nullp(t2))){
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3092,a[2]=t6,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=t4;
t10=((C_word*)t0)[3];
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3003,a[2]=t12,a[3]=t10,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_3003(t14,t8,t6);}}

/* k3090 in loop in k7057 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_3092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3092,2,av);}
a=C_alloc(3);
t2=C_i_equalp(((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=(C_truep(t2)?((C_word*)t0)[4]:C_a_i_cons(&a,2,((C_word*)t0)[5],t1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3103 in loop in k7057 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_3105(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3105,2,av);}
/* mini-srfi-1.scm:123: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3078(t2,((C_word*)t0)[3],t1);}

/* foldr457 in foldl563 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_fcall f_3126(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_3126,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3155,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g462 in foldr457 in foldl563 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_fcall f_3134(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3134,4,t0,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3141,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* mini-srfi-1.scm:131: pred */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* k3139 in g462 in foldr457 in foldl563 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_3141(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3141,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3153 in foldr457 in foldl563 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_3155(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3155,2,av);}
/* mini-srfi-1.scm:131: g462 */
t2=((C_word*)t0)[2];
f_3134(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* foldr475 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_fcall f_3170(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_3170,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3204,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g480 in foldr475 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_fcall f_3178(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_3178,4,t0,t1,t2,t3);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3182,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* mini-srfi-1.scm:135: pred */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* k3180 in g480 in foldr475 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_3182(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_3182,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* mini-srfi-1.scm:135: g490 */
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=(
/* mini-srfi-1.scm:135: g490 */
  f_3186(C_a_i(&a,3),t2,t1)
);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g490 in k3180 in g480 in foldr475 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static C_word C_fcall f_3186(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k3202 in foldr475 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_3204(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3204,2,av);}
/* mini-srfi-1.scm:134: g480 */
t2=((C_word*)t0)[2];
f_3178(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* loop in k4557 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static C_word C_fcall f_3283(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:{}
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=t1;
t4=C_u_i_car(t3);
return(t4);}
else{
t3=t1;
t4=C_u_i_cdr(t3);
t6=t4;
t1=t6;
goto loop;}}

/* foldl563 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_fcall f_3383(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,3)))){
C_save_and_reclaim_args((void *)trf_3383,4,t0,t1,t2,t3);}
a=C_alloc(14);
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3416,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(0));
t8=t3;
t9=t7;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=t10;
t12=C_i_check_list_2(t8,lf[392]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3126,a[2]=t11,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_3126(t16,t6,t8);}
else{
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* a3404 in foldl563 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_3405(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3405,3,av);}
t3=C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_not(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3414 in foldl563 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_3416(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3416,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
f_3383(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in ... */
static void C_ccall f_3788(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3788,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[21] /* (set! main#host-libs ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7795,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:67: chicken.platform#software-version */
t4=C_fast_retrieve(lf[247]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in ... */
static void C_ccall f_3814(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_3814,2,av);}
a=C_alloc(5);
t2=C_mutate(&lf[36] /* (set! main#elf ...) */,C_u_i_memq(t1,lf[37]));
t3=C_mutate(&lf[38] /* (set! main#stop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3817,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3844,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:79: chicken.process-context#command-line-arguments */
t5=C_fast_retrieve(lf[430]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* main#stop in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in ... */
static void C_fcall f_3817(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,3)))){
C_save_and_reclaim_args((void *)trf_3817,3,t1,t2,t3);}
a=C_alloc(13);
t4=*((C_word*)lf[39]+1);
t5=*((C_word*)lf[39]+1);
t6=C_i_check_port_2(*((C_word*)lf[39]+1),C_fix(2),C_SCHEME_TRUE,lf[40]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3824,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3840,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t9=*((C_word*)lf[46]+1);{
C_word av2[4];
av2[0]=t9;
av2[1]=t8;
av2[2]=C_mpointer(&a,(void*)C_CSC_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}

/* k3822 in main#stop in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in ... */
static void C_ccall f_3824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3824,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:76: ##sys#print */
t3=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[45];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3825 in k3822 in main#stop in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in ... */
static void C_ccall f_3827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,5)))){
C_save_and_reclaim((void *)f_3827,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=0;
av2[1]=t2;
av2[2]=*((C_word*)lf[43]+1);
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
av2[5]=((C_word*)t0)[5];
C_apply(6,av2);}}

/* k3828 in k3825 in k3822 in main#stop in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in ... */
static void C_ccall f_3830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3830,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3833,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:76: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[42]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[42]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k3831 in k3828 in k3825 in k3822 in main#stop in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in ... */
static void C_ccall f_3833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3833,2,av);}
/* csc.scm:77: chicken.base#exit */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(64);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3838 in main#stop in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in ... */
static void C_ccall f_3840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3840,2,av);}
/* csc.scm:76: ##sys#print */
t2=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in ... */
static void C_ccall f_3844(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3844,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[47] /* (set! main#arguments ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3848,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:80: chicken.platform#feature? */
t4=C_fast_retrieve(lf[428]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[429];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in ... */
static void C_ccall f_3848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,3)))){
C_save_and_reclaim((void *)f_3848,2,av);}
a=C_alloc(16);
t2=lf[3] /* main#cross-chicken */ =t1;;
t3=C_i_not(C_retrieve2(lf[3],C_text("main#cross-chicken")));
t4=(C_truep(t3)?t3:C_i_member(lf[48],C_retrieve2(lf[47],C_text("main#arguments"))));
t5=C_mutate(&lf[49] /* (set! main#host-mode ...) */,t4);
t6=C_mutate(&lf[50] /* (set! main#quotewrap ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3866,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[54] /* (set! main#quotewrap-no-slash-trans ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3880,tmp=(C_word)a,a+=2,tmp));
t8=(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))?C_retrieve2(lf[20],C_text("main#host-sharedir")):C_retrieve2(lf[14],C_text("main#default-sharedir")));
t9=C_mutate(&lf[55] /* (set! main#home ...) */,t8);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3896,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7772,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7776,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t13=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t13;
av2[1]=t12;
av2[2]=C_mpointer(&a,(void*)C_CHICKEN_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t13+1)))(4,av2);}}

/* main#quotewrap in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in ... */
static void C_ccall f_3866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_3866,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3874,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3878,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:89: chicken.pathname#normalize-pathname */
t5=C_fast_retrieve(lf[53]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3872 in main#quotewrap in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in ... */
static void C_ccall f_3874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3874,2,av);}
/* csc.scm:89: chicken.process#qs */
t2=C_fast_retrieve(lf[51]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3876 in main#quotewrap in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in ... */
static void C_ccall f_3878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3878,2,av);}
if(C_truep(C_mk_bool(C_WINDOWS_SHELL))){
/* csc.scm:85: chicken.string#string-translate */
t2=C_fast_retrieve(lf[52]);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_make_character(92);
av2[4]=C_make_character(47);
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=t1;
/* csc.scm:89: chicken.process#qs */
t3=C_fast_retrieve(lf[51]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* main#quotewrap-no-slash-trans in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in ... */
static void C_ccall f_3880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3880,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3888,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: chicken.pathname#normalize-pathname */
t4=C_fast_retrieve(lf[53]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3886 in main#quotewrap-no-slash-trans in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in ... */
static void C_ccall f_3888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3888,2,av);}
/* csc.scm:92: chicken.process#qs */
t2=C_fast_retrieve(lf[51]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in ... */
static void C_ccall f_3896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3896,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[56] /* (set! main#translator ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3900,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
t4=C_retrieve2(lf[23],C_text("main#host-cc"));
t5=C_retrieve2(lf[23],C_text("main#host-cc"));
/* csc.scm:100: quotewrap */
t6=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=C_retrieve2(lf[23],C_text("main#host-cc"));
f_3866(3,av2);}}
else{
t4=C_retrieve2(lf[6],C_text("main#default-cc"));
t5=C_retrieve2(lf[6],C_text("main#default-cc"));
/* csc.scm:100: quotewrap */
t6=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=C_retrieve2(lf[6],C_text("main#default-cc"));
f_3866(3,av2);}}}

/* k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in ... */
static void C_ccall f_3900(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3900,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[57] /* (set! main#compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
t4=C_retrieve2(lf[24],C_text("main#host-cxx"));
t5=C_retrieve2(lf[24],C_text("main#host-cxx"));
/* csc.scm:101: quotewrap */
t6=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=C_retrieve2(lf[24],C_text("main#host-cxx"));
f_3866(3,av2);}}
else{
t4=C_retrieve2(lf[7],C_text("main#default-cxx"));
t5=C_retrieve2(lf[7],C_text("main#default-cxx"));
/* csc.scm:101: quotewrap */
t6=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=C_retrieve2(lf[7],C_text("main#default-cxx"));
f_3866(3,av2);}}}

/* k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in ... */
static void C_ccall f_3904(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_3904,2,av);}
a=C_alloc(9);
t2=C_mutate(&lf[58] /* (set! main#c++-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7754,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_RC_COMPILER);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_mpointer(&a,(void*)C_TARGET_RC_COMPILER);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in ... */
static void C_ccall f_3908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3908,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[59] /* (set! main#rc-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
t4=C_retrieve2(lf[23],C_text("main#host-cc"));
t5=C_retrieve2(lf[23],C_text("main#host-cc"));
/* csc.scm:103: quotewrap */
t6=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=C_retrieve2(lf[23],C_text("main#host-cc"));
f_3866(3,av2);}}
else{
t4=C_retrieve2(lf[6],C_text("main#default-cc"));
t5=C_retrieve2(lf[6],C_text("main#default-cc"));
/* csc.scm:103: quotewrap */
t6=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=C_retrieve2(lf[6],C_text("main#default-cc"));
f_3866(3,av2);}}}

/* k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in ... */
static void C_ccall f_3912(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3912,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[60] /* (set! main#linker ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
t4=C_retrieve2(lf[24],C_text("main#host-cxx"));
t5=C_retrieve2(lf[24],C_text("main#host-cxx"));
/* csc.scm:104: quotewrap */
t6=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=C_retrieve2(lf[24],C_text("main#host-cxx"));
f_3866(3,av2);}}
else{
t4=C_retrieve2(lf[7],C_text("main#default-cxx"));
t5=C_retrieve2(lf[7],C_text("main#default-cxx"));
/* csc.scm:104: quotewrap */
t6=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=C_retrieve2(lf[7],C_text("main#default-cxx"));
f_3866(3,av2);}}}

/* k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in ... */
static void C_ccall f_3916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3916,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[61] /* (set! main#c++-linker ...) */,t1);
t3=(C_truep(C_retrieve2(lf[29],C_text("main#mingw")))?lf[62]:lf[63]);
t4=C_mutate(&lf[64] /* (set! main#object-extension ...) */,t3);
t5=C_mutate(&lf[65] /* (set! main#library-extension ...) */,lf[66]);
t6=C_mutate(&lf[67] /* (set! main#executable-extension ...) */,lf[68]);
t7=C_mutate(&lf[69] /* (set! main#shared-library-extension ...) */,C_fast_retrieve(lf[70]));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:111: ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[186]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[186]+1);
av2[1]=t8;
av2[2]=lf[427];
av2[3]=C_retrieve2(lf[64],C_text("main#object-extension"));
tp(4,av2);}}

/* k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in ... */
static void C_ccall f_3929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3929,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[71] /* (set! main#static-object-extension ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:112: ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[186]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[186]+1);
av2[1]=t3;
av2[2]=lf[426];
av2[3]=C_retrieve2(lf[65],C_text("main#library-extension"));
tp(4,av2);}}

/* k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in ... */
static void C_ccall f_3933(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3933,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[72] /* (set! main#static-library-extension ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[29],C_text("main#mingw"));
if(C_truep(C_retrieve2(lf[29],C_text("main#mingw")))){
t5=C_retrieve2(lf[29],C_text("main#mingw"));
t6=t3;
f_3938(t6,(C_truep(C_retrieve2(lf[29],C_text("main#mingw")))?lf[424]:lf[425]));}
else{
t5=C_retrieve2(lf[33],C_text("main#cygwin"));
t6=t3;
f_3938(t6,(C_truep(C_retrieve2(lf[33],C_text("main#cygwin")))?lf[424]:lf[425]));}}

/* k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in ... */
static void C_fcall f_3938(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3938,2,t0,t1);}
a=C_alloc(5);
t2=C_mutate(&lf[73] /* (set! main#pic-options ...) */,t1);
t3=lf[74] /* main#generate-manifest */ =C_SCHEME_FALSE;;
t4=C_mutate(&lf[75] /* (set! main#libchicken ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3941,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3988,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
t6=C_retrieve2(lf[22],C_text("main#host-cflags"));
t7=C_retrieve2(lf[22],C_text("main#host-cflags"));
/* csc.scm:132: chicken.string#string-split */
t8=C_fast_retrieve(lf[240]);{
C_word av2[3];
av2[0]=t8;
av2[1]=t5;
av2[2]=C_retrieve2(lf[22],C_text("main#host-cflags"));
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t6=C_retrieve2(lf[8],C_text("main#default-cflags"));
t7=C_retrieve2(lf[8],C_text("main#default-cflags"));
/* csc.scm:132: chicken.string#string-split */
t8=C_fast_retrieve(lf[240]);{
C_word av2[3];
av2[0]=t8;
av2[1]=t5;
av2[2]=C_retrieve2(lf[8],C_text("main#default-cflags"));
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}}

/* main#libchicken in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in ... */
static void C_fcall f_3941(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_3941,1,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3949,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_not(C_retrieve2(lf[49],C_text("main#host-mode"))))){
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_TARGET_LIB_NAME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_LIB_NAME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k3947 in main#libchicken in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in ... */
static void C_ccall f_3949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3949,2,av);}
/* csc.scm:118: scheme#string-append */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[77];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3982 in main#linker-libraries in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_3984(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3984,2,av);}
/* csc.scm:129: chicken.pathname#make-pathname */
t2=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[106],C_text("main#library-dir"));
av2[3]=t1;
av2[4]=C_retrieve2(lf[65],C_text("main#library-extension"));
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in ... */
static void C_ccall f_3988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_3988,2,av);}
a=C_alloc(9);
t2=C_mutate(&lf[78] /* (set! main#default-compilation-optimization-options ...) */,t1);
t3=C_mutate(&lf[79] /* (set! main#best-compilation-optimization-options ...) */,C_retrieve2(lf[78],C_text("main#default-compilation-optimization-options")));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7729,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_LDFLAGS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_mpointer(&a,(void*)C_TARGET_LDFLAGS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in ... */
static void C_ccall f_3993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_3993,2,av);}
a=C_alloc(9);
t2=C_mutate(&lf[80] /* (set! main#default-linking-optimization-options ...) */,t1);
t3=C_mutate(&lf[81] /* (set! main#best-linking-optimization-options ...) */,C_retrieve2(lf[80],C_text("main#default-linking-optimization-options")));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3998,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
t5=t4;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_END_OF_LIST;
f_3998(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7725,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_mpointer(&a,(void*)C_TARGET_FEATURES);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in ... */
static void C_ccall f_3998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3998,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[82] /* (set! main#extra-features ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#string->list */
t4=C_fast_retrieve(lf[149]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[423];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in ... */
static void C_ccall f_4005(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_4005,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[83] /* (set! main#short-options ...) */,t1);
t3=lf[84] /* main#scheme-files */ =C_SCHEME_END_OF_LIST;;
t4=lf[85] /* main#c-files */ =C_SCHEME_END_OF_LIST;;
t5=lf[86] /* main#rc-files */ =C_SCHEME_END_OF_LIST;;
t6=lf[87] /* main#generated-c-files */ =C_SCHEME_END_OF_LIST;;
t7=lf[88] /* main#generated-rc-files */ =C_SCHEME_END_OF_LIST;;
t8=lf[89] /* main#object-files */ =C_SCHEME_END_OF_LIST;;
t9=lf[90] /* main#generated-object-files */ =C_SCHEME_END_OF_LIST;;
t10=lf[91] /* main#transient-link-files */ =C_SCHEME_END_OF_LIST;;
t11=lf[92] /* main#linked-extensions */ =C_SCHEME_END_OF_LIST;;
t12=lf[93] /* main#cpp-mode */ =C_SCHEME_FALSE;;
t13=lf[94] /* main#objc-mode */ =C_SCHEME_FALSE;;
t14=lf[95] /* main#embedded */ =C_SCHEME_FALSE;;
t15=lf[96] /* main#inquiry-only */ =C_SCHEME_FALSE;;
t16=lf[97] /* main#show-cflags */ =C_SCHEME_FALSE;;
t17=lf[98] /* main#show-ldflags */ =C_SCHEME_FALSE;;
t18=lf[99] /* main#show-libs */ =C_SCHEME_FALSE;;
t19=lf[100] /* main#dry-run */ =C_SCHEME_FALSE;;
t20=lf[101] /* main#gui */ =C_SCHEME_FALSE;;
t21=lf[102] /* main#deployed */ =C_SCHEME_FALSE;;
t22=lf[103] /* main#rpath */ =C_SCHEME_FALSE;;
t23=lf[104] /* main#ignore-repository */ =C_SCHEME_FALSE;;
t24=lf[105] /* main#show-debugging-help */ =C_SCHEME_FALSE;;
t25=(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))?C_retrieve2(lf[17],C_text("main#host-libdir")):C_retrieve2(lf[10],C_text("main#default-libdir")));
t26=C_mutate(&lf[106] /* (set! main#library-dir ...) */,t25);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
/* ##sys#peek-c-string */
t28=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t28;
av2[1]=t27;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t28+1)))(4,av2);}}
else{
/* ##sys#peek-c-string */
t28=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t28;
av2[1]=t27;
av2[2]=C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t28+1)))(4,av2);}}}

/* k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in ... */
static void C_ccall f_4035(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_4035,2,av);}
a=C_alloc(9);
t2=C_mutate(&lf[107] /* (set! main#extra-libraries ...) */,t1);
t3=(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))?C_retrieve2(lf[21],C_text("main#host-libs")):C_retrieve2(lf[9],C_text("main#default-libs")));
t4=C_mutate(&lf[108] /* (set! main#extra-shared-libraries ...) */,t3);
t5=lf[109] /* main#translate-options */ =C_SCHEME_END_OF_LIST;;
t6=(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))?C_retrieve2(lf[19],C_text("main#host-incdir")):C_retrieve2(lf[12],C_text("main#default-incdir")));
t7=C_i_member(t6,lf[110]);
t8=C_i_not(t7);
t9=(C_truep(t8)?t6:C_SCHEME_FALSE);
t10=C_mutate(&lf[111] /* (set! main#include-dir ...) */,t9);
t11=lf[112] /* main#compile-options */ =C_SCHEME_END_OF_LIST;;
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7595,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[111],C_text("main#include-dir")))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7705,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:245: chicken.string#conc */
t15=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=lf[422];
av2[3]=C_retrieve2(lf[111],C_text("main#include-dir"));
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}
else{
t14=t13;
f_7595(t14,C_SCHEME_END_OF_LIST);}}

/* k4047 in main#linker-libraries in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_4049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_4049,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list1(&a,1,t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4051 in main#linker-libraries in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_4053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4053,2,av);}
/* csc.scm:229: scheme#string-append */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[140];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4067 in main#linker-libraries in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_4069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_4069,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list1(&a,1,t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in ... */
static void C_ccall f_4088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(30,c,4)))){
C_save_and_reclaim((void *)f_4088,2,av);}
a=C_alloc(30);
t2=C_mutate(&lf[113] /* (set! main#builtin-compile-options ...) */,t1);
t3=lf[114] /* main#translation-optimization-options */ =C_SCHEME_END_OF_LIST;;
t4=C_mutate(&lf[115] /* (set! main#compilation-optimization-options ...) */,C_retrieve2(lf[78],C_text("main#default-compilation-optimization-options")));
t5=C_mutate(&lf[116] /* (set! main#linking-optimization-options ...) */,C_retrieve2(lf[80],C_text("main#default-linking-optimization-options")));
t6=lf[117] /* main#link-options */ =C_SCHEME_END_OF_LIST;;
t7=lf[118] /* main#target-filename */ =C_SCHEME_FALSE;;
t8=lf[119] /* main#verbose */ =C_SCHEME_FALSE;;
t9=lf[120] /* main#keep-files */ =C_SCHEME_FALSE;;
t10=lf[121] /* main#translate-only */ =C_SCHEME_FALSE;;
t11=lf[122] /* main#compile-only */ =C_SCHEME_FALSE;;
t12=lf[123] /* main#to-stdout */ =C_SCHEME_FALSE;;
t13=lf[124] /* main#shared */ =C_SCHEME_FALSE;;
t14=lf[125] /* main#static */ =C_SCHEME_FALSE;;
t15=C_mutate(&lf[126] /* (set! main#repo-path ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4226,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[128] /* (set! main#find-object-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4238,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[133] /* (set! main#compiler-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6683,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[138] /* (set! main#linker-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7170,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[139] /* (set! main#linker-libraries ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7223,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[141] /* (set! main#constant1663 ...) */,lf[142]);
t21=C_mutate(&lf[143] /* (set! main#string-any ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7321,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate(&lf[134] /* (set! main#quote-option ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7355,tmp=(C_word)a,a+=2,tmp));
t23=lf[150] /* main#last-exit-code */ =C_SCHEME_FALSE;;
t24=C_mutate(&lf[151] /* (set! main#command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7467,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate(&lf[164] /* (set! main#$delete-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7480,tmp=(C_word)a,a+=2,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7570,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7580,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7584,a[2]=t27,tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7588,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1138: chicken.process-context#get-environment-variable */
t30=C_fast_retrieve(lf[162]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t30;
av2[1]=t29;
av2[2]=lf[418];
((C_proc)(void*)(*((C_word*)t30+1)))(3,av2);}}

/* k4101 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_fcall f_4103(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_4103,2,t0,t1);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4107,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[102],C_text("main#deployed")))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4177,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:273: chicken.platform#software-version */
t5=C_fast_retrieve(lf[247]);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t3;
f_4107(t4,C_SCHEME_END_OF_LIST);}}

/* k4105 in k4101 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_fcall f_4107(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_4107,2,t0,t1);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:276: chicken.process-context#get-environment-variable */
t4=C_fast_retrieve(lf[162]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[242];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4109 in k4105 in k4101 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,4)))){
C_save_and_reclaim((void *)f_4111,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
t4=t1;
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4127,a[2]=t7,a[3]=t8,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:278: chicken.string#string-split */
t10=C_fast_retrieve(lf[240]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=t4;
av2[3]=lf[241];
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
/* csc.scm:259: scheme#append */
t3=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k4112 in k4109 in k4105 in k4101 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_4114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4114,2,av);}
/* csc.scm:259: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4125 in k4109 in k4105 in k4101 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_4127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_4127,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4132,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4132(t5,((C_word*)t0)[4],t1);}

/* map-loop941 in k4125 in k4109 in k4105 in k4101 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_fcall f_4132(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_4132,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:278: g964 */
t5=*((C_word*)lf[76]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[239];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4155 in map-loop941 in k4125 in k4109 in k4105 in k4101 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_4157(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4157,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4132(t6,((C_word*)t0)[5],t5);}

/* k4175 in k4101 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_4177,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
f_4107(t2,(C_truep((C_truep(C_eqp(t1,lf[243]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[244]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[245]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))?C_a_i_list1(&a,1,lf[246]):C_SCHEME_END_OF_LIST));}

/* k4183 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4185(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_4185,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4189,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4193,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[102],C_text("main#deployed")))){
/* csc.scm:263: chicken.string#conc */
t5=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[249];
av2[3]=lf[250];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
t5=C_retrieve2(lf[17],C_text("main#host-libdir"));
t6=C_retrieve2(lf[17],C_text("main#host-libdir"));
/* csc.scm:263: chicken.string#conc */
t7=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=lf[249];
av2[3]=C_retrieve2(lf[17],C_text("main#host-libdir"));
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}}

/* k4187 in k4183 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_4189,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
f_4103(t2,C_a_i_list2(&a,2,((C_word*)t0)[3],t1));}

/* k4191 in k4183 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4193,2,av);}
/* csc.scm:263: chicken.string#conc */
t2=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[249];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4207 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_4209,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
f_4103(t2,C_a_i_list1(&a,1,t1));}

/* k4214 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4216(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_4216,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
f_4103(t2,C_a_i_list1(&a,1,t1));}

/* main#repo-path in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_fcall f_4226(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,1)))){
C_save_and_reclaim_args((void *)trf_4226,1,t1);}
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
/* csc.scm:295: chicken.platform#repository-path */
t2=C_fast_retrieve(lf[127]);{
C_word av2[2];
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=t1;
t3=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t3))){
t4=t2;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_retrieve2(lf[25],C_text("main#target-repo"));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_car(t3);
t5=t2;{
C_word av2[2];
av2[0]=t5;
av2[1]=(C_truep(t4)?C_retrieve2(lf[26],C_text("main#target-run-repo")):C_retrieve2(lf[25],C_text("main#target-repo")));
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}

/* main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_ccall f_4238(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_4238,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4242,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:299: chicken.pathname#make-pathname */
t4=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
av2[3]=t2;
av2[4]=C_retrieve2(lf[64],C_text("main#object-extension"));
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4240 in main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_4242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4242,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:300: chicken.pathname#make-pathname */
t4=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[3];
av2[4]=C_retrieve2(lf[65],C_text("main#library-extension"));
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4243 in k4240 in main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_4245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_4245,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:302: chicken.pathname#make-pathname */
t4=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[4];
av2[4]=C_retrieve2(lf[72],C_text("main#static-library-extension"));
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4246 in k4243 in k4240 in main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4248(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_4248,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csc.scm:303: chicken.pathname#make-pathname */
t4=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[5];
av2[4]=C_retrieve2(lf[71],C_text("main#static-object-extension"));
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4249 in k4246 in k4243 in k4240 in main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_4251,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:304: chicken.file#file-exists? */
t4=C_fast_retrieve(lf[131]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4252 in k4249 in k4246 in k4243 in k4240 in main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4254(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_4254,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:305: chicken.file#file-exists? */
t3=C_fast_retrieve(lf[131]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k4258 in k4252 in k4249 in k4246 in k4243 in k4240 in main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_4260(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_4260,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(C_fast_retrieve(lf[130]),C_SCHEME_TRUE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4298,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:307: chicken.file#file-exists? */
t5=C_fast_retrieve(lf[131]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t2;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_4266(2,av2);}}}}

/* k4264 in k4258 in k4252 in k4249 in k4246 in k4243 in k4240 in main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_ccall f_4266(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_4266,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_not(C_retrieve2(lf[104],C_text("main#ignore-repository"))))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4292,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:310: repo-path */
f_4226(t3);}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* k4276 in k4264 in k4258 in k4252 in k4249 in k4246 in k4243 in k4240 in main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_4278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4278,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:311: repo-path */
f_4226(t2);}}

/* k4286 in k4276 in k4264 in k4258 in k4252 in k4249 in k4246 in k4243 in k4240 in main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_4288(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4288,2,av);}
/* csc.scm:311: chicken.load#find-file */
t2=C_fast_retrieve(lf[129]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4290 in k4264 in k4258 in k4252 in k4249 in k4246 in k4243 in k4240 in main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_4292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4292,2,av);}
/* csc.scm:310: chicken.load#find-file */
t2=C_fast_retrieve(lf[129]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4296 in k4258 in k4252 in k4249 in k4246 in k4243 in k4240 in main#find-object-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_ccall f_4298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4298,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
f_4266(2,av2);}}
else{
/* csc.scm:308: chicken.file#file-exists? */
t2=C_fast_retrieve(lf[131]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k4308 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4310(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,2)))){
C_save_and_reclaim((void *)f_4310,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[257],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,lf[258],t4);
t6=C_a_i_cons(&a,2,t1,t5);
t7=C_a_i_cons(&a,2,lf[259],t6);
t8=C_a_i_cons(&a,2,t1,t7);
t9=C_a_i_cons(&a,2,lf[260],t8);
/* csc.scm:28: ##sys#print-to-string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[214]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[214]+1);
av2[1]=t2;
av2[2]=t9;
tp(3,av2);}}

/* k4315 in k4308 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4317,2,av);}
/* csc.scm:318: chicken.base#print */
t2=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* t-options in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_fcall f_4350(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,3)))){
C_save_and_reclaim_args((void *)trf_4350,2,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4355,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:530: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=C_retrieve2(lf[109],C_text("main#translate-options"));
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k4353 in t-options in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_4355(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4355,2,av);}
t2=C_mutate(&lf[109] /* (set! main#translate-options ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* check in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_fcall f_4357(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,3)))){
C_save_and_reclaim_args((void *)trf_4357,4,t1,t2,t3,t4);}
a=C_alloc(3);
t5=C_i_length(t3);
if(C_truep(C_i_nullp(t4))){
if(C_truep(C_i_greater_or_equalp(t5,C_fix(1)))){
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
/* csc.scm:534: stop */
f_3817(t1,lf[168],C_a_i_list(&a,1,t2));}}
else{
t6=C_i_car(t4);
if(C_truep(C_i_greater_or_equalp(t5,t6))){
t7=C_SCHEME_UNDEFINED;
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
/* csc.scm:534: stop */
f_3817(t1,lf[168],C_a_i_list(&a,1,t2));}}}

/* shared-build in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_fcall f_4383(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,3)))){
C_save_and_reclaim_args((void *)trf_4383,2,t1,t2);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4388,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:537: cons* */
f_2941(t3,lf[173],C_a_i_list(&a,2,lf[174],C_retrieve2(lf[109],C_text("main#translate-options"))));}

/* k4386 in shared-build in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_4388(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_4388,2,av);}
a=C_alloc(4);
t2=C_mutate(&lf[109] /* (set! main#translate-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:538: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_retrieve2(lf[73],C_text("main#pic-options"));
av2[3]=lf[172];
av2[4]=C_retrieve2(lf[112],C_text("main#compile-options"));
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4390 in k4386 in shared-build in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4392(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4392,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[31],C_text("main#osx")))){
if(C_truep(((C_word*)t0)[3])){
/* csc.scm:540: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[169];
av2[3]=C_retrieve2(lf[117],C_text("main#link-options"));
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
/* csc.scm:540: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[170];
av2[3]=C_retrieve2(lf[117],C_text("main#link-options"));
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}
else{
/* csc.scm:540: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[171];
av2[3]=C_retrieve2(lf[117],C_text("main#link-options"));
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k4394 in k4390 in k4386 in shared-build in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4396(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4396,2,av);}
t2=C_mutate(&lf[117] /* (set! main#link-options ...) */,t1);
t3=lf[124] /* main#shared */ =C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* generate-target-filename in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_fcall f_4413(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_4413,2,t1,t2);}
if(C_truep(C_retrieve2(lf[124],C_text("main#shared")))){
t3=C_retrieve2(lf[69],C_text("main#shared-library-extension"));
t4=C_retrieve2(lf[69],C_text("main#shared-library-extension"));
/* csc.scm:550: chicken.pathname#pathname-replace-extension */
t5=C_fast_retrieve(lf[175]);{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_retrieve2(lf[69],C_text("main#shared-library-extension"));
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
if(C_truep(C_retrieve2(lf[122],C_text("main#compile-only")))){
t3=C_retrieve2(lf[64],C_text("main#object-extension"));
t4=C_retrieve2(lf[64],C_text("main#object-extension"));
/* csc.scm:550: chicken.pathname#pathname-replace-extension */
t5=C_fast_retrieve(lf[175]);{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_retrieve2(lf[64],C_text("main#object-extension"));
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=C_retrieve2(lf[67],C_text("main#executable-extension"));
t4=C_retrieve2(lf[67],C_text("main#executable-extension"));
/* csc.scm:550: chicken.pathname#pathname-replace-extension */
t5=C_fast_retrieve(lf[175]);{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_retrieve2(lf[67],C_text("main#executable-extension"));
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}}

/* loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_fcall f_4429(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,3)))){
C_save_and_reclaim_args((void *)trf_4429,3,t0,t1,t2);}
a=C_alloc(11);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4440,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:559: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=C_retrieve2(lf[112],C_text("main#compile-options"));
av2[3]=C_retrieve2(lf[113],C_text("main#builtin-compile-options"));
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4677,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t7,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csc.scm:607: scheme#string->symbol */
t9=*((C_word*)lf[416]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}

/* k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_4440(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_4440,2,av);}
a=C_alloc(13);
t2=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4670,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4103,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[36],C_text("main#elf")))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4185,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:262: chicken.string#conc */
t8=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[251];
av2[3]=C_retrieve2(lf[106],C_text("main#library-dir"));
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
if(C_truep(C_retrieve2(lf[35],C_text("main#aix")))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4209,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:270: chicken.string#conc */
t8=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[252];
av2[3]=C_retrieve2(lf[106],C_text("main#library-dir"));
av2[4]=lf[253];
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4216,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:272: chicken.string#conc */
t8=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[254];
av2[3]=C_retrieve2(lf[106],C_text("main#library-dir"));
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}}}

/* k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4444(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_4444,2,av);}
a=C_alloc(10);
t2=C_mutate(&lf[117] /* (set! main#link-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[96],C_text("main#inquiry-only")))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4633,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[97],C_text("main#show-cflags")))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4666,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:563: compiler-options */
f_6683(t5);}
else{
t5=t4;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_4633(2,av2);}}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_4447(2,av2);}}}

/* k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,3)))){
C_save_and_reclaim((void *)f_4447,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[84],C_text("main#scheme-files"))))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4559,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_nullp(C_retrieve2(lf[85],C_text("main#c-files")));
t5=(C_truep(t4)?C_i_nullp(C_retrieve2(lf[89],C_text("main#object-files"))):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4583,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[105],C_text("main#show-debugging-help")))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4593,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4597,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:574: cons* */
f_2941(t8,C_retrieve2(lf[56],C_text("main#translator")),C_a_i_list(&a,2,lf[221],C_retrieve2(lf[109],C_text("main#translate-options"))));}
else{
/* csc.scm:575: stop */
f_3817(t3,lf[220],C_SCHEME_END_OF_LIST);}}
else{
t6=t3;{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_4559(2,av2);}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4606,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(C_retrieve2(lf[124],C_text("main#shared")))?C_i_not(C_retrieve2(lf[95],C_text("main#embedded"))):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_a_i_cons(&a,2,lf[236],C_retrieve2(lf[109],C_text("main#translate-options")));
t6=C_mutate(&lf[109] /* (set! main#translate-options ...) */,t5);
t7=t3;
f_4606(t7,t6);}
else{
t5=t3;
f_4606(t5,C_SCHEME_UNDEFINED);}}}

/* k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4450(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_4450,2,av);}
a=C_alloc(18);
if(C_truep(C_retrieve2(lf[121],C_text("main#translate-only")))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=t2;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6411,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_retrieve2(lf[85],C_text("main#c-files"));
t8=C_i_check_list_2(C_retrieve2(lf[85],C_text("main#c-files")),lf[176]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6497,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6660,a[2]=t11,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_6660(t13,t9,C_retrieve2(lf[85],C_text("main#c-files")));}}

/* k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_4456(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_4456,2,av);}
a=C_alloc(15);
if(C_truep(C_retrieve2(lf[122],C_text("main#compile-only")))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(C_retrieve2(lf[92],C_text("main#linked-extensions"))))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4549,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4553,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_retrieve2(lf[128],C_text("main#find-object-file"));
t6=C_retrieve2(lf[92],C_text("main#linked-extensions"));
t7=C_retrieve2(lf[92],C_text("main#linked-extensions"));
t8=C_i_noop2(C_retrieve2(lf[92],C_text("main#linked-extensions")),C_SCHEME_UNDEFINED);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3170,a[2]=t5,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_3170(t12,t4,C_retrieve2(lf[92],C_text("main#linked-extensions")));}
else{
t3=t2;
f_4462(t3,C_SCHEME_UNDEFINED);}}}

/* k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_fcall f_4462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,4)))){
C_save_and_reclaim_args((void *)trf_4462,2,t0,t1);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4465,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_member(C_retrieve2(lf[118],C_text("main#target-filename")),C_retrieve2(lf[84],C_text("main#scheme-files"))))){
t3=*((C_word*)lf[39]+1);
t4=*((C_word*)lf[39]+1);
t5=C_i_check_port_2(*((C_word*)lf[39]+1),C_fix(2),C_SCHEME_TRUE,lf[40]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4477,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:594: ##sys#print */
t7=*((C_word*)lf[44]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[204];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[39]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_4465(2,av2);}}}

/* k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_4465(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_4465,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6741,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[89],C_text("main#object-files"));
t5=C_retrieve2(lf[90],C_text("main#generated-object-files"));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7045,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_7045(t9,t3,C_retrieve2(lf[89],C_text("main#object-files")),C_retrieve2(lf[89],C_text("main#object-files")));}

/* k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_4477(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_4477,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:594: ##sys#print */
t3=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_retrieve2(lf[118],C_text("main#target-filename"));
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_4480(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_4480,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:594: ##sys#print */
t3=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[203];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_4483(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_4483,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:594: ##sys#print */
t3=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_retrieve2(lf[118],C_text("main#target-filename"));
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_4486(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_4486,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:594: ##sys#print */
t3=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[202];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_4489(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4489,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4492,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:594: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[42]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[42]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_4492(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4492,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4499,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:598: chicken.base#open-output-string */
t3=C_fast_retrieve(lf[181]);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in ... */
static void C_ccall f_4499(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4499,2,av);}
a=C_alloc(5);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_fix(2),C_SCHEME_TRUE,lf[177]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_mk_bool(C_WINDOWS_SHELL))){
/* csc.scm:598: ##sys#print */
t6=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[200];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
/* csc.scm:598: ##sys#print */
t6=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[201];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}

/* k4503 in k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in ... */
static void C_ccall f_4505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4505,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:598: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[42]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[42]+1);
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* k4506 in k4503 in k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in ... */
static void C_ccall f_4508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_4508,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_mk_bool(C_WINDOWS_SHELL))){
t3=C_retrieve2(lf[54],C_text("main#quotewrap-no-slash-trans"));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f8590,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=t4;
t6=C_retrieve2(lf[118],C_text("main#target-filename"));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8662,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: chicken.pathname#normalize-pathname */
t8=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=C_retrieve2(lf[118],C_text("main#target-filename"));
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t3=C_retrieve2(lf[50],C_text("main#quotewrap"));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f8594,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:598: g1071 */
t5=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_retrieve2(lf[118],C_text("main#target-filename"));
f_3866(3,av2);}}}

/* k4509 in k4506 in k4503 in k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in ... */
static void C_ccall f_4511(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4511,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:598: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[42]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[42]+1);
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* k4512 in k4509 in k4506 in k4503 in k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in ... */
static void C_ccall f_4514(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_4514,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(C_mk_bool(C_WINDOWS_SHELL))?C_retrieve2(lf[54],C_text("main#quotewrap-no-slash-trans")):C_retrieve2(lf[50],C_text("main#quotewrap")));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4527,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4531,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:602: scheme#string-append */
t7=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=C_retrieve2(lf[118],C_text("main#target-filename"));
av2[3]=lf[199];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k4515 in k4512 in k4509 in k4506 in k4503 in k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in ... */
static void C_ccall f_4517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4517,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:598: chicken.base#get-output-string */
t3=C_fast_retrieve(lf[178]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4518 in k4515 in k4512 in k4509 in k4506 in k4503 in k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in ... */
static void C_ccall f_4520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4520,2,av);}
/* csc.scm:597: command */
f_7467(((C_word*)t0)[2],t1);}

/* k4525 in k4512 in k4509 in k4506 in k4503 in k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in ... */
static void C_ccall f_4527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4527,2,av);}
/* csc.scm:598: ##sys#print */
t2=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4529 in k4512 in k4509 in k4506 in k4503 in k4497 in k4490 in k4487 in k4484 in k4481 in k4478 in k4475 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in ... */
static void C_ccall f_4531(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4531,2,av);}
/* csc.scm:598: g1073 */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4547 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_ccall f_4549(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4549,2,av);}
t2=C_mutate(&lf[89] /* (set! main#object-files ...) */,t1);
t3=((C_word*)t0)[2];
f_4462(t3,t2);}

/* k4551 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_ccall f_4553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4553,2,av);}
/* csc.scm:592: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_retrieve2(lf[89],C_text("main#object-files"));
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4557 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4559,2,av);}
a=C_alloc(5);
if(C_truep(C_retrieve2(lf[118],C_text("main#target-filename")))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
f_4450(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_nullp(C_retrieve2(lf[85],C_text("main#c-files")));
t4=(C_truep(t3)?C_retrieve2(lf[89],C_text("main#object-files")):C_retrieve2(lf[85],C_text("main#c-files")));
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3283,tmp=(C_word)a,a+=2,tmp);
t6=(
  f_3283(t4)
);
/* csc.scm:578: generate-target-filename */
f_4413(t2,t6);}}

/* k4564 in k4557 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_4566(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4566,2,av);}
t2=C_mutate(&lf[118] /* (set! main#target-filename ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
f_4450(2,av2);}}

/* k4581 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4583(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4583,2,av);}
/* csc.scm:575: stop */
f_3817(((C_word*)t0)[2],lf[220],C_SCHEME_END_OF_LIST);}

/* k4591 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4593,2,av);}
/* csc.scm:572: command */
f_7467(((C_word*)t0)[2],t1);}

/* k4595 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4597(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4597,2,av);}
/* csc.scm:573: chicken.string#string-intersperse */
t2=C_fast_retrieve(lf[136]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_fcall f_4606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_4606,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[118],C_text("main#target-filename")))){
t3=t2;
f_4609(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4616,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[84],C_text("main#scheme-files"));
t5=C_i_car(C_retrieve2(lf[84],C_text("main#scheme-files")));
/* csc.scm:585: generate-target-filename */
f_4413(t3,t5);}}

/* k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_fcall f_4609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_4609,2,t0,t1);}
a=C_alloc(5);
t2=C_retrieve2(lf[84],C_text("main#scheme-files"));
t3=C_i_check_list_2(C_retrieve2(lf[84],C_text("main#scheme-files")),lf[176]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6386,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6386(t7,((C_word*)t0)[2],C_retrieve2(lf[84],C_text("main#scheme-files")));}

/* k4614 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_4616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4616,2,av);}
t2=C_mutate(&lf[118] /* (set! main#target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_4609(t3,t2);}

/* k4631 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4633(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_4633,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[98],C_text("main#show-ldflags")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4659,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:564: linker-options */
f_7170(t3);}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_4636(2,av2);}}}

/* k4634 in k4631 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4636(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_4636,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4639,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[99],C_text("main#show-libs")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4652,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:565: linker-libraries */
f_7223(t3);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8616,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:566: scheme#newline */
t4=*((C_word*)lf[237]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4637 in k4634 in k4631 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_4639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4639,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:566: scheme#newline */
t3=*((C_word*)lf[237]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4640 in k4637 in k4634 in k4631 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_ccall f_4642(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4642,2,av);}
/* csc.scm:567: chicken.base#exit */
t2=C_fast_retrieve(lf[41]);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4650 in k4634 in k4631 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_4652(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4652,2,av);}
/* csc.scm:565: chicken.base#print* */
t2=*((C_word*)lf[238]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4657 in k4631 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4659,2,av);}
/* csc.scm:564: chicken.base#print* */
t2=*((C_word*)lf[238]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4664 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4666(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4666,2,av);}
/* csc.scm:563: chicken.base#print* */
t2=*((C_word*)lf[238]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4668 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4670(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4670,2,av);}
/* csc.scm:560: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[117],C_text("main#link-options"));
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_4677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,4)))){
C_save_and_reclaim((void *)f_4677,2,av);}
a=C_alloc(20);
t2=t1;
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_eqp(t3,lf[255]);
t6=(C_truep(t5)?t5:C_eqp(t3,lf[256]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4692,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4310,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=C_mpointer(&a,(void*)C_CSC_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
t7=C_eqp(t3,lf[261]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4704,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4711,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:613: chicken.platform#chicken-version */
t10=C_fast_retrieve(lf[262]);{
C_word *av2=av;
av2[0]=t10;
av2[1]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t8=C_eqp(t3,lf[263]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4720,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4727,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:616: chicken.base#open-output-string */
t11=C_fast_retrieve(lf[181]);{
C_word *av2=av;
av2[0]=t11;
av2[1]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t9=C_eqp(t3,lf[265]);
if(C_truep(t9)){
t10=lf[93] /* main#cpp-mode */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[31],C_text("main#osx")))){
t11=C_a_i_cons(&a,2,lf[266],C_retrieve2(lf[112],C_text("main#compile-options")));
t12=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t11);
/* csc.scm:847: loop */
t13=((C_word*)((C_word*)t0)[2])[1];
f_4429(t13,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
/* csc.scm:847: loop */
t11=((C_word*)((C_word*)t0)[2])[1];
f_4429(t11,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t10=C_eqp(t3,lf[267]);
if(C_truep(t10)){
t11=lf[94] /* main#objc-mode */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t12=((C_word*)((C_word*)t0)[2])[1];
f_4429(t12,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t11=C_eqp(t3,lf[268]);
if(C_truep(t11)){
t12=C_a_i_cons(&a,2,lf[269],C_retrieve2(lf[109],C_text("main#translate-options")));
t13=C_mutate(&lf[109] /* (set! main#translate-options ...) */,t12);
t14=lf[125] /* main#static */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t15=((C_word*)((C_word*)t0)[2])[1];
f_4429(t15,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t12=C_eqp(t3,lf[270]);
if(C_truep(t12)){
t13=lf[96] /* main#inquiry-only */ =C_SCHEME_TRUE;;
t14=lf[97] /* main#show-cflags */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t15=((C_word*)((C_word*)t0)[2])[1];
f_4429(t15,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t13=C_eqp(t3,lf[271]);
if(C_truep(t13)){
t14=lf[96] /* main#inquiry-only */ =C_SCHEME_TRUE;;
t15=lf[98] /* main#show-ldflags */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_4429(t16,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t14=C_eqp(t3,lf[272]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4799,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:632: chicken.base#print */
t16=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t16;
av2[1]=t15;
av2[2]=C_retrieve2(lf[57],C_text("main#compiler"));
((C_proc)(void*)(*((C_word*)t16+1)))(3,av2);}}
else{
t15=C_eqp(t3,lf[273]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4811,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:633: chicken.base#print */
t17=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t17;
av2[1]=t16;
av2[2]=C_retrieve2(lf[58],C_text("main#c++-compiler"));
((C_proc)(void*)(*((C_word*)t17+1)))(3,av2);}}
else{
t16=C_eqp(t3,lf[274]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4823,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:634: chicken.base#print */
t18=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t18;
av2[1]=t17;
av2[2]=C_retrieve2(lf[60],C_text("main#linker"));
((C_proc)(void*)(*((C_word*)t18+1)))(3,av2);}}
else{
t17=C_eqp(t3,lf[275]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4835,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:635: chicken.base#print */
t19=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t19;
av2[1]=t18;
av2[2]=C_retrieve2(lf[55],C_text("main#home"));
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}
else{
t18=C_eqp(t3,lf[276]);
if(C_truep(t18)){
t19=lf[96] /* main#inquiry-only */ =C_SCHEME_TRUE;;
t20=lf[99] /* main#show-libs */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t21=((C_word*)((C_word*)t0)[2])[1];
f_4429(t21,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t19=C_eqp(t3,lf[277]);
t20=(C_truep(t19)?t19:C_eqp(t3,lf[278]));
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_numberp(C_retrieve2(lf[119],C_text("main#verbose"))))){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4873,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:641: cons* */
f_2941(t22,lf[281],C_a_i_list(&a,2,lf[282],C_retrieve2(lf[112],C_text("main#compile-options"))));}
else{
t22=t21;
f_4858(t22,C_SCHEME_UNDEFINED);}}
else{
t21=C_eqp(t3,lf[283]);
t22=(C_truep(t21)?t21:C_eqp(t3,lf[284]));
if(C_truep(t22)){
t23=C_a_i_cons(&a,2,lf[285],C_retrieve2(lf[112],C_text("main#compile-options")));
t24=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t23);
/* csc.scm:649: t-options */
f_4350(t4,C_a_i_list(&a,1,lf[286]));}
else{
t23=C_eqp(t3,lf[287]);
t24=(C_truep(t23)?t23:C_eqp(t3,lf[288]));
if(C_truep(t24)){
t25=lf[121] /* main#translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:652: t-options */
f_4350(t4,C_a_i_list(&a,1,lf[289]));}
else{
t25=C_eqp(t3,lf[290]);
t26=(C_truep(t25)?t25:C_eqp(t3,lf[291]));
if(C_truep(t26)){
t27=lf[121] /* main#translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:655: t-options */
f_4350(t4,C_a_i_list(&a,1,lf[292]));}
else{
t27=C_eqp(t3,lf[293]);
if(C_truep(t27)){
t28=lf[120] /* main#keep-files */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t29=((C_word*)((C_word*)t0)[2])[1];
f_4429(t29,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t28=C_eqp(t3,lf[294]);
if(C_truep(t28)){
t29=lf[122] /* main#compile-only */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t30=((C_word*)((C_word*)t0)[2])[1];
f_4429(t30,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t29=C_eqp(t3,lf[295]);
if(C_truep(t29)){
t30=lf[121] /* main#translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t31=((C_word*)((C_word*)t0)[2])[1];
f_4429(t31,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t30=C_eqp(t3,lf[296]);
t31=(C_truep(t30)?t30:C_eqp(t3,lf[297]));
if(C_truep(t31)){
t32=lf[95] /* main#embedded */ =C_SCHEME_TRUE;;
t33=C_a_i_cons(&a,2,lf[298],C_retrieve2(lf[112],C_text("main#compile-options")));
t34=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t33);
/* csc.scm:847: loop */
t35=((C_word*)((C_word*)t0)[2])[1];
f_4429(t35,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t32=C_eqp(t3,lf[299]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:663: check */
f_4357(t33,t2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t33=C_eqp(t3,lf[302]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:669: check */
f_4357(t34,t2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t34=C_eqp(t3,lf[303]);
t35=(C_truep(t34)?t34:C_eqp(t3,lf[304]));
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:673: check */
f_4357(t36,t2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t36=C_eqp(t3,lf[306]);
if(C_truep(t36)){
t37=C_a_i_cons(&a,2,lf[307],C_retrieve2(lf[112],C_text("main#compile-options")));
t38=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t37);
/* csc.scm:847: loop */
t39=((C_word*)((C_word*)t0)[2])[1];
f_4429(t39,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t37=C_eqp(t3,lf[308]);
if(C_truep(t37)){
t38=lf[104] /* main#ignore-repository */ =C_SCHEME_TRUE;;
/* csc.scm:680: t-options */
f_4350(t4,C_a_i_list(&a,1,((C_word*)t0)[7]));}
else{
t38=C_eqp(t3,lf[309]);
if(C_truep(t38)){
t39=C_set_block_item(lf[130] /* ##sys#setup-mode */,0,C_SCHEME_TRUE);
/* csc.scm:683: t-options */
f_4350(t4,C_a_i_list(&a,1,((C_word*)t0)[7]));}
else{
t39=C_eqp(t3,lf[310]);
if(C_truep(t39)){
t40=lf[74] /* main#generate-manifest */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t41=((C_word*)((C_word*)t0)[2])[1];
f_4429(t41,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t40=C_eqp(t3,lf[311]);
if(C_truep(t40)){
t41=lf[101] /* main#gui */ =C_SCHEME_TRUE;;
t42=C_a_i_cons(&a,2,lf[312],C_retrieve2(lf[112],C_text("main#compile-options")));
t43=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t42);
if(C_truep(C_retrieve2(lf[29],C_text("main#mingw")))){
t44=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:691: chicken.pathname#make-pathname */
t45=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t45;
av2[1]=t44;
av2[2]=C_retrieve2(lf[20],C_text("main#host-sharedir"));
av2[3]=lf[317];
av2[4]=C_retrieve2(lf[64],C_text("main#object-extension"));
((C_proc)(void*)(*((C_word*)t45+1)))(5,av2);}}
else{
/* csc.scm:847: loop */
t44=((C_word*)((C_word*)t0)[2])[1];
f_4429(t44,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t41=C_eqp(t3,lf[318]);
if(C_truep(t41)){
t42=lf[102] /* main#deployed */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t43=((C_word*)((C_word*)t0)[2])[1];
f_4429(t43,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t42=C_eqp(t3,lf[319]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5104,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:701: check */
f_4357(t43,t2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t43=C_eqp(t3,lf[321]);
t44=(C_truep(t43)?t43:C_eqp(t3,lf[322]));
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5131,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:706: check */
f_4357(t45,t2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t45=C_eqp(t3,lf[323]);
t46=(C_truep(t45)?t45:C_eqp(t3,lf[324]));
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5152,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:710: cons* */
f_2941(t47,lf[325],C_a_i_list(&a,2,lf[326],((C_word*)((C_word*)t0)[4])[1]));}
else{
t47=C_eqp(t3,lf[327]);
if(C_truep(t47)){
t48=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5162,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:711: cons* */
f_2941(t48,lf[328],C_a_i_list(&a,2,lf[329],((C_word*)((C_word*)t0)[4])[1]));}
else{
t48=C_eqp(t3,lf[330]);
if(C_truep(t48)){
t49=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5172,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:712: cons* */
f_2941(t49,lf[331],C_a_i_list(&a,2,lf[332],((C_word*)((C_word*)t0)[4])[1]));}
else{
t49=C_eqp(t3,lf[333]);
if(C_truep(t49)){
t50=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5182,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:713: cons* */
f_2941(t50,lf[334],C_a_i_list(&a,2,lf[335],((C_word*)((C_word*)t0)[4])[1]));}
else{
t50=C_eqp(t3,lf[336]);
if(C_truep(t50)){
t51=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5192,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:714: cons* */
f_2941(t51,lf[337],C_a_i_list(&a,2,lf[338],((C_word*)((C_word*)t0)[4])[1]));}
else{
t51=C_eqp(t3,lf[339]);
if(C_truep(t51)){
t52=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:716: cons* */
f_2941(t52,lf[340],C_a_i_list(&a,2,lf[341],((C_word*)((C_word*)t0)[4])[1]));}
else{
t52=C_eqp(t3,lf[342]);
if(C_truep(t52)){
t53=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5212,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:717: cons* */
f_2941(t53,lf[343],C_a_i_list(&a,2,lf[344],((C_word*)((C_word*)t0)[4])[1]));}
else{
t53=C_eqp(t3,lf[345]);
if(C_truep(t53)){
t54=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5222,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:718: cons* */
f_2941(t54,lf[346],C_a_i_list(&a,2,lf[347],((C_word*)((C_word*)t0)[4])[1]));}
else{
t54=C_eqp(t3,lf[348]);
if(C_truep(t54)){
t55=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5232,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:719: cons* */
f_2941(t55,lf[349],C_a_i_list(&a,2,lf[350],((C_word*)((C_word*)t0)[4])[1]));}
else{
t55=C_eqp(t3,lf[351]);
if(C_truep(t55)){
t56=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:720: cons* */
f_2941(t56,lf[352],C_a_i_list(&a,2,lf[353],((C_word*)((C_word*)t0)[4])[1]));}
else{
t56=C_eqp(t3,lf[354]);
if(C_truep(t56)){
t57=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5251,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:722: check */
f_4357(t57,t2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t57=C_eqp(t3,lf[355]);
if(C_truep(t57)){
t58=lf[119] /* main#verbose */ =C_SCHEME_TRUE;;
t59=lf[100] /* main#dry-run */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t60=((C_word*)((C_word*)t0)[2])[1];
f_4429(t60,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t58=C_eqp(t3,lf[356]);
t59=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5293,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],a[9]=t2,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t58)){
t60=t59;
f_5293(t60,t58);}
else{
t60=C_eqp(t3,lf[414]);
t61=t59;
f_5293(t61,(C_truep(t60)?t60:C_eqp(t3,lf[415])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4678 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4680(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4680,2,av);}
/* csc.scm:847: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4429(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k4690 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4692,2,av);}
/* csc.scm:611: chicken.base#exit */
t2=C_fast_retrieve(lf[41]);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4702 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4704,2,av);}
/* csc.scm:614: chicken.base#exit */
t2=C_fast_retrieve(lf[41]);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4709 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4711(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4711,2,av);}
/* csc.scm:613: chicken.base#print */
t2=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4718 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4720,2,av);}
/* csc.scm:617: chicken.base#exit */
t2=C_fast_retrieve(lf[41]);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4725 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4727,2,av);}
a=C_alloc(5);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_fix(2),C_SCHEME_TRUE,lf[177]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:616: ##sys#print */
t6=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_retrieve2(lf[56],C_text("main#translator"));
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4731 in k4725 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4733,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:616: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[42]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[42]+1);
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* k4734 in k4731 in k4725 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4736(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_4736,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:616: ##sys#print */
t3=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[264];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4737 in k4734 in k4731 in k4725 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_4739(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4739,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4742,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:616: chicken.base#get-output-string */
t3=C_fast_retrieve(lf[178]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4740 in k4737 in k4734 in k4731 in k4725 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_ccall f_4742(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4742,2,av);}
/* csc.scm:616: chicken.process#system */
t2=C_fast_retrieve(lf[156]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4797 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4799,2,av);}
/* csc.scm:632: chicken.base#exit */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4809 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4811(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4811,2,av);}
/* csc.scm:633: chicken.base#exit */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4821 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4823,2,av);}
/* csc.scm:634: chicken.base#exit */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4833 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4835(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4835,2,av);}
/* csc.scm:635: chicken.base#exit */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4856 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_fcall f_4858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_4858,2,t0,t1);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:643: t-options */
f_4350(t2,C_a_i_list(&a,1,lf[279]));}

/* k4859 in k4856 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4861,2,av);}
if(C_truep(C_retrieve2(lf[119],C_text("main#verbose")))){
t2=lf[119] /* main#verbose */ =C_fix(2);;
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4429(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=lf[119] /* main#verbose */ =C_SCHEME_TRUE;;
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4429(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4871 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4873(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_4873,2,av);}
a=C_alloc(3);
t2=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t1);
t3=C_a_i_cons(&a,2,lf[280],C_retrieve2(lf[117],C_text("main#link-options")));
t4=C_mutate(&lf[117] /* (set! main#link-options ...) */,t3);
t5=((C_word*)t0)[2];
f_4858(t5,t4);}

/* k4961 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4963(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_4963,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:664: t-options */
f_4350(t2,C_a_i_list(&a,2,lf[301],t3));}

/* k4964 in k4961 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_4966(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_4966,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4978,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:666: chicken.string#string-split */
t5=C_fast_retrieve(lf[240]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[300];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k4968 in k4964 in k4961 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4970,2,av);}
t2=C_mutate(&lf[92] /* (set! main#linked-extensions ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:847: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4429(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k4976 in k4964 in k4961 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_4978(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4978,2,av);}
/* csc.scm:666: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[92],C_text("main#linked-extensions"));
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4993 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_4995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4995,2,av);}
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(&lf[106] /* (set! main#library-dir ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:847: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4429(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5013 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_5015,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:674: t-options */
f_4350(t2,C_a_i_list(&a,2,lf[305],t3));}

/* k5016 in k5013 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5018(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5018,2,av);}
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:847: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4429(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5082 in k5086 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5084(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5084,2,av);}
t2=C_mutate(&lf[117] /* (set! main#link-options ...) */,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4429(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k5086 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
C_save_and_reclaim((void *)f_5088,2,av);}
a=C_alloc(20);
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[89],C_text("main#object-files")));
t3=C_mutate(&lf[89] /* (set! main#object-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:696: cons* */
f_2941(t4,lf[313],C_a_i_list(&a,4,lf[314],lf[315],lf[316],C_retrieve2(lf[117],C_text("main#link-options"))));}

/* k5102 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5104(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_5104,2,av);}
a=C_alloc(11);
if(C_truep(C_retrieve2(lf[31],C_text("main#osx")))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:703: cons* */
f_2941(t2,lf[320],C_a_i_list(&a,2,t3,C_retrieve2(lf[117],C_text("main#link-options"))));}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:847: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4429(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}}

/* k5113 in k5102 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5115,2,av);}
t2=C_mutate(&lf[117] /* (set! main#link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:847: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4429(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5129 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5131(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5131,2,av);}
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=C_mutate(&lf[118] /* (set! main#target-filename ...) */,t2);
/* csc.scm:847: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4429(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5150 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5152,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5160 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5162(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5162,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5170 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5172(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5172,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5180 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5182(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5182,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5190 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5192,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5200 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5202,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5210 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5212(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5212,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5220 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5222,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5230 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5232,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5240 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5242,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5249 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_5251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_5251,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:723: t-options */
f_4350(t2,C_a_i_list(&a,2,((C_word*)t0)[6],t3));}

/* k5252 in k5249 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5254(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5254,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* ##sys#string->list */
t4=C_fast_retrieve(lf[149]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5264 in k5252 in k5249 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_5266(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5266,2,av);}
if(C_truep(C_u_i_memq(C_make_character(104),t1))){
t2=lf[105] /* main#show-debugging-help */ =C_SCHEME_TRUE;;
t3=lf[121] /* main#translate-only */ =C_SCHEME_TRUE;;
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:847: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4429(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:847: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4429(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}}

/* k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_fcall f_5293(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,4)))){
C_save_and_reclaim_args((void *)trf_5293,2,t0,t1);}
a=C_alloc(10);
if(C_truep(t1)){
/* csc.scm:732: shared-build */
f_4383(((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[357]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[358]));
if(C_truep(t3)){
/* csc.scm:734: shared-build */
f_4383(((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5317,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:736: check */
f_4357(t5,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5334,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:740: check */
f_4357(t6,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[361]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5351,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:744: check */
f_4357(t7,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[362]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5368,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:748: check */
f_4357(t8,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[363]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5385,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:752: check */
f_4357(t9,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[365]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5406,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:755: check */
f_4357(t10,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[366]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5432,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t12=C_a_i_list1(&a,1,lf[367]);
/* csc.scm:759: scheme#append */
t13=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t13;
av2[1]=t11;
av2[2]=C_retrieve2(lf[117],C_text("main#link-options"));
av2[3]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(4,av2);}}
else{
t11=C_eqp(((C_word*)t0)[4],lf[368]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5445,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:761: check */
f_4357(t12,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[369]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5470,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:765: check */
f_4357(t13,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t13)){
/* csc.scm:847: loop */
t14=((C_word*)((C_word*)t0)[6])[1];
f_4429(t14,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5525,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:773: check */
f_4357(t15,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[377]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5545,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:777: check */
f_4357(t16,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[379]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5566,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:781: scheme#append */
t18=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t18;
av2[1]=t17;
av2[2]=C_retrieve2(lf[84],C_text("main#scheme-files"));
av2[3]=lf[381];
((C_proc)(void*)(*((C_word*)t18+1)))(4,av2);}}
else{
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5576,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t18=C_eqp(((C_word*)t0)[9],lf[413]);
if(C_truep(t18)){
t19=lf[123] /* main#to-stdout */ =C_SCHEME_TRUE;;
t20=lf[121] /* main#translate-only */ =C_SCHEME_TRUE;;
t21=t17;
f_5576(t21,t20);}
else{
t19=t17;
f_5576(t19,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}}}

/* k5315 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5317,2,av);}
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(&lf[56] /* (set! main#translator ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:847: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4429(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5332 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5334,2,av);}
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(&lf[57] /* (set! main#compiler ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:847: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4429(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5349 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5351(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5351,2,av);}
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(&lf[58] /* (set! main#c++-compiler ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:847: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4429(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5366 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5368,2,av);}
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(&lf[60] /* (set! main#linker ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:847: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4429(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5383 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5385(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_5385,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:753: cons* */
f_2941(t2,lf[364],C_a_i_list(&a,2,t3,t4));}

/* k5387 in k5383 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_5389(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5389,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5404 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_5406,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5418,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:756: chicken.string#string-split */
t5=C_fast_retrieve(lf[240]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5408 in k5404 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_5410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5410,2,av);}
t2=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:847: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4429(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5416 in k5404 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_5418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5418,2,av);}
/* csc.scm:756: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[112],C_text("main#compile-options"));
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5430 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5432(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5432,2,av);}
t2=C_mutate(&lf[117] /* (set! main#link-options ...) */,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4429(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k5443 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5445(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_5445,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5457,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:762: chicken.string#string-split */
t5=C_fast_retrieve(lf[240]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5447 in k5443 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_5449(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5449,2,av);}
t2=C_mutate(&lf[117] /* (set! main#link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:847: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4429(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5455 in k5443 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_5457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5457,2,av);}
/* csc.scm:762: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[117],C_text("main#link-options"));
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5468 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5470(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_5470,2,av);}
a=C_alloc(8);
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(&lf[103] /* (set! main#rpath ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5500,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:767: chicken.platform#build-platform */
t6=C_fast_retrieve(lf[373]);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k5482 in k5468 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_fcall f_5484(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_5484,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5496,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:769: scheme#string-append */
t4=*((C_word*)lf[76]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[370];
av2[3]=C_retrieve2(lf[103],C_text("main#rpath"));
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:847: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4429(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}}

/* k5486 in k5482 in k5468 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_5488(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5488,2,av);}
t2=C_mutate(&lf[117] /* (set! main#link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:847: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4429(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5494 in k5482 in k5468 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_5496(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_5496,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* csc.scm:769: scheme#append */
t3=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[117],C_text("main#link-options"));
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5498 in k5468 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_5500(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5500,2,av);}
if(C_truep((C_truep(C_eqp(t1,lf[371]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[372]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t2=C_i_not(C_retrieve2(lf[29],C_text("main#mingw")));
t3=((C_word*)t0)[2];
f_5484(t3,(C_truep(t2)?C_i_not(C_retrieve2(lf[31],C_text("main#osx"))):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
f_5484(t2,C_SCHEME_FALSE);}}

/* k5523 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5525(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_5525,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:774: t-options */
f_4350(t2,C_a_i_list(&a,2,lf[376],t3));}

/* k5526 in k5523 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_5528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5528,2,av);}
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:847: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4429(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5543 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_5545,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:778: t-options */
f_4350(t2,C_a_i_list(&a,2,lf[378],t3));}

/* k5546 in k5543 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_5548(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5548,2,av);}
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:847: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4429(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5564 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_5566(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_5566,2,av);}
a=C_alloc(5);
t2=C_mutate(&lf[84] /* (set! main#scheme-files ...) */,t1);
if(C_truep(C_retrieve2(lf[118],C_text("main#target-filename")))){
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4429(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:783: chicken.pathname#make-pathname */
t4=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[380];
av2[4]=C_retrieve2(lf[67],C_text("main#executable-extension"));
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* k5571 in k5564 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_5573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5573,2,av);}
t2=C_mutate(&lf[118] /* (set! main#target-filename ...) */,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4429(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_fcall f_5576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_5576,2,t0,t1);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_truep(C_eqp(((C_word*)t0)[2],lf[411]))?C_SCHEME_TRUE:(C_truep(C_eqp(((C_word*)t0)[2],lf[412]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=C_mutate(&lf[115] /* (set! main#compilation-optimization-options ...) */,C_retrieve2(lf[79],C_text("main#best-compilation-optimization-options")));
t4=C_mutate(&lf[116] /* (set! main#linking-optimization-options ...) */,C_retrieve2(lf[81],C_text("main#best-linking-optimization-options")));
t5=t2;
f_5579(t5,t4);}
else{
t3=t2;
f_5579(t3,C_SCHEME_UNDEFINED);}}

/* k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_fcall f_5579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,4)))){
C_save_and_reclaim_args((void *)trf_5579,2,t0,t1);}
a=C_alloc(12);
t2=C_i_assq(((C_word*)t0)[2],lf[382]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(
/* csc.scm:791: g1218 */
  f_5586(C_a_i(&a,3),t3,t2)
);
/* csc.scm:847: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4429(t5,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}
else{
if(C_truep(C_i_memq(((C_word*)t0)[2],lf[383]))){
/* csc.scm:792: t-options */
f_4350(((C_word*)t0)[7],C_a_i_list(&a,1,((C_word*)t0)[8]));}
else{
if(C_truep(C_i_memq(((C_word*)t0)[2],lf[384]))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:794: check */
f_4357(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5633,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t4=C_block_size(((C_word*)t0)[8]);
if(C_truep(C_fixnum_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6008,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:797: scheme#substring */
t6=*((C_word*)lf[389]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[8];
av2[3]=C_fix(0);
av2[4]=C_fix(2);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t5=t3;
f_5633(t5,C_SCHEME_FALSE);}}}}}

/* g1218 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static C_word C_fcall f_5586(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;{}
t2=C_i_cadr(t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
return(t4);}

/* k5614 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_5616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_5616,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:795: t-options */
f_4350(t2,C_a_i_list(&a,2,((C_word*)t0)[6],t3));}

/* k5617 in k5614 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_ccall f_5619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5619,2,av);}
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:847: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4429(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_fcall f_5633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_5633,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
/* csc.scm:798: t-options */
f_4350(((C_word*)t0)[3],C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5642,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_block_size(((C_word*)t0)[4]);
if(C_truep(C_fixnum_greaterp(t3,C_fix(1)))){
t4=C_i_string_ref(((C_word*)t0)[4],C_fix(0));
t5=t2;
f_5642(t5,C_u_i_char_equalp(C_make_character(45),t4));}
else{
t4=t2;
f_5642(t4,C_SCHEME_FALSE);}}}

/* k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_fcall f_5642(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,4)))){
C_save_and_reclaim_args((void *)trf_5642,2,t0,t1);}
a=C_alloc(11);
if(C_truep(t1)){
t2=C_i_string_ref(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_u_i_char_equalp(C_make_character(76),t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5652,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=C_i_string_ref(((C_word*)t0)[2],C_fix(2));
if(C_truep(C_u_i_char_whitespacep(t4))){
/* csc.scm:803: chicken.base#error */
t5=*((C_word*)lf[385]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[386];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t3;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_5652(2,av2);}}}
else{
t3=C_i_string_ref(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_u_i_char_equalp(C_make_character(73),t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5679,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=C_i_string_ref(((C_word*)t0)[2],C_fix(2));
if(C_truep(C_u_i_char_whitespacep(t5))){
/* csc.scm:807: chicken.base#error */
t6=*((C_word*)lf[385]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t4;
av2[2]=lf[387];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t6=t4;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_5679(2,av2);}}}
else{
t4=C_i_string_ref(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_u_i_char_equalp(C_make_character(68),t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:810: scheme#substring */
t6=*((C_word*)lf[389]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(2);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t5=C_i_string_ref(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_u_i_char_equalp(C_make_character(70),t5))){
if(C_truep(C_retrieve2(lf[31],C_text("main#osx")))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:813: scheme#append */
t8=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t6;
av2[2]=C_retrieve2(lf[112],C_text("main#compile-options"));
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
/* csc.scm:847: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4429(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1]);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=C_block_size(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t7,C_fix(3)))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5840,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:814: scheme#substring */
t9=*((C_word*)lf[389]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
av2[4]=C_fix(4);
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t8=t6;
f_5734(t8,C_SCHEME_FALSE);}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:823: chicken.file#file-exists? */
t3=C_fast_retrieve(lf[131]);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k5650 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_5652(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_5652,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[5]);
/* csc.scm:804: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=C_retrieve2(lf[117],C_text("main#link-options"));
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5654 in k5650 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_5656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5656,2,av);}
t2=C_mutate(&lf[117] /* (set! main#link-options ...) */,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4429(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k5677 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_5679(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_5679,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[5]);
/* csc.scm:808: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=C_retrieve2(lf[112],C_text("main#compile-options"));
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5681 in k5677 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_5683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5683,2,av);}
t2=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4429(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k5708 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_5710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5710,2,av);}
a=C_alloc(6);
/* csc.scm:810: t-options */
f_4350(((C_word*)t0)[3],C_a_i_list(&a,2,lf[388],t1));}

/* k5722 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_5724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5724,2,av);}
t2=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4429(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_fcall f_5734(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_5734,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[5]);
/* csc.scm:815: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=C_retrieve2(lf[117],C_text("main#link-options"));
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=C_block_size(((C_word*)t0)[5]);
if(C_truep(C_fixnum_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5823,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#string->list */
t4=C_fast_retrieve(lf[149]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* csc.scm:822: stop */
f_3817(((C_word*)t0)[6],lf[393],C_a_i_list(&a,1,((C_word*)t0)[7]));}}}

/* k5736 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_5738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5738,2,av);}
t2=C_mutate(&lf[117] /* (set! main#link-options ...) */,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4429(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k5759 in k5817 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_5761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5761,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:847: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4429(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k5776 in k5817 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_5778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5778,2,av);}
/* csc.scm:820: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop1235 in k5817 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_fcall f_5780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_5780,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5805,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_string(&a,1,t4);
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[186]);
C_word av2[4];
av2[0]=*((C_word*)lf[186]+1);
av2[1]=t3;
av2[2]=lf[390];
av2[3]=t5;
tp(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5803 in map-loop1235 in k5817 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_5805(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5805,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5780(t6,((C_word*)t0)[5],t5);}

/* k5817 in k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_5819(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,3)))){
C_save_and_reclaim((void *)f_5819,2,av);}
a=C_alloc(21);
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5778,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5780,a[2]=t5,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5780(t11,t7,((C_word*)t0)[5]);}
else{
/* csc.scm:821: stop */
f_3817(((C_word*)t0)[6],lf[391],C_a_i_list(&a,1,((C_word*)t0)[7]));}}

/* k5821 in k5732 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_5823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,4)))){
C_save_and_reclaim((void *)f_5823,2,av);}
a=C_alloc(16);
t2=C_i_cdr(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=C_a_i_list(&a,1,C_retrieve2(lf[83],C_text("main#short-options")));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3383,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_3383(t9,t4,t5,t3);}

/* k5838 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_5840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5840,2,av);}
t2=((C_word*)t0)[2];
f_5734(t2,C_u_i_string_equal_p(lf[394],t1));}

/* k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_5852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,5)))){
C_save_and_reclaim((void *)f_5852,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5857,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:824: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5972,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[186]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[186]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[409];
tp(4,av2);}}}

/* a5856 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_5857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5857,2,av);}
/* csc.scm:824: chicken.pathname#decompose-pathname */
t2=C_fast_retrieve(lf[395]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a5862 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_5863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_5863,5,av);}
a=C_alloc(7);
if(C_truep(C_i_not(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5874,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:826: scheme#append */
t7=*((C_word*)lf[137]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t5;
av2[2]=C_retrieve2(lf[84],C_text("main#scheme-files"));
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
if(C_truep((C_truep(C_i_equalp(t4,lf[396]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[397]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5888,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:828: scheme#append */
t7=*((C_word*)lf[137]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t5;
av2[2]=C_retrieve2(lf[85],C_text("main#c-files"));
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
if(C_truep(C_i_string_ci_equal_p(t4,lf[398]))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5902,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:830: scheme#append */
t7=*((C_word*)lf[137]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t5;
av2[2]=C_retrieve2(lf[86],C_text("main#rc-files"));
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
if(C_truep((C_truep(C_i_equalp(t4,lf[399]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[400]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[401]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[402]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[403]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5915,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[31],C_text("main#osx")))){
t6=C_a_i_cons(&a,2,lf[404],C_retrieve2(lf[112],C_text("main#compile-options")));
t7=C_mutate(&lf[112] /* (set! main#compile-options ...) */,t6);
t8=t5;
f_5915(t8,t7);}
else{
t6=t5;
f_5915(t6,C_SCHEME_UNDEFINED);}}
else{
if(C_truep((C_truep(C_i_equalp(t4,lf[405]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[406]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[407]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t5=lf[94] /* main#objc-mode */ =C_SCHEME_TRUE;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5939,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:837: scheme#append */
t8=*((C_word*)lf[137]+1);{
C_word *av2=av;
av2[0]=t8;
av2[1]=t6;
av2[2]=C_retrieve2(lf[85],C_text("main#c-files"));
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t5=C_retrieve2(lf[64],C_text("main#object-extension"));
t6=C_u_i_string_equal_p(t4,C_retrieve2(lf[64],C_text("main#object-extension")));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5951,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t6)){
t8=t7;
f_5951(t8,t6);}
else{
t8=C_retrieve2(lf[65],C_text("main#library-extension"));
t9=t7;
f_5951(t9,C_u_i_string_equal_p(t4,C_retrieve2(lf[65],C_text("main#library-extension"))));}}}}}}}

/* k5872 in a5862 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_5874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5874,2,av);}
t2=C_mutate(&lf[84] /* (set! main#scheme-files ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5886 in a5862 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_5888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5888,2,av);}
t2=C_mutate(&lf[85] /* (set! main#c-files ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5900 in a5862 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_5902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5902,2,av);}
t2=C_mutate(&lf[86] /* (set! main#rc-files ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5913 in a5862 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_fcall f_5915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_5915,2,t0,t1);}
a=C_alloc(6);
t2=lf[93] /* main#cpp-mode */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:834: scheme#append */
t5=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=C_retrieve2(lf[85],C_text("main#c-files"));
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k5918 in k5913 in a5862 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_5920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5920,2,av);}
t2=C_mutate(&lf[85] /* (set! main#c-files ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5937 in a5862 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_5939(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5939,2,av);}
t2=C_mutate(&lf[85] /* (set! main#c-files ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5949 in a5862 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_fcall f_5951(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_5951,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5955,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:840: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=C_retrieve2(lf[89],C_text("main#object-files"));
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:841: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=C_retrieve2(lf[84],C_text("main#scheme-files"));
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k5953 in k5949 in a5862 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_5955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5955,2,av);}
t2=C_mutate(&lf[89] /* (set! main#object-files ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5961 in k5949 in a5862 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_5963(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5963,2,av);}
t2=C_mutate(&lf[84] /* (set! main#scheme-files ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5970 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_5972(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_5972,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5978,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csc.scm:844: chicken.file#file-exists? */
t4=C_fast_retrieve(lf[131]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5976 in k5970 in k5850 in k5640 in k5631 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_5978(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_5978,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
/* csc.scm:847: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4429(t4,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* csc.scm:846: stop */
f_3817(((C_word*)t0)[6],lf[408],C_a_i_list(&a,1,((C_word*)t0)[7]));}}

/* k6006 in k5577 in k5574 in k5291 in k4675 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_6008(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6008,2,av);}
t2=((C_word*)t0)[2];
f_5633(t2,C_u_i_string_equal_p(lf[410],t1));}

/* k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_6215(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_6215,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6218,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_member(t2,C_retrieve2(lf[85],C_text("main#c-files"))))){
/* csc.scm:864: stop */
f_3817(t3,lf[232],C_a_i_list(&a,2,((C_word*)t0)[3],t2));}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_6218(2,av2);}}}

/* k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_6218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_6218,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6255,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6259,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6263,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:868: quotewrap */
t6=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[4];
f_3866(3,av2);}}

/* k6219 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_6221(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_6221,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(C_retrieve2(lf[125],C_text("main#static")))?C_retrieve2(lf[122],C_text("main#compile-only")):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6251,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:893: chicken.pathname#pathname-replace-extension */
t5=C_fast_retrieve(lf[175]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[222];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t4=t2;
f_6224(t4,C_SCHEME_UNDEFINED);}}

/* k6222 in k6219 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_fcall f_6224(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_6224,2,t0,t1);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:895: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_retrieve2(lf[85],C_text("main#c-files"));
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6226 in k6222 in k6219 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_6228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6228,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[85] /* (set! main#c-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6232,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:896: scheme#append */
t5=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=C_retrieve2(lf[87],C_text("main#generated-c-files"));
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k6230 in k6226 in k6222 in k6219 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_6232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6232,2,av);}
t2=C_mutate(&lf[87] /* (set! main#generated-c-files ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6249 in k6219 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_6251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_6251,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[91],C_text("main#transient-link-files")));
t3=C_mutate(&lf[91] /* (set! main#transient-link-files ...) */,t2);
t4=((C_word*)t0)[2];
f_6224(t4,t3);}

/* k6253 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_6255(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6255,2,av);}
/* csc.scm:866: command */
f_7467(((C_word*)t0)[2],t1);}

/* k6257 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_6259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6259,2,av);}
/* csc.scm:867: chicken.string#string-intersperse */
t2=C_fast_retrieve(lf[136]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[223];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6261 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_6263(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_6263,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6267,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6271,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[123],C_text("main#to-stdout")))){
t5=t4;
f_6271(t5,lf[230]);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6357,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:872: quotewrap */
t6=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[3];
f_3866(3,av2);}}}

/* k6265 in k6261 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_6267(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6267,2,av);}
a=C_alloc(6);
/* csc.scm:868: cons* */
f_2941(((C_word*)t0)[2],C_retrieve2(lf[56],C_text("main#translator")),C_a_i_list(&a,2,((C_word*)t0)[3],t1));}

/* k6269 in k6261 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_fcall f_6271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(20,0,2)))){
C_save_and_reclaim_args((void *)trf_6271,2,t0,t1);}
a=C_alloc(20);
t2=t1;
t3=(C_truep(C_i_debug_modep())?lf[224]:C_SCHEME_END_OF_LIST);
t4=t3;
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=C_retrieve2(lf[134],C_text("main#quote-option"));
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6282,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=t7,a[6]=t9,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6326,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6336,a[2]=t11,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[125],C_text("main#static")))){
t13=C_i_member(lf[229],C_retrieve2(lf[109],C_text("main#translate-options")));
t14=t12;
f_6336(t14,C_i_not(t13));}
else{
t13=t12;
f_6336(t13,C_SCHEME_FALSE);}}

/* k6280 in k6269 in k6261 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_6282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_6282,2,av);}
a=C_alloc(13);
t2=C_i_check_list_2(t1,lf[135]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6290,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6290(t7,t3,t1);}

/* k6286 in k6280 in k6269 in k6261 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_6288(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6288,2,av);}
/* csc.scm:869: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop1316 in k6280 in k6269 in k6261 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_fcall f_6290(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6290,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6315,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:876: g1322 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6313 in map-loop1316 in k6280 in k6269 in k6261 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in ... */
static void C_ccall f_6315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6315,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6290(t6,((C_word*)t0)[5],t5);}

/* k6324 in k6269 in k6261 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_fcall f_6326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,6)))){
C_save_and_reclaim_args((void *)trf_6326,2,t0,t1);}
if(C_truep(C_retrieve2(lf[93],C_text("main#cpp-mode")))){
/* csc.scm:877: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word av2[7];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[82],C_text("main#extra-features"));
av2[3]=C_retrieve2(lf[109],C_text("main#translate-options"));
av2[4]=t1;
av2[5]=lf[225];
av2[6]=C_retrieve2(lf[114],C_text("main#translation-optimization-options"));
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}
else{
if(C_truep(C_retrieve2(lf[94],C_text("main#objc-mode")))){
/* csc.scm:877: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word av2[7];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[82],C_text("main#extra-features"));
av2[3]=C_retrieve2(lf[109],C_text("main#translate-options"));
av2[4]=t1;
av2[5]=lf[226];
av2[6]=C_retrieve2(lf[114],C_text("main#translation-optimization-options"));
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}
else{
/* csc.scm:877: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word av2[7];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[82],C_text("main#extra-features"));
av2[3]=C_retrieve2(lf[109],C_text("main#translate-options"));
av2[4]=t1;
av2[5]=C_SCHEME_END_OF_LIST;
av2[6]=C_retrieve2(lf[114],C_text("main#translation-optimization-options"));
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}}}

/* k6334 in k6269 in k6261 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_fcall f_6336(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,3)))){
C_save_and_reclaim_args((void *)trf_6336,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:884: chicken.pathname#pathname-replace-extension */
t3=C_fast_retrieve(lf[175]);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[228];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];
f_6326(t2,C_SCHEME_END_OF_LIST);}}

/* k6341 in k6334 in k6269 in k6261 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_6343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_6343,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
f_6326(t2,C_a_i_list2(&a,2,lf[227],t1));}

/* k6355 in k6261 in k6216 in k6213 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_6357(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_6357,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
f_6271(t2,C_a_i_list(&a,2,lf[231],t1));}

/* for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_fcall f_6386(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_6386,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6396,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=C_i_length(C_retrieve2(lf[84],C_text("main#scheme-files")));
t8=C_eqp(C_fix(1),t7);
t9=(C_truep(t8)?C_retrieve2(lf[118],C_text("main#target-filename")):t6);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6215,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[93],C_text("main#cpp-mode")))){
/* csc.scm:858: chicken.pathname#pathname-replace-extension */
t11=C_fast_retrieve(lf[175]);{
C_word av2[4];
av2[0]=t11;
av2[1]=t10;
av2[2]=t9;
av2[3]=lf[233];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
if(C_truep(C_retrieve2(lf[94],C_text("main#objc-mode")))){
/* csc.scm:858: chicken.pathname#pathname-replace-extension */
t11=C_fast_retrieve(lf[175]);{
C_word av2[4];
av2[0]=t11;
av2[1]=t10;
av2[2]=t9;
av2[3]=lf[234];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
/* csc.scm:858: chicken.pathname#pathname-replace-extension */
t11=C_fast_retrieve(lf[175]);{
C_word av2[4];
av2[0]=t11;
av2[1]=t10;
av2[2]=t9;
av2[3]=lf[235];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6394 in for-each-loop1295 in k4607 in k4604 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_6396(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6396,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6386(t3,((C_word*)t0)[4],t2);}

/* g1359 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_fcall f_6411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_6411,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6415,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[122],C_text("main#compile-only")))){
if(C_truep(C_retrieve2(lf[118],C_text("main#target-filename")))){
t4=C_i_length(C_retrieve2(lf[85],C_text("main#c-files")));
t5=C_eqp(C_fix(1),t4);
if(C_truep(t5)){
t6=t3;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_retrieve2(lf[118],C_text("main#target-filename"));
f_6415(2,av2);}}
else{
/* csc.scm:910: chicken.pathname#pathname-replace-extension */
t6=C_fast_retrieve(lf[175]);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_retrieve2(lf[64],C_text("main#object-extension"));
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}
else{
/* csc.scm:910: chicken.pathname#pathname-replace-extension */
t4=C_fast_retrieve(lf[175]);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_retrieve2(lf[64],C_text("main#object-extension"));
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}
else{
/* csc.scm:910: chicken.pathname#pathname-replace-extension */
t4=C_fast_retrieve(lf[175]);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_retrieve2(lf[64],C_text("main#object-extension"));
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k6413 in g1359 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_ccall f_6415(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_6415,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6418,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_member(t2,C_retrieve2(lf[89],C_text("main#object-files"))))){
/* csc.scm:912: stop */
f_3817(t3,lf[210],C_a_i_list(&a,2,((C_word*)t0)[4],t2));}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_6418(2,av2);}}}

/* k6416 in k6413 in g1359 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_6418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_6418,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6433,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[93],C_text("main#cpp-mode")))?C_retrieve2(lf[58],C_text("main#c++-compiler")):C_retrieve2(lf[57],C_text("main#compiler")));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6445,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:918: quotewrap */
t7=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[5];
f_3866(3,av2);}}

/* k6419 in k6416 in k6413 in g1359 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_6421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_6421,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[90],C_text("main#generated-object-files")));
t3=C_mutate(&lf[90] /* (set! main#generated-object-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k6431 in k6416 in k6413 in g1359 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_6433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6433,2,av);}
/* csc.scm:914: command */
f_7467(((C_word*)t0)[2],t1);}

/* k6443 in k6416 in k6413 in g1359 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_6445(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_6445,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6449,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6468,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:919: quotewrap */
t5=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
f_3866(3,av2);}}

/* k6447 in k6443 in k6416 in k6413 in g1359 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_6449(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6449,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[93],C_text("main#cpp-mode")))){
t4=C_i_string_equal_p(lf[206],C_retrieve2(lf[58],C_text("main#c++-compiler")));
t5=t3;
f_6453(t5,(C_truep(t4)?lf[207]:lf[208]));}
else{
t4=t3;
f_6453(t4,lf[208]);}}

/* k6451 in k6447 in k6443 in k6416 in k6413 in g1359 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_fcall f_6453(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_6453,2,t0,t1);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:924: compiler-options */
f_6683(t3);}

/* k6455 in k6451 in k6447 in k6443 in k6416 in k6413 in g1359 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_6457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,2)))){
C_save_and_reclaim((void *)f_6457,2,av);}
a=C_alloc(18);
t2=C_a_i_list6(&a,6,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[205],((C_word*)t0)[5],t1);
/* csc.scm:915: chicken.string#string-intersperse */
t3=C_fast_retrieve(lf[136]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[6];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6466 in k6443 in k6416 in k6413 in g1359 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_6468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6468,2,av);}
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[186]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[186]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[209];
av2[3]=t1;
tp(4,av2);}}

/* k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_6497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_6497,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6633,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[74],C_text("main#generate-manifest")))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6658,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:928: chicken.platform#software-type */
t5=C_fast_retrieve(lf[219]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t3;
f_6633(t4,C_SCHEME_FALSE);}}

/* k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_fcall f_6500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,3)))){
C_save_and_reclaim_args((void *)trf_6500,2,t0,t1);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6501,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve2(lf[86],C_text("main#rc-files"));
t4=C_i_check_list_2(C_retrieve2(lf[86],C_text("main#rc-files")),lf[176]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6609,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6609(t9,t5,C_retrieve2(lf[86],C_text("main#rc-files")));}

/* g1369 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_fcall f_6501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_6501,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6505,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:935: scheme#string-append */
t4=*((C_word*)lf[76]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[211];
av2[4]=C_retrieve2(lf[64],C_text("main#object-extension"));
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k6503 in g1369 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_6505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_6505,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6508,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6520,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6528,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:938: quotewrap */
t6=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[4];
f_3866(3,av2);}}

/* k6506 in k6503 in g1369 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_6508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_6508,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[90],C_text("main#generated-object-files")));
t3=C_mutate(&lf[90] /* (set! main#generated-object-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k6518 in k6503 in g1369 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_6520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6520,2,av);}
/* csc.scm:936: command */
f_7467(((C_word*)t0)[2],t1);}

/* k6526 in k6503 in g1369 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_6528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6528,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6532,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:938: quotewrap */
t4=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
f_3866(3,av2);}}

/* k6530 in k6526 in k6503 in g1369 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_6532(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_6532,2,av);}
a=C_alloc(9);
t2=C_a_i_list3(&a,3,C_retrieve2(lf[59],C_text("main#rc-compiler")),((C_word*)t0)[2],t1);
/* csc.scm:937: chicken.string#string-intersperse */
t3=C_fast_retrieve(lf[136]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6536 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_6538(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6538,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6542,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6607,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:942: scheme#reverse */
t4=*((C_word*)lf[190]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6540 in k6536 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_6542(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_6542,2,av);}
a=C_alloc(9);
t2=C_mutate(&lf[89] /* (set! main#object-files ...) */,t1);
if(C_truep(C_retrieve2(lf[120],C_text("main#keep-files")))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_retrieve2(lf[164],C_text("main#$delete-file"));
t4=C_retrieve2(lf[87],C_text("main#generated-c-files"));
t5=C_i_check_list_2(C_retrieve2(lf[87],C_text("main#generated-c-files")),lf[176]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6551,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6582,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_6582(t10,t6,C_retrieve2(lf[87],C_text("main#generated-c-files")));}}

/* k6549 in k6540 in k6536 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_6551(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6551,2,av);}
a=C_alloc(6);
t2=C_retrieve2(lf[164],C_text("main#$delete-file"));
t3=C_retrieve2(lf[88],C_text("main#generated-rc-files"));
t4=C_i_check_list_2(C_retrieve2(lf[88],C_text("main#generated-rc-files")),lf[176]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6559,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_6559(t8,((C_word*)t0)[2],C_retrieve2(lf[88],C_text("main#generated-rc-files")));}

/* for-each-loop1428 in k6549 in k6540 in k6536 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_fcall f_6559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6559,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6569,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:945: g1429 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6567 in for-each-loop1428 in k6549 in k6540 in k6536 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_6569(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6569,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6559(t3,((C_word*)t0)[4],t2);}

/* for-each-loop1411 in k6540 in k6536 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_fcall f_6582(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6582,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6592,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:944: g1412 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6590 in for-each-loop1411 in k6540 in k6536 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_6592(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6592,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6582(t3,((C_word*)t0)[4],t2);}

/* k6605 in k6536 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_6607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6607,2,av);}
/* csc.scm:942: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_retrieve2(lf[89],C_text("main#object-files"));
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop1368 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_fcall f_6609(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6609,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6619,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:933: g1369 */
t5=((C_word*)t0)[3];
f_6501(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6617 in for-each-loop1368 in k6498 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_6619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6619,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6609(t3,((C_word*)t0)[4],t2);}

/* k6631 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_fcall f_6633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,3)))){
C_save_and_reclaim_args((void *)trf_6633,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6636,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:929: chicken.pathname#pathname-replace-extension */
t3=C_fast_retrieve(lf[175]);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_retrieve2(lf[118],C_text("main#target-filename"));
av2[3]=lf[218];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];
f_6500(t2,C_SCHEME_UNDEFINED);}}

/* k6634 in k6631 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in ... */
static void C_ccall f_6636(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_6636,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6639,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6651,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:930: chicken.pathname#pathname-file */
t5=C_fast_retrieve(lf[217]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_retrieve2(lf[118],C_text("main#target-filename"));
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6637 in k6634 in k6631 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_6639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_6639,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[86],C_text("main#rc-files")));
t3=C_mutate(&lf[86] /* (set! main#rc-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[88],C_text("main#generated-rc-files")));
t5=C_mutate(&lf[88] /* (set! main#generated-rc-files ...) */,t4);
t6=((C_word*)t0)[3];
f_6500(t6,t5);}

/* k6649 in k6634 in k6631 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_6651(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6651,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t1;
t4=((C_word*)t0)[3];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7539,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[119],C_text("main#verbose")))){
/* csc.scm:1112: chicken.base#print */
t6=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[216];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t6=t5;{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_7539(2,av2);}}}

/* k6656 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_ccall f_6658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6658,2,av);}
t2=((C_word*)t0)[2];
f_6633(t2,C_eqp(lf[15],t1));}

/* for-each-loop1358 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_fcall f_6660(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6660,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6670,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:904: g1359 */
t5=((C_word*)t0)[3];
f_6411(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6668 in for-each-loop1358 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_ccall f_6670(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6670,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6660(t3,((C_word*)t0)[4],t2);}

/* main#compiler-options in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_fcall f_6683(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,3)))){
C_save_and_reclaim_args((void *)trf_6683,1,t1);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=C_retrieve2(lf[134],C_text("main#quote-option"));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6694,a[2]=t1,a[3]=t4,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* csc.scm:950: scheme#append */
t8=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=C_retrieve2(lf[115],C_text("main#compilation-optimization-options"));
av2[3]=C_retrieve2(lf[112],C_text("main#compile-options"));
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k6692 in main#compiler-options in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_6694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_6694,2,av);}
a=C_alloc(11);
t2=C_i_check_list_2(t1,lf[135]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6702,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6702(t7,t3,t1);}

/* k6698 in k6692 in main#compiler-options in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_6700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6700,2,av);}
/* csc.scm:948: chicken.string#string-intersperse */
t2=C_fast_retrieve(lf[136]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop1451 in k6692 in main#compiler-options in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_fcall f_6702(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6702,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6727,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:949: g1457 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6725 in map-loop1451 in k6692 in main#compiler-options in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_6727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6727,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6702(t6,((C_word*)t0)[5],t5);}

/* k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_ccall f_6741(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,3)))){
C_save_and_reclaim((void *)f_6741,2,av);}
a=C_alloc(16);
t2=C_mutate(&lf[89] /* (set! main#object-files ...) */,t1);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_retrieve2(lf[50],C_text("main#quotewrap"));
t8=C_retrieve2(lf[89],C_text("main#object-files"));
t9=C_i_check_list_2(C_retrieve2(lf[89],C_text("main#object-files")),lf[135]);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6750,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6886,a[2]=t5,a[3]=t12,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_6886(t14,t10,C_retrieve2(lf[89],C_text("main#object-files")));}

/* k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_6750(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6750,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6753,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:961: quotewrap */
t4=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_retrieve2(lf[118],C_text("main#target-filename"));
f_3866(3,av2);}}

/* k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_6753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,2)))){
C_save_and_reclaim((void *)f_6753,2,av);}
a=C_alloc(21);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6756,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6851,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6855,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(C_retrieve2(lf[93],C_text("main#cpp-mode")))?C_retrieve2(lf[61],C_text("main#c++-linker")):C_retrieve2(lf[60],C_text("main#linker")));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6863,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6871,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6884,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:969: quotewrap */
t11=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=C_retrieve2(lf[118],C_text("main#target-filename"));
f_3866(3,av2);}}

/* k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_6756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,3)))){
C_save_and_reclaim((void *)f_6756,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6759,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_truep(C_retrieve2(lf[31],C_text("main#osx")))?C_retrieve2(lf[49],C_text("main#host-mode")):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6800,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6810,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6814,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_POSTINSTALL_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t4=t2;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_6759(2,av2);}}}

/* k6757 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_6759(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_6759,2,av);}
a=C_alloc(4);
if(C_truep(C_retrieve2(lf[120],C_text("main#keep-files")))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_retrieve2(lf[164],C_text("main#$delete-file"));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6765,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:990: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_retrieve2(lf[90],C_text("main#generated-object-files"));
av2[3]=C_retrieve2(lf[91],C_text("main#transient-link-files"));
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k6763 in k6757 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in ... */
static void C_ccall f_6765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6765,2,av);}
a=C_alloc(6);
t2=C_i_check_list_2(t1,lf[176]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6773,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6773(t6,((C_word*)t0)[3],t1);}

/* for-each-loop1513 in k6763 in k6757 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in ... */
static void C_fcall f_6773(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6773,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6783,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:989: g1514 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6781 in for-each-loop1513 in k6763 in k6757 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in ... */
static void C_ccall f_6783(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6783,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6773(t3,((C_word*)t0)[4],t2);}

/* k6798 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_6800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6800,2,av);}
a=C_alloc(4);
if(C_truep(C_retrieve2(lf[101],C_text("main#gui")))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7503,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1107: chicken.base#open-output-string */
t5=C_fast_retrieve(lf[181]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
f_6759(2,av2);}}}

/* k6808 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_6810(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6810,2,av);}
/* csc.scm:973: command */
f_7467(((C_word*)t0)[2],t1);}

/* k6812 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_6814(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_6814,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6818,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:975: libchicken */
f_3941(t3);}

/* k6816 in k6812 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in ... */
static void C_ccall f_6818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_6818,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6826,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6846,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:977: libchicken */
f_3941(t5);}

/* k6820 in k6816 in k6812 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in ... */
static void C_ccall f_6822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,8)))){
C_save_and_reclaim((void *)f_6822,2,av);}
/* csc.scm:974: scheme#string-append */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 9) {
  av2=av;
} else {
  av2=C_alloc(9);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[182];
av2[4]=((C_word*)t0)[4];
av2[5]=lf[183];
av2[6]=t1;
av2[7]=lf[184];
av2[8]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(9,av2);}}

/* k6824 in k6816 in k6812 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in ... */
static void C_ccall f_6826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_6826,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6829,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[102],C_text("main#deployed")))){
/* csc.scm:979: chicken.pathname#make-pathname */
t4=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[185];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6839,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
t5=C_retrieve2(lf[17],C_text("main#host-libdir"));
t6=C_retrieve2(lf[17],C_text("main#host-libdir"));
/* csc.scm:980: chicken.pathname#make-pathname */
t7=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=C_retrieve2(lf[17],C_text("main#host-libdir"));
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}}

/* k6827 in k6824 in k6816 in k6812 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in ... */
static void C_ccall f_6829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6829,2,av);}
/* csc.scm:976: quotewrap */
t2=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
f_3866(3,av2);}}

/* k6837 in k6824 in k6816 in k6812 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in ... */
static void C_ccall f_6839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6839,2,av);}
/* csc.scm:980: chicken.pathname#make-pathname */
t2=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6844 in k6816 in k6812 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in ... */
static void C_ccall f_6846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6846,2,av);}
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[186]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[186]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[187];
tp(4,av2);}}

/* k6849 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_6851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6851,2,av);}
/* csc.scm:963: command */
f_7467(((C_word*)t0)[2],t1);}

/* k6853 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_6855(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6855,2,av);}
/* csc.scm:964: chicken.string#string-intersperse */
t2=C_fast_retrieve(lf[136]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6861 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_6863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_6863,2,av);}
a=C_alloc(3);
/* csc.scm:965: cons* */
f_2941(((C_word*)t0)[2],((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* k6869 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_6871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_6871,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6875,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:970: linker-options */
f_7170(t3);}

/* k6873 in k6869 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_6875(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6875,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6879,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:971: linker-libraries */
f_7223(t3);}

/* k6877 in k6873 in k6869 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in ... */
static void C_ccall f_6879(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_6879,2,av);}
a=C_alloc(9);
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t1);
/* csc.scm:967: scheme#append */
t3=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6882 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_6884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6884,2,av);}
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[186]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[186]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[188];
av2[3]=t1;
tp(4,av2);}}

/* map-loop1479 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_fcall f_6886(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6886,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6911,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:960: g1485 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6909 in map-loop1479 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_6911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6911,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6886(t6,((C_word*)t0)[5],t5);}

/* k6925 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_6927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6927,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6930,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fast_retrieve(lf[130]))){
/* csc.scm:997: chicken.string#string-chomp */
t3=C_fast_retrieve(lf[196]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=lf[197];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t1;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8584,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:998: chicken.pathname#make-pathname */
t5=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_FALSE;
av2[3]=t3;
av2[4]=lf[195];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* k6928 in k6925 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_6930(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_6930,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6937,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:998: chicken.pathname#make-pathname */
t3=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
av2[3]=t1;
av2[4]=lf[195];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6935 in k6928 in k6925 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_6937(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6937,2,av);}
/* csc.scm:998: chicken.file#file-exists? */
t2=C_fast_retrieve(lf[131]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6949 in map-loop1542 in k6964 in k7089 in k7066 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in ... */
static void C_ccall f_6951(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_6951,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* csc.scm:1002: stop */
f_3817(((C_word*)t0)[2],lf[192],C_a_i_list(&a,1,((C_word*)t0)[3]));}}

/* k6964 in k7089 in k7066 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_6966(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_6966,2,av);}
a=C_alloc(7);
t2=C_i_check_list_2(t1,lf[135]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6974,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6974(t6,((C_word*)t0)[4],t1);}

/* map-loop1542 in k6964 in k7089 in k7066 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in ... */
static void C_fcall f_6974(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_6974,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6999,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6951,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1001: find-object-file */
t8=C_retrieve2(lf[128],C_text("main#find-object-file"));{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
f_4238(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6997 in map-loop1542 in k6964 in k7089 in k7066 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in ... */
static void C_ccall f_6999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6999,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6974(t6,((C_word*)t0)[5],t5);}

/* map-loop1565 in k7089 in k7066 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_fcall f_7008(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7008,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7033,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:1003: g1571 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7031 in map-loop1565 in k7089 in k7066 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in ... */
static void C_ccall f_7033(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7033,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7008(t6,((C_word*)t0)[5],t5);}

/* loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in ... */
static void C_fcall f_7045(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7045,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7059,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1006: scheme#reverse */
t5=*((C_word*)lf[190]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=C_retrieve2(lf[125],C_text("main#static"));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7065,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[125],C_text("main#static")))){
t6=t5;
f_7065(t6,C_retrieve2(lf[125],C_text("main#static")));}
else{
t6=C_i_car(t2);
t7=C_i_member(t6,((C_word*)t0)[3]);
t8=t5;
f_7065(t8,C_i_not(t7));}}}

/* k7057 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_7059(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7059,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=*((C_word*)lf[189]+1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3078,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3078(t7,t2,t1);}

/* k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_fcall f_7065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_7065,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[5]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6927,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:995: chicken.pathname#pathname-strip-extension */
t6=C_fast_retrieve(lf[198]);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t2=C_i_cdr(((C_word*)t0)[5]);
t3=((C_word*)t0)[5];
t4=C_u_i_car(t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
/* csc.scm:1013: loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7045(t6,((C_word*)t0)[3],t2,t5);}}

/* k7066 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_7068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_7068,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7091,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1010: scheme#with-input-from-file */
t4=C_fast_retrieve(lf[193]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
av2[3]=*((C_word*)lf[194]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
f_7071(2,av2);}}}

/* k7069 in k7066 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_7071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7071,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[5];
t5=C_u_i_cdr(t4);
/* csc.scm:1012: scheme#append */
t6=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t2;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k7076 in k7069 in k7066 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in ... */
static void C_ccall f_7078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_7078,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1012: scheme#append */
t4=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7080 in k7076 in k7069 in k7066 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in ... */
static void C_ccall f_7082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7082,2,av);}
/* csc.scm:1012: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7045(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k7089 in k7066 in k7063 in loop in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_7091(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,3)))){
C_save_and_reclaim((void *)f_7091,2,av);}
a=C_alloc(23);
t2=((C_word*)t0)[2];
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=C_fast_retrieve(lf[191]);
t12=C_i_check_list_2(t1,lf[135]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6966,a[2]=t5,a[3]=t6,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7008,a[2]=t9,a[3]=t15,a[4]=t11,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_7008(t17,t13,t1);}

/* main#linker-options in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_fcall f_7170(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,3)))){
C_save_and_reclaim_args((void *)trf_7170,1,t1);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=C_retrieve2(lf[134],C_text("main#quote-option"));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7181,a[2]=t1,a[3]=t4,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1027: scheme#append */
t8=*((C_word*)lf[137]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=C_retrieve2(lf[116],C_text("main#linking-optimization-options"));
av2[3]=C_retrieve2(lf[117],C_text("main#link-options"));
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k7179 in main#linker-options in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7181(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_7181,2,av);}
a=C_alloc(11);
t2=C_i_check_list_2(t1,lf[135]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7187,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7189,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7189(t7,t3,t1);}

/* k7185 in k7179 in main#linker-options in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_7187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7187,2,av);}
/* csc.scm:1025: chicken.string#string-intersperse */
t2=C_fast_retrieve(lf[136]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop1635 in k7179 in main#linker-options in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_fcall f_7189(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7189,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7214,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:1026: g1641 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7212 in map-loop1635 in k7179 in main#linker-options in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_7214(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7214,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7189(t6,((C_word*)t0)[5],t5);}

/* main#linker-libraries in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_fcall f_7223(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,3)))){
C_save_and_reclaim_args((void *)trf_7223,1,t1);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7231,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7235,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[125],C_text("main#static")))){
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4069,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3984,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:129: libchicken */
f_3941(t7);}
else{
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4049,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4053,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[49],C_text("main#host-mode")))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[46]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_LIB_NAME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[46]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=C_mpointer(&a,(void*)C_TARGET_LIB_NAME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}}

/* k7229 in main#linker-libraries in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7231(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7231,2,av);}
/* csc.scm:1030: chicken.string#string-intersperse */
t2=C_fast_retrieve(lf[136]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7233 in main#linker-libraries in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7235(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_7235,2,av);}
a=C_alloc(3);
t2=(C_truep(C_retrieve2(lf[125],C_text("main#static")))?C_a_i_list1(&a,1,C_retrieve2(lf[107],C_text("main#extra-libraries"))):C_a_i_list1(&a,1,C_retrieve2(lf[108],C_text("main#extra-shared-libraries"))));
/* csc.scm:1031: scheme#append */
t3=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7256 in k7366 in k7360 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_7258(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_7258,2,av);}
a=C_alloc(3);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7268,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1056: chicken.string#string-translate* */
t3=C_fast_retrieve(lf[146]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=lf[147];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=t1;
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7266 in k7256 in k7366 in k7360 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_7268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7268,2,av);}
/* csc.scm:1056: scheme#string-append */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[144];
av2[3]=t1;
av2[4]=lf[145];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7270 in k7366 in k7360 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_7272(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7272,2,av);}
/* ##sys#list->string */
t2=C_fast_retrieve(lf[148]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7274 in k7366 in k7360 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_7276(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7276,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7278,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7278(t5,((C_word*)t0)[3],t1);}

/* fold in k7274 in k7366 in k7360 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_fcall f_7278(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7278,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
if(C_truep(C_i_memq(t4,C_retrieve2(lf[141],C_text("main#constant1663"))))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7301,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=C_u_i_cdr(t6);
/* csc.scm:1051: fold */
t9=t5;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7306,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_u_i_char_whitespacep(t4))){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t5;
f_7306(t7,t6);}
else{
t6=t5;
f_7306(t6,C_SCHEME_UNDEFINED);}}}}

/* k7299 in fold in k7274 in k7366 in k7360 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_7301(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7301,2,av);}
a=C_alloc(6);
/* csc.scm:1051: cons* */
f_2941(((C_word*)t0)[2],C_make_character(92),C_a_i_list(&a,2,((C_word*)t0)[3],t1));}

/* k7304 in fold in k7274 in k7366 in k7360 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_fcall f_7306(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_7306,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
/* csc.scm:1054: fold */
t5=((C_word*)((C_word*)t0)[5])[1];
f_7278(t5,t2,t4);}

/* k7311 in k7304 in fold in k7274 in k7366 in k7360 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_7313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_7313,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* main#string-any in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_fcall f_7321(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_7321,3,t1,t2,t3);}
a=C_alloc(8);
t4=C_i_string_length(t3);
t5=t4;
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7330,a[2]=t3,a[3]=t5,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_7330(t9,t1,C_fix(0));}

/* lp in main#string-any in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_fcall f_7330(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_7330,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_i_string_ref(((C_word*)t0)[2],t2);
t4=t2;
t5=C_a_i_fixnum_plus(&a,2,t4,C_fix(1));
if(C_truep(C_i_integer_equalp(t5,((C_word*)t0)[3]))){
/* csc.scm:1065: criteria */
t6=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t6;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7347,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1066: criteria */
t7=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}}

/* k7345 in lp in main#string-any in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_7347(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7347,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
/* csc.scm:1067: lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7330(t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_ccall f_7355(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7355,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7362,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7385,tmp=(C_word)a,a+=2,tmp);
/* csc.scm:1070: string-any */
f_7321(t3,t4,t2);}

/* k7360 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7362(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7362,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7368,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7373,tmp=(C_word)a,a+=2,tmp);
/* csc.scm:1071: string-any */
f_7321(t2,t3,((C_word*)t0)[2]);}}

/* k7366 in k7360 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_7368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_7368,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7258,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7272,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7276,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* ##sys#string->list */
t9=C_fast_retrieve(lf[149]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a7372 in k7360 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_7373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7373,3,av);}
t3=C_u_i_char_whitespacep(t2);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=(C_truep(t3)?t3:C_i_memq(t2,C_retrieve2(lf[141],C_text("main#constant1663"))));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a7384 in main#quote-option in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7385(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7385,3,av);}
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_i_char_equalp(C_make_character(34),t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7394 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7396(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7396,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7399,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[119],C_text("main#verbose")))){
/* csc.scm:1087: chicken.base#print */
t4=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_7399(2,av2);}}}

/* k7397 in k7394 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_7399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7399,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[100],C_text("main#dry-run")))){
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_fix(0);
f_7402(2,av2);}}
else{
/* csc.scm:1088: chicken.process#system */
t3=C_fast_retrieve(lf[156]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k7400 in k7397 in k7394 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_7402(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_7402,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7405,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_7405(2,av2);}}
else{
t5=*((C_word*)lf[152]+1);
t6=*((C_word*)lf[152]+1);
t7=C_i_check_port_2(*((C_word*)lf[152]+1),C_fix(2),C_SCHEME_TRUE,lf[153]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7422,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1090: ##sys#print */
t9=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[155];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[152]+1);
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}}

/* k7403 in k7400 in k7397 in k7394 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_7405(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7405,2,av);}
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
t3=lf[150] /* main#last-exit-code */ =C_fix(0);;
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_retrieve2(lf[150],C_text("main#last-exit-code"));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=lf[150] /* main#last-exit-code */ =C_fix(1);;
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_retrieve2(lf[150],C_text("main#last-exit-code"));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7420 in k7400 in k7397 in k7394 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_7422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_7422,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1090: ##sys#print */
t3=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k7423 in k7420 in k7400 in k7397 in k7394 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in ... */
static void C_ccall f_7425(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_7425,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1090: ##sys#print */
t3=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[154];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k7426 in k7423 in k7420 in k7400 in k7397 in k7394 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in ... */
static void C_ccall f_7428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_7428,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1090: ##sys#print */
t3=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k7429 in k7426 in k7423 in k7420 in k7400 in k7397 in k7394 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in ... */
static void C_ccall f_7431(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7431,2,av);}
/* csc.scm:1090: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[42]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[42]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k7445 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_7447,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1080: g1719 */
t3=t2;
f_7451(t3,((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
f_7396(2,av2);}}}

/* g1719 in k7445 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_fcall f_7451(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_7451,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7459,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1085: chicken.process#qs */
t4=C_fast_retrieve(lf[51]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7457 in g1719 in k7445 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_7459(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_7459,2,av);}
/* csc.scm:1084: scheme#string-append */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[160];
av2[3]=t1;
av2[4]=lf[161];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_fcall f_7467(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,4)))){
C_save_and_reclaim_args((void *)trf_7467,2,t1,t2);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7475,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t3;
t5=t2;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7396,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_mk_bool(C_WINDOWS_SHELL))){
/* csc.scm:1081: scheme#string-append */
t7=*((C_word*)lf[76]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[158];
av2[3]=t5;
av2[4]=lf[159];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7447,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[31],C_text("main#osx")))){
/* csc.scm:1082: chicken.process-context#get-environment-variable */
t8=C_fast_retrieve(lf[162]);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[163];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t8=t7;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
f_7447(2,av2);}}}}

/* k7473 in main#command in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7475(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7475,2,av);}
if(C_truep(C_i_zerop(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* csc.scm:1097: chicken.base#exit */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[150],C_text("main#last-exit-code"));
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* main#$delete-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_ccall f_7480(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_7480,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7484,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[119],C_text("main#verbose")))){
/* csc.scm:1101: chicken.base#print */
t4=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[166];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
if(C_truep(C_retrieve2(lf[100],C_text("main#dry-run")))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
/* csc.scm:1102: chicken.file#delete-file */
t4=C_fast_retrieve(lf[165]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}}

/* k7482 in main#$delete-file in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7484(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7484,2,av);}
if(C_truep(C_retrieve2(lf[100],C_text("main#dry-run")))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* csc.scm:1102: chicken.file#delete-file */
t2=C_fast_retrieve(lf[165]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k7501 in k6798 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in ... */
static void C_ccall f_7503(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_7503,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_fix(2),C_SCHEME_TRUE,lf[177]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7509,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1107: ##sys#print */
t6=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[180];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7507 in k7501 in k6798 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in ... */
static void C_ccall f_7509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_7509,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7533,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1108: quotewrap */
t4=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
f_3866(3,av2);}}

/* k7510 in k7507 in k7501 in k6798 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in ... */
static void C_ccall f_7512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_7512,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1107: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[42]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[42]+1);
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* k7513 in k7510 in k7507 in k7501 in k6798 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in ... */
static void C_ccall f_7515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_7515,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7525,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7529,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1109: chicken.pathname#make-pathname */
t5=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_retrieve2(lf[55],C_text("main#home"));
av2[3]=lf[179];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k7516 in k7513 in k7510 in k7507 in k7501 in k6798 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in ... */
static void C_ccall f_7518(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7518,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7521,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1107: chicken.base#get-output-string */
t3=C_fast_retrieve(lf[178]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7519 in k7516 in k7513 in k7510 in k7507 in k7501 in k6798 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in ... */
static void C_ccall f_7521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7521,2,av);}
/* csc.scm:1106: command */
f_7467(((C_word*)t0)[2],t1);}

/* k7523 in k7513 in k7510 in k7507 in k7501 in k6798 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in ... */
static void C_ccall f_7525(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7525,2,av);}
/* csc.scm:1107: ##sys#print */
t2=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7527 in k7513 in k7510 in k7507 in k7501 in k6798 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in ... */
static void C_ccall f_7529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7529,2,av);}
/* csc.scm:1109: quotewrap */
t2=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
f_3866(3,av2);}}

/* k7531 in k7507 in k7501 in k6798 in k6754 in k6751 in k6748 in k6739 in k4463 in k4460 in k4454 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in ... */
static void C_ccall f_7533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7533,2,av);}
/* csc.scm:1107: ##sys#print */
t2=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7537 in k6649 in k6634 in k6631 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in ... */
static void C_ccall f_7539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_7539,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7544,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1113: scheme#with-output-to-file */
t3=C_fast_retrieve(lf[215]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a7543 in k7537 in k6649 in k6634 in k6631 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in ... */
static void C_ccall f_7544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_7544,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7552,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[212],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,lf[213],t4);
/* csc.scm:28: ##sys#print-to-string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[214]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[214]+1);
av2[1]=t2;
av2[2]=t5;
tp(3,av2);}}

/* k7550 in a7543 in k7537 in k6649 in k6634 in k6631 in k6495 in k4448 in k4445 in k4442 in k4438 in loop in k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in ... */
static void C_ccall f_7552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7552,2,av);}
/* csc.scm:1115: chicken.base#print */
t2=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7568 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_ccall f_7570(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7570,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.base#implicit-exit-handler */
t3=C_fast_retrieve(lf[167]);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7574 in k7568 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7576(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7576,2,av);}
t2=t1;{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7578 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_ccall f_7580(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,5)))){
C_save_and_reclaim((void *)f_7580,2,av);}
a=C_alloc(25);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4350,tmp=(C_word)a,a+=2,tmp));
t11=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4357,tmp=(C_word)a,a+=2,tmp));
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4383,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4413,tmp=(C_word)a,a+=2,tmp));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4429,a[2]=t9,a[3]=t15,a[4]=t3,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_4429(t17,((C_word*)t0)[2],t1);}

/* k7582 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_ccall f_7584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7584,2,av);}
/* csc.scm:1137: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_retrieve2(lf[47],C_text("main#arguments"));
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7586 in k4086 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_ccall f_7588(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7588,2,av);}
if(C_truep(t1)){
t2=t1;
/* csc.scm:1138: chicken.string#string-split */
t3=C_fast_retrieve(lf[240]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* csc.scm:1138: chicken.string#string-split */
t2=C_fast_retrieve(lf[240]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[417];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k7593 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in ... */
static void C_fcall f_7595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_7595,2,t0,t1);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7599,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:246: chicken.process-context#get-environment-variable */
t4=C_fast_retrieve(lf[162]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[421];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7597 in k7593 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in ... */
static void C_ccall f_7599(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,3)))){
C_save_and_reclaim((void *)f_7599,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
t4=t1;
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=C_retrieve2(lf[50],C_text("main#quotewrap"));
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7618,a[2]=t7,a[3]=t8,a[4]=t3,a[5]=t11,a[6]=t13,a[7]=t12,tmp=(C_word)a,a+=8,tmp);
/* csc.scm:248: chicken.string#string-split */
t15=C_fast_retrieve(lf[240]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=t4;
av2[3]=lf[420];
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}
else{
/* csc.scm:244: scheme#append */
t3=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k7600 in k7597 in k7593 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7602,2,av);}
/* csc.scm:244: scheme#append */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7616 in k7597 in k7593 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in ... */
static void C_ccall f_7618(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_7618,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7663,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7663(t6,t2,t1);}

/* k7619 in k7616 in k7597 in k7593 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_ccall f_7621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_7621,2,av);}
a=C_alloc(7);
t2=C_i_check_list_2(t1,lf[135]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7629,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7629(t6,((C_word*)t0)[4],t1);}

/* map-loop862 in k7619 in k7616 in k7597 in k7593 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_fcall f_7629(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_7629,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7654,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:248: g885 */
t5=*((C_word*)lf[76]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[419];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7652 in map-loop862 in k7619 in k7616 in k7597 in k7593 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in ... */
static void C_ccall f_7654(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7654,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7629(t6,((C_word*)t0)[5],t5);}

/* map-loop889 in k7616 in k7597 in k7593 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in ... */
static void C_fcall f_7663(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7663,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7688,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:248: g895 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7686 in map-loop889 in k7616 in k7597 in k7593 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in ... */
static void C_ccall f_7688(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7688,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7663(t6,((C_word*)t0)[5],t5);}

/* k7703 in k4033 in k4003 in k3996 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in ... */
static void C_ccall f_7705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_7705,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
f_7595(t2,C_a_i_list1(&a,1,t1));}

/* k7723 in k3991 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in ... */
static void C_ccall f_7725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7725,2,av);}
/* csc.scm:143: chicken.string#string-split */
t2=C_fast_retrieve(lf[240]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7727 in k3986 in k3936 in k3931 in k3927 in k3914 in k3910 in k3906 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in ... */
static void C_ccall f_7729(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7729,2,av);}
/* csc.scm:138: chicken.string#string-split */
t2=C_fast_retrieve(lf[240]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7752 in k3902 in k3898 in k3894 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in ... */
static void C_ccall f_7754(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7754,2,av);}
/* csc.scm:102: quotewrap */
t2=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
f_3866(3,av2);}}

/* k7770 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in ... */
static void C_ccall f_7772(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7772,2,av);}
/* csc.scm:98: quotewrap */
t2=C_retrieve2(lf[50],C_text("main#quotewrap"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
f_3866(3,av2);}}

/* k7774 in k3846 in k3842 in k3812 in k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in ... */
static void C_ccall f_7776(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7776,2,av);}
/* csc.scm:98: chicken.pathname#make-pathname */
t2=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[18],C_text("main#host-bindir"));
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7781 in k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in ... */
static void C_ccall f_7783(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7783,2,av);}
a=C_alloc(3);
t2=C_eqp(t1,lf[34]);
t3=lf[35] /* main#aix */ =t2;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3814,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:73: chicken.platform#software-version */
t5=C_fast_retrieve(lf[247]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k7785 in k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in ... */
static void C_ccall f_7787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7787,2,av);}
a=C_alloc(3);
t2=C_eqp(t1,lf[32]);
t3=lf[33] /* main#cygwin */ =t2;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:70: chicken.platform#build-platform */
t5=C_fast_retrieve(lf[373]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k7789 in k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in ... */
static void C_ccall f_7791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7791,2,av);}
a=C_alloc(3);
t2=C_eqp(t1,lf[30]);
t3=lf[31] /* main#osx */ =t2;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:69: chicken.platform#software-version */
t5=C_fast_retrieve(lf[247]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k7793 in k3786 in k2504 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in ... */
static void C_ccall f_7795(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7795,2,av);}
a=C_alloc(3);
t2=C_eqp(t1,lf[28]);
t3=lf[29] /* main#mingw */ =t2;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:68: chicken.platform#software-version */
t5=C_fast_retrieve(lf[247]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k7804 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in ... */
static void C_ccall f_7806(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_7806,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t1;
/* egg-environment.scm:121: chicken.pathname#make-pathname */
t4=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
av2[3]=lf[431];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
/* egg-environment.scm:122: chicken.process-context#current-directory */
t3=C_fast_retrieve(lf[432]);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7807 in k7804 in k2501 in k2432 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in ... */
static void C_ccall f_7809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7809,2,av);}
/* egg-environment.scm:121: chicken.pathname#make-pathname */
t2=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[431];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7814 in k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in ... */
static void C_ccall f_7816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7816,2,av);}
/* egg-environment.scm:97: scheme#string-append */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[11],C_text("main#default-runlibdir"));
av2[3]=lf[435];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7819 in k2424 in k2420 in k2416 in k2412 in k2408 in k2404 in k2400 in k2396 in k2392 in k2388 in k2384 in k2380 in k2376 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in ... */
static void C_ccall f_7821(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7821,2,av);}
/* egg-environment.scm:94: scheme#string-append */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[10],C_text("main#default-libdir"));
av2[3]=lf[437];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7824 in k2372 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in ... */
static void C_ccall f_7826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7826,2,av);}
/* egg-environment.scm:77: chicken.pathname#make-pathname */
t2=C_fast_retrieve(lf[132]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[13],C_text("main#default-bindir"));
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7828 in k2368 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in ... */
static void C_ccall f_7830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7830,2,av);}
/* egg-environment.scm:74: scheme#string-append */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[13],C_text("main#default-bindir"));
av2[3]=lf[438];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7832 in k2364 in k2360 in k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in ... */
static void C_ccall f_7834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7834,2,av);}
/* egg-environment.scm:71: scheme#string-append */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[13],C_text("main#default-bindir"));
av2[3]=lf[439];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7839 in k2352 in k2348 in k2344 in k2340 in k2336 in k2332 in k2328 in k2324 in k2320 in k2316 in k2312 in k2308 in k2304 in k2300 in k2294 in k2288 in k2285 in k2282 in k2279 in k2276 in k2273 in ... */
static void C_ccall f_7841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7841,2,av);}
a=C_alloc(6);
t2=C_eqp(t1,lf[15]);
t3=(C_truep(t2)?C_mk_bool(C_WINDOWS_SHELL):lf[16]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_PREFIX);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point

void C_ccall C_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void*)C_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(2205))){
C_save(t1);
C_rereclaim2(2205*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,442);
lf[0]=C_h_intern(&lf[0],5, C_text("main#"));
lf[15]=C_h_intern(&lf[15],7, C_text("windows"));
lf[16]=C_h_intern(&lf[16],4, C_text("unix"));
lf[28]=C_h_intern(&lf[28],7, C_text("mingw32"));
lf[30]=C_h_intern(&lf[30],6, C_text("macosx"));
lf[32]=C_h_intern(&lf[32],6, C_text("cygwin"));
lf[34]=C_h_intern(&lf[34],3, C_text("aix"));
lf[37]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\005\001linux\376\003\000\000\002\376\001\000\000\006\001netbsd\376\003\000\000\002\376\001\000\000\007\001freebsd\376\003\000\000\002\376\001\000\000\007\001solaris\376\003\000\000\002\376\001\000\000\007\001"
"openbsd\376\003\000\000\002\376\001\000\000\004\001hurd\376\003\000\000\002\376\001\000\000\005\001haiku\376\377\016"));
lf[39]=C_h_intern(&lf[39],20, C_text("##sys#standard-error"));
lf[40]=C_h_intern(&lf[40],7, C_text("fprintf"));
lf[41]=C_h_intern(&lf[41],17, C_text("chicken.base#exit"));
lf[42]=C_h_intern(&lf[42],18, C_text("##sys#write-char-0"));
lf[43]=C_h_intern(&lf[43],22, C_text("chicken.format#fprintf"));
lf[44]=C_h_intern(&lf[44],11, C_text("##sys#print"));
lf[45]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002: "));
lf[46]=C_h_intern(&lf[46],19, C_text("##sys#peek-c-string"));
lf[48]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005-host"));
lf[51]=C_h_intern(&lf[51],18, C_text("chicken.process#qs"));
lf[52]=C_h_intern(&lf[52],31, C_text("chicken.string#string-translate"));
lf[53]=C_h_intern(&lf[53],35, C_text("chicken.pathname#normalize-pathname"));
lf[62]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003obj"));
lf[63]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001o"));
lf[66]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001a"));
lf[68]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[70]=C_h_intern(&lf[70],28, C_text("##sys#load-dynamic-extension"));
lf[76]=C_h_intern(&lf[76],20, C_text("scheme#string-append"));
lf[77]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003lib"));
lf[110]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016"));
lf[127]=C_h_intern(&lf[127],32, C_text("chicken.platform#repository-path"));
lf[129]=C_h_intern(&lf[129],22, C_text("chicken.load#find-file"));
lf[130]=C_h_intern(&lf[130],16, C_text("##sys#setup-mode"));
lf[131]=C_h_intern(&lf[131],25, C_text("chicken.file#file-exists\077"));
lf[132]=C_h_intern(&lf[132],30, C_text("chicken.pathname#make-pathname"));
lf[135]=C_h_intern(&lf[135],3, C_text("map"));
lf[136]=C_h_intern(&lf[136],33, C_text("chicken.string#string-intersperse"));
lf[137]=C_h_intern(&lf[137],13, C_text("scheme#append"));
lf[140]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-l"));
lf[142]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016"));
lf[144]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\042"));
lf[145]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\042"));
lf[146]=C_h_intern(&lf[146],32, C_text("chicken.string#string-translate\052"));
lf[147]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016"));
lf[148]=C_h_intern(&lf[148],18, C_text("##sys#list->string"));
lf[149]=C_h_intern(&lf[149],18, C_text("##sys#string->list"));
lf[152]=C_h_intern(&lf[152],21, C_text("##sys#standard-output"));
lf[153]=C_h_intern(&lf[153],6, C_text("printf"));
lf[154]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002: "));
lf[155]=C_decode_literal(C_heaptop,C_text("\376B\000\000;\012Error: shell command terminated with non-zero exit status "));
lf[156]=C_h_intern(&lf[156],22, C_text("chicken.process#system"));
lf[157]=C_h_intern(&lf[157],18, C_text("chicken.base#print"));
lf[158]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\042"));
lf[159]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\042"));
lf[160]=C_decode_literal(C_heaptop,C_text("\376B\000\000\037/usr/bin/env DYLD_LIBRARY_PATH="));
lf[161]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001 "));
lf[162]=C_h_intern(&lf[162],48, C_text("chicken.process-context#get-environment-variable"));
lf[163]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021DYLD_LIBRARY_PATH"));
lf[165]=C_h_intern(&lf[165],24, C_text("chicken.file#delete-file"));
lf[166]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003rm "));
lf[167]=C_h_intern(&lf[167],34, C_text("chicken.base#implicit-exit-handler"));
lf[168]=C_decode_literal(C_heaptop,C_text("\376B\000\000#not enough arguments to option `~A\047"));
lf[169]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\013-dynamiclib\376\377\016"));
lf[170]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\007-bundle\376\003\000\000\002\376B\000\000\034-headerpad_max_install_names\376\377\016"));
lf[171]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\007-shared\376\377\016"));
lf[172]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016"));
lf[173]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010-feature"));
lf[174]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026chicken-compile-shared"));
lf[175]=C_h_intern(&lf[175],43, C_text("chicken.pathname#pathname-replace-extension"));
lf[176]=C_h_intern(&lf[176],8, C_text("for-each"));
lf[177]=C_h_intern(&lf[177],6, C_text("format"));
lf[178]=C_h_intern(&lf[178],30, C_text("chicken.base#get-output-string"));
lf[179]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005mac.r"));
lf[180]=C_decode_literal(C_heaptop,C_text("\376B\000\000 /Developer/Tools/Rez -t APPL -o "));
lf[181]=C_h_intern(&lf[181],31, C_text("chicken.base#open-output-string"));
lf[182]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011 -change "));
lf[183]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007.dylib "));
lf[184]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001 "));
lf[185]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020@executable_path"));
lf[186]=C_h_intern(&lf[186],19, C_text("##sys#string-append"));
lf[187]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006.dylib"));
lf[188]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003-o "));
lf[189]=C_h_intern(&lf[189],15, C_text("scheme#string=\077"));
lf[190]=C_h_intern(&lf[190],14, C_text("scheme#reverse"));
lf[191]=C_h_intern(&lf[191],23, C_text("chicken.string#->string"));
lf[192]=C_decode_literal(C_heaptop,C_text("\376B\000\000#could not find linked extension: ~A"));
lf[193]=C_h_intern(&lf[193],27, C_text("scheme#with-input-from-file"));
lf[194]=C_h_intern(&lf[194],11, C_text("scheme#read"));
lf[195]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004link"));
lf[196]=C_h_intern(&lf[196],27, C_text("chicken.string#string-chomp"));
lf[197]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007.static"));
lf[198]=C_h_intern(&lf[198],41, C_text("chicken.pathname#pathname-strip-extension"));
lf[199]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004.old"));
lf[200]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004move"));
lf[201]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002mv"));
lf[202]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005.old\047"));
lf[203]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030\047 - renaming source to `"));
lf[204]=C_decode_literal(C_heaptop,C_text("\376B\000\0001Warning: output file will overwrite source file `"));
lf[205]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-c"));
lf[206]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003g++"));
lf[207]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022-Wno-write-strings"));
lf[208]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[209]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003-o "));
lf[210]=C_decode_literal(C_heaptop,C_text("\376B\000\000Pobject file generated from `~a\047 will overwrite explicitly given object file"
" `~a\047"));
lf[211]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001."));
lf[212]=C_decode_literal(C_heaptop,C_text("\376B\000\001\232\042\042 type=\042\042win32\042\042/>\134r\134n\042\012  \042  <ms_asmv2:trustInfo xmlns:ms_asmv2=\042\042urn:sche"
"mas-microsoft-com:asm.v2\042\042>\134r\134n\042\012  \042    <ms_asmv2:security>\134r\134n\042\012  \042      <ms_as"
"mv2:requestedPrivileges>\134r\134n\042\012  \042        <ms_asmv2:requestedExecutionLevel level"
"=\042\042asInvoker\042\042 uiAccess=\042\042false\042\042/>\134r\134n\042\012  \042      </ms_asmv2:requestedPrivileges"
">\134r\134n\042\012  \042    </ms_asmv2:security>\134r\134n\042\012  \042  </ms_asmv2:trustInfo>\134r\134n\042\012  \042</ass"
"embly>\134r\134n\042\012END"));
lf[213]=C_decode_literal(C_heaptop,C_text("\376B\000\001\0031 24 MOVEABLE PURE\012BEGIN\012  \042<\077xml version=\042\0421.0\042\042 encoding=\042\042UTF-8\042\042 standa"
"lone=\042\042yes\042\042\077>\134r\134n\042\012  \042<assembly xmlns=\042\042urn:schemas-microsoft-com:asm.v1\042\042 mani"
"festVersion=\042\0421.0\042\042>\134r\134n\042\012  \042  <assemblyIdentity version=\042\0421.0.0.0\042\042 processorAr"
"chitecture=\042\042\052\042\042 name=\042\042"));
lf[214]=C_h_intern(&lf[214],21, C_text("##sys#print-to-string"));
lf[215]=C_h_intern(&lf[215],26, C_text("scheme#with-output-to-file"));
lf[216]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013generating "));
lf[217]=C_h_intern(&lf[217],30, C_text("chicken.pathname#pathname-file"));
lf[218]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002rc"));
lf[219]=C_h_intern(&lf[219],30, C_text("chicken.platform#software-type"));
lf[220]=C_decode_literal(C_heaptop,C_text("\376B\000\000\031no source files specified"));
lf[221]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011bogus.scm"));
lf[222]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004link"));
lf[223]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001 "));
lf[224]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\003-:d\376\377\016"));
lf[225]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\025chicken-scheme-to-c++\376\377\016"));
lf[226]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\026chicken-scheme-to-objc\376\377\016"));
lf[227]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017-emit-link-file"));
lf[228]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004link"));
lf[229]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017-emit-link-file"));
lf[230]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016"));
lf[231]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014-output-file"));
lf[232]=C_decode_literal(C_heaptop,C_text("\376B\000\000KC file generated from `~a\047 will overwrite explicitly given source file `~a\047"
));
lf[233]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003cpp"));
lf[234]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001m"));
lf[235]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001c"));
lf[236]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010-dynamic"));
lf[237]=C_h_intern(&lf[237],14, C_text("scheme#newline"));
lf[238]=C_h_intern(&lf[238],19, C_text("chicken.base#print\052"));
lf[239]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-L"));
lf[240]=C_h_intern(&lf[240],27, C_text("chicken.string#string-split"));
lf[241]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002:;"));
lf[242]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026CHICKEN_C_LIBRARY_PATH"));
lf[243]=C_h_intern(&lf[243],7, C_text("freebsd"));
lf[244]=C_h_intern(&lf[244],7, C_text("openbsd"));
lf[245]=C_h_intern(&lf[245],6, C_text("netbsd"));
lf[246]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015-Wl,-z,origin"));
lf[247]=C_h_intern(&lf[247],33, C_text("chicken.platform#software-version"));
lf[248]=C_h_intern(&lf[248],19, C_text("chicken.string#conc"));
lf[249]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006-Wl,-R"));
lf[250]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007$ORIGIN"));
lf[251]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-L"));
lf[252]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007-Wl,-R\042"));
lf[253]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\042"));
lf[254]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-L"));
lf[255]=C_h_intern(&lf[255],5, C_text("-help"));
lf[256]=C_h_intern(&lf[256],6, C_text("--help"));
lf[257]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003\047.\012"));
lf[258]=C_decode_literal(C_heaptop,C_text("\376B\000)X\047 is a driver program for the CHICKEN compiler. Files given on the\012  comman"
"d line are translated, compiled or linked as needed.\012\012  FILENAME is a Scheme sou"
"rce file name with optional extension or a\012  C/C++/Objective-C source, object or"
" library file name with extension. OPTION\012  may be one of the following:\012\012  Gene"
"ral options:\012\012    -h  -help                      display this text and exit\012    "
"-v  -verbose                   show compiler notes and tool-invocations\012    -vv "
"                           display information about translation\012               "
"                     progress\012    -vvv                           display informa"
"tion about all compilation\012                                    stages\012    -versi"
"on                       display Scheme compiler version and exit\012    -release  "
"                     display release number and exit\012\012  File and pathname option"
"s:\012\012    -o -output-file FILENAME       specifies target executable name\012    -I -"
"include-path PATHNAME      specifies alternative path for included\012             "
"                       files\012    -to-stdout                     write compiler t"
"o stdout (implies -t)\012    -s -shared -dynamic            generate dynamically lo"
"adable shared object\012                                    file\012\012  Language option"
"s:\012\012    -D  -DSYMBOL  -feature SYMBOL  register feature identifier\012    -no-featu"
"re SYMBOL             disable builtin feature identifier\012    -c++               "
"            compile via a C++ source file (.cpp) \012    -objc                     "
"     compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012    -i"
" -case-insensitive           don\047t preserve case of read symbols    \012    -K -key"
"word-style STYLE        enable alternative keyword-syntax\012                      "
"              (prefix, suffix or none)\012       -no-parentheses-synonyms    disabl"
"es list delimiter synonyms\012       -no-symbol-escape           disables support f"
"or escaped symbols\012       -r5rs-syntax                disables the CHICKEN exten"
"sions to\012                                    R5RS syntax\012    -compile-syntax    "
"            macros are made available at run-time\012    -j -emit-import-library MO"
"DULE write compile-time module information into\012                                "
"    separate file\012    -J -emit-all-import-libraries  emit import-libraries for a"
"ll defined modules\012    -no-module-registration        do not generate module reg"
"istration code\012    -no-compiler-syntax            disable expansion of compiler-"
"macros\012    -m -module NAME                wrap compiled code in a module\012\012  Tran"
"slation options:\012\012    -x  -explicit-use              do not use units `library\047 "
"and `eval\047 by\012                                    default\012    -P  -check-syntax "
"             stop compilation after macro-expansion\012    -A  -analyze-only       "
"       stop compilation after first analysis pass\012\012  Debugging options:\012\012    -w "
" -no-warnings               disable warnings\012    -d0 -d1 -d2 -d3 -debug-level NU"
"MBER\012                                   set level of available debugging informa"
"tion\012    -no-trace                      disable rudimentary debugging informatio"
"n\012    -debug-info                    enable debug-information in compiled code f"
"or use\012                                    with an external debugger\012    -profil"
"e                       executable emits profiling information \012    -accumulate-"
"profile            executable emits profiling information in\012                   "
"                 append mode\012    -profile-name FILENAME         name of the gene"
"rated profile information\012                                    file\012    -consult-"
"types-file FILENAME   load additional type database\012\012  Optimization options:\012\012  "
"  -O -O0 -O1 -O2 -O3 -O4 -O5 -optimize-level NUMBER\012                            "
"       enable certain sets of optimization options\012    -optimize-leaf-routines  "
"      enable leaf routine optimization\012    -no-usual-integrations         standa"
"rd procedures may be redefined\012    -u  -unsafe                    disable safety"
" checks\012    -local                         assume globals are only modified in c"
"urrent\012                                    file\012    -b  -block                  "
"   enable block-compilation\012    -disable-interrupts            disable interrupt"
"s in compiled code\012    -f  -fixnum-arithmetic         assume all numbers are fix"
"nums\012    -disable-stack-overflow-checks disables detection of stack-overflows\012  "
"  -inline                        enable inlining\012    -inline-limit LIMIT        "
"    set inlining threshold\012    -inline-global                 enable cross-modul"
"e inlining\012    -specialize                    perform type-based specialization "
"of primitive calls\012    -oi -emit-inline-file FILENAME generate file with globall"
"y inlinable\012                                    procedures (implies -inline -loc"
"al)\012    -consult-inline-file FILENAME  explicitly load inline file\012    -ot  -emi"
"t-types-file FILENAME write type-declaration information into file\012    -no-argc-"
"checks                disable argument count checks\012    -no-bound-checks        "
"       disable bound variable checks\012    -no-procedure-checks           disable "
"procedure call checks\012    -no-procedure-checks-for-usual-bindings\012              "
"                     disable procedure call checks only for usual\012              "
"                      bindings\012    -no-procedure-checks-for-toplevel-bindings\012  "
"                                 disable procedure call checks for toplevel\012    "
"                                bindings\012    -strict-types                  assu"
"me variable do not change their type\012    -clustering                    combine "
"groups of local procedures into dispatch\012                                     lo"
"op\012    -lfa2                          perform additional lightweight flow-analys"
"is pass\012\012  Configuration options:\012\012    -unit NAME                     compile fi"
"le as a library unit\012    -uses NAME                     declare library unit as "
"used.\012    -heap-size NUMBER              specifies heap-size of compiled executa"
"ble\012    -nursery NUMBER  -stack-size NUMBER\012                                   s"
"pecifies nursery size of compiled\012                                   executable\012"
"    -X -extend FILENAME            load file before compilation commences\012    -p"
"relude EXPRESSION            add expression to beginning of source file\012    -pos"
"tlude EXPRESSION           add expression to end of source file\012    -prologue FI"
"LENAME             include file before main source file\012    -epilogue FILENAME  "
"           include file after main source file\012\012    -e  -embedded               "
"   compile as embedded\012                                    (don\047t generate `main"
"()\047)\012    -gui                           compile as GUI application\012    -link NAM"
"E                     link extension with compiled executable\012                  "
"                  (implies -uses)\012    -R  -require-extension NAME    require ext"
"ension and import in compiled\012                                    code\012    -dll "
"-library                  compile multiple units into a dynamic\012                "
"                    library\012    -libdir DIRECTORY              override director"
"y for runtime library\012\012  Options to other passes:\012\012    -C OPTION                "
"      pass option to C compiler\012    -L OPTION                      pass option t"
"o linker\012    -I<DIR>                        pass \134\042-I<DIR>\134\042 to C compiler\012     "
"                               (add include path)\012    -L<DIR>                   "
"     pass \134\042-L<DIR>\134\042 to linker\012                                    (add library"
" path)\012    -k                             keep intermediate files\012    -c        "
"                     stop after compilation to object files\012    -t              "
"               stop after translation to C\012    -cc COMPILER                   se"
"lect other C compiler than the default\012    -cxx COMPILER                  select"
" other C++ compiler than the default\012    -ld COMPILER                   select o"
"ther linker than the default \012    -static                        link with stati"
"c CHICKEN libraries and\012                                    extensions (if possi"
"ble)\012    -F<DIR>                        pass \134\042-F<DIR>\134\042 to C compiler\012         "
"                           (add framework header path on Mac OS X)\012    -framewor"
"k NAME                passed to linker on Mac OS X\012    -rpath PATHNAME          "
"      add directory to runtime library search path\012    -Wl,...                  "
"      pass linker options\012    -strip                         strip resulting bin"
"ary\012\012  Inquiry options:\012\012    -home                          show home-directory "
"(where support files go)\012    -cflags                        show required C-comp"
"iler flags and exit\012    -ldflags                       show required linker flag"
"s and exit\012    -libs                          show required libraries and exit\012 "
"   -cc-name                       show name of default C compiler used\012    -cxx-"
"name                      show name of default C++ compiler used\012    -ld-name   "
"                    show name of default linker used\012    -dry-run               "
"        just show commands executed, don\047t run them\012                            "
"        (implies `-v\047)\012\012  Obscure options:\012\012    -debug MODES                   d"
"isplay debugging output for the given modes\012    -compiler PATHNAME             u"
"se other compiler than default `chicken\047\012    -raw                           do n"
"ot generate implicit init- and exit code\012    -emit-external-prototypes-first\012   "
"                                emit prototypes for callbacks before foreign\012   "
"                                 declarations\012    -regenerate-import-libraries  "
" emit import libraries even when unchanged\012    -ignore-repository             do"
" not refer to repository for extensions\012    -keep-shadowed-macros          do no"
"t remove shadowed macro\012    -host                          compile for host when"
" configured for\012                                    cross-compiling\012    -private"
"-repository            load extensions from executable path\012    -deployed       "
"               link support file to be used from a deployed \012                   "
"                 executable (sets `rpath\047 accordingly, if supported\012            "
"                        on this platform)\012    -no-elevation                  emb"
"ed manifest on Windows to supress elevation\012                                    "
"warnings for programs named `install\047 or `setup\047\012\012  Options can be collapsed if "
"unambiguous, so\012\012    -vkfO\012\012  is the same as\012\012    -v -k -fixnum-arithmetic -opti"
"mize\012\012  The contents of the environment variable CSC_OPTIONS are implicitly pass"
"ed to\012  every invocation of `"));
lf[259]=C_decode_literal(C_heaptop,C_text("\376B\000\000! [OPTION ...] [FILENAME ...]\012\012  `"));
lf[260]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007Usage: "));
lf[261]=C_h_intern(&lf[261],8, C_text("-release"));
lf[262]=C_h_intern(&lf[262],32, C_text("chicken.platform#chicken-version"));
lf[263]=C_h_intern(&lf[263],8, C_text("-version"));
lf[264]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011 -version"));
lf[265]=C_h_intern(&lf[265],4, C_text("-c++"));
lf[266]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017-no-cpp-precomp"));
lf[267]=C_h_intern(&lf[267],5, C_text("-objc"));
lf[268]=C_h_intern(&lf[268],7, C_text("-static"));
lf[269]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007-static"));
lf[270]=C_h_intern(&lf[270],7, C_text("-cflags"));
lf[271]=C_h_intern(&lf[271],8, C_text("-ldflags"));
lf[272]=C_h_intern(&lf[272],8, C_text("-cc-name"));
lf[273]=C_h_intern(&lf[273],9, C_text("-cxx-name"));
lf[274]=C_h_intern(&lf[274],8, C_text("-ld-name"));
lf[275]=C_h_intern(&lf[275],5, C_text("-home"));
lf[276]=C_h_intern(&lf[276],5, C_text("-libs"));
lf[277]=C_h_intern(&lf[277],2, C_text("-v"));
lf[278]=C_h_intern(&lf[278],8, C_text("-verbose"));
lf[279]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010-verbose"));
lf[280]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-v"));
lf[281]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-v"));
lf[282]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-Q"));
lf[283]=C_h_intern(&lf[283],2, C_text("-w"));
lf[284]=C_h_intern(&lf[284],12, C_text("-no-warnings"));
lf[285]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-w"));
lf[286]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014-no-warnings"));
lf[287]=C_h_intern(&lf[287],2, C_text("-A"));
lf[288]=C_h_intern(&lf[288],13, C_text("-analyze-only"));
lf[289]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015-analyze-only"));
lf[290]=C_h_intern(&lf[290],2, C_text("-P"));
lf[291]=C_h_intern(&lf[291],13, C_text("-check-syntax"));
lf[292]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015-check-syntax"));
lf[293]=C_h_intern(&lf[293],2, C_text("-k"));
lf[294]=C_h_intern(&lf[294],2, C_text("-c"));
lf[295]=C_h_intern(&lf[295],2, C_text("-t"));
lf[296]=C_h_intern(&lf[296],2, C_text("-e"));
lf[297]=C_h_intern(&lf[297],9, C_text("-embedded"));
lf[298]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014-DC_EMBEDDED"));
lf[299]=C_h_intern(&lf[299],5, C_text("-link"));
lf[300]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002, "));
lf[301]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005-uses"));
lf[302]=C_h_intern(&lf[302],7, C_text("-libdir"));
lf[303]=C_h_intern(&lf[303],18, C_text("-require-extension"));
lf[304]=C_h_intern(&lf[304],2, C_text("-R"));
lf[305]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022-require-extension"));
lf[306]=C_h_intern(&lf[306],19, C_text("-private-repository"));
lf[307]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026-DC_PRIVATE_REPOSITORY"));
lf[308]=C_h_intern(&lf[308],18, C_text("-ignore-repository"));
lf[309]=C_h_intern(&lf[309],11, C_text("-setup-mode"));
lf[310]=C_h_intern(&lf[310],13, C_text("-no-elevation"));
lf[311]=C_h_intern(&lf[311],4, C_text("-gui"));
lf[312]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007-DC_GUI"));
lf[313]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012-lkernel32"));
lf[314]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010-luser32"));
lf[315]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007-lgdi32"));
lf[316]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011-mwindows"));
lf[317]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012chicken.rc"));
lf[318]=C_h_intern(&lf[318],9, C_text("-deployed"));
lf[319]=C_h_intern(&lf[319],10, C_text("-framework"));
lf[320]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012-framework"));
lf[321]=C_h_intern(&lf[321],2, C_text("-o"));
lf[322]=C_h_intern(&lf[322],12, C_text("-output-file"));
lf[323]=C_h_intern(&lf[323],2, C_text("-O"));
lf[324]=C_h_intern(&lf[324],3, C_text("-O1"));
lf[325]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017-optimize-level"));
lf[326]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0011"));
lf[327]=C_h_intern(&lf[327],3, C_text("-O0"));
lf[328]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017-optimize-level"));
lf[329]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0010"));
lf[330]=C_h_intern(&lf[330],3, C_text("-O2"));
lf[331]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017-optimize-level"));
lf[332]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0012"));
lf[333]=C_h_intern(&lf[333],3, C_text("-O3"));
lf[334]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017-optimize-level"));
lf[335]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0013"));
lf[336]=C_h_intern(&lf[336],3, C_text("-O4"));
lf[337]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017-optimize-level"));
lf[338]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0014"));
lf[339]=C_h_intern(&lf[339],3, C_text("-O5"));
lf[340]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017-optimize-level"));
lf[341]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0015"));
lf[342]=C_h_intern(&lf[342],3, C_text("-d0"));
lf[343]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014-debug-level"));
lf[344]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0010"));
lf[345]=C_h_intern(&lf[345],3, C_text("-d1"));
lf[346]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014-debug-level"));
lf[347]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0011"));
lf[348]=C_h_intern(&lf[348],3, C_text("-d2"));
lf[349]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014-debug-level"));
lf[350]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0012"));
lf[351]=C_h_intern(&lf[351],3, C_text("-d3"));
lf[352]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014-debug-level"));
lf[353]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0013"));
lf[354]=C_h_intern(&lf[354],6, C_text("-debug"));
lf[355]=C_h_intern(&lf[355],8, C_text("-dry-run"));
lf[356]=C_h_intern(&lf[356],2, C_text("-s"));
lf[357]=C_h_intern(&lf[357],4, C_text("-dll"));
lf[358]=C_h_intern(&lf[358],8, C_text("-library"));
lf[359]=C_h_intern(&lf[359],9, C_text("-compiler"));
lf[360]=C_h_intern(&lf[360],3, C_text("-cc"));
lf[361]=C_h_intern(&lf[361],4, C_text("-cxx"));
lf[362]=C_h_intern(&lf[362],3, C_text("-ld"));
lf[363]=C_h_intern(&lf[363],2, C_text("-I"));
lf[364]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015-include-path"));
lf[365]=C_h_intern(&lf[365],2, C_text("-C"));
lf[366]=C_h_intern(&lf[366],6, C_text("-strip"));
lf[367]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-s"));
lf[368]=C_h_intern(&lf[368],2, C_text("-L"));
lf[369]=C_h_intern(&lf[369],6, C_text("-rpath"));
lf[370]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006-Wl,-R"));
lf[371]=C_h_intern(&lf[371],3, C_text("gnu"));
lf[372]=C_h_intern(&lf[372],5, C_text("clang"));
lf[373]=C_h_intern(&lf[373],31, C_text("chicken.platform#build-platform"));
lf[374]=C_h_intern(&lf[374],5, C_text("-host"));
lf[375]=C_h_intern(&lf[375],3, C_text("-oi"));
lf[376]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021-emit-inline-file"));
lf[377]=C_h_intern(&lf[377],3, C_text("-ot"));
lf[378]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020-emit-types-file"));
lf[379]=C_h_intern(&lf[379],1, C_text("-"));
lf[380]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001a"));
lf[381]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\001-\376\377\016"));
lf[382]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376"
"\003\000\000\002\376\001\000\000\002\001-m\376\003\000\000\002\376B\000\000\007-module\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\002\001-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001-D\376\003\000\000\002\376B\000\000\010-featur"
"e\376\377\016\376\003\000\000\002\376\003\000\000\002\376\016\000\000\002\376\377\001\000\000\000\000\376\377\001\377\377\377\377\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001-"
"K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001-X\376\003\000\000\002\376B\000\000\007-extend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\002\001-J\376\003\000\000\002\376B\000\000\032-emit-all-import-libraries\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001-N\376\003\000\000\002\376B\000\000\027-no-modul"
"e-registration\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001-u\376"
"\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001-j\376\003\000\000\002\376B\000\000\024-emit-import-library\376\377\016\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\002\001-b\376\003\000\000\002\376B\000\000\006-block\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001-types\376\003\000\000\002\376B\000\000\023-consult-types-file\376\377"
"\016\376\377\016"));
lf[383]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\015\001-explicit-use\376\003\000\000\002\376\001\000\000\011\001-no-trace\376\003\000\000\002\376\001\000\000\014\001-no-warnings\376\003\000\000\002\376\001\000\000\026\001-n"
"o-usual-integrations\376\003\000\000\002\376\001\000\000\027\001-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007\001-unsafe\376\003\000\000\002\376\001\000"
"\000\006\001-block\376\003\000\000\002\376\001\000\000\023\001-disable-interrupts\376\003\000\000\002\376\001\000\000\022\001-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012\001-"
"to-stdout\376\003\000\000\002\376\001\000\000\010\001-profile\376\003\000\000\002\376\001\000\000\004\001-raw\376\003\000\000\002\376\001\000\000\023\001-accumulate-profile\376\003\000\000\002\376\001"
"\000\000\015\001-check-syntax\376\003\000\000\002\376\001\000\000\021\001-case-insensitive\376\003\000\000\002\376\001\000\000\007\001-shared\376\003\000\000\002\376\001\000\000\017\001-compi"
"le-syntax\376\003\000\000\002\376\001\000\000\017\001-no-lambda-info\376\003\000\000\002\376\001\000\000\010\001-dynamic\376\003\000\000\002\376\001\000\000\036\001-disable-stack-"
"overflow-checks\376\003\000\000\002\376\001\000\000\006\001-local\376\003\000\000\002\376\001\000\000\037\001-emit-external-prototypes-first\376\003\000\000\002\376"
"\001\000\000\007\001-inline\376\003\000\000\002\376\001\000\000\010\001-release\376\003\000\000\002\376\001\000\000\015\001-analyze-only\376\003\000\000\002\376\001\000\000\025\001-keep-shadowed"
"-macros\376\003\000\000\002\376\001\000\000\016\001-inline-global\376\003\000\000\002\376\001\000\000\022\001-ignore-repository\376\003\000\000\002\376\001\000\000\021\001-no-symb"
"ol-escape\376\003\000\000\002\376\001\000\000\030\001-no-parentheses-synonyms\376\003\000\000\002\376\001\000\000\014\001-r5rs-syntax\376\003\000\000\002\376\001\000\000\017\001-n"
"o-argc-checks\376\003\000\000\002\376\001\000\000\020\001-no-bound-checks\376\003\000\000\002\376\001\000\000\024\001-no-procedure-checks\376\003\000\000\002\376\001\000\000"
"\023\001-no-compiler-syntax\376\003\000\000\002\376\001\000\000\032\001-emit-all-import-libraries\376\003\000\000\002\376\001\000\000\015\001-no-elevati"
"on\376\003\000\000\002\376\001\000\000\027\001-no-module-registration\376\003\000\000\002\376\001\000\000\047\001-no-procedure-checks-for-usual-bi"
"ndings\376\003\000\000\002\376\001\000\000\034\001-regenerate-import-libraries\376\003\000\000\002\376\001\000\000\013\001-specialize\376\003\000\000\002\376\001\000\000\015\001-s"
"trict-types\376\003\000\000\002\376\001\000\000\013\001-clustering\376\003\000\000\002\376\001\000\000\005\001-lfa2\376\003\000\000\002\376\001\000\000\013\001-debug-info\376\003\000\000\002\376\001\000\000"
"\052\001-no-procedure-checks-for-toplevel-bindings\376\377\016"));
lf[384]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001-debug\376\003\000\000\002\376\001\000\000\012\001-heap-size\376\003\000\000\002\376\001\000\000\010\001-nursery\376\003\000\000\002\376\001\000\000\013\001-stack-size\376"
"\003\000\000\002\376\001\000\000\011\001-compiler\376\003\000\000\002\376\001\000\000\005\001-unit\376\003\000\000\002\376\001\000\000\005\001-uses\376\003\000\000\002\376\001\000\000\016\001-keyword-style\376\003\000\000"
"\002\376\001\000\000\017\001-optimize-level\376\003\000\000\002\376\001\000\000\015\001-include-path\376\003\000\000\002\376\001\000\000\016\001-database-size\376\003\000\000\002\376\001\000\000"
"\007\001-extend\376\003\000\000\002\376\001\000\000\010\001-prelude\376\003\000\000\002\376\001\000\000\011\001-postlude\376\003\000\000\002\376\001\000\000\011\001-prologue\376\003\000\000\002\376\001\000\000\011\001-"
"epilogue\376\003\000\000\002\376\001\000\000\017\001-emit-link-file\376\003\000\000\002\376\001\000\000\015\001-inline-limit\376\003\000\000\002\376\001\000\000\015\001-profile-na"
"me\376\003\000\000\002\376\001\000\000\021\001-emit-inline-file\376\003\000\000\002\376\001\000\000\024\001-consult-inline-file\376\003\000\000\002\376\001\000\000\020\001-emit-ty"
"pes-file\376\003\000\000\002\376\001\000\000\023\001-consult-types-file\376\003\000\000\002\376\001\000\000\010\001-feature\376\003\000\000\002\376\001\000\000\014\001-debug-level"
"\376\003\000\000\002\376\001\000\000\024\001-emit-import-library\376\003\000\000\002\376\001\000\000\007\001-module\376\003\000\000\002\376\001\000\000\005\001-link\376\003\000\000\002\376\001\000\000\013\001-no-"
"feature\376\377\016"));
lf[385]=C_h_intern(&lf[385],18, C_text("chicken.base#error"));
lf[386]=C_decode_literal(C_heaptop,C_text("\376B\000\000-bad -L argument, <DIR> starts with whitespace"));
lf[387]=C_decode_literal(C_heaptop,C_text("\376B\000\000-bad -I argument: <DIR> starts with whitespace"));
lf[388]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010-feature"));
lf[389]=C_h_intern(&lf[389],16, C_text("scheme#substring"));
lf[390]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001-"));
lf[391]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023invalid option `~A\047"));
lf[392]=C_h_intern(&lf[392],5, C_text("foldr"));
lf[393]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023invalid option `~A\047"));
lf[394]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004-Wl,"));
lf[395]=C_h_intern(&lf[395],35, C_text("chicken.pathname#decompose-pathname"));
lf[396]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001h"));
lf[397]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001c"));
lf[398]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002rc"));
lf[399]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003cpp"));
lf[400]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001C"));
lf[401]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002cc"));
lf[402]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003cxx"));
lf[403]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003hpp"));
lf[404]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017-no-cpp-precomp"));
lf[405]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001m"));
lf[406]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001M"));
lf[407]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002mm"));
lf[408]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030file `~A\047 does not exist"));
lf[409]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004.scm"));
lf[410]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-:"));
lf[411]=C_h_intern(&lf[411],15, C_text("-optimize-level"));
lf[412]=C_h_intern(&lf[412],15, C_text("-benchmark-mode"));
lf[413]=C_h_intern(&lf[413],10, C_text("-to-stdout"));
lf[414]=C_h_intern(&lf[414],7, C_text("-shared"));
lf[415]=C_h_intern(&lf[415],8, C_text("-dynamic"));
lf[416]=C_h_intern(&lf[416],21, C_text("scheme#string->symbol"));
lf[417]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[418]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013CSC_OPTIONS"));
lf[419]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-I"));
lf[420]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002:;"));
lf[421]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026CHICKEN_C_INCLUDE_PATH"));
lf[422]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-I"));
lf[423]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030PHhsfiENxubvwAOeWkctgSJM"));
lf[424]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016"));
lf[425]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016"));
lf[426]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007static."));
lf[427]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007static."));
lf[428]=C_h_intern(&lf[428],25, C_text("chicken.platform#feature\077"));
lf[429]=C_h_intern_kw(&lf[429],13, C_text("cross-chicken"));
lf[430]=C_h_intern(&lf[430],46, C_text("chicken.process-context#command-line-arguments"));
lf[431]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017chicken-install"));
lf[432]=C_h_intern(&lf[432],41, C_text("chicken.process-context#current-directory"));
lf[433]=C_h_intern(&lf[433],39, C_text("chicken.platform#system-cache-directory"));
lf[434]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021CHICKEN_EGG_CACHE"));
lf[435]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011/chicken/"));
lf[436]=C_h_intern(&lf[436],20, C_text("##sys#fixnum->string"));
lf[437]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011/chicken/"));
lf[438]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001/"));
lf[439]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001/"));
lf[440]=C_h_intern(&lf[440],30, C_text("##sys#register-compiled-module"));
lf[441]=C_h_intern(&lf[441],4, C_text("main"));
C_register_lf2(lf,442,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2266,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[480] = {
{C_text("f8584:csc_2escm"),(void*)f8584},
{C_text("f8590:csc_2escm"),(void*)f8590},
{C_text("f8594:csc_2escm"),(void*)f8594},
{C_text("f8616:csc_2escm"),(void*)f8616},
{C_text("f8662:csc_2escm"),(void*)f8662},
{C_text("f_2266:csc_2escm"),(void*)f_2266},
{C_text("f_2269:csc_2escm"),(void*)f_2269},
{C_text("f_2272:csc_2escm"),(void*)f_2272},
{C_text("f_2275:csc_2escm"),(void*)f_2275},
{C_text("f_2278:csc_2escm"),(void*)f_2278},
{C_text("f_2281:csc_2escm"),(void*)f_2281},
{C_text("f_2284:csc_2escm"),(void*)f_2284},
{C_text("f_2287:csc_2escm"),(void*)f_2287},
{C_text("f_2290:csc_2escm"),(void*)f_2290},
{C_text("f_2296:csc_2escm"),(void*)f_2296},
{C_text("f_2302:csc_2escm"),(void*)f_2302},
{C_text("f_2306:csc_2escm"),(void*)f_2306},
{C_text("f_2310:csc_2escm"),(void*)f_2310},
{C_text("f_2314:csc_2escm"),(void*)f_2314},
{C_text("f_2318:csc_2escm"),(void*)f_2318},
{C_text("f_2322:csc_2escm"),(void*)f_2322},
{C_text("f_2326:csc_2escm"),(void*)f_2326},
{C_text("f_2330:csc_2escm"),(void*)f_2330},
{C_text("f_2334:csc_2escm"),(void*)f_2334},
{C_text("f_2338:csc_2escm"),(void*)f_2338},
{C_text("f_2342:csc_2escm"),(void*)f_2342},
{C_text("f_2346:csc_2escm"),(void*)f_2346},
{C_text("f_2350:csc_2escm"),(void*)f_2350},
{C_text("f_2354:csc_2escm"),(void*)f_2354},
{C_text("f_2362:csc_2escm"),(void*)f_2362},
{C_text("f_2366:csc_2escm"),(void*)f_2366},
{C_text("f_2370:csc_2escm"),(void*)f_2370},
{C_text("f_2374:csc_2escm"),(void*)f_2374},
{C_text("f_2378:csc_2escm"),(void*)f_2378},
{C_text("f_2382:csc_2escm"),(void*)f_2382},
{C_text("f_2386:csc_2escm"),(void*)f_2386},
{C_text("f_2390:csc_2escm"),(void*)f_2390},
{C_text("f_2394:csc_2escm"),(void*)f_2394},
{C_text("f_2398:csc_2escm"),(void*)f_2398},
{C_text("f_2402:csc_2escm"),(void*)f_2402},
{C_text("f_2406:csc_2escm"),(void*)f_2406},
{C_text("f_2410:csc_2escm"),(void*)f_2410},
{C_text("f_2414:csc_2escm"),(void*)f_2414},
{C_text("f_2418:csc_2escm"),(void*)f_2418},
{C_text("f_2422:csc_2escm"),(void*)f_2422},
{C_text("f_2426:csc_2escm"),(void*)f_2426},
{C_text("f_2430:csc_2escm"),(void*)f_2430},
{C_text("f_2434:csc_2escm"),(void*)f_2434},
{C_text("f_2503:csc_2escm"),(void*)f_2503},
{C_text("f_2506:csc_2escm"),(void*)f_2506},
{C_text("f_2941:csc_2escm"),(void*)f_2941},
{C_text("f_2947:csc_2escm"),(void*)f_2947},
{C_text("f_2961:csc_2escm"),(void*)f_2961},
{C_text("f_3003:csc_2escm"),(void*)f_3003},
{C_text("f_3016:csc_2escm"),(void*)f_3016},
{C_text("f_3030:csc_2escm"),(void*)f_3030},
{C_text("f_3078:csc_2escm"),(void*)f_3078},
{C_text("f_3092:csc_2escm"),(void*)f_3092},
{C_text("f_3105:csc_2escm"),(void*)f_3105},
{C_text("f_3126:csc_2escm"),(void*)f_3126},
{C_text("f_3134:csc_2escm"),(void*)f_3134},
{C_text("f_3141:csc_2escm"),(void*)f_3141},
{C_text("f_3155:csc_2escm"),(void*)f_3155},
{C_text("f_3170:csc_2escm"),(void*)f_3170},
{C_text("f_3178:csc_2escm"),(void*)f_3178},
{C_text("f_3182:csc_2escm"),(void*)f_3182},
{C_text("f_3186:csc_2escm"),(void*)f_3186},
{C_text("f_3204:csc_2escm"),(void*)f_3204},
{C_text("f_3283:csc_2escm"),(void*)f_3283},
{C_text("f_3383:csc_2escm"),(void*)f_3383},
{C_text("f_3405:csc_2escm"),(void*)f_3405},
{C_text("f_3416:csc_2escm"),(void*)f_3416},
{C_text("f_3788:csc_2escm"),(void*)f_3788},
{C_text("f_3814:csc_2escm"),(void*)f_3814},
{C_text("f_3817:csc_2escm"),(void*)f_3817},
{C_text("f_3824:csc_2escm"),(void*)f_3824},
{C_text("f_3827:csc_2escm"),(void*)f_3827},
{C_text("f_3830:csc_2escm"),(void*)f_3830},
{C_text("f_3833:csc_2escm"),(void*)f_3833},
{C_text("f_3840:csc_2escm"),(void*)f_3840},
{C_text("f_3844:csc_2escm"),(void*)f_3844},
{C_text("f_3848:csc_2escm"),(void*)f_3848},
{C_text("f_3866:csc_2escm"),(void*)f_3866},
{C_text("f_3874:csc_2escm"),(void*)f_3874},
{C_text("f_3878:csc_2escm"),(void*)f_3878},
{C_text("f_3880:csc_2escm"),(void*)f_3880},
{C_text("f_3888:csc_2escm"),(void*)f_3888},
{C_text("f_3896:csc_2escm"),(void*)f_3896},
{C_text("f_3900:csc_2escm"),(void*)f_3900},
{C_text("f_3904:csc_2escm"),(void*)f_3904},
{C_text("f_3908:csc_2escm"),(void*)f_3908},
{C_text("f_3912:csc_2escm"),(void*)f_3912},
{C_text("f_3916:csc_2escm"),(void*)f_3916},
{C_text("f_3929:csc_2escm"),(void*)f_3929},
{C_text("f_3933:csc_2escm"),(void*)f_3933},
{C_text("f_3938:csc_2escm"),(void*)f_3938},
{C_text("f_3941:csc_2escm"),(void*)f_3941},
{C_text("f_3949:csc_2escm"),(void*)f_3949},
{C_text("f_3984:csc_2escm"),(void*)f_3984},
{C_text("f_3988:csc_2escm"),(void*)f_3988},
{C_text("f_3993:csc_2escm"),(void*)f_3993},
{C_text("f_3998:csc_2escm"),(void*)f_3998},
{C_text("f_4005:csc_2escm"),(void*)f_4005},
{C_text("f_4035:csc_2escm"),(void*)f_4035},
{C_text("f_4049:csc_2escm"),(void*)f_4049},
{C_text("f_4053:csc_2escm"),(void*)f_4053},
{C_text("f_4069:csc_2escm"),(void*)f_4069},
{C_text("f_4088:csc_2escm"),(void*)f_4088},
{C_text("f_4103:csc_2escm"),(void*)f_4103},
{C_text("f_4107:csc_2escm"),(void*)f_4107},
{C_text("f_4111:csc_2escm"),(void*)f_4111},
{C_text("f_4114:csc_2escm"),(void*)f_4114},
{C_text("f_4127:csc_2escm"),(void*)f_4127},
{C_text("f_4132:csc_2escm"),(void*)f_4132},
{C_text("f_4157:csc_2escm"),(void*)f_4157},
{C_text("f_4177:csc_2escm"),(void*)f_4177},
{C_text("f_4185:csc_2escm"),(void*)f_4185},
{C_text("f_4189:csc_2escm"),(void*)f_4189},
{C_text("f_4193:csc_2escm"),(void*)f_4193},
{C_text("f_4209:csc_2escm"),(void*)f_4209},
{C_text("f_4216:csc_2escm"),(void*)f_4216},
{C_text("f_4226:csc_2escm"),(void*)f_4226},
{C_text("f_4238:csc_2escm"),(void*)f_4238},
{C_text("f_4242:csc_2escm"),(void*)f_4242},
{C_text("f_4245:csc_2escm"),(void*)f_4245},
{C_text("f_4248:csc_2escm"),(void*)f_4248},
{C_text("f_4251:csc_2escm"),(void*)f_4251},
{C_text("f_4254:csc_2escm"),(void*)f_4254},
{C_text("f_4260:csc_2escm"),(void*)f_4260},
{C_text("f_4266:csc_2escm"),(void*)f_4266},
{C_text("f_4278:csc_2escm"),(void*)f_4278},
{C_text("f_4288:csc_2escm"),(void*)f_4288},
{C_text("f_4292:csc_2escm"),(void*)f_4292},
{C_text("f_4298:csc_2escm"),(void*)f_4298},
{C_text("f_4310:csc_2escm"),(void*)f_4310},
{C_text("f_4317:csc_2escm"),(void*)f_4317},
{C_text("f_4350:csc_2escm"),(void*)f_4350},
{C_text("f_4355:csc_2escm"),(void*)f_4355},
{C_text("f_4357:csc_2escm"),(void*)f_4357},
{C_text("f_4383:csc_2escm"),(void*)f_4383},
{C_text("f_4388:csc_2escm"),(void*)f_4388},
{C_text("f_4392:csc_2escm"),(void*)f_4392},
{C_text("f_4396:csc_2escm"),(void*)f_4396},
{C_text("f_4413:csc_2escm"),(void*)f_4413},
{C_text("f_4429:csc_2escm"),(void*)f_4429},
{C_text("f_4440:csc_2escm"),(void*)f_4440},
{C_text("f_4444:csc_2escm"),(void*)f_4444},
{C_text("f_4447:csc_2escm"),(void*)f_4447},
{C_text("f_4450:csc_2escm"),(void*)f_4450},
{C_text("f_4456:csc_2escm"),(void*)f_4456},
{C_text("f_4462:csc_2escm"),(void*)f_4462},
{C_text("f_4465:csc_2escm"),(void*)f_4465},
{C_text("f_4477:csc_2escm"),(void*)f_4477},
{C_text("f_4480:csc_2escm"),(void*)f_4480},
{C_text("f_4483:csc_2escm"),(void*)f_4483},
{C_text("f_4486:csc_2escm"),(void*)f_4486},
{C_text("f_4489:csc_2escm"),(void*)f_4489},
{C_text("f_4492:csc_2escm"),(void*)f_4492},
{C_text("f_4499:csc_2escm"),(void*)f_4499},
{C_text("f_4505:csc_2escm"),(void*)f_4505},
{C_text("f_4508:csc_2escm"),(void*)f_4508},
{C_text("f_4511:csc_2escm"),(void*)f_4511},
{C_text("f_4514:csc_2escm"),(void*)f_4514},
{C_text("f_4517:csc_2escm"),(void*)f_4517},
{C_text("f_4520:csc_2escm"),(void*)f_4520},
{C_text("f_4527:csc_2escm"),(void*)f_4527},
{C_text("f_4531:csc_2escm"),(void*)f_4531},
{C_text("f_4549:csc_2escm"),(void*)f_4549},
{C_text("f_4553:csc_2escm"),(void*)f_4553},
{C_text("f_4559:csc_2escm"),(void*)f_4559},
{C_text("f_4566:csc_2escm"),(void*)f_4566},
{C_text("f_4583:csc_2escm"),(void*)f_4583},
{C_text("f_4593:csc_2escm"),(void*)f_4593},
{C_text("f_4597:csc_2escm"),(void*)f_4597},
{C_text("f_4606:csc_2escm"),(void*)f_4606},
{C_text("f_4609:csc_2escm"),(void*)f_4609},
{C_text("f_4616:csc_2escm"),(void*)f_4616},
{C_text("f_4633:csc_2escm"),(void*)f_4633},
{C_text("f_4636:csc_2escm"),(void*)f_4636},
{C_text("f_4639:csc_2escm"),(void*)f_4639},
{C_text("f_4642:csc_2escm"),(void*)f_4642},
{C_text("f_4652:csc_2escm"),(void*)f_4652},
{C_text("f_4659:csc_2escm"),(void*)f_4659},
{C_text("f_4666:csc_2escm"),(void*)f_4666},
{C_text("f_4670:csc_2escm"),(void*)f_4670},
{C_text("f_4677:csc_2escm"),(void*)f_4677},
{C_text("f_4680:csc_2escm"),(void*)f_4680},
{C_text("f_4692:csc_2escm"),(void*)f_4692},
{C_text("f_4704:csc_2escm"),(void*)f_4704},
{C_text("f_4711:csc_2escm"),(void*)f_4711},
{C_text("f_4720:csc_2escm"),(void*)f_4720},
{C_text("f_4727:csc_2escm"),(void*)f_4727},
{C_text("f_4733:csc_2escm"),(void*)f_4733},
{C_text("f_4736:csc_2escm"),(void*)f_4736},
{C_text("f_4739:csc_2escm"),(void*)f_4739},
{C_text("f_4742:csc_2escm"),(void*)f_4742},
{C_text("f_4799:csc_2escm"),(void*)f_4799},
{C_text("f_4811:csc_2escm"),(void*)f_4811},
{C_text("f_4823:csc_2escm"),(void*)f_4823},
{C_text("f_4835:csc_2escm"),(void*)f_4835},
{C_text("f_4858:csc_2escm"),(void*)f_4858},
{C_text("f_4861:csc_2escm"),(void*)f_4861},
{C_text("f_4873:csc_2escm"),(void*)f_4873},
{C_text("f_4963:csc_2escm"),(void*)f_4963},
{C_text("f_4966:csc_2escm"),(void*)f_4966},
{C_text("f_4970:csc_2escm"),(void*)f_4970},
{C_text("f_4978:csc_2escm"),(void*)f_4978},
{C_text("f_4995:csc_2escm"),(void*)f_4995},
{C_text("f_5015:csc_2escm"),(void*)f_5015},
{C_text("f_5018:csc_2escm"),(void*)f_5018},
{C_text("f_5084:csc_2escm"),(void*)f_5084},
{C_text("f_5088:csc_2escm"),(void*)f_5088},
{C_text("f_5104:csc_2escm"),(void*)f_5104},
{C_text("f_5115:csc_2escm"),(void*)f_5115},
{C_text("f_5131:csc_2escm"),(void*)f_5131},
{C_text("f_5152:csc_2escm"),(void*)f_5152},
{C_text("f_5162:csc_2escm"),(void*)f_5162},
{C_text("f_5172:csc_2escm"),(void*)f_5172},
{C_text("f_5182:csc_2escm"),(void*)f_5182},
{C_text("f_5192:csc_2escm"),(void*)f_5192},
{C_text("f_5202:csc_2escm"),(void*)f_5202},
{C_text("f_5212:csc_2escm"),(void*)f_5212},
{C_text("f_5222:csc_2escm"),(void*)f_5222},
{C_text("f_5232:csc_2escm"),(void*)f_5232},
{C_text("f_5242:csc_2escm"),(void*)f_5242},
{C_text("f_5251:csc_2escm"),(void*)f_5251},
{C_text("f_5254:csc_2escm"),(void*)f_5254},
{C_text("f_5266:csc_2escm"),(void*)f_5266},
{C_text("f_5293:csc_2escm"),(void*)f_5293},
{C_text("f_5317:csc_2escm"),(void*)f_5317},
{C_text("f_5334:csc_2escm"),(void*)f_5334},
{C_text("f_5351:csc_2escm"),(void*)f_5351},
{C_text("f_5368:csc_2escm"),(void*)f_5368},
{C_text("f_5385:csc_2escm"),(void*)f_5385},
{C_text("f_5389:csc_2escm"),(void*)f_5389},
{C_text("f_5406:csc_2escm"),(void*)f_5406},
{C_text("f_5410:csc_2escm"),(void*)f_5410},
{C_text("f_5418:csc_2escm"),(void*)f_5418},
{C_text("f_5432:csc_2escm"),(void*)f_5432},
{C_text("f_5445:csc_2escm"),(void*)f_5445},
{C_text("f_5449:csc_2escm"),(void*)f_5449},
{C_text("f_5457:csc_2escm"),(void*)f_5457},
{C_text("f_5470:csc_2escm"),(void*)f_5470},
{C_text("f_5484:csc_2escm"),(void*)f_5484},
{C_text("f_5488:csc_2escm"),(void*)f_5488},
{C_text("f_5496:csc_2escm"),(void*)f_5496},
{C_text("f_5500:csc_2escm"),(void*)f_5500},
{C_text("f_5525:csc_2escm"),(void*)f_5525},
{C_text("f_5528:csc_2escm"),(void*)f_5528},
{C_text("f_5545:csc_2escm"),(void*)f_5545},
{C_text("f_5548:csc_2escm"),(void*)f_5548},
{C_text("f_5566:csc_2escm"),(void*)f_5566},
{C_text("f_5573:csc_2escm"),(void*)f_5573},
{C_text("f_5576:csc_2escm"),(void*)f_5576},
{C_text("f_5579:csc_2escm"),(void*)f_5579},
{C_text("f_5586:csc_2escm"),(void*)f_5586},
{C_text("f_5616:csc_2escm"),(void*)f_5616},
{C_text("f_5619:csc_2escm"),(void*)f_5619},
{C_text("f_5633:csc_2escm"),(void*)f_5633},
{C_text("f_5642:csc_2escm"),(void*)f_5642},
{C_text("f_5652:csc_2escm"),(void*)f_5652},
{C_text("f_5656:csc_2escm"),(void*)f_5656},
{C_text("f_5679:csc_2escm"),(void*)f_5679},
{C_text("f_5683:csc_2escm"),(void*)f_5683},
{C_text("f_5710:csc_2escm"),(void*)f_5710},
{C_text("f_5724:csc_2escm"),(void*)f_5724},
{C_text("f_5734:csc_2escm"),(void*)f_5734},
{C_text("f_5738:csc_2escm"),(void*)f_5738},
{C_text("f_5761:csc_2escm"),(void*)f_5761},
{C_text("f_5778:csc_2escm"),(void*)f_5778},
{C_text("f_5780:csc_2escm"),(void*)f_5780},
{C_text("f_5805:csc_2escm"),(void*)f_5805},
{C_text("f_5819:csc_2escm"),(void*)f_5819},
{C_text("f_5823:csc_2escm"),(void*)f_5823},
{C_text("f_5840:csc_2escm"),(void*)f_5840},
{C_text("f_5852:csc_2escm"),(void*)f_5852},
{C_text("f_5857:csc_2escm"),(void*)f_5857},
{C_text("f_5863:csc_2escm"),(void*)f_5863},
{C_text("f_5874:csc_2escm"),(void*)f_5874},
{C_text("f_5888:csc_2escm"),(void*)f_5888},
{C_text("f_5902:csc_2escm"),(void*)f_5902},
{C_text("f_5915:csc_2escm"),(void*)f_5915},
{C_text("f_5920:csc_2escm"),(void*)f_5920},
{C_text("f_5939:csc_2escm"),(void*)f_5939},
{C_text("f_5951:csc_2escm"),(void*)f_5951},
{C_text("f_5955:csc_2escm"),(void*)f_5955},
{C_text("f_5963:csc_2escm"),(void*)f_5963},
{C_text("f_5972:csc_2escm"),(void*)f_5972},
{C_text("f_5978:csc_2escm"),(void*)f_5978},
{C_text("f_6008:csc_2escm"),(void*)f_6008},
{C_text("f_6215:csc_2escm"),(void*)f_6215},
{C_text("f_6218:csc_2escm"),(void*)f_6218},
{C_text("f_6221:csc_2escm"),(void*)f_6221},
{C_text("f_6224:csc_2escm"),(void*)f_6224},
{C_text("f_6228:csc_2escm"),(void*)f_6228},
{C_text("f_6232:csc_2escm"),(void*)f_6232},
{C_text("f_6251:csc_2escm"),(void*)f_6251},
{C_text("f_6255:csc_2escm"),(void*)f_6255},
{C_text("f_6259:csc_2escm"),(void*)f_6259},
{C_text("f_6263:csc_2escm"),(void*)f_6263},
{C_text("f_6267:csc_2escm"),(void*)f_6267},
{C_text("f_6271:csc_2escm"),(void*)f_6271},
{C_text("f_6282:csc_2escm"),(void*)f_6282},
{C_text("f_6288:csc_2escm"),(void*)f_6288},
{C_text("f_6290:csc_2escm"),(void*)f_6290},
{C_text("f_6315:csc_2escm"),(void*)f_6315},
{C_text("f_6326:csc_2escm"),(void*)f_6326},
{C_text("f_6336:csc_2escm"),(void*)f_6336},
{C_text("f_6343:csc_2escm"),(void*)f_6343},
{C_text("f_6357:csc_2escm"),(void*)f_6357},
{C_text("f_6386:csc_2escm"),(void*)f_6386},
{C_text("f_6396:csc_2escm"),(void*)f_6396},
{C_text("f_6411:csc_2escm"),(void*)f_6411},
{C_text("f_6415:csc_2escm"),(void*)f_6415},
{C_text("f_6418:csc_2escm"),(void*)f_6418},
{C_text("f_6421:csc_2escm"),(void*)f_6421},
{C_text("f_6433:csc_2escm"),(void*)f_6433},
{C_text("f_6445:csc_2escm"),(void*)f_6445},
{C_text("f_6449:csc_2escm"),(void*)f_6449},
{C_text("f_6453:csc_2escm"),(void*)f_6453},
{C_text("f_6457:csc_2escm"),(void*)f_6457},
{C_text("f_6468:csc_2escm"),(void*)f_6468},
{C_text("f_6497:csc_2escm"),(void*)f_6497},
{C_text("f_6500:csc_2escm"),(void*)f_6500},
{C_text("f_6501:csc_2escm"),(void*)f_6501},
{C_text("f_6505:csc_2escm"),(void*)f_6505},
{C_text("f_6508:csc_2escm"),(void*)f_6508},
{C_text("f_6520:csc_2escm"),(void*)f_6520},
{C_text("f_6528:csc_2escm"),(void*)f_6528},
{C_text("f_6532:csc_2escm"),(void*)f_6532},
{C_text("f_6538:csc_2escm"),(void*)f_6538},
{C_text("f_6542:csc_2escm"),(void*)f_6542},
{C_text("f_6551:csc_2escm"),(void*)f_6551},
{C_text("f_6559:csc_2escm"),(void*)f_6559},
{C_text("f_6569:csc_2escm"),(void*)f_6569},
{C_text("f_6582:csc_2escm"),(void*)f_6582},
{C_text("f_6592:csc_2escm"),(void*)f_6592},
{C_text("f_6607:csc_2escm"),(void*)f_6607},
{C_text("f_6609:csc_2escm"),(void*)f_6609},
{C_text("f_6619:csc_2escm"),(void*)f_6619},
{C_text("f_6633:csc_2escm"),(void*)f_6633},
{C_text("f_6636:csc_2escm"),(void*)f_6636},
{C_text("f_6639:csc_2escm"),(void*)f_6639},
{C_text("f_6651:csc_2escm"),(void*)f_6651},
{C_text("f_6658:csc_2escm"),(void*)f_6658},
{C_text("f_6660:csc_2escm"),(void*)f_6660},
{C_text("f_6670:csc_2escm"),(void*)f_6670},
{C_text("f_6683:csc_2escm"),(void*)f_6683},
{C_text("f_6694:csc_2escm"),(void*)f_6694},
{C_text("f_6700:csc_2escm"),(void*)f_6700},
{C_text("f_6702:csc_2escm"),(void*)f_6702},
{C_text("f_6727:csc_2escm"),(void*)f_6727},
{C_text("f_6741:csc_2escm"),(void*)f_6741},
{C_text("f_6750:csc_2escm"),(void*)f_6750},
{C_text("f_6753:csc_2escm"),(void*)f_6753},
{C_text("f_6756:csc_2escm"),(void*)f_6756},
{C_text("f_6759:csc_2escm"),(void*)f_6759},
{C_text("f_6765:csc_2escm"),(void*)f_6765},
{C_text("f_6773:csc_2escm"),(void*)f_6773},
{C_text("f_6783:csc_2escm"),(void*)f_6783},
{C_text("f_6800:csc_2escm"),(void*)f_6800},
{C_text("f_6810:csc_2escm"),(void*)f_6810},
{C_text("f_6814:csc_2escm"),(void*)f_6814},
{C_text("f_6818:csc_2escm"),(void*)f_6818},
{C_text("f_6822:csc_2escm"),(void*)f_6822},
{C_text("f_6826:csc_2escm"),(void*)f_6826},
{C_text("f_6829:csc_2escm"),(void*)f_6829},
{C_text("f_6839:csc_2escm"),(void*)f_6839},
{C_text("f_6846:csc_2escm"),(void*)f_6846},
{C_text("f_6851:csc_2escm"),(void*)f_6851},
{C_text("f_6855:csc_2escm"),(void*)f_6855},
{C_text("f_6863:csc_2escm"),(void*)f_6863},
{C_text("f_6871:csc_2escm"),(void*)f_6871},
{C_text("f_6875:csc_2escm"),(void*)f_6875},
{C_text("f_6879:csc_2escm"),(void*)f_6879},
{C_text("f_6884:csc_2escm"),(void*)f_6884},
{C_text("f_6886:csc_2escm"),(void*)f_6886},
{C_text("f_6911:csc_2escm"),(void*)f_6911},
{C_text("f_6927:csc_2escm"),(void*)f_6927},
{C_text("f_6930:csc_2escm"),(void*)f_6930},
{C_text("f_6937:csc_2escm"),(void*)f_6937},
{C_text("f_6951:csc_2escm"),(void*)f_6951},
{C_text("f_6966:csc_2escm"),(void*)f_6966},
{C_text("f_6974:csc_2escm"),(void*)f_6974},
{C_text("f_6999:csc_2escm"),(void*)f_6999},
{C_text("f_7008:csc_2escm"),(void*)f_7008},
{C_text("f_7033:csc_2escm"),(void*)f_7033},
{C_text("f_7045:csc_2escm"),(void*)f_7045},
{C_text("f_7059:csc_2escm"),(void*)f_7059},
{C_text("f_7065:csc_2escm"),(void*)f_7065},
{C_text("f_7068:csc_2escm"),(void*)f_7068},
{C_text("f_7071:csc_2escm"),(void*)f_7071},
{C_text("f_7078:csc_2escm"),(void*)f_7078},
{C_text("f_7082:csc_2escm"),(void*)f_7082},
{C_text("f_7091:csc_2escm"),(void*)f_7091},
{C_text("f_7170:csc_2escm"),(void*)f_7170},
{C_text("f_7181:csc_2escm"),(void*)f_7181},
{C_text("f_7187:csc_2escm"),(void*)f_7187},
{C_text("f_7189:csc_2escm"),(void*)f_7189},
{C_text("f_7214:csc_2escm"),(void*)f_7214},
{C_text("f_7223:csc_2escm"),(void*)f_7223},
{C_text("f_7231:csc_2escm"),(void*)f_7231},
{C_text("f_7235:csc_2escm"),(void*)f_7235},
{C_text("f_7258:csc_2escm"),(void*)f_7258},
{C_text("f_7268:csc_2escm"),(void*)f_7268},
{C_text("f_7272:csc_2escm"),(void*)f_7272},
{C_text("f_7276:csc_2escm"),(void*)f_7276},
{C_text("f_7278:csc_2escm"),(void*)f_7278},
{C_text("f_7301:csc_2escm"),(void*)f_7301},
{C_text("f_7306:csc_2escm"),(void*)f_7306},
{C_text("f_7313:csc_2escm"),(void*)f_7313},
{C_text("f_7321:csc_2escm"),(void*)f_7321},
{C_text("f_7330:csc_2escm"),(void*)f_7330},
{C_text("f_7347:csc_2escm"),(void*)f_7347},
{C_text("f_7355:csc_2escm"),(void*)f_7355},
{C_text("f_7362:csc_2escm"),(void*)f_7362},
{C_text("f_7368:csc_2escm"),(void*)f_7368},
{C_text("f_7373:csc_2escm"),(void*)f_7373},
{C_text("f_7385:csc_2escm"),(void*)f_7385},
{C_text("f_7396:csc_2escm"),(void*)f_7396},
{C_text("f_7399:csc_2escm"),(void*)f_7399},
{C_text("f_7402:csc_2escm"),(void*)f_7402},
{C_text("f_7405:csc_2escm"),(void*)f_7405},
{C_text("f_7422:csc_2escm"),(void*)f_7422},
{C_text("f_7425:csc_2escm"),(void*)f_7425},
{C_text("f_7428:csc_2escm"),(void*)f_7428},
{C_text("f_7431:csc_2escm"),(void*)f_7431},
{C_text("f_7447:csc_2escm"),(void*)f_7447},
{C_text("f_7451:csc_2escm"),(void*)f_7451},
{C_text("f_7459:csc_2escm"),(void*)f_7459},
{C_text("f_7467:csc_2escm"),(void*)f_7467},
{C_text("f_7475:csc_2escm"),(void*)f_7475},
{C_text("f_7480:csc_2escm"),(void*)f_7480},
{C_text("f_7484:csc_2escm"),(void*)f_7484},
{C_text("f_7503:csc_2escm"),(void*)f_7503},
{C_text("f_7509:csc_2escm"),(void*)f_7509},
{C_text("f_7512:csc_2escm"),(void*)f_7512},
{C_text("f_7515:csc_2escm"),(void*)f_7515},
{C_text("f_7518:csc_2escm"),(void*)f_7518},
{C_text("f_7521:csc_2escm"),(void*)f_7521},
{C_text("f_7525:csc_2escm"),(void*)f_7525},
{C_text("f_7529:csc_2escm"),(void*)f_7529},
{C_text("f_7533:csc_2escm"),(void*)f_7533},
{C_text("f_7539:csc_2escm"),(void*)f_7539},
{C_text("f_7544:csc_2escm"),(void*)f_7544},
{C_text("f_7552:csc_2escm"),(void*)f_7552},
{C_text("f_7570:csc_2escm"),(void*)f_7570},
{C_text("f_7576:csc_2escm"),(void*)f_7576},
{C_text("f_7580:csc_2escm"),(void*)f_7580},
{C_text("f_7584:csc_2escm"),(void*)f_7584},
{C_text("f_7588:csc_2escm"),(void*)f_7588},
{C_text("f_7595:csc_2escm"),(void*)f_7595},
{C_text("f_7599:csc_2escm"),(void*)f_7599},
{C_text("f_7602:csc_2escm"),(void*)f_7602},
{C_text("f_7618:csc_2escm"),(void*)f_7618},
{C_text("f_7621:csc_2escm"),(void*)f_7621},
{C_text("f_7629:csc_2escm"),(void*)f_7629},
{C_text("f_7654:csc_2escm"),(void*)f_7654},
{C_text("f_7663:csc_2escm"),(void*)f_7663},
{C_text("f_7688:csc_2escm"),(void*)f_7688},
{C_text("f_7705:csc_2escm"),(void*)f_7705},
{C_text("f_7725:csc_2escm"),(void*)f_7725},
{C_text("f_7729:csc_2escm"),(void*)f_7729},
{C_text("f_7754:csc_2escm"),(void*)f_7754},
{C_text("f_7772:csc_2escm"),(void*)f_7772},
{C_text("f_7776:csc_2escm"),(void*)f_7776},
{C_text("f_7783:csc_2escm"),(void*)f_7783},
{C_text("f_7787:csc_2escm"),(void*)f_7787},
{C_text("f_7791:csc_2escm"),(void*)f_7791},
{C_text("f_7795:csc_2escm"),(void*)f_7795},
{C_text("f_7806:csc_2escm"),(void*)f_7806},
{C_text("f_7809:csc_2escm"),(void*)f_7809},
{C_text("f_7816:csc_2escm"),(void*)f_7816},
{C_text("f_7821:csc_2escm"),(void*)f_7821},
{C_text("f_7826:csc_2escm"),(void*)f_7826},
{C_text("f_7830:csc_2escm"),(void*)f_7830},
{C_text("f_7834:csc_2escm"),(void*)f_7834},
{C_text("f_7841:csc_2escm"),(void*)f_7841},
{C_text("toplevel:csc_2escm"),(void*)C_toplevel},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding unexported module binding: main#staticbuild 
o|hiding unexported module binding: main#debugbuild 
o|hiding unexported module binding: main#cross-chicken 
o|hiding unexported module binding: main#binary-version 
o|hiding unexported module binding: main#major-version 
o|hiding unexported module binding: main#default-cc 
o|hiding unexported module binding: main#default-cxx 
o|hiding unexported module binding: main#default-install-program 
o|hiding unexported module binding: main#default-cflags 
o|hiding unexported module binding: main#default-ldflags 
o|hiding unexported module binding: main#default-install-program-executable-flags 
o|hiding unexported module binding: main#default-install-program-data-flags 
o|hiding unexported module binding: main#default-libs 
o|hiding unexported module binding: main#default-libdir 
o|hiding unexported module binding: main#default-runlibdir 
o|hiding unexported module binding: main#default-slibdir 
o|hiding unexported module binding: main#default-incdir 
o|hiding unexported module binding: main#default-bindir 
o|hiding unexported module binding: main#default-sharedir 
o|hiding unexported module binding: main#default-platform 
o|hiding unexported module binding: main#default-prefix 
o|hiding unexported module binding: main#default-bindir 
o|hiding unexported module binding: main#default-csc 
o|hiding unexported module binding: main#default-csi 
o|hiding unexported module binding: main#default-builder 
o|hiding unexported module binding: main#target-librarian 
o|hiding unexported module binding: main#target-librarian-options 
o|hiding unexported module binding: main#host-repo 
o|hiding unexported module binding: main#host-libdir 
o|hiding unexported module binding: main#host-bindir 
o|hiding unexported module binding: main#host-incdir 
o|hiding unexported module binding: main#host-sharedir 
o|hiding unexported module binding: main#host-libs 
o|hiding unexported module binding: main#host-cflags 
o|hiding unexported module binding: main#host-ldflags 
o|hiding unexported module binding: main#host-cc 
o|hiding unexported module binding: main#host-cxx 
o|hiding unexported module binding: main#target-repo 
o|hiding unexported module binding: main#target-run-repo 
o|hiding unexported module binding: main#+egg-info-extension+ 
o|hiding unexported module binding: main#+version-file+ 
o|hiding unexported module binding: main#+timestamp-file+ 
o|hiding unexported module binding: main#+status-file+ 
o|hiding unexported module binding: main#+egg-extension+ 
o|hiding unexported module binding: main#validate-environment 
o|hiding unexported module binding: main#destination-repository 
o|hiding unexported module binding: main#probe-dir 
o|hiding unexported module binding: main#cache-directory 
o|hiding unexported module binding: main#partition 
o|hiding unexported module binding: main#span 
o|hiding unexported module binding: main#take 
o|hiding unexported module binding: main#drop 
o|hiding unexported module binding: main#split-at 
o|hiding unexported module binding: main#append-map 
o|hiding unexported module binding: main#every 
o|hiding unexported module binding: main#any 
o|hiding unexported module binding: main#cons* 
o|hiding unexported module binding: main#concatenate 
o|hiding unexported module binding: main#delete 
o|hiding unexported module binding: main#first 
o|hiding unexported module binding: main#second 
o|hiding unexported module binding: main#third 
o|hiding unexported module binding: main#fourth 
o|hiding unexported module binding: main#fifth 
o|hiding unexported module binding: main#delete-duplicates 
o|hiding unexported module binding: main#alist-cons 
o|hiding unexported module binding: main#filter 
o|hiding unexported module binding: main#filter-map 
o|hiding unexported module binding: main#remove 
o|hiding unexported module binding: main#unzip1 
o|hiding unexported module binding: main#last 
o|hiding unexported module binding: main#list-index 
o|hiding unexported module binding: main#lset-adjoin/eq? 
o|hiding unexported module binding: main#lset-difference/eq? 
o|hiding unexported module binding: main#lset-union/eq? 
o|hiding unexported module binding: main#lset-intersection/eq? 
o|hiding unexported module binding: main#list-tabulate 
o|hiding unexported module binding: main#lset<=/eq? 
o|hiding unexported module binding: main#lset=/eq? 
o|hiding unexported module binding: main#length+ 
o|hiding unexported module binding: main#find 
o|hiding unexported module binding: main#find-tail 
o|hiding unexported module binding: main#iota 
o|hiding unexported module binding: main#make-list 
o|hiding unexported module binding: main#posq 
o|hiding unexported module binding: main#posv 
o|hiding unexported module binding: main#host-libs 
o|hiding unexported module binding: main#TARGET_CC 
o|hiding unexported module binding: main#windows 
o|hiding unexported module binding: main#mingw 
o|hiding unexported module binding: main#osx 
o|hiding unexported module binding: main#cygwin 
o|hiding unexported module binding: main#aix 
o|hiding unexported module binding: main#elf 
o|hiding unexported module binding: main#stop 
o|hiding unexported module binding: main#arguments 
o|hiding unexported module binding: main#cross-chicken 
o|hiding unexported module binding: main#host-mode 
o|hiding unexported module binding: main#back-slash->forward-slash 
o|hiding unexported module binding: main#quotewrap 
o|hiding unexported module binding: main#quotewrap-no-slash-trans 
o|hiding unexported module binding: main#home 
o|hiding unexported module binding: main#translator 
o|hiding unexported module binding: main#compiler 
o|hiding unexported module binding: main#c++-compiler 
o|hiding unexported module binding: main#rc-compiler 
o|hiding unexported module binding: main#linker 
o|hiding unexported module binding: main#c++-linker 
o|hiding unexported module binding: main#object-extension 
o|hiding unexported module binding: main#library-extension 
o|hiding unexported module binding: main#link-output-flag 
o|hiding unexported module binding: main#executable-extension 
o|hiding unexported module binding: main#compile-output-flag 
o|hiding unexported module binding: main#shared-library-extension 
o|hiding unexported module binding: main#static-object-extension 
o|hiding unexported module binding: main#static-library-extension 
o|hiding unexported module binding: main#default-translation-optimization-options 
o|hiding unexported module binding: main#pic-options 
o|hiding unexported module binding: main#generate-manifest 
o|hiding unexported module binding: main#libchicken 
o|hiding unexported module binding: main#dynamic-libchicken 
o|hiding unexported module binding: main#default-library 
o|hiding unexported module binding: main#default-compilation-optimization-options 
o|hiding unexported module binding: main#best-compilation-optimization-options 
o|hiding unexported module binding: main#default-linking-optimization-options 
o|hiding unexported module binding: main#best-linking-optimization-options 
o|hiding unexported module binding: main#extra-features 
o|hiding unexported module binding: main#constant807 
o|hiding unexported module binding: main#constant810 
o|hiding unexported module binding: main#constant814 
o|hiding unexported module binding: main#short-options 
o|hiding unexported module binding: main#scheme-files 
o|hiding unexported module binding: main#c-files 
o|hiding unexported module binding: main#rc-files 
o|hiding unexported module binding: main#generated-c-files 
o|hiding unexported module binding: main#generated-rc-files 
o|hiding unexported module binding: main#object-files 
o|hiding unexported module binding: main#generated-object-files 
o|hiding unexported module binding: main#transient-link-files 
o|hiding unexported module binding: main#linked-extensions 
o|hiding unexported module binding: main#cpp-mode 
o|hiding unexported module binding: main#objc-mode 
o|hiding unexported module binding: main#embedded 
o|hiding unexported module binding: main#inquiry-only 
o|hiding unexported module binding: main#show-cflags 
o|hiding unexported module binding: main#show-ldflags 
o|hiding unexported module binding: main#show-libs 
o|hiding unexported module binding: main#dry-run 
o|hiding unexported module binding: main#gui 
o|hiding unexported module binding: main#deployed 
o|hiding unexported module binding: main#rpath 
o|hiding unexported module binding: main#ignore-repository 
o|hiding unexported module binding: main#show-debugging-help 
o|hiding unexported module binding: main#library-dir 
o|hiding unexported module binding: main#extra-libraries 
o|hiding unexported module binding: main#extra-shared-libraries 
o|hiding unexported module binding: main#default-library-files 
o|hiding unexported module binding: main#library-files 
o|hiding unexported module binding: main#shared-library-files 
o|hiding unexported module binding: main#translate-options 
o|hiding unexported module binding: main#include-dir 
o|hiding unexported module binding: main#compile-options 
o|hiding unexported module binding: main#builtin-compile-options 
o|hiding unexported module binding: main#compile-only-flag 
o|hiding unexported module binding: main#translation-optimization-options 
o|hiding unexported module binding: main#compilation-optimization-options 
o|hiding unexported module binding: main#linking-optimization-options 
o|hiding unexported module binding: main#link-options 
o|hiding unexported module binding: main#builtin-link-options 
o|hiding unexported module binding: main#target-filename 
o|hiding unexported module binding: main#verbose 
o|hiding unexported module binding: main#keep-files 
o|hiding unexported module binding: main#translate-only 
o|hiding unexported module binding: main#compile-only 
o|hiding unexported module binding: main#to-stdout 
o|hiding unexported module binding: main#shared 
o|hiding unexported module binding: main#static 
o|hiding unexported module binding: main#repo-path 
o|hiding unexported module binding: main#find-object-file 
o|hiding unexported module binding: main#usage 
o|hiding unexported module binding: main#run 
o|hiding unexported module binding: main#run-translation 
o|hiding unexported module binding: main#run-compilation 
o|hiding unexported module binding: main#compiler-options 
o|hiding unexported module binding: main#run-linking 
o|hiding unexported module binding: main#collect-linked-objects 
o|hiding unexported module binding: main#copy-files 
o|hiding unexported module binding: main#linker-options 
o|hiding unexported module binding: main#linker-libraries 
o|hiding unexported module binding: main#constant1663 
o|hiding unexported module binding: main#cleanup 
o|hiding unexported module binding: main#string-any 
o|hiding unexported module binding: main#quote-option 
o|hiding unexported module binding: main#last-exit-code 
o|hiding unexported module binding: main#$system 
o|hiding unexported module binding: main#command 
o|hiding unexported module binding: main#$delete-file 
o|hiding unexported module binding: main#rez 
o|hiding unexported module binding: main#create-win-manifest 
S|applied compiler syntax:
S|  chicken.format#printf		1
S|  scheme#for-each		6
S|  chicken.format#sprintf		4
S|  chicken.format#fprintf		2
S|  chicken.base#foldl		3
S|  scheme#map		13
S|  chicken.base#foldr		3
o|eliminated procedure checks: 150 
o|specializations:
o|  1 (scheme#zero? *)
o|  2 (scheme#zero? integer)
o|  1 (scheme#= integer integer)
o|  1 (scheme#+ fixnum fixnum)
o|  1 (##sys#debug-mode?)
o|  2 (scheme#= fixnum fixnum)
o|  5 (scheme#string-append string string)
o|  5 (scheme#char=? char char)
o|  7 (scheme#string-ref string fixnum)
o|  4 (scheme#string=? string string)
o|  4 (scheme#> fixnum fixnum)
o|  4 (scheme#string-length string)
o|  1 (scheme#memv (or symbol keyword procedure eof null fixnum char boolean) list)
o|  71 (scheme#eqv? (or eof null fixnum char boolean symbol keyword) *)
o|  7 (##sys#check-output-port * * *)
o|  2 (chicken.base#current-error-port)
o|  4 (scheme#memq * list)
o|  1 (scheme#eqv? * *)
o|  6 (##sys#check-list (or pair list) *)
o|  26 (scheme#cdr pair)
o|  8 (scheme#car pair)
o|  2 (scheme#number->string fixnum)
(o e)|safe calls: 813 
(o e)|assignments to immediate values: 25 
o|removed side-effect free assignment to unused variable: main#default-install-program 
o|removed side-effect free assignment to unused variable: main#default-ldflags 
o|removed side-effect free assignment to unused variable: main#default-install-program-executable-flags 
o|removed side-effect free assignment to unused variable: main#default-install-program-data-flags 
o|removed side-effect free assignment to unused variable: main#default-slibdir 
o|removed side-effect free assignment to unused variable: main#default-platform 
o|removed side-effect free assignment to unused variable: main#default-prefix 
o|removed side-effect free assignment to unused variable: main#default-csc 
o|removed side-effect free assignment to unused variable: main#default-csi 
o|removed side-effect free assignment to unused variable: main#default-builder 
o|removed side-effect free assignment to unused variable: main#target-librarian 
o|removed side-effect free assignment to unused variable: main#target-librarian-options 
o|removed side-effect free assignment to unused variable: main#host-ldflags 
o|removed side-effect free assignment to unused variable: main#+egg-info-extension+ 
o|removed side-effect free assignment to unused variable: main#+version-file+ 
o|removed side-effect free assignment to unused variable: main#+timestamp-file+ 
o|removed side-effect free assignment to unused variable: main#+status-file+ 
o|removed side-effect free assignment to unused variable: main#+egg-extension+ 
o|removed side-effect free assignment to unused variable: main#validate-environment 
o|removed side-effect free assignment to unused variable: main#probe-dir 
o|removed side-effect free assignment to unused variable: main#cache-directory 
o|removed side-effect free assignment to unused variable: main#partition 
o|removed side-effect free assignment to unused variable: main#span 
o|removed side-effect free assignment to unused variable: main#drop 
o|removed side-effect free assignment to unused variable: main#split-at 
o|removed side-effect free assignment to unused variable: main#append-map 
o|inlining procedure: k2888 
o|inlining procedure: k2888 
o|inlining procedure: k2919 
o|inlining procedure: k2919 
o|merged explicitly consed rest parameter: xs406 
o|inlining procedure: k2949 
o|inlining procedure: k2949 
o|removed side-effect free assignment to unused variable: main#concatenate 
o|removed side-effect free assignment to unused variable: main#second 
o|removed side-effect free assignment to unused variable: main#third 
o|removed side-effect free assignment to unused variable: main#fourth 
o|removed side-effect free assignment to unused variable: main#fifth 
o|removed side-effect free assignment to unused variable: main#alist-cons 
o|inlining procedure: k3136 
o|inlining procedure: k3136 
o|inlining procedure: k3128 
o|inlining procedure: k3128 
o|removed side-effect free assignment to unused variable: main#remove 
o|removed side-effect free assignment to unused variable: main#unzip1 
o|removed side-effect free assignment to unused variable: main#list-index 
o|removed side-effect free assignment to unused variable: main#lset-adjoin/eq? 
o|removed side-effect free assignment to unused variable: main#lset-union/eq? 
o|removed side-effect free assignment to unused variable: main#lset-intersection/eq? 
o|inlining procedure: k3527 
o|inlining procedure: k3527 
o|removed side-effect free assignment to unused variable: main#lset<=/eq? 
o|removed side-effect free assignment to unused variable: main#lset=/eq? 
o|removed side-effect free assignment to unused variable: main#length+ 
o|removed side-effect free assignment to unused variable: main#find 
o|removed side-effect free assignment to unused variable: main#find-tail 
o|removed side-effect free assignment to unused variable: main#iota 
o|removed side-effect free assignment to unused variable: main#make-list 
o|removed side-effect free assignment to unused variable: main#posq 
o|removed side-effect free assignment to unused variable: main#posv 
o|removed side-effect free assignment to unused variable: main#TARGET_CC 
o|removed side-effect free assignment to unused variable: main#windows 
o|substituted constant variable: a3815 
o|merged explicitly consed rest parameter: args756 
o|propagated global variable: out757760 ##sys#standard-error 
o|substituted constant variable: a3820 
o|substituted constant variable: a3821 
o|contracted procedure: "(csc.scm:89) main#back-slash->forward-slash" 
o|inlining procedure: k3859 
o|inlining procedure: k3859 
o|inlining procedure: k3947 
o|inlining procedure: k3947 
o|removed side-effect free assignment to unused variable: main#dynamic-libchicken 
o|substituted constant variable: main#default-translation-optimization-options 
o|inlining procedure: k4228 
o|inlining procedure: k4228 
o|contracted procedure: "(csc.scm:296) main#destination-repository" 
o|inlining procedure: k2467 
o|inlining procedure: k2467 
o|inlining procedure: k4255 
o|inlining procedure: k4255 
o|inlining procedure: k4267 
o|inlining procedure: k4267 
o|inlining procedure: k4279 
o|inlining procedure: k4279 
o|inlining procedure: k4299 
o|inlining procedure: k4299 
o|inlining procedure: k6704 
o|inlining procedure: k6704 
o|removed side-effect free assignment to unused variable: main#copy-files 
o|inlining procedure: k7191 
o|inlining procedure: k7191 
o|inlining procedure: k7237 
o|inlining procedure: k7237 
o|contracted procedure: "(csc.scm:1033) main#library-files" 
o|contracted procedure: "(csc.scm:231) main#default-library" 
o|contracted procedure: "(csc.scm:1034) main#shared-library-files" 
o|contracted procedure: "(csc.scm:232) main#default-library-files" 
o|inlining procedure: k4051 
o|inlining procedure: k4051 
o|substituted constant variable: a7336 
o|inlining procedure: k7337 
o|inlining procedure: k7337 
o|inlining procedure: k7357 
o|inlining procedure: k7357 
o|contracted procedure: "(csc.scm:1074) main#cleanup" 
o|inlining procedure: k7259 
o|inlining procedure: k7259 
o|inlining procedure: k7280 
o|inlining procedure: k7280 
o|consed rest parameter at call site: "(csc.scm:1051) main#cons*" 2 
o|inlining procedure: k7378 
o|inlining procedure: k7378 
o|inlining procedure: k7469 
o|inlining procedure: k7469 
o|contracted procedure: "(csc.scm:1096) main#$system" 
o|inlining procedure: k7407 
o|inlining procedure: k7407 
o|propagated global variable: out17231726 ##sys#standard-output 
o|substituted constant variable: a7418 
o|substituted constant variable: a7419 
o|propagated global variable: out17231726 ##sys#standard-output 
o|inlining procedure: k7448 
o|inlining procedure: k7448 
o|inlining procedure: k7485 
o|inlining procedure: k7485 
o|contracted procedure: "(csc.scm:1136) main#run" 
o|merged explicitly consed rest parameter: os1014 
o|merged explicitly consed rest parameter: n1017 
o|inlining procedure: k4359 
o|inlining procedure: k4359 
o|consed rest parameter at call site: "(csc.scm:534) main#stop" 2 
o|inlining procedure: k4373 
o|inlining procedure: k4373 
o|inlining procedure: k4399 
o|inlining procedure: k4399 
o|consed rest parameter at call site: "(csc.scm:537) main#cons*" 2 
o|inlining procedure: k4419 
o|propagated global variable: r44207928 main#shared-library-extension 
o|inlining procedure: k4419 
o|inlining procedure: k4431 
o|inlining procedure: k4457 
o|inlining procedure: k4457 
o|contracted procedure: "(csc.scm:603) main#run-linking" 
o|inlining procedure: k6760 
o|inlining procedure: k6760 
o|inlining procedure: k6775 
o|inlining procedure: k6775 
o|inlining procedure: k6801 
o|contracted procedure: "(csc.scm:987) main#rez" 
o|substituted constant variable: a7505 
o|substituted constant variable: a7506 
o|inlining procedure: k6801 
o|inlining procedure: k6827 
o|inlining procedure: k6827 
o|inlining procedure: k6837 
o|propagated global variable: r68387945 main#host-libdir 
o|inlining procedure: k6837 
o|substituted constant variable: a6847 
o|consed rest parameter at call site: "(csc.scm:965) main#cons*" 2 
o|substituted constant variable: main#link-output-flag 
o|inlining procedure: k6888 
o|inlining procedure: k6888 
o|propagated global variable: g14911495 main#object-files 
o|contracted procedure: "(csc.scm:959) main#collect-linked-objects" 
o|inlining procedure: k7047 
o|contracted procedure: "(csc.scm:1006) main#delete-duplicates" 
o|inlining procedure: k3080 
o|inlining procedure: k3080 
o|contracted procedure: "(mini-srfi-1.scm:123) main#delete" 
o|inlining procedure: k3005 
o|inlining procedure: k3005 
o|inlining procedure: k7047 
o|contracted procedure: "(csc.scm:1010) locate-objects1535" 
o|inlining procedure: k6976 
o|contracted procedure: "(csc.scm:1000) g15481557" 
o|inlining procedure: k6952 
o|inlining procedure: k6952 
o|consed rest parameter at call site: "(csc.scm:1002) main#stop" 2 
o|inlining procedure: k6976 
o|inlining procedure: k7010 
o|inlining procedure: k7010 
o|contracted procedure: "(csc.scm:1008) locate-link-file1534" 
o|propagated global variable: tmp16031605 main#static 
o|propagated global variable: tmp16031605 main#static 
o|propagated global variable: ofiles1532 main#object-files 
o|propagated global variable: ofiles1532 main#object-files 
o|propagated global variable: out10531056 ##sys#standard-error 
o|substituted constant variable: a4473 
o|substituted constant variable: a4474 
o|substituted constant variable: a4501 
o|substituted constant variable: a4502 
o|inlining procedure: k4540 
o|inlining procedure: k4540 
o|propagated global variable: out10531056 ##sys#standard-error 
o|contracted procedure: "(csc.scm:592) main#filter-map" 
o|propagated global variable: lst470 main#linked-extensions 
o|inlining procedure: k3183 
o|inlining procedure: k3183 
o|inlining procedure: k3172 
o|inlining procedure: k3172 
o|contracted procedure: "(csc.scm:588) main#run-compilation" 
o|substituted constant variable: main#compile-only-flag 
o|inlining procedure: k6458 
o|inlining procedure: k6458 
o|substituted constant variable: main#compile-output-flag 
o|consed rest parameter at call site: "(csc.scm:912) main#stop" 2 
o|inlining procedure: k6481 
o|substituted constant variable: a6487 
o|inlining procedure: k6481 
o|inlining procedure: k6543 
o|inlining procedure: k6543 
o|inlining procedure: k6561 
o|inlining procedure: k6561 
o|propagated global variable: g14351437 main#generated-rc-files 
o|inlining procedure: k6584 
o|inlining procedure: k6584 
o|propagated global variable: g14181420 main#generated-c-files 
o|inlining procedure: k6611 
o|inlining procedure: k6611 
o|propagated global variable: g13751399 main#rc-files 
o|contracted procedure: "(csc.scm:930) main#create-win-manifest" 
o|inlining procedure: k6662 
o|inlining procedure: k6662 
o|propagated global variable: g13651377 main#c-files 
o|inlining procedure: k4560 
o|inlining procedure: k4560 
o|contracted procedure: "(csc.scm:579) main#last" 
o|inlining procedure: k3285 
o|inlining procedure: k3285 
o|consed rest parameter at call site: "(csc.scm:575) main#stop" 2 
o|inlining procedure: k4581 
o|consed rest parameter at call site: "(csc.scm:575) main#stop" 2 
o|consed rest parameter at call site: "(csc.scm:574) main#cons*" 2 
o|inlining procedure: k4581 
o|consed rest parameter at call site: "(csc.scm:575) main#stop" 2 
o|contracted procedure: "(csc.scm:586) main#run-translation" 
o|inlining procedure: k6388 
o|contracted procedure: "(csc.scm:853) g12961303" 
o|consed rest parameter at call site: "(csc.scm:868) main#cons*" 2 
o|inlining procedure: k6292 
o|inlining procedure: k6292 
o|inlining procedure: k6328 
o|inlining procedure: k6328 
o|consed rest parameter at call site: "(csc.scm:864) main#stop" 2 
o|inlining procedure: k6365 
o|inlining procedure: k6365 
o|substituted constant variable: a6374 
o|inlining procedure: k6388 
o|propagated global variable: g13021304 main#scheme-files 
o|contracted procedure: "(csc.scm:585) main#first" 
o|propagated global variable: x428 main#scheme-files 
o|contracted procedure: "(csc.scm:560) main#builtin-link-options" 
o|inlining procedure: k4112 
o|contracted procedure: "(csc.scm:276) g936937" 
o|inlining procedure: k4134 
o|contracted procedure: "(csc.scm:278) g947956" 
o|inlining procedure: k4134 
o|inlining procedure: k4112 
o|substituted constant variable: a4178 
o|inlining procedure: k4191 
o|inlining procedure: k4191 
o|inlining procedure: k4200 
o|inlining procedure: k4200 
o|inlining procedure: k4431 
o|contracted procedure: "(csc.scm:610) main#usage" 
o|inlining procedure: k4696 
o|inlining procedure: k4696 
o|substituted constant variable: a4729 
o|substituted constant variable: a4730 
o|inlining procedure: k4743 
o|inlining procedure: k4743 
o|inlining procedure: k4764 
o|inlining procedure: k4764 
o|inlining procedure: k4783 
o|inlining procedure: k4783 
o|inlining procedure: k4803 
o|inlining procedure: k4803 
o|inlining procedure: k4827 
o|inlining procedure: k4827 
o|inlining procedure: k4847 
o|consed rest parameter at call site: "(csc.scm:643) t-options1009" 1 
o|consed rest parameter at call site: "(csc.scm:641) main#cons*" 2 
o|inlining procedure: k4847 
o|consed rest parameter at call site: "(csc.scm:649) t-options1009" 1 
o|inlining procedure: k4894 
o|consed rest parameter at call site: "(csc.scm:652) t-options1009" 1 
o|inlining procedure: k4894 
o|consed rest parameter at call site: "(csc.scm:655) t-options1009" 1 
o|inlining procedure: k4920 
o|inlining procedure: k4920 
o|inlining procedure: k4934 
o|inlining procedure: k4934 
o|inlining procedure: k4955 
o|consed rest parameter at call site: "(csc.scm:664) t-options1009" 1 
o|consed rest parameter at call site: "(csc.scm:663) check1010" 3 
o|inlining procedure: k4955 
o|consed rest parameter at call site: "(csc.scm:669) check1010" 3 
o|inlining procedure: k5004 
o|consed rest parameter at call site: "(csc.scm:674) t-options1009" 1 
o|consed rest parameter at call site: "(csc.scm:673) check1010" 3 
o|inlining procedure: k5004 
o|contracted procedure: "(csc.scm:677) use-private-repository1012" 
o|inlining procedure: k5036 
o|consed rest parameter at call site: "(csc.scm:680) t-options1009" 1 
o|inlining procedure: k5036 
o|consed rest parameter at call site: "(csc.scm:683) t-options1009" 1 
o|inlining procedure: k5056 
o|inlining procedure: k5056 
o|inlining procedure: k5074 
o|consed rest parameter at call site: "(csc.scm:696) main#cons*" 2 
o|inlining procedure: k5074 
o|inlining procedure: k5089 
o|inlining procedure: k5089 
o|consed rest parameter at call site: "(csc.scm:703) main#cons*" 2 
o|consed rest parameter at call site: "(csc.scm:701) check1010" 3 
o|inlining procedure: k5120 
o|consed rest parameter at call site: "(csc.scm:706) check1010" 3 
o|inlining procedure: k5120 
o|consed rest parameter at call site: "(csc.scm:710) main#cons*" 2 
o|inlining procedure: k5153 
o|consed rest parameter at call site: "(csc.scm:711) main#cons*" 2 
o|inlining procedure: k5153 
o|consed rest parameter at call site: "(csc.scm:712) main#cons*" 2 
o|inlining procedure: k5173 
o|consed rest parameter at call site: "(csc.scm:713) main#cons*" 2 
o|inlining procedure: k5173 
o|consed rest parameter at call site: "(csc.scm:714) main#cons*" 2 
o|inlining procedure: k5193 
o|consed rest parameter at call site: "(csc.scm:716) main#cons*" 2 
o|inlining procedure: k5193 
o|consed rest parameter at call site: "(csc.scm:717) main#cons*" 2 
o|inlining procedure: k5213 
o|consed rest parameter at call site: "(csc.scm:718) main#cons*" 2 
o|inlining procedure: k5213 
o|consed rest parameter at call site: "(csc.scm:719) main#cons*" 2 
o|inlining procedure: k5233 
o|consed rest parameter at call site: "(csc.scm:720) main#cons*" 2 
o|inlining procedure: k5233 
o|substituted constant variable: a5262 
o|consed rest parameter at call site: "(csc.scm:723) t-options1009" 1 
o|consed rest parameter at call site: "(csc.scm:722) check1010" 3 
o|inlining procedure: k5277 
o|inlining procedure: k5277 
o|inlining procedure: k5297 
o|inlining procedure: k5297 
o|consed rest parameter at call site: "(csc.scm:736) check1010" 3 
o|inlining procedure: k5326 
o|consed rest parameter at call site: "(csc.scm:740) check1010" 3 
o|inlining procedure: k5326 
o|consed rest parameter at call site: "(csc.scm:744) check1010" 3 
o|inlining procedure: k5360 
o|consed rest parameter at call site: "(csc.scm:748) check1010" 3 
o|inlining procedure: k5360 
o|consed rest parameter at call site: "(csc.scm:753) main#cons*" 2 
o|consed rest parameter at call site: "(csc.scm:752) check1010" 3 
o|inlining procedure: k5398 
o|consed rest parameter at call site: "(csc.scm:755) check1010" 3 
o|inlining procedure: k5398 
o|inlining procedure: k5437 
o|consed rest parameter at call site: "(csc.scm:761) check1010" 3 
o|inlining procedure: k5437 
o|substituted constant variable: a5501 
o|inlining procedure: k5502 
o|inlining procedure: k5502 
o|consed rest parameter at call site: "(csc.scm:765) check1010" 3 
o|inlining procedure: k5511 
o|inlining procedure: k5511 
o|consed rest parameter at call site: "(csc.scm:774) t-options1009" 1 
o|consed rest parameter at call site: "(csc.scm:773) check1010" 3 
o|inlining procedure: k5537 
o|consed rest parameter at call site: "(csc.scm:778) t-options1009" 1 
o|consed rest parameter at call site: "(csc.scm:777) check1010" 3 
o|inlining procedure: k5537 
o|inlining procedure: k5567 
o|inlining procedure: k5567 
o|inlining procedure: k5583 
o|inlining procedure: k5583 
o|consed rest parameter at call site: "(csc.scm:792) t-options1009" 1 
o|inlining procedure: k5608 
o|consed rest parameter at call site: "(csc.scm:795) t-options1009" 1 
o|consed rest parameter at call site: "(csc.scm:794) check1010" 3 
o|inlining procedure: k5608 
o|consed rest parameter at call site: "(csc.scm:798) t-options1009" 1 
o|inlining procedure: k5637 
o|substituted constant variable: a5649 
o|substituted constant variable: a5646 
o|substituted constant variable: a5669 
o|substituted constant variable: a5676 
o|substituted constant variable: a5673 
o|inlining procedure: k5670 
o|substituted constant variable: a5696 
o|inlining procedure: k5670 
o|substituted constant variable: a5703 
o|substituted constant variable: a5700 
o|consed rest parameter at call site: "(csc.scm:810) t-options1009" 1 
o|substituted constant variable: a5717 
o|substituted constant variable: a5714 
o|inlining procedure: k5711 
o|inlining procedure: k5711 
o|inlining procedure: k5743 
o|inlining procedure: k5782 
o|contracted procedure: "(csc.scm:820) g12411250" 
o|substituted constant variable: a5771 
o|inlining procedure: k5782 
o|consed rest parameter at call site: "(csc.scm:821) main#stop" 2 
o|contracted procedure: "(csc.scm:818) main#lset-difference/eq?" 
o|inlining procedure: k3385 
o|contracted procedure: "(mini-srfi-1.scm:164) g570571" 
o|inlining procedure: k3385 
o|inlining procedure: k5743 
o|consed rest parameter at call site: "(csc.scm:822) main#stop" 2 
o|substituted constant variable: a5831 
o|substituted constant variable: a5836 
o|substituted constant variable: a5845 
o|inlining procedure: k5637 
o|inlining procedure: k5865 
o|inlining procedure: k5865 
o|inlining procedure: k5893 
o|inlining procedure: k5893 
o|inlining procedure: k5929 
o|inlining procedure: k5929 
o|inlining procedure: k5973 
o|inlining procedure: k5973 
o|consed rest parameter at call site: "(csc.scm:846) main#stop" 2 
o|substituted constant variable: a5987 
o|substituted constant variable: a5994 
o|substituted constant variable: a5991 
o|substituted constant variable: a5999 
o|substituted constant variable: a6004 
o|substituted constant variable: a6013 
o|substituted constant variable: main#constant810 
o|substituted constant variable: main#constant807 
o|substituted constant variable: main#constant814 
o|substituted constant variable: a6016 
o|substituted constant variable: a6025 
o|substituted constant variable: a6027 
o|substituted constant variable: a6029 
o|substituted constant variable: a6031 
o|substituted constant variable: a6033 
o|substituted constant variable: a6035 
o|substituted constant variable: a6037 
o|substituted constant variable: a6039 
o|substituted constant variable: a6041 
o|substituted constant variable: a6043 
o|substituted constant variable: a6045 
o|substituted constant variable: a6047 
o|substituted constant variable: a6049 
o|substituted constant variable: a6054 
o|substituted constant variable: a6056 
o|inlining procedure: k6060 
o|inlining procedure: k6060 
o|substituted constant variable: a6067 
o|substituted constant variable: a6069 
o|substituted constant variable: a6071 
o|substituted constant variable: a6073 
o|substituted constant variable: a6075 
o|substituted constant variable: a6077 
o|substituted constant variable: a6079 
o|substituted constant variable: a6081 
o|substituted constant variable: a6083 
o|substituted constant variable: a6085 
o|substituted constant variable: a6087 
o|substituted constant variable: a6089 
o|substituted constant variable: a6091 
o|substituted constant variable: a6093 
o|substituted constant variable: a6098 
o|substituted constant variable: a6100 
o|substituted constant variable: a6105 
o|substituted constant variable: a6107 
o|substituted constant variable: a6109 
o|substituted constant variable: a6111 
o|substituted constant variable: a6113 
o|substituted constant variable: a6115 
o|substituted constant variable: a6117 
o|substituted constant variable: a6119 
o|substituted constant variable: a6121 
o|substituted constant variable: a6126 
o|substituted constant variable: a6128 
o|substituted constant variable: a6130 
o|substituted constant variable: a6132 
o|substituted constant variable: a6137 
o|substituted constant variable: a6139 
o|substituted constant variable: a6141 
o|substituted constant variable: a6143 
o|substituted constant variable: a6145 
o|substituted constant variable: a6150 
o|substituted constant variable: a6152 
o|substituted constant variable: a6157 
o|substituted constant variable: a6159 
o|substituted constant variable: a6164 
o|substituted constant variable: a6166 
o|substituted constant variable: a6171 
o|substituted constant variable: a6173 
o|substituted constant variable: a6175 
o|substituted constant variable: a6177 
o|substituted constant variable: a6179 
o|substituted constant variable: a6181 
o|substituted constant variable: a6183 
o|substituted constant variable: a6185 
o|substituted constant variable: a6187 
o|substituted constant variable: a6189 
o|substituted constant variable: a6191 
o|substituted constant variable: a6193 
o|substituted constant variable: a6195 
o|substituted constant variable: a6197 
o|substituted constant variable: a6202 
o|substituted constant variable: a6204 
o|inlining procedure: k7589 
o|inlining procedure: k7589 
o|inlining procedure: k7600 
o|contracted procedure: "(csc.scm:246) g857858" 
o|inlining procedure: k7631 
o|contracted procedure: "(csc.scm:248) g868877" 
o|inlining procedure: k7631 
o|inlining procedure: k7665 
o|inlining procedure: k7665 
o|inlining procedure: k7600 
o|inlining procedure: k7727 
o|inlining procedure: k7727 
o|inlining procedure: k7737 
o|propagated global variable: r77388132 main#host-cflags 
o|inlining procedure: k7737 
o|propagated global variable: r77388134 main#default-cflags 
o|inlining procedure: k7740 
o|inlining procedure: k7740 
o|propagated global variable: r77418137 main#cygwin 
o|inlining procedure: k7744 
o|propagated global variable: r77458138 main#host-cxx 
o|inlining procedure: k7744 
o|propagated global variable: r77458140 main#default-cxx 
o|inlining procedure: k7748 
o|propagated global variable: r77498142 main#host-cc 
o|inlining procedure: k7748 
o|propagated global variable: r77498144 main#default-cc 
o|inlining procedure: k7752 
o|inlining procedure: k7752 
o|inlining procedure: k7762 
o|propagated global variable: r77638150 main#host-cxx 
o|inlining procedure: k7762 
o|propagated global variable: r77638152 main#default-cxx 
o|inlining procedure: k7766 
o|propagated global variable: r77678154 main#host-cc 
o|inlining procedure: k7766 
o|propagated global variable: r77678156 main#default-cc 
o|inlining procedure: k7807 
o|inlining procedure: k7807 
o|simplifications: ((if . 2)) 
o|replaced variables: 843 
o|removed binding forms: 452 
o|removed side-effect free assignment to unused variable: main#every 
o|removed side-effect free assignment to unused variable: main#any 
o|removed side-effect free assignment to unused variable: main#list-tabulate 
o|propagated global variable: out757760 ##sys#standard-error 
o|removed side-effect free assignment to unused variable: main#link-output-flag 
o|removed side-effect free assignment to unused variable: main#compile-output-flag 
o|removed side-effect free assignment to unused variable: main#default-translation-optimization-options 
o|removed side-effect free assignment to unused variable: main#constant807 
o|removed side-effect free assignment to unused variable: main#constant810 
o|removed side-effect free assignment to unused variable: main#constant814 
o|removed side-effect free assignment to unused variable: main#compile-only-flag 
o|substituted constant variable: rest192194 
o|substituted constant variable: mode193 
o|folded constant expression: (scheme#eq? (quote target) (quote target)) 
o|substituted constant variable: r72817902 
o|substituted constant variable: r74087908 
o|substituted constant variable: r74087911 
o|propagated global variable: out17231726 ##sys#standard-output 
o|substituted constant variable: r43747920 
o|substituted constant variable: r43747920 
o|inlining procedure: k4399 
o|inlining procedure: k4399 
o|substituted constant variable: r44007926 
o|substituted constant variable: r44007926 
o|inlining procedure: k4419 
o|propagated global variable: r44208182 main#object-extension 
o|propagated global variable: r44208182 main#object-extension 
o|inlining procedure: k4419 
o|propagated global variable: r44208184 main#executable-extension 
o|propagated global variable: r44208184 main#executable-extension 
o|substituted constant variable: a6880 
o|propagated global variable: out10531056 ##sys#standard-error 
o|substituted constant variable: r45417963 
o|substituted constant variable: r45417963 
o|substituted constant variable: r45417965 
o|substituted constant variable: r45417965 
o|substituted constant variable: r31737970 
o|propagated global variable: g476477 main#linked-extensions 
o|substituted constant variable: r64597972 
o|substituted constant variable: a6464 
o|substituted constant variable: r64827974 
o|substituted constant variable: r63298002 
o|substituted constant variable: r63298002 
o|inlining procedure: k6328 
o|inlining procedure: k6328 
o|substituted constant variable: r63668006 
o|substituted constant variable: r63668006 
o|inlining procedure: k6365 
o|inlining procedure: k6365 
o|substituted constant variable: r41138015 
o|substituted constant variable: r41138015 
o|substituted constant variable: r41928017 
o|substituted constant variable: r41928017 
o|inlining procedure: k4191 
o|propagated global variable: r41928252 main#host-libdir 
o|propagated global variable: r41928252 main#host-libdir 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|substituted constant variable: r55038081 
o|inlining procedure: k4678 
o|substituted constant variable: r55128083 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|contracted procedure: "(mini-srfi-1.scm:166) main#filter" 
o|substituted constant variable: r31297863 
o|inlining procedure: k4678 
o|substituted constant variable: r75908118 
o|substituted constant variable: r75908118 
o|substituted constant variable: r76018126 
o|substituted constant variable: r76018126 
o|removed call to pure procedure with unused result: "(csc.scm:66) scheme#eq?" 
o|replaced variables: 51 
o|removed binding forms: 921 
o|removed conditional forms: 1 
o|contracted procedure: k3791 
o|contracted procedure: k2470 
o|inlining procedure: k7482 
o|inlining procedure: k6928 
o|inlining procedure: k4533 
o|propagated global variable: r45348588 main#quotewrap-no-slash-trans 
o|inlining procedure: k4533 
o|propagated global variable: r45348592 main#quotewrap 
o|inlining procedure: k6475 
o|inlining procedure: k6475 
o|inlining procedure: k4637 
o|inlining procedure: k4168 
o|inlining procedure: k4168 
o|removed call to pure procedure with unused result: "(csc.scm:66) chicken.platform#software-type" 
o|replaced variables: 24 
o|removed binding forms: 206 
o|contracted procedure: k7797 
o|inlining procedure: k3872 
o|substituted constant variable: r2471 
o|substituted constant variable: r44008178 
o|substituted constant variable: r44008180 
o|inlining procedure: "(csc.scm:598) main#quotewrap-no-slash-trans" 
o|propagated global variable: str7778660 main#target-filename 
o|substituted constant variable: r64768598 
o|substituted constant variable: r64768599 
o|substituted constant variable: r63298234 
o|substituted constant variable: r63298236 
o|substituted constant variable: r63668238 
o|substituted constant variable: r63668240 
o|substituted constant variable: r41698621 
o|simplifications: ((if . 1) (let . 1)) 
o|replaced variables: 7 
o|removed binding forms: 29 
o|removed conditional forms: 4 
o|removed side-effect free assignment to unused variable: main#host-repo 
o|inlining procedure: k2464 
o|replaced variables: 3 
o|removed binding forms: 14 
o|substituted constant variable: r24658701 
o|removed binding forms: 4 
o|removed conditional forms: 1 
o|removed binding forms: 1 
o|simplifications: ((if . 36) (##core#call . 387)) 
o|  call simplifications:
o|    scheme#assq
o|    ##sys#call-with-values
o|    scheme#string-ci=?
o|    ##sys#size	4
o|    chicken.fixnum#fx>	4
o|    scheme#string
o|    scheme#cadr
o|    scheme#number?
o|    ##sys#list
o|    scheme#string=?
o|    scheme#member	10
o|    scheme#cdr	20
o|    scheme#equal?
o|    scheme#length	3
o|    scheme#>=	2
o|    scheme#char=?
o|    scheme#string->list	4
o|    scheme#memq	5
o|    scheme#char-whitespace?	4
o|    scheme#list->string
o|    scheme#string-length
o|    scheme#string-ref
o|    scheme#list	31
o|    ##sys#check-list	15
o|    scheme#pair?	20
o|    ##sys#setslot	10
o|    ##sys#slot	48
o|    scheme#eq?	83
o|    scheme#not	11
o|    ##sys#apply
o|    scheme#null?	14
o|    scheme#car	29
o|    scheme#cons	56
o|contracted procedure: k7835 
o|contracted procedure: k2356 
o|contracted procedure: k2952 
o|contracted procedure: k2963 
o|contracted procedure: k3795 
o|contracted procedure: k3799 
o|contracted procedure: k3803 
o|contracted procedure: k3807 
o|contracted procedure: k3850 
o|contracted procedure: k3853 
o|contracted procedure: k3890 
o|contracted procedure: k3918 
o|contracted procedure: k3950 
o|contracted procedure: k4029 
o|contracted procedure: k4037 
o|contracted procedure: k4078 
o|contracted procedure: k7710 
o|contracted procedure: k7706 
o|contracted procedure: k4081 
o|contracted procedure: k2482 
o|contracted procedure: k2464 
o|contracted procedure: k4273 
o|contracted procedure: k4293 
o|contracted procedure: k6689 
o|contracted procedure: k6695 
o|contracted procedure: k6707 
o|contracted procedure: k6710 
o|contracted procedure: k6713 
o|contracted procedure: k6721 
o|contracted procedure: k6729 
o|contracted procedure: k7176 
o|contracted procedure: k7182 
o|contracted procedure: k7194 
o|contracted procedure: k7197 
o|contracted procedure: k7200 
o|contracted procedure: k7208 
o|contracted procedure: k7216 
o|contracted procedure: k7237 
o|contracted procedure: k7323 
o|contracted procedure: k7332 
o|contracted procedure: k7283 
o|contracted procedure: k7286 
o|contracted procedure: k7292 
o|contracted procedure: k7316 
o|contracted procedure: k7375 
o|contracted procedure: k7410 
o|contracted procedure: k7414 
o|contracted procedure: k4369 
o|contracted procedure: k4376 
o|inlining procedure: k4362 
o|contracted procedure: k4373 
o|inlining procedure: k4362 
o|contracted procedure: k4434 
o|contracted procedure: k6742 
o|contracted procedure: k6745 
o|contracted procedure: k6766 
o|contracted procedure: k6778 
o|contracted procedure: k6788 
o|contracted procedure: k6792 
o|contracted procedure: k6795 
o|contracted procedure: k6857 
o|contracted procedure: k6865 
o|contracted procedure: k6891 
o|contracted procedure: k6894 
o|contracted procedure: k6897 
o|contracted procedure: k6905 
o|contracted procedure: k6913 
o|propagated global variable: g14911495 main#object-files 
o|contracted procedure: k7050 
o|contracted procedure: k3083 
o|contracted procedure: k3086 
o|contracted procedure: k3096 
o|contracted procedure: k3008 
o|contracted procedure: k3034 
o|contracted procedure: k6944 
o|contracted procedure: k6958 
o|contracted procedure: k6961 
o|contracted procedure: k6967 
o|contracted procedure: k6979 
o|contracted procedure: k6982 
o|contracted procedure: k6985 
o|contracted procedure: k6993 
o|contracted procedure: k7001 
o|contracted procedure: k7013 
o|contracted procedure: k7016 
o|contracted procedure: k7019 
o|contracted procedure: k7027 
o|contracted procedure: k7035 
o|contracted procedure: k7093 
o|contracted procedure: k7100 
o|contracted procedure: k7104 
o|contracted procedure: k7117 
o|contracted procedure: k7113 
o|contracted procedure: k4469 
o|contracted procedure: k4522 
o|contracted procedure: k4543 
o|contracted procedure: k3163 
o|contracted procedure: k3175 
o|contracted procedure: k3198 
o|contracted procedure: k3206 
o|propagated global variable: g476477 main#linked-extensions 
o|contracted procedure: k6423 
o|contracted procedure: k6427 
o|contracted procedure: k6439 
o|contracted procedure: k6435 
o|contracted procedure: k6458 
o|contracted procedure: k6469 
o|contracted procedure: k6489 
o|contracted procedure: k6475 
o|contracted procedure: k6492 
o|contracted procedure: k6510 
o|contracted procedure: k6514 
o|contracted procedure: k6522 
o|contracted procedure: k6533 
o|contracted procedure: k6546 
o|contracted procedure: k6552 
o|contracted procedure: k6564 
o|contracted procedure: k6574 
o|contracted procedure: k6578 
o|propagated global variable: g14351437 main#generated-rc-files 
o|contracted procedure: k6587 
o|contracted procedure: k6597 
o|contracted procedure: k6601 
o|propagated global variable: g14181420 main#generated-c-files 
o|contracted procedure: k6614 
o|contracted procedure: k6624 
o|contracted procedure: k6628 
o|propagated global variable: g13751399 main#rc-files 
o|contracted procedure: k6641 
o|contracted procedure: k6645 
o|contracted procedure: k7562 
o|contracted procedure: k7558 
o|contracted procedure: k7554 
o|contracted procedure: k6665 
o|contracted procedure: k6675 
o|contracted procedure: k6679 
o|propagated global variable: g13651377 main#c-files 
o|contracted procedure: k4554 
o|contracted procedure: k4575 
o|contracted procedure: k4572 
o|contracted procedure: k3298 
o|contracted procedure: k3288 
o|contracted procedure: k4598 
o|contracted procedure: k4578 
o|contracted procedure: k6379 
o|contracted procedure: k6391 
o|contracted procedure: k6401 
o|contracted procedure: k6405 
o|contracted procedure: k6376 
o|contracted procedure: k6371 
o|contracted procedure: k6210 
o|contracted procedure: k6234 
o|contracted procedure: k6238 
o|contracted procedure: k6241 
o|contracted procedure: k6245 
o|contracted procedure: k6273 
o|contracted procedure: k6277 
o|contracted procedure: k6283 
o|contracted procedure: k6295 
o|contracted procedure: k6298 
o|contracted procedure: k6301 
o|contracted procedure: k6309 
o|contracted procedure: k6317 
o|contracted procedure: k6348 
o|contracted procedure: k6358 
o|propagated global variable: g13021304 main#scheme-files 
o|contracted procedure: k4618 
o|contracted procedure: k4621 
o|contracted procedure: k4625 
o|contracted procedure: k4117 
o|contracted procedure: k4137 
o|contracted procedure: k4140 
o|contracted procedure: k4143 
o|contracted procedure: k4151 
o|contracted procedure: k4159 
o|contracted procedure: k4671 
o|contracted procedure: k4684 
o|contracted procedure: k4687 
o|contracted procedure: k4343 
o|contracted procedure: k4339 
o|contracted procedure: k4335 
o|contracted procedure: k4331 
o|contracted procedure: k4327 
o|contracted procedure: k4323 
o|contracted procedure: k4319 
o|contracted procedure: k4699 
o|contracted procedure: k4715 
o|contracted procedure: k4746 
o|contracted procedure: k4754 
o|contracted procedure: k4760 
o|contracted procedure: k4767 
o|contracted procedure: k4771 
o|contracted procedure: k4778 
o|contracted procedure: k4786 
o|contracted procedure: k4794 
o|contracted procedure: k4806 
o|contracted procedure: k4818 
o|contracted procedure: k4830 
o|contracted procedure: k4842 
o|contracted procedure: k4850 
o|contracted procedure: k4853 
o|contracted procedure: k4867 
o|contracted procedure: k4875 
o|contracted procedure: k4881 
o|contracted procedure: k4884 
o|contracted procedure: k4888 
o|contracted procedure: k4897 
o|contracted procedure: k4900 
o|contracted procedure: k4910 
o|contracted procedure: k4913 
o|contracted procedure: k4923 
o|contracted procedure: k4930 
o|contracted procedure: k4937 
o|contracted procedure: k4944 
o|contracted procedure: k4947 
o|contracted procedure: k4952 
o|contracted procedure: k4958 
o|contracted procedure: k4972 
o|contracted procedure: k4980 
o|contracted procedure: k4984 
o|contracted procedure: k4990 
o|contracted procedure: k4997 
o|contracted procedure: k5001 
o|contracted procedure: k5007 
o|contracted procedure: k5010 
o|contracted procedure: k5020 
o|contracted procedure: k5024 
o|contracted procedure: k5030 
o|contracted procedure: k4409 
o|contracted procedure: k5039 
o|contracted procedure: k5049 
o|contracted procedure: k5059 
o|contracted procedure: k5066 
o|contracted procedure: k5071 
o|contracted procedure: k5078 
o|contracted procedure: k5092 
o|contracted procedure: k5099 
o|contracted procedure: k5109 
o|contracted procedure: k5117 
o|contracted procedure: k5123 
o|contracted procedure: k5126 
o|contracted procedure: k5132 
o|contracted procedure: k5136 
o|contracted procedure: k5143 
o|contracted procedure: k5146 
o|contracted procedure: k5156 
o|contracted procedure: k5166 
o|contracted procedure: k5176 
o|contracted procedure: k5186 
o|contracted procedure: k5196 
o|contracted procedure: k5206 
o|contracted procedure: k5216 
o|contracted procedure: k5226 
o|contracted procedure: k5236 
o|contracted procedure: k5246 
o|contracted procedure: k5259 
o|contracted procedure: k5270 
o|contracted procedure: k5274 
o|contracted procedure: k5280 
o|contracted procedure: k5288 
o|contracted procedure: k5300 
o|contracted procedure: k5303 
o|contracted procedure: k5312 
o|contracted procedure: k5319 
o|contracted procedure: k5323 
o|contracted procedure: k5329 
o|contracted procedure: k5336 
o|contracted procedure: k5340 
o|contracted procedure: k5346 
o|contracted procedure: k5353 
o|contracted procedure: k5357 
o|contracted procedure: k5363 
o|contracted procedure: k5370 
o|contracted procedure: k5374 
o|contracted procedure: k5380 
o|contracted procedure: k5391 
o|contracted procedure: k5395 
o|contracted procedure: k5401 
o|contracted procedure: k5412 
o|contracted procedure: k5420 
o|contracted procedure: k5426 
o|contracted procedure: k5434 
o|contracted procedure: k5440 
o|contracted procedure: k5451 
o|contracted procedure: k5459 
o|contracted procedure: k5465 
o|contracted procedure: k5472 
o|contracted procedure: k5479 
o|contracted procedure: k5490 
o|contracted procedure: k5505 
o|contracted procedure: k5514 
o|contracted procedure: k5520 
o|contracted procedure: k5530 
o|contracted procedure: k5534 
o|contracted procedure: k5540 
o|contracted procedure: k5550 
o|contracted procedure: k5554 
o|contracted procedure: k5560 
o|contracted procedure: k5580 
o|contracted procedure: k5593 
o|contracted procedure: k5589 
o|contracted procedure: k5602 
o|contracted procedure: k5611 
o|contracted procedure: k5621 
o|contracted procedure: k5625 
o|contracted procedure: k5658 
o|contracted procedure: k5661 
o|contracted procedure: k5685 
o|contracted procedure: k5688 
o|contracted procedure: k5726 
o|contracted procedure: k5740 
o|contracted procedure: k5828 
o|contracted procedure: k5746 
o|contracted procedure: k5749 
o|contracted procedure: k5755 
o|contracted procedure: k5763 
o|contracted procedure: k5785 
o|contracted procedure: k5788 
o|contracted procedure: k5791 
o|contracted procedure: k5799 
o|contracted procedure: k5807 
o|contracted procedure: k5773 
o|contracted procedure: k3388 
o|contracted procedure: k3395 
o|contracted procedure: k3418 
o|contracted procedure: k3411 
o|contracted procedure: k3119 
o|contracted procedure: k3131 
o|contracted procedure: k3149 
o|contracted procedure: k3157 
o|contracted procedure: k5842 
o|contracted procedure: k5833 
o|contracted procedure: k5868 
o|contracted procedure: k5876 
o|contracted procedure: k5882 
o|contracted procedure: k5890 
o|contracted procedure: k5896 
o|contracted procedure: k5904 
o|contracted procedure: k5910 
o|contracted procedure: k5922 
o|contracted procedure: k5926 
o|contracted procedure: k5932 
o|contracted procedure: k5941 
o|contracted procedure: k5957 
o|contracted procedure: k5965 
o|contracted procedure: k5980 
o|contracted procedure: k5996 
o|contracted procedure: k5988 
o|contracted procedure: k6010 
o|contracted procedure: k6001 
o|contracted procedure: k6019 
o|contracted procedure: k6057 
o|contracted procedure: k7605 
o|contracted procedure: k7613 
o|contracted procedure: k7622 
o|contracted procedure: k7634 
o|contracted procedure: k7637 
o|contracted procedure: k7640 
o|contracted procedure: k7648 
o|contracted procedure: k7656 
o|contracted procedure: k7668 
o|contracted procedure: k7671 
o|contracted procedure: k7674 
o|contracted procedure: k7682 
o|contracted procedure: k7690 
o|contracted procedure: k7843 
o|contracted procedure: k7847 
o|contracted procedure: k7851 
o|simplifications: ((if . 3) (let . 52)) 
o|removed binding forms: 359 
o|inlining procedure: k5105 
o|inlining procedure: k5105 
o|inlining procedure: k5255 
o|inlining procedure: k5255 
o|inlining procedure: k5475 
o|inlining procedure: k5475 
o|substituted constant variable: r7844 
o|substituted constant variable: r7848 
o|substituted constant variable: r7844 
o|substituted constant variable: r7848 
o|substituted constant variable: r7852 
o|simplifications: ((let . 2)) 
o|replaced variables: 76 
o|removed binding forms: 1 
o|inlining procedure: k4678 
o|simplifications: ((if . 2)) 
o|removed binding forms: 53 
o|removed binding forms: 1 
o|direct leaf routine/allocation: g490491 3 
o|direct leaf routine/allocation: loop530 0 
o|direct leaf routine/allocation: g12181219 3 
o|contracted procedure: k4568 
o|converted assignments to bindings: (loop530) 
o|inlining procedure: "(csc.scm:791) k4678" 
o|simplifications: ((let . 1)) 
o|removed binding forms: 1 
x|eliminated type checks:
x|  C_i_check_list_2:	1
o|customizable procedures: (k3936 k7593 map-loop889906 map-loop862913 k5291 k5574 k5577 k5631 k5640 k5949 k5913 k5732 foldr457460 g462463 foldl563567 map-loop12351253 k5482 shared-build1011 check1010 k4856 t-options1009 loop1033 k4101 k4105 map-loop941966 k4604 k4607 k6269 k6334 k6324 map-loop13161337 k6222 for-each-loop12951349 generate-target-filename1013 g13591376 for-each-loop13581389 k6631 k6498 g13691398 for-each-loop13681404 for-each-loop14111421 for-each-loop14281438 k6451 main#compiler-options foldr475478 g480481 k4460 k7063 map-loop15651582 map-loop15421589 loop1596 loop420 loop440 map-loop14791496 main#linker-options main#linker-libraries main#command for-each-loop15131523 main#stop g17191720 main#string-any k7304 fold1669 main#cons* lp1682 main#libchicken map-loop16351652 map-loop14511468 main#repo-path loop407) 
o|calls to known targets: 308 
o|identified direct recursive calls: f_2947 1 
o|identified direct recursive calls: f_7278 1 
o|identified direct recursive calls: f_3170 1 
o|identified direct recursive calls: f_3283 1 
o|identified direct recursive calls: f_3126 1 
o|fast box initializations: 30 
o|fast global references: 413 
o|fast global assignments: 202 
o|dropping unused closure argument: f_2941 
o|dropping unused closure argument: f_3283 
o|dropping unused closure argument: f_3817 
o|dropping unused closure argument: f_3941 
o|dropping unused closure argument: f_4226 
o|dropping unused closure argument: f_4350 
o|dropping unused closure argument: f_4357 
o|dropping unused closure argument: f_4383 
o|dropping unused closure argument: f_4413 
o|dropping unused closure argument: f_6683 
o|dropping unused closure argument: f_7170 
o|dropping unused closure argument: f_7223 
o|dropping unused closure argument: f_7321 
o|dropping unused closure argument: f_7467 
*/
/* end of file */
