/* Generated from chicken-ffi-syntax.scm by the CHICKEN compiler
   http://www.call-cc.org
   Version 5.1.0rc1 (prerelease) (rev 7358d2e5)
   linux-unix-gnu-x86-64 [ 64bit dload ptables ]
   command line: chicken-ffi-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -consult-types-file ./types.db -explicit-use -no-trace -output-file chicken-ffi-syntax.c
   unit: chicken-ffi-syntax
   uses: data-structures extras internal library expand
*/
#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_internal_toplevel)
C_externimport void C_ccall C_internal_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[98];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,16),40,97,50,55,51,50,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,42),40,99,111,109,112,105,108,101,114,45,111,110,108,121,45,101,114,45,116,114,97,110,115,102,111,114,109,101,114,32,116,114,97,110,115,102,111,114,109,101,114,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,16),40,97,50,56,48,51,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,49,48,49,55,32,103,49,48,50,57,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,16),40,97,50,56,52,55,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,57,55,54,32,103,57,56,56,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,16),40,97,50,57,52,50,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,57,52,50,32,103,57,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,16),40,97,51,48,51,51,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,57,48,49,32,103,57,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,16),40,97,51,49,50,56,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,56,54,48,32,103,56,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,56,51,49,32,103,56,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,16),40,97,51,50,49,57,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,16),40,97,51,51,57,52,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,16),40,97,51,52,49,49,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,16),40,97,51,52,50,56,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,16),40,97,51,52,52,57,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,16),40,97,51,53,49,53,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,6),40,103,55,50,48,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,98,105,110,100,105,110,103,115,32,97,108,105,97,115,101,115,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,11),40,97,51,54,57,48,32,98,32,97,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,10),40,103,49,53,56,32,120,32,114,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,15),40,102,111,108,100,114,49,53,51,32,103,49,53,52,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,49,57,53,32,103,50,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,49,54,56,32,103,49,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,108,115,116,115,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,55,49,52,32,103,55,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,16),40,97,51,53,56,56,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,16),40,97,51,55,53,53,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,13),40,97,51,56,52,49,32,120,32,114,32,99,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,54,53,50,32,103,54,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,54,50,53,32,103,54,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,16),40,97,51,56,54,50,32,102,111,114,109,32,114,32,99,41};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word *av) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word *av) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word *av) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word *av) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word *av) C_noret;
C_noret_decl(f_1659)
static void C_fcall f_1659(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1667)
static void C_fcall f_1667(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word *av) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word *av) C_noret;
C_noret_decl(f_1699)
static void C_fcall f_1699(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word *av) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word *av) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word *av) C_noret;
C_noret_decl(f_1731)
static void C_fcall f_1731(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word *av) C_noret;
C_noret_decl(f_1780)
static void C_fcall f_1780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1854)
static C_word C_fcall f_1854(C_word t0);
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word *av) C_noret;
C_noret_decl(f_2727)
static void C_fcall f_2727(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word *av) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word *av) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word *av) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word *av) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word *av) C_noret;
C_noret_decl(f_2762)
static void C_ccall f_2762(C_word c,C_word *av) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word *av) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word *av) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word *av) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word *av) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word *av) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word *av) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word *av) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word *av) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word *av) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word *av) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word *av) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word *av) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word *av) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word *av) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word *av) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word *av) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word *av) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word *av) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word *av) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word *av) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word *av) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word *av) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word *av) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word *av) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word *av) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word *av) C_noret;
C_noret_decl(f_2901)
static void C_fcall f_2901(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word *av) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word *av) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word *av) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word *av) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word *av) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word *av) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word *av) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word *av) C_noret;
C_noret_decl(f_2992)
static void C_fcall f_2992(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word *av) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word *av) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word *av) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word *av) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word *av) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word *av) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word *av) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word *av) C_noret;
C_noret_decl(f_3087)
static void C_fcall f_3087(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word *av) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word *av) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word *av) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word *av) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word *av) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word *av) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word *av) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word *av) C_noret;
C_noret_decl(f_3178)
static void C_fcall f_3178(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word *av) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word *av) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word *av) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word *av) C_noret;
C_noret_decl(f_3227)
static void C_fcall f_3227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word *av) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word *av) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word *av) C_noret;
C_noret_decl(f_3259)
static void C_fcall f_3259(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word *av) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word *av) C_noret;
C_noret_decl(f_3290)
static void C_fcall f_3290(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word *av) C_noret;
C_noret_decl(f_3324)
static void C_fcall f_3324(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word *av) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word *av) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word *av) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word *av) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word *av) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word *av) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word *av) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word *av) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word *av) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word *av) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word *av) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word *av) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word *av) C_noret;
C_noret_decl(f_3467)
static void C_fcall f_3467(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word *av) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word *av) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word *av) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word *av) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word *av) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word *av) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word *av) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word *av) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word *av) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word *av) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word *av) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word *av) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word *av) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word *av) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word *av) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word *av) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word *av) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word *av) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word *av) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word *av) C_noret;
C_noret_decl(f_3602)
static void C_fcall f_3602(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word *av) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word *av) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word *av) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word *av) C_noret;
C_noret_decl(f_3629)
static void C_fcall f_3629(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word *av) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word *av) C_noret;
C_noret_decl(f_3714)
static void C_fcall f_3714(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word *av) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word *av) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word *av) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word *av) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word *av) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word *av) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word *av) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word *av) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word *av) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word *av) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word *av) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word *av) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word *av) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word *av) C_noret;
C_noret_decl(f_3870)
static void C_fcall f_3870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_fcall f_3873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word *av) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word *av) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word *av) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word *av) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word *av) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word *av) C_noret;
C_noret_decl(f_4007)
static void C_fcall f_4007(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word *av) C_noret;
C_noret_decl(f_4056)
static void C_fcall f_4056(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word *av) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word *av) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dffi_2dsyntax_toplevel)
C_externexport void C_ccall C_chicken_2dffi_2dsyntax_toplevel(C_word c,C_word *av) C_noret;

C_noret_decl(trf_1659)
static void C_ccall trf_1659(C_word c,C_word *av) C_noret;
static void C_ccall trf_1659(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1659(t0,t1,t2);}

C_noret_decl(trf_1667)
static void C_ccall trf_1667(C_word c,C_word *av) C_noret;
static void C_ccall trf_1667(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1667(t0,t1,t2,t3);}

C_noret_decl(trf_1699)
static void C_ccall trf_1699(C_word c,C_word *av) C_noret;
static void C_ccall trf_1699(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1699(t0,t1,t2);}

C_noret_decl(trf_1731)
static void C_ccall trf_1731(C_word c,C_word *av) C_noret;
static void C_ccall trf_1731(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1731(t0,t1,t2);}

C_noret_decl(trf_1780)
static void C_ccall trf_1780(C_word c,C_word *av) C_noret;
static void C_ccall trf_1780(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1780(t0,t1,t2);}

C_noret_decl(trf_2727)
static void C_ccall trf_2727(C_word c,C_word *av) C_noret;
static void C_ccall trf_2727(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2727(t0,t1);}

C_noret_decl(trf_2901)
static void C_ccall trf_2901(C_word c,C_word *av) C_noret;
static void C_ccall trf_2901(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2901(t0,t1,t2);}

C_noret_decl(trf_2992)
static void C_ccall trf_2992(C_word c,C_word *av) C_noret;
static void C_ccall trf_2992(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2992(t0,t1,t2);}

C_noret_decl(trf_3087)
static void C_ccall trf_3087(C_word c,C_word *av) C_noret;
static void C_ccall trf_3087(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3087(t0,t1,t2);}

C_noret_decl(trf_3178)
static void C_ccall trf_3178(C_word c,C_word *av) C_noret;
static void C_ccall trf_3178(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3178(t0,t1,t2);}

C_noret_decl(trf_3227)
static void C_ccall trf_3227(C_word c,C_word *av) C_noret;
static void C_ccall trf_3227(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3227(t0,t1);}

C_noret_decl(trf_3259)
static void C_ccall trf_3259(C_word c,C_word *av) C_noret;
static void C_ccall trf_3259(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3259(t0,t1);}

C_noret_decl(trf_3290)
static void C_ccall trf_3290(C_word c,C_word *av) C_noret;
static void C_ccall trf_3290(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3290(t0,t1,t2);}

C_noret_decl(trf_3324)
static void C_ccall trf_3324(C_word c,C_word *av) C_noret;
static void C_ccall trf_3324(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3324(t0,t1,t2);}

C_noret_decl(trf_3467)
static void C_ccall trf_3467(C_word c,C_word *av) C_noret;
static void C_ccall trf_3467(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3467(t0,t1);}

C_noret_decl(trf_3602)
static void C_ccall trf_3602(C_word c,C_word *av) C_noret;
static void C_ccall trf_3602(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3602(t0,t1);}

C_noret_decl(trf_3629)
static void C_ccall trf_3629(C_word c,C_word *av) C_noret;
static void C_ccall trf_3629(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3629(t0,t1,t2,t3);}

C_noret_decl(trf_3714)
static void C_ccall trf_3714(C_word c,C_word *av) C_noret;
static void C_ccall trf_3714(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3714(t0,t1,t2);}

C_noret_decl(trf_3870)
static void C_ccall trf_3870(C_word c,C_word *av) C_noret;
static void C_ccall trf_3870(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3870(t0,t1);}

C_noret_decl(trf_3873)
static void C_ccall trf_3873(C_word c,C_word *av) C_noret;
static void C_ccall trf_3873(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3873(t0,t1);}

C_noret_decl(trf_4007)
static void C_ccall trf_4007(C_word c,C_word *av) C_noret;
static void C_ccall trf_4007(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4007(t0,t1,t2);}

C_noret_decl(trf_4056)
static void C_ccall trf_4056(C_word c,C_word *av) C_noret;
static void C_ccall trf_4056(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4056(t0,t1,t2);}

/* k1429 */
static void C_ccall f_1431(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1431,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1434,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* k1432 in k1429 */
static void C_ccall f_1434(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1434,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_internal_toplevel(2,av2);}}

/* k1435 in k1432 in k1429 */
static void C_ccall f_1437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1437,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_1440(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1440,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_expand_toplevel(2,av2);}}

/* k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_1443(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_1443,2,av);}
a=C_alloc(11);
t2=C_a_i_provide(&a,1,lf[0]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:51: ##sys#macro-environment */
t4=*((C_word*)lf[97]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* foldr153 in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_1659(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(9,0,4)))){
C_save_and_reclaim_args((void *)trf_1659,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[2],a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1686,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g158 in foldr153 in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_1667(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_1667,4,t0,t1,t2,t3);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1675,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* mini-srfi-1.scm:72: proc */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1673 in g158 in foldr153 in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_1675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_1675,2,av);}
/* mini-srfi-1.scm:72: scheme#append */
t2=*((C_word*)lf[78]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1684 in foldr153 in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_1686(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_1686,2,av);}
/* mini-srfi-1.scm:72: g158 */
t2=((C_word*)t0)[2];
f_1667(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* loop in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_1699(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,0,3)))){
C_save_and_reclaim_args((void *)trf_1699,3,t0,t1,t2);}
a=C_alloc(25);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1854,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
t5=(
  f_1854(t3)
);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1713,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=t2;
t12=C_i_check_list_2(t11,lf[26]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1778,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1780,a[2]=t9,a[3]=t15,a[4]=t10,a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_1780(t17,t13,t11);}}

/* k1711 in loop in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_1713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,3)))){
C_save_and_reclaim((void *)f_1713,2,av);}
a=C_alloc(21);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1717,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)t0)[3];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1731,a[2]=t6,a[3]=t11,a[4]=t7,a[5]=((C_word)li25),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_1731(t13,t9,t8);}

/* k1715 in k1711 in loop in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_1717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_1717,2,av);}
/* mini-srfi-1.scm:76: scheme#append */
t2=*((C_word*)lf[78]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1727 in k1711 in loop in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_1729(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_1729,2,av);}
/* mini-srfi-1.scm:77: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1699(t2,((C_word*)t0)[3],t1);}

/* map-loop195 in k1711 in loop in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_1731(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_1731,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1776 in loop in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_1778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_1778,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
C_apply(4,av2);}}

/* map-loop168 in loop in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_1780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_1780,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in loop in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static C_word C_fcall f_1854(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=C_i_car(t1);
t3=C_i_nullp(t2);
if(C_truep(t3)){
return(t3);}
else{
t4=t1;
t5=C_u_i_cdr(t4);
t7=t5;
t1=t7;
goto loop;}}}

/* k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_2725,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2727,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2753,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4161,a[2]=t4,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:66: chicken.base#alist-ref */
t6=*((C_word*)lf[73]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[88];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* compiler-only-er-transformer in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_2727(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,5)))){
C_save_and_reclaim_args((void *)trf_2727,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2733,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:57: ##sys#er-transformer */
t4=*((C_word*)lf[5]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a2732 in compiler-only-er-transformer in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_2733,5,av);}
a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* chicken-ffi-syntax.scm:59: chicken.platform#feature? */
t6=*((C_word*)lf[3]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[4];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k2738 in a2732 in compiler-only-er-transformer in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2740(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_2740,2,av);}
if(C_truep(t1)){
/* chicken-ffi-syntax.scm:60: transformer */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=C_i_car(((C_word*)t0)[4]);
/* chicken-ffi-syntax.scm:61: chicken.syntax#syntax-error */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=lf[2];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_2753,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3840,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3842,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:106: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2756,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3836,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:113: chicken.base#alist-ref */
t4=*((C_word*)lf[73]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[80];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2759(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_2759,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3587,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3589,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:131: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2762(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_2762,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3583,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:166: chicken.base#alist-ref */
t4=*((C_word*)lf[73]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[59];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_2765,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3450,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:182: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2768(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_2768,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3427,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3429,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:208: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_2771,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3412,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:219: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2774(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_2774,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3393,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3395,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:227: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2777(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_2777,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3218,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3220,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:235: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_2780,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3127,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:254: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2783(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_2783,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3032,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3034,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:268: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_2786,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2943,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:285: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2789(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,5)))){
C_save_and_reclaim((void *)f_2789,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2848,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:299: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2790 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2792(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,5)))){
C_save_and_reclaim((void *)f_2792,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2802,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2804,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:314: compiler-only-er-transformer */
f_2727(t3,t4);}

/* k2793 in k2790 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2795(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2795,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:329: chicken.internal#macro-subset */
t3=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2796 in k2793 in k2790 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_ccall f_2798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_2798,2,av);}
t2=C_mutate((C_word*)lf[6]+1 /* (set! ##sys#chicken-ffi-macro-environment ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2800 in k2790 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_2802,2,av);}
/* chicken-ffi-syntax.scm:311: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[9];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a2803 in k2790 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2804(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_2804,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2808,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:316: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[9];
av2[3]=t2;
av2[4]=lf[24];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2806 in a2803 in k2790 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_ccall f_2808(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2808,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2811,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* chicken-ffi-syntax.scm:317: chicken.syntax#strip-syntax */
t4=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2809 in k2806 in a2803 in k2790 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in ... */
static void C_ccall f_2811(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2811,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2814,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:318: chicken.base#gensym */
t4=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[21];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2812 in k2809 in k2806 in a2803 in k2790 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in ... */
static void C_ccall f_2814(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_2814,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2817,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
f_2817(2,av2);}}
else{
/* chicken-ffi-syntax.scm:323: chicken.compiler.c-backend#foreign-type-declaration */
t4=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[19];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k2815 in k2812 in k2809 in k2806 in a2803 in k2790 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in ... */
static void C_ccall f_2817(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_2817,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:325: scheme#string-append */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[16];
av2[3]=t1;
av2[4]=lf[17];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2830 in k2815 in k2812 in k2809 in k2806 in a2803 in k2790 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in ... */
static void C_ccall f_2832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,c,1)))){
C_save_and_reclaim((void *)f_2832,2,av);}
a=C_alloc(33);
t2=C_a_i_list(&a,4,lf[10],((C_word*)t0)[2],lf[11],t1);
t3=C_a_i_list(&a,4,lf[12],lf[13],C_SCHEME_FALSE,((C_word*)t0)[2]);
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[14],t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2844 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_2846,2,av);}
/* chicken-ffi-syntax.scm:296: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[25];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a2847 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_2848,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2852,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:301: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[25];
av2[3]=t2;
av2[4]=lf[32];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2850 in a2847 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_2852,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_caddr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:305: chicken.syntax#strip-syntax */
t8=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k2879 in k2850 in a2847 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_ccall f_2881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_2881,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(t1,lf[26]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2901,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2901(t7,t3,t1);}

/* k2885 in k2879 in k2850 in a2847 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in ... */
static void C_ccall f_2887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_2887,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2891,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2895,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:307: chicken.syntax#strip-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k2889 in k2885 in k2879 in k2850 in a2847 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in ... */
static void C_ccall f_2891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,1)))){
C_save_and_reclaim((void *)f_2891,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,3,lf[27],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,lf[28],t4);
t6=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[12],t2,C_SCHEME_FALSE,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k2893 in k2885 in k2879 in k2850 in a2847 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in ... */
static void C_ccall f_2895(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2895,2,av);}
/* chicken-ffi-syntax.scm:306: chicken.compiler.support#foreign-type->scrutiny-type */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[30];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop1017 in k2879 in k2850 in a2847 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in ... */
static void C_fcall f_2901(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_2901,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
/* chicken-ffi-syntax.scm:304: chicken.compiler.support#foreign-type->scrutiny-type */
t6=*((C_word*)lf[29]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=lf[31];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2924 in map-loop1017 in k2879 in k2850 in a2847 in k2787 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in ... */
static void C_ccall f_2926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2926,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2901(t6,((C_word*)t0)[5],t5);}

/* k2939 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_2941,2,av);}
/* chicken-ffi-syntax.scm:282: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[33];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a2942 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2943(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_2943,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2947,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:287: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[33];
av2[3]=t2;
av2[4]=lf[35];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2945 in a2942 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_2947,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_cdddr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:290: chicken.syntax#strip-syntax */
t8=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k2970 in k2945 in a2942 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_2972(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_2972,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(t1,lf[26]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2992,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2992(t7,t3,t1);}

/* k2976 in k2970 in k2945 in a2942 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_ccall f_2978(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_2978,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2982,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2986,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:292: chicken.syntax#strip-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k2980 in k2976 in k2970 in k2945 in a2942 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in ... */
static void C_ccall f_2982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,1)))){
C_save_and_reclaim((void *)f_2982,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,3,lf[27],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,lf[34],t4);
t6=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[12],t2,C_SCHEME_FALSE,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k2984 in k2976 in k2970 in k2945 in a2942 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in ... */
static void C_ccall f_2986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2986,2,av);}
/* chicken-ffi-syntax.scm:291: chicken.compiler.support#foreign-type->scrutiny-type */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[30];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop976 in k2970 in k2945 in a2942 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_fcall f_2992(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_2992,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3017,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[29]+1);
/* chicken-ffi-syntax.scm:289: g999 */
t6=*((C_word*)lf[29]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[31];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3015 in map-loop976 in k2970 in k2945 in a2942 in k2784 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in ... */
static void C_ccall f_3017(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3017,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2992(t6,((C_word*)t0)[5],t5);}

/* k3030 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3032(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3032,2,av);}
/* chicken-ffi-syntax.scm:265: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[36];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3033 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3034,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3038,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:270: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[36];
av2[3]=t2;
av2[4]=lf[38];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3036 in a3033 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3038(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_3038,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_caddr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:276: chicken.syntax#strip-syntax */
t8=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k3065 in k3036 in a3033 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_3067,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(t1,lf[26]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3087,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word)li7),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3087(t7,t3,t1);}

/* k3071 in k3065 in k3036 in a3033 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_3073,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3077,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3081,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:278: chicken.syntax#strip-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k3075 in k3071 in k3065 in k3036 in a3033 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_ccall f_3077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,1)))){
C_save_and_reclaim((void *)f_3077,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,3,lf[27],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,lf[37],t4);
t6=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[12],t2,C_SCHEME_FALSE,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k3079 in k3071 in k3065 in k3036 in a3033 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_ccall f_3081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3081,2,av);}
/* chicken-ffi-syntax.scm:277: chicken.compiler.support#foreign-type->scrutiny-type */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[30];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop942 in k3065 in k3036 in a3033 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_3087(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_3087,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3112,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
/* chicken-ffi-syntax.scm:273: chicken.compiler.support#foreign-type->scrutiny-type */
t6=*((C_word*)lf[29]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=lf[31];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3110 in map-loop942 in k3065 in k3036 in a3033 in k2781 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_ccall f_3112(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3112,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3087(t6,((C_word*)t0)[5],t5);}

/* k3125 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3127,2,av);}
/* chicken-ffi-syntax.scm:251: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[39];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3128 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3129,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3133,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:256: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[39];
av2[3]=t2;
av2[4]=lf[41];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3131 in a3128 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_3133,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_cdddr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:259: chicken.syntax#strip-syntax */
t8=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k3156 in k3131 in a3128 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_3158,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(t1,lf[26]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3178,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word)li9),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3178(t7,t3,t1);}

/* k3162 in k3156 in k3131 in a3128 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_3164,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3168,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:261: chicken.syntax#strip-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k3166 in k3162 in k3156 in k3131 in a3128 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3168(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,1)))){
C_save_and_reclaim((void *)f_3168,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,3,lf[27],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,lf[40],t4);
t6=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[12],t2,C_SCHEME_FALSE,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k3170 in k3162 in k3156 in k3131 in a3128 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3172(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3172,2,av);}
/* chicken-ffi-syntax.scm:260: chicken.compiler.support#foreign-type->scrutiny-type */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[30];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop901 in k3156 in k3131 in a3128 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_3178(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_3178,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3203,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[29]+1);
/* chicken-ffi-syntax.scm:258: g924 */
t6=*((C_word*)lf[29]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[31];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3201 in map-loop901 in k3156 in k3131 in a3128 in k2778 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3203(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3203,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3178(t6,((C_word*)t0)[5],t5);}

/* k3216 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3218,2,av);}
/* chicken-ffi-syntax.scm:232: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[42];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3220(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3220,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3224,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:237: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[42];
av2[3]=t2;
av2[4]=lf[45];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3222 in a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3224(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3224,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cddr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t3))){
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_i_stringp(t4);
t6=t2;
f_3227(t6,C_i_not(t5));}
else{
t4=t2;
f_3227(t4,C_SCHEME_FALSE);}}

/* k3225 in k3222 in a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_3227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3227,2,t0,t1);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_car(t5);
/* chicken-ffi-syntax.scm:239: chicken.syntax#strip-syntax */
t7=*((C_word*)lf[22]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t3;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_3230(2,av2);}}}

/* k3228 in k3225 in k3222 in a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3230(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3230,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=C_i_caddr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:240: chicken.syntax#strip-syntax */
t5=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_car(t5);
/* chicken-ffi-syntax.scm:240: chicken.syntax#strip-syntax */
t7=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}

/* k3231 in k3228 in k3225 in k3222 in a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_3233,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=C_i_check_list_2(t1,lf[26]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3324,a[2]=t4,a[3]=t9,a[4]=t5,a[5]=((C_word)li12),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3324(t11,t7,t1);}

/* k3240 in k3231 in k3228 in k3225 in k3222 in a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,3)))){
C_save_and_reclaim((void *)f_3242,2,av);}
a=C_alloc(21);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(t1,lf[26]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3274,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3290,a[2]=t5,a[3]=t10,a[4]=t6,a[5]=((C_word)li11),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_3290(t12,t8,t1);}

/* k3257 in k3240 in k3231 in k3228 in k3225 in k3222 in a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_fcall f_3259(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,1)))){
C_save_and_reclaim_args((void *)trf_3259,2,t0,t1);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,lf[27],t1);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,lf[43],t4);
t6=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[12],t2,C_SCHEME_FALSE,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k3272 in k3240 in k3231 in k3228 in k3225 in k3222 in a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_ccall f_3274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_3274,2,av);}
a=C_alloc(4);
t2=t1;
if(C_truep(C_i_not(((C_word*)t0)[2]))){
t3=((C_word*)t0)[3];
f_3259(t3,C_a_i_cons(&a,2,t2,lf[44]));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3288,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:247: chicken.compiler.support#foreign-type->scrutiny-type */
t4=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[30];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k3286 in k3272 in k3240 in k3231 in k3228 in k3225 in k3222 in a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in ... */
static void C_ccall f_3288(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_3288,2,av);}
a=C_alloc(6);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
f_3259(t3,C_a_i_cons(&a,2,((C_word*)t0)[3],t2));}

/* map-loop860 in k3240 in k3231 in k3228 in k3225 in k3222 in a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_fcall f_3290(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_3290,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[29]+1);
/* chicken-ffi-syntax.scm:243: g883 */
t6=*((C_word*)lf[29]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[31];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3313 in map-loop860 in k3240 in k3231 in k3228 in k3225 in k3222 in a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in ... */
static void C_ccall f_3315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3315,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3290(t6,((C_word*)t0)[5],t5);}

/* map-loop831 in k3231 in k3228 in k3225 in k3222 in a3219 in k2775 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_3324(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_3324,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3391 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3393(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3393,2,av);}
/* chicken-ffi-syntax.scm:224: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[46];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3394 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3395,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3399,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:229: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[46];
av2[3]=t2;
av2[4]=lf[47];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3397 in a3394 in k2772 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3399,2,av);}
a=C_alloc(3);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[10],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3408 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3410,2,av);}
/* chicken-ffi-syntax.scm:216: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[48];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3411 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3412(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3412,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3416,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:221: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[48];
av2[3]=t2;
av2[4]=lf[50];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3414 in a3411 in k2769 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3416(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3416,2,av);}
a=C_alloc(3);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[49],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3425 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3427,2,av);}
/* chicken-ffi-syntax.scm:205: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[51];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3428 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3429(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3429,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3433,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:210: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[51];
av2[3]=t2;
av2[4]=lf[53];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3431 in a3428 in k2766 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_3433,2,av);}
a=C_alloc(9);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,lf[51],t2);
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[52],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3446 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3448(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3448,2,av);}
/* chicken-ffi-syntax.scm:179: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[54];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3449 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3450(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3450,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3454,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:184: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[54];
av2[3]=t2;
av2[4]=lf[58];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3452 in a3449 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3454,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:185: chicken.base#gensym */
t3=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[57];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3455 in k3452 in a3449 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,4)))){
C_save_and_reclaim((void *)f_3457,2,av);}
a=C_alloc(22);
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3467,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=C_i_caddr(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3491,a[2]=t4,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_stringp(t3))){
t8=t4;
f_3467(t8,C_a_i_list(&a,4,lf[10],t2,t6,t3));}
else{
if(C_truep(C_i_symbolp(t3))){
/* chicken-ffi-syntax.scm:191: scheme#symbol->string */
t8=*((C_word*)lf[55]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
/* chicken-ffi-syntax.scm:193: chicken.syntax#syntax-error */
t8=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[54];
av2[3]=lf[56];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}}

/* k3465 in k3455 in k3452 in a3449 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_3467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_3467,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3479,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_caddr(((C_word*)t0)[4]);
/* chicken-ffi-syntax.scm:198: chicken.syntax#strip-syntax */
t6=*((C_word*)lf[22]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k3473 in k3465 in k3455 in k3452 in a3449 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3475(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,1)))){
C_save_and_reclaim((void *)f_3475,2,av);}
a=C_alloc(21);
t2=C_a_i_list(&a,4,lf[12],t1,C_SCHEME_FALSE,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[14],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3477 in k3465 in k3455 in k3452 in a3449 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3479(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3479,2,av);}
/* chicken-ffi-syntax.scm:197: chicken.compiler.support#foreign-type->scrutiny-type */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[30];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3489 in k3455 in k3452 in a3449 in k2763 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3491(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,1)))){
C_save_and_reclaim((void *)f_3491,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
f_3467(t2,C_a_i_list(&a,4,lf[10],((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k3512 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3514(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3514,2,av);}
/* chicken-ffi-syntax.scm:164: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[60];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_3516,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3520,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:169: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[60];
av2[3]=t2;
av2[4]=lf[72];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3518 in a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3520,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:170: chicken.base#gensym */
t3=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[71];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3521 in k3518 in a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3523,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3538,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:172: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[59];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3536 in k3521 in k3518 in a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3538(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_3538,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3546,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-ffi-syntax.scm:174: chicken.base#open-output-string */
t4=*((C_word*)lf[70]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3544 in k3536 in k3521 in k3518 in a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_3546,2,av);}
a=C_alloc(8);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_fix(2),C_SCHEME_TRUE,lf[61]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-ffi-syntax.scm:174: ##sys#print */
t6=*((C_word*)lf[64]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[69];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3550 in k3544 in k3536 in k3521 in k3518 in a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_3552,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-ffi-syntax.scm:174: ##sys#print */
t3=*((C_word*)lf[64]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3553 in k3550 in k3544 in k3536 in k3521 in k3518 in a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3555(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_3555,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-ffi-syntax.scm:174: ##sys#print */
t3=*((C_word*)lf[64]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[68];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3556 in k3553 in k3550 in k3544 in k3536 in k3521 in k3518 in a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_3558,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3571,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[7]);
/* chicken-ffi-syntax.scm:176: chicken.string#string-intersperse */
t5=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[67];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k3559 in k3556 in k3553 in k3550 in k3544 in k3536 in k3521 in k3518 in a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3561(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3561,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-ffi-syntax.scm:174: ##sys#print */
t3=*((C_word*)lf[64]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[65];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3562 in k3559 in k3556 in k3553 in k3550 in k3544 in k3536 in k3521 in k3518 in a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3564(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3564,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:174: chicken.base#get-output-string */
t3=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3544 in k3536 in k3521 in k3518 in a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 in ... */
static void C_ccall f_3567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,1)))){
C_save_and_reclaim((void *)f_3567,2,av);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,lf[51],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_list(&a,2,lf[62],((C_word*)t0)[3]);
t5=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[14],t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k3569 in k3556 in k3553 in k3550 in k3544 in k3536 in k3521 in k3518 in a3515 in k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3571(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3571,2,av);}
/* chicken-ffi-syntax.scm:174: ##sys#print */
t2=*((C_word*)lf[64]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3581 in k2760 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3583(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,5)))){
C_save_and_reclaim((void *)f_3583,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,lf[59],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3514,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3516,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:167: compiler-only-er-transformer */
f_2727(t5,t6);}

/* k3585 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3587(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3587,2,av);}
/* chicken-ffi-syntax.scm:128: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[74];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_3589,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3593,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:133: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[74];
av2[3]=t2;
av2[4]=lf[79];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,3)))){
C_save_and_reclaim((void *)f_3593,2,av);}
a=C_alloc(23);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3602,a[2]=((C_word*)t0)[3],a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t12=C_i_check_list_2(t3,lf[26]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3714,a[2]=t9,a[3]=t15,a[4]=t11,a[5]=t10,a[6]=((C_word)li28),tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_3714(t17,t13,t3);}

/* g720 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_3602(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_3602,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:136: chicken.base#gensym */
t3=*((C_word*)lf[20]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3608 in g720 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3610,2,av);}
/* chicken-ffi-syntax.scm:136: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,4)))){
C_save_and_reclaim((void *)f_3616,2,av);}
a=C_alloc(22);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3691,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=C_a_i_list(&a,1,t2);
if(C_truep(C_i_nullp(t6))){
t7=C_i_check_list_2(((C_word*)t0)[4],lf[77]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1659,a[2]=t5,a[3]=t9,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_1659(t11,t3,((C_word*)t0)[4]);}
else{
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1699,a[2]=t9,a[3]=t5,a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_1699(t11,t3,t7);}}

/* k3621 in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3623(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_3623,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3627,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3629,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word)li20),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3629(t7,t3,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3625 in k3621 in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_3627,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[75],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k3621 in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_3629(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_3629,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_cons(&a,2,lf[75],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=t4;
t6=C_i_car(t3);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3652,a[2]=t5,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=t2;
t10=C_u_i_cdr(t9);
t11=t3;
t12=C_u_i_cdr(t11);
/* chicken-ffi-syntax.scm:149: loop */
t14=t8;
t15=t10;
t16=t12;
t1=t14;
t2=t15;
t3=t16;
goto loop;}}

/* k3650 in loop in k3621 in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3652(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,1)))){
C_save_and_reclaim((void *)f_3652,2,av);}
a=C_alloc(15);
t2=C_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(3),t2);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[2]);
t5=C_i_cadr(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_list(&a,5,lf[76],t4,t5,((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t4=C_i_car(((C_word*)t0)[2]);
t5=C_i_cadr(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[76],t4,t5,t1);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* a3690 in k3614 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_3691,4,av);}
a=C_alloc(6);
t4=C_i_cddr(t2);
if(C_truep(C_i_pairp(t4))){
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=C_a_i_cons(&a,2,t3,t7);
t9=t1;{
C_word *av2=av;
av2[0]=t9;
av2[1]=C_a_i_list1(&a,1,t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* map-loop714 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_3714(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_3714,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3739,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-ffi-syntax.scm:136: g720 */
t4=((C_word*)t0)[4];
f_3602(t4,t3);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3737 in map-loop714 in k3591 in a3588 in k2757 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3739(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3739,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3714(t6,((C_word*)t0)[5],t5);}

/* k3752 in k3834 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3754(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3754,2,av);}
/* chicken-ffi-syntax.scm:111: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[81];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3755 in k3834 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_3756,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3760,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:116: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[81];
av2[3]=t2;
av2[4]=lf[84];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3758 in a3755 in k3834 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3760(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_3760,2,av);}
a=C_alloc(11);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3775,a[2]=t3,a[3]=t5,a[4]=t12,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3822,a[2]=((C_word*)t0)[4],a[3]=t13,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:120: chicken.base#gensym */
t15=*((C_word*)lf[20]+1);{
C_word *av2=av;
av2[0]=t15;
av2[1]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}

/* k3773 in k3758 in a3755 in k3834 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3775(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_3775,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-ffi-syntax.scm:121: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[80];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3780 in k3773 in k3758 in a3755 in k3834 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_3782,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken-ffi-syntax.scm:122: scheme#symbol->string */
t4=*((C_word*)lf[55]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3816 in k3780 in k3773 in k3758 in a3755 in k3834 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(48,c,1)))){
C_save_and_reclaim((void *)f_3818,2,av);}
a=C_alloc(48);
t2=C_a_i_list(&a,4,lf[10],((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_a_i_list(&a,5,lf[82],((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[4]);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t4=C_u_i_car(((C_word*)t0)[5]);
t5=C_a_i_list(&a,3,lf[83],((C_word*)t0)[2],t4);
t6=C_a_i_list(&a,1,t5);
t7=C_a_i_cons(&a,2,t3,t6);
t8=C_a_i_cons(&a,2,t2,t7);
t9=((C_word*)t0)[6];{
C_word *av2=av;
av2[0]=t9;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[7],t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t2,t4);
t6=((C_word*)t0)[6];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k3820 in k3758 in a3755 in k3834 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3822,2,av);}
/* chicken-ffi-syntax.scm:120: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3834 in k2754 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,5)))){
C_save_and_reclaim((void *)f_3836,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,lf[80],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3756,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:114: compiler-only-er-transformer */
f_2727(t5,t6);}

/* k3838 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3840,2,av);}
/* chicken-ffi-syntax.scm:103: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[85];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3841 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3842,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3846,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:108: ##sys#check-syntax */
t6=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[85];
av2[3]=t2;
av2[4]=lf[87];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3844 in a3841 in k2751 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_3846,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[86],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3859 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3861,2,av);}
/* chicken-ffi-syntax.scm:64: ##sys#extend-macro-environment */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[90];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3863,5,av);}
a=C_alloc(5);
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3870,a[2]=t6,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t6))){
t8=C_u_i_car(t6);
t9=t7;
f_3870(t9,C_i_stringp(t8));}
else{
t8=t7;
f_3870(t8,C_SCHEME_FALSE);}}

/* k3868 in a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_3870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_3870,2,t0,t1);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_not(t2))){
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t4=C_u_i_car(((C_word*)t0)[2]);
t5=t3;
f_3873(t5,C_i_symbolp(t4));}
else{
t4=t3;
f_3873(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3873(t4,C_SCHEME_FALSE);}}

/* k3871 in k3868 in a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_3873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_3873,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:75: ##sys#check-syntax */
t3=*((C_word*)lf[23]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[90];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[91];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
/* chicken-ffi-syntax.scm:85: ##sys#check-syntax */
t3=*((C_word*)lf[23]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[90];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[95];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
/* chicken-ffi-syntax.scm:86: ##sys#check-syntax */
t3=*((C_word*)lf[23]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[90];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[96];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}}

/* k3877 in k3871 in k3868 in a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3879(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3879,2,av);}
a=C_alloc(5);
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:77: r */
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[80];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3887 in k3877 in k3871 in k3868 in a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3889(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(42,c,1)))){
C_save_and_reclaim((void *)f_3889,2,av);}
a=C_alloc(42);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,lf[10],((C_word*)t0)[3],t2);
t4=C_u_i_cdr(((C_word*)t0)[2]);
t5=C_u_i_car(t4);
t6=C_a_i_list(&a,4,lf[82],((C_word*)t0)[3],t5,C_SCHEME_TRUE);
t7=C_u_i_cdr(((C_word*)t0)[2]);
t8=C_u_i_cdr(t7);
if(C_truep(C_i_pairp(t8))){
t9=C_i_caddr(((C_word*)t0)[2]);
t10=C_a_i_list(&a,3,lf[83],((C_word*)t0)[3],t9);
t11=C_a_i_list(&a,1,t10);
t12=C_a_i_cons(&a,2,t6,t11);
t13=C_a_i_cons(&a,2,t3,t12);
t14=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t14;
av2[1]=C_a_i_cons(&a,2,t1,t13);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t9=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t3,t9);
t11=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t11;
av2[1]=C_a_i_cons(&a,2,t1,t10);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}

/* k3934 in k3871 in k3868 in a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3936(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_3936,2,av);}
a=C_alloc(8);
t2=(C_truep(((C_word*)t0)[2])?C_i_cadr(((C_word*)t0)[3]):C_i_car(((C_word*)t0)[3]));
t3=t2;
t4=C_i_cdr(t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3949,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-ffi-syntax.scm:89: r */
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[88];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k3947 in k3934 in k3871 in k3868 in a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(37,c,3)))){
C_save_and_reclaim((void *)f_3949,2,av);}
a=C_alloc(37);
t2=t1;
t3=C_u_i_car(((C_word*)t0)[2]);
t4=C_u_i_car(((C_word*)t0)[2]);
t5=C_a_i_list(&a,2,lf[92],t4);
t6=t5;
t7=(C_truep(((C_word*)t0)[3])?C_i_car(((C_word*)t0)[4]):lf[93]);
t8=t7;
t9=(C_truep(((C_word*)t0)[3])?C_i_caddr(((C_word*)t0)[4]):C_i_cadr(((C_word*)t0)[4]));
t10=C_a_i_list(&a,2,lf[92],t9);
t11=t10;
t12=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t13=t12;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=((C_word*)t14)[1];
t16=C_i_check_list_2(((C_word*)t0)[5],lf[26]);
t17=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t8,a[6]=t11,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t3,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4056,a[2]=t14,a[3]=t19,a[4]=t15,a[5]=((C_word)li33),tmp=(C_word)a,a+=6,tmp));
t21=((C_word*)t19)[1];
f_4056(t21,t17,((C_word*)t0)[5]);}

/* k3977 in k4052 in k3947 in k3934 in k3871 in k3868 in a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3979(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,3)))){
C_save_and_reclaim((void *)f_3979,2,av);}
a=C_alloc(25);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4007,a[2]=t5,a[3]=t9,a[4]=t6,a[5]=((C_word)li32),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_4007(t11,t7,((C_word*)t0)[11]);}

/* k3993 in k3977 in k4052 in k3947 in k3934 in k3871 in k3868 in a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_3995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,c,1)))){
C_save_and_reclaim((void *)f_3995,2,av);}
a=C_alloc(33);
t2=(C_truep(((C_word*)t0)[2])?C_i_cdddr(((C_word*)t0)[3]):C_i_cddr(((C_word*)t0)[3]));
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,6,lf[94],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],t4);
t6=((C_word*)t0)[9];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,((C_word*)t0)[10],((C_word*)t0)[11],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* map-loop652 in k3977 in k4052 in k3947 in k3934 in k3871 in k3868 in a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_4007(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_4007,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4052 in k3947 in k3934 in k3871 in k3868 in a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_4054(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,2)))){
C_save_and_reclaim((void *)f_4054,2,av);}
a=C_alloc(18);
t2=C_a_i_list(&a,2,lf[92],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-ffi-syntax.scm:95: r */
t5=((C_word*)t0)[11];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[89];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* map-loop625 in k3947 in k3934 in k3871 in k3868 in a3862 in k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_fcall f_4056(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_4056,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4151 in k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_4153(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,5)))){
C_save_and_reclaim((void *)f_4153,2,av);}
a=C_alloc(19);
t2=C_a_i_cons(&a,2,lf[89],t1);
t3=C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3861,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3863,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:69: compiler-only-er-transformer */
f_2727(t5,t6);}

/* k4155 in k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_4157(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_4157,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,lf[80],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-ffi-syntax.scm:68: chicken.base#alist-ref */
t5=*((C_word*)lf[73]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[89];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k4159 in k2723 in k1441 in k1438 in k1435 in k1432 in k1429 */
static void C_ccall f_4161(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_4161,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,lf[88],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4157,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-ffi-syntax.scm:67: chicken.base#alist-ref */
t5=*((C_word*)lf[73]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[80];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_chicken_2dffi_2dsyntax_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("chicken-ffi-syntax"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void*)C_chicken_2dffi_2dsyntax_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(1118))){
C_save(t1);
C_rereclaim2(1118*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,98);
lf[0]=C_h_intern(&lf[0],18, C_text("chicken-ffi-syntax"));
lf[1]=C_h_intern(&lf[1],27, C_text("chicken.syntax#syntax-error"));
lf[2]=C_decode_literal(C_heaptop,C_text("\376B\000\000,The FFI is not supported in interpreted mode"));
lf[3]=C_h_intern(&lf[3],25, C_text("chicken.platform#feature\077"));
lf[4]=C_h_intern(&lf[4],9, C_text("compiling"));
lf[5]=C_h_intern(&lf[5],20, C_text("##sys#er-transformer"));
lf[6]=C_h_intern(&lf[6],35, C_text("##sys#chicken-ffi-macro-environment"));
lf[7]=C_h_intern(&lf[7],29, C_text("chicken.internal#macro-subset"));
lf[8]=C_h_intern(&lf[8],30, C_text("##sys#extend-macro-environment"));
lf[9]=C_h_intern(&lf[9],17, C_text("foreign-type-size"));
lf[10]=C_h_intern(&lf[10],30, C_text("##core#define-foreign-variable"));
lf[11]=C_h_intern(&lf[11],6, C_text("size_t"));
lf[12]=C_h_intern(&lf[12],10, C_text("##core#the"));
lf[13]=C_h_intern(&lf[13],6, C_text("fixnum"));
lf[14]=C_h_intern(&lf[14],12, C_text("##core#begin"));
lf[15]=C_h_intern(&lf[15],20, C_text("scheme#string-append"));
lf[16]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007sizeof("));
lf[17]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001)"));
lf[18]=C_h_intern(&lf[18],51, C_text("chicken.compiler.c-backend#foreign-type-declaration"));
lf[19]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[20]=C_h_intern(&lf[20],19, C_text("chicken.base#gensym"));
lf[21]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005code_"));
lf[22]=C_h_intern(&lf[22],27, C_text("chicken.syntax#strip-syntax"));
lf[23]=C_h_intern(&lf[23],18, C_text("##sys#check-syntax"));
lf[24]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\377\016"));
lf[25]=C_h_intern(&lf[25],20, C_text("foreign-safe-lambda\052"));
lf[26]=C_h_intern(&lf[26],3, C_text("map"));
lf[27]=C_h_intern(&lf[27],9, C_text("procedure"));
lf[28]=C_h_intern(&lf[28],27, C_text("##core#foreign-safe-lambda\052"));
lf[29]=C_h_intern(&lf[29],52, C_text("chicken.compiler.support#foreign-type->scrutiny-type"));
lf[30]=C_h_intern(&lf[30],6, C_text("result"));
lf[31]=C_h_intern(&lf[31],3, C_text("arg"));
lf[32]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\001\000\000\001\001_"));
lf[33]=C_h_intern(&lf[33],19, C_text("foreign-safe-lambda"));
lf[34]=C_h_intern(&lf[34],26, C_text("##core#foreign-safe-lambda"));
lf[35]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\001\000\000\001\001_"));
lf[36]=C_h_intern(&lf[36],15, C_text("foreign-lambda\052"));
lf[37]=C_h_intern(&lf[37],22, C_text("##core#foreign-lambda\052"));
lf[38]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\001\000\000\001\001_"));
lf[39]=C_h_intern(&lf[39],14, C_text("foreign-lambda"));
lf[40]=C_h_intern(&lf[40],21, C_text("##core#foreign-lambda"));
lf[41]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\001\000\000\001\001_"));
lf[42]=C_h_intern(&lf[42],17, C_text("foreign-primitive"));
lf[43]=C_h_intern(&lf[43],24, C_text("##core#foreign-primitive"));
lf[44]=C_h_intern(&lf[44],1, C_text("\052"));
lf[45]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\001\000\000\001\001_"));
lf[46]=C_h_intern(&lf[46],23, C_text("define-foreign-variable"));
lf[47]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\006\001symbol\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\003\376\001\000\000\006\001string\376\377\001\000\000\000\000\376\377\001\000\000\000\001"));
lf[48]=C_h_intern(&lf[48],19, C_text("define-foreign-type"));
lf[49]=C_h_intern(&lf[49],26, C_text("##core#define-foreign-type"));
lf[50]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\006\001symbol\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\003\376\001\000\000\001\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\002"));
lf[51]=C_h_intern(&lf[51],15, C_text("foreign-declare"));
lf[52]=C_h_intern(&lf[52],14, C_text("##core#declare"));
lf[53]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\002\376\001\000\000\006\001string\376\377\001\000\000\000\000"));
lf[54]=C_h_intern(&lf[54],13, C_text("foreign-value"));
lf[55]=C_h_intern(&lf[55],21, C_text("scheme#symbol->string"));
lf[56]=C_decode_literal(C_heaptop,C_text("\376B\000\000\052bad argument type - not a string or symbol"));
lf[57]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005code_"));
lf[58]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\377\016"));
lf[59]=C_h_intern(&lf[59],7, C_text("declare"));
lf[60]=C_h_intern(&lf[60],12, C_text("foreign-code"));
lf[61]=C_h_intern(&lf[61],6, C_text("format"));
lf[62]=C_h_intern(&lf[62],13, C_text("##core#inline"));
lf[63]=C_h_intern(&lf[63],30, C_text("chicken.base#get-output-string"));
lf[64]=C_h_intern(&lf[64],11, C_text("##sys#print"));
lf[65]=C_decode_literal(C_heaptop,C_text("\376B\000\000 \012; return C_SCHEME_UNDEFINED; }\012"));
lf[66]=C_h_intern(&lf[66],33, C_text("chicken.string#string-intersperse"));
lf[67]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\012"));
lf[68]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005() { "));
lf[69]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016static C_word "));
lf[70]=C_h_intern(&lf[70],31, C_text("chicken.base#open-output-string"));
lf[71]=C_h_intern(&lf[71],5, C_text("code_"));
lf[72]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\002\376\001\000\000\006\001string\376\377\001\000\000\000\000"));
lf[73]=C_h_intern(&lf[73],22, C_text("chicken.base#alist-ref"));
lf[74]=C_h_intern(&lf[74],12, C_text("let-location"));
lf[75]=C_h_intern(&lf[75],10, C_text("##core#let"));
lf[76]=C_h_intern(&lf[76],19, C_text("##core#let-location"));
lf[77]=C_h_intern(&lf[77],5, C_text("foldr"));
lf[78]=C_h_intern(&lf[78],13, C_text("scheme#append"));
lf[79]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010\001variable\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\003\376\001\000\000\001\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\000\376\001\000\000\001\001_"));
lf[80]=C_h_intern(&lf[80],5, C_text("begin"));
lf[81]=C_h_intern(&lf[81],15, C_text("define-location"));
lf[82]=C_h_intern(&lf[82],31, C_text("##core#define-external-variable"));
lf[83]=C_h_intern(&lf[83],11, C_text("##core#set!"));
lf[84]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\010\001variable\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\003\376\001\000\000\001\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001"));
lf[85]=C_h_intern(&lf[85],8, C_text("location"));
lf[86]=C_h_intern(&lf[86],15, C_text("##core#location"));
lf[87]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\010\001location\376\003\000\000\002\376\001\000\000\001\001_\376\377\016"));
lf[88]=C_h_intern(&lf[88],6, C_text("define"));
lf[89]=C_h_intern(&lf[89],6, C_text("lambda"));
lf[90]=C_h_intern(&lf[90],15, C_text("define-external"));
lf[91]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001symbol\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\003\376\001\000\000\001\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001"));
lf[92]=C_h_intern(&lf[92],12, C_text("##core#quote"));
lf[93]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[94]=C_h_intern(&lf[94],31, C_text("##core#foreign-callback-wrapper"));
lf[95]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\006\001symbol\376\377\016\376\377\001\000"
"\000\000\000\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\002\376\001\000\000\001\001_\376\377\001\000\000\000\001"));
lf[96]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\006\001symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001\001_\376\000"
"\000\000\002\376\001\000\000\001\001_\376\377\001\000\000\000\001"));
lf[97]=C_h_intern(&lf[97],23, C_text("##sys#macro-environment"));
C_register_lf2(lf,98,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1431,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_data_2dstructures_toplevel(2,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[166] = {
{C_text("f_1431:chicken_2dffi_2dsyntax_2escm"),(void*)f_1431},
{C_text("f_1434:chicken_2dffi_2dsyntax_2escm"),(void*)f_1434},
{C_text("f_1437:chicken_2dffi_2dsyntax_2escm"),(void*)f_1437},
{C_text("f_1440:chicken_2dffi_2dsyntax_2escm"),(void*)f_1440},
{C_text("f_1443:chicken_2dffi_2dsyntax_2escm"),(void*)f_1443},
{C_text("f_1659:chicken_2dffi_2dsyntax_2escm"),(void*)f_1659},
{C_text("f_1667:chicken_2dffi_2dsyntax_2escm"),(void*)f_1667},
{C_text("f_1675:chicken_2dffi_2dsyntax_2escm"),(void*)f_1675},
{C_text("f_1686:chicken_2dffi_2dsyntax_2escm"),(void*)f_1686},
{C_text("f_1699:chicken_2dffi_2dsyntax_2escm"),(void*)f_1699},
{C_text("f_1713:chicken_2dffi_2dsyntax_2escm"),(void*)f_1713},
{C_text("f_1717:chicken_2dffi_2dsyntax_2escm"),(void*)f_1717},
{C_text("f_1729:chicken_2dffi_2dsyntax_2escm"),(void*)f_1729},
{C_text("f_1731:chicken_2dffi_2dsyntax_2escm"),(void*)f_1731},
{C_text("f_1778:chicken_2dffi_2dsyntax_2escm"),(void*)f_1778},
{C_text("f_1780:chicken_2dffi_2dsyntax_2escm"),(void*)f_1780},
{C_text("f_1854:chicken_2dffi_2dsyntax_2escm"),(void*)f_1854},
{C_text("f_2725:chicken_2dffi_2dsyntax_2escm"),(void*)f_2725},
{C_text("f_2727:chicken_2dffi_2dsyntax_2escm"),(void*)f_2727},
{C_text("f_2733:chicken_2dffi_2dsyntax_2escm"),(void*)f_2733},
{C_text("f_2740:chicken_2dffi_2dsyntax_2escm"),(void*)f_2740},
{C_text("f_2753:chicken_2dffi_2dsyntax_2escm"),(void*)f_2753},
{C_text("f_2756:chicken_2dffi_2dsyntax_2escm"),(void*)f_2756},
{C_text("f_2759:chicken_2dffi_2dsyntax_2escm"),(void*)f_2759},
{C_text("f_2762:chicken_2dffi_2dsyntax_2escm"),(void*)f_2762},
{C_text("f_2765:chicken_2dffi_2dsyntax_2escm"),(void*)f_2765},
{C_text("f_2768:chicken_2dffi_2dsyntax_2escm"),(void*)f_2768},
{C_text("f_2771:chicken_2dffi_2dsyntax_2escm"),(void*)f_2771},
{C_text("f_2774:chicken_2dffi_2dsyntax_2escm"),(void*)f_2774},
{C_text("f_2777:chicken_2dffi_2dsyntax_2escm"),(void*)f_2777},
{C_text("f_2780:chicken_2dffi_2dsyntax_2escm"),(void*)f_2780},
{C_text("f_2783:chicken_2dffi_2dsyntax_2escm"),(void*)f_2783},
{C_text("f_2786:chicken_2dffi_2dsyntax_2escm"),(void*)f_2786},
{C_text("f_2789:chicken_2dffi_2dsyntax_2escm"),(void*)f_2789},
{C_text("f_2792:chicken_2dffi_2dsyntax_2escm"),(void*)f_2792},
{C_text("f_2795:chicken_2dffi_2dsyntax_2escm"),(void*)f_2795},
{C_text("f_2798:chicken_2dffi_2dsyntax_2escm"),(void*)f_2798},
{C_text("f_2802:chicken_2dffi_2dsyntax_2escm"),(void*)f_2802},
{C_text("f_2804:chicken_2dffi_2dsyntax_2escm"),(void*)f_2804},
{C_text("f_2808:chicken_2dffi_2dsyntax_2escm"),(void*)f_2808},
{C_text("f_2811:chicken_2dffi_2dsyntax_2escm"),(void*)f_2811},
{C_text("f_2814:chicken_2dffi_2dsyntax_2escm"),(void*)f_2814},
{C_text("f_2817:chicken_2dffi_2dsyntax_2escm"),(void*)f_2817},
{C_text("f_2832:chicken_2dffi_2dsyntax_2escm"),(void*)f_2832},
{C_text("f_2846:chicken_2dffi_2dsyntax_2escm"),(void*)f_2846},
{C_text("f_2848:chicken_2dffi_2dsyntax_2escm"),(void*)f_2848},
{C_text("f_2852:chicken_2dffi_2dsyntax_2escm"),(void*)f_2852},
{C_text("f_2881:chicken_2dffi_2dsyntax_2escm"),(void*)f_2881},
{C_text("f_2887:chicken_2dffi_2dsyntax_2escm"),(void*)f_2887},
{C_text("f_2891:chicken_2dffi_2dsyntax_2escm"),(void*)f_2891},
{C_text("f_2895:chicken_2dffi_2dsyntax_2escm"),(void*)f_2895},
{C_text("f_2901:chicken_2dffi_2dsyntax_2escm"),(void*)f_2901},
{C_text("f_2926:chicken_2dffi_2dsyntax_2escm"),(void*)f_2926},
{C_text("f_2941:chicken_2dffi_2dsyntax_2escm"),(void*)f_2941},
{C_text("f_2943:chicken_2dffi_2dsyntax_2escm"),(void*)f_2943},
{C_text("f_2947:chicken_2dffi_2dsyntax_2escm"),(void*)f_2947},
{C_text("f_2972:chicken_2dffi_2dsyntax_2escm"),(void*)f_2972},
{C_text("f_2978:chicken_2dffi_2dsyntax_2escm"),(void*)f_2978},
{C_text("f_2982:chicken_2dffi_2dsyntax_2escm"),(void*)f_2982},
{C_text("f_2986:chicken_2dffi_2dsyntax_2escm"),(void*)f_2986},
{C_text("f_2992:chicken_2dffi_2dsyntax_2escm"),(void*)f_2992},
{C_text("f_3017:chicken_2dffi_2dsyntax_2escm"),(void*)f_3017},
{C_text("f_3032:chicken_2dffi_2dsyntax_2escm"),(void*)f_3032},
{C_text("f_3034:chicken_2dffi_2dsyntax_2escm"),(void*)f_3034},
{C_text("f_3038:chicken_2dffi_2dsyntax_2escm"),(void*)f_3038},
{C_text("f_3067:chicken_2dffi_2dsyntax_2escm"),(void*)f_3067},
{C_text("f_3073:chicken_2dffi_2dsyntax_2escm"),(void*)f_3073},
{C_text("f_3077:chicken_2dffi_2dsyntax_2escm"),(void*)f_3077},
{C_text("f_3081:chicken_2dffi_2dsyntax_2escm"),(void*)f_3081},
{C_text("f_3087:chicken_2dffi_2dsyntax_2escm"),(void*)f_3087},
{C_text("f_3112:chicken_2dffi_2dsyntax_2escm"),(void*)f_3112},
{C_text("f_3127:chicken_2dffi_2dsyntax_2escm"),(void*)f_3127},
{C_text("f_3129:chicken_2dffi_2dsyntax_2escm"),(void*)f_3129},
{C_text("f_3133:chicken_2dffi_2dsyntax_2escm"),(void*)f_3133},
{C_text("f_3158:chicken_2dffi_2dsyntax_2escm"),(void*)f_3158},
{C_text("f_3164:chicken_2dffi_2dsyntax_2escm"),(void*)f_3164},
{C_text("f_3168:chicken_2dffi_2dsyntax_2escm"),(void*)f_3168},
{C_text("f_3172:chicken_2dffi_2dsyntax_2escm"),(void*)f_3172},
{C_text("f_3178:chicken_2dffi_2dsyntax_2escm"),(void*)f_3178},
{C_text("f_3203:chicken_2dffi_2dsyntax_2escm"),(void*)f_3203},
{C_text("f_3218:chicken_2dffi_2dsyntax_2escm"),(void*)f_3218},
{C_text("f_3220:chicken_2dffi_2dsyntax_2escm"),(void*)f_3220},
{C_text("f_3224:chicken_2dffi_2dsyntax_2escm"),(void*)f_3224},
{C_text("f_3227:chicken_2dffi_2dsyntax_2escm"),(void*)f_3227},
{C_text("f_3230:chicken_2dffi_2dsyntax_2escm"),(void*)f_3230},
{C_text("f_3233:chicken_2dffi_2dsyntax_2escm"),(void*)f_3233},
{C_text("f_3242:chicken_2dffi_2dsyntax_2escm"),(void*)f_3242},
{C_text("f_3259:chicken_2dffi_2dsyntax_2escm"),(void*)f_3259},
{C_text("f_3274:chicken_2dffi_2dsyntax_2escm"),(void*)f_3274},
{C_text("f_3288:chicken_2dffi_2dsyntax_2escm"),(void*)f_3288},
{C_text("f_3290:chicken_2dffi_2dsyntax_2escm"),(void*)f_3290},
{C_text("f_3315:chicken_2dffi_2dsyntax_2escm"),(void*)f_3315},
{C_text("f_3324:chicken_2dffi_2dsyntax_2escm"),(void*)f_3324},
{C_text("f_3393:chicken_2dffi_2dsyntax_2escm"),(void*)f_3393},
{C_text("f_3395:chicken_2dffi_2dsyntax_2escm"),(void*)f_3395},
{C_text("f_3399:chicken_2dffi_2dsyntax_2escm"),(void*)f_3399},
{C_text("f_3410:chicken_2dffi_2dsyntax_2escm"),(void*)f_3410},
{C_text("f_3412:chicken_2dffi_2dsyntax_2escm"),(void*)f_3412},
{C_text("f_3416:chicken_2dffi_2dsyntax_2escm"),(void*)f_3416},
{C_text("f_3427:chicken_2dffi_2dsyntax_2escm"),(void*)f_3427},
{C_text("f_3429:chicken_2dffi_2dsyntax_2escm"),(void*)f_3429},
{C_text("f_3433:chicken_2dffi_2dsyntax_2escm"),(void*)f_3433},
{C_text("f_3448:chicken_2dffi_2dsyntax_2escm"),(void*)f_3448},
{C_text("f_3450:chicken_2dffi_2dsyntax_2escm"),(void*)f_3450},
{C_text("f_3454:chicken_2dffi_2dsyntax_2escm"),(void*)f_3454},
{C_text("f_3457:chicken_2dffi_2dsyntax_2escm"),(void*)f_3457},
{C_text("f_3467:chicken_2dffi_2dsyntax_2escm"),(void*)f_3467},
{C_text("f_3475:chicken_2dffi_2dsyntax_2escm"),(void*)f_3475},
{C_text("f_3479:chicken_2dffi_2dsyntax_2escm"),(void*)f_3479},
{C_text("f_3491:chicken_2dffi_2dsyntax_2escm"),(void*)f_3491},
{C_text("f_3514:chicken_2dffi_2dsyntax_2escm"),(void*)f_3514},
{C_text("f_3516:chicken_2dffi_2dsyntax_2escm"),(void*)f_3516},
{C_text("f_3520:chicken_2dffi_2dsyntax_2escm"),(void*)f_3520},
{C_text("f_3523:chicken_2dffi_2dsyntax_2escm"),(void*)f_3523},
{C_text("f_3538:chicken_2dffi_2dsyntax_2escm"),(void*)f_3538},
{C_text("f_3546:chicken_2dffi_2dsyntax_2escm"),(void*)f_3546},
{C_text("f_3552:chicken_2dffi_2dsyntax_2escm"),(void*)f_3552},
{C_text("f_3555:chicken_2dffi_2dsyntax_2escm"),(void*)f_3555},
{C_text("f_3558:chicken_2dffi_2dsyntax_2escm"),(void*)f_3558},
{C_text("f_3561:chicken_2dffi_2dsyntax_2escm"),(void*)f_3561},
{C_text("f_3564:chicken_2dffi_2dsyntax_2escm"),(void*)f_3564},
{C_text("f_3567:chicken_2dffi_2dsyntax_2escm"),(void*)f_3567},
{C_text("f_3571:chicken_2dffi_2dsyntax_2escm"),(void*)f_3571},
{C_text("f_3583:chicken_2dffi_2dsyntax_2escm"),(void*)f_3583},
{C_text("f_3587:chicken_2dffi_2dsyntax_2escm"),(void*)f_3587},
{C_text("f_3589:chicken_2dffi_2dsyntax_2escm"),(void*)f_3589},
{C_text("f_3593:chicken_2dffi_2dsyntax_2escm"),(void*)f_3593},
{C_text("f_3602:chicken_2dffi_2dsyntax_2escm"),(void*)f_3602},
{C_text("f_3610:chicken_2dffi_2dsyntax_2escm"),(void*)f_3610},
{C_text("f_3616:chicken_2dffi_2dsyntax_2escm"),(void*)f_3616},
{C_text("f_3623:chicken_2dffi_2dsyntax_2escm"),(void*)f_3623},
{C_text("f_3627:chicken_2dffi_2dsyntax_2escm"),(void*)f_3627},
{C_text("f_3629:chicken_2dffi_2dsyntax_2escm"),(void*)f_3629},
{C_text("f_3652:chicken_2dffi_2dsyntax_2escm"),(void*)f_3652},
{C_text("f_3691:chicken_2dffi_2dsyntax_2escm"),(void*)f_3691},
{C_text("f_3714:chicken_2dffi_2dsyntax_2escm"),(void*)f_3714},
{C_text("f_3739:chicken_2dffi_2dsyntax_2escm"),(void*)f_3739},
{C_text("f_3754:chicken_2dffi_2dsyntax_2escm"),(void*)f_3754},
{C_text("f_3756:chicken_2dffi_2dsyntax_2escm"),(void*)f_3756},
{C_text("f_3760:chicken_2dffi_2dsyntax_2escm"),(void*)f_3760},
{C_text("f_3775:chicken_2dffi_2dsyntax_2escm"),(void*)f_3775},
{C_text("f_3782:chicken_2dffi_2dsyntax_2escm"),(void*)f_3782},
{C_text("f_3818:chicken_2dffi_2dsyntax_2escm"),(void*)f_3818},
{C_text("f_3822:chicken_2dffi_2dsyntax_2escm"),(void*)f_3822},
{C_text("f_3836:chicken_2dffi_2dsyntax_2escm"),(void*)f_3836},
{C_text("f_3840:chicken_2dffi_2dsyntax_2escm"),(void*)f_3840},
{C_text("f_3842:chicken_2dffi_2dsyntax_2escm"),(void*)f_3842},
{C_text("f_3846:chicken_2dffi_2dsyntax_2escm"),(void*)f_3846},
{C_text("f_3861:chicken_2dffi_2dsyntax_2escm"),(void*)f_3861},
{C_text("f_3863:chicken_2dffi_2dsyntax_2escm"),(void*)f_3863},
{C_text("f_3870:chicken_2dffi_2dsyntax_2escm"),(void*)f_3870},
{C_text("f_3873:chicken_2dffi_2dsyntax_2escm"),(void*)f_3873},
{C_text("f_3879:chicken_2dffi_2dsyntax_2escm"),(void*)f_3879},
{C_text("f_3889:chicken_2dffi_2dsyntax_2escm"),(void*)f_3889},
{C_text("f_3936:chicken_2dffi_2dsyntax_2escm"),(void*)f_3936},
{C_text("f_3949:chicken_2dffi_2dsyntax_2escm"),(void*)f_3949},
{C_text("f_3979:chicken_2dffi_2dsyntax_2escm"),(void*)f_3979},
{C_text("f_3995:chicken_2dffi_2dsyntax_2escm"),(void*)f_3995},
{C_text("f_4007:chicken_2dffi_2dsyntax_2escm"),(void*)f_4007},
{C_text("f_4054:chicken_2dffi_2dsyntax_2escm"),(void*)f_4054},
{C_text("f_4056:chicken_2dffi_2dsyntax_2escm"),(void*)f_4056},
{C_text("f_4153:chicken_2dffi_2dsyntax_2escm"),(void*)f_4153},
{C_text("f_4157:chicken_2dffi_2dsyntax_2escm"),(void*)f_4157},
{C_text("f_4161:chicken_2dffi_2dsyntax_2escm"),(void*)f_4161},
{C_text("toplevel:chicken_2dffi_2dsyntax_2escm"),(void*)C_chicken_2dffi_2dsyntax_toplevel},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  chicken.format#sprintf		1
S|  chicken.base#foldl		3
S|  scheme#map		12
S|  chicken.base#foldr		3
o|eliminated procedure checks: 143 
o|specializations:
o|  1 (##sys#check-output-port * * *)
o|  1 (scheme#= fixnum fixnum)
o|  1 (scheme#cdddr (pair * (pair * pair)))
o|  3 (scheme#cddr (pair * pair))
o|  3 (scheme#cadr (pair * pair))
o|  1 (scheme#eqv? * *)
o|  4 (##sys#check-list (or pair list) *)
o|  29 (scheme#cdr pair)
o|  12 (scheme#car pair)
(o e)|safe calls: 420 
o|safe globals: (posv posq make-list iota find-tail find length+ lset=/eq? lset<=/eq? list-tabulate lset-intersection/eq? lset-union/eq? lset-difference/eq? lset-adjoin/eq? list-index last unzip1 remove filter-map filter alist-cons delete-duplicates fifth fourth third second first delete concatenate cons* any every append-map split-at drop take span partition) 
o|removed side-effect free assignment to unused variable: partition 
o|removed side-effect free assignment to unused variable: span 
o|removed side-effect free assignment to unused variable: drop 
o|removed side-effect free assignment to unused variable: split-at 
o|inlining procedure: k1825 
o|inlining procedure: k1825 
o|inlining procedure: k1856 
o|inlining procedure: k1856 
o|removed side-effect free assignment to unused variable: cons* 
o|removed side-effect free assignment to unused variable: concatenate 
o|removed side-effect free assignment to unused variable: first 
o|removed side-effect free assignment to unused variable: second 
o|removed side-effect free assignment to unused variable: third 
o|removed side-effect free assignment to unused variable: fourth 
o|removed side-effect free assignment to unused variable: fifth 
o|removed side-effect free assignment to unused variable: delete-duplicates 
o|removed side-effect free assignment to unused variable: alist-cons 
o|inlining procedure: k2073 
o|inlining procedure: k2073 
o|inlining procedure: k2065 
o|inlining procedure: k2065 
o|removed side-effect free assignment to unused variable: filter-map 
o|removed side-effect free assignment to unused variable: remove 
o|removed side-effect free assignment to unused variable: unzip1 
o|removed side-effect free assignment to unused variable: last 
o|removed side-effect free assignment to unused variable: list-index 
o|removed side-effect free assignment to unused variable: lset-adjoin/eq? 
o|removed side-effect free assignment to unused variable: lset-difference/eq? 
o|removed side-effect free assignment to unused variable: lset-union/eq? 
o|removed side-effect free assignment to unused variable: lset-intersection/eq? 
o|inlining procedure: k2464 
o|inlining procedure: k2464 
o|removed side-effect free assignment to unused variable: lset<=/eq? 
o|removed side-effect free assignment to unused variable: lset=/eq? 
o|removed side-effect free assignment to unused variable: length+ 
o|removed side-effect free assignment to unused variable: find 
o|removed side-effect free assignment to unused variable: find-tail 
o|removed side-effect free assignment to unused variable: iota 
o|removed side-effect free assignment to unused variable: make-list 
o|removed side-effect free assignment to unused variable: posq 
o|removed side-effect free assignment to unused variable: posv 
o|inlining procedure: k2735 
o|inlining procedure: k2735 
o|inlining procedure: k2903 
o|contracted procedure: "(chicken-ffi-syntax.scm:303) g10231032" 
o|inlining procedure: k2903 
o|inlining procedure: k2994 
o|contracted procedure: "(chicken-ffi-syntax.scm:289) g982991" 
o|propagated global variable: g9991000 chicken.compiler.support#foreign-type->scrutiny-type 
o|inlining procedure: k2994 
o|inlining procedure: k3089 
o|contracted procedure: "(chicken-ffi-syntax.scm:272) g948957" 
o|inlining procedure: k3089 
o|inlining procedure: k3180 
o|contracted procedure: "(chicken-ffi-syntax.scm:258) g907916" 
o|propagated global variable: g924925 chicken.compiler.support#foreign-type->scrutiny-type 
o|inlining procedure: k3180 
o|inlining procedure: k3276 
o|inlining procedure: k3276 
o|inlining procedure: k3292 
o|contracted procedure: "(chicken-ffi-syntax.scm:243) g866875" 
o|propagated global variable: g883884 chicken.compiler.support#foreign-type->scrutiny-type 
o|inlining procedure: k3292 
o|inlining procedure: k3326 
o|inlining procedure: k3326 
o|inlining procedure: k3358 
o|inlining procedure: k3358 
o|inlining procedure: k3489 
o|inlining procedure: k3489 
o|substituted constant variable: a3548 
o|substituted constant variable: a3549 
o|removed unused formal parameters: (_731) 
o|inlining procedure: k3631 
o|inlining procedure: k3631 
o|substituted constant variable: a3681 
o|inlining procedure: k3693 
o|inlining procedure: k3693 
o|contracted procedure: "(chicken-ffi-syntax.scm:138) append-map" 
o|inlining procedure: k1646 
o|inlining procedure: k1661 
o|inlining procedure: k1661 
o|inlining procedure: k1646 
o|inlining procedure: k1701 
o|inlining procedure: k1701 
o|inlining procedure: k1733 
o|contracted procedure: "(mini-srfi-1.scm:77) g201210" 
o|inlining procedure: k1733 
o|inlining procedure: k1782 
o|contracted procedure: "(mini-srfi-1.scm:76) g174183" 
o|inlining procedure: k1782 
o|inlining procedure: k3716 
o|removed unused parameter to known procedure: _731 "(chicken-ffi-syntax.scm:136) g720729" 
o|inlining procedure: k3716 
o|inlining procedure: k3800 
o|inlining procedure: k3800 
o|inlining procedure: k3874 
o|inlining procedure: k3907 
o|inlining procedure: k3907 
o|inlining procedure: k3874 
o|inlining procedure: k3997 
o|inlining procedure: k3997 
o|inlining procedure: k4009 
o|contracted procedure: "(chicken-ffi-syntax.scm:96) g658667" 
o|inlining procedure: k4009 
o|inlining procedure: k4058 
o|contracted procedure: "(chicken-ffi-syntax.scm:94) g631640" 
o|inlining procedure: k4058 
o|inlining procedure: k4090 
o|inlining procedure: k4090 
o|inlining procedure: k4119 
o|inlining procedure: k4119 
o|replaced variables: 257 
o|removed binding forms: 145 
o|removed side-effect free assignment to unused variable: every 
o|removed side-effect free assignment to unused variable: filter 
o|removed side-effect free assignment to unused variable: list-tabulate 
o|substituted constant variable: r32774182 
o|substituted constant variable: r32774182 
o|substituted constant variable: r36944201 
o|substituted constant variable: r16624204 
o|substituted constant variable: r17024206 
o|contracted procedure: "(mini-srfi-1.scm:74) any" 
o|substituted constant variable: r18574164 
o|substituted constant variable: r38014216 
o|substituted constant variable: r38014216 
o|substituted constant variable: r39084221 
o|substituted constant variable: r39084221 
o|substituted constant variable: r41204237 
o|converted assignments to bindings: (compiler-only-er-transformer590) 
o|simplifications: ((let . 1)) 
o|replaced variables: 3 
o|removed binding forms: 295 
o|removed call to pure procedure with unused result: "(chicken-ffi-syntax.scm:136) ##sys#slot" 
o|replaced variables: 17 
o|removed binding forms: 18 
o|contracted procedure: k3741 
o|removed binding forms: 19 
o|removed binding forms: 1 
o|simplifications: ((if . 5) (##core#call . 237)) 
o|  call simplifications:
o|    scheme#apply
o|    scheme#null?	5
o|    scheme#length
o|    scheme#eq?
o|    scheme#symbol?	2
o|    scheme#cdr	7
o|    scheme#cddr	3
o|    scheme#not	3
o|    scheme#list	2
o|    scheme#cdddr	3
o|    scheme#caddr	9
o|    ##sys#check-list	10
o|    scheme#pair?	18
o|    scheme#cons	24
o|    ##sys#setslot	11
o|    ##sys#slot	34
o|    ##sys#cons	28
o|    scheme#cadr	15
o|    scheme#string?	4
o|    ##sys#list	41
o|    scheme#car	15
o|contracted procedure: k2748 
o|contracted procedure: k2822 
o|contracted procedure: k2826 
o|contracted procedure: k2833 
o|contracted procedure: k2840 
o|contracted procedure: k2867 
o|contracted procedure: k2882 
o|contracted procedure: k2857 
o|contracted procedure: k2861 
o|contracted procedure: k2897 
o|contracted procedure: k2906 
o|contracted procedure: k2909 
o|contracted procedure: k2912 
o|contracted procedure: k2920 
o|contracted procedure: k2928 
o|contracted procedure: k2876 
o|contracted procedure: k2935 
o|contracted procedure: k2962 
o|contracted procedure: k2973 
o|contracted procedure: k2952 
o|contracted procedure: k2956 
o|contracted procedure: k2988 
o|contracted procedure: k2997 
o|contracted procedure: k3000 
o|contracted procedure: k3003 
o|contracted procedure: k3011 
o|contracted procedure: k3019 
o|contracted procedure: k3026 
o|contracted procedure: k3053 
o|contracted procedure: k3068 
o|contracted procedure: k3043 
o|contracted procedure: k3047 
o|contracted procedure: k3083 
o|contracted procedure: k3092 
o|contracted procedure: k3095 
o|contracted procedure: k3098 
o|contracted procedure: k3106 
o|contracted procedure: k3114 
o|contracted procedure: k3062 
o|contracted procedure: k3121 
o|contracted procedure: k3148 
o|contracted procedure: k3159 
o|contracted procedure: k3138 
o|contracted procedure: k3142 
o|contracted procedure: k3174 
o|contracted procedure: k3183 
o|contracted procedure: k3186 
o|contracted procedure: k3189 
o|contracted procedure: k3197 
o|contracted procedure: k3205 
o|contracted procedure: k3212 
o|contracted procedure: k3234 
o|contracted procedure: k3237 
o|contracted procedure: k3247 
o|contracted procedure: k3251 
o|contracted procedure: k3261 
o|contracted procedure: k3269 
o|contracted procedure: k3279 
o|contracted procedure: k3276 
o|contracted procedure: k3295 
o|contracted procedure: k3298 
o|contracted procedure: k3301 
o|contracted procedure: k3309 
o|contracted procedure: k3317 
o|contracted procedure: k3329 
o|contracted procedure: k3351 
o|contracted procedure: k3347 
o|contracted procedure: k3332 
o|contracted procedure: k3335 
o|contracted procedure: k3343 
o|contracted procedure: k3358 
o|contracted procedure: k3387 
o|contracted procedure: k3372 
o|contracted procedure: k3383 
o|contracted procedure: k3379 
o|contracted procedure: k3404 
o|contracted procedure: k3421 
o|contracted procedure: k3442 
o|contracted procedure: k3438 
o|contracted procedure: k3458 
o|contracted procedure: k3469 
o|contracted procedure: k3481 
o|contracted procedure: k3485 
o|contracted procedure: k3492 
o|contracted procedure: k3498 
o|contracted procedure: k3577 
o|contracted procedure: k3508 
o|contracted procedure: k3540 
o|contracted procedure: k3528 
o|contracted procedure: k3532 
o|contracted procedure: k3573 
o|contracted procedure: k3594 
o|contracted procedure: k3599 
o|contracted procedure: k3611 
o|contracted procedure: k3634 
o|contracted procedure: k3641 
o|contracted procedure: k3644 
o|contracted procedure: k3647 
o|contracted procedure: k3683 
o|contracted procedure: k3656 
o|contracted procedure: k3663 
o|contracted procedure: k3667 
o|contracted procedure: k3674 
o|contracted procedure: k3678 
o|contracted procedure: k3710 
o|contracted procedure: k3696 
o|contracted procedure: k3703 
o|contracted procedure: k1649 
o|contracted procedure: k1652 
o|contracted procedure: k1664 
o|contracted procedure: k1680 
o|contracted procedure: k1688 
o|contracted procedure: k1695 
o|contracted procedure: k1719 
o|contracted procedure: k1736 
o|contracted procedure: k1758 
o|contracted procedure: k1754 
o|contracted procedure: k1739 
o|contracted procedure: k1742 
o|contracted procedure: k1750 
o|contracted procedure: k1765 
o|contracted procedure: k1773 
o|contracted procedure: k1785 
o|contracted procedure: k1807 
o|contracted procedure: k1803 
o|contracted procedure: k1788 
o|contracted procedure: k1791 
o|contracted procedure: k1799 
o|contracted procedure: k1859 
o|contracted procedure: k1874 
o|contracted procedure: k1862 
o|contracted procedure: k3719 
o|contracted procedure: k3722 
o|contracted procedure: k3725 
o|contracted procedure: k3733 
o|contracted procedure: k3830 
o|contracted procedure: k3748 
o|contracted procedure: k3761 
o|contracted procedure: k3764 
o|contracted procedure: k3823 
o|contracted procedure: k3770 
o|contracted procedure: k3788 
o|contracted procedure: k3784 
o|contracted procedure: k3796 
o|contracted procedure: k3803 
o|contracted procedure: k3810 
o|contracted procedure: k3800 
o|contracted procedure: k3851 
o|contracted procedure: k4139 
o|contracted procedure: k4143 
o|contracted procedure: k4147 
o|contracted procedure: k3855 
o|contracted procedure: k3865 
o|contracted procedure: k3880 
o|contracted procedure: k3931 
o|contracted procedure: k3895 
o|contracted procedure: k3891 
o|contracted procedure: k3903 
o|contracted procedure: k3910 
o|contracted procedure: k3921 
o|contracted procedure: k3917 
o|contracted procedure: k3907 
o|contracted procedure: k3937 
o|contracted procedure: k3940 
o|contracted procedure: k3957 
o|contracted procedure: k3961 
o|contracted procedure: k4090 
o|contracted procedure: k3965 
o|contracted procedure: k4041 
o|contracted procedure: k4049 
o|contracted procedure: k3969 
o|contracted procedure: k3985 
o|contracted procedure: k3997 
o|contracted procedure: k3981 
o|contracted procedure: k3973 
o|contracted procedure: k3953 
o|contracted procedure: k4012 
o|contracted procedure: k4034 
o|contracted procedure: k4030 
o|contracted procedure: k4015 
o|contracted procedure: k4018 
o|contracted procedure: k4026 
o|contracted procedure: k4061 
o|contracted procedure: k4083 
o|contracted procedure: k4079 
o|contracted procedure: k4064 
o|contracted procedure: k4067 
o|contracted procedure: k4075 
o|contracted procedure: k4116 
o|contracted procedure: k4122 
o|contracted procedure: k4130 
o|simplifications: ((let . 26)) 
o|removed binding forms: 191 
o|inlining procedure: k3792 
o|inlining procedure: k3792 
o|inlining procedure: k3899 
o|inlining procedure: k3899 
o|replaced variables: 69 
o|removed binding forms: 42 
o|replaced variables: 6 
o|removed binding forms: 3 
o|direct leaf routine/allocation: loop237 0 
o|contracted procedure: k1704 
o|converted assignments to bindings: (loop237) 
o|simplifications: ((let . 1)) 
o|removed binding forms: 1 
o|customizable procedures: (k3868 k3871 map-loop625643 map-loop652670 g720729 map-loop714732 map-loop168186 map-loop195213 loop164 foldr153156 g158159 loop744 k3465 k3225 map-loop831848 map-loop860885 k3257 map-loop901926 map-loop942960 map-loop9761001 map-loop10171035 compiler-only-er-transformer590) 
o|calls to known targets: 58 
o|identified direct recursive calls: f_3324 1 
o|identified direct recursive calls: f_3629 1 
o|identified direct recursive calls: f_1659 1 
o|identified direct recursive calls: f_1854 1 
o|identified direct recursive calls: f_1731 1 
o|identified direct recursive calls: f_1780 1 
o|identified direct recursive calls: f_4007 1 
o|identified direct recursive calls: f_4056 1 
o|fast box initializations: 14 
o|dropping unused closure argument: f_1854 
o|dropping unused closure argument: f_2727 
*/
/* end of file */
