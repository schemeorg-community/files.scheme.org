/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-cc.org
   Version 5.1.0rc1 (prerelease) (rev 7358d2e5)
   linux-unix-gnu-x86-64 [ 64bit dload ptables ]
   command line: csi.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -consult-types-file ./types.db -no-lambda-info -no-trace -output-file csi.c
   uses: library eval expand extras file internal pathname port posix repl data-structures
*/
#include "chicken.h"

#include <signal.h>

#if defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_file_toplevel)
C_externimport void C_ccall C_file_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_internal_toplevel)
C_externimport void C_ccall C_internal_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_pathname_toplevel)
C_externimport void C_ccall C_pathname_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_port_toplevel)
C_externimport void C_ccall C_port_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_repl_toplevel)
C_externimport void C_ccall C_repl_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[404];
static double C_possibly_force_alignment;


/* from k3941 */
C_regparm static C_word C_fcall stub712(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(f9399)
static void C_ccall f9399(C_word c,C_word *av) C_noret;
C_noret_decl(f9440)
static void C_ccall f9440(C_word c,C_word *av) C_noret;
C_noret_decl(f9458)
static void C_ccall f9458(C_word c,C_word *av) C_noret;
C_noret_decl(f9462)
static void C_ccall f9462(C_word c,C_word *av) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word *av) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word *av) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word *av) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word *av) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word *av) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word *av) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word *av) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word *av) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word *av) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word *av) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word *av) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word *av) C_noret;
C_noret_decl(f_3047)
static void C_fcall f_3047(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word *av) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word *av) C_noret;
C_noret_decl(f_3122)
static void C_fcall f_3122(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word *av) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word *av) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word *av) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word *av) C_noret;
C_noret_decl(f_3847)
static void C_fcall f_3847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word *av) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word *av) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word *av) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word *av) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word *av) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word *av) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word *av) C_noret;
C_noret_decl(f_3948)
static void C_fcall f_3948(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word *av) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word *av) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word *av) C_noret;
C_noret_decl(f_3977)
static void C_fcall f_3977(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word *av) C_noret;
C_noret_decl(f_3999)
static void C_fcall f_3999(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word *av) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word *av) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word *av) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word *av) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word *av) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word *av) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word *av) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word *av) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word *av) C_noret;
C_noret_decl(f_4056)
static void C_fcall f_4056(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word *av) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word *av) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word *av) C_noret;
C_noret_decl(f_4106)
static void C_fcall f_4106(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4116)
static void C_fcall f_4116(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word *av) C_noret;
C_noret_decl(f_4161)
static void C_fcall f_4161(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word *av) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word *av) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word *av) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word *av) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word *av) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word *av) C_noret;
C_noret_decl(f_4205)
static void C_fcall f_4205(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word *av) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word *av) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word *av) C_noret;
C_noret_decl(f_4261)
static void C_ccall f_4261(C_word c,C_word *av) C_noret;
C_noret_decl(f_4269)
static void C_ccall f_4269(C_word c,C_word *av) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word *av) C_noret;
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word *av) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word *av) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word *av) C_noret;
C_noret_decl(f_4317)
static C_word C_fcall f_4317(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word *av) C_noret;
C_noret_decl(f_4363)
static void C_fcall f_4363(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word *av) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word *av) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word *av) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word *av) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word *av) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word *av) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word *av) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word *av) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word *av) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word *av) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word *av) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word *av) C_noret;
C_noret_decl(f_4466)
static void C_ccall f_4466(C_word c,C_word *av) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word *av) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word *av) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word *av) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word *av) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word *av) C_noret;
C_noret_decl(f_4513)
static void C_fcall f_4513(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word *av) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word *av) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word *av) C_noret;
C_noret_decl(f_4548)
static void C_fcall f_4548(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word *av) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word *av) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word *av) C_noret;
C_noret_decl(f_4569)
static void C_fcall f_4569(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word *av) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word *av) C_noret;
C_noret_decl(f_4603)
static void C_ccall f_4603(C_word c,C_word *av) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word *av) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word *av) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word *av) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word *av) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word *av) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word *av) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word *av) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word *av) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word *av) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word *av) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word *av) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word *av) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word *av) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word *av) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word *av) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word *av) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word *av) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word *av) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word *av) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word *av) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word *av) C_noret;
C_noret_decl(f_4780)
static void C_ccall f_4780(C_word c,C_word *av) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word *av) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word *av) C_noret;
C_noret_decl(f_4820)
static void C_fcall f_4820(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word *av) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word *av) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word *av) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word *av) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word *av) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word *av) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word *av) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word *av) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word *av) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word *av) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word *av) C_noret;
C_noret_decl(f_4956)
static void C_fcall f_4956(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word *av) C_noret;
C_noret_decl(f_4990)
static void C_ccall f_4990(C_word c,C_word *av) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word *av) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word *av) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word *av) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word *av) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word *av) C_noret;
C_noret_decl(f_5024)
static void C_fcall f_5024(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word *av) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word *av) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word *av) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word *av) C_noret;
C_noret_decl(f_5062)
static void C_fcall f_5062(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5070)
static void C_fcall f_5070(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5072)
static void C_ccall f_5072(C_word c,C_word *av) C_noret;
C_noret_decl(f_5076)
static void C_ccall f_5076(C_word c,C_word *av) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word *av) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word *av) C_noret;
C_noret_decl(f_5084)
static void C_fcall f_5084(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word *av) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word *av) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word *av) C_noret;
C_noret_decl(f_5104)
static void C_fcall f_5104(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word *av) C_noret;
C_noret_decl(f_5118)
static void C_fcall f_5118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word *av) C_noret;
C_noret_decl(f_5135)
static void C_ccall f_5135(C_word c,C_word *av) C_noret;
C_noret_decl(f_5150)
static void C_ccall f_5150(C_word c,C_word *av) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word *av) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word *av) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word *av) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word *av) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word *av) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word *av) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word *av) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word *av) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word *av) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word *av) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word *av) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word *av) C_noret;
C_noret_decl(f_5230)
static void C_ccall f_5230(C_word c,C_word *av) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word *av) C_noret;
C_noret_decl(f_5245)
static void C_ccall f_5245(C_word c,C_word *av) C_noret;
C_noret_decl(f_5247)
static void C_fcall f_5247(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word *av) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word *av) C_noret;
C_noret_decl(f_5280)
static void C_fcall f_5280(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word *av) C_noret;
C_noret_decl(f_5325)
static C_word C_fcall f_5325(C_word t0,C_word t1);
C_noret_decl(f_5360)
static C_word C_fcall f_5360(C_word t0);
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word *av) C_noret;
C_noret_decl(f_5392)
static void C_fcall f_5392(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word *av) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word *av) C_noret;
C_noret_decl(f_5410)
static void C_fcall f_5410(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word *av) C_noret;
C_noret_decl(f_5442)
static void C_fcall f_5442(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word *av) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word *av) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word *av) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word *av) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word *av) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word *av) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word *av) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word *av) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word *av) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word *av) C_noret;
C_noret_decl(f_5703)
static void C_ccall f_5703(C_word c,C_word *av) C_noret;
C_noret_decl(f_5712)
static void C_ccall f_5712(C_word c,C_word *av) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word *av) C_noret;
C_noret_decl(f_5727)
static void C_ccall f_5727(C_word c,C_word *av) C_noret;
C_noret_decl(f_5732)
static void C_fcall f_5732(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word *av) C_noret;
C_noret_decl(f_5745)
static void C_ccall f_5745(C_word c,C_word *av) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word *av) C_noret;
C_noret_decl(f_5757)
static void C_ccall f_5757(C_word c,C_word *av) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word *av) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word *av) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word *av) C_noret;
C_noret_decl(f_5795)
static void C_fcall f_5795(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word *av) C_noret;
C_noret_decl(f_5807)
static void C_fcall f_5807(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5838)
static void C_ccall f_5838(C_word c,C_word *av) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word *av) C_noret;
C_noret_decl(f_5906)
static void C_ccall f_5906(C_word c,C_word *av) C_noret;
C_noret_decl(f_5912)
static void C_ccall f_5912(C_word c,C_word *av) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word *av) C_noret;
C_noret_decl(f_5940)
static void C_ccall f_5940(C_word c,C_word *av) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word *av) C_noret;
C_noret_decl(f_6064)
static void C_ccall f_6064(C_word c,C_word *av) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word *av) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word *av) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089(C_word c,C_word *av) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101(C_word c,C_word *av) C_noret;
C_noret_decl(f_6104)
static void C_ccall f_6104(C_word c,C_word *av) C_noret;
C_noret_decl(f_6115)
static void C_fcall f_6115(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6123)
static void C_fcall f_6123(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6144)
static void C_ccall f_6144(C_word c,C_word *av) C_noret;
C_noret_decl(f_6153)
static void C_fcall f_6153(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6163)
static void C_ccall f_6163(C_word c,C_word *av) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word *av) C_noret;
C_noret_decl(f_6199)
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word *av) C_noret;
C_noret_decl(f_6212)
static void C_fcall f_6212(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6222)
static void C_ccall f_6222(C_word c,C_word *av) C_noret;
C_noret_decl(f_6235)
static void C_ccall f_6235(C_word c,C_word *av) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word *av) C_noret;
C_noret_decl(f_6267)
static void C_fcall f_6267(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6277)
static void C_ccall f_6277(C_word c,C_word *av) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word *av) C_noret;
C_noret_decl(f_6308)
static void C_fcall f_6308(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6322)
static void C_fcall f_6322(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word *av) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word *av) C_noret;
C_noret_decl(f_6349)
static void C_fcall f_6349(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word *av) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word *av) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word *av) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word *av) C_noret;
C_noret_decl(f_6431)
static void C_fcall f_6431(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6433)
static void C_fcall f_6433(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6436)
static void C_fcall f_6436(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6458)
static void C_ccall f_6458(C_word c,C_word *av) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word *av) C_noret;
C_noret_decl(f_6482)
static void C_ccall f_6482(C_word c,C_word *av) C_noret;
C_noret_decl(f_6501)
static void C_fcall f_6501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word *av) C_noret;
C_noret_decl(f_6539)
static void C_fcall f_6539(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6544)
static void C_fcall f_6544(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6579)
static void C_fcall f_6579(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6582)
static void C_fcall f_6582(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word *av) C_noret;
C_noret_decl(f_6602)
static void C_ccall f_6602(C_word c,C_word *av) C_noret;
C_noret_decl(f_6614)
static void C_fcall f_6614(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word *av) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word *av) C_noret;
C_noret_decl(f_6630)
static void C_ccall f_6630(C_word c,C_word *av) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word *av) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word *av) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word *av) C_noret;
C_noret_decl(f_6648)
static void C_fcall f_6648(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word *av) C_noret;
C_noret_decl(f_6664)
static void C_ccall f_6664(C_word c,C_word *av) C_noret;
C_noret_decl(f_6699)
static void C_fcall f_6699(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6733)
static void C_fcall f_6733(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6743)
static void C_ccall f_6743(C_word c,C_word *av) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word *av) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word *av) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word *av) C_noret;
C_noret_decl(f_6775)
static void C_ccall f_6775(C_word c,C_word *av) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word *av) C_noret;
C_noret_decl(f_6784)
static void C_fcall f_6784(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_fcall f_6787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word *av) C_noret;
C_noret_decl(f_6810)
static void C_fcall f_6810(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6819)
static void C_fcall f_6819(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word *av) C_noret;
C_noret_decl(f_6853)
static void C_ccall f_6853(C_word c,C_word *av) C_noret;
C_noret_decl(f_6856)
static void C_ccall f_6856(C_word c,C_word *av) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word *av) C_noret;
C_noret_decl(f_6862)
static void C_ccall f_6862(C_word c,C_word *av) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word *av) C_noret;
C_noret_decl(f_6868)
static void C_ccall f_6868(C_word c,C_word *av) C_noret;
C_noret_decl(f_6871)
static void C_ccall f_6871(C_word c,C_word *av) C_noret;
C_noret_decl(f_6874)
static void C_ccall f_6874(C_word c,C_word *av) C_noret;
C_noret_decl(f_6877)
static void C_ccall f_6877(C_word c,C_word *av) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word *av) C_noret;
C_noret_decl(f_6893)
static void C_fcall f_6893(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6903)
static void C_ccall f_6903(C_word c,C_word *av) C_noret;
C_noret_decl(f_6908)
static void C_fcall f_6908(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6921)
static void C_ccall f_6921(C_word c,C_word *av) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word *av) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word *av) C_noret;
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word *av) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word *av) C_noret;
C_noret_decl(f_6967)
static void C_fcall f_6967(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6977)
static void C_ccall f_6977(C_word c,C_word *av) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word *av) C_noret;
C_noret_decl(f_7014)
static void C_ccall f_7014(C_word c,C_word *av) C_noret;
C_noret_decl(f_7028)
static void C_fcall f_7028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7069)
static void C_fcall f_7069(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7126)
static void C_fcall f_7126(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_fcall f_7128(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7139)
static void C_ccall f_7139(C_word c,C_word *av) C_noret;
C_noret_decl(f_7159)
static void C_ccall f_7159(C_word c,C_word *av) C_noret;
C_noret_decl(f_7162)
static void C_fcall f_7162(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7166)
static void C_ccall f_7166(C_word c,C_word *av) C_noret;
C_noret_decl(f_7169)
static void C_ccall f_7169(C_word c,C_word *av) C_noret;
C_noret_decl(f_7181)
static void C_fcall f_7181(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7206)
static void C_ccall f_7206(C_word c,C_word *av) C_noret;
C_noret_decl(f_7215)
static void C_fcall f_7215(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7221)
static void C_fcall f_7221(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7231)
static void C_ccall f_7231(C_word c,C_word *av) C_noret;
C_noret_decl(f_7243)
static void C_ccall f_7243(C_word c,C_word *av) C_noret;
C_noret_decl(f_7246)
static void C_ccall f_7246(C_word c,C_word *av) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word *av) C_noret;
C_noret_decl(f_7252)
static void C_ccall f_7252(C_word c,C_word *av) C_noret;
C_noret_decl(f_7255)
static void C_ccall f_7255(C_word c,C_word *av) C_noret;
C_noret_decl(f_7291)
static void C_ccall f_7291(C_word c,C_word *av) C_noret;
C_noret_decl(f_7298)
static void C_ccall f_7298(C_word c,C_word *av) C_noret;
C_noret_decl(f_7300)
static void C_fcall f_7300(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word *av) C_noret;
C_noret_decl(f_7353)
static void C_ccall f_7353(C_word c,C_word *av) C_noret;
C_noret_decl(f_7358)
static void C_fcall f_7358(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7364)
static void C_fcall f_7364(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7376)
static void C_fcall f_7376(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7413)
static void C_fcall f_7413(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7419)
static void C_fcall f_7419(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7441)
static void C_fcall f_7441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7455)
static void C_ccall f_7455(C_word c,C_word *av) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476(C_word c,C_word *av) C_noret;
C_noret_decl(f_7480)
static void C_ccall f_7480(C_word c,C_word *av) C_noret;
C_noret_decl(f_7484)
static void C_fcall f_7484(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word *av) C_noret;
C_noret_decl(f_7531)
static void C_ccall f_7531(C_word c,C_word *av) C_noret;
C_noret_decl(f_7562)
static C_word C_fcall f_7562(C_word t0);
C_noret_decl(f_7592)
static void C_ccall f_7592(C_word c,C_word *av) C_noret;
C_noret_decl(f_7595)
static void C_ccall f_7595(C_word c,C_word *av) C_noret;
C_noret_decl(f_7598)
static void C_ccall f_7598(C_word c,C_word *av) C_noret;
C_noret_decl(f_7601)
static void C_ccall f_7601(C_word c,C_word *av) C_noret;
C_noret_decl(f_7604)
static void C_fcall f_7604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7607)
static void C_ccall f_7607(C_word c,C_word *av) C_noret;
C_noret_decl(f_7610)
static void C_fcall f_7610(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613(C_word c,C_word *av) C_noret;
C_noret_decl(f_7616)
static void C_fcall f_7616(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7622)
static void C_ccall f_7622(C_word c,C_word *av) C_noret;
C_noret_decl(f_7628)
static void C_ccall f_7628(C_word c,C_word *av) C_noret;
C_noret_decl(f_7630)
static void C_fcall f_7630(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7636)
static void C_fcall f_7636(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7644)
static void C_fcall f_7644(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7665)
static void C_ccall f_7665(C_word c,C_word *av) C_noret;
C_noret_decl(f_7681)
static void C_ccall f_7681(C_word c,C_word *av) C_noret;
C_noret_decl(f_7684)
static void C_ccall f_7684(C_word c,C_word *av) C_noret;
C_noret_decl(f_7687)
static void C_ccall f_7687(C_word c,C_word *av) C_noret;
C_noret_decl(f_7690)
static void C_ccall f_7690(C_word c,C_word *av) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word *av) C_noret;
C_noret_decl(f_7705)
static void C_ccall f_7705(C_word c,C_word *av) C_noret;
C_noret_decl(f_7727)
static void C_ccall f_7727(C_word c,C_word *av) C_noret;
C_noret_decl(f_7742)
static void C_fcall f_7742(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7749)
static void C_ccall f_7749(C_word c,C_word *av) C_noret;
C_noret_decl(f_7756)
static void C_ccall f_7756(C_word c,C_word *av) C_noret;
C_noret_decl(f_7758)
static void C_fcall f_7758(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7768)
static void C_ccall f_7768(C_word c,C_word *av) C_noret;
C_noret_decl(f_7775)
static void C_ccall f_7775(C_word c,C_word *av) C_noret;
C_noret_decl(f_7779)
static void C_ccall f_7779(C_word c,C_word *av) C_noret;
C_noret_decl(f_7781)
static void C_ccall f_7781(C_word c,C_word *av) C_noret;
C_noret_decl(f_7789)
static void C_ccall f_7789(C_word c,C_word *av) C_noret;
C_noret_decl(f_7799)
static void C_ccall f_7799(C_word c,C_word *av) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word *av) C_noret;
C_noret_decl(f_7805)
static void C_fcall f_7805(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word *av) C_noret;
C_noret_decl(f_7811)
static void C_fcall f_7811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7814)
static void C_ccall f_7814(C_word c,C_word *av) C_noret;
C_noret_decl(f_7817)
static void C_ccall f_7817(C_word c,C_word *av) C_noret;
C_noret_decl(f_7823)
static void C_ccall f_7823(C_word c,C_word *av) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word *av) C_noret;
C_noret_decl(f_7832)
static void C_ccall f_7832(C_word c,C_word *av) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word *av) C_noret;
C_noret_decl(f_7841)
static void C_ccall f_7841(C_word c,C_word *av) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word *av) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word *av) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word *av) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word *av) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word *av) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word *av) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word *av) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word *av) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word *av) C_noret;
C_noret_decl(f_7872)
static void C_fcall f_7872(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7877)
static void C_fcall f_7877(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7905)
static void C_ccall f_7905(C_word c,C_word *av) C_noret;
C_noret_decl(f_7934)
static void C_ccall f_7934(C_word c,C_word *av) C_noret;
C_noret_decl(f_7946)
static void C_ccall f_7946(C_word c,C_word *av) C_noret;
C_noret_decl(f_7961)
static void C_ccall f_7961(C_word c,C_word *av) C_noret;
C_noret_decl(f_7980)
static void C_ccall f_7980(C_word c,C_word *av) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990(C_word c,C_word *av) C_noret;
C_noret_decl(f_8005)
static void C_ccall f_8005(C_word c,C_word *av) C_noret;
C_noret_decl(f_8015)
static void C_ccall f_8015(C_word c,C_word *av) C_noret;
C_noret_decl(f_8025)
static void C_ccall f_8025(C_word c,C_word *av) C_noret;
C_noret_decl(f_8036)
static void C_ccall f_8036(C_word c,C_word *av) C_noret;
C_noret_decl(f_8040)
static void C_ccall f_8040(C_word c,C_word *av) C_noret;
C_noret_decl(f_8047)
static void C_ccall f_8047(C_word c,C_word *av) C_noret;
C_noret_decl(f_8049)
static void C_ccall f_8049(C_word c,C_word *av) C_noret;
C_noret_decl(f_8077)
static void C_ccall f_8077(C_word c,C_word *av) C_noret;
C_noret_decl(f_8081)
static void C_ccall f_8081(C_word c,C_word *av) C_noret;
C_noret_decl(f_8087)
static void C_ccall f_8087(C_word c,C_word *av) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word *av) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word *av) C_noret;
C_noret_decl(f_8096)
static void C_ccall f_8096(C_word c,C_word *av) C_noret;
C_noret_decl(f_8101)
static void C_fcall f_8101(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8114)
static void C_ccall f_8114(C_word c,C_word *av) C_noret;
C_noret_decl(f_8117)
static void C_ccall f_8117(C_word c,C_word *av) C_noret;
C_noret_decl(f_8132)
static void C_ccall f_8132(C_word c,C_word *av) C_noret;
C_noret_decl(f_8151)
static void C_ccall f_8151(C_word c,C_word *av) C_noret;
C_noret_decl(f_8163)
static void C_ccall f_8163(C_word c,C_word *av) C_noret;
C_noret_decl(f_8177)
static void C_ccall f_8177(C_word c,C_word *av) C_noret;
C_noret_decl(f_8180)
static void C_ccall f_8180(C_word c,C_word *av) C_noret;
C_noret_decl(f_8183)
static void C_ccall f_8183(C_word c,C_word *av) C_noret;
C_noret_decl(f_8186)
static void C_ccall f_8186(C_word c,C_word *av) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189(C_word c,C_word *av) C_noret;
C_noret_decl(f_8198)
static void C_ccall f_8198(C_word c,C_word *av) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word *av) C_noret;
C_noret_decl(f_8210)
static void C_ccall f_8210(C_word c,C_word *av) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word *av) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word *av) C_noret;
C_noret_decl(f_8284)
static void C_ccall f_8284(C_word c,C_word *av) C_noret;
C_noret_decl(f_8290)
static void C_ccall f_8290(C_word c,C_word *av) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word *av) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word *av) C_noret;
C_noret_decl(f_8305)
static void C_fcall f_8305(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8330)
static void C_ccall f_8330(C_word c,C_word *av) C_noret;
C_noret_decl(f_8339)
static void C_fcall f_8339(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8364)
static void C_ccall f_8364(C_word c,C_word *av) C_noret;
C_noret_decl(f_8373)
static void C_fcall f_8373(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8383)
static void C_ccall f_8383(C_word c,C_word *av) C_noret;
C_noret_decl(f_8396)
static void C_fcall f_8396(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8406)
static void C_ccall f_8406(C_word c,C_word *av) C_noret;
C_noret_decl(f_8419)
static void C_fcall f_8419(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8429)
static void C_ccall f_8429(C_word c,C_word *av) C_noret;
C_noret_decl(f_8443)
static void C_ccall f_8443(C_word c,C_word *av) C_noret;
C_noret_decl(f_8446)
static void C_ccall f_8446(C_word c,C_word *av) C_noret;
C_noret_decl(f_8449)
static void C_ccall f_8449(C_word c,C_word *av) C_noret;
C_noret_decl(f_8458)
static void C_ccall f_8458(C_word c,C_word *av) C_noret;
C_noret_decl(f_8461)
static void C_ccall f_8461(C_word c,C_word *av) C_noret;
C_noret_decl(f_8471)
static void C_ccall f_8471(C_word c,C_word *av) C_noret;
C_noret_decl(f_8478)
static void C_ccall f_8478(C_word c,C_word *av) C_noret;
C_noret_decl(f_8488)
static void C_ccall f_8488(C_word c,C_word *av) C_noret;
C_noret_decl(f_8494)
static void C_ccall f_8494(C_word c,C_word *av) C_noret;
C_noret_decl(f_8497)
static void C_ccall f_8497(C_word c,C_word *av) C_noret;
C_noret_decl(f_8502)
static void C_fcall f_8502(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8527)
static void C_ccall f_8527(C_word c,C_word *av) C_noret;
C_noret_decl(f_8538)
static void C_ccall f_8538(C_word c,C_word *av) C_noret;
C_noret_decl(f_8547)
static void C_ccall f_8547(C_word c,C_word *av) C_noret;
C_noret_decl(f_8553)
static void C_ccall f_8553(C_word c,C_word *av) C_noret;
C_noret_decl(f_8556)
static void C_ccall f_8556(C_word c,C_word *av) C_noret;
C_noret_decl(f_8559)
static void C_ccall f_8559(C_word c,C_word *av) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word *av) C_noret;
C_noret_decl(f_8571)
static void C_ccall f_8571(C_word c,C_word *av) C_noret;
C_noret_decl(f_8636)
static void C_ccall f_8636(C_word c,C_word *av) C_noret;
C_noret_decl(f_8649)
static void C_ccall f_8649(C_word c,C_word *av) C_noret;
C_noret_decl(f_8653)
static void C_ccall f_8653(C_word c,C_word *av) C_noret;
C_noret_decl(f_8657)
static void C_ccall f_8657(C_word c,C_word *av) C_noret;
C_noret_decl(f_8663)
static void C_ccall f_8663(C_word c,C_word *av) C_noret;
C_noret_decl(f_8669)
static void C_ccall f_8669(C_word c,C_word *av) C_noret;
C_noret_decl(f_8671)
static void C_ccall f_8671(C_word c,C_word *av) C_noret;
C_noret_decl(f_8677)
static void C_ccall f_8677(C_word c,C_word *av) C_noret;
C_noret_decl(f_8681)
static void C_ccall f_8681(C_word c,C_word *av) C_noret;
C_noret_decl(f_8690)
static void C_ccall f_8690(C_word c,C_word *av) C_noret;
C_noret_decl(f_8696)
static void C_ccall f_8696(C_word c,C_word *av) C_noret;
C_noret_decl(f_8700)
static void C_fcall f_8700(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8704)
static void C_ccall f_8704(C_word c,C_word *av) C_noret;
C_noret_decl(f_8717)
static void C_ccall f_8717(C_word c,C_word *av) C_noret;
C_noret_decl(f_8719)
static void C_ccall f_8719(C_word c,C_word *av) C_noret;
C_noret_decl(f_8727)
static void C_ccall f_8727(C_word c,C_word *av) C_noret;
C_noret_decl(f_8730)
static void C_ccall f_8730(C_word c,C_word *av) C_noret;
C_noret_decl(f_8737)
static void C_ccall f_8737(C_word c,C_word *av) C_noret;
C_noret_decl(f_8741)
static void C_ccall f_8741(C_word c,C_word *av) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750(C_word c,C_word *av) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word *av) C_noret;

C_noret_decl(trf_3047)
static void C_ccall trf_3047(C_word c,C_word *av) C_noret;
static void C_ccall trf_3047(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3047(t0,t1,t2);}

C_noret_decl(trf_3122)
static void C_ccall trf_3122(C_word c,C_word *av) C_noret;
static void C_ccall trf_3122(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3122(t0,t1,t2);}

C_noret_decl(trf_3847)
static void C_ccall trf_3847(C_word c,C_word *av) C_noret;
static void C_ccall trf_3847(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3847(t0,t1);}

C_noret_decl(trf_3948)
static void C_ccall trf_3948(C_word c,C_word *av) C_noret;
static void C_ccall trf_3948(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3948(t0,t1);}

C_noret_decl(trf_3977)
static void C_ccall trf_3977(C_word c,C_word *av) C_noret;
static void C_ccall trf_3977(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3977(t0,t1,t2);}

C_noret_decl(trf_3999)
static void C_ccall trf_3999(C_word c,C_word *av) C_noret;
static void C_ccall trf_3999(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3999(t0,t1,t2);}

C_noret_decl(trf_4056)
static void C_ccall trf_4056(C_word c,C_word *av) C_noret;
static void C_ccall trf_4056(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4056(t0,t1,t2);}

C_noret_decl(trf_4106)
static void C_ccall trf_4106(C_word c,C_word *av) C_noret;
static void C_ccall trf_4106(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4106(t0,t1,t2);}

C_noret_decl(trf_4116)
static void C_ccall trf_4116(C_word c,C_word *av) C_noret;
static void C_ccall trf_4116(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4116(t0,t1);}

C_noret_decl(trf_4161)
static void C_ccall trf_4161(C_word c,C_word *av) C_noret;
static void C_ccall trf_4161(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4161(t0,t1,t2);}

C_noret_decl(trf_4205)
static void C_ccall trf_4205(C_word c,C_word *av) C_noret;
static void C_ccall trf_4205(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4205(t0,t1);}

C_noret_decl(trf_4363)
static void C_ccall trf_4363(C_word c,C_word *av) C_noret;
static void C_ccall trf_4363(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4363(t0,t1);}

C_noret_decl(trf_4513)
static void C_ccall trf_4513(C_word c,C_word *av) C_noret;
static void C_ccall trf_4513(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4513(t0,t1,t2);}

C_noret_decl(trf_4548)
static void C_ccall trf_4548(C_word c,C_word *av) C_noret;
static void C_ccall trf_4548(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4548(t0,t1,t2);}

C_noret_decl(trf_4569)
static void C_ccall trf_4569(C_word c,C_word *av) C_noret;
static void C_ccall trf_4569(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4569(t0,t1,t2);}

C_noret_decl(trf_4820)
static void C_ccall trf_4820(C_word c,C_word *av) C_noret;
static void C_ccall trf_4820(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4820(t0,t1,t2);}

C_noret_decl(trf_4956)
static void C_ccall trf_4956(C_word c,C_word *av) C_noret;
static void C_ccall trf_4956(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4956(t0,t1,t2);}

C_noret_decl(trf_5024)
static void C_ccall trf_5024(C_word c,C_word *av) C_noret;
static void C_ccall trf_5024(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5024(t0,t1,t2,t3);}

C_noret_decl(trf_5062)
static void C_ccall trf_5062(C_word c,C_word *av) C_noret;
static void C_ccall trf_5062(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5062(t0,t1,t2);}

C_noret_decl(trf_5070)
static void C_ccall trf_5070(C_word c,C_word *av) C_noret;
static void C_ccall trf_5070(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5070(t0,t1);}

C_noret_decl(trf_5084)
static void C_ccall trf_5084(C_word c,C_word *av) C_noret;
static void C_ccall trf_5084(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5084(t0,t1);}

C_noret_decl(trf_5104)
static void C_ccall trf_5104(C_word c,C_word *av) C_noret;
static void C_ccall trf_5104(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5104(t0,t1,t2);}

C_noret_decl(trf_5118)
static void C_ccall trf_5118(C_word c,C_word *av) C_noret;
static void C_ccall trf_5118(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5118(t0,t1);}

C_noret_decl(trf_5247)
static void C_ccall trf_5247(C_word c,C_word *av) C_noret;
static void C_ccall trf_5247(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5247(t0,t1,t2);}

C_noret_decl(trf_5280)
static void C_ccall trf_5280(C_word c,C_word *av) C_noret;
static void C_ccall trf_5280(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5280(t0,t1,t2);}

C_noret_decl(trf_5392)
static void C_ccall trf_5392(C_word c,C_word *av) C_noret;
static void C_ccall trf_5392(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5392(t0,t1,t2,t3);}

C_noret_decl(trf_5410)
static void C_ccall trf_5410(C_word c,C_word *av) C_noret;
static void C_ccall trf_5410(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5410(t0,t1,t2);}

C_noret_decl(trf_5442)
static void C_ccall trf_5442(C_word c,C_word *av) C_noret;
static void C_ccall trf_5442(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5442(t0,t1,t2,t3);}

C_noret_decl(trf_5732)
static void C_ccall trf_5732(C_word c,C_word *av) C_noret;
static void C_ccall trf_5732(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5732(t0,t1,t2);}

C_noret_decl(trf_5795)
static void C_ccall trf_5795(C_word c,C_word *av) C_noret;
static void C_ccall trf_5795(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5795(t0,t1);}

C_noret_decl(trf_5807)
static void C_ccall trf_5807(C_word c,C_word *av) C_noret;
static void C_ccall trf_5807(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5807(t0,t1,t2,t3);}

C_noret_decl(trf_6115)
static void C_ccall trf_6115(C_word c,C_word *av) C_noret;
static void C_ccall trf_6115(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6115(t0,t1,t2);}

C_noret_decl(trf_6123)
static void C_ccall trf_6123(C_word c,C_word *av) C_noret;
static void C_ccall trf_6123(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6123(t0,t1,t2);}

C_noret_decl(trf_6153)
static void C_ccall trf_6153(C_word c,C_word *av) C_noret;
static void C_ccall trf_6153(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6153(t0,t1,t2);}

C_noret_decl(trf_6199)
static void C_ccall trf_6199(C_word c,C_word *av) C_noret;
static void C_ccall trf_6199(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6199(t0,t1,t2);}

C_noret_decl(trf_6212)
static void C_ccall trf_6212(C_word c,C_word *av) C_noret;
static void C_ccall trf_6212(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6212(t0,t1,t2);}

C_noret_decl(trf_6267)
static void C_ccall trf_6267(C_word c,C_word *av) C_noret;
static void C_ccall trf_6267(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6267(t0,t1,t2);}

C_noret_decl(trf_6308)
static void C_ccall trf_6308(C_word c,C_word *av) C_noret;
static void C_ccall trf_6308(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6308(t0,t1,t2);}

C_noret_decl(trf_6322)
static void C_ccall trf_6322(C_word c,C_word *av) C_noret;
static void C_ccall trf_6322(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6322(t0,t1,t2);}

C_noret_decl(trf_6349)
static void C_ccall trf_6349(C_word c,C_word *av) C_noret;
static void C_ccall trf_6349(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6349(t0,t1,t2);}

C_noret_decl(trf_6431)
static void C_ccall trf_6431(C_word c,C_word *av) C_noret;
static void C_ccall trf_6431(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6431(t0,t1,t2);}

C_noret_decl(trf_6433)
static void C_ccall trf_6433(C_word c,C_word *av) C_noret;
static void C_ccall trf_6433(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6433(t0,t1,t2,t3);}

C_noret_decl(trf_6436)
static void C_ccall trf_6436(C_word c,C_word *av) C_noret;
static void C_ccall trf_6436(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6436(t0,t1,t2);}

C_noret_decl(trf_6501)
static void C_ccall trf_6501(C_word c,C_word *av) C_noret;
static void C_ccall trf_6501(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6501(t0,t1);}

C_noret_decl(trf_6539)
static void C_ccall trf_6539(C_word c,C_word *av) C_noret;
static void C_ccall trf_6539(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6539(t0,t1,t2);}

C_noret_decl(trf_6544)
static void C_ccall trf_6544(C_word c,C_word *av) C_noret;
static void C_ccall trf_6544(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6544(t0,t1);}

C_noret_decl(trf_6579)
static void C_ccall trf_6579(C_word c,C_word *av) C_noret;
static void C_ccall trf_6579(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_6579(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6582)
static void C_ccall trf_6582(C_word c,C_word *av) C_noret;
static void C_ccall trf_6582(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_6582(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6614)
static void C_ccall trf_6614(C_word c,C_word *av) C_noret;
static void C_ccall trf_6614(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6614(t0,t1,t2);}

C_noret_decl(trf_6648)
static void C_ccall trf_6648(C_word c,C_word *av) C_noret;
static void C_ccall trf_6648(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6648(t0,t1,t2,t3);}

C_noret_decl(trf_6699)
static void C_ccall trf_6699(C_word c,C_word *av) C_noret;
static void C_ccall trf_6699(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6699(t0,t1,t2,t3);}

C_noret_decl(trf_6733)
static void C_ccall trf_6733(C_word c,C_word *av) C_noret;
static void C_ccall trf_6733(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6733(t0,t1,t2);}

C_noret_decl(trf_6784)
static void C_ccall trf_6784(C_word c,C_word *av) C_noret;
static void C_ccall trf_6784(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6784(t0,t1);}

C_noret_decl(trf_6787)
static void C_ccall trf_6787(C_word c,C_word *av) C_noret;
static void C_ccall trf_6787(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6787(t0,t1);}

C_noret_decl(trf_6810)
static void C_ccall trf_6810(C_word c,C_word *av) C_noret;
static void C_ccall trf_6810(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6810(t0,t1);}

C_noret_decl(trf_6819)
static void C_ccall trf_6819(C_word c,C_word *av) C_noret;
static void C_ccall trf_6819(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6819(t0,t1,t2,t3);}

C_noret_decl(trf_6893)
static void C_ccall trf_6893(C_word c,C_word *av) C_noret;
static void C_ccall trf_6893(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6893(t0,t1,t2,t3);}

C_noret_decl(trf_6908)
static void C_ccall trf_6908(C_word c,C_word *av) C_noret;
static void C_ccall trf_6908(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6908(t0,t1,t2,t3);}

C_noret_decl(trf_6967)
static void C_ccall trf_6967(C_word c,C_word *av) C_noret;
static void C_ccall trf_6967(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6967(t0,t1,t2,t3);}

C_noret_decl(trf_7028)
static void C_ccall trf_7028(C_word c,C_word *av) C_noret;
static void C_ccall trf_7028(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7028(t0,t1);}

C_noret_decl(trf_7069)
static void C_ccall trf_7069(C_word c,C_word *av) C_noret;
static void C_ccall trf_7069(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7069(t0,t1);}

C_noret_decl(trf_7126)
static void C_ccall trf_7126(C_word c,C_word *av) C_noret;
static void C_ccall trf_7126(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7126(t0,t1);}

C_noret_decl(trf_7128)
static void C_ccall trf_7128(C_word c,C_word *av) C_noret;
static void C_ccall trf_7128(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7128(t0,t1,t2);}

C_noret_decl(trf_7162)
static void C_ccall trf_7162(C_word c,C_word *av) C_noret;
static void C_ccall trf_7162(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7162(t0,t1,t2);}

C_noret_decl(trf_7181)
static void C_ccall trf_7181(C_word c,C_word *av) C_noret;
static void C_ccall trf_7181(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7181(t0,t1,t2);}

C_noret_decl(trf_7215)
static void C_ccall trf_7215(C_word c,C_word *av) C_noret;
static void C_ccall trf_7215(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7215(t0,t1,t2,t3);}

C_noret_decl(trf_7221)
static void C_ccall trf_7221(C_word c,C_word *av) C_noret;
static void C_ccall trf_7221(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7221(t0,t1,t2,t3);}

C_noret_decl(trf_7300)
static void C_ccall trf_7300(C_word c,C_word *av) C_noret;
static void C_ccall trf_7300(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7300(t0,t1,t2,t3);}

C_noret_decl(trf_7358)
static void C_ccall trf_7358(C_word c,C_word *av) C_noret;
static void C_ccall trf_7358(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7358(t0,t1,t2);}

C_noret_decl(trf_7364)
static void C_ccall trf_7364(C_word c,C_word *av) C_noret;
static void C_ccall trf_7364(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7364(t0,t1,t2);}

C_noret_decl(trf_7376)
static void C_ccall trf_7376(C_word c,C_word *av) C_noret;
static void C_ccall trf_7376(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7376(t0,t1,t2);}

C_noret_decl(trf_7413)
static void C_ccall trf_7413(C_word c,C_word *av) C_noret;
static void C_ccall trf_7413(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7413(t0,t1);}

C_noret_decl(trf_7419)
static void C_ccall trf_7419(C_word c,C_word *av) C_noret;
static void C_ccall trf_7419(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7419(t0,t1,t2);}

C_noret_decl(trf_7441)
static void C_ccall trf_7441(C_word c,C_word *av) C_noret;
static void C_ccall trf_7441(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7441(t0,t1);}

C_noret_decl(trf_7484)
static void C_ccall trf_7484(C_word c,C_word *av) C_noret;
static void C_ccall trf_7484(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7484(t0,t1,t2);}

C_noret_decl(trf_7604)
static void C_ccall trf_7604(C_word c,C_word *av) C_noret;
static void C_ccall trf_7604(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7604(t0,t1);}

C_noret_decl(trf_7610)
static void C_ccall trf_7610(C_word c,C_word *av) C_noret;
static void C_ccall trf_7610(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7610(t0,t1);}

C_noret_decl(trf_7616)
static void C_ccall trf_7616(C_word c,C_word *av) C_noret;
static void C_ccall trf_7616(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7616(t0,t1);}

C_noret_decl(trf_7630)
static void C_ccall trf_7630(C_word c,C_word *av) C_noret;
static void C_ccall trf_7630(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7630(t0,t1,t2);}

C_noret_decl(trf_7636)
static void C_ccall trf_7636(C_word c,C_word *av) C_noret;
static void C_ccall trf_7636(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7636(t0,t1,t2);}

C_noret_decl(trf_7644)
static void C_ccall trf_7644(C_word c,C_word *av) C_noret;
static void C_ccall trf_7644(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7644(t0,t1,t2);}

C_noret_decl(trf_7742)
static void C_ccall trf_7742(C_word c,C_word *av) C_noret;
static void C_ccall trf_7742(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7742(t0,t1,t2);}

C_noret_decl(trf_7758)
static void C_ccall trf_7758(C_word c,C_word *av) C_noret;
static void C_ccall trf_7758(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7758(t0,t1,t2);}

C_noret_decl(trf_7805)
static void C_ccall trf_7805(C_word c,C_word *av) C_noret;
static void C_ccall trf_7805(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7805(t0,t1);}

C_noret_decl(trf_7811)
static void C_ccall trf_7811(C_word c,C_word *av) C_noret;
static void C_ccall trf_7811(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7811(t0,t1);}

C_noret_decl(trf_7872)
static void C_ccall trf_7872(C_word c,C_word *av) C_noret;
static void C_ccall trf_7872(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7872(t0,t1);}

C_noret_decl(trf_7877)
static void C_ccall trf_7877(C_word c,C_word *av) C_noret;
static void C_ccall trf_7877(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7877(t0,t1,t2);}

C_noret_decl(trf_8101)
static void C_ccall trf_8101(C_word c,C_word *av) C_noret;
static void C_ccall trf_8101(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8101(t0,t1,t2);}

C_noret_decl(trf_8305)
static void C_ccall trf_8305(C_word c,C_word *av) C_noret;
static void C_ccall trf_8305(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8305(t0,t1,t2);}

C_noret_decl(trf_8339)
static void C_ccall trf_8339(C_word c,C_word *av) C_noret;
static void C_ccall trf_8339(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8339(t0,t1,t2);}

C_noret_decl(trf_8373)
static void C_ccall trf_8373(C_word c,C_word *av) C_noret;
static void C_ccall trf_8373(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8373(t0,t1,t2);}

C_noret_decl(trf_8396)
static void C_ccall trf_8396(C_word c,C_word *av) C_noret;
static void C_ccall trf_8396(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8396(t0,t1,t2);}

C_noret_decl(trf_8419)
static void C_ccall trf_8419(C_word c,C_word *av) C_noret;
static void C_ccall trf_8419(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8419(t0,t1,t2);}

C_noret_decl(trf_8502)
static void C_ccall trf_8502(C_word c,C_word *av) C_noret;
static void C_ccall trf_8502(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8502(t0,t1,t2);}

C_noret_decl(trf_8700)
static void C_ccall trf_8700(C_word c,C_word *av) C_noret;
static void C_ccall trf_8700(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8700(t0,t1,t2);}

/* f9399 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f9399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9399,2,av);}
/* csi.scm:1093: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[89]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[89]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[83]+1);
tp(4,av2);}}

/* f9440 in k8161 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in ... */
static void C_ccall f9440(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f9440,2,av);}
/* csi.scm:145: chicken.base#print */
t2=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[314];
av2[3]=t1;
av2[4]=lf[315];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* f9458 in k8441 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in ... */
static void C_ccall f9458(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f9458,2,av);}
/* csi.scm:1044: chicken.base#case-sensitive */
t2=C_fast_retrieve(lf[324]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* f9462 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in ... */
static void C_ccall f9462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f9462,2,av);}
/* csi.scm:145: chicken.base#print */
t2=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[314];
av2[3]=t1;
av2[4]=lf[315];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k2514 */
static void C_ccall f_2516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2516,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k2517 in k2514 */
static void C_ccall f_2519(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2519,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_expand_toplevel(2,av2);}}

/* k2520 in k2517 in k2514 */
static void C_ccall f_2522(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2522,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2525,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_2525(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2525,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_file_toplevel(2,av2);}}

/* k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_2528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2528,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_internal_toplevel(2,av2);}}

/* k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_2531(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2531,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_pathname_toplevel(2,av2);}}

/* k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_2534(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2534,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_port_toplevel(2,av2);}}

/* k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_2537(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2537,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_posix_toplevel(2,av2);}}

/* k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_2540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2540,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2543,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_repl_toplevel(2,av2);}}

/* k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_2543(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2543,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_data_2dstructures_toplevel(2,av2);}}

/* k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_2546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,7)))){
C_save_and_reclaim((void *)f_2546,2,av);}
a=C_alloc(11);
t2=C_a_i_provide(&a,1,lf[0]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:44: ##sys#register-compiled-module */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[401]);
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=*((C_word*)lf[401]+1);
av2[1]=t3;
av2[2]=lf[402];
av2[3]=lf[402];
av2[4]=C_SCHEME_END_OF_LIST;
av2[5]=lf[403];
av2[6]=C_SCHEME_END_OF_LIST;
av2[7]=C_SCHEME_END_OF_LIST;
tp(8,av2);}}

/* k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_2549(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_2549,2,av);}
a=C_alloc(6);
t2=C_mutate(&lf[1] /* (set! chicken.csi#constant680 ...) */,lf[2]);
t3=C_set_block_item(lf[3] /* ##sys#repl-print-length-limit */,0,C_fix(2048));
t4=C_a_i_cons(&a,2,lf[4],C_fast_retrieve(lf[5]));
t5=C_mutate((C_word*)lf[5]+1 /* (set! ##sys#features ...) */,t4);
t6=C_set_block_item(lf[6] /* ##sys#notices-enabled */,0,C_SCHEME_TRUE);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:82: chicken.base#make-parameter */
t8=C_fast_retrieve(lf[400]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* loop in loop in k8275 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in ... */
static void C_fcall f_3047(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_3047,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3060,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* mini-srfi-1.scm:106: test */
t5=((C_word*)t0)[3];{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=t4;
((C_proc)C_fast_retrieve_proc(t5))(4,av2);}}}

/* k3058 in loop in loop in k8275 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in ... */
static void C_ccall f_3060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3060,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* mini-srfi-1.scm:107: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3047(t4,((C_word*)t0)[4],t3);}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3074,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* mini-srfi-1.scm:109: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_3047(t7,t4,t6);}}

/* k3072 in k3058 in loop in loop in k8275 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in ... */
static void C_ccall f_3074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3074,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k8275 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in ... */
static void C_fcall f_3122(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,0,3)))){
C_save_and_reclaim_args((void *)trf_3122,3,t0,t1,t2);}
a=C_alloc(17);
if(C_truep(C_i_nullp(t2))){
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3136,a[2]=t6,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3149,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=t4;
t10=((C_word*)t0)[3];
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3047,a[2]=t12,a[3]=t10,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_3047(t14,t8,t6);}}

/* k3134 in loop in k8275 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in ... */
static void C_ccall f_3136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3136,2,av);}
a=C_alloc(3);
t2=C_i_equalp(((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=(C_truep(t2)?((C_word*)t0)[4]:C_a_i_cons(&a,2,((C_word*)t0)[5],t1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3147 in loop in k8275 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in ... */
static void C_ccall f_3149(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3149,2,av);}
/* mini-srfi-1.scm:123: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3122(t2,((C_word*)t0)[3],t1);}

/* k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_3839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3839,2,av);}
a=C_alloc(3);
t2=C_mutate((C_word*)lf[7]+1 /* (set! chicken.csi#editor-command ...) */,t1);
t3=lf[8] /* chicken.csi#selected-frame */ =C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3844,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:86: chicken.process-context#get-environment-variable */
t5=C_fast_retrieve(lf[23]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[399];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_3844(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_3844,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3847,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_3847(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8741,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:87: chicken.process-context#get-environment-variable */
t4=C_fast_retrieve(lf[23]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[398];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_3847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_3847,2,t0,t1);}
a=C_alloc(7);
t2=C_mutate(&lf[9] /* (set! chicken.csi#default-editor ...) */,t1);
t3=C_mutate(&lf[10] /* (set! chicken.csi#dirseparator? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3887,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[12] /* (set! chicken.csi#chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3902,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[394]);
C_word av2[4];
av2[0]=*((C_word*)lf[394]+1);
av2[1]=t5;
av2[2]=C_fix(256);
av2[3]=C_make_character(32);
tp(4,av2);}}

/* k3851 in k8492 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in ... */
static void C_ccall f_3853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_3853,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3856,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3863,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,lf[354],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,C_retrieve2(lf[1],C_text("chicken.csi#constant680")),t4);
t6=C_a_i_cons(&a,2,lf[355],t5);
/* csi.scm:44: ##sys#print-to-string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[356]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[356]+1);
av2[1]=t3;
av2[2]=t6;
tp(3,av2);}}

/* k3854 in k3851 in k8492 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in ... */
static void C_ccall f_3856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3856,2,av);}
/* csi.scm:122: scheme#display */
t2=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[353];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3861 in k3851 in k8492 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in ... */
static void C_ccall f_3863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3863,2,av);}
/* csi.scm:117: scheme#display */
t2=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* chicken.csi#dirseparator? in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_3887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3887,3,av);}
if(C_truep(*((C_word*)lf[11]+1))){
t3=C_i_char_equalp(t2,C_make_character(92));
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=(C_truep(t3)?t3:C_i_char_equalp(t2,C_make_character(47)));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_i_char_equalp(t2,C_make_character(47));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.csi#chop-separator in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_3902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_3902,3,av);}
a=C_alloc(10);
t3=C_block_size(t2);
t4=C_a_i_fixnum_difference(&a,2,t3,C_fix(1));
t5=C_i_string_ref(t2,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3916,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_fixnum_greaterp(t4,C_fix(0)))){
/* csi.scm:159: dirseparator? */
t7=C_retrieve2(lf[10],C_text("chicken.csi#dirseparator\077"));{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
f_3887(3,av2);}}
else{
t7=t6;{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
f_3916(2,av2);}}}

/* k3914 in chicken.csi#chop-separator in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_3916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3916,2,av);}
if(C_truep(t1)){
/* csi.scm:160: substring */
t2=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(0);
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_3929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(49,c,3)))){
C_save_and_reclaim((void *)f_3929,2,av);}
a=C_alloc(49);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3948,tmp=(C_word)a,a+=2,tmp);
t4=C_mutate(&lf[17] /* (set! chicken.csi#lookup-script-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3999,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=C_a_i_vector(&a,32,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5);
t7=C_mutate(&lf[25] /* (set! chicken.csi#history-list ...) */,t6);
t8=lf[26] /* chicken.csi#history-count */ =C_fix(1);;
t9=C_fast_retrieve(lf[27]);
t10=C_mutate(&lf[28] /* (set! chicken.csi#history-add ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4106,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[30] /* (set! chicken.csi#history-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4205,tmp=(C_word)a,a+=2,tmp));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4272,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8719,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:247: chicken.repl#repl-prompt */
t14=C_fast_retrieve(lf[393]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}

/* addext in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_3948(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_3948,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3955,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:170: chicken.file#file-exists? */
t4=C_fast_retrieve(lf[14]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3953 in addext in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_3955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3955,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[15]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[15]+1);
av2[1]=t2;
av2[2]=t3;
av2[3]=lf[16];
tp(4,av2);}}}

/* k3956 in k3953 in addext in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_3958(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3958,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:173: chicken.file#file-exists? */
t4=C_fast_retrieve(lf[14]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3962 in k3956 in k3953 in addext in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_3964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3964,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=(C_truep(t1)?((C_word*)t0)[3]:C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_3977(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3977,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3990,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_subchar(((C_word*)t0)[4],t2);
/* csi.scm:178: proc */
t5=((C_word*)t0)[5];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}}

/* k3988 in loop in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_3990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3990,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm:179: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3977(t3,((C_word*)t0)[2],t2);}}

/* chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_3999(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_3999,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4003,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:181: chicken.process-context#get-environment-variable */
t4=C_fast_retrieve(lf[23]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[24];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_4003,2,av);}
a=C_alloc(7);
t2=t1;
t3=C_block_size(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=C_i_string_ref(((C_word*)t0)[2],C_fix(0));
/* csi.scm:183: dirseparator? */
t6=C_retrieve2(lf[10],C_text("chicken.csi#dirseparator\077"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
f_3887(3,av2);}}
else{
t4=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_4015,2,av);}
a=C_alloc(15);
if(C_truep(t1)){
/* csi.scm:183: addext */
f_3948(((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_retrieve2(lf[10],C_text("chicken.csi#dirseparator\077"));
t4=((C_word*)t0)[4];
t5=C_block_size(t4);
t6=t5;
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3977,a[2]=t6,a[3]=t8,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3977(t10,t2,C_fix(0));}}

/* k4022 in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_4024,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_truep(((C_word*)t0)[5])?C_i_foreign_block_argumentp(((C_word*)t0)[5]):C_SCHEME_FALSE);
t5=C_fix(256);
t6=stub712(t3,t4,t5);
/* csi.scm:168: ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=t6;
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:187: addext */
f_3948(t2,((C_word*)t0)[4]);}}

/* k4025 in k4022 in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_4027,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4038,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:186: chop-separator */
t4=C_retrieve2(lf[12],C_text("chicken.csi#chop-separator"));{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
f_3902(3,av2);}}

/* k4032 in k4025 in k4022 in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4034,2,av);}
/* csi.scm:186: addext */
f_3948(((C_word*)t0)[3],t1);}

/* k4036 in k4025 in k4022 in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4038(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4038,2,av);}
/* csi.scm:186: scheme#string-append */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[19];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4039 in k4022 in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4041(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4041,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[15]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[15]+1);
av2[1]=t2;
av2[2]=lf[22];
av2[3]=t3;
tp(4,av2);}}}

/* k4045 in k4039 in k4022 in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4047(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4047,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:190: ##sys#split-path */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[21]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[21]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}

/* k4052 in k4045 in k4039 in k4022 in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_4054(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_4054,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4056,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4056(t5,((C_word*)t0)[4],t1);}

/* loop in k4052 in k4045 in k4039 in k4022 in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_fcall f_4056(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_4056,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4066,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4083,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(0));
/* csi.scm:192: chop-separator */
t6=C_retrieve2(lf[12],C_text("chicken.csi#chop-separator"));{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
f_3902(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4064 in loop in k4052 in k4045 in k4039 in k4022 in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_4066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4066,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:193: addext */
f_3948(t2,t1);}

/* k4067 in k4064 in loop in k4052 in k4045 in k4039 in k4022 in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_4069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4069,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm:194: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4056(t3,((C_word*)t0)[2],t2);}}

/* k4081 in loop in k4052 in k4045 in k4039 in k4022 in k4013 in k4001 in chicken.csi#lookup-script-file in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_4083(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4083,2,av);}
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[15]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[15]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* chicken.csi#history-add in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_4106(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_4106,3,t0,t1,t2);}
a=C_alloc(7);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?*((C_word*)lf[29]+1):C_slot(t2,C_fix(0)));
t5=t4;
t6=C_block_size(C_retrieve2(lf[25],C_text("chicken.csi#history-list")));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4116,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(C_retrieve2(lf[26],C_text("chicken.csi#history-count")),t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4130,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_fixnum_times(C_fix(2),t6);
/* csi.scm:209: vector-resize */
t10=((C_word*)t0)[2];{
C_word av2[4];
av2[0]=t10;
av2[1]=t8;
av2[2]=C_retrieve2(lf[25],C_text("chicken.csi#history-list"));
av2[3]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
t8=t7;
f_4116(t8,C_SCHEME_UNDEFINED);}}

/* k4114 in chicken.csi#history-add in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_4116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,1)))){
C_save_and_reclaim_args((void *)trf_4116,2,t0,t1);}
t2=C_i_vector_set(C_retrieve2(lf[25],C_text("chicken.csi#history-list")),C_retrieve2(lf[26],C_text("chicken.csi#history-count")),((C_word*)t0)[2]);
t3=C_fixnum_plus(C_retrieve2(lf[26],C_text("chicken.csi#history-count")),C_fix(1));
t4=lf[26] /* chicken.csi#history-count */ =t3;;
t5=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t5;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k4128 in chicken.csi#history-add in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4130,2,av);}
t2=C_mutate(&lf[25] /* (set! chicken.csi#history-list ...) */,t1);
t3=((C_word*)t0)[2];
f_4116(t3,t2);}

/* doloop769 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_4161(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_4161,3,t0,t1,t2);}
a=C_alloc(6);
t3=t2;
t4=C_retrieve2(lf[26],C_text("chicken.csi#history-count"));
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_retrieve2(lf[26],C_text("chicken.csi#history-count"))))){
t5=C_SCHEME_UNDEFINED;
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=*((C_word*)lf[83]+1);
t6=*((C_word*)lf[83]+1);
t7=C_i_check_port_2(*((C_word*)lf[83]+1),C_fix(2),C_SCHEME_TRUE,lf[84]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4174,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:222: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[89]);
C_word av2[4];
av2[0]=*((C_word*)lf[89]+1);
av2[1]=t8;
av2[2]=C_make_character(35);
av2[3]=*((C_word*)lf[83]+1);
tp(4,av2);}}}

/* k4172 in doloop769 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_4174,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:222: ##sys#print */
t3=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4175 in k4172 in doloop769 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4177,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:222: ##sys#print */
t3=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[88];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4178 in k4175 in k4172 in doloop769 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_4180(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_4180,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4195,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:223: ##sys#with-print-length-limit */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[87]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[87]+1);
av2[1]=t2;
av2[2]=C_fix(80);
av2[3]=t3;
tp(4,av2);}}

/* k4181 in k4178 in k4175 in k4172 in doloop769 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_4183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4183,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:227: newline */
t3=*((C_word*)lf[85]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4184 in k4181 in k4178 in k4175 in k4172 in doloop769 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_4186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4186,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4161(t3,((C_word*)t0)[4],t2);}

/* a4194 in k4178 in k4175 in k4172 in doloop769 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_4195(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4195,2,av);}
t2=C_i_vector_ref(C_retrieve2(lf[25],C_text("chicken.csi#history-list")),((C_word*)t0)[2]);
/* csi.scm:226: ##sys#print */
t3=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=*((C_word*)lf[83]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* chicken.csi#history-ref in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_4205(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_4205,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4209,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:230: scheme#inexact->exact */
t4=*((C_word*)lf[33]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4207 in chicken.csi#history-ref in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4209,2,av);}
t2=C_fixnum_greaterp(t1,C_fix(0));
t3=(C_truep(t2)?C_fixnum_less_or_equal_p(t1,C_retrieve2(lf[26],C_text("chicken.csi#history-count"))):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_vector_ref(C_retrieve2(lf[25],C_text("chicken.csi#history-list")),t1);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* csi.scm:233: ##sys#error */
t4=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[32];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* ##sys#user-read-hook in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_4232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4232,4,av);}
a=C_alloc(3);
t4=C_i_char_equalp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4249,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_fixnum_difference(C_retrieve2(lf[26],C_text("chicken.csi#history-count")),C_fix(1));
/* csi.scm:242: history-ref */
f_4205(t6,t7);}
else{
/* csi.scm:243: old-hook */
t6=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}}

/* k4247 in ##sys#user-read-hook in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in ... */
static void C_ccall f_4249(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_4249,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[276],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##sys#sharp-number-hook in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_4261(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4261,4,av);}
a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4269,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:245: history-ref */
f_4205(t4,t3);}

/* k4267 in ##sys#sharp-number-hook in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in ... */
static void C_ccall f_4269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_4269,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[276],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4272(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,4)))){
C_save_and_reclaim((void *)f_4272,2,av);}
a=C_alloc(18);
t2=C_set_block_item(lf[34] /* ##sys#break-on-error */,0,C_SCHEME_FALSE);
t3=C_fast_retrieve(lf[35]);
t4=C_mutate((C_word*)lf[35]+1 /* (set! ##sys#read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4284,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=lf[38] /* chicken.csi#command-table */ =C_SCHEME_END_OF_LIST;;
t6=C_mutate((C_word*)lf[39]+1 /* (set! chicken.csi#toplevel-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4297,tmp=(C_word)a,a+=2,tmp));
t7=C_fast_retrieve(lf[41]);
t8=C_fast_retrieve(lf[42]);
t9=C_fast_retrieve(lf[43]);
t10=C_fast_retrieve(lf[44]);
t11=C_fast_retrieve(lf[45]);
t12=*((C_word*)lf[46]+1);
t13=C_mutate(&lf[47] /* (set! chicken.csi#csi-eval ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4347,a[2]=t11,a[3]=t10,a[4]=t9,a[5]=t8,a[6]=t7,a[7]=t12,tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4916,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8677,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:416: toplevel-command */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[39]);
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[39]+1);
av2[1]=t14;
av2[2]=lf[386];
av2[3]=t15;
av2[4]=lf[387];
tp(5,av2);}}

/* ##sys#read-prompt-hook in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4284,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4291,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_tty_forcedp();
if(C_truep(t3)){
if(C_truep(t3)){
/* csi.scm:269: old */
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t1;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
/* csi.scm:262: ##sys#tty-port? */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[36]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[36]+1);
av2[1]=t2;
av2[2]=*((C_word*)lf[37]+1);
tp(3,av2);}}}

/* k4289 in ##sys#read-prompt-hook in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4291(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4291,2,av);}
if(C_truep(t1)){
/* csi.scm:269: old */
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.csi#toplevel-command in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +12,c,2)))){
C_save_and_reclaim((void*)f_4297,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+12);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_check_symbol_2(t2,lf[40]);
t9=(C_truep(t7)?C_i_check_string_2(t7,lf[40]):C_SCHEME_UNDEFINED);
t10=C_i_assq(t2,C_retrieve2(lf[38],C_text("chicken.csi#command-table")));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4317,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t12=(
/* csi.scm:276: g834 */
  f_4317(C_a_i(&a,6),t11,t10)
);
t13=t1;{
C_word *av2=av;
av2[0]=t13;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t11=C_a_i_list3(&a,3,t2,t3,t7);
t12=C_a_i_cons(&a,2,t11,C_retrieve2(lf[38],C_text("chicken.csi#command-table")));
t13=C_mutate(&lf[38] /* (set! chicken.csi#command-table ...) */,t12);
t14=t1;{
C_word *av2=av;
av2[0]=t14;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}

/* g834 in chicken.csi#toplevel-command in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static C_word C_fcall f_4317(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
return(C_i_set_cdr(t1,t2));}

/* chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4347(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_4347,3,av);}
a=C_alloc(10);
if(C_truep(C_eofp(t2))){
/* csi.scm:295: chicken.base#exit */
t3=C_fast_retrieve(lf[48]);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4363,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(0));
t5=t3;
f_4363(t5,C_eqp(lf[110],t4));}
else{
t4=t3;
f_4363(t4,C_SCHEME_FALSE);}}}

/* k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_4363(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,3)))){
C_save_and_reclaim_args((void *)trf_4363,2,t0,t1);}
a=C_alloc(10);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_assq(t2,C_retrieve2(lf[38],C_text("chicken.csi#command-table")));
if(C_truep(t3)){
t4=((C_word*)t0)[3];
t5=C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4380,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:300: g867 */
t7=t5;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)C_fast_retrieve_proc(t7))(2,av2);}}
else{
t4=C_eqp(t2,lf[49]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:307: read */
t6=*((C_word*)lf[51]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_eqp(t2,lf[52]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4418,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:311: read */
t7=*((C_word*)lf[51]+1);{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_eqp(t2,lf[54]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:316: read */
t8=*((C_word*)lf[51]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(t2,lf[56]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:320: read */
t9=*((C_word*)lf[51]+1);{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=C_eqp(t2,lf[58]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4466,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:324: read */
t10=*((C_word*)lf[51]+1);{
C_word av2[2];
av2[0]=t10;
av2[1]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t9=C_eqp(t2,lf[59]);
if(C_truep(t9)){
/* csi.scm:329: report */
t10=C_retrieve2(lf[60],C_text("chicken.csi#report"));
f_5062(t10,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t10=C_eqp(t2,lf[61]);
if(C_truep(t10)){
/* csi.scm:330: chicken.repl#quit */
t11=C_fast_retrieve(lf[62]);{
C_word av2[2];
av2[0]=t11;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t11=C_eqp(t2,lf[63]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4538,a[2]=((C_word*)t0)[6],a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:332: read-line */
t14=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t14;
av2[1]=t13;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t12=C_eqp(t2,lf[65]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4594,a[2]=((C_word*)t0)[6],a[3]=t13,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:336: read-line */
t15=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t15;
av2[1]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t13=C_eqp(t2,lf[69]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4603,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:340: read */
t15=*((C_word*)lf[51]+1);{
C_word av2[2];
av2[0]=t15;
av2[1]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t14=C_eqp(t2,lf[73]);
if(C_truep(t14)){
if(C_truep(C_fast_retrieve(lf[74]))){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t16=C_a_i_list1(&a,1,C_fast_retrieve(lf[74]));
/* csi.scm:346: history-add */
t17=C_retrieve2(lf[28],C_text("chicken.csi#history-add"));
f_4106(t17,t15,t16);}
else{
t15=C_SCHEME_UNDEFINED;
t16=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t16;
av2[1]=t15;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}}
else{
t15=C_eqp(t2,lf[75]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4671,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4689,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4693,a[2]=t17,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:351: editor-command */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[7]);
C_word av2[2];
av2[0]=*((C_word*)lf[7]+1);
av2[1]=t18;
tp(2,av2);}}
else{
t16=C_eqp(t2,lf[80]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t18=*((C_word*)lf[29]+1);
/* csi.scm:215: scheme#vector-fill! */
t19=*((C_word*)lf[81]+1);{
C_word av2[4];
av2[0]=t19;
av2[1]=t17;
av2[2]=C_retrieve2(lf[25],C_text("chicken.csi#history-list"));
av2[3]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t19+1)))(4,av2);}}
else{
t17=C_eqp(t2,lf[82]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4161,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t22=((C_word*)t20)[1];
f_4161(t22,t18,C_fix(1));}
else{
t18=C_eqp(t2,lf[90]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:362: show-frameinfo */
f_6784(t19,C_retrieve2(lf[8],C_text("chicken.csi#selected-frame")));}
else{
t19=C_eqp(t2,lf[92]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4752,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:365: read */
t22=*((C_word*)lf[51]+1);{
C_word av2[2];
av2[0]=t22;
av2[1]=t21;
((C_proc)(void*)(*((C_word*)t22+1)))(2,av2);}}
else{
t20=C_eqp(t2,lf[96]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4765,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:368: read */
t22=*((C_word*)lf[51]+1);{
C_word av2[2];
av2[0]=t22;
av2[1]=t21;
((C_proc)(void*)(*((C_word*)t22+1)))(2,av2);}}
else{
t21=C_eqp(t2,lf[104]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:370: read-line */
t23=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t23;
av2[1]=t22;
((C_proc)(void*)(*((C_word*)t23+1)))(2,av2);}}
else{
t22=C_eqp(t2,lf[105]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4793,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:375: display */
t24=*((C_word*)lf[93]+1);{
C_word av2[3];
av2[0]=t24;
av2[1]=t23;
av2[2]=lf[108];
((C_proc)(void*)(*((C_word*)t24+1)))(3,av2);}}
else{
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:406: printf */
t24=*((C_word*)lf[76]+1);{
C_word av2[4];
av2[0]=t24;
av2[1]=t23;
av2[2]=lf[109];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t24+1)))(4,av2);}}}}}}}}}}}}}}}}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:409: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}}

/* k4378 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4380(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4380,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4393 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_4395,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4405,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4409,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:308: expand */
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4396 in k4393 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4398(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4398,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4403 in k4393 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4405(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4405,2,av);}
/* csi.scm:308: pretty-print */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4407 in k4393 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4409,2,av);}
/* csi.scm:308: chicken.syntax#strip-syntax */
t2=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4416 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4418,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:312: eval */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4419 in k4416 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4421,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:313: pretty-print */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4422 in k4419 in k4416 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4424,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4434 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4436(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4436,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:317: eval */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4437 in k4434 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4439,2,av);}
/* csi.scm:318: describe */
t2=C_retrieve2(lf[55],C_text("chicken.csi#describe"));
f_5392(t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4449 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4451,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:321: eval */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4452 in k4449 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4454,2,av);}
/* csi.scm:322: dump */
f_6431(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4464 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4466(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4466,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4469,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:325: read */
t4=*((C_word*)lf[51]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4467 in k4464 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4469,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:326: eval */
t4=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4470 in k4467 in k4464 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4472,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:327: eval */
t4=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4473 in k4470 in k4467 in k4464 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_4475(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4475,2,av);}
a=C_alloc(3);
/* csi.scm:328: dump */
f_6431(((C_word*)t0)[2],((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* k4503 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_4505,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4513,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4513(t6,t2,t1);}

/* k4506 in k4503 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4508,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop892 in k4503 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_4513(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_4513,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4523,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:333: g893 */
t5=*((C_word*)lf[64]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4521 in for-each-loop892 in k4503 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4523,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4513(t3,((C_word*)t0)[4],t2);}

/* k4536 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4538(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4538,2,av);}
/* csi.scm:332: string-split */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4545 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_4547,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4564,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4569,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4569(t7,t3,t1);}

/* g912 in k4545 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_4548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,4)))){
C_save_and_reclaim_args((void *)trf_4548,3,t0,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4554,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:337: g927 */
t4=((C_word*)t0)[3];{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[68];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* a4553 in g912 in k4545 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4554(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4554,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4558,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:337: pretty-print */
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4556 in a4553 in g912 in k4545 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_4558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4558,2,av);}
/* csi.scm:337: chicken.base#print* */
t2=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[67];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4562 in k4545 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4564(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4564,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop911 in k4545 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_4569(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_4569,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4579,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:337: g912 */
t5=((C_word*)t0)[3];
f_4548(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4577 in for-each-loop911 in k4545 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4579(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4579,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4569(t3,((C_word*)t0)[4],t2);}

/* k4592 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4594,2,av);}
/* csi.scm:336: string-split */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4601 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4603(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_4603,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4608,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:341: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}

/* a4607 in k4601 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4608,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4612,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:341: ##sys#start-timer */
t3=*((C_word*)lf[72]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4610 in a4607 in k4601 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4612(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4612,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4623,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:341: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a4616 in k4610 in a4607 in k4601 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_4617(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4617,2,av);}
/* csi.scm:341: eval */
t2=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a4622 in k4610 in a4607 in k4601 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_4623(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +7,c,2)))){
C_save_and_reclaim((void*)f_4623,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+7);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4627,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4634,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:341: ##sys#stop-timer */
t5=*((C_word*)lf[71]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k4625 in a4622 in k4610 in a4607 in k4601 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_4627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4627,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
C_apply_values(3,av2);}}

/* k4632 in a4622 in k4610 in a4607 in k4601 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_4634(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4634,2,av);}
/* csi.scm:341: ##sys#display-times */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[70]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[70]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* a4635 in k4601 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4636(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +5,c,2)))){
C_save_and_reclaim((void*)f_4636,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+5);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4640,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:342: history-add */
t4=C_retrieve2(lf[28],C_text("chicken.csi#history-add"));
f_4106(t4,t3,t2);}

/* k4638 in a4635 in k4601 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4640,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
C_apply(4,av2);}}

/* k4653 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4655(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4655,2,av);}
/* csi.scm:347: describe */
t2=C_retrieve2(lf[55],C_text("chicken.csi#describe"));
f_5392(t2,((C_word*)t0)[2],C_fast_retrieve(lf[74]),C_SCHEME_END_OF_LIST);}

/* k4669 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4671,2,av);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(C_i_not(t2))){
/* csi.scm:354: printf */
t3=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[77];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4687 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4689(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4689,2,av);}
/* csi.scm:349: chicken.process#system */
t2=C_fast_retrieve(lf[78]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4691 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4693,2,av);}
a=C_alloc(4);
t2=(C_truep(t1)?t1:C_retrieve2(lf[9],C_text("chicken.csi#default-editor")));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:352: read-line */
t5=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k4698 in k4691 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4700,2,av);}
/* csi.scm:350: scheme#string-append */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[79];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4707 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4709(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4709,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4719 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4721(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4721,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4731 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4733,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4743 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4745,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4750 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4752,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_numberp(t3);
t5=C_i_not(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7069,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_7069(t7,t5);}
else{
t7=C_i_not(C_fast_retrieve(lf[95]));
if(C_truep(t7)){
t8=t6;
f_7069(t8,t7);}
else{
t8=C_fixnum_lessp(t3,C_fix(0));
if(C_truep(t8)){
t9=t6;
f_7069(t9,t8);}
else{
t9=C_i_length(C_fast_retrieve(lf[95]));
t10=t6;
f_7069(t10,C_fixnum_greater_or_equal_p(t3,t9));}}}}

/* k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_4765,2,av);}
a=C_alloc(7);
t2=((C_word*)t0)[2];
t3=C_fast_retrieve(lf[95]);
t4=(C_truep(C_fast_retrieve(lf[95]))?C_fast_retrieve(lf[95]):C_SCHEME_END_OF_LIST);
t5=t4;
t6=C_i_length(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7126,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_symbolp(t1))){
t8=t7;
f_7126(t8,C_slot(t1,C_fix(1)));}
else{
if(C_truep(C_i_stringp(t1))){
t8=t7;
f_7126(t8,t1);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7353,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:866: display */
t9=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[103];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}}

/* k4772 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4774(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4774,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:371: chicken.process#system */
t3=C_fast_retrieve(lf[78]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4775 in k4772 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4777(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_4777,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4780,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list1(&a,1,t2);
/* csi.scm:372: history-add */
t5=C_retrieve2(lf[28],C_text("chicken.csi#history-add"));
f_4106(t5,t3,t4);}

/* k4778 in k4775 in k4772 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4780,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4791 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_4793,2,av);}
a=C_alloc(8);
t2=C_retrieve2(lf[38],C_text("chicken.csi#command-table"));
t3=C_i_check_list_2(C_retrieve2(lf[38],C_text("chicken.csi#command-table")),lf[100]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4820,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4820(t8,t4,C_retrieve2(lf[38],C_text("chicken.csi#command-table")));}

/* k4813 in k4791 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4815,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop958 in k4791 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_4820(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_4820,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4830,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_caddr(t4);
if(C_truep(t5)){
/* csi.scm:401: chicken.base#print */
t6=*((C_word*)lf[106]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=C_make_character(32);
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t6=C_u_i_car(t4);
/* csi.scm:402: chicken.base#print */
t7=*((C_word*)lf[106]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t3;
av2[2]=lf[107];
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4828 in for-each-loop958 in k4791 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4830,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4820(t3,((C_word*)t0)[4],t2);}

/* k4842 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4844(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4844,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a4889 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4890,2,av);}
/* csi.scm:409: eval */
t2=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a4895 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +5,c,2)))){
C_save_and_reclaim((void*)f_4896,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+5);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4900,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:410: history-add */
t4=C_retrieve2(lf[28],C_text("chicken.csi#history-add"));
f_4106(t4,t3,t2);}

/* k4898 in a4895 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4900(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4900,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
C_apply(4,av2);}}

/* k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_4916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_4916,2,av);}
a=C_alloc(9);
t2=C_fast_retrieve(lf[111]);
t3=C_fast_retrieve(lf[112]);
t4=C_fast_retrieve(lf[113]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5061,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[379]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_PREFIX);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_4922(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_4922,2,av);}
a=C_alloc(14);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4945,a[2]=t5,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4990,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:443: scheme#call-with-current-continuation */
t9=*((C_word*)lf[376]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k4934 in map-loop998 in k4946 in k4943 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_4936(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_4936,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4939,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:441: scheme#write */
t4=*((C_word*)lf[179]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k4937 in k4934 in map-loop998 in k4946 in k4943 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_4939(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4939,2,av);}
/* csi.scm:442: chicken.base#get-output-string */
t2=C_fast_retrieve(lf[371]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4943 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_4945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4945,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:443: g1021 */
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}

/* k4946 in k4943 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_4948(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_4948,2,av);}
a=C_alloc(7);
t2=C_i_check_list_2(t1,lf[138]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4956,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4956(t6,((C_word*)t0)[4],t1);}

/* map-loop998 in k4946 in k4943 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_fcall f_4956(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_4956,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
if(C_truep(C_i_stringp(t6))){
t7=t5;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4936,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:440: chicken.base#open-output-string */
t8=C_fast_retrieve(lf[372]);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4979 in map-loop998 in k4946 in k4943 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_4981(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4981,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4956(t6,((C_word*)t0)[5],t5);}

/* a4989 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_4990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_4990,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4996,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:443: chicken.condition#with-exception-handler */
t5=C_fast_retrieve(lf[375]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a4995 in a4989 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_4996(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4996,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5002,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:443: k1018 */
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* a5001 in a4995 in a4989 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_5002(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5002,2,av);}
/* csi.scm:443: ##sys#error */
t2=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[373];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a5007 in a4989 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_5008(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_5008,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5014,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5047,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:443: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a5013 in a5007 in a4989 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_5014(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5014,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:444: scheme#read */
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5020 in a5013 in a5007 in a4989 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_5022(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5022,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5024,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5024(t5,((C_word*)t0)[3],t1,C_SCHEME_END_OF_LIST);}

/* doloop1025 in k5020 in a5013 in a5007 in a4989 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_fcall f_5024(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_5024,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_eofp(t2))){
/* csi.scm:446: scheme#reverse */
t4=*((C_word*)lf[374]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5041,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:444: scheme#read */
t5=*((C_word*)lf[51]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k5039 in doloop1025 in k5020 in a5013 in a5007 in a4989 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_5041(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_5041,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_5024(t3,((C_word*)t0)[5],t1,t2);}

/* a5046 in a5007 in a4989 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_5047(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2)))){
C_save_and_reclaim((void*)f_5047,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5053,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:443: k1018 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* a5052 in a5046 in a5007 in a4989 in k4920 in k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_5053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5053,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_5061(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_5061,2,av);}
a=C_alloc(9);
t2=t1;
t3=C_mutate(&lf[60] /* (set! chicken.csi#report ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5062,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t4=C_mutate(&lf[144] /* (set! chicken.csi#bytevector-data ...) */,lf[145]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:557: scheme#make-vector */
t6=*((C_word*)lf[378]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_fix(37);
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_5062(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_5062,3,t0,t1,t2);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=t3;
f_5070(t5,C_u_i_car(t4));}
else{
t4=t3;
f_5070(t4,*((C_word*)lf[83]+1));}}

/* k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_5070(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_5070,2,t0,t1);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:459: with-output-to-port */
t3=((C_word*)t0)[5];{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[6];
av2[2]=t1;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_5072(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5072,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5076,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:461: chicken.gc#gc */
t3=C_fast_retrieve(lf[143]);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_5076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5076,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:462: ##sys#symbol-table-info */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[142]);
C_word *av2=av;
av2[0]=*((C_word*)lf[142]+1);
av2[1]=t2;
tp(2,av2);}}

/* k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_5079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_5079,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5082,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:463: chicken.gc#memory-statistics */
t4=C_fast_retrieve(lf[141]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_5082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_5082,2,av);}
a=C_alloc(14);
t2=t1;
t3=C_mk_bool(C_interrupts_enabled);
t4=C_mk_bool(C_heap_size_is_fixed);
t5=C_mk_bool(C_STACK_GROWS_DOWNWARD);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5084,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t4,a[7]=t5,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=t6,a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* csi.scm:468: printf */
t8=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[140];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* shorten in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_fcall f_5084(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_5084,2,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5092,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_fixnum_times(t2,C_fix(100));
/* csi.scm:467: scheme#truncate */
t5=*((C_word*)lf[114]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5090 in shorten in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_5092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5092,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_fixnum_divide(t1,C_fix(100));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_5100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,3)))){
C_save_and_reclaim((void *)f_5100,2,av);}
a=C_alloc(28);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_fast_retrieve(lf[137]);
t8=C_fast_retrieve(lf[5]);
t9=C_i_check_list_2(C_fast_retrieve(lf[5]),lf[138]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5278,a[2]=((C_word*)t0)[11],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5280,a[2]=t5,a[3]=t12,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_5280(t14,t10,C_fast_retrieve(lf[5]));}

/* k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_5103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,3)))){
C_save_and_reclaim((void *)f_5103,2,av);}
a=C_alloc(22);
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5104,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_check_list_2(t1,lf[100]);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5247,a[2]=t8,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_5247(t10,t6,t1);}

/* g1088 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_fcall f_5104(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_5104,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5108,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:473: printf */
t4=*((C_word*)lf[76]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[117];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5106 in g1088 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_5108(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(70,c,2)))){
C_save_and_reclaim((void *)f_5108,2,av);}
a=C_alloc(70);
t2=C_i_string_length(((C_word*)t0)[2]);
t3=C_a_i_fixnum_difference(&a,2,C_fix(16),t2);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)((C_word*)t0)[3])[1];
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_s_a_i_plus(&a,2,t5,C_fix(1)));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t8=((C_word*)t4)[1];
if(C_truep(C_fixnum_less_or_equal_p(t8,C_fix(0)))){
t9=((C_word*)((C_word*)t0)[3])[1];
t10=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_s_a_i_plus(&a,2,t9,C_fix(1)));
t11=C_fixnum_plus(((C_word*)t4)[1],C_fix(18));
t12=C_set_block_item(t4,0,t11);
t13=t7;
f_5118(t13,t12);}
else{
t9=t7;
f_5118(t9,C_SCHEME_UNDEFINED);}}

/* k5116 in k5106 in g1088 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_fcall f_5118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_5118,2,t0,t1);}
a=C_alloc(4);
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(C_fixnum_greater_or_equal_p(t2,C_fix(3)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:481: scheme#display */
t4=*((C_word*)lf[93]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[115];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5135,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:484: scheme#make-string */
t4=*((C_word*)lf[116]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k5125 in k5116 in k5106 in g1088 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_ccall f_5127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5127,2,av);}
t2=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5133 in k5116 in k5106 in g1088 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_ccall f_5135(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5135,2,av);}
/* csi.scm:484: scheme#display */
t2=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_5150(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,2)))){
C_save_and_reclaim((void *)f_5150,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5166,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* csi.scm:502: chicken.platform#machine-type */
t4=C_fast_retrieve(lf[136]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5151 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_5153(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_5153,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:521: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[89]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[89]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[83]+1);
tp(4,av2);}}

/* k5154 in k5151 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_5156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5156,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5159,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* csi.scm:522: scheme#display */
t3=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[118];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5157 in k5154 in k5151 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_ccall f_5159(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5159,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_5166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_5166,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm:503: chicken.platform#feature? */
t4=C_fast_retrieve(lf[134]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[135];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5172 in k5243 in k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_ccall f_5174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_5174,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* csi.scm:505: chicken.platform#software-version */
t4=C_fast_retrieve(lf[132]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5176 in k5172 in k5243 in k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_ccall f_5178(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,2)))){
C_save_and_reclaim((void *)f_5178,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* csi.scm:506: chicken.platform#build-platform */
t4=C_fast_retrieve(lf[131]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5180 in k5176 in k5172 in k5243 in k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in ... */
static void C_ccall f_5182(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_5182,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* csi.scm:508: chicken.platform#installation-repository */
t4=C_fast_retrieve(lf[130]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5184 in k5180 in k5176 in k5172 in k5243 in k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in ... */
static void C_ccall f_5186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_5186,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* csi.scm:509: chicken.platform#repository-path */
t4=C_fast_retrieve(lf[129]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5188 in k5184 in k5180 in k5176 in k5172 in k5243 in k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in ... */
static void C_ccall f_5190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,2)))){
C_save_and_reclaim((void *)f_5190,2,av);}
a=C_alloc(20);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t2,a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5242,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:511: chicken.base#keyword-style */
t5=C_fast_retrieve(lf[128]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k5192 in k5188 in k5184 in k5180 in k5176 in k5172 in k5243 in k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in ... */
static void C_ccall f_5194(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,2)))){
C_save_and_reclaim((void *)f_5194,2,av);}
a=C_alloc(18);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t2,a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* csi.scm:512: shorten */
f_5084(t3,t4);}

/* k5196 in k5192 in k5188 in k5184 in k5180 in k5176 in k5172 in k5243 in k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in ... */
static void C_ccall f_5198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,2)))){
C_save_and_reclaim((void *)f_5198,2,av);}
a=C_alloc(18);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t2,a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
/* csi.scm:513: shorten */
f_5084(t3,t4);}

/* k5200 in k5196 in k5192 in k5188 in k5184 in k5180 in k5176 in k5172 in k5243 in k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in ... */
static void C_ccall f_5202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,2)))){
C_save_and_reclaim((void *)f_5202,2,av);}
a=C_alloc(20);
t2=t1;
t3=C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
t4=t3;
t5=C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
t6=t5;
t7=(C_truep(((C_word*)t0)[4])?lf[121]:lf[122]);
t8=t7;
t9=C_i_vector_ref(((C_word*)t0)[3],C_fix(1));
t10=t9;
t11=C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t12=t11;
t13=(C_truep(((C_word*)t0)[5])?lf[123]:lf[124]);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_5230,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=t2,a[14]=t4,a[15]=t6,a[16]=t8,a[17]=t10,a[18]=t12,a[19]=t14,tmp=(C_word)a,a+=20,tmp);
/* csi.scm:520: argv */
t16=((C_word*)t0)[17];{
C_word *av2=av;
av2[0]=t16;
av2[1]=t15;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}

/* k5228 in k5200 in k5196 in k5192 in k5188 in k5184 in k5180 in k5176 in k5172 in k5243 in k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in ... */
static void C_ccall f_5230(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,21)))){
C_save_and_reclaim((void *)f_5230,2,av);}
/* csi.scm:486: printf */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 22) {
  av2=av;
} else {
  av2=C_alloc(22);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[125];
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
av2[5]=((C_word*)t0)[5];
av2[6]=((C_word*)t0)[6];
av2[7]=((C_word*)t0)[7];
av2[8]=((C_word*)t0)[8];
av2[9]=((C_word*)t0)[9];
av2[10]=((C_word*)t0)[10];
av2[11]=C_fast_retrieve(lf[126]);
av2[12]=((C_word*)t0)[11];
av2[13]=((C_word*)t0)[12];
av2[14]=((C_word*)t0)[13];
av2[15]=((C_word*)t0)[14];
av2[16]=((C_word*)t0)[15];
av2[17]=((C_word*)t0)[16];
av2[18]=((C_word*)t0)[17];
av2[19]=((C_word*)t0)[18];
av2[20]=((C_word*)t0)[19];
av2[21]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(22,av2);}}

/* k5240 in k5188 in k5184 in k5180 in k5176 in k5172 in k5243 in k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in ... */
static void C_ccall f_5242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5242,2,av);}
/* csi.scm:511: scheme#symbol->string */
t2=*((C_word*)lf[127]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5243 in k5164 in k5148 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_5245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_5245,2,av);}
a=C_alloc(12);
t2=(C_truep(t1)?lf[119]:lf[120]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* csi.scm:504: chicken.platform#software-type */
t5=C_fast_retrieve(lf[133]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* for-each-loop1087 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_fcall f_5247(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_5247,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5257,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:471: g1088 */
t5=((C_word*)t0)[3];
f_5104(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5255 in for-each-loop1087 in k5101 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_5257(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5257,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5247(t3,((C_word*)t0)[4],t2);}

/* k5276 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_5278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5278,2,av);}
/* csi.scm:469: sort */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=*((C_word*)lf[139]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop1061 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_fcall f_5280(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_5280,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5305,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:469: g1067 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5303 in map-loop1061 in k5098 in k5080 in k5077 in k5074 in a5071 in k5068 in chicken.csi#report in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_5305(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5305,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5280(t6,((C_word*)t0)[5],t5);}

/* lp in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static C_word C_fcall f_5325(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_pairp(t1))){
t3=t1;
t4=C_u_i_cdr(t3);
if(C_truep(C_i_pairp(t4))){
t5=C_u_i_cdr(t4);
t6=C_i_cdr(t2);
t7=C_eqp(t5,t6);
if(C_truep(t7)){
return(t7);}
else{
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}

/* lp in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static C_word C_fcall f_5360(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_overflow_check;
loop:{}
t2=C_i_pairp(t1);
if(C_truep(C_i_not(t2))){
return(C_SCHEME_FALSE);}
else{
t3=C_i_car(t1);
t4=C_eqp(t1,t3);
if(C_truep(t4)){
return(t4);}
else{
t5=t1;
t6=C_u_i_cdr(t5);
t8=t6;
t1=t8;
goto loop;}}}

/* k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_5390(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,6)))){
C_save_and_reclaim((void *)f_5390,2,av);}
a=C_alloc(28);
t2=C_mutate(&lf[146] /* (set! chicken.csi#describer-table ...) */,t1);
t3=*((C_word*)lf[147]+1);
t4=*((C_word*)lf[148]+1);
t5=*((C_word*)lf[149]+1);
t6=C_mutate(&lf[55] /* (set! chicken.csi#describe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5392,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t7=C_mutate((C_word*)lf[239]+1 /* (set! chicken.csi#set-describer! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6422,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[57] /* (set! chicken.csi#dump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6431,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[214] /* (set! chicken.csi#hexdump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6579,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[91] /* (set! chicken.csi#show-frameinfo ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6784,tmp=(C_word)a,a+=2,tmp));
t11=C_establish_signal_handler(C_fix((C_word)SIGINT),C_fix((C_word)SIGINT));
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8671,tmp=(C_word)a,a+=2,tmp);
t13=C_i_setslot(C_fast_retrieve(lf[258]),C_fix((C_word)SIGINT),t12);
t14=C_mutate(&lf[259] /* (set! chicken.csi#member* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7358,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[260] /* (set! chicken.csi#canonicalize-args ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7413,tmp=(C_word)a,a+=2,tmp));
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8663,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7592,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8657,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:974: chicken.process-context#get-environment-variable */
t20=C_fast_retrieve(lf[23]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t20;
av2[1]=t19;
av2[2]=lf[377];
((C_proc)(void*)(*((C_word*)t20+1)))(3,av2);}}

/* chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_5392(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,0,6)))){
C_save_and_reclaim_args((void *)trf_5392,4,t0,t1,t2,t3);}
a=C_alloc(17);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[83]+1):C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5398,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5530,a[2]=t1,a[3]=t2,a[4]=t6,a[5]=t7,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_permanentp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6414,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:591: ##sys#block-address */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[238]);
C_word av2[3];
av2[0]=*((C_word*)lf[238]+1);
av2[1]=t9;
av2[2]=t2;
tp(3,av2);}}
else{
t9=t8;{
C_word av2[2];
av2[0]=t9;
av2[1]=C_SCHEME_UNDEFINED;
f_5530(2,av2);}}}

/* descseq in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_5398(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_5398,6,av);}
a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5527,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm:568: plen */
t7=t3;{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}

/* k5403 in k5525 in descseq in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_5405(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_5405,2,av);}
a=C_alloc(10);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5410(t5,((C_word*)t0)[7],C_fix(0));}

/* loop1 in k5403 in k5525 in descseq in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_fcall f_5410(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,4)))){
C_save_and_reclaim_args((void *)trf_5410,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=C_fixnum_difference(((C_word*)t0)[2],t2);
/* csi.scm:573: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[151];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5433,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t5=C_fixnum_plus(((C_word*)t0)[4],t2);
/* csi.scm:575: pref */
t6=((C_word*)t0)[6];{
C_word av2[4];
av2[0]=t6;
av2[1]=t4;
av2[2]=((C_word*)t0)[7];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}}}

/* k5431 in loop1 in k5403 in k5525 in descseq in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_5433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_5433,2,av);}
a=C_alloc(12);
t2=t1;
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[3],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t6,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_5442(t8,((C_word*)t0)[9],C_fix(1),t4);}

/* loop2 in k5431 in loop1 in k5403 in k5525 in descseq in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_fcall f_5442(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,3)))){
C_save_and_reclaim_args((void *)trf_5442,4,t0,t1,t2,t3);}
a=C_alloc(12);
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5452,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:578: ##sys#with-print-length-limit */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[87]);
C_word av2[4];
av2[0]=*((C_word*)lf[87]+1);
av2[1]=t4;
av2[2]=C_fix(1000);
av2[3]=t5;
tp(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5512,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:588: pref */
t5=((C_word*)t0)[8];{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[9];
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t5))(4,av2);}}}

/* k5450 in loop2 in k5431 in loop1 in k5403 in k5525 in descseq in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_5452(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_5452,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[3],C_fix(1)))){
t3=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=C_eqp(((C_word*)t0)[3],C_fix(2));
if(C_truep(t4)){
/* csi.scm:583: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[152];
av2[4]=t3;
av2[5]=lf[153];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
/* csi.scm:583: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[152];
av2[4]=t3;
av2[5]=lf[154];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}}
else{
/* csi.scm:586: scheme#newline */
t3=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k5453 in k5450 in loop2 in k5431 in loop1 in k5403 in k5525 in descseq in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_5455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5455,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],((C_word*)t0)[3]);
/* csi.scm:587: loop1 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5410(t3,((C_word*)t0)[5],t2);}

/* a5483 in loop2 in k5431 in loop1 in k5403 in k5525 in descseq in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_5484(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_5484,2,av);}
/* csi.scm:581: fprintf */
t2=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[155];
av2[4]=((C_word*)t0)[3];
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k5510 in loop2 in k5431 in loop1 in k5403 in k5525 in descseq in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_5512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5512,2,av);}
t2=C_eqp(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* csi.scm:588: loop2 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_5442(t5,((C_word*)t0)[6],t3,t4);}
else{
/* csi.scm:589: loop2 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5442(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[7]);}}

/* k5525 in descseq in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_5527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,5)))){
C_save_and_reclaim((void *)f_5527,2,av);}
a=C_alloc(8);
t2=C_fixnum_difference(t1,((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5405,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
/* csi.scm:569: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[156];
av2[4]=((C_word*)t0)[7];
av2[5]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
t5=t4;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_5405(2,av2);}}}

/* k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_5530(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,7)))){
C_save_and_reclaim((void *)f_5530,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_charp(((C_word*)t0)[3]))){
t3=C_fix(C_character_code(((C_word*)t0)[3]));
/* csi.scm:594: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[157];
av2[4]=((C_word*)t0)[3];
av2[5]=t3;
av2[6]=t3;
av2[7]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(8,av2);}}
else{
switch(((C_word*)t0)[3]){
case C_SCHEME_TRUE:
/* csi.scm:595: fprintf */
t3=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[158];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}
case C_SCHEME_FALSE:
/* csi.scm:596: fprintf */
t3=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[159];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}
default:
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
/* csi.scm:597: fprintf */
t3=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[160];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
if(C_truep(C_eofp(((C_word*)t0)[3]))){
/* csi.scm:598: fprintf */
t3=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[161];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=*((C_word*)lf[29]+1);
t4=C_eqp(*((C_word*)lf[29]+1),((C_word*)t0)[3]);
if(C_truep(t4)){
/* csi.scm:599: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[162];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
if(C_truep(C_fixnump(((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5599,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:601: fprintf */
t6=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[164];
av2[4]=((C_word*)t0)[3];
av2[5]=((C_word*)t0)[3];
av2[6]=((C_word*)t0)[3];
av2[7]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(8,av2);}}
else{
if(C_truep(C_i_bignump(((C_word*)t0)[3]))){
/* csi.scm:607: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[165];
av2[4]=((C_word*)t0)[3];
av2[5]=((C_word*)t0)[3];
av2[6]=((C_word*)t0)[3];
av2[7]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(8,av2);}}
else{
if(C_truep(C_unboundvaluep(((C_word*)t0)[3]))){
/* csi.scm:610: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[166];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
if(C_truep(C_i_flonump(((C_word*)t0)[3]))){
/* csi.scm:611: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[167];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
if(C_truep(C_i_ratnump(((C_word*)t0)[3]))){
/* csi.scm:612: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[168];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
if(C_truep(C_i_cplxnump(((C_word*)t0)[3]))){
if(C_truep(C_i_exactp(((C_word*)t0)[3]))){
/* csi.scm:613: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[169];
av2[4]=lf[170];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
/* csi.scm:613: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[169];
av2[4]=lf[171];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}}
else{
if(C_truep(C_i_numberp(((C_word*)t0)[3]))){
/* csi.scm:615: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[172];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
/* csi.scm:616: descseq */
t5=((C_word*)t0)[5];{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[173];
av2[3]=*((C_word*)lf[174]+1);
av2[4]=((C_word*)t0)[6];
av2[5]=C_fix(0);
f_5398(6,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
/* csi.scm:617: descseq */
t5=((C_word*)t0)[5];{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[175];
av2[3]=*((C_word*)lf[174]+1);
av2[4]=*((C_word*)lf[176]+1);
av2[5]=C_fix(0);
f_5398(6,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5696,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* csi.scm:618: chicken.keyword#keyword? */
t6=C_fast_retrieve(lf[236]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}}}}}}}}}}}}}

/* k5531 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_5533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5533,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5597 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_5599(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_5599,2,av);}
a=C_alloc(3);
t2=C_make_character(C_unfix(((C_word*)t0)[2]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5605,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[2],C_fix(65536)))){
/* csi.scm:604: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[163];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
/* csi.scm:605: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[89]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[89]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[83]+1);
tp(4,av2);}}}

/* k5603 in k5597 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_5605(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5605,2,av);}
/* csi.scm:605: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[89]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[89]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[83]+1);
tp(4,av2);}}

/* k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_5696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_5696,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:620: ##sys#symbol->string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[178]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[178]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5712,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5783,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:622: ##sys#symbol-has-toplevel-binding? */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[187]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[187]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}
else{
t2=((C_word*)t0)[4];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5325,tmp=(C_word)a,a+=2,tmp);
t4=(
  f_5325(t2,t2)
);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5795,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_5795(t6,t4);}
else{
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5360,tmp=(C_word)a,a+=2,tmp);
t8=t5;
f_5795(t8,(
  f_5360(t6)
));}}}}

/* k5701 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_5703(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5703,2,av);}
/* csi.scm:619: fprintf */
t2=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[177];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5710 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_5712(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_5712,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5780,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:625: ##sys#interned-symbol? */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[185]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[185]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}

/* k5713 in k5710 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_5715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_5715,2,av);}
a=C_alloc(5);
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=t2;
if(C_truep(C_i_nullp(t3))){
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5727,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:629: scheme#display */
t5=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[181];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k5725 in k5713 in k5710 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_5727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_5727,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5732,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5732(t5,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* doloop1200 in k5725 in k5713 in k5710 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_fcall f_5732(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_5732,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5742,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
/* csi.scm:632: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[180];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* k5740 in doloop1200 in k5725 in k5713 in k5710 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_5742(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_5742,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:633: ##sys#with-print-length-limit */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[87]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[87]+1);
av2[1]=t2;
av2[2]=C_fix(1000);
av2[3]=t3;
tp(4,av2);}}

/* k5743 in k5740 in doloop1200 in k5725 in k5713 in k5710 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_5745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5745,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:637: scheme#newline */
t3=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5746 in k5743 in k5740 in doloop1200 in k5725 in k5713 in k5710 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_5748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5748,2,av);}
t2=C_i_cddr(((C_word*)t0)[2]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5732(t3,((C_word*)t0)[4],t2);}

/* a5756 in k5740 in doloop1200 in k5725 in k5713 in k5710 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_5757(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5757,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:636: scheme#write */
t3=*((C_word*)lf[179]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5775 in k5778 in k5710 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_5777(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_5777,2,av);}
/* csi.scm:624: fprintf */
t2=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[184];
av2[4]=((C_word*)t0)[4];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k5778 in k5710 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_5780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5780,2,av);}
a=C_alloc(5);
t2=(C_truep(t1)?lf[182]:lf[183]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:626: ##sys#symbol->string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[178]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[178]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}

/* k5781 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_5783(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5783,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_5712(2,av2);}}
else{
/* csi.scm:623: scheme#display */
t2=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[186];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_fcall f_5795(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,5)))){
C_save_and_reclaim_args((void *)trf_5795,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:639: fprintf */
t3=*((C_word*)lf[150]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[191];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
/* csi.scm:649: descseq */
t2=((C_word*)t0)[5];{
C_word av2[6];
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[192];
av2[3]=((C_word*)t0)[6];
av2[4]=((C_word*)t0)[7];
av2[5]=C_fix(0);
f_5398(6,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* csi.scm:650: fprintf */
t6=*((C_word*)lf[150]+1);{
C_word av2[6];
av2[0]=t6;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[193];
av2[4]=t3;
av2[5]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}
else{
if(C_truep(C_i_closurep(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5902,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5906,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:654: ##sys#peek-unsigned-integer */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[196]);
C_word av2[4];
av2[0]=*((C_word*)lf[196]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
tp(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:656: chicken.base#port? */
t3=C_fast_retrieve(lf[235]);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}}}}

/* k5796 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_5798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_5798,2,av);}
a=C_alloc(9);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5807,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5807(t6,((C_word*)t0)[4],((C_word*)t0)[2],t2);}

/* loop-print in k5796 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_fcall f_5807(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_5807,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_not_pair_p(t2);
t5=(C_truep(t4)?t4:C_i_nullp(t2));
if(C_truep(t5)){
/* csi.scm:643: printf */
t6=*((C_word*)lf[76]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t1;
av2[2]=lf[188];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=C_i_car(t2);
if(C_truep(C_i_memq(t6,t3))){
/* csi.scm:645: fprintf */
t7=*((C_word*)lf[150]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[189];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t7=t2;
t8=C_u_i_car(t7);
t9=C_i_memq(t8,t3);
if(C_truep(C_i_not(t9))){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5838,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t11=t2;
t12=C_u_i_car(t11);
/* csi.scm:647: fprintf */
t13=*((C_word*)lf[150]+1);{
C_word av2[5];
av2[0]=t13;
av2[1]=t10;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[190];
av2[4]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(5,av2);}}
else{
t10=C_SCHEME_UNDEFINED;
t11=t1;{
C_word av2[2];
av2[0]=t11;
av2[1]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}}}

/* k5836 in loop-print in k5796 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_5838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_5838,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
/* csi.scm:648: loop-print */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5807(t7,((C_word*)t0)[5],t3,t6);}

/* k5900 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_5902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_5902,2,av);}
/* csi.scm:653: descseq */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=*((C_word*)lf[174]+1);
av2[4]=*((C_word*)lf[176]+1);
av2[5]=C_fix(1);
f_5398(6,av2);}}

/* k5904 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_5906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5906,2,av);}
/* csi.scm:654: sprintf */
t2=*((C_word*)lf[194]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[195];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_5912(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_5912,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=(C_truep(t2)?lf[197]:lf[198]);
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(7));
t6=t5;
t7=C_slot(((C_word*)t0)[2],C_fix(3));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t6,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
/* csi.scm:662: ##sys#peek-unsigned-integer */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[196]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[196]+1);
av2[1]=t9;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
tp(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:663: ##sys#locative? */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[234]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[234]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}}

/* k5929 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_5931(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_5931,2,av);}
/* csi.scm:657: fprintf */
t2=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[199];
av2[4]=((C_word*)t0)[4];
av2[5]=((C_word*)t0)[5];
av2[6]=((C_word*)t0)[6];
av2[7]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}

/* k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_5940(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_5940,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:665: ##sys#peek-unsigned-integer */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[196]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[196]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
tp(4,av2);}}
else{
if(C_truep(C_anypointerp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:680: ##sys#peek-unsigned-integer */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[196]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[196]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
tp(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:681: ##sys#bytevector? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[233]+1));
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[233]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}}}

/* k5945 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_5947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,6)))){
C_save_and_reclaim((void *)f_5947,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[2],C_fix(2));
switch(t3){
case C_fix(0):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[201];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(1):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[202];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(2):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[203];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(3):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[204];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(4):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[205];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(5):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[206];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(6):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[207];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(7):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[208];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(8):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[209];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(9):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[210];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(10):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[211];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(11):
/* csi.scm:664: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[212];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
default:
t4=C_SCHEME_UNDEFINED;
/* csi.scm:664: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[200];
av2[4]=t1;
av2[5]=t2;
av2[6]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(7,av2);}}}

/* k6062 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_6064(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6064,2,av);}
/* csi.scm:680: fprintf */
t2=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[213];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_6070(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,6)))){
C_save_and_reclaim((void *)f_6070,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_block_size(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:683: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[216];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
if(C_truep(C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:686: ##sys#lambda-info->string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[218]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[218]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}
else{
if(C_truep(C_i_structurep(((C_word*)t0)[2],lf[219]))){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[222]:lf[223]);
t6=C_slot(((C_word*)t0)[2],C_fix(3));
/* csi.scm:689: fprintf */
t7=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[224];
av2[4]=t2;
av2[5]=t5;
av2[6]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}
else{
if(C_truep(C_i_structurep(((C_word*)t0)[2],lf[225]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(1));
/* csi.scm:703: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[228];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
if(C_truep(C_structurep(((C_word*)t0)[2]))){
t2=C_slot(((C_word*)t0)[2],C_fix(0));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:719: chicken.internal#hash-table-ref */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[231]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[231]+1);
av2[1]=t4;
av2[2]=C_retrieve2(lf[146],C_text("chicken.csi#describer-table"));
av2[3]=t3;
tp(4,av2);}}
else{
/* csi.scm:726: fprintf */
t2=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[232];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}}}}}

/* k6074 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_6076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6076,2,av);}
/* csi.scm:684: hexdump */
f_6579(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],*((C_word*)lf[215]+1),((C_word*)t0)[5]);}

/* k6087 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_6089(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6089,2,av);}
/* csi.scm:686: fprintf */
t2=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[217];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6099 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_6101(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_6101,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm:691: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[221];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k6102 in k6099 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_6104(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_6104,2,av);}
a=C_alloc(8);
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=C_block_size(t3);
t5=t4;
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6115,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6115(t9,((C_word*)t0)[4],C_fix(0));}

/* doloop1238 in k6102 in k6099 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_fcall f_6115(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,3)))){
C_save_and_reclaim_args((void *)trf_6115,3,t0,t1,t2);}
a=C_alloc(14);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6123,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
t5=C_i_check_list_2(t4,lf[100]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6144,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6153,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_6153(t10,t6,t4);}}

/* g1244 in doloop1238 in k6102 in k6099 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_fcall f_6123(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,5)))){
C_save_and_reclaim_args((void *)trf_6123,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
/* csi.scm:699: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[220];
av2[4]=t3;
av2[5]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}

/* k6142 in doloop1238 in k6102 in k6099 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_ccall f_6144(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6144,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6115(t3,((C_word*)t0)[4],t2);}

/* for-each-loop1243 in doloop1238 in k6102 in k6099 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_fcall f_6153(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6153,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6163,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:697: g1244 */
t5=((C_word*)t0)[3];
f_6123(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6161 in for-each-loop1243 in doloop1238 in k6102 in k6099 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_ccall f_6163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6163,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6153(t3,((C_word*)t0)[4],t2);}

/* k6196 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_6198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_6198,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_i_check_list_2(t3,lf[100]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6267,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_6267(t8,((C_word*)t0)[4],t3);}

/* g1266 in k6196 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_6199,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6203,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:706: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[227];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k6201 in g1266 in k6196 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_6203(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_6203,2,av);}
a=C_alloc(7);
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6212,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6212(t6,((C_word*)t0)[5],t2);}

/* loop in k6201 in g1266 in k6196 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_fcall f_6212(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(13,0,3)))){
C_save_and_reclaim_args((void *)trf_6212,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6222,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_caar(t2);
t5=C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6235,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6240,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:710: ##sys#with-print-length-limit */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[87]);
C_word av2[4];
av2[0]=*((C_word*)lf[87]+1);
av2[1]=t6;
av2[2]=C_fix(100);
av2[3]=t7;
tp(4,av2);}}
else{
t6=C_i_cddr(t2);
/* csi.scm:715: loop */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}

/* k6220 in loop in k6201 in g1266 in k6196 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_ccall f_6222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6222,2,av);}
t2=C_i_cddr(((C_word*)t0)[2]);
/* csi.scm:715: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6212(t3,((C_word*)t0)[4],t2);}

/* k6233 in loop in k6201 in g1266 in k6196 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_ccall f_6235(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6235,2,av);}
/* csi.scm:714: scheme#newline */
t2=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a6239 in loop in k6201 in g1266 in k6196 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_ccall f_6240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6240,2,av);}
t2=C_i_cdar(((C_word*)t0)[2]);
t3=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:713: fprintf */
t4=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[226];
av2[4]=t2;
av2[5]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* for-each-loop1265 in k6196 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_fcall f_6267(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6267,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6277,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:704: g1266 */
t5=((C_word*)t0)[3];
f_6199(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6275 in for-each-loop1265 in k6196 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_6277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6277,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6267(t3,((C_word*)t0)[4],t2);}

/* k6302 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_6304(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_6304,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:719: g1295 */
t3=t2;
f_6308(t3,((C_word*)t0)[4],t1);}
else{
t2=C_i_assq(((C_word*)t0)[5],C_retrieve2(lf[144],C_text("chicken.csi#bytevector-data")));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6322,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:719: g1306 */
t4=t3;
f_6322(t4,((C_word*)t0)[4],t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[2],C_fix(0));
/* csi.scm:724: fprintf */
t5=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[230];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}}

/* g1295 in k6302 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_fcall f_6308(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_6308,3,t0,t1,t2);}
/* csi.scm:719: g1303 */
t3=t2;{
C_word av2[4];
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}

/* g1306 in k6302 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_fcall f_6322(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,0,3)))){
C_save_and_reclaim_args((void *)trf_6322,3,t0,t1,t2);}
a=C_alloc(19);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6330,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_i_cdr(t2);
t9=C_i_check_list_2(t8,lf[138]);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6343,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6349,a[2]=t6,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_6349(t14,t10,t8);}

/* k6328 in g1306 in k6302 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_6330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6330,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
C_apply(4,av2);}}

/* k6341 in g1306 in k6302 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_6343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_6343,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,C_fix(0));
/* csi.scm:722: scheme#append */
t3=*((C_word*)lf[229]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* map-loop1311 in g1306 in k6302 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_fcall f_6349(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6349,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6374,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:722: g1317 */
t5=*((C_word*)lf[53]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6372 in map-loop1311 in g1306 in k6302 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_ccall f_6374(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6374,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6349(t6,((C_word*)t0)[5],t5);}

/* k6385 in k6302 in k6068 in k5938 in k5910 in k5793 in k5694 in k5528 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_6387(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6387,2,av);}
/* csi.scm:725: descseq */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_FALSE;
av2[3]=*((C_word*)lf[174]+1);
av2[4]=*((C_word*)lf[176]+1);
av2[5]=C_fix(1);
f_5398(6,av2);}}

/* k6412 in chicken.csi#describe in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_6414(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6414,2,av);}
/* csi.scm:591: fprintf */
t2=*((C_word*)lf[150]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[237];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* chicken.csi#set-describer! in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_6422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6422,4,av);}
t4=C_i_check_symbol_2(t2,lf[240]);
/* csi.scm:731: chicken.internal#hash-table-set! */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[241]);
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[241]+1);
av2[1]=t1;
av2[2]=C_retrieve2(lf[146],C_text("chicken.csi#describer-table"));
av2[3]=t2;
av2[4]=t3;
tp(5,av2);}}

/* chicken.csi#dump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_6431(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,4)))){
C_save_and_reclaim_args((void *)trf_6431,3,t1,t2,t3);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6433,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6539,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6544,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t3))){
/* csi.scm:738: def-len1350 */
t7=t6;
f_6544(t7,t1);}
else{
t7=C_i_car(t3);
t8=C_u_i_cdr(t3);
if(C_truep(C_i_nullp(t8))){
/* csi.scm:738: def-out1351 */
t9=t5;
f_6539(t9,t1,t7);}
else{
t9=C_i_car(t8);
t10=C_u_i_cdr(t8);
/* csi.scm:738: body1348 */
t11=t4;
f_6433(t11,t1,t7,t9);}}}

/* body1348 in chicken.csi#dump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_fcall f_6433(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,4)))){
C_save_and_reclaim_args((void *)trf_6433,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6436,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_immp(((C_word*)t0)[2]))){
/* csi.scm:742: ##sys#error */
t5=*((C_word*)lf[31]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t1;
av2[2]=lf[243];
av2[3]=lf[244];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6458,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:743: ##sys#bytevector? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[233]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[233]+1);
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}}

/* bestlen in body1348 in chicken.csi#dump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_fcall f_6436(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_6436,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm:741: scheme#min */
t3=*((C_word*)lf[242]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6456 in body1348 in chicken.csi#dump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_6458(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_6458,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* csi.scm:743: bestlen */
t4=((C_word*)t0)[5];
f_6436(t4,t2,t3);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* csi.scm:744: bestlen */
t4=((C_word*)t0)[5];
f_6436(t4,t2,t3);}
else{
t2=C_immp(((C_word*)t0)[3]);
t3=C_i_not(t2);
t4=(C_truep(t3)?C_anypointerp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t4)){
/* csi.scm:746: hexdump */
f_6579(((C_word*)t0)[2],((C_word*)t0)[3],C_fix(32),*((C_word*)lf[245]+1),((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_structurep(((C_word*)t0)[3]))){
t6=C_slot(((C_word*)t0)[3],C_fix(0));
t7=t5;
f_6501(t7,C_i_assq(t6,C_retrieve2(lf[144],C_text("chicken.csi#bytevector-data"))));}
else{
t6=t5;
f_6501(t6,C_SCHEME_FALSE);}}}}}

/* k6463 in k6456 in body1348 in chicken.csi#dump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_6465(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6465,2,av);}
/* csi.scm:743: hexdump */
f_6579(((C_word*)t0)[2],((C_word*)t0)[3],t1,*((C_word*)lf[215]+1),((C_word*)t0)[4]);}

/* k6480 in k6456 in body1348 in chicken.csi#dump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_6482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6482,2,av);}
/* csi.scm:744: hexdump */
f_6579(((C_word*)t0)[2],((C_word*)t0)[3],t1,*((C_word*)lf[215]+1),((C_word*)t0)[4]);}

/* k6499 in k6456 in body1348 in chicken.csi#dump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_fcall f_6501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_6501,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6511,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_block_size(t3);
/* csi.scm:749: bestlen */
t6=((C_word*)t0)[5];
f_6436(t6,t4,t5);}
else{
/* csi.scm:750: ##sys#error */
t2=*((C_word*)lf[31]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[243];
av2[3]=lf[246];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* k6509 in k6499 in k6456 in body1348 in chicken.csi#dump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_6511(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6511,2,av);}
/* csi.scm:749: hexdump */
f_6579(((C_word*)t0)[2],((C_word*)t0)[3],t1,*((C_word*)lf[215]+1),((C_word*)t0)[4]);}

/* def-out1351 in chicken.csi#dump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_fcall f_6539(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_6539,3,t0,t1,t2);}
/* csi.scm:738: body1348 */
t3=((C_word*)t0)[2];
f_6433(t3,t1,t2,*((C_word*)lf[83]+1));}

/* def-len1350 in chicken.csi#dump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_fcall f_6544(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_6544,2,t0,t1);}
/* csi.scm:738: def-out1351 */
t2=((C_word*)t0)[2];
f_6539(t2,t1,C_SCHEME_FALSE);}

/* chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_6579(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,6)))){
C_save_and_reclaim_args((void *)trf_6579,5,t1,t2,t3,t4,t5);}
a=C_alloc(12);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6582,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6614,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t4,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_6614(t10,t1,C_fix(0));}

/* justify in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_fcall f_6582(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_6582,5,t1,t2,t3,t4,t5);}
a=C_alloc(5);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6586,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#number->string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[247]);
C_word av2[4];
av2[0]=*((C_word*)lf[247]+1);
av2[1]=t6;
av2[2]=t2;
av2[3]=t4;
tp(4,av2);}}

/* k6584 in justify in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_6586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_6586,2,av);}
a=C_alloc(4);
t2=t1;
t3=C_block_size(t2);
if(C_truep(C_fixnum_lessp(t3,((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6602,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_difference(((C_word*)t0)[2],t3);
/* csi.scm:763: make-string */
t6=*((C_word*)lf[116]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6600 in k6584 in justify in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_6602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6602,2,av);}
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[15]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[15]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_fcall f_6614(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,5)))){
C_save_and_reclaim_args((void *)trf_6614,3,t0,t1,t2);}
a=C_alloc(14);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6624,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6782,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:768: justify */
f_6582(t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_6624(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_6624,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* ##sys#write-char/port */
t3=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(58);
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_6627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,4)))){
C_save_and_reclaim((void *)f_6627,2,av);}
a=C_alloc(19);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6699,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_6699(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* k6628 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_6630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_6630,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* ##sys#write-char/port */
t3=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6631 in k6628 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_6633(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,4)))){
C_save_and_reclaim((void *)f_6633,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6648,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_6648(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* k6634 in k6631 in k6628 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_6636(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6636,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#write-char/port */
t3=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6637 in k6634 in k6631 in k6628 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_6639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6639,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6614(t3,((C_word*)t0)[4],t2);}

/* doloop1397 in k6631 in k6628 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_fcall f_6648(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_6648,4,t0,t1,t2,t3);}
a=C_alloc(7);
t4=C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6661,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:785: ref */
t7=((C_word*)t0)[5];{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[6];
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* k6659 in doloop1397 in k6631 in k6628 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_6661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6661,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_make_character(C_unfix(t1));
/* ##sys#write-char/port */
t6=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=t5;
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
/* ##sys#write-char/port */
t5=C_fast_retrieve(lf[248]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=C_make_character(46);
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k6662 in k6659 in doloop1397 in k6631 in k6628 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_6664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6664,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_6648(t4,((C_word*)t0)[5],t2,t3);}

/* doloop1396 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_fcall f_6699(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,3)))){
C_save_and_reclaim_args((void *)trf_6699,4,t0,t1,t2,t3);}
a=C_alloc(10);
t4=C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]));
if(C_truep(t5)){
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]))){
t6=C_fixnum_modulo(((C_word*)t0)[2],C_fix(16));
t7=C_eqp(t6,C_fix(0));
if(C_truep(t7)){
t8=C_SCHEME_UNDEFINED;
t9=t1;{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=C_fixnum_difference(C_fix(16),t6);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6733,a[2]=t10,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_6733(t12,t1,t8);}}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6753,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* ##sys#write-char/port */
t7=C_fast_retrieve(lf[248]);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}

/* doloop1405 in doloop1396 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_fcall f_6733(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_6733,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6743,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:778: display */
t5=*((C_word*)lf[93]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[249];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k6741 in doloop1405 in doloop1396 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_6743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6743,2,av);}
t2=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6733(t3,((C_word*)t0)[4],t2);}

/* k6751 in doloop1396 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_6753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_6753,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6771,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6775,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:780: ref */
t5=((C_word*)t0)[8];{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[9];
av2[3]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t5))(4,av2);}}

/* k6754 in k6751 in doloop1396 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_6756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6756,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_6699(t4,((C_word*)t0)[5],t2,t3);}

/* k6769 in k6751 in doloop1396 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_6771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6771,2,av);}
/* csi.scm:780: display */
t2=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6773 in k6751 in doloop1396 in k6625 in k6622 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_6775(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6775,2,av);}
/* csi.scm:780: justify */
f_6582(((C_word*)t0)[3],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k6780 in doloop1386 in chicken.csi#hexdump in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_6782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6782,2,av);}
/* csi.scm:768: display */
t2=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_6784(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_6784,2,t1,t2);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6787,tmp=(C_word)a,a+=2,tmp);
t4=C_fast_retrieve(lf[95]);
t5=(C_truep(C_fast_retrieve(lf[95]))?C_fast_retrieve(lf[95]):C_SCHEME_END_OF_LIST);
t6=t5;
t7=C_i_length(t6);
t8=t7;
t9=t2;
t10=(C_truep(C_u_i_memq(t9,t6))?t2:C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6810,a[2]=t8,a[3]=t3,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t10)){
t12=t11;
f_6810(t12,t10);}
else{
if(C_truep(C_fixnum_greaterp(t8,C_fix(0)))){
t12=C_fixnum_difference(t8,C_fix(1));
t13=t11;
f_6810(t13,C_i_list_ref(t6,t12));}
else{
t12=t11;
f_6810(t12,C_SCHEME_FALSE);}}}

/* prin1 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_fcall f_6787(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,3)))){
C_save_and_reclaim_args((void *)trf_6787,2,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6793,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:799: ##sys#with-print-length-limit */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[87]);
C_word av2[4];
av2[0]=*((C_word*)lf[87]+1);
av2[1]=t1;
av2[2]=C_fix(100);
av2[3]=t3;
tp(4,av2);}}

/* a6792 in prin1 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_6793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6793,2,av);}
/* csi.scm:802: ##sys#print */
t2=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=C_SCHEME_TRUE;
av2[4]=*((C_word*)lf[83]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_fcall f_6810(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_6810,2,t0,t1);}
a=C_alloc(6);
t2=C_mutate(&lf[8] /* (set! chicken.csi#selected-frame ...) */,t1);
t3=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6819,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6819(t7,((C_word*)t0)[4],((C_word*)t0)[5],t3);}

/* doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_fcall f_6819(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,4)))){
C_save_and_reclaim_args((void *)trf_6819,4,t0,t1,t2,t3);}
a=C_alloc(14);
if(C_truep(C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=t4;
t6=C_eqp(C_retrieve2(lf[8],C_text("chicken.csi#selected-frame")),t5);
t7=t6;
t8=C_slot(t5,C_fix(1));
t9=t8;
t10=C_slot(t5,C_fix(2));
t11=t10;
t12=C_i_structurep(t11,lf[98]);
t13=t12;
t14=(C_truep(t13)?C_slot(t11,C_fix(1)):t11);
t15=t14;
t16=*((C_word*)lf[83]+1);
t17=*((C_word*)lf[83]+1);
t18=C_i_check_port_2(*((C_word*)lf[83]+1),C_fix(2),C_SCHEME_TRUE,lf[84]);
t19=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6850,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t7,a[7]=t13,a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,a[11]=t15,a[12]=t16,a[13]=t5,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t7)){
/* csi.scm:818: ##sys#print */
t20=*((C_word*)lf[86]+1);{
C_word av2[5];
av2[0]=t20;
av2[1]=t19;
av2[2]=C_make_character(42);
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[83]+1);
((C_proc)(void*)(*((C_word*)t20+1)))(5,av2);}}
else{
/* csi.scm:818: ##sys#print */
t20=*((C_word*)lf[86]+1);{
C_word av2[5];
av2[0]=t20;
av2[1]=t19;
av2[2]=C_make_character(32);
av2[3]=C_SCHEME_FALSE;
av2[4]=t16;
((C_proc)(void*)(*((C_word*)t20+1)))(5,av2);}}}}

/* k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_6850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,4)))){
C_save_and_reclaim((void *)f_6850,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* csi.scm:818: ##sys#print */
t3=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[12];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_6853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_6853,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* csi.scm:818: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[89]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[89]+1);
av2[1]=t2;
av2[2]=C_make_character(58);
av2[3]=((C_word*)t0)[12];
tp(4,av2);}}

/* k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_6856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,2)))){
C_save_and_reclaim((void *)f_6856,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7028,a[2]=t2,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[7])){
t4=C_slot(((C_word*)t0)[9],C_fix(2));
t5=t3;
f_7028(t5,C_i_pairp(t4));}
else{
t4=t3;
f_7028(t4,C_SCHEME_FALSE);}}

/* k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_6859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_6859,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* csi.scm:818: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[89]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[89]+1);
av2[1]=t2;
av2[2]=C_make_character(9);
av2[3]=((C_word*)t0)[12];
tp(4,av2);}}

/* k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_6862(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_6862,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=C_slot(((C_word*)t0)[13],C_fix(0));
/* csi.scm:818: ##sys#print */
t4=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[12];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_6865(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_6865,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm:818: ##sys#print */
t3=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[254];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[12];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_6868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,3)))){
C_save_and_reclaim((void *)f_6868,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[11])){
t3=*((C_word*)lf[83]+1);
t4=*((C_word*)lf[83]+1);
t5=C_i_check_port_2(*((C_word*)lf[83]+1),C_fix(2),C_SCHEME_TRUE,lf[84]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7011,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:823: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[89]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[89]+1);
av2[1]=t6;
av2[2]=C_make_character(91);
av2[3]=*((C_word*)lf[83]+1);
tp(4,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6871(2,av2);}}}

/* k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_ccall f_6871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_6871,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[10])){
/* csi.scm:824: prin1 */
f_6787(t2,((C_word*)t0)[10]);}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6874(2,av2);}}}

/* k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_ccall f_6874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_6874,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm:825: newline */
t3=*((C_word*)lf[85]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in ... */
static void C_ccall f_6877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,4)))){
C_save_and_reclaim((void *)f_6877,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep(((C_word*)t0)[6])?((C_word*)t0)[7]:C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6893,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t5=C_slot(((C_word*)t0)[9],C_fix(2));
t6=C_slot(((C_word*)t0)[9],C_fix(3));
t7=C_i_check_list_2(t5,lf[100]);
t8=C_i_check_list_2(t6,lf[100]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6967,a[2]=t10,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_6967(t12,t2,t5,t6);}
else{
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t7=((C_word*)((C_word*)t0)[4])[1];
f_6819(t7,((C_word*)t0)[5],t5,t6);}}

/* k6878 in k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in ... */
static void C_ccall f_6880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6880,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_6819(t5,((C_word*)t0)[5],t3,t4);}

/* g1480 in k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in ... */
static void C_fcall f_6893(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6893,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6903,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:830: display */
t5=*((C_word*)lf[93]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[252];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k6901 in g1480 in k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in ... */
static void C_ccall f_6903(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_6903,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6908,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6908(t5,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[5]);}

/* doloop1493 in k6901 in g1480 in k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in ... */
static void C_fcall f_6908(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,4)))){
C_save_and_reclaim_args((void *)trf_6908,4,t0,t1,t2,t3);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=*((C_word*)lf[83]+1);
t5=*((C_word*)lf[83]+1);
t6=C_i_check_port_2(*((C_word*)lf[83]+1),C_fix(2),C_SCHEME_TRUE,lf[84]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6921,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* csi.scm:834: ##sys#print */
t8=*((C_word*)lf[86]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[251];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[83]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}

/* k6919 in doloop1493 in k6901 in g1480 in k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in ... */
static void C_ccall f_6921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_6921,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* csi.scm:834: ##sys#print */
t4=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k6922 in k6919 in doloop1493 in k6901 in g1480 in k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in ... */
static void C_ccall f_6924(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_6924,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:834: ##sys#print */
t3=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[250];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6925 in k6922 in k6919 in doloop1493 in k6901 in g1480 in k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in ... */
static void C_ccall f_6927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6927,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[6],((C_word*)t0)[2]);
/* csi.scm:835: prin1 */
f_6787(t2,t3);}

/* k6928 in k6925 in k6922 in k6919 in doloop1493 in k6901 in g1480 in k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in ... */
static void C_ccall f_6930(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6930,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:836: newline */
t3=*((C_word*)lf[85]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6931 in k6928 in k6925 in k6922 in k6919 in doloop1493 in k6901 in g1480 in k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in ... */
static void C_ccall f_6933(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6933,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[4])[1];
f_6908(t5,((C_word*)t0)[5],t2,t4);}

/* for-each-loop1479 in k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in ... */
static void C_fcall f_6967(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_6967,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6977,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* csi.scm:827: g1480 */
t9=((C_word*)t0)[3];
f_6893(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k6975 in for-each-loop1479 in k6875 in k6872 in k6869 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in ... */
static void C_ccall f_6977(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6977,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_6967(t4,((C_word*)t0)[5],t2,t3);}

/* k7009 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_ccall f_7011(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_7011,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:823: ##sys#print */
t3=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k7012 in k7009 in k6866 in k6863 in k6860 in k6857 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_ccall f_7014(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7014,2,av);}
/* csi.scm:823: ##sys#print */
t2=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[253];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7026 in k6854 in k6851 in k6848 in doloop1442 in k6808 in chicken.csi#show-frameinfo in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_fcall f_7028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_7028,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm:818: ##sys#print */
t2=*((C_word*)lf[86]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[255];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
/* csi.scm:818: ##sys#print */
t2=*((C_word*)lf[86]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[256];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* k7067 in k4750 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_7069(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_7069,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm:847: display */
t2=*((C_word*)lf[93]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[94];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_i_length(C_fast_retrieve(lf[95]));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_fixnum_difference(t2,t3);
t5=C_i_list_ref(C_fast_retrieve(lf[95]),t4);
t6=C_mutate(&lf[8] /* (set! chicken.csi#selected-frame ...) */,t5);
/* csi.scm:853: show-frameinfo */
f_6784(((C_word*)t0)[2],C_retrieve2(lf[8],C_text("chicken.csi#selected-frame")));}}

/* k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_7126(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_7126,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7128,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7159,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:874: call/cc */
t5=*((C_word*)lf[102]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* compare in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_fcall f_7128(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,4)))){
C_save_and_reclaim_args((void *)trf_7128,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7139,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=C_i_string_length(((C_word*)t0)[2]);
t6=C_i_string_length(t3);
t7=C_i_fixnum_min(t5,t6);
/* csi.scm:872: scheme#substring */
t8=*((C_word*)lf[13]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t4;
av2[2]=t3;
av2[3]=C_fix(0);
av2[4]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}

/* k7137 in compare in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_7139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7139,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_i_string_equal_p(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_7159(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_7159,3,av);}
a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7162,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7181,a[2]=t3,a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_7181(t7,t1,((C_word*)t0)[4]);}

/* fail in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_fcall f_7162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_7162,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7166,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:877: display */
t4=*((C_word*)lf[93]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7164 in fail in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_7166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7166,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:878: newline */
t3=*((C_word*)lf[85]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7167 in k7164 in fail in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_7169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7169,2,av);}
t2=*((C_word*)lf[29]+1);
/* csi.scm:879: return */
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=*((C_word*)lf[29]+1);
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}

/* doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_fcall f_7181(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(20,0,4)))){
C_save_and_reclaim_args((void *)trf_7181,3,t0,t1,t2);}
a=C_alloc(20);
if(C_truep(C_i_nullp(t2))){
/* csi.scm:881: fail */
t3=((C_word*)t0)[2];
f_7162(t3,t1,lf[97]);}
else{
t3=C_i_car(t2);
t4=C_eqp(C_retrieve2(lf[8],C_text("chicken.csi#selected-frame")),t3);
t5=C_slot(t3,C_fix(2));
t6=C_i_structurep(t5,lf[98]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7206,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(C_truep(t4)?t6:C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7215,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t10=C_slot(t5,C_fix(2));
t11=C_slot(t5,C_fix(3));
t12=C_i_check_list_2(t10,lf[100]);
t13=C_i_check_list_2(t11,lf[100]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7291,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7300,a[2]=t16,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t18=((C_word*)t16)[1];
f_7300(t18,t14,t10,t11);}
else{
t9=t2;
t10=C_u_i_cdr(t9);
t19=t1;
t20=t10;
t1=t19;
t2=t20;
goto loop;}}}

/* k7204 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_7206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7206,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)((C_word*)t0)[3])[1];
f_7181(t4,((C_word*)t0)[4],t3);}

/* g1577 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_fcall f_7215(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_7215,4,t0,t1,t2,t3);}
a=C_alloc(8);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7221,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7221(t7,t1,C_fix(0),t2);}

/* doloop1590 in g1577 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_fcall f_7221(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,2)))){
C_save_and_reclaim_args((void *)trf_7221,4,t0,t1,t2,t3);}
a=C_alloc(15);
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7231,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7243,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t6=C_i_car(t3);
/* csi.scm:893: compare */
t7=((C_word*)t0)[5];
f_7128(t7,t5,t6);}}

/* k7229 in doloop1590 in g1577 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_7231(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7231,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[4])[1];
f_7221(t5,((C_word*)t0)[5],t2,t4);}

/* k7241 in doloop1590 in g1577 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_7243(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_7243,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:894: display */
t3=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[99];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)t0)[6];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[7])[1];
f_7221(t5,((C_word*)t0)[8],t2,t4);}}

/* k7244 in k7241 in doloop1590 in g1577 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_7246(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_7246,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[6];
t4=C_u_i_car(t3);
/* csi.scm:895: display */
t5=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7247 in k7244 in k7241 in doloop1590 in g1577 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_7249(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_7249,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:896: newline */
t3=*((C_word*)lf[85]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7250 in k7247 in k7244 in k7241 in doloop1590 in g1577 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_7252(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_7252,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_list1(&a,1,t3);
/* csi.scm:897: history-add */
t5=C_retrieve2(lf[28],C_text("chicken.csi#history-add"));
f_4106(t5,t2,t4);}

/* k7253 in k7250 in k7247 in k7244 in k7241 in doloop1590 in g1577 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_7255(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7255,2,av);}
t2=C_slot(((C_word*)t0)[2],((C_word*)t0)[3]);
/* csi.scm:898: return */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[5];
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}

/* k7289 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_7291(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_7291,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:901: ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[15]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[15]+1);
av2[1]=t2;
av2[2]=lf[101];
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* k7296 in k7289 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_7298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7298,2,av);}
/* csi.scm:901: fail */
t2=((C_word*)t0)[2];
f_7162(t2,((C_word*)t0)[3],t1);}

/* for-each-loop1576 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_fcall f_7300(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_7300,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7310,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* csi.scm:888: g1577 */
t9=((C_word*)t0)[3];
f_7215(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k7308 in for-each-loop1576 in doloop1562 in a7158 in k7124 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_7310(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7310,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_7300(t4,((C_word*)t0)[5],t2,t3);}

/* k7351 in k4763 in k4361 in chicken.csi#csi-eval in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_7353(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7353,2,av);}
t2=((C_word*)t0)[2];
f_7126(t2,C_SCHEME_FALSE);}

/* chicken.csi#member* in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_7358(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_7358,3,t1,t2,t3);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7364,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7364(t7,t1,t3);}

/* loop in chicken.csi#member* in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_fcall f_7364(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_7364,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7376,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7376(t6,t1,((C_word*)t0)[3]);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* find in loop in chicken.csi#member* in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_fcall f_7376(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_7376,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_i_cdr(((C_word*)t0)[2]);
/* csi.scm:925: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7364(t4,t1,t3);}
else{
t3=C_i_car(t2);
t4=C_i_car(((C_word*)t0)[2]);
if(C_truep(C_i_equalp(t3,t4))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t2;
t6=C_u_i_cdr(t5);
/* csi.scm:927: find */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* chicken.csi#canonicalize-args in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_7413(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_7413,2,t1,t2);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7419,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7419(t6,t1,t2);}

/* loop in chicken.csi#canonicalize-args in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_fcall f_7419(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7419,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
if(C_truep((C_truep(C_i_equalp(t4,lf[261]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[262]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[263]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[264]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[265]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7441,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=C_block_size(t4);
if(C_truep(C_fixnum_greaterp(t6,C_fix(2)))){
t7=C_subchar(t4,C_fix(0));
if(C_truep(C_i_char_equalp(C_make_character(45),t7))){
t8=C_i_member(t4,lf[268]);
t9=t5;
f_7441(t9,C_i_not(t8));}
else{
t8=t5;
f_7441(t8,C_SCHEME_FALSE);}}
else{
t7=t5;
f_7441(t7,C_SCHEME_FALSE);}}}}

/* k7439 in loop in chicken.csi#canonicalize-args in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_fcall f_7441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_7441,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(58),t2))){
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* csi.scm:949: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7419(t5,((C_word*)t0)[5],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7455,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7523,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:950: scheme#substring */
t5=*((C_word*)lf[13]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7531,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* csi.scm:954: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7419(t5,t2,t4);}}

/* k7453 in k7439 in loop in chicken.csi#canonicalize-args in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_7455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,3)))){
C_save_and_reclaim((void *)f_7455,2,av);}
a=C_alloc(19);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7562,tmp=(C_word)a,a+=2,tmp);
t3=(
  f_7562(t1)
);
if(C_truep(t3)){
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7484,a[2]=t6,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_7484(t12,t8,t1);}
else{
/* csi.scm:953: ##sys#error */
t4=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[266];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k7474 in k7453 in k7439 in loop in chicken.csi#canonicalize-args in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_7476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7476,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7480,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* csi.scm:952: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7419(t6,t3,t5);}

/* k7478 in k7474 in k7453 in k7439 in loop in chicken.csi#canonicalize-args in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_7480(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7480,2,av);}
/* csi.scm:952: scheme#append */
t2=*((C_word*)lf[229]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop1687 in k7453 in k7439 in loop in chicken.csi#canonicalize-args in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_fcall f_7484(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7484,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_string(&a,2,C_make_character(45),t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7521 in k7439 in loop in chicken.csi#canonicalize-args in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_7523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7523,2,av);}
/* ##sys#string->list */
t2=C_fast_retrieve(lf[267]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7529 in k7439 in loop in chicken.csi#canonicalize-args in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_7531(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_7531,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k7453 in k7439 in loop in chicken.csi#canonicalize-args in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static C_word C_fcall f_7562(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:{}
t2=C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=C_i_car(t1);
if(C_truep((C_truep(C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=t1;
t5=C_u_i_cdr(t4);
t7=t5;
t1=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_7592(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_7592,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7595,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8653,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:975: chicken.process-context#command-line-arguments */
t5=C_fast_retrieve(lf[299]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_7595(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_7595,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7598,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:977: member* */
f_7358(t4,lf[369],((C_word*)t3)[1]);}

/* k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in ... */
static void C_ccall f_7598(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7598,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:978: member* */
f_7358(t3,lf[368],((C_word*)((C_word*)t0)[2])[1]);}

/* k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in ... */
static void C_ccall f_7601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,2)))){
C_save_and_reclaim((void *)f_7601,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7604,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8553,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(t2);
t6=C_i_pairp(t5);
t7=C_i_not(t6);
if(C_truep(t7)){
if(C_truep(t7)){
/* csi.scm:983: ##sys#error */
t8=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t4;
av2[2]=lf[366];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t8=t4;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_UNDEFINED;
f_8553(2,av2);}}}
else{
t8=C_i_cadr(t2);
t9=C_i_string_length(t8);
t10=C_eqp(t9,C_fix(0));
if(C_truep(t10)){
if(C_truep(t10)){
/* csi.scm:983: ##sys#error */
t11=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t4;
av2[2]=lf[366];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t11=t4;{
C_word *av2=av;
av2[0]=t11;
av2[1]=C_SCHEME_UNDEFINED;
f_8553(2,av2);}}}
else{
t11=C_u_i_cdr(t2);
t12=C_u_i_car(t11);
t13=C_i_string_ref(t12,C_fix(0));
if(C_truep(C_u_i_char_equalp(C_make_character(45),t13))){
/* csi.scm:983: ##sys#error */
t14=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t14;
av2[1]=t4;
av2[2]=lf[366];
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}
else{
t14=t4;{
C_word *av2=av;
av2[0]=t14;
av2[1]=C_SCHEME_UNDEFINED;
f_8553(2,av2);}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8636,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8649,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:993: canonicalize-args */
f_7413(t5,((C_word*)t0)[5]);}}

/* k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_fcall f_7604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_7604,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:996: member* */
f_7358(t2,lf[363],((C_word*)((C_word*)t0)[2])[1]);}

/* k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_7607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_7607,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_7610(t4,((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8547,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:997: member* */
f_7358(t4,lf[362],((C_word*)((C_word*)t0)[2])[1]);}}

/* k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_fcall f_7610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_7610,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7613,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:998: member* */
f_7358(t3,lf[361],((C_word*)((C_word*)t0)[2])[1]);}

/* k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_7613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_7613,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_7616(t3,((C_word*)t0)[4]);}
else{
if(C_truep(t1)){
t3=t1;
t4=t2;
f_7616(t4,t3);}
else{
t3=t2;
f_7616(t3,((C_word*)t0)[6]);}}}

/* k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_fcall f_7616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,0,2)))){
C_save_and_reclaim_args((void *)trf_7616,2,t0,t1);}
a=C_alloc(20);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_retrieve2(lf[12],C_text("chicken.csi#chop-separator"));
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t7,a[11]=t6,tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8538,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1002: chicken.process-context#get-environment-variable */
t10=C_fast_retrieve(lf[23]);{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[360];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_7622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,3)))){
C_save_and_reclaim((void *)f_7622,2,av);}
a=C_alloc(17);
t2=C_i_check_list_2(t1,lf[138]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8502,a[2]=((C_word*)t0)[9],a[3]=t5,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_8502(t7,t3,t1);}

/* k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_ccall f_7628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,4)))){
C_save_and_reclaim((void *)f_7628,2,av);}
a=C_alloc(24);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7630,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7742,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7799,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8494,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1027: member* */
f_7358(t10,lf[358],((C_word*)((C_word*)t0)[2])[1]);}

/* collect-options in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_fcall f_7630(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_7630,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7636,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7636(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in ... */
static void C_fcall f_7636(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_7636,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_i_member(((C_word*)t0)[2],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1005: g1861 */
t5=t4;
f_7644(t5,t1,t3);}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* g1861 in loop in collect-options in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in ... */
static void C_fcall f_7644(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_7644,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* csi.scm:1008: ##sys#error */
t4=*((C_word*)lf[31]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[270];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=C_i_cadr(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7665,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
/* csi.scm:1009: loop */
t10=((C_word*)((C_word*)t0)[3])[1];
f_7636(t10,t6,t9);}}

/* k7663 in g1861 in loop in collect-options in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in ... */
static void C_ccall f_7665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_7665,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7679 in k8149 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in ... */
static void C_ccall f_7681(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_7681,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7684,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=C_a_i_list2(&a,2,t1,lf[311]);
/* csi.scm:1013: chicken.pathname#make-pathname */
t4=C_fast_retrieve(lf[308]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_retrieve2(lf[1],C_text("chicken.csi#constant680"));
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_7684(2,av2);}}}

/* k7682 in k7679 in k8149 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in ... */
static void C_ccall f_7684(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7684,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7687,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1015: chicken.process-context#get-environment-variable */
t4=C_fast_retrieve(lf[23]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[310];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7685 in k7682 in k7679 in k8149 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_7687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_7687,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=C_i_string_equal_p(t2,lf[307]);
if(C_truep(C_i_not(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7727,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_retrieve2(lf[1],C_text("chicken.csi#constant680"));
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[15]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[15]+1);
av2[1]=t5;
av2[2]=lf[309];
av2[3]=C_retrieve2(lf[1],C_text("chicken.csi#constant680"));
tp(4,av2);}}
else{
t5=t3;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_7690(2,av2);}}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_7690(2,av2);}}}

/* k7688 in k7685 in k7682 in k7679 in k8149 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in ... */
static void C_ccall f_7690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_7690,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* csi.scm:1018: chicken.file#file-exists? */
t4=C_fast_retrieve(lf[14]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_7696(2,av2);}}}

/* k7694 in k7688 in k7685 in k7682 in k7679 in k8149 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in ... */
static void C_ccall f_7696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7696,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
/* csi.scm:1019: scheme#load */
t2=*((C_word*)lf[64]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* csi.scm:1020: chicken.file#file-exists? */
t3=C_fast_retrieve(lf[14]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}

/* k7703 in k7694 in k7688 in k7685 in k7682 in k7679 in k8149 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in ... */
static void C_ccall f_7705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7705,2,av);}
if(C_truep(t1)){
/* csi.scm:1021: scheme#load */
t2=*((C_word*)lf[64]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k7725 in k7685 in k7682 in k7679 in k8149 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in ... */
static void C_ccall f_7727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7727,2,av);}
/* csi.scm:1017: chicken.pathname#make-pathname */
t2=C_fast_retrieve(lf[308]);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* evalstring in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_fcall f_7742(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7742,3,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7789,tmp=(C_word)a,a+=2,tmp):C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7749,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1023: chicken.base#open-input-string */
t8=C_fast_retrieve(lf[272]);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k7747 in evalstring in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in ... */
static void C_ccall f_7749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_7749,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7756,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:1024: scheme#read */
t4=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7754 in k7747 in evalstring in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in ... */
static void C_ccall f_7756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_7756,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7758,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7758(t5,((C_word*)t0)[4],t1);}

/* doloop1891 in k7754 in k7747 in evalstring in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in ... */
static void C_fcall f_7758(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,3)))){
C_save_and_reclaim_args((void *)trf_7758,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_eofp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7768,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7779,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7781,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1026: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=t4;
av2[2]=t5;
av2[3]=*((C_word*)lf[271]+1);
C_call_with_values(4,av2);}}}

/* k7766 in doloop1891 in k7754 in k7747 in evalstring in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in ... */
static void C_ccall f_7768(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7768,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1024: scheme#read */
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7773 in k7766 in doloop1891 in k7754 in k7747 in evalstring in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in ... */
static void C_ccall f_7775(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7775,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
f_7758(t2,((C_word*)t0)[3],t1);}

/* k7777 in doloop1891 in k7754 in k7747 in evalstring in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in ... */
static void C_ccall f_7779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7779,2,av);}
/* csi.scm:1026: rec */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* a7780 in doloop1891 in k7754 in k7747 in evalstring in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in ... */
static void C_ccall f_7781(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7781,2,av);}
/* csi.scm:1026: scheme#eval */
t2=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* f_7789 in evalstring in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in ... */
static void C_ccall f_7789(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7789,2,av);}
t2=t1;{
C_word *av2=av;
av2[0]=t2;
av2[1]=*((C_word*)lf[29]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_ccall f_7799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,2)))){
C_save_and_reclaim((void *)f_7799,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_member(lf[352],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8488,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9462,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:145: chicken.platform#chicken-version */
t6=C_fast_retrieve(lf[316]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_7802(2,av2);}}}

/* k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in ... */
static void C_ccall f_7802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_7802,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_member(lf[350],((C_word*)((C_word*)t0)[6])[1]))){
t3=C_set_block_item(lf[351] /* ##sys#setup-mode */,0,C_SCHEME_TRUE);
t4=t2;
f_7805(t4,t3);}
else{
t3=t2;
f_7805(t3,C_SCHEME_UNDEFINED);}}

/* k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in ... */
static void C_fcall f_7805(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,2)))){
C_save_and_reclaim_args((void *)trf_7805,2,t0,t1);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_member(lf[349],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8471,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8478,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1036: chicken.platform#chicken-version */
t5=C_fast_retrieve(lf[316]);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_7808(2,av2);}}}

/* k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in ... */
static void C_ccall f_7808(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,3)))){
C_save_and_reclaim((void *)f_7808,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8458,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1038: member* */
f_7358(t3,lf[348],((C_word*)((C_word*)t0)[6])[1]);}

/* k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in ... */
static void C_fcall f_7811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,0,3)))){
C_save_and_reclaim_args((void *)trf_7811,2,t0,t1);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8443,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1041: member* */
f_7358(t3,lf[345],((C_word*)((C_word*)t0)[6])[1]);}

/* k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in ... */
static void C_ccall f_7814(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_7814,2,av);}
a=C_alloc(13);
t2=C_fast_retrieve(lf[273]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* csi.scm:1045: collect-options */
t4=((C_word*)((C_word*)t0)[11])[1];
f_7630(t4,t3,lf[342]);}

/* k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in ... */
static void C_ccall f_7817(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_7817,2,av);}
a=C_alloc(18);
t2=C_i_check_list_2(t1,lf[100]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8419,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_8419(t7,t3,t1);}

/* k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in ... */
static void C_ccall f_7823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_7823,2,av);}
a=C_alloc(13);
t2=C_fast_retrieve(lf[273]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* csi.scm:1046: collect-options */
t4=((C_word*)((C_word*)t0)[11])[1];
f_7630(t4,t3,lf[341]);}

/* k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in ... */
static void C_ccall f_7826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_7826,2,av);}
a=C_alloc(18);
t2=C_i_check_list_2(t1,lf[100]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8396,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_8396(t7,t3,t1);}

/* k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in ... */
static void C_ccall f_7832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_7832,2,av);}
a=C_alloc(13);
t2=C_fast_retrieve(lf[274]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* csi.scm:1047: collect-options */
t4=((C_word*)((C_word*)t0)[11])[1];
f_7630(t4,t3,lf[340]);}

/* k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in ... */
static void C_ccall f_7835(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_7835,2,av);}
a=C_alloc(18);
t2=C_i_check_list_2(t1,lf[100]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8373,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_8373(t7,t3,t1);}

/* k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in ... */
static void C_ccall f_7841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(26,c,2)))){
C_save_and_reclaim((void *)f_7841,2,av);}
a=C_alloc(26);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8277,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_retrieve2(lf[12],C_text("chicken.csi#chop-separator"));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8284,a[2]=t3,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=t6,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* csi.scm:1050: collect-options */
t10=((C_word*)((C_word*)t0)[11])[1];
f_7630(t10,t9,lf[339]);}

/* k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in ... */
static void C_ccall f_7845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_7845,2,av);}
a=C_alloc(9);
t2=C_mutate((C_word*)lf[126]+1 /* (set! ##sys#include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=C_i_cdr(((C_word*)t0)[9]);
t5=C_i_pairp(t4);
if(C_truep(C_i_not(t5))){
/* csi.scm:1057: ##sys#error */
t6=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=lf[331];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=C_i_cadr(((C_word*)t0)[9]);
if(C_truep(C_i_string_equal_p(lf[332],t6))){
/* csi.scm:1059: chicken.base#keyword-style */
t7=C_fast_retrieve(lf[128]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=lf[333];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t7=C_u_i_cdr(((C_word*)t0)[9]);
t8=C_u_i_car(t7);
if(C_truep(C_i_string_equal_p(lf[334],t8))){
/* csi.scm:1061: chicken.base#keyword-style */
t9=C_fast_retrieve(lf[128]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t3;
av2[2]=lf[323];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t9=C_u_i_cdr(((C_word*)t0)[9]);
t10=C_u_i_car(t9);
if(C_truep(C_i_string_equal_p(lf[335],t10))){
/* csi.scm:1063: chicken.base#keyword-style */
t11=C_fast_retrieve(lf[128]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t3;
av2[2]=lf[336];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t11=t3;{
C_word *av2=av;
av2[0]=t11;
av2[1]=C_SCHEME_UNDEFINED;
f_7848(2,av2);}}}}}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_7848(2,av2);}}}

/* k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in ... */
static void C_ccall f_7848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_7848,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8210,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1064: member* */
f_7358(t3,lf[330],((C_word*)((C_word*)t0)[6])[1]);}

/* k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in ... */
static void C_ccall f_7851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_7851,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8198,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1067: member* */
f_7358(t3,lf[328],((C_word*)((C_word*)t0)[6])[1]);}

/* k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in ... */
static void C_ccall f_7854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_7854,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8177,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1070: member* */
f_7358(t3,lf[326],((C_word*)((C_word*)t0)[6])[1]);}

/* k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in ... */
static void C_ccall f_7857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_7857,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_a_i_cons(&a,2,lf[319],C_fast_retrieve(lf[320]));
/* csi.scm:1079: scheme#eval */
t4=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in ... */
static void C_ccall f_7860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_7860,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_a_i_cons(&a,2,lf[289],C_fast_retrieve(lf[318]));
/* csi.scm:1080: scheme#eval */
t4=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in ... */
static void C_ccall f_7863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_7863,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_7866(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8163,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1082: chicken.load#load-verbose */
t4=C_fast_retrieve(lf[317]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in ... */
static void C_ccall f_7866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_7866,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:1084: member* */
f_7358(t3,lf[313],((C_word*)((C_word*)t0)[6])[1]);}

/* k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in ... */
static void C_ccall f_7869(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_7869,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_set_block_item(lf[6] /* ##sys#notices-enabled */,0,C_SCHEME_FALSE);
t4=t2;
f_7872(t4,t3);}
else{
t3=t2;
f_7872(t3,C_SCHEME_UNDEFINED);}}

/* k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in ... */
static void C_fcall f_7872(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_7872,2,t0,t1);}
a=C_alloc(8);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7877,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7877(t5,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1]);}

/* doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in ... */
static void C_fcall f_7877(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(17,0,4)))){
C_save_and_reclaim_args((void *)trf_7877,3,t0,t1,t2);}
a=C_alloc(17);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[2])){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_fast_retrieve(lf[275]);
t5=C_mutate((C_word*)lf[275]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4232,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[277]+1 /* (set! ##sys#sharp-number-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4261,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9399,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1092: chicken.repl#repl */
t8=C_fast_retrieve(lf[278]);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=C_retrieve2(lf[47],C_text("chicken.csi#csi-eval"));
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}}
else{
t4=C_i_car(((C_word*)t3)[1]);
t5=C_i_member(t4,lf[279]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7905,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=C_i_cdr(((C_word*)t3)[1]);
t20=t1;
t21=t7;
t1=t20;
t2=t21;
goto loop;}
else{
if(C_truep((C_truep(C_i_equalp(t4,lf[280]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[281]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[282]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[283]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[284]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[285]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[286]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))){
t7=C_i_cdr(((C_word*)t3)[1]);
t8=C_set_block_item(t3,0,t7);
t9=C_i_cdr(((C_word*)t3)[1]);
t20=t1;
t21=t9;
t1=t20;
t2=t21;
goto loop;}
else{
t7=C_i_string_equal_p(lf[287],t4);
t8=(C_truep(t7)?t7:C_u_i_string_equal_p(lf[288],t4));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7934,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7946,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=C_i_cadr(((C_word*)t3)[1]);
/* csi.scm:1099: scheme#string->symbol */
t12=*((C_word*)lf[290]+1);{
C_word av2[3];
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t9=C_u_i_string_equal_p(lf[291],t4);
t10=(C_truep(t9)?t9:C_u_i_string_equal_p(lf[292],t4));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7961,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t12=C_i_cadr(((C_word*)t3)[1]);
/* csi.scm:1102: evalstring */
f_7742(t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=C_u_i_string_equal_p(lf[293],t4);
t12=(C_truep(t11)?t11:C_u_i_string_equal_p(lf[294],t4));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7980,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t14=C_i_cadr(((C_word*)t3)[1]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7990,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1105: evalstring */
f_7742(t13,t14,C_a_i_list(&a,1,t15));}
else{
t13=C_u_i_string_equal_p(lf[296],t4);
t14=(C_truep(t13)?t13:C_u_i_string_equal_p(lf[297],t4));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8005,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t16=C_i_cadr(((C_word*)t3)[1]);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8015,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1108: evalstring */
f_7742(t15,t16,C_a_i_list(&a,1,t17));}
else{
t15=(C_truep(((C_word*)t0)[5])?C_i_car(((C_word*)t0)[5]):C_SCHEME_FALSE);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8025,a[2]=t16,a[3]=t6,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_equalp(lf[301],t16))){
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8077,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1112: scheme#load */
t19=*((C_word*)lf[64]+1);{
C_word av2[4];
av2[0]=t19;
av2[1]=t17;
av2[2]=t4;
av2[3]=t18;
((C_proc)(void*)(*((C_word*)t19+1)))(4,av2);}}
else{
/* csi.scm:1112: scheme#load */
t18=*((C_word*)lf[64]+1);{
C_word av2[4];
av2[0]=t18;
av2[1]=t17;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t18+1)))(4,av2);}}}}}}}}}}

/* k7903 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_7905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7905,2,av);}
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_7877(t3,((C_word*)t0)[4],t2);}

/* k7932 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_7934(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7934,2,av);}
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_7877(t5,((C_word*)t0)[4],t4);}

/* k7944 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_7946(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_7946,2,av);}
a=C_alloc(6);
t2=C_a_i_list(&a,2,lf[289],t1);
/* csi.scm:1099: scheme#eval */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7959 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_7961(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7961,2,av);}
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_7877(t5,((C_word*)t0)[4],t4);}

/* k7978 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_7980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7980,2,av);}
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_7877(t5,((C_word*)t0)[4],t4);}

/* a7989 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_7990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,4)))){
C_save_and_reclaim((void*)f_7990,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t1;
av2[2]=*((C_word*)lf[295]+1);
av2[3]=*((C_word*)lf[106]+1);
av2[4]=t2;
C_apply(5,av2);}}

/* k8003 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_8005(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8005,2,av);}
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_7877(t5,((C_word*)t0)[4],t4);}

/* a8014 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_8015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,4)))){
C_save_and_reclaim((void*)f_8015,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t1;
av2[2]=*((C_word*)lf[295]+1);
av2[3]=C_fast_retrieve(lf[45]);
av2[4]=t2;
C_apply(5,av2);}}

/* k8023 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_8025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_8025,2,av);}
a=C_alloc(4);
if(C_truep(C_i_equalp(lf[298],((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8036,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8049,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1129: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[5])[1];
f_7877(t3,((C_word*)t0)[6],t2);}}

/* a8035 in k8023 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in ... */
static void C_ccall f_8036(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8036,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8040,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1129: scheme#eval */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[300];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8038 in a8035 in k8023 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in ... */
static void C_ccall f_8040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_8040,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8047,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1129: chicken.process-context#command-line-arguments */
t4=C_fast_retrieve(lf[299]);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k8045 in k8038 in a8035 in k8023 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in ... */
static void C_ccall f_8047(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8047,2,av);}
/* csi.scm:1129: g2063 */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* a8048 in k8023 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in ... */
static void C_ccall f_8049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,2)))){
C_save_and_reclaim((void*)f_8049,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
if(C_truep(C_fixnump(t4))){
/* csi.scm:1131: chicken.base#exit */
t5=C_fast_retrieve(lf[48]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* csi.scm:1131: chicken.base#exit */
t5=C_fast_retrieve(lf[48]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* f_8077 in doloop1851 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in ... */
static void C_ccall f_8077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_8077,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8081,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8132,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1116: chicken.port#with-output-to-string */
t5=C_fast_retrieve(lf[306]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8079 */
static void C_ccall f_8081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_8081,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_block_size(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:1118: chicken.base#flush-output */
t6=*((C_word*)lf[305]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=*((C_word*)lf[83]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k8085 in k8079 */
static void C_ccall f_8087(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_8087,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:1119: scheme#display */
t3=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[304];
av2[3]=*((C_word*)lf[302]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k8088 in k8085 in k8079 */
static void C_ccall f_8090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_8090,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8101,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8101(t6,t2,C_fix(0));}

/* k8091 in k8088 in k8085 in k8079 */
static void C_ccall f_8093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_8093,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1126: scheme#newline */
t3=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[302]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8094 in k8091 in k8088 in k8085 in k8079 */
static void C_ccall f_8096(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8096,2,av);}
/* csi.scm:1127: scheme#eval */
t2=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* doloop2052 in k8088 in k8085 in k8079 */
static void C_fcall f_8101(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_8101,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_i_string_ref(((C_word*)t0)[3],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8114,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#write-char/port */
t6=C_fast_retrieve(lf[248]);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
av2[3]=*((C_word*)lf[302]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* k8112 in doloop2052 in k8088 in k8085 in k8079 */
static void C_ccall f_8114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_8114,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_u_i_char_equalp(C_make_character(10),((C_word*)t0)[5]))){
/* csi.scm:1125: scheme#display */
t3=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[303];
av2[3]=*((C_word*)lf[302]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8101(t4,((C_word*)t0)[4],t3);}}

/* k8115 in k8112 in doloop2052 in k8088 in k8085 in k8079 */
static void C_ccall f_8117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8117,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8101(t3,((C_word*)t0)[4],t2);}

/* a8131 */
static void C_ccall f_8132(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8132,2,av);}
t2=C_fast_retrieve(lf[45]);
/* csi.scm:1116: g2049 */
t3=C_fast_retrieve(lf[45]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8149 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in ... */
static void C_ccall f_8151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8151,2,av);}
a=C_alloc(3);
t2=(C_truep(t1)?t1:(C_truep(((C_word*)t0)[2])?((C_word*)t0)[2]:((C_word*)t0)[3]));
if(C_truep(t2)){
t3=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_7869(2,av2);}}
else{
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7681,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1012: chicken.platform#system-config-directory */
t5=C_fast_retrieve(lf[312]);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k8161 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in ... */
static void C_ccall f_8163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8163,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9440,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:145: chicken.platform#chicken-version */
t4=C_fast_retrieve(lf[316]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k8175 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in ... */
static void C_ccall f_8177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8177,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_8180(2,av2);}}
else{
/* csi.scm:1071: scheme#display */
t3=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[325];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_7857(2,av2);}}}

/* k8178 in k8175 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in ... */
static void C_ccall f_8180(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8180,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8183,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1072: chicken.base#case-sensitive */
t3=C_fast_retrieve(lf[324]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8181 in k8178 in k8175 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in ... */
static void C_ccall f_8183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8183,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1073: chicken.base#keyword-style */
t3=C_fast_retrieve(lf[128]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[323];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8184 in k8181 in k8178 in k8175 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in ... */
static void C_ccall f_8186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8186,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8189,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1074: chicken.base#parentheses-synonyms */
t3=C_fast_retrieve(lf[322]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8187 in k8184 in k8181 in k8178 in k8175 in k7852 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in ... */
static void C_ccall f_8189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8189,2,av);}
/* csi.scm:1075: chicken.base#symbol-escape */
t2=C_fast_retrieve(lf[321]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8196 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in ... */
static void C_ccall f_8198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8198,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8201,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* csi.scm:1069: chicken.base#symbol-escape */
t3=C_fast_retrieve(lf[321]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* csi.scm:1068: scheme#display */
t3=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[327];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_7854(2,av2);}}}

/* k8199 in k8196 in k7849 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in ... */
static void C_ccall f_8201(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8201,2,av);}
/* csi.scm:1069: chicken.base#symbol-escape */
t2=C_fast_retrieve(lf[321]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8208 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in ... */
static void C_ccall f_8210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8210,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8213,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* csi.scm:1066: chicken.base#parentheses-synonyms */
t3=C_fast_retrieve(lf[322]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* csi.scm:1065: scheme#display */
t3=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[329];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_7851(2,av2);}}}

/* k8211 in k8208 in k7846 in k7843 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in ... */
static void C_ccall f_8213(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8213,2,av);}
/* csi.scm:1066: chicken.base#parentheses-synonyms */
t2=C_fast_retrieve(lf[322]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8275 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in ... */
static void C_ccall f_8277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_8277,2,av);}
a=C_alloc(6);
t2=*((C_word*)lf[337]+1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3122,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3122(t6,((C_word*)t0)[2],t1);}

/* k8282 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in ... */
static void C_ccall f_8284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_8284,2,av);}
a=C_alloc(13);
t2=C_i_check_list_2(t1,lf[138]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8339,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_8339(t7,t3,t1);}

/* k8288 in k8282 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in ... */
static void C_ccall f_8290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_8290,2,av);}
a=C_alloc(13);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_retrieve2(lf[12],C_text("chicken.csi#chop-separator"));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8297,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t7,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* csi.scm:1051: collect-options */
t9=((C_word*)((C_word*)t0)[4])[1];
f_7630(t9,t8,lf[338]);}

/* k8295 in k8288 in k8282 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in ... */
static void C_ccall f_8297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_8297,2,av);}
a=C_alloc(13);
t2=C_i_check_list_2(t1,lf[138]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8305,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_8305(t7,t3,t1);}

/* k8301 in k8295 in k8288 in k8282 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in ... */
static void C_ccall f_8303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_8303,2,av);}
/* csi.scm:1050: scheme#append */
t2=*((C_word*)lf[229]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
av2[4]=C_fast_retrieve(lf[126]);
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* map-loop1951 in k8295 in k8288 in k8282 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in ... */
static void C_fcall f_8305(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8305,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8330,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1051: g1957 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8328 in map-loop1951 in k8295 in k8288 in k8282 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in ... */
static void C_ccall f_8330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8330,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8305(t6,((C_word*)t0)[5],t5);}

/* map-loop1925 in k8282 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in ... */
static void C_fcall f_8339(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8339,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8364,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1050: g1931 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8362 in map-loop1925 in k8282 in k7839 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in ... */
static void C_ccall f_8364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8364,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8339(t6,((C_word*)t0)[5],t5);}

/* for-each-loop1843 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in ... */
static void C_fcall f_8373(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_8373,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8383,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1047: g1844 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8381 in for-each-loop1843 in k7833 in k7830 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in ... */
static void C_ccall f_8383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8383,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8373(t3,((C_word*)t0)[4],t2);}

/* for-each-loop1833 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in ... */
static void C_fcall f_8396(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_8396,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8406,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1046: g1834 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8404 in for-each-loop1833 in k7824 in k7821 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in ... */
static void C_ccall f_8406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8406,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8396(t3,((C_word*)t0)[4],t2);}

/* for-each-loop1823 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in ... */
static void C_fcall f_8419(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_8419,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8429,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1045: g1824 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8427 in for-each-loop1823 in k7815 in k7812 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in ... */
static void C_ccall f_8429(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8429,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8419(t3,((C_word*)t0)[4],t2);}

/* k8441 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in ... */
static void C_ccall f_8443(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_8443,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8446,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9458,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1043: chicken.platform#register-feature! */
t4=C_fast_retrieve(lf[273]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[343];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* csi.scm:1042: scheme#display */
t3=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[344];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_7814(2,av2);}}}

/* k8444 in k8441 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in ... */
static void C_ccall f_8446(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8446,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8449,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1043: chicken.platform#register-feature! */
t3=C_fast_retrieve(lf[273]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[343];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8447 in k8444 in k8441 in k7809 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in ... */
static void C_ccall f_8449(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8449,2,av);}
/* csi.scm:1044: chicken.base#case-sensitive */
t2=C_fast_retrieve(lf[324]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8456 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in ... */
static void C_ccall f_8458(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8458,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8461,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=C_set_block_item(lf[346] /* ##sys#warnings-enabled */,0,C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
f_7811(t4,t3);}
else{
/* csi.scm:1039: scheme#display */
t3=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[347];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[2];
f_7811(t2,C_SCHEME_UNDEFINED);}}

/* k8459 in k8456 in k7806 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in ... */
static void C_ccall f_8461(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8461,2,av);}
t2=C_set_block_item(lf[346] /* ##sys#warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_7811(t3,t2);}

/* k8469 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in ... */
static void C_ccall f_8471(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8471,2,av);}
/* csi.scm:1037: chicken.base#exit */
t2=C_fast_retrieve(lf[48]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8476 in k7803 in k7800 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in ... */
static void C_ccall f_8478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8478,2,av);}
/* csi.scm:1036: chicken.base#print */
t2=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8486 in k7797 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in ... */
static void C_ccall f_8488(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8488,2,av);}
/* csi.scm:1032: chicken.base#exit */
t2=C_fast_retrieve(lf[48]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8492 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_ccall f_8494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_8494,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8497,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3853,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:96: scheme#display */
t5=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[357];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_7799(2,av2);}}}

/* k8495 in k8492 in k7626 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in ... */
static void C_ccall f_8497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8497,2,av);}
/* csi.scm:1029: chicken.base#exit */
t2=C_fast_retrieve(lf[48]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop1791 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in ... */
static void C_fcall f_8502(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8502,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8527,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1000: g1797 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8525 in map-loop1791 in k7620 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in ... */
static void C_ccall f_8527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8527,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8502(t6,((C_word*)t0)[5],t5);}

/* k8536 in k7614 in k7611 in k7608 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in ... */
static void C_ccall f_8538(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8538,2,av);}
if(C_truep(t1)){
t2=t1;
/* csi.scm:1001: ##sys#split-path */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[21]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[21]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
tp(3,av2);}}
else{
/* csi.scm:1001: ##sys#split-path */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[21]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[21]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[359];
tp(3,av2);}}}

/* k8545 in k7605 in k7602 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_8547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8547,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_7610(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7610(t2,((C_word*)t0)[3]);}}

/* k8551 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_8553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_8553,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:984: chicken.process-context#program-name */
t4=C_fast_retrieve(lf[365]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k8554 in k8551 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in ... */
static void C_ccall f_8556(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_8556,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_u_i_cdr(t3);
/* csi.scm:985: chicken.process-context#command-line-arguments */
t5=C_fast_retrieve(lf[299]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8557 in k8554 in k8551 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in ... */
static void C_ccall f_8559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_8559,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:987: chicken.platform#register-feature! */
t3=C_fast_retrieve(lf[273]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[364];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8560 in k8557 in k8554 in k8551 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in ... */
static void C_ccall f_8562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_8562,2,av);}
a=C_alloc(4);
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_i_set_i_slot(t2,C_fix(1),C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[11]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:990: lookup-script-file */
t6=C_retrieve2(lf[17],C_text("chicken.csi#lookup-script-file"));
f_3999(t6,t4,t5);}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];
f_7604(t5,t4);}}

/* k8569 in k8560 in k8557 in k8554 in k8551 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in ... */
static void C_ccall f_8571(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8571,2,av);}
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_7604(t3,C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[3];
f_7604(t2,C_SCHEME_FALSE);}}

/* k8634 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_8636(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8636,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_member(lf[367],((C_word*)((C_word*)t0)[2])[1]);
t4=((C_word*)t0)[3];
f_7604(t4,(C_truep(t3)?C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k8647 in k7599 in k7596 in k7593 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in ... */
static void C_ccall f_8649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8649,2,av);}
/* csi.scm:993: scheme#append */
t2=*((C_word*)lf[229]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8651 in k7590 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_8653(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8653,2,av);}
/* csi.scm:975: canonicalize-args */
f_7413(((C_word*)t0)[2],t1);}

/* k8655 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8657(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_8657,2,av);}
a=C_alloc(4);
t2=(C_truep(t1)?t1:lf[370]);
t3=((C_word*)t0)[2];
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4922,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:436: chicken.base#open-input-string */
t6=C_fast_retrieve(lf[272]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k8661 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8663(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8663,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8669,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.base#implicit-exit-handler */
t3=C_fast_retrieve(lf[269]);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8667 in k8661 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_8669(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8669,2,av);}
t2=t1;{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a8670 in k5388 in k5059 in k4914 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8671,3,av);}
/* csi.scm:916: ##sys#user-interrupt-hook */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[257]);
C_word *av2=av;
av2[0]=*((C_word*)lf[257]+1);
av2[1]=t1;
tp(2,av2);}}

/* a8676 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8677,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8681,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:420: scheme#read */
t3=*((C_word*)lf[51]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8679 in a8676 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8681(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_8681,2,av);}
a=C_alloc(7);
t2=t1;
if(C_truep(C_i_not(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8690,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:422: ##sys#switch-module */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[381]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[381]+1);
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
tp(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8696,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8717,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:424: ##sys#resolve-module-name */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[385]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[385]+1);
av2[1]=t4;
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
tp(4,av2);}}}

/* k8688 in k8679 in a8676 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8690,2,av);}
/* csi.scm:423: printf */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[380];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8694 in k8679 in a8676 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_8696,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:421: g989 */
t3=t2;
f_8700(t3,((C_word*)t0)[3],t1);}
else{
/* csi.scm:429: printf */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[383];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* g989 in k8694 in k8679 in a8676 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_fcall f_8700(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_8700,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8704,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:426: ##sys#switch-module */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[381]);
C_word av2[3];
av2[0]=*((C_word*)lf[381]+1);
av2[1]=t3;
av2[2]=t2;
tp(3,av2);}}

/* k8702 in g989 in k8694 in k8679 in a8676 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in ... */
static void C_ccall f_8704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8704,2,av);}
/* csi.scm:427: printf */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[382];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8715 in k8679 in a8676 in k4270 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8717,2,av);}
/* csi.scm:424: ##sys#find-module */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[384]);
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[384]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
tp(4,av2);}}

/* a8718 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8719(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8719,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8727,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:251: ##sys#current-module */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[392]);
C_word *av2=av;
av2[0]=*((C_word*)lf[392]+1);
av2[1]=t2;
tp(2,av2);}}

/* k8725 in a8718 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_8727,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8730,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8737,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:253: ##sys#module-name */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[390]);
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[390]+1);
av2[1]=t3;
av2[2]=t1;
tp(3,av2);}}
else{
/* csi.scm:250: sprintf */
t3=*((C_word*)lf[194]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[388];
av2[3]=lf[391];
av2[4]=C_retrieve2(lf[26],C_text("chicken.csi#history-count"));
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k8728 in k8725 in a8718 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8730,2,av);}
/* csi.scm:250: sprintf */
t2=*((C_word*)lf[194]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[388];
av2[3]=t1;
av2[4]=C_retrieve2(lf[26],C_text("chicken.csi#history-count"));
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k8735 in k8725 in a8718 in k3927 in k3845 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8737,2,av);}
/* csi.scm:253: sprintf */
t2=*((C_word*)lf[194]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[389];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8739 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8741(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8741,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_3847(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8750,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:88: chicken.process-context#get-environment-variable */
t3=C_fast_retrieve(lf[23]);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[397];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k8748 in k8739 in k3842 in k3837 in k2547 in k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in k2520 in k2517 in k2514 */
static void C_ccall f_8750(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8750,2,av);}
t2=((C_word*)t0)[2];
f_3847(t2,(C_truep(t1)?lf[395]:lf[396]));}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point

void C_ccall C_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void*)C_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(1952))){
C_save(t1);
C_rereclaim2(1952*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,404);
lf[0]=C_h_intern(&lf[0],12, C_text("chicken.csi#"));
lf[2]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005csirc"));
lf[3]=C_h_intern(&lf[3],29, C_text("##sys#repl-print-length-limit"));
lf[4]=C_h_intern_kw(&lf[4],3, C_text("csi"));
lf[5]=C_h_intern(&lf[5],14, C_text("##sys#features"));
lf[6]=C_h_intern(&lf[6],21, C_text("##sys#notices-enabled"));
lf[7]=C_h_intern(&lf[7],26, C_text("chicken.csi#editor-command"));
lf[11]=C_h_intern(&lf[11],22, C_text("##sys#windows-platform"));
lf[13]=C_h_intern(&lf[13],16, C_text("scheme#substring"));
lf[14]=C_h_intern(&lf[14],25, C_text("chicken.file#file-exists\077"));
lf[15]=C_h_intern(&lf[15],19, C_text("##sys#string-append"));
lf[16]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004.bat"));
lf[18]=C_h_intern(&lf[18],20, C_text("scheme#string-append"));
lf[19]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001/"));
lf[20]=C_h_intern(&lf[20],27, C_text("##sys#peek-nonnull-c-string"));
lf[21]=C_h_intern(&lf[21],16, C_text("##sys#split-path"));
lf[22]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001/"));
lf[23]=C_h_intern(&lf[23],48, C_text("chicken.process-context#get-environment-variable"));
lf[24]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004PATH"));
lf[27]=C_h_intern(&lf[27],26, C_text("chicken.base#vector-resize"));
lf[29]=C_h_intern(&lf[29],21, C_text("##sys#undefined-value"));
lf[31]=C_h_intern(&lf[31],11, C_text("##sys#error"));
lf[32]=C_decode_literal(C_heaptop,C_text("\376B\000\000 history entry index out of range"));
lf[33]=C_h_intern(&lf[33],21, C_text("scheme#inexact->exact"));
lf[34]=C_h_intern(&lf[34],20, C_text("##sys#break-on-error"));
lf[35]=C_h_intern(&lf[35],22, C_text("##sys#read-prompt-hook"));
lf[36]=C_h_intern(&lf[36],15, C_text("##sys#tty-port\077"));
lf[37]=C_h_intern(&lf[37],20, C_text("##sys#standard-input"));
lf[39]=C_h_intern(&lf[39],28, C_text("chicken.csi#toplevel-command"));
lf[40]=C_h_intern(&lf[40],16, C_text("toplevel-command"));
lf[41]=C_h_intern(&lf[41],25, C_text("chicken.load#load-noisily"));
lf[42]=C_h_intern(&lf[42],20, C_text("chicken.io#read-line"));
lf[43]=C_h_intern(&lf[43],27, C_text("chicken.string#string-split"));
lf[44]=C_h_intern(&lf[44],21, C_text("chicken.syntax#expand"));
lf[45]=C_h_intern(&lf[45],33, C_text("chicken.pretty-print#pretty-print"));
lf[46]=C_h_intern(&lf[46],13, C_text("scheme#values"));
lf[48]=C_h_intern(&lf[48],17, C_text("chicken.base#exit"));
lf[49]=C_h_intern(&lf[49],1, C_text("x"));
lf[50]=C_h_intern(&lf[50],27, C_text("chicken.syntax#strip-syntax"));
lf[51]=C_h_intern(&lf[51],11, C_text("scheme#read"));
lf[52]=C_h_intern(&lf[52],1, C_text("p"));
lf[53]=C_h_intern(&lf[53],11, C_text("scheme#eval"));
lf[54]=C_h_intern(&lf[54],1, C_text("d"));
lf[56]=C_h_intern(&lf[56],2, C_text("du"));
lf[58]=C_h_intern(&lf[58],3, C_text("dur"));
lf[59]=C_h_intern(&lf[59],1, C_text("r"));
lf[61]=C_h_intern(&lf[61],1, C_text("q"));
lf[62]=C_h_intern(&lf[62],17, C_text("chicken.repl#quit"));
lf[63]=C_h_intern(&lf[63],1, C_text("l"));
lf[64]=C_h_intern(&lf[64],11, C_text("scheme#load"));
lf[65]=C_h_intern(&lf[65],2, C_text("ln"));
lf[66]=C_h_intern(&lf[66],19, C_text("chicken.base#print\052"));
lf[67]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004==> "));
lf[68]=C_h_intern_kw(&lf[68],7, C_text("printer"));
lf[69]=C_h_intern(&lf[69],1, C_text("t"));
lf[70]=C_h_intern(&lf[70],19, C_text("##sys#display-times"));
lf[71]=C_h_intern(&lf[71],16, C_text("##sys#stop-timer"));
lf[72]=C_h_intern(&lf[72],17, C_text("##sys#start-timer"));
lf[73]=C_h_intern(&lf[73],3, C_text("exn"));
lf[74]=C_h_intern(&lf[74],20, C_text("##sys#last-exception"));
lf[75]=C_h_intern(&lf[75],1, C_text("e"));
lf[76]=C_h_intern(&lf[76],21, C_text("chicken.format#printf"));
lf[77]=C_decode_literal(C_heaptop,C_text("\376B\000\000,editor returned with non-zero exit status ~a"));
lf[78]=C_h_intern(&lf[78],22, C_text("chicken.process#system"));
lf[79]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001 "));
lf[80]=C_h_intern(&lf[80],2, C_text("ch"));
lf[81]=C_h_intern(&lf[81],19, C_text("scheme#vector-fill!"));
lf[82]=C_h_intern(&lf[82],1, C_text("h"));
lf[83]=C_h_intern(&lf[83],21, C_text("##sys#standard-output"));
lf[84]=C_h_intern(&lf[84],6, C_text("printf"));
lf[85]=C_h_intern(&lf[85],14, C_text("scheme#newline"));
lf[86]=C_h_intern(&lf[86],11, C_text("##sys#print"));
lf[87]=C_h_intern(&lf[87],29, C_text("##sys#with-print-length-limit"));
lf[88]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002: "));
lf[89]=C_h_intern(&lf[89],18, C_text("##sys#write-char-0"));
lf[90]=C_h_intern(&lf[90],1, C_text("c"));
lf[92]=C_h_intern(&lf[92],1, C_text("f"));
lf[93]=C_h_intern(&lf[93],14, C_text("scheme#display"));
lf[94]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016no such frame\012"));
lf[95]=C_h_intern(&lf[95],28, C_text("##sys#repl-recent-call-chain"));
lf[96]=C_h_intern(&lf[96],1, C_text("g"));
lf[97]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027no environment in frame"));
lf[98]=C_h_intern(&lf[98],9, C_text("frameinfo"));
lf[99]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012; getting "));
lf[100]=C_h_intern(&lf[100],8, C_text("for-each"));
lf[101]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022no such variable: "));
lf[102]=C_h_intern(&lf[102],20, C_text("chicken.base#call/cc"));
lf[103]=C_decode_literal(C_heaptop,C_text("\376B\000\000#string or symbol required for `,g\047\012"));
lf[104]=C_h_intern(&lf[104],1, C_text("s"));
lf[105]=C_h_intern(&lf[105],1, C_text("\077"));
lf[106]=C_h_intern(&lf[106],18, C_text("chicken.base#print"));
lf[107]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002 ,"));
lf[108]=C_decode_literal(C_heaptop,C_text("\376B\000\003\266Toplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,h            "
"    Show history of expression results\012 ,ch               Clear history of expre"
"ssion results\012 ,e FILENAME       Run external editor\012 ,s TEXT ...       Execute "
"shell-command\012 ,exn              Describe last exception\012 ,c                Show"
" call-chain of most recent error\012 ,f N              Select frame N\012 ,g NAME     "
"      Get variable NAME from current frame\012 ,t EXP            Evaluate form and "
"print elapsed time\012 ,x EXP            Pretty print expanded expression EXP\012"));
lf[109]=C_decode_literal(C_heaptop,C_text("\376B\000\0005undefined toplevel command ~s - enter `,\077\047 for help~%"));
lf[110]=C_h_intern(&lf[110],7, C_text("unquote"));
lf[111]=C_h_intern(&lf[111],17, C_text("chicken.sort#sort"));
lf[112]=C_h_intern(&lf[112],32, C_text("chicken.port#with-output-to-port"));
lf[113]=C_h_intern(&lf[113],28, C_text("chicken.process-context#argv"));
lf[114]=C_h_intern(&lf[114],15, C_text("scheme#truncate"));
lf[115]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\012"));
lf[116]=C_h_intern(&lf[116],18, C_text("scheme#make-string"));
lf[117]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004  ~a"));
lf[118]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027interrupts are enabled\012"));
lf[119]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010(64-bit)"));
lf[120]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[121]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010 (fixed)"));
lf[122]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[123]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010downward"));
lf[124]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006upward"));
lf[125]=C_decode_literal(C_heaptop,C_text("\376B\000\002\354~%~%~\012                   Machine type:    \011~A ~A~%~\012                   Soft"
"ware type:   \011~A~%~\012                   Software version:\011~A~%~\012                 "
"  Build platform:  \011~A~%~\012                   Installation prefix:\011~A~%~\012        "
"           Extension installation location:\011~A~%~\012                   Extension p"
"ath:  \011~A~%~\012                   Include path:    \011~A~%~\012                   Keywo"
"rd style:   \011~A~%~\012                   Symbol-table load:\011~S~%  ~\012               "
"      Avg bucket length:\011~S~%  ~\012                     Total symbol count:\011~S~%~\012"
"                   Memory:\011heap size is ~S bytes~A with ~S bytes currently in us"
"e~%~  \012                     nursery size is ~S bytes, stack grows ~A~%~\012        "
"           Command line:    \011~S~%"));
lf[126]=C_h_intern(&lf[126],23, C_text("##sys#include-pathnames"));
lf[127]=C_h_intern(&lf[127],21, C_text("scheme#symbol->string"));
lf[128]=C_h_intern(&lf[128],26, C_text("chicken.base#keyword-style"));
lf[129]=C_h_intern(&lf[129],32, C_text("chicken.platform#repository-path"));
lf[130]=C_h_intern(&lf[130],40, C_text("chicken.platform#installation-repository"));
lf[131]=C_h_intern(&lf[131],31, C_text("chicken.platform#build-platform"));
lf[132]=C_h_intern(&lf[132],33, C_text("chicken.platform#software-version"));
lf[133]=C_h_intern(&lf[133],30, C_text("chicken.platform#software-type"));
lf[134]=C_h_intern(&lf[134],25, C_text("chicken.platform#feature\077"));
lf[135]=C_h_intern_kw(&lf[135],5, C_text("64bit"));
lf[136]=C_h_intern(&lf[136],29, C_text("chicken.platform#machine-type"));
lf[137]=C_h_intern(&lf[137],31, C_text("chicken.keyword#keyword->string"));
lf[138]=C_h_intern(&lf[138],3, C_text("map"));
lf[139]=C_h_intern(&lf[139],15, C_text("scheme#string<\077"));
lf[140]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015Features:~%~%"));
lf[141]=C_h_intern(&lf[141],28, C_text("chicken.gc#memory-statistics"));
lf[142]=C_h_intern(&lf[142],23, C_text("##sys#symbol-table-info"));
lf[143]=C_h_intern(&lf[143],13, C_text("chicken.gc#gc"));
lf[145]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017\001u8vector-le"
"ngth\376\003\000\000\002\376\001\000\000\014\001u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001s8vector\376\003\000\000\002\376B\000\000\026vector of signed"
" bytes\376\003\000\000\002\376\001\000\000\017\001s8vector-length\376\003\000\000\002\376\001\000\000\014\001s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001u16vec"
"tor\376\003\000\000\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020\001u16vector-length\376\003\000\000\002\376\001\000\000"
"\015\001u16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit wor"
"ds\376\003\000\000\002\376\001\000\000\020\001s16vector-length\376\003\000\000\002\376\001\000\000\015\001s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001u32vecto"
"r\376\003\000\000\002\376B\000\000\037vector of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020\001u32vector-length\376\003\000\000\002\376\001\000\000\015\001"
"u32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words"
"\376\003\000\000\002\376\001\000\000\020\001s32vector-length\376\003\000\000\002\376\001\000\000\015\001s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001u64vector\376"
"\003\000\000\002\376B\000\000\037vector of unsigned 64-bit words\376\003\000\000\002\376\001\000\000\020\001u64vector-length\376\003\000\000\002\376\001\000\000\015\001u6"
"4vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001s64vector\376\003\000\000\002\376B\000\000\035vector of signed 64-bit words\376\003"
"\000\000\002\376\001\000\000\020\001s64vector-length\376\003\000\000\002\376\001\000\000\015\001s64vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001f32vector\376\003\000"
"\000\002\376B\000\000\027vector of 32-bit floats\376\003\000\000\002\376\001\000\000\020\001f32vector-length\376\003\000\000\002\376\001\000\000\015\001f32vector-re"
"f\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020\001f64vect"
"or-length\376\003\000\000\002\376\001\000\000\015\001f64vector-ref\376\377\016\376\377\016"));
lf[147]=C_h_intern(&lf[147],13, C_text("scheme#length"));
lf[148]=C_h_intern(&lf[148],15, C_text("scheme#list-ref"));
lf[149]=C_h_intern(&lf[149],17, C_text("scheme#string-ref"));
lf[150]=C_h_intern(&lf[150],22, C_text("chicken.format#fprintf"));
lf[151]=C_decode_literal(C_heaptop,C_text("\376B\000\000 ~% (~A elements not displayed)~%"));
lf[152]=C_decode_literal(C_heaptop,C_text("\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%"));
lf[153]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[154]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001s"));
lf[155]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007 ~S: ~S"));
lf[156]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021~A of length ~S~%"));
lf[157]=C_decode_literal(C_heaptop,C_text("\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%"));
lf[158]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016boolean true~%"));
lf[159]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017boolean false~%"));
lf[160]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014empty list~%"));
lf[161]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024end-of-file object~%"));
lf[162]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024unspecified object~%"));
lf[163]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016, character ~S"));
lf[164]=C_decode_literal(C_heaptop,C_text("\376B\000\0002exact immediate integer ~S~%  #x~X~%  #o~O~%  #b~B"));
lf[165]=C_decode_literal(C_heaptop,C_text("\376B\000\0000exact large integer ~S~%  #x~X~%  #o~O~%  #b~B~%"));
lf[166]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017unbound value~%"));
lf[167]=C_decode_literal(C_heaptop,C_text("\376B\000\000\034inexact rational number ~S~%"));
lf[168]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020exact ratio ~S~%"));
lf[169]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026~A complex number ~S~%"));
lf[170]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005exact"));
lf[171]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007inexact"));
lf[172]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013number ~S~%"));
lf[173]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006string"));
lf[174]=C_h_intern(&lf[174],10, C_text("##sys#size"));
lf[175]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006vector"));
lf[176]=C_h_intern(&lf[176],10, C_text("##sys#slot"));
lf[177]=C_decode_literal(C_heaptop,C_text("\376B\000\000\035keyword symbol with name ~s~%"));
lf[178]=C_h_intern(&lf[178],20, C_text("##sys#symbol->string"));
lf[179]=C_h_intern(&lf[179],12, C_text("scheme#write"));
lf[180]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005  ~s\011"));
lf[181]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020  \012properties:\012\012"));
lf[182]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[183]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013uninterned "));
lf[184]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027~asymbol with name ~S~%"));
lf[185]=C_h_intern(&lf[185],22, C_text("##sys#interned-symbol\077"));
lf[186]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010unbound "));
lf[187]=C_h_intern(&lf[187],34, C_text("##sys#symbol-has-toplevel-binding\077"));
lf[188]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005eol~%"));
lf[189]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012(circle)~%"));
lf[190]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006~S -> "));
lf[191]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024circular structure: "));
lf[192]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004list"));
lf[193]=C_decode_literal(C_heaptop,C_text("\376B\000\000\036pair with car ~S~%and cdr ~S~%"));
lf[194]=C_h_intern(&lf[194],22, C_text("chicken.format#sprintf"));
lf[195]=C_decode_literal(C_heaptop,C_text("\376B\000\000 procedure with code pointer 0x~X"));
lf[196]=C_h_intern(&lf[196],27, C_text("##sys#peek-unsigned-integer"));
lf[197]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005input"));
lf[198]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006output"));
lf[199]=C_decode_literal(C_heaptop,C_text("\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%"));
lf[200]=C_decode_literal(C_heaptop,C_text("\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%"));
lf[201]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004slot"));
lf[202]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004char"));
lf[203]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010u8vector"));
lf[204]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010s8vector"));
lf[205]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011u16vector"));
lf[206]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011s16vector"));
lf[207]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011u32vector"));
lf[208]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011s32vector"));
lf[209]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011u64vector"));
lf[210]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011s64vector"));
lf[211]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011f32vector"));
lf[212]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011f64vector"));
lf[213]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024machine pointer ~X~%"));
lf[215]=C_h_intern(&lf[215],10, C_text("##sys#byte"));
lf[216]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022blob of size ~S:~%"));
lf[217]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030lambda information: ~s~%"));
lf[218]=C_h_intern(&lf[218],25, C_text("##sys#lambda-info->string"));
lf[219]=C_h_intern(&lf[219],10, C_text("hash-table"));
lf[220]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013 ~S\011-> ~S~%"));
lf[221]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025  hash function: ~a~%"));
lf[222]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[223]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001s"));
lf[224]=C_decode_literal(C_heaptop,C_text("\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%"));
lf[225]=C_h_intern(&lf[225],9, C_text("condition"));
lf[226]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007\011~s: ~s"));
lf[227]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005 ~s~%"));
lf[228]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017condition: ~s~%"));
lf[229]=C_h_intern(&lf[229],13, C_text("scheme#append"));
lf[230]=C_decode_literal(C_heaptop,C_text("\376B\000\000\031structure of type `~S\047:~%"));
lf[231]=C_h_intern(&lf[231],31, C_text("chicken.internal#hash-table-ref"));
lf[232]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020unknown object~%"));
lf[233]=C_h_intern(&lf[233],17, C_text("##sys#bytevector\077"));
lf[234]=C_h_intern(&lf[234],15, C_text("##sys#locative\077"));
lf[235]=C_h_intern(&lf[235],18, C_text("chicken.base#port\077"));
lf[236]=C_h_intern(&lf[236],24, C_text("chicken.keyword#keyword\077"));
lf[237]=C_decode_literal(C_heaptop,C_text("\376B\000\000\034statically allocated (0x~X) "));
lf[238]=C_h_intern(&lf[238],19, C_text("##sys#block-address"));
lf[239]=C_h_intern(&lf[239],26, C_text("chicken.csi#set-describer!"));
lf[240]=C_h_intern(&lf[240],14, C_text("set-describer!"));
lf[241]=C_h_intern(&lf[241],32, C_text("chicken.internal#hash-table-set!"));
lf[242]=C_h_intern(&lf[242],10, C_text("scheme#min"));
lf[243]=C_h_intern(&lf[243],4, C_text("dump"));
lf[244]=C_decode_literal(C_heaptop,C_text("\376B\000\000\034cannot dump immediate object"));
lf[245]=C_h_intern(&lf[245],15, C_text("##sys#peek-byte"));
lf[246]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022cannot dump object"));
lf[247]=C_h_intern(&lf[247],20, C_text("##sys#number->string"));
lf[248]=C_h_intern(&lf[248],21, C_text("##sys#write-char/port"));
lf[249]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003   "));
lf[250]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004:\011  "));
lf[251]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002  "));
lf[252]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006  ---\012"));
lf[253]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002] "));
lf[254]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003\011  "));
lf[255]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002[]"));
lf[256]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002  "));
lf[257]=C_h_intern(&lf[257],25, C_text("##sys#user-interrupt-hook"));
lf[258]=C_h_intern(&lf[258],19, C_text("##sys#signal-vector"));
lf[261]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-s"));
lf[262]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003-ss"));
lf[263]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007-script"));
lf[264]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003-sx"));
lf[265]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002--"));
lf[266]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016invalid option"));
lf[267]=C_h_intern(&lf[267],18, C_text("##sys#string->list"));
lf[268]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000"
"\002\376B\000\000\006--help\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\013-no-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-cas"
"e-insensitive\376\003\000\000\002\376B\000\000\016-keyword-style\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000"
"\021-no-symbol-escape\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\022-require-"
"extension\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\010-no-ini"
"t\376\003\000\000\002\376B\000\000\015-include-path\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-prin"
"t\376\003\000\000\002\376B\000\000\002--\376\377\016"));
lf[269]=C_h_intern(&lf[269],34, C_text("chicken.base#implicit-exit-handler"));
lf[270]=C_decode_literal(C_heaptop,C_text("\376B\000\000\047missing argument to command-line option"));
lf[271]=C_h_intern(&lf[271],10, C_text("##sys#list"));
lf[272]=C_h_intern(&lf[272],30, C_text("chicken.base#open-input-string"));
lf[273]=C_h_intern(&lf[273],34, C_text("chicken.platform#register-feature!"));
lf[274]=C_h_intern(&lf[274],36, C_text("chicken.platform#unregister-feature!"));
lf[275]=C_h_intern(&lf[275],20, C_text("##sys#user-read-hook"));
lf[276]=C_h_intern(&lf[276],5, C_text("quote"));
lf[277]=C_h_intern(&lf[277],23, C_text("##sys#sharp-number-hook"));
lf[278]=C_h_intern(&lf[278],17, C_text("chicken.repl#repl"));
lf[279]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\002-n"
"\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-"
"insensitive\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000\000\002\376B\000"
"\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B"
"\000\000\007-script\376\377\016"));
lf[280]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-D"));
lf[281]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010-feature"));
lf[282]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-I"));
lf[283]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015-include-path"));
lf[284]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-K"));
lf[285]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016-keyword-style"));
lf[286]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013-no-feature"));
lf[287]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-R"));
lf[288]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022-require-extension"));
lf[289]=C_h_intern(&lf[289],6, C_text("import"));
lf[290]=C_h_intern(&lf[290],21, C_text("scheme#string->symbol"));
lf[291]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-e"));
lf[292]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005-eval"));
lf[293]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-p"));
lf[294]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006-print"));
lf[295]=C_h_intern(&lf[295],15, C_text("scheme#for-each"));
lf[296]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-P"));
lf[297]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015-pretty-print"));
lf[298]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003-ss"));
lf[299]=C_h_intern(&lf[299],46, C_text("chicken.process-context#command-line-arguments"));
lf[300]=C_h_intern(&lf[300],4, C_text("main"));
lf[301]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003-sx"));
lf[302]=C_h_intern(&lf[302],20, C_text("##sys#standard-error"));
lf[303]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002; "));
lf[304]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003\012; "));
lf[305]=C_h_intern(&lf[305],25, C_text("chicken.base#flush-output"));
lf[306]=C_h_intern(&lf[306],34, C_text("chicken.port#with-output-to-string"));
lf[307]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[308]=C_h_intern(&lf[308],30, C_text("chicken.pathname#make-pathname"));
lf[309]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001."));
lf[310]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004HOME"));
lf[311]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007chicken"));
lf[312]=C_h_intern(&lf[312],40, C_text("chicken.platform#system-config-directory"));
lf[313]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016"));
lf[314]=C_decode_literal(C_heaptop,C_text("\376B\000\000KCHICKEN\012(c) 2008-2019, The CHICKEN Team\012(c) 2000-2007, Felix L. Winkelmann\012"
));
lf[315]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\012"));
lf[316]=C_h_intern(&lf[316],32, C_text("chicken.platform#chicken-version"));
lf[317]=C_h_intern(&lf[317],25, C_text("chicken.load#load-verbose"));
lf[318]=C_h_intern(&lf[318],32, C_text("chicken.internal#default-imports"));
lf[319]=C_h_intern(&lf[319],17, C_text("import-for-syntax"));
lf[320]=C_h_intern(&lf[320],39, C_text("chicken.internal#default-syntax-imports"));
lf[321]=C_h_intern(&lf[321],26, C_text("chicken.base#symbol-escape"));
lf[322]=C_h_intern(&lf[322],33, C_text("chicken.base#parentheses-synonyms"));
lf[323]=C_h_intern_kw(&lf[323],4, C_text("none"));
lf[324]=C_h_intern(&lf[324],27, C_text("chicken.base#case-sensitive"));
lf[325]=C_decode_literal(C_heaptop,C_text("\376B\000\000/Disabled the CHICKEN extensions to R5RS syntax\012"));
lf[326]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016"));
lf[327]=C_decode_literal(C_heaptop,C_text("\376B\000\000%Disabled support for escaped symbols\012"));
lf[328]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\377\016"));
lf[329]=C_decode_literal(C_heaptop,C_text("\376B\000\000\052Disabled support for parentheses synonyms\012"));
lf[330]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\377\016"));
lf[331]=C_decode_literal(C_heaptop,C_text("\376B\000\000+missing argument to `-keyword-style\047 option"));
lf[332]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006prefix"));
lf[333]=C_h_intern_kw(&lf[333],6, C_text("prefix"));
lf[334]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004none"));
lf[335]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006suffix"));
lf[336]=C_h_intern_kw(&lf[336],6, C_text("suffix"));
lf[337]=C_h_intern(&lf[337],15, C_text("scheme#string=\077"));
lf[338]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-I"));
lf[339]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015-include-path"));
lf[340]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013-no-feature"));
lf[341]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002-D"));
lf[342]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010-feature"));
lf[343]=C_h_intern(&lf[343],16, C_text("case-insensitive"));
lf[344]=C_decode_literal(C_heaptop,C_text("\376B\000\000-Identifiers and symbols are case insensitive\012"));
lf[345]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016"));
lf[346]=C_h_intern(&lf[346],22, C_text("##sys#warnings-enabled"));
lf[347]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026Warnings are disabled\012"));
lf[348]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016"));
lf[349]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010-release"));
lf[350]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013-setup-mode"));
lf[351]=C_h_intern(&lf[351],16, C_text("##sys#setup-mode"));
lf[352]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010-version"));
lf[353]=C_decode_literal(C_heaptop,C_text("\376B\000\004e    -b  -batch                    terminate after command-line processing\012 "
"   -w  -no-warnings              disable all warnings\012    -K  -keyword-style STY"
"LE      enable alternative keyword-syntax\012                                   (pr"
"efix, suffix or none)\012        -no-parentheses-synonyms  disables list delimiter "
"synonyms\012        -no-symbol-escape         disables support for escaped symbols\012"
"        -r5rs-syntax              disables the CHICKEN extensions to\012           "
"                        R5RS syntax\012    -s  -script PATHNAME          use csi as"
" interpreter for Scheme scripts\012        -ss PATHNAME              same as `-s\047, "
"but invoke `main\047 procedure\012        -sx PATHNAME              same as `-s\047, but "
"print each expression\012                                   as it is evaluated\012    "
"    -setup-mode               prefer the current directory when locating extensi"
"ons\012    -R  -require-extension NAME   require extension and import before\012      "
"                             executing code\012    -I  -include-path PATHNAME    ad"
"d PATHNAME to include path\012    --                            ignore all followin"
"g options\012"));
lf[354]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003 \047\012"));
lf[355]=C_decode_literal(C_heaptop,C_text("\376B\000\000D    -n  -no-init                  do not load initialization file ` "));
lf[356]=C_h_intern(&lf[356],21, C_text("##sys#print-to-string"));
lf[357]=C_decode_literal(C_heaptop,C_text("\376B\000\003.usage: csi [OPTION ...] [FILENAME ...]\012\012  `csi\047 is the CHICKEN interpreter."
"\012  \012  FILENAME is a Scheme source file name with optional extension. OPTION may "
"be\012  one of the following:\012\012    -h  -help                     display this text "
"and exit\012        -version                  display version and exit\012        -rel"
"ease                  print release number and exit\012    -i  -case-insensitive   "
"      enable case-insensitive reading\012    -e  -eval EXPRESSION          evaluate"
" given expression\012    -p  -print EXPRESSION         evaluate and print result(s)"
"\012    -P  -pretty-print EXPRESSION  evaluate and print result(s) prettily\012    -D "
" -feature SYMBOL           register feature identifier\012        -no-feature SYMBO"
"L        disable built-in feature identifier\012    -q  -quiet                    d"
"o not print banner\012"));
lf[358]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016"));
lf[359]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[360]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024CHICKEN_INCLUDE_PATH"));
lf[361]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016"));
lf[362]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016"));
lf[363]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016"));
lf[364]=C_h_intern(&lf[364],14, C_text("chicken-script"));
lf[365]=C_h_intern(&lf[365],36, C_text("chicken.process-context#program-name"));
lf[366]=C_decode_literal(C_heaptop,C_text("\376B\000\000\042missing or invalid script argument"));
lf[367]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002--"));
lf[368]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016"));
lf[369]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016"));
lf[370]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[371]=C_h_intern(&lf[371],30, C_text("chicken.base#get-output-string"));
lf[372]=C_h_intern(&lf[372],31, C_text("chicken.base#open-output-string"));
lf[373]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025invalid option syntax"));
lf[374]=C_h_intern(&lf[374],14, C_text("scheme#reverse"));
lf[375]=C_h_intern(&lf[375],40, C_text("chicken.condition#with-exception-handler"));
lf[376]=C_h_intern(&lf[376],37, C_text("scheme#call-with-current-continuation"));
lf[377]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013CSI_OPTIONS"));
lf[378]=C_h_intern(&lf[378],18, C_text("scheme#make-vector"));
lf[379]=C_h_intern(&lf[379],19, C_text("##sys#peek-c-string"));
lf[380]=C_decode_literal(C_heaptop,C_text("\376B\000\000(; resetting current module to toplevel~%"));
lf[381]=C_h_intern(&lf[381],19, C_text("##sys#switch-module"));
lf[382]=C_decode_literal(C_heaptop,C_text("\376B\000\000$; switching current module to `~a\047~%"));
lf[383]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027undefined module `~a\047~%"));
lf[384]=C_h_intern(&lf[384],17, C_text("##sys#find-module"));
lf[385]=C_h_intern(&lf[385],25, C_text("##sys#resolve-module-name"));
lf[386]=C_h_intern(&lf[386],1, C_text("m"));
lf[387]=C_decode_literal(C_heaptop,C_text("\376B\000\0005,m MODULE         switch to module with name `MODULE\047"));
lf[388]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010#;~A~A> "));
lf[389]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003~a:"));
lf[390]=C_h_intern(&lf[390],17, C_text("##sys#module-name"));
lf[391]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[392]=C_h_intern(&lf[392],20, C_text("##sys#current-module"));
lf[393]=C_h_intern(&lf[393],24, C_text("chicken.repl#repl-prompt"));
lf[394]=C_h_intern(&lf[394],17, C_text("##sys#make-string"));
lf[395]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013emacsclient"));
lf[396]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002vi"));
lf[397]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005EMACS"));
lf[398]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006VISUAL"));
lf[399]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006EDITOR"));
lf[400]=C_h_intern(&lf[400],27, C_text("chicken.base#make-parameter"));
lf[401]=C_h_intern(&lf[401],30, C_text("##sys#register-compiled-module"));
lf[402]=C_h_intern(&lf[402],11, C_text("chicken.csi"));
lf[403]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001editor-command\376\001\000\000\032\001chicken.csi#editor-command\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001to"
"plevel-command\376\001\000\000\034\001chicken.csi#toplevel-command\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001set-describer!\376\001"
"\000\000\032\001chicken.csi#set-describer!\376\377\016"));
C_register_lf2(lf,404,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2516,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[502] = {
{C_text("f9399:csi_2escm"),(void*)f9399},
{C_text("f9440:csi_2escm"),(void*)f9440},
{C_text("f9458:csi_2escm"),(void*)f9458},
{C_text("f9462:csi_2escm"),(void*)f9462},
{C_text("f_2516:csi_2escm"),(void*)f_2516},
{C_text("f_2519:csi_2escm"),(void*)f_2519},
{C_text("f_2522:csi_2escm"),(void*)f_2522},
{C_text("f_2525:csi_2escm"),(void*)f_2525},
{C_text("f_2528:csi_2escm"),(void*)f_2528},
{C_text("f_2531:csi_2escm"),(void*)f_2531},
{C_text("f_2534:csi_2escm"),(void*)f_2534},
{C_text("f_2537:csi_2escm"),(void*)f_2537},
{C_text("f_2540:csi_2escm"),(void*)f_2540},
{C_text("f_2543:csi_2escm"),(void*)f_2543},
{C_text("f_2546:csi_2escm"),(void*)f_2546},
{C_text("f_2549:csi_2escm"),(void*)f_2549},
{C_text("f_3047:csi_2escm"),(void*)f_3047},
{C_text("f_3060:csi_2escm"),(void*)f_3060},
{C_text("f_3074:csi_2escm"),(void*)f_3074},
{C_text("f_3122:csi_2escm"),(void*)f_3122},
{C_text("f_3136:csi_2escm"),(void*)f_3136},
{C_text("f_3149:csi_2escm"),(void*)f_3149},
{C_text("f_3839:csi_2escm"),(void*)f_3839},
{C_text("f_3844:csi_2escm"),(void*)f_3844},
{C_text("f_3847:csi_2escm"),(void*)f_3847},
{C_text("f_3853:csi_2escm"),(void*)f_3853},
{C_text("f_3856:csi_2escm"),(void*)f_3856},
{C_text("f_3863:csi_2escm"),(void*)f_3863},
{C_text("f_3887:csi_2escm"),(void*)f_3887},
{C_text("f_3902:csi_2escm"),(void*)f_3902},
{C_text("f_3916:csi_2escm"),(void*)f_3916},
{C_text("f_3929:csi_2escm"),(void*)f_3929},
{C_text("f_3948:csi_2escm"),(void*)f_3948},
{C_text("f_3955:csi_2escm"),(void*)f_3955},
{C_text("f_3958:csi_2escm"),(void*)f_3958},
{C_text("f_3964:csi_2escm"),(void*)f_3964},
{C_text("f_3977:csi_2escm"),(void*)f_3977},
{C_text("f_3990:csi_2escm"),(void*)f_3990},
{C_text("f_3999:csi_2escm"),(void*)f_3999},
{C_text("f_4003:csi_2escm"),(void*)f_4003},
{C_text("f_4015:csi_2escm"),(void*)f_4015},
{C_text("f_4024:csi_2escm"),(void*)f_4024},
{C_text("f_4027:csi_2escm"),(void*)f_4027},
{C_text("f_4034:csi_2escm"),(void*)f_4034},
{C_text("f_4038:csi_2escm"),(void*)f_4038},
{C_text("f_4041:csi_2escm"),(void*)f_4041},
{C_text("f_4047:csi_2escm"),(void*)f_4047},
{C_text("f_4054:csi_2escm"),(void*)f_4054},
{C_text("f_4056:csi_2escm"),(void*)f_4056},
{C_text("f_4066:csi_2escm"),(void*)f_4066},
{C_text("f_4069:csi_2escm"),(void*)f_4069},
{C_text("f_4083:csi_2escm"),(void*)f_4083},
{C_text("f_4106:csi_2escm"),(void*)f_4106},
{C_text("f_4116:csi_2escm"),(void*)f_4116},
{C_text("f_4130:csi_2escm"),(void*)f_4130},
{C_text("f_4161:csi_2escm"),(void*)f_4161},
{C_text("f_4174:csi_2escm"),(void*)f_4174},
{C_text("f_4177:csi_2escm"),(void*)f_4177},
{C_text("f_4180:csi_2escm"),(void*)f_4180},
{C_text("f_4183:csi_2escm"),(void*)f_4183},
{C_text("f_4186:csi_2escm"),(void*)f_4186},
{C_text("f_4195:csi_2escm"),(void*)f_4195},
{C_text("f_4205:csi_2escm"),(void*)f_4205},
{C_text("f_4209:csi_2escm"),(void*)f_4209},
{C_text("f_4232:csi_2escm"),(void*)f_4232},
{C_text("f_4249:csi_2escm"),(void*)f_4249},
{C_text("f_4261:csi_2escm"),(void*)f_4261},
{C_text("f_4269:csi_2escm"),(void*)f_4269},
{C_text("f_4272:csi_2escm"),(void*)f_4272},
{C_text("f_4284:csi_2escm"),(void*)f_4284},
{C_text("f_4291:csi_2escm"),(void*)f_4291},
{C_text("f_4297:csi_2escm"),(void*)f_4297},
{C_text("f_4317:csi_2escm"),(void*)f_4317},
{C_text("f_4347:csi_2escm"),(void*)f_4347},
{C_text("f_4363:csi_2escm"),(void*)f_4363},
{C_text("f_4380:csi_2escm"),(void*)f_4380},
{C_text("f_4395:csi_2escm"),(void*)f_4395},
{C_text("f_4398:csi_2escm"),(void*)f_4398},
{C_text("f_4405:csi_2escm"),(void*)f_4405},
{C_text("f_4409:csi_2escm"),(void*)f_4409},
{C_text("f_4418:csi_2escm"),(void*)f_4418},
{C_text("f_4421:csi_2escm"),(void*)f_4421},
{C_text("f_4424:csi_2escm"),(void*)f_4424},
{C_text("f_4436:csi_2escm"),(void*)f_4436},
{C_text("f_4439:csi_2escm"),(void*)f_4439},
{C_text("f_4451:csi_2escm"),(void*)f_4451},
{C_text("f_4454:csi_2escm"),(void*)f_4454},
{C_text("f_4466:csi_2escm"),(void*)f_4466},
{C_text("f_4469:csi_2escm"),(void*)f_4469},
{C_text("f_4472:csi_2escm"),(void*)f_4472},
{C_text("f_4475:csi_2escm"),(void*)f_4475},
{C_text("f_4505:csi_2escm"),(void*)f_4505},
{C_text("f_4508:csi_2escm"),(void*)f_4508},
{C_text("f_4513:csi_2escm"),(void*)f_4513},
{C_text("f_4523:csi_2escm"),(void*)f_4523},
{C_text("f_4538:csi_2escm"),(void*)f_4538},
{C_text("f_4547:csi_2escm"),(void*)f_4547},
{C_text("f_4548:csi_2escm"),(void*)f_4548},
{C_text("f_4554:csi_2escm"),(void*)f_4554},
{C_text("f_4558:csi_2escm"),(void*)f_4558},
{C_text("f_4564:csi_2escm"),(void*)f_4564},
{C_text("f_4569:csi_2escm"),(void*)f_4569},
{C_text("f_4579:csi_2escm"),(void*)f_4579},
{C_text("f_4594:csi_2escm"),(void*)f_4594},
{C_text("f_4603:csi_2escm"),(void*)f_4603},
{C_text("f_4608:csi_2escm"),(void*)f_4608},
{C_text("f_4612:csi_2escm"),(void*)f_4612},
{C_text("f_4617:csi_2escm"),(void*)f_4617},
{C_text("f_4623:csi_2escm"),(void*)f_4623},
{C_text("f_4627:csi_2escm"),(void*)f_4627},
{C_text("f_4634:csi_2escm"),(void*)f_4634},
{C_text("f_4636:csi_2escm"),(void*)f_4636},
{C_text("f_4640:csi_2escm"),(void*)f_4640},
{C_text("f_4655:csi_2escm"),(void*)f_4655},
{C_text("f_4671:csi_2escm"),(void*)f_4671},
{C_text("f_4689:csi_2escm"),(void*)f_4689},
{C_text("f_4693:csi_2escm"),(void*)f_4693},
{C_text("f_4700:csi_2escm"),(void*)f_4700},
{C_text("f_4709:csi_2escm"),(void*)f_4709},
{C_text("f_4721:csi_2escm"),(void*)f_4721},
{C_text("f_4733:csi_2escm"),(void*)f_4733},
{C_text("f_4745:csi_2escm"),(void*)f_4745},
{C_text("f_4752:csi_2escm"),(void*)f_4752},
{C_text("f_4765:csi_2escm"),(void*)f_4765},
{C_text("f_4774:csi_2escm"),(void*)f_4774},
{C_text("f_4777:csi_2escm"),(void*)f_4777},
{C_text("f_4780:csi_2escm"),(void*)f_4780},
{C_text("f_4793:csi_2escm"),(void*)f_4793},
{C_text("f_4815:csi_2escm"),(void*)f_4815},
{C_text("f_4820:csi_2escm"),(void*)f_4820},
{C_text("f_4830:csi_2escm"),(void*)f_4830},
{C_text("f_4844:csi_2escm"),(void*)f_4844},
{C_text("f_4890:csi_2escm"),(void*)f_4890},
{C_text("f_4896:csi_2escm"),(void*)f_4896},
{C_text("f_4900:csi_2escm"),(void*)f_4900},
{C_text("f_4916:csi_2escm"),(void*)f_4916},
{C_text("f_4922:csi_2escm"),(void*)f_4922},
{C_text("f_4936:csi_2escm"),(void*)f_4936},
{C_text("f_4939:csi_2escm"),(void*)f_4939},
{C_text("f_4945:csi_2escm"),(void*)f_4945},
{C_text("f_4948:csi_2escm"),(void*)f_4948},
{C_text("f_4956:csi_2escm"),(void*)f_4956},
{C_text("f_4981:csi_2escm"),(void*)f_4981},
{C_text("f_4990:csi_2escm"),(void*)f_4990},
{C_text("f_4996:csi_2escm"),(void*)f_4996},
{C_text("f_5002:csi_2escm"),(void*)f_5002},
{C_text("f_5008:csi_2escm"),(void*)f_5008},
{C_text("f_5014:csi_2escm"),(void*)f_5014},
{C_text("f_5022:csi_2escm"),(void*)f_5022},
{C_text("f_5024:csi_2escm"),(void*)f_5024},
{C_text("f_5041:csi_2escm"),(void*)f_5041},
{C_text("f_5047:csi_2escm"),(void*)f_5047},
{C_text("f_5053:csi_2escm"),(void*)f_5053},
{C_text("f_5061:csi_2escm"),(void*)f_5061},
{C_text("f_5062:csi_2escm"),(void*)f_5062},
{C_text("f_5070:csi_2escm"),(void*)f_5070},
{C_text("f_5072:csi_2escm"),(void*)f_5072},
{C_text("f_5076:csi_2escm"),(void*)f_5076},
{C_text("f_5079:csi_2escm"),(void*)f_5079},
{C_text("f_5082:csi_2escm"),(void*)f_5082},
{C_text("f_5084:csi_2escm"),(void*)f_5084},
{C_text("f_5092:csi_2escm"),(void*)f_5092},
{C_text("f_5100:csi_2escm"),(void*)f_5100},
{C_text("f_5103:csi_2escm"),(void*)f_5103},
{C_text("f_5104:csi_2escm"),(void*)f_5104},
{C_text("f_5108:csi_2escm"),(void*)f_5108},
{C_text("f_5118:csi_2escm"),(void*)f_5118},
{C_text("f_5127:csi_2escm"),(void*)f_5127},
{C_text("f_5135:csi_2escm"),(void*)f_5135},
{C_text("f_5150:csi_2escm"),(void*)f_5150},
{C_text("f_5153:csi_2escm"),(void*)f_5153},
{C_text("f_5156:csi_2escm"),(void*)f_5156},
{C_text("f_5159:csi_2escm"),(void*)f_5159},
{C_text("f_5166:csi_2escm"),(void*)f_5166},
{C_text("f_5174:csi_2escm"),(void*)f_5174},
{C_text("f_5178:csi_2escm"),(void*)f_5178},
{C_text("f_5182:csi_2escm"),(void*)f_5182},
{C_text("f_5186:csi_2escm"),(void*)f_5186},
{C_text("f_5190:csi_2escm"),(void*)f_5190},
{C_text("f_5194:csi_2escm"),(void*)f_5194},
{C_text("f_5198:csi_2escm"),(void*)f_5198},
{C_text("f_5202:csi_2escm"),(void*)f_5202},
{C_text("f_5230:csi_2escm"),(void*)f_5230},
{C_text("f_5242:csi_2escm"),(void*)f_5242},
{C_text("f_5245:csi_2escm"),(void*)f_5245},
{C_text("f_5247:csi_2escm"),(void*)f_5247},
{C_text("f_5257:csi_2escm"),(void*)f_5257},
{C_text("f_5278:csi_2escm"),(void*)f_5278},
{C_text("f_5280:csi_2escm"),(void*)f_5280},
{C_text("f_5305:csi_2escm"),(void*)f_5305},
{C_text("f_5325:csi_2escm"),(void*)f_5325},
{C_text("f_5360:csi_2escm"),(void*)f_5360},
{C_text("f_5390:csi_2escm"),(void*)f_5390},
{C_text("f_5392:csi_2escm"),(void*)f_5392},
{C_text("f_5398:csi_2escm"),(void*)f_5398},
{C_text("f_5405:csi_2escm"),(void*)f_5405},
{C_text("f_5410:csi_2escm"),(void*)f_5410},
{C_text("f_5433:csi_2escm"),(void*)f_5433},
{C_text("f_5442:csi_2escm"),(void*)f_5442},
{C_text("f_5452:csi_2escm"),(void*)f_5452},
{C_text("f_5455:csi_2escm"),(void*)f_5455},
{C_text("f_5484:csi_2escm"),(void*)f_5484},
{C_text("f_5512:csi_2escm"),(void*)f_5512},
{C_text("f_5527:csi_2escm"),(void*)f_5527},
{C_text("f_5530:csi_2escm"),(void*)f_5530},
{C_text("f_5533:csi_2escm"),(void*)f_5533},
{C_text("f_5599:csi_2escm"),(void*)f_5599},
{C_text("f_5605:csi_2escm"),(void*)f_5605},
{C_text("f_5696:csi_2escm"),(void*)f_5696},
{C_text("f_5703:csi_2escm"),(void*)f_5703},
{C_text("f_5712:csi_2escm"),(void*)f_5712},
{C_text("f_5715:csi_2escm"),(void*)f_5715},
{C_text("f_5727:csi_2escm"),(void*)f_5727},
{C_text("f_5732:csi_2escm"),(void*)f_5732},
{C_text("f_5742:csi_2escm"),(void*)f_5742},
{C_text("f_5745:csi_2escm"),(void*)f_5745},
{C_text("f_5748:csi_2escm"),(void*)f_5748},
{C_text("f_5757:csi_2escm"),(void*)f_5757},
{C_text("f_5777:csi_2escm"),(void*)f_5777},
{C_text("f_5780:csi_2escm"),(void*)f_5780},
{C_text("f_5783:csi_2escm"),(void*)f_5783},
{C_text("f_5795:csi_2escm"),(void*)f_5795},
{C_text("f_5798:csi_2escm"),(void*)f_5798},
{C_text("f_5807:csi_2escm"),(void*)f_5807},
{C_text("f_5838:csi_2escm"),(void*)f_5838},
{C_text("f_5902:csi_2escm"),(void*)f_5902},
{C_text("f_5906:csi_2escm"),(void*)f_5906},
{C_text("f_5912:csi_2escm"),(void*)f_5912},
{C_text("f_5931:csi_2escm"),(void*)f_5931},
{C_text("f_5940:csi_2escm"),(void*)f_5940},
{C_text("f_5947:csi_2escm"),(void*)f_5947},
{C_text("f_6064:csi_2escm"),(void*)f_6064},
{C_text("f_6070:csi_2escm"),(void*)f_6070},
{C_text("f_6076:csi_2escm"),(void*)f_6076},
{C_text("f_6089:csi_2escm"),(void*)f_6089},
{C_text("f_6101:csi_2escm"),(void*)f_6101},
{C_text("f_6104:csi_2escm"),(void*)f_6104},
{C_text("f_6115:csi_2escm"),(void*)f_6115},
{C_text("f_6123:csi_2escm"),(void*)f_6123},
{C_text("f_6144:csi_2escm"),(void*)f_6144},
{C_text("f_6153:csi_2escm"),(void*)f_6153},
{C_text("f_6163:csi_2escm"),(void*)f_6163},
{C_text("f_6198:csi_2escm"),(void*)f_6198},
{C_text("f_6199:csi_2escm"),(void*)f_6199},
{C_text("f_6203:csi_2escm"),(void*)f_6203},
{C_text("f_6212:csi_2escm"),(void*)f_6212},
{C_text("f_6222:csi_2escm"),(void*)f_6222},
{C_text("f_6235:csi_2escm"),(void*)f_6235},
{C_text("f_6240:csi_2escm"),(void*)f_6240},
{C_text("f_6267:csi_2escm"),(void*)f_6267},
{C_text("f_6277:csi_2escm"),(void*)f_6277},
{C_text("f_6304:csi_2escm"),(void*)f_6304},
{C_text("f_6308:csi_2escm"),(void*)f_6308},
{C_text("f_6322:csi_2escm"),(void*)f_6322},
{C_text("f_6330:csi_2escm"),(void*)f_6330},
{C_text("f_6343:csi_2escm"),(void*)f_6343},
{C_text("f_6349:csi_2escm"),(void*)f_6349},
{C_text("f_6374:csi_2escm"),(void*)f_6374},
{C_text("f_6387:csi_2escm"),(void*)f_6387},
{C_text("f_6414:csi_2escm"),(void*)f_6414},
{C_text("f_6422:csi_2escm"),(void*)f_6422},
{C_text("f_6431:csi_2escm"),(void*)f_6431},
{C_text("f_6433:csi_2escm"),(void*)f_6433},
{C_text("f_6436:csi_2escm"),(void*)f_6436},
{C_text("f_6458:csi_2escm"),(void*)f_6458},
{C_text("f_6465:csi_2escm"),(void*)f_6465},
{C_text("f_6482:csi_2escm"),(void*)f_6482},
{C_text("f_6501:csi_2escm"),(void*)f_6501},
{C_text("f_6511:csi_2escm"),(void*)f_6511},
{C_text("f_6539:csi_2escm"),(void*)f_6539},
{C_text("f_6544:csi_2escm"),(void*)f_6544},
{C_text("f_6579:csi_2escm"),(void*)f_6579},
{C_text("f_6582:csi_2escm"),(void*)f_6582},
{C_text("f_6586:csi_2escm"),(void*)f_6586},
{C_text("f_6602:csi_2escm"),(void*)f_6602},
{C_text("f_6614:csi_2escm"),(void*)f_6614},
{C_text("f_6624:csi_2escm"),(void*)f_6624},
{C_text("f_6627:csi_2escm"),(void*)f_6627},
{C_text("f_6630:csi_2escm"),(void*)f_6630},
{C_text("f_6633:csi_2escm"),(void*)f_6633},
{C_text("f_6636:csi_2escm"),(void*)f_6636},
{C_text("f_6639:csi_2escm"),(void*)f_6639},
{C_text("f_6648:csi_2escm"),(void*)f_6648},
{C_text("f_6661:csi_2escm"),(void*)f_6661},
{C_text("f_6664:csi_2escm"),(void*)f_6664},
{C_text("f_6699:csi_2escm"),(void*)f_6699},
{C_text("f_6733:csi_2escm"),(void*)f_6733},
{C_text("f_6743:csi_2escm"),(void*)f_6743},
{C_text("f_6753:csi_2escm"),(void*)f_6753},
{C_text("f_6756:csi_2escm"),(void*)f_6756},
{C_text("f_6771:csi_2escm"),(void*)f_6771},
{C_text("f_6775:csi_2escm"),(void*)f_6775},
{C_text("f_6782:csi_2escm"),(void*)f_6782},
{C_text("f_6784:csi_2escm"),(void*)f_6784},
{C_text("f_6787:csi_2escm"),(void*)f_6787},
{C_text("f_6793:csi_2escm"),(void*)f_6793},
{C_text("f_6810:csi_2escm"),(void*)f_6810},
{C_text("f_6819:csi_2escm"),(void*)f_6819},
{C_text("f_6850:csi_2escm"),(void*)f_6850},
{C_text("f_6853:csi_2escm"),(void*)f_6853},
{C_text("f_6856:csi_2escm"),(void*)f_6856},
{C_text("f_6859:csi_2escm"),(void*)f_6859},
{C_text("f_6862:csi_2escm"),(void*)f_6862},
{C_text("f_6865:csi_2escm"),(void*)f_6865},
{C_text("f_6868:csi_2escm"),(void*)f_6868},
{C_text("f_6871:csi_2escm"),(void*)f_6871},
{C_text("f_6874:csi_2escm"),(void*)f_6874},
{C_text("f_6877:csi_2escm"),(void*)f_6877},
{C_text("f_6880:csi_2escm"),(void*)f_6880},
{C_text("f_6893:csi_2escm"),(void*)f_6893},
{C_text("f_6903:csi_2escm"),(void*)f_6903},
{C_text("f_6908:csi_2escm"),(void*)f_6908},
{C_text("f_6921:csi_2escm"),(void*)f_6921},
{C_text("f_6924:csi_2escm"),(void*)f_6924},
{C_text("f_6927:csi_2escm"),(void*)f_6927},
{C_text("f_6930:csi_2escm"),(void*)f_6930},
{C_text("f_6933:csi_2escm"),(void*)f_6933},
{C_text("f_6967:csi_2escm"),(void*)f_6967},
{C_text("f_6977:csi_2escm"),(void*)f_6977},
{C_text("f_7011:csi_2escm"),(void*)f_7011},
{C_text("f_7014:csi_2escm"),(void*)f_7014},
{C_text("f_7028:csi_2escm"),(void*)f_7028},
{C_text("f_7069:csi_2escm"),(void*)f_7069},
{C_text("f_7126:csi_2escm"),(void*)f_7126},
{C_text("f_7128:csi_2escm"),(void*)f_7128},
{C_text("f_7139:csi_2escm"),(void*)f_7139},
{C_text("f_7159:csi_2escm"),(void*)f_7159},
{C_text("f_7162:csi_2escm"),(void*)f_7162},
{C_text("f_7166:csi_2escm"),(void*)f_7166},
{C_text("f_7169:csi_2escm"),(void*)f_7169},
{C_text("f_7181:csi_2escm"),(void*)f_7181},
{C_text("f_7206:csi_2escm"),(void*)f_7206},
{C_text("f_7215:csi_2escm"),(void*)f_7215},
{C_text("f_7221:csi_2escm"),(void*)f_7221},
{C_text("f_7231:csi_2escm"),(void*)f_7231},
{C_text("f_7243:csi_2escm"),(void*)f_7243},
{C_text("f_7246:csi_2escm"),(void*)f_7246},
{C_text("f_7249:csi_2escm"),(void*)f_7249},
{C_text("f_7252:csi_2escm"),(void*)f_7252},
{C_text("f_7255:csi_2escm"),(void*)f_7255},
{C_text("f_7291:csi_2escm"),(void*)f_7291},
{C_text("f_7298:csi_2escm"),(void*)f_7298},
{C_text("f_7300:csi_2escm"),(void*)f_7300},
{C_text("f_7310:csi_2escm"),(void*)f_7310},
{C_text("f_7353:csi_2escm"),(void*)f_7353},
{C_text("f_7358:csi_2escm"),(void*)f_7358},
{C_text("f_7364:csi_2escm"),(void*)f_7364},
{C_text("f_7376:csi_2escm"),(void*)f_7376},
{C_text("f_7413:csi_2escm"),(void*)f_7413},
{C_text("f_7419:csi_2escm"),(void*)f_7419},
{C_text("f_7441:csi_2escm"),(void*)f_7441},
{C_text("f_7455:csi_2escm"),(void*)f_7455},
{C_text("f_7476:csi_2escm"),(void*)f_7476},
{C_text("f_7480:csi_2escm"),(void*)f_7480},
{C_text("f_7484:csi_2escm"),(void*)f_7484},
{C_text("f_7523:csi_2escm"),(void*)f_7523},
{C_text("f_7531:csi_2escm"),(void*)f_7531},
{C_text("f_7562:csi_2escm"),(void*)f_7562},
{C_text("f_7592:csi_2escm"),(void*)f_7592},
{C_text("f_7595:csi_2escm"),(void*)f_7595},
{C_text("f_7598:csi_2escm"),(void*)f_7598},
{C_text("f_7601:csi_2escm"),(void*)f_7601},
{C_text("f_7604:csi_2escm"),(void*)f_7604},
{C_text("f_7607:csi_2escm"),(void*)f_7607},
{C_text("f_7610:csi_2escm"),(void*)f_7610},
{C_text("f_7613:csi_2escm"),(void*)f_7613},
{C_text("f_7616:csi_2escm"),(void*)f_7616},
{C_text("f_7622:csi_2escm"),(void*)f_7622},
{C_text("f_7628:csi_2escm"),(void*)f_7628},
{C_text("f_7630:csi_2escm"),(void*)f_7630},
{C_text("f_7636:csi_2escm"),(void*)f_7636},
{C_text("f_7644:csi_2escm"),(void*)f_7644},
{C_text("f_7665:csi_2escm"),(void*)f_7665},
{C_text("f_7681:csi_2escm"),(void*)f_7681},
{C_text("f_7684:csi_2escm"),(void*)f_7684},
{C_text("f_7687:csi_2escm"),(void*)f_7687},
{C_text("f_7690:csi_2escm"),(void*)f_7690},
{C_text("f_7696:csi_2escm"),(void*)f_7696},
{C_text("f_7705:csi_2escm"),(void*)f_7705},
{C_text("f_7727:csi_2escm"),(void*)f_7727},
{C_text("f_7742:csi_2escm"),(void*)f_7742},
{C_text("f_7749:csi_2escm"),(void*)f_7749},
{C_text("f_7756:csi_2escm"),(void*)f_7756},
{C_text("f_7758:csi_2escm"),(void*)f_7758},
{C_text("f_7768:csi_2escm"),(void*)f_7768},
{C_text("f_7775:csi_2escm"),(void*)f_7775},
{C_text("f_7779:csi_2escm"),(void*)f_7779},
{C_text("f_7781:csi_2escm"),(void*)f_7781},
{C_text("f_7789:csi_2escm"),(void*)f_7789},
{C_text("f_7799:csi_2escm"),(void*)f_7799},
{C_text("f_7802:csi_2escm"),(void*)f_7802},
{C_text("f_7805:csi_2escm"),(void*)f_7805},
{C_text("f_7808:csi_2escm"),(void*)f_7808},
{C_text("f_7811:csi_2escm"),(void*)f_7811},
{C_text("f_7814:csi_2escm"),(void*)f_7814},
{C_text("f_7817:csi_2escm"),(void*)f_7817},
{C_text("f_7823:csi_2escm"),(void*)f_7823},
{C_text("f_7826:csi_2escm"),(void*)f_7826},
{C_text("f_7832:csi_2escm"),(void*)f_7832},
{C_text("f_7835:csi_2escm"),(void*)f_7835},
{C_text("f_7841:csi_2escm"),(void*)f_7841},
{C_text("f_7845:csi_2escm"),(void*)f_7845},
{C_text("f_7848:csi_2escm"),(void*)f_7848},
{C_text("f_7851:csi_2escm"),(void*)f_7851},
{C_text("f_7854:csi_2escm"),(void*)f_7854},
{C_text("f_7857:csi_2escm"),(void*)f_7857},
{C_text("f_7860:csi_2escm"),(void*)f_7860},
{C_text("f_7863:csi_2escm"),(void*)f_7863},
{C_text("f_7866:csi_2escm"),(void*)f_7866},
{C_text("f_7869:csi_2escm"),(void*)f_7869},
{C_text("f_7872:csi_2escm"),(void*)f_7872},
{C_text("f_7877:csi_2escm"),(void*)f_7877},
{C_text("f_7905:csi_2escm"),(void*)f_7905},
{C_text("f_7934:csi_2escm"),(void*)f_7934},
{C_text("f_7946:csi_2escm"),(void*)f_7946},
{C_text("f_7961:csi_2escm"),(void*)f_7961},
{C_text("f_7980:csi_2escm"),(void*)f_7980},
{C_text("f_7990:csi_2escm"),(void*)f_7990},
{C_text("f_8005:csi_2escm"),(void*)f_8005},
{C_text("f_8015:csi_2escm"),(void*)f_8015},
{C_text("f_8025:csi_2escm"),(void*)f_8025},
{C_text("f_8036:csi_2escm"),(void*)f_8036},
{C_text("f_8040:csi_2escm"),(void*)f_8040},
{C_text("f_8047:csi_2escm"),(void*)f_8047},
{C_text("f_8049:csi_2escm"),(void*)f_8049},
{C_text("f_8077:csi_2escm"),(void*)f_8077},
{C_text("f_8081:csi_2escm"),(void*)f_8081},
{C_text("f_8087:csi_2escm"),(void*)f_8087},
{C_text("f_8090:csi_2escm"),(void*)f_8090},
{C_text("f_8093:csi_2escm"),(void*)f_8093},
{C_text("f_8096:csi_2escm"),(void*)f_8096},
{C_text("f_8101:csi_2escm"),(void*)f_8101},
{C_text("f_8114:csi_2escm"),(void*)f_8114},
{C_text("f_8117:csi_2escm"),(void*)f_8117},
{C_text("f_8132:csi_2escm"),(void*)f_8132},
{C_text("f_8151:csi_2escm"),(void*)f_8151},
{C_text("f_8163:csi_2escm"),(void*)f_8163},
{C_text("f_8177:csi_2escm"),(void*)f_8177},
{C_text("f_8180:csi_2escm"),(void*)f_8180},
{C_text("f_8183:csi_2escm"),(void*)f_8183},
{C_text("f_8186:csi_2escm"),(void*)f_8186},
{C_text("f_8189:csi_2escm"),(void*)f_8189},
{C_text("f_8198:csi_2escm"),(void*)f_8198},
{C_text("f_8201:csi_2escm"),(void*)f_8201},
{C_text("f_8210:csi_2escm"),(void*)f_8210},
{C_text("f_8213:csi_2escm"),(void*)f_8213},
{C_text("f_8277:csi_2escm"),(void*)f_8277},
{C_text("f_8284:csi_2escm"),(void*)f_8284},
{C_text("f_8290:csi_2escm"),(void*)f_8290},
{C_text("f_8297:csi_2escm"),(void*)f_8297},
{C_text("f_8303:csi_2escm"),(void*)f_8303},
{C_text("f_8305:csi_2escm"),(void*)f_8305},
{C_text("f_8330:csi_2escm"),(void*)f_8330},
{C_text("f_8339:csi_2escm"),(void*)f_8339},
{C_text("f_8364:csi_2escm"),(void*)f_8364},
{C_text("f_8373:csi_2escm"),(void*)f_8373},
{C_text("f_8383:csi_2escm"),(void*)f_8383},
{C_text("f_8396:csi_2escm"),(void*)f_8396},
{C_text("f_8406:csi_2escm"),(void*)f_8406},
{C_text("f_8419:csi_2escm"),(void*)f_8419},
{C_text("f_8429:csi_2escm"),(void*)f_8429},
{C_text("f_8443:csi_2escm"),(void*)f_8443},
{C_text("f_8446:csi_2escm"),(void*)f_8446},
{C_text("f_8449:csi_2escm"),(void*)f_8449},
{C_text("f_8458:csi_2escm"),(void*)f_8458},
{C_text("f_8461:csi_2escm"),(void*)f_8461},
{C_text("f_8471:csi_2escm"),(void*)f_8471},
{C_text("f_8478:csi_2escm"),(void*)f_8478},
{C_text("f_8488:csi_2escm"),(void*)f_8488},
{C_text("f_8494:csi_2escm"),(void*)f_8494},
{C_text("f_8497:csi_2escm"),(void*)f_8497},
{C_text("f_8502:csi_2escm"),(void*)f_8502},
{C_text("f_8527:csi_2escm"),(void*)f_8527},
{C_text("f_8538:csi_2escm"),(void*)f_8538},
{C_text("f_8547:csi_2escm"),(void*)f_8547},
{C_text("f_8553:csi_2escm"),(void*)f_8553},
{C_text("f_8556:csi_2escm"),(void*)f_8556},
{C_text("f_8559:csi_2escm"),(void*)f_8559},
{C_text("f_8562:csi_2escm"),(void*)f_8562},
{C_text("f_8571:csi_2escm"),(void*)f_8571},
{C_text("f_8636:csi_2escm"),(void*)f_8636},
{C_text("f_8649:csi_2escm"),(void*)f_8649},
{C_text("f_8653:csi_2escm"),(void*)f_8653},
{C_text("f_8657:csi_2escm"),(void*)f_8657},
{C_text("f_8663:csi_2escm"),(void*)f_8663},
{C_text("f_8669:csi_2escm"),(void*)f_8669},
{C_text("f_8671:csi_2escm"),(void*)f_8671},
{C_text("f_8677:csi_2escm"),(void*)f_8677},
{C_text("f_8681:csi_2escm"),(void*)f_8681},
{C_text("f_8690:csi_2escm"),(void*)f_8690},
{C_text("f_8696:csi_2escm"),(void*)f_8696},
{C_text("f_8700:csi_2escm"),(void*)f_8700},
{C_text("f_8704:csi_2escm"),(void*)f_8704},
{C_text("f_8717:csi_2escm"),(void*)f_8717},
{C_text("f_8719:csi_2escm"),(void*)f_8719},
{C_text("f_8727:csi_2escm"),(void*)f_8727},
{C_text("f_8730:csi_2escm"),(void*)f_8730},
{C_text("f_8737:csi_2escm"),(void*)f_8737},
{C_text("f_8741:csi_2escm"),(void*)f_8741},
{C_text("f_8750:csi_2escm"),(void*)f_8750},
{C_text("toplevel:csi_2escm"),(void*)C_toplevel},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding unexported module binding: chicken.csi#constant193 
o|hiding unexported module binding: chicken.csi#partition 
o|hiding unexported module binding: chicken.csi#span 
o|hiding unexported module binding: chicken.csi#take 
o|hiding unexported module binding: chicken.csi#drop 
o|hiding unexported module binding: chicken.csi#split-at 
o|hiding unexported module binding: chicken.csi#append-map 
o|hiding unexported module binding: chicken.csi#every 
o|hiding unexported module binding: chicken.csi#any 
o|hiding unexported module binding: chicken.csi#cons* 
o|hiding unexported module binding: chicken.csi#concatenate 
o|hiding unexported module binding: chicken.csi#delete 
o|hiding unexported module binding: chicken.csi#first 
o|hiding unexported module binding: chicken.csi#second 
o|hiding unexported module binding: chicken.csi#third 
o|hiding unexported module binding: chicken.csi#fourth 
o|hiding unexported module binding: chicken.csi#fifth 
o|hiding unexported module binding: chicken.csi#delete-duplicates 
o|hiding unexported module binding: chicken.csi#alist-cons 
o|hiding unexported module binding: chicken.csi#filter 
o|hiding unexported module binding: chicken.csi#filter-map 
o|hiding unexported module binding: chicken.csi#remove 
o|hiding unexported module binding: chicken.csi#unzip1 
o|hiding unexported module binding: chicken.csi#last 
o|hiding unexported module binding: chicken.csi#list-index 
o|hiding unexported module binding: chicken.csi#lset-adjoin/eq? 
o|hiding unexported module binding: chicken.csi#lset-difference/eq? 
o|hiding unexported module binding: chicken.csi#lset-union/eq? 
o|hiding unexported module binding: chicken.csi#lset-intersection/eq? 
o|hiding unexported module binding: chicken.csi#list-tabulate 
o|hiding unexported module binding: chicken.csi#lset<=/eq? 
o|hiding unexported module binding: chicken.csi#lset=/eq? 
o|hiding unexported module binding: chicken.csi#length+ 
o|hiding unexported module binding: chicken.csi#find 
o|hiding unexported module binding: chicken.csi#find-tail 
o|hiding unexported module binding: chicken.csi#iota 
o|hiding unexported module binding: chicken.csi#make-list 
o|hiding unexported module binding: chicken.csi#posq 
o|hiding unexported module binding: chicken.csi#posv 
o|hiding unexported module binding: chicken.csi#constant680 
o|hiding unexported module binding: chicken.csi#selected-frame 
o|hiding unexported module binding: chicken.csi#default-editor 
o|hiding unexported module binding: chicken.csi#print-usage 
o|hiding unexported module binding: chicken.csi#print-banner 
o|hiding unexported module binding: chicken.csi#dirseparator? 
o|hiding unexported module binding: chicken.csi#chop-separator 
o|hiding unexported module binding: chicken.csi#lookup-script-file 
o|hiding unexported module binding: chicken.csi#history-list 
o|hiding unexported module binding: chicken.csi#history-count 
o|hiding unexported module binding: chicken.csi#history-add 
o|hiding unexported module binding: chicken.csi#history-clear 
o|hiding unexported module binding: chicken.csi#history-show 
o|hiding unexported module binding: chicken.csi#history-ref 
o|hiding unexported module binding: chicken.csi#register-repl-history! 
o|hiding unexported module binding: chicken.csi#tty-input? 
o|hiding unexported module binding: chicken.csi#command-table 
o|hiding unexported module binding: chicken.csi#csi-eval 
o|hiding unexported module binding: chicken.csi#parse-option-string 
o|hiding unexported module binding: chicken.csi#report 
o|hiding unexported module binding: chicken.csi#bytevector-data 
o|hiding unexported module binding: chicken.csi#circular-list? 
o|hiding unexported module binding: chicken.csi#improper-pairs? 
o|hiding unexported module binding: chicken.csi#describer-table 
o|hiding unexported module binding: chicken.csi#describe 
o|hiding unexported module binding: chicken.csi#dump 
o|hiding unexported module binding: chicken.csi#hexdump 
o|hiding unexported module binding: chicken.csi#show-frameinfo 
o|hiding unexported module binding: chicken.csi#select-frame 
o|hiding unexported module binding: chicken.csi#copy-from-frame 
o|hiding unexported module binding: chicken.csi#defhandler 
o|hiding unexported module binding: chicken.csi#member* 
o|hiding unexported module binding: chicken.csi#constant1665 
o|hiding unexported module binding: chicken.csi#constant1671 
o|hiding unexported module binding: chicken.csi#canonicalize-args 
o|hiding unexported module binding: chicken.csi#findall 
o|hiding unexported module binding: chicken.csi#constant1735 
o|hiding unexported module binding: chicken.csi#constant1743 
o|hiding unexported module binding: chicken.csi#run 
S|applied compiler syntax:
S|  scheme#for-each		11
S|  chicken.format#printf		4
S|  chicken.base#foldl		3
S|  scheme#map		10
S|  chicken.base#foldr		3
o|eliminated procedure checks: 161 
o|eliminated procedure checks: 1 
o|specializations:
o|  1 (scheme#string-length string)
o|  7 (scheme#string=? string string)
o|  1 (scheme#set-cdr! pair *)
o|  2 (scheme#cddr (pair * pair))
o|  2 (scheme#char=? char char)
o|  3 (scheme#cadr (pair * pair))
o|  1 (scheme#min fixnum fixnum)
o|  1 (scheme#memq * list)
o|  1 (scheme#number->string * *)
o|  2 (chicken.base#add1 *)
o|  1 (scheme#- fixnum fixnum)
o|  1 (scheme#/ * *)
o|  1 (scheme#current-output-port)
o|  2 (scheme#zero? integer)
o|  31 (scheme#eqv? * (or eof null fixnum char boolean symbol keyword))
o|  4 (##sys#check-output-port * * *)
o|  1 (scheme#> fixnum fixnum)
o|  5 (scheme#string-append string string)
o|  1 (scheme#make-string fixnum)
o|  1 (chicken.base#sub1 fixnum)
o|  1 (scheme#eqv? * *)
o|  6 (##sys#check-list (or pair list) *)
o|  40 (scheme#cdr pair)
o|  14 (scheme#car pair)
(o e)|safe calls: 1002 
(o e)|assignments to immediate values: 5 
o|removed side-effect free assignment to unused variable: chicken.csi#partition 
o|removed side-effect free assignment to unused variable: chicken.csi#span 
o|removed side-effect free assignment to unused variable: chicken.csi#drop 
o|removed side-effect free assignment to unused variable: chicken.csi#split-at 
o|removed side-effect free assignment to unused variable: chicken.csi#append-map 
o|inlining procedure: k2932 
o|inlining procedure: k2932 
o|inlining procedure: k2963 
o|inlining procedure: k2963 
o|removed side-effect free assignment to unused variable: chicken.csi#cons* 
o|removed side-effect free assignment to unused variable: chicken.csi#concatenate 
o|removed side-effect free assignment to unused variable: chicken.csi#first 
o|removed side-effect free assignment to unused variable: chicken.csi#second 
o|removed side-effect free assignment to unused variable: chicken.csi#third 
o|removed side-effect free assignment to unused variable: chicken.csi#fourth 
o|removed side-effect free assignment to unused variable: chicken.csi#fifth 
o|removed side-effect free assignment to unused variable: chicken.csi#alist-cons 
o|inlining procedure: k3180 
o|inlining procedure: k3180 
o|inlining procedure: k3172 
o|inlining procedure: k3172 
o|removed side-effect free assignment to unused variable: chicken.csi#filter-map 
o|removed side-effect free assignment to unused variable: chicken.csi#remove 
o|removed side-effect free assignment to unused variable: chicken.csi#unzip1 
o|removed side-effect free assignment to unused variable: chicken.csi#last 
o|removed side-effect free assignment to unused variable: chicken.csi#list-index 
o|removed side-effect free assignment to unused variable: chicken.csi#lset-adjoin/eq? 
o|removed side-effect free assignment to unused variable: chicken.csi#lset-difference/eq? 
o|removed side-effect free assignment to unused variable: chicken.csi#lset-union/eq? 
o|removed side-effect free assignment to unused variable: chicken.csi#lset-intersection/eq? 
o|inlining procedure: k3571 
o|inlining procedure: k3571 
o|removed side-effect free assignment to unused variable: chicken.csi#lset<=/eq? 
o|removed side-effect free assignment to unused variable: chicken.csi#lset=/eq? 
o|removed side-effect free assignment to unused variable: chicken.csi#length+ 
o|removed side-effect free assignment to unused variable: chicken.csi#find 
o|removed side-effect free assignment to unused variable: chicken.csi#find-tail 
o|removed side-effect free assignment to unused variable: chicken.csi#iota 
o|removed side-effect free assignment to unused variable: chicken.csi#make-list 
o|removed side-effect free assignment to unused variable: chicken.csi#posq 
o|removed side-effect free assignment to unused variable: chicken.csi#posv 
o|substituted constant variable: chicken.csi#constant193 
o|inlining procedure: k3892 
o|inlining procedure: k3892 
o|inlining procedure: k3911 
o|inlining procedure: k3911 
o|inlining procedure: k3950 
o|inlining procedure: k3950 
o|substituted constant variable: a3966 
o|inlining procedure: k4004 
o|inlining procedure: k4019 
o|contracted procedure: "(csi.scm:185) _getcwd709" 
o|inlining procedure: k4019 
o|inlining procedure: k4058 
o|inlining procedure: k4058 
o|substituted constant variable: a4089 
o|contracted procedure: "(csi.scm:184) string-index720" 
o|inlining procedure: k3979 
o|inlining procedure: k3979 
o|inlining procedure: k4004 
o|substituted constant variable: a4099 
o|inlining procedure: k4163 
o|propagated global variable: out772775 ##sys#standard-output 
o|substituted constant variable: a4170 
o|substituted constant variable: a4171 
o|inlining procedure: k4163 
o|propagated global variable: out772775 ##sys#standard-output 
o|inlining procedure: k4210 
o|inlining procedure: k4210 
o|inlining procedure: k4286 
o|inlining procedure: k4286 
o|contracted procedure: "(csi.scm:269) chicken.csi#tty-input?" 
o|inlining procedure: k4276 
o|inlining procedure: k4276 
o|inlining procedure: k4311 
o|inlining procedure: k4311 
o|inlining procedure: k4349 
o|inlining procedure: k4349 
o|inlining procedure: k4370 
o|contracted procedure: "(csi.scm:299) g864865" 
o|inlining procedure: k4370 
o|inlining procedure: k4410 
o|inlining procedure: k4410 
o|consed rest parameter at call site: "(csi.scm:318) chicken.csi#describe" 2 
o|inlining procedure: k4443 
o|consed rest parameter at call site: "(csi.scm:322) chicken.csi#dump" 2 
o|inlining procedure: k4443 
o|consed rest parameter at call site: "(csi.scm:328) chicken.csi#dump" 2 
o|inlining procedure: k4479 
o|consed rest parameter at call site: "(csi.scm:329) chicken.csi#report" 1 
o|inlining procedure: k4479 
o|inlining procedure: k4497 
o|inlining procedure: k4515 
o|inlining procedure: k4515 
o|inlining procedure: k4497 
o|inlining procedure: k4571 
o|inlining procedure: k4571 
o|inlining procedure: k4595 
o|inlining procedure: k4595 
o|inlining procedure: k4650 
o|consed rest parameter at call site: "(csi.scm:347) chicken.csi#describe" 2 
o|inlining procedure: k4650 
o|inlining procedure: k4663 
o|inlining procedure: k4663 
o|contracted procedure: "(csi.scm:356) chicken.csi#history-clear" 
o|inlining procedure: k4713 
o|inlining procedure: k4713 
o|inlining procedure: k4737 
o|inlining procedure: k4737 
o|inlining procedure: k4766 
o|inlining procedure: k4766 
o|inlining procedure: k4822 
o|contracted procedure: "(csi.scm:397) g959966" 
o|inlining procedure: k4799 
o|inlining procedure: k4799 
o|inlining procedure: k4822 
o|propagated global variable: g965967 chicken.csi#command-table 
o|substituted constant variable: a4849 
o|substituted constant variable: a4851 
o|substituted constant variable: a4853 
o|substituted constant variable: a4855 
o|substituted constant variable: a4857 
o|substituted constant variable: a4859 
o|substituted constant variable: a4861 
o|substituted constant variable: a4863 
o|substituted constant variable: a4865 
o|substituted constant variable: a4867 
o|substituted constant variable: a4869 
o|substituted constant variable: a4871 
o|substituted constant variable: a4873 
o|substituted constant variable: a4875 
o|substituted constant variable: a4877 
o|substituted constant variable: a4879 
o|substituted constant variable: a4881 
o|substituted constant variable: a4883 
o|substituted constant variable: a4885 
o|merged explicitly consed rest parameter: port1046 
o|substituted constant variable: a5093 
o|substituted constant variable: a5112 
o|inlining procedure: k5119 
o|inlining procedure: k5119 
o|inlining procedure: k5157 
o|inlining procedure: k5157 
o|inlining procedure: k5249 
o|inlining procedure: k5249 
o|inlining procedure: k5282 
o|inlining procedure: k5282 
o|propagated global variable: g10731077 ##sys#features 
o|merged explicitly consed rest parameter: rest11551157 
o|inlining procedure: k5415 
o|inlining procedure: k5415 
o|inlining procedure: k5444 
o|inlining procedure: k5474 
o|inlining procedure: k5474 
o|inlining procedure: k5444 
o|inlining procedure: k5531 
o|inlining procedure: k5531 
o|inlining procedure: k5555 
o|inlining procedure: k5555 
o|inlining procedure: k5573 
o|inlining procedure: k5573 
o|inlining procedure: k5591 
o|inlining procedure: k5591 
o|inlining procedure: k5624 
o|inlining procedure: k5624 
o|inlining procedure: k5639 
o|inlining procedure: k5639 
o|inlining procedure: k5658 
o|inlining procedure: k5658 
o|inlining procedure: k5664 
o|inlining procedure: k5664 
o|inlining procedure: k5682 
o|inlining procedure: k5682 
o|inlining procedure: k5704 
o|inlining procedure: k5734 
o|inlining procedure: k5734 
o|inlining procedure: k5704 
o|inlining procedure: k5809 
o|inlining procedure: k5809 
o|inlining procedure: k5830 
o|inlining procedure: k5830 
o|inlining procedure: k5865 
o|inlining procedure: k5865 
o|inlining procedure: k5887 
o|inlining procedure: k5887 
o|inlining procedure: k5935 
o|inlining procedure: k5956 
o|inlining procedure: k5956 
o|inlining procedure: k5968 
o|inlining procedure: k5968 
o|inlining procedure: k5980 
o|inlining procedure: k5980 
o|inlining procedure: k5992 
o|inlining procedure: k5992 
o|inlining procedure: k6004 
o|inlining procedure: k6004 
o|inlining procedure: k6016 
o|inlining procedure: k6016 
o|substituted constant variable: a6029 
o|substituted constant variable: a6031 
o|substituted constant variable: a6033 
o|substituted constant variable: a6035 
o|substituted constant variable: a6037 
o|substituted constant variable: a6039 
o|substituted constant variable: a6041 
o|substituted constant variable: a6043 
o|substituted constant variable: a6045 
o|substituted constant variable: a6047 
o|substituted constant variable: a6049 
o|substituted constant variable: a6051 
o|inlining procedure: k5935 
o|inlining procedure: k6065 
o|inlining procedure: k6065 
o|inlining procedure: k6090 
o|inlining procedure: k6117 
o|inlining procedure: k6117 
o|inlining procedure: k6155 
o|inlining procedure: k6155 
o|inlining procedure: k6090 
o|inlining procedure: k6214 
o|inlining procedure: k6214 
o|inlining procedure: k6269 
o|inlining procedure: k6269 
o|inlining procedure: k6293 
o|inlining procedure: k6351 
o|inlining procedure: k6351 
o|inlining procedure: k6319 
o|inlining procedure: k6319 
o|inlining procedure: k6293 
o|contracted procedure: "(csi.scm:638) chicken.csi#improper-pairs?" 
o|inlining procedure: k5362 
o|inlining procedure: k5362 
o|contracted procedure: "(csi.scm:638) chicken.csi#circular-list?" 
o|inlining procedure: k5327 
o|inlining procedure: k5347 
o|inlining procedure: k5347 
o|inlining procedure: k5327 
o|merged explicitly consed rest parameter: len-out1345 
o|inlining procedure: k6438 
o|inlining procedure: k6438 
o|inlining procedure: k6444 
o|inlining procedure: k6444 
o|inlining procedure: k6470 
o|inlining procedure: k6470 
o|inlining procedure: k6496 
o|inlining procedure: k6496 
o|inlining procedure: k6549 
o|inlining procedure: k6549 
o|inlining procedure: k6590 
o|inlining procedure: k6590 
o|inlining procedure: k6616 
o|inlining procedure: k6616 
o|inlining procedure: k6650 
o|inlining procedure: k6650 
o|inlining procedure: k6701 
o|inlining procedure: k6719 
o|inlining procedure: k6719 
o|inlining procedure: k6735 
o|inlining procedure: k6735 
o|inlining procedure: k6701 
o|inlining procedure: k6821 
o|propagated global variable: out14571460 ##sys#standard-output 
o|substituted constant variable: a6846 
o|substituted constant variable: a6847 
o|inlining procedure: k6821 
o|inlining procedure: k6895 
o|inlining procedure: k6895 
o|inlining procedure: k6910 
o|propagated global variable: out14971500 ##sys#standard-output 
o|substituted constant variable: a6917 
o|substituted constant variable: a6918 
o|inlining procedure: k6910 
o|propagated global variable: out14971500 ##sys#standard-output 
o|inlining procedure: k6969 
o|inlining procedure: k6969 
o|propagated global variable: out14691472 ##sys#standard-output 
o|substituted constant variable: a7007 
o|substituted constant variable: a7008 
o|propagated global variable: out14691472 ##sys#standard-output 
o|inlining procedure: k7023 
o|inlining procedure: k7023 
o|inlining procedure: k7037 
o|propagated global variable: out14571460 ##sys#standard-output 
o|inlining procedure: k7037 
o|inlining procedure: k7043 
o|inlining procedure: k7043 
o|propagated global variable: tmp14381440 ##sys#repl-recent-call-chain 
o|propagated global variable: tmp14381440 ##sys#repl-recent-call-chain 
o|inlining procedure: k7061 
o|inlining procedure: k7061 
o|inlining procedure: k7095 
o|inlining procedure: k7095 
o|inlining procedure: k7152 
o|inlining procedure: k7183 
o|inlining procedure: k7183 
o|inlining procedure: k7223 
o|inlining procedure: k7223 
o|inlining procedure: k7302 
o|inlining procedure: k7302 
o|inlining procedure: k7152 
o|inlining procedure: k7345 
o|inlining procedure: k7345 
o|propagated global variable: tmp15481550 ##sys#repl-recent-call-chain 
o|propagated global variable: tmp15481550 ##sys#repl-recent-call-chain 
o|inlining procedure: k7366 
o|inlining procedure: k7378 
o|inlining procedure: k7378 
o|inlining procedure: k7366 
o|inlining procedure: k7421 
o|inlining procedure: k7421 
o|inlining procedure: k7436 
o|inlining procedure: k7456 
o|inlining procedure: k7486 
o|contracted procedure: "(csi.scm:952) g16931702" 
o|inlining procedure: k7486 
o|inlining procedure: k7456 
o|contracted procedure: "(csi.scm:951) chicken.csi#findall" 
o|substituted constant variable: chicken.csi#constant1665 
o|inlining procedure: k7567 
o|inlining procedure: k7567 
o|inlining procedure: k7436 
o|inlining procedure: k7537 
o|substituted constant variable: chicken.csi#constant1671 
o|inlining procedure: k7537 
o|contracted procedure: "(csi.scm:1133) chicken.csi#run" 
o|inlining procedure: k7646 
o|inlining procedure: k7646 
o|inlining procedure: k7641 
o|inlining procedure: k7641 
o|merged explicitly consed rest parameter: rest18811883 
o|inlining procedure: k7760 
o|inlining procedure: k7760 
o|inlining procedure: k7879 
o|contracted procedure: "(csi.scm:1091) chicken.csi#register-repl-history!" 
o|inlining procedure: k4234 
o|inlining procedure: k4234 
o|inlining procedure: k7879 
o|inlining procedure: k7913 
o|inlining procedure: k7913 
o|substituted constant variable: a7954 
o|inlining procedure: k7951 
o|consed rest parameter at call site: "(csi.scm:1102) evalstring1820" 2 
o|inlining procedure: k7951 
o|substituted constant variable: a7973 
o|consed rest parameter at call site: "(csi.scm:1105) evalstring1820" 2 
o|substituted constant variable: a7998 
o|inlining procedure: k7995 
o|consed rest parameter at call site: "(csi.scm:1108) evalstring1820" 2 
o|inlining procedure: k7995 
o|inlining procedure: k8058 
o|inlining procedure: k8058 
o|inlining procedure: k8071 
o|inlining procedure: k8103 
o|inlining procedure: k8103 
o|substituted constant variable: a8125 
o|propagated global variable: g20492050 chicken.pretty-print#pretty-print 
o|inlining procedure: k8071 
o|substituted constant variable: a8140 
o|substituted constant variable: a8142 
o|substituted constant variable: a8144 
o|substituted constant variable: a8146 
o|substituted constant variable: chicken.csi#constant1743 
o|substituted constant variable: chicken.csi#constant1735 
o|contracted procedure: "(csi.scm:1085) loadinit1819" 
o|inlining procedure: k7691 
o|inlining procedure: k7691 
o|inlining procedure: k7715 
o|substituted constant variable: a7728 
o|inlining procedure: k7715 
o|inlining procedure: k8158 
o|inlining procedure: k8158 
o|inlining procedure: k8199 
o|inlining procedure: k8199 
o|inlining procedure: k8211 
o|inlining procedure: k8211 
o|inlining procedure: k8220 
o|inlining procedure: k8220 
o|inlining procedure: k8238 
o|inlining procedure: k8238 
o|contracted procedure: "(csi.scm:1049) chicken.csi#delete-duplicates" 
o|inlining procedure: k3124 
o|inlining procedure: k3124 
o|contracted procedure: "(mini-srfi-1.scm:123) chicken.csi#delete" 
o|inlining procedure: k3049 
o|inlining procedure: k3049 
o|inlining procedure: k8307 
o|inlining procedure: k8307 
o|inlining procedure: k8341 
o|inlining procedure: k8341 
o|inlining procedure: k8375 
o|inlining procedure: k8375 
o|inlining procedure: k8398 
o|inlining procedure: k8398 
o|inlining procedure: k8421 
o|inlining procedure: k8421 
o|inlining procedure: k8459 
o|inlining procedure: k8459 
o|contracted procedure: "(csi.scm:1028) chicken.csi#print-usage" 
o|inlining procedure: k8504 
o|inlining procedure: k8504 
o|inlining procedure: k8539 
o|inlining procedure: k8539 
o|inlining procedure: k8542 
o|inlining procedure: k8542 
o|inlining procedure: k8548 
o|inlining procedure: k8548 
o|inlining procedure: k8566 
o|inlining procedure: k8566 
o|substituted constant variable: a8586 
o|inlining procedure: k8606 
o|inlining procedure: k8606 
o|substituted constant variable: a8609 
o|inlining procedure: k8640 
o|inlining procedure: k8640 
o|contracted procedure: "(csi.scm:974) chicken.csi#parse-option-string" 
o|inlining procedure: k4958 
o|contracted procedure: "(csi.scm:437) g10041013" 
o|inlining procedure: k4928 
o|inlining procedure: k4928 
o|inlining procedure: k4958 
o|inlining procedure: k5026 
o|inlining procedure: k5026 
o|inlining procedure: k8682 
o|inlining procedure: k8682 
o|inlining procedure: k8728 
o|inlining procedure: k8728 
o|substituted constant variable: a8738 
o|inlining procedure: k8742 
o|inlining procedure: k8742 
o|replaced variables: 958 
o|removed binding forms: 394 
o|removed side-effect free assignment to unused variable: chicken.csi#constant193 
o|removed side-effect free assignment to unused variable: chicken.csi#every 
o|removed side-effect free assignment to unused variable: chicken.csi#any 
o|removed side-effect free assignment to unused variable: chicken.csi#filter 
o|removed side-effect free assignment to unused variable: chicken.csi#list-tabulate 
o|substituted constant variable: int711716 
o|substituted constant variable: r40598783 
o|substituted constant variable: r39808784 
o|substituted constant variable: r40058786 
o|contracted procedure: "(csi.scm:359) chicken.csi#history-show" 
o|propagated global variable: out772775 ##sys#standard-output 
o|contracted procedure: "(csi.scm:365) chicken.csi#select-frame" 
o|contracted procedure: "(csi.scm:368) chicken.csi#copy-from-frame" 
o|converted assignments to bindings: (fail1563) 
o|converted assignments to bindings: (compare1558) 
o|substituted constant variable: r73468988 
o|converted assignments to bindings: (shorten1055) 
o|substituted constant variable: r54758850 
o|substituted constant variable: r54758850 
o|substituted constant variable: r54758852 
o|substituted constant variable: r54758852 
o|inlining procedure: k5603 
o|inlining procedure: k5531 
o|substituted constant variable: r56598875 
o|substituted constant variable: r56598875 
o|substituted constant variable: r56598877 
o|substituted constant variable: r56598877 
o|inlining procedure: k5531 
o|removed call to pure procedure with unused result: "(csi.scm:652) ##sys#size" 
o|substituted constant variable: r59578896 
o|substituted constant variable: r59578896 
o|inlining procedure: k5956 
o|inlining procedure: k5956 
o|substituted constant variable: r59698900 
o|inlining procedure: k5956 
o|inlining procedure: k5956 
o|substituted constant variable: r59818902 
o|inlining procedure: k5956 
o|inlining procedure: k5956 
o|substituted constant variable: r59938904 
o|inlining procedure: k5956 
o|inlining procedure: k5956 
o|substituted constant variable: r60058906 
o|inlining procedure: k5956 
o|inlining procedure: k5956 
o|substituted constant variable: r60178908 
o|inlining procedure: k5956 
o|inlining procedure: k5956 
o|substituted constant variable: r53638929 
o|substituted constant variable: r53288934 
o|converted assignments to bindings: (descseq1163) 
o|converted assignments to bindings: (bestlen1364) 
o|converted assignments to bindings: (justify1387) 
o|propagated global variable: out14571460 ##sys#standard-output 
o|propagated global variable: out14971500 ##sys#standard-output 
o|propagated global variable: out14691472 ##sys#standard-output 
o|substituted constant variable: r70248965 
o|substituted constant variable: r70248965 
o|substituted constant variable: r70248967 
o|substituted constant variable: r70248967 
o|substituted constant variable: r70388969 
o|substituted constant variable: r70388969 
o|substituted constant variable: r70388971 
o|substituted constant variable: r70388971 
o|substituted constant variable: r70448974 
o|converted assignments to bindings: (prin11435) 
o|substituted constant variable: r73678992 
o|removed side-effect free assignment to unused variable: chicken.csi#constant1665 
o|removed side-effect free assignment to unused variable: chicken.csi#constant1671 
o|substituted constant variable: r74228993 
o|substituted constant variable: clist1722 
o|substituted constant variable: r75389004 
o|removed side-effect free assignment to unused variable: chicken.csi#constant1735 
o|removed side-effect free assignment to unused variable: chicken.csi#constant1743 
o|substituted constant variable: r76429008 
o|substituted constant variable: r80599023 
o|substituted constant variable: r80599023 
o|substituted constant variable: r80729029 
o|substituted constant variable: r80729029 
o|substituted constant variable: r77169034 
o|substituted constant variable: r85409085 
o|substituted constant variable: r85409085 
o|substituted constant variable: r86419096 
o|substituted constant variable: r87299107 
o|substituted constant variable: r87299107 
o|converted assignments to bindings: (addext719) 
o|simplifications: ((let . 8)) 
o|replaced variables: 25 
o|removed binding forms: 981 
o|inlining procedure: k3889 
o|inlining procedure: k7204 
o|contracted procedure: k5893 
o|inlining procedure: k6220 
o|inlining procedure: k7888 
o|inlining procedure: k7903 
o|inlining procedure: k7903 
o|inlining procedure: k7903 
o|inlining procedure: k7903 
o|inlining procedure: k7903 
o|inlining procedure: k7903 
o|inlining procedure: k7903 
o|inlining procedure: k8115 
o|inlining procedure: k7703 
o|inlining procedure: "(csi.scm:1083) chicken.csi#print-banner" 
o|inlining procedure: k8444 
o|inlining procedure: "(csi.scm:1031) chicken.csi#print-banner" 
o|inlining procedure: k8597 
o|inlining procedure: k8597 
o|inlining procedure: k8597 
o|replaced variables: 12 
o|removed binding forms: 105 
o|removed side-effect free assignment to unused variable: chicken.csi#print-banner 
o|substituted constant variable: r38909312 
o|substituted constant variable: r38909312 
o|substituted constant variable: r38909312 
o|inlining procedure: k4289 
o|substituted constant variable: r59579175 
o|substituted constant variable: r59579177 
o|substituted constant variable: r59579179 
o|substituted constant variable: r59579181 
o|substituted constant variable: r59579183 
o|substituted constant variable: r59579185 
o|substituted constant variable: r59579187 
o|substituted constant variable: r59579189 
o|substituted constant variable: r59579191 
o|substituted constant variable: r59579193 
o|substituted constant variable: r59579195 
o|substituted constant variable: r77049437 
o|replaced variables: 2 
o|removed binding forms: 26 
o|removed conditional forms: 2 
o|replaced variables: 1 
o|removed binding forms: 16 
o|simplifications: ((let . 1)) 
o|removed binding forms: 1 
o|simplifications: ((if . 41) (##core#call . 549)) 
o|  call simplifications:
o|    scheme#make-vector
o|    scheme#set-car!
o|    ##sys#cons	2
o|    scheme#char-whitespace?
o|    ##sys#list	3
o|    chicken.base#void
o|    scheme#member	9
o|    scheme#string->list
o|    scheme#string
o|    scheme#equal?	4
o|    chicken.fixnum#fxmod
o|    scheme#write-char	7
o|    ##sys#immediate?	2
o|    ##sys#permanent?
o|    scheme#char?
o|    chicken.base#fixnum?	2
o|    chicken.base#bignum?
o|    chicken.base#flonum?
o|    chicken.base#ratnum?
o|    chicken.base#cplxnum?
o|    scheme#vector?
o|    scheme#list?
o|    scheme#procedure?
o|    ##sys#pointer?	2
o|    ##sys#generic-structure?	2
o|    scheme#cdr	19
o|    scheme#caar
o|    scheme#cdar
o|    chicken.fixnum#fx=	3
o|    chicken.base#atom?
o|    scheme#memq	3
o|    scheme#cddr	3
o|    scheme#exact?
o|    scheme#integer->char	2
o|    scheme#char->integer
o|    ##sys#setslot	9
o|    scheme#<=
o|    scheme#+
o|    scheme#*
o|    ##sys#/-2
o|    scheme#eof-object?	4
o|    scheme#caddr
o|    scheme#symbol?	2
o|    scheme#string?	4
o|    ##sys#structure?	4
o|    ##sys#check-list	17
o|    scheme#string-length	4
o|    chicken.fixnum#fxmin
o|    scheme#string=?	6
o|    scheme#number?	2
o|    chicken.fixnum#fx<	4
o|    scheme#length	4
o|    chicken.fixnum#fx-	11
o|    scheme#list-ref	2
o|    scheme#>=	2
o|    scheme#eq?	44
o|    scheme#not	11
o|    scheme#apply	5
o|    ##sys#call-with-values	6
o|    ##sys#apply	2
o|    scheme#cadr	13
o|    scheme#car	21
o|    ##sys#check-symbol	2
o|    ##sys#check-string
o|    scheme#assq	4
o|    scheme#cons	25
o|    scheme#list	11
o|    scheme#set-cdr!	2
o|    chicken.fixnum#fx<=
o|    scheme#vector-ref	8
o|    scheme#null?	24
o|    ##sys#void	20
o|    chicken.fixnum#fx*
o|    scheme#vector-set!
o|    chicken.fixnum#fx>=	15
o|    chicken.fixnum#fx+	20
o|    scheme#pair?	31
o|    ##sys#slot	86
o|    ##sys#foreign-block-argument
o|    ##sys#foreign-fixnum-argument
o|    ##sys#size	12
o|    scheme#string-ref	4
o|    chicken.fixnum#fx>	6
o|    scheme#char=?	6
o|contracted procedure: k3832 
o|contracted procedure: k3889 
o|contracted procedure: k3905 
o|contracted procedure: k3908 
o|contracted procedure: k3920 
o|contracted procedure: k4096 
o|contracted procedure: k4007 
o|contracted procedure: k3937 
o|contracted procedure: k3941 
o|contracted procedure: k4061 
o|contracted procedure: k4077 
o|contracted procedure: k4086 
o|contracted procedure: k3970 
o|contracted procedure: k3982 
o|contracted procedure: k3995 
o|contracted procedure: k4092 
o|contracted procedure: k4101 
o|contracted procedure: k4135 
o|contracted procedure: k4108 
o|contracted procedure: k4111 
o|contracted procedure: k4117 
o|contracted procedure: k4121 
o|contracted procedure: k4124 
o|contracted procedure: k4132 
o|contracted procedure: k4222 
o|contracted procedure: k4213 
o|contracted procedure: k4340 
o|contracted procedure: k4299 
o|contracted procedure: k4302 
o|contracted procedure: k4305 
o|contracted procedure: k4308 
o|contracted procedure: k4323 
o|contracted procedure: k4334 
o|contracted procedure: k4330 
o|contracted procedure: k4352 
o|contracted procedure: k4364 
o|contracted procedure: k4367 
o|contracted procedure: k4375 
o|contracted procedure: k4390 
o|contracted procedure: k4413 
o|contracted procedure: k4431 
o|contracted procedure: k4446 
o|contracted procedure: k4461 
o|contracted procedure: k4482 
o|contracted procedure: k4491 
o|contracted procedure: k4500 
o|contracted procedure: k4518 
o|contracted procedure: k4528 
o|contracted procedure: k4532 
o|contracted procedure: k4542 
o|contracted procedure: k4574 
o|contracted procedure: k4584 
o|contracted procedure: k4588 
o|contracted procedure: k4598 
o|contracted procedure: k4647 
o|contracted procedure: k4660 
o|contracted procedure: k4666 
o|contracted procedure: k4682 
o|contracted procedure: k4675 
o|contracted procedure: k4694 
o|contracted procedure: k4704 
o|contracted procedure: k4151 
o|propagated global variable: r4152 ##sys#undefined-value 
o|contracted procedure: k4716 
o|contracted procedure: k4166 
o|propagated global variable: g9872 chicken.csi#history-count 
o|contracted procedure: k4191 
o|contracted procedure: k4201 
o|contracted procedure: k4728 
o|contracted procedure: k4740 
o|contracted procedure: k7112 
o|contracted procedure: k7064 
o|contracted procedure: k7085 
o|contracted procedure: k7089 
o|contracted procedure: k7081 
o|contracted procedure: k7074 
o|contracted procedure: k7092 
o|contracted procedure: k7098 
o|contracted procedure: k7108 
o|contracted procedure: k4756 
o|contracted procedure: k7118 
o|contracted procedure: k7121 
o|contracted procedure: k7130 
o|contracted procedure: k7145 
o|contracted procedure: k7149 
o|contracted procedure: k7141 
o|contracted procedure: k7174 
o|propagated global variable: r7175 ##sys#undefined-value 
o|contracted procedure: k7186 
o|contracted procedure: k7192 
o|contracted procedure: k7195 
o|contracted procedure: k7198 
o|contracted procedure: k7201 
o|contracted procedure: k7212 
o|contracted procedure: k7226 
o|contracted procedure: k7236 
o|contracted procedure: k7260 
o|contracted procedure: k7268 
o|contracted procedure: k7264 
o|contracted procedure: k7274 
o|contracted procedure: k7277 
o|contracted procedure: k7280 
o|contracted procedure: k7283 
o|contracted procedure: k7286 
o|contracted procedure: k7330 
o|contracted procedure: k7305 
o|contracted procedure: k7315 
o|contracted procedure: k7319 
o|contracted procedure: k7323 
o|contracted procedure: k7327 
o|contracted procedure: k7339 
o|contracted procedure: k7348 
o|contracted procedure: k4769 
o|contracted procedure: k4782 
o|contracted procedure: k4788 
o|contracted procedure: k4810 
o|contracted procedure: k4825 
o|contracted procedure: k4835 
o|contracted procedure: k4839 
o|contracted procedure: k4796 
o|propagated global variable: g965967 chicken.csi#command-table 
o|contracted procedure: k4904 
o|contracted procedure: k4911 
o|contracted procedure: k5095 
o|contracted procedure: k5109 
o|contracted procedure: k5122 
o|substituted constant variable: g9884 
o|contracted procedure: k5136 
o|substituted constant variable: g9886 
o|contracted procedure: k5142 
o|contracted procedure: k5145 
o|contracted procedure: k5168 
o|contracted procedure: k5204 
o|contracted procedure: k5208 
o|contracted procedure: k5212 
o|contracted procedure: k5216 
o|contracted procedure: k5220 
o|contracted procedure: k5224 
o|contracted procedure: k5232 
o|contracted procedure: k5236 
o|contracted procedure: k5252 
o|contracted procedure: k5262 
o|contracted procedure: k5266 
o|contracted procedure: k5270 
o|contracted procedure: k5273 
o|contracted procedure: k5285 
o|contracted procedure: k5288 
o|contracted procedure: k5291 
o|contracted procedure: k5299 
o|contracted procedure: k5307 
o|propagated global variable: g10731077 ##sys#features 
o|contracted procedure: k5313 
o|contracted procedure: k6415 
o|contracted procedure: k5394 
o|contracted procedure: k5400 
o|contracted procedure: k5412 
o|contracted procedure: k5421 
o|contracted procedure: k5428 
o|contracted procedure: k5514 
o|contracted procedure: k5438 
o|contracted procedure: k5447 
o|contracted procedure: k5460 
o|contracted procedure: k5463 
o|contracted procedure: k5470 
o|contracted procedure: k5477 
o|contracted procedure: k5492 
o|contracted procedure: k5499 
o|contracted procedure: k5503 
o|contracted procedure: k5518 
o|contracted procedure: k5537 
o|contracted procedure: k5540 
o|contracted procedure: k5549 
o|contracted procedure: k5558 
o|contracted procedure: k5567 
o|contracted procedure: k5576 
o|contracted procedure: k6402 
o|contracted procedure: k5585 
o|propagated global variable: r6403 ##sys#undefined-value 
o|contracted procedure: k5594 
o|contracted procedure: k5600 
o|contracted procedure: k5609 
o|contracted procedure: k5618 
o|contracted procedure: k5633 
o|contracted procedure: k5642 
o|contracted procedure: k5651 
o|contracted procedure: k5661 
o|contracted procedure: k5667 
o|contracted procedure: k5676 
o|contracted procedure: k5685 
o|contracted procedure: k5707 
o|contracted procedure: k5716 
o|contracted procedure: k5722 
o|contracted procedure: k5737 
o|contracted procedure: k5753 
o|contracted procedure: k5763 
o|contracted procedure: k5767 
o|contracted procedure: k5771 
o|contracted procedure: k5803 
o|contracted procedure: k5812 
o|contracted procedure: k5815 
o|contracted procedure: k5859 
o|contracted procedure: k5824 
o|contracted procedure: k5853 
o|contracted procedure: k5833 
o|contracted procedure: k5845 
o|contracted procedure: k5868 
o|contracted procedure: k5877 
o|contracted procedure: k5890 
o|contracted procedure: k5932 
o|contracted procedure: k5917 
o|contracted procedure: k5921 
o|contracted procedure: k5925 
o|contracted procedure: k5949 
o|contracted procedure: k5953 
o|contracted procedure: k5959 
o|contracted procedure: k5965 
o|contracted procedure: k5971 
o|contracted procedure: k5977 
o|contracted procedure: k5983 
o|contracted procedure: k5989 
o|contracted procedure: k5995 
o|contracted procedure: k6001 
o|contracted procedure: k6007 
o|contracted procedure: k6013 
o|contracted procedure: k6019 
o|contracted procedure: k6025 
o|contracted procedure: k6055 
o|contracted procedure: k6071 
o|contracted procedure: k6093 
o|contracted procedure: k6096 
o|contracted procedure: k6105 
o|contracted procedure: k6108 
o|contracted procedure: k6120 
o|contracted procedure: k6129 
o|contracted procedure: k6133 
o|contracted procedure: k6136 
o|contracted procedure: k6139 
o|contracted procedure: k6149 
o|contracted procedure: k6158 
o|contracted procedure: k6168 
o|contracted procedure: k6172 
o|contracted procedure: k6176 
o|contracted procedure: k6187 
o|contracted procedure: k6180 
o|contracted procedure: k6184 
o|contracted procedure: k6193 
o|contracted procedure: k6208 
o|contracted procedure: k6217 
o|contracted procedure: k6227 
o|contracted procedure: k6254 
o|contracted procedure: k6230 
o|contracted procedure: k6246 
o|contracted procedure: k6250 
o|contracted procedure: k62279354 
o|contracted procedure: k6257 
o|contracted procedure: k6260 
o|contracted procedure: k6272 
o|contracted procedure: k6282 
o|contracted procedure: k6286 
o|contracted procedure: k6290 
o|contracted procedure: k6296 
o|contracted procedure: k6299 
o|contracted procedure: k6316 
o|contracted procedure: k6332 
o|contracted procedure: k6335 
o|contracted procedure: k6338 
o|contracted procedure: k6345 
o|contracted procedure: k6354 
o|contracted procedure: k6357 
o|contracted procedure: k6360 
o|contracted procedure: k6368 
o|contracted procedure: k6376 
o|contracted procedure: k6392 
o|contracted procedure: k5384 
o|contracted procedure: k5365 
o|contracted procedure: k5380 
o|contracted procedure: k5368 
o|contracted procedure: k5330 
o|contracted procedure: k5337 
o|contracted procedure: k5341 
o|contracted procedure: k5344 
o|contracted procedure: k6405 
o|contracted procedure: k6424 
o|contracted procedure: k6447 
o|contracted procedure: k6467 
o|contracted procedure: k6473 
o|contracted procedure: k6484 
o|contracted procedure: k6536 
o|contracted procedure: k6529 
o|contracted procedure: k6490 
o|contracted procedure: k6502 
o|contracted procedure: k6513 
o|contracted procedure: k6519 
o|contracted procedure: k6526 
o|contracted procedure: k6552 
o|contracted procedure: k6558 
o|contracted procedure: k6565 
o|contracted procedure: k6571 
o|contracted procedure: k6587 
o|contracted procedure: k6593 
o|contracted procedure: k6605 
o|contracted procedure: k6619 
o|contracted procedure: k6644 
o|contracted procedure: k6653 
o|contracted procedure: k6656 
o|contracted procedure: k6669 
o|contracted procedure: k6673 
o|contracted procedure: k6689 
o|contracted procedure: k6676 
o|contracted procedure: k6683 
o|contracted procedure: k6704 
o|contracted procedure: k6707 
o|contracted procedure: k6713 
o|contracted procedure: k6716 
o|contracted procedure: k6722 
o|contracted procedure: k6729 
o|contracted procedure: k6738 
o|contracted procedure: k6748 
o|contracted procedure: k6761 
o|contracted procedure: k6765 
o|contracted procedure: k6798 
o|contracted procedure: k6801 
o|contracted procedure: k6805 
o|contracted procedure: k6815 
o|contracted procedure: k6824 
o|contracted procedure: k6827 
o|contracted procedure: k6830 
o|contracted procedure: k6833 
o|contracted procedure: k6836 
o|contracted procedure: k6839 
o|contracted procedure: k6842 
o|contracted procedure: k6887 
o|contracted procedure: k6890 
o|contracted procedure: k6898 
o|contracted procedure: k6913 
o|contracted procedure: k6938 
o|contracted procedure: k6944 
o|contracted procedure: k6948 
o|contracted procedure: k6951 
o|contracted procedure: k6954 
o|contracted procedure: k6957 
o|contracted procedure: k6960 
o|contracted procedure: k6997 
o|contracted procedure: k6972 
o|contracted procedure: k6982 
o|contracted procedure: k6986 
o|contracted procedure: k6990 
o|contracted procedure: k6994 
o|contracted procedure: k7019 
o|contracted procedure: k7033 
o|contracted procedure: k7046 
o|contracted procedure: k7053 
o|contracted procedure: k7354 
o|contracted procedure: k7369 
o|contracted procedure: k7381 
o|contracted procedure: k7388 
o|contracted procedure: k7403 
o|contracted procedure: k7407 
o|contracted procedure: k7394 
o|contracted procedure: k7424 
o|contracted procedure: k7427 
o|contracted procedure: k7433 
o|contracted procedure: k7445 
o|contracted procedure: k7466 
o|contracted procedure: k7489 
o|contracted procedure: k7511 
o|contracted procedure: k7507 
o|contracted procedure: k7492 
o|contracted procedure: k7495 
o|contracted procedure: k7503 
o|contracted procedure: k7564 
o|contracted procedure: k7582 
o|contracted procedure: k7573 
o|contracted procedure: k7552 
o|contracted procedure: k7534 
o|contracted procedure: k7540 
o|contracted procedure: k7547 
o|contracted procedure: k7617 
o|contracted procedure: k7623 
o|contracted procedure: k7638 
o|contracted procedure: k7670 
o|contracted procedure: k7649 
o|contracted procedure: k7659 
o|contracted procedure: k7786 
o|contracted procedure: k7744 
o|contracted procedure: k7763 
o|contracted procedure: k7818 
o|contracted procedure: k7827 
o|contracted procedure: k7836 
o|contracted procedure: k7882 
o|contracted procedure: k4237 
o|contracted procedure: k4240 
o|contracted procedure: k4251 
o|contracted procedure: k7897 
o|contracted procedure: k7900 
o|contracted procedure: k7910 
o|contracted procedure: k79109404 
o|contracted procedure: k7916 
o|contracted procedure: k7920 
o|contracted procedure: k79109408 
o|contracted procedure: k7926 
o|contracted procedure: k7929 
o|contracted procedure: k7936 
o|contracted procedure: k79109412 
o|contracted procedure: k7940 
o|contracted procedure: k7948 
o|contracted procedure: k7956 
o|contracted procedure: k7963 
o|contracted procedure: k79109416 
o|contracted procedure: k7967 
o|contracted procedure: k7975 
o|contracted procedure: k7982 
o|contracted procedure: k79109420 
o|contracted procedure: k7986 
o|contracted procedure: k8000 
o|contracted procedure: k8007 
o|contracted procedure: k79109424 
o|contracted procedure: k8011 
o|contracted procedure: k8020 
o|contracted procedure: k8029 
o|contracted procedure: k8064 
o|contracted procedure: k8051 
o|contracted procedure: k8061 
o|contracted procedure: k79109428 
o|contracted procedure: k8074 
o|contracted procedure: k8082 
o|contracted procedure: k8106 
o|contracted procedure: k8109 
o|contracted procedure: k8122 
o|contracted procedure: k81229432 
o|contracted procedure: k8152 
o|contracted procedure: k7731 
o|contracted procedure: k7718 
o|contracted procedure: k7738 
o|contracted procedure: k8168 
o|contracted procedure: k8172 
o|contracted procedure: k8271 
o|contracted procedure: k8267 
o|contracted procedure: k8223 
o|contracted procedure: k8263 
o|contracted procedure: k8232 
o|contracted procedure: k8241 
o|contracted procedure: k8250 
o|contracted procedure: k3127 
o|contracted procedure: k3130 
o|contracted procedure: k3140 
o|contracted procedure: k3052 
o|contracted procedure: k3078 
o|contracted procedure: k8279 
o|contracted procedure: k8285 
o|contracted procedure: k8292 
o|contracted procedure: k8298 
o|contracted procedure: k8310 
o|contracted procedure: k8313 
o|contracted procedure: k8316 
o|contracted procedure: k8324 
o|contracted procedure: k8332 
o|contracted procedure: k8344 
o|contracted procedure: k8347 
o|contracted procedure: k8350 
o|contracted procedure: k8358 
o|contracted procedure: k8366 
o|contracted procedure: k8378 
o|contracted procedure: k8388 
o|contracted procedure: k8392 
o|contracted procedure: k8401 
o|contracted procedure: k8411 
o|contracted procedure: k8415 
o|contracted procedure: k8424 
o|contracted procedure: k8434 
o|contracted procedure: k8438 
o|contracted procedure: k8466 
o|contracted procedure: k8479 
o|contracted procedure: k8483 
o|contracted procedure: k3873 
o|contracted procedure: k3869 
o|contracted procedure: k3865 
o|contracted procedure: k8507 
o|contracted procedure: k8510 
o|contracted procedure: k8513 
o|contracted procedure: k8521 
o|contracted procedure: k8529 
o|contracted procedure: k8563 
o|contracted procedure: k8581 
o|contracted procedure: k8591 
o|contracted procedure: k8630 
o|contracted procedure: k8626 
o|contracted procedure: k8594 
o|contracted procedure: k8622 
o|contracted procedure: k8618 
o|contracted procedure: k8603 
o|contracted procedure: k8611 
o|contracted procedure: k8637 
o|contracted procedure: k8658 
o|contracted procedure: k4923 
o|contracted procedure: k4949 
o|contracted procedure: k4961 
o|contracted procedure: k4964 
o|contracted procedure: k4967 
o|contracted procedure: k4975 
o|contracted procedure: k4983 
o|contracted procedure: k4931 
o|contracted procedure: k5029 
o|contracted procedure: k5043 
o|contracted procedure: k8685 
o|contracted procedure: k8752 
o|contracted procedure: k8756 
o|contracted procedure: k8760 
o|simplifications: ((if . 3) (let . 120)) 
o|removed binding forms: 500 
o|inlining procedure: k7229 
o|inlining procedure: k6878 
o|substituted constant variable: r8753 
o|substituted constant variable: r8757 
o|substituted constant variable: r8753 
o|substituted constant variable: r8757 
o|substituted constant variable: r8761 
o|replaced variables: 214 
o|removed binding forms: 2 
o|simplifications: ((if . 1)) 
o|removed binding forms: 91 
o|direct leaf routine/allocation: g834835 6 
o|direct leaf routine/allocation: lp1138 0 
o|direct leaf routine/allocation: lp1124 0 
o|direct leaf routine/allocation: loop1723 0 
o|contracted procedure: "(csi.scm:276) k4311" 
o|contracted procedure: k5790 
o|converted assignments to bindings: (lp1138) 
o|converted assignments to bindings: (lp1124) 
o|contracted procedure: k7459 
o|converted assignments to bindings: (loop1723) 
o|simplifications: ((let . 3)) 
o|removed binding forms: 3 
o|replaced variables: 2 
o|removed binding forms: 1 
o|customizable procedures: (k3845 g989990 doloop10251026 map-loop9981031 chicken.csi#canonicalize-args chicken.csi#lookup-script-file k7602 k7608 k7614 map-loop17911811 k7803 k7809 for-each-loop18231904 for-each-loop18331911 for-each-loop18431918 map-loop19251942 collect-options1818 map-loop19511968 loop354 loop374 chicken.csi#member* k7870 doloop20522053 evalstring1820 doloop18511998 chicken.csi#history-ref doloop18911892 g18611862 loop1853 k7439 map-loop16871712 loop1675 find1654 loop1651 k6808 k7026 g14801488 for-each-loop14791509 prin11435 doloop14931494 doloop14421448 justify1387 doloop13961398 doloop14051406 doloop13971413 doloop13861394 def-len13501372 def-out13511370 body13481357 k6499 bestlen1364 k5793 g13061307 map-loop13111328 g12951296 g12661273 for-each-loop12651282 loop1276 g12441251 for-each-loop12431254 doloop12381239 chicken.csi#hexdump loop-print1213 doloop12001201 loop21183 loop11173 k5068 map-loop10611078 g10881095 for-each-loop10871109 shorten1055 k5116 k4361 for-each-loop958970 k7124 g15771585 for-each-loop15761600 compare1558 doloop15901591 doloop15621567 fail1563 k7067 chicken.csi#show-frameinfo doloop769770 chicken.csi#history-add g912919 for-each-loop911931 for-each-loop892902 chicken.csi#report chicken.csi#dump chicken.csi#describe k4114 loop727 loop746 addext719) 
o|calls to known targets: 260 
o|identified direct recursive calls: f_7181 1 
o|identified direct recursive calls: f_5325 1 
o|identified direct recursive calls: f_6212 1 
o|identified direct recursive calls: f_5360 1 
o|identified direct recursive calls: f_7376 1 
o|identified direct recursive calls: f_7562 1 
o|identified direct recursive calls: f_7484 1 
o|unused rest argument: _1889 f_7789 
o|identified direct recursive calls: f_7877 2 
o|fast box initializations: 49 
o|fast global references: 77 
o|fast global assignments: 26 
o|dropping unused closure argument: f_3948 
o|dropping unused closure argument: f_4205 
o|dropping unused closure argument: f_5084 
o|dropping unused closure argument: f_5325 
o|dropping unused closure argument: f_5360 
o|dropping unused closure argument: f_6431 
o|dropping unused closure argument: f_6579 
o|dropping unused closure argument: f_6582 
o|dropping unused closure argument: f_6784 
o|dropping unused closure argument: f_6787 
o|dropping unused closure argument: f_7358 
o|dropping unused closure argument: f_7413 
o|dropping unused closure argument: f_7562 
o|dropping unused closure argument: f_7742 
*/
/* end of file */
