/* Generated from modules.scm by the CHICKEN compiler
   http://www.call-cc.org
   Version 5.1.0rc1 (prerelease) (rev 7358d2e5)
   linux-unix-gnu-x86-64 [ 64bit dload ptables ]
   command line: modules.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -consult-types-file ./types.db -explicit-use -no-trace -output-file modules.c
   unit: modules
   uses: chicken-syntax library internal expand
*/
#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_internal_toplevel)
C_externimport void C_ccall C_internal_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[242];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,10),40,108,111,111,112,32,108,115,116,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,19),40,100,101,108,101,116,101,32,120,32,108,115,116,32,116,101,115,116,41,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,15),40,109,111,100,117,108,101,45,110,97,109,101,32,120,41,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,25),40,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,32,120,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,32),40,115,101,116,45,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,32,121,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,24),40,35,35,115,121,115,35,109,111,100,117,108,101,45,101,120,112,111,114,116,115,32,109,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,45,97,108,105,97,115,32,97,108,105,97,115,32,110,97,109,101,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,7),40,97,53,53,55,56,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,7),40,97,53,53,57,53,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,97,53,54,48,49,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,56,57,57,32,103,57,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,119,105,116,104,45,109,111,100,117,108,101,45,97,108,105,97,115,101,115,32,98,105,110,100,105,110,103,115,32,116,104,117,110,107,41,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,8),40,103,57,52,51,32,97,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,110,32,100,111,110,101,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,114,101,115,111,108,118,101,45,109,111,100,117,108,101,45,110,97,109,101,32,110,97,109,101,32,108,111,99,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,110,100,45,109,111,100,117,108,101,32,110,97,109,101,32,46,32,114,101,115,116,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,8),40,103,57,56,49,32,109,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,25),40,35,35,115,121,115,35,115,119,105,116,99,104,45,109,111,100,117,108,101,32,109,111,100,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,7),40,103,49,48,49,52,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,6),40,103,57,57,56,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,24),40,102,111,114,45,101,97,99,104,45,108,111,111,112,57,57,55,32,103,49,48,48,52,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,97,100,100,45,116,111,45,101,120,112,111,114,116,45,108,105,115,116,32,109,111,100,32,101,120,112,115,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,116,111,112,108,101,118,101,108,45,100,101,102,105,110,105,116,105,111,110,45,104,111,111,107,32,115,121,109,32,114,101,110,97,109,101,100,32,101,120,112,111,114,116,101,100,63,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,30),40,99,104,101,99,107,45,102,111,114,45,114,101,100,101,102,32,115,121,109,32,101,110,118,32,115,101,110,118,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,101,120,112,111,114,116,32,115,121,109,32,109,111,100,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,115,121,110,116,97,120,45,101,120,112,111,114,116,32,115,121,109,32,109,111,100,32,118,97,108,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,11),40,97,54,49,52,54,32,120,32,121,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,115,121,110,116,97,120,45,101,120,112,111,114,116,32,115,121,109,32,109,111,100,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,47),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,32,110,97,109,101,32,108,105,98,32,101,120,112,108,105,115,116,32,46,32,114,101,115,116,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,9),40,103,49,49,56,54,32,101,41,0,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,49,56,53,32,103,49,49,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,11),40,108,112,32,115,101,32,115,101,50,41,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,101,115,32,108,97,115,116,45,115,101,32,115,101,50,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,15),40,109,101,114,103,101,45,115,101,32,115,101,115,42,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,15),40,103,49,50,55,56,32,115,101,120,112,111,114,116,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,9),40,108,111,111,112,32,115,100,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,49,50,55,50,32,103,49,50,56,52,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,49,50,51,57,32,103,49,50,53,49,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,45,114,101,103,105,115,116,114,97,116,105,111,110,32,109,111,100,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,12),40,103,49,52,48,55,32,115,101,120,112,41,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,12),40,103,49,52,49,55,32,110,101,120,112,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,52,49,54,32,103,49,52,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,52,48,54,32,103,49,52,49,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,49,51,55,52,32,103,49,51,56,54,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,49,51,52,54,32,103,49,51,53,56,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,75),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,32,110,97,109,101,32,108,105,98,32,105,101,120,112,111,114,116,115,32,118,101,120,112,111,114,116,115,32,115,101,120,112,111,114,116,115,32,46,32,114,101,115,116,41,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,10),40,103,49,52,55,53,32,115,101,41,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,49,52,54,57,32,103,49,52,56,49,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,53),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,99,111,114,101,45,109,111,100,117,108,101,32,110,97,109,101,32,108,105,98,32,118,101,120,112,111,114,116,115,32,46,32,114,101,115,116,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,105,109,105,116,105,118,101,45,109,111,100,117,108,101,32,110,97,109,101,32,118,101,120,112,111,114,116,115,32,46,32,114,101,115,116,41,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,9),40,108,111,111,112,32,120,108,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,30),40,102,105,110,100,45,101,120,112,111,114,116,32,115,121,109,32,109,111,100,32,105,110,100,105,114,101,99,116,41,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,9),40,103,49,54,52,56,32,97,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,54,52,55,32,103,49,54,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,11),40,103,49,54,49,55,32,115,121,109,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,54,49,54,32,103,49,54,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,9),40,103,49,54,48,49,32,117,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,9),40,103,49,55,49,55,32,109,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,55,49,54,32,103,49,55,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,49,54,56,49,32,103,49,54,57,51,41,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,119,97,114,110,32,109,115,103,32,105,100,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,9),40,103,49,49,52,56,32,97,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,9),40,103,49,49,53,53,32,97,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,50,32,105,101,120,112,111,114,116,115,41};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,101,120,112,111,114,116,115,41,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,54,48,48,32,103,49,54,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,9),40,108,111,111,112,32,120,108,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,9),40,108,111,111,112,32,109,101,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,49,53,52,54,32,103,49,53,53,56,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,27),40,35,35,115,121,115,35,102,105,110,97,108,105,122,101,45,109,111,100,117,108,101,32,109,111,100,41,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,7),40,97,56,50,51,53,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,7),40,97,56,50,57,55,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,7),40,97,56,51,48,50,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,7),40,97,56,51,49,49,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,7),40,97,56,50,57,49,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,7),40,97,56,51,49,54,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,105,109,112,111,114,116,45,108,105,98,114,97,114,121,45,104,111,111,107,32,109,110,97,109,101,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,36),40,102,105,110,100,45,109,111,100,117,108,101,47,105,109,112,111,114,116,45,108,105,98,114,97,114,121,32,108,105,98,32,108,111,99,41,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,17),40,119,97,114,110,32,109,115,103,32,109,111,100,32,105,100,41,0,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,9),40,116,111,115,116,114,32,120,41,0,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,105,109,112,111,114,116,115,32,110,97,109,101,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,7),40,97,56,53,51,56,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,10),40,103,49,57,48,49,32,105,100,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,57,48,48,32,103,49,57,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,9),40,103,49,57,50,49,32,97,41,0,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,9),40,103,49,57,50,53,32,97,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,105,100,115,32,118,32,115,32,109,105,115,115,105,110,103,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,60),40,97,56,53,52,56,32,110,97,109,101,49,56,54,50,32,108,105,98,49,56,54,52,32,115,112,101,99,49,56,54,54,32,105,109,112,118,49,56,54,56,32,105,109,112,115,49,56,55,48,32,105,109,112,105,49,56,55,50,41,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,7),40,97,56,54,56,56,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,10),40,103,49,57,55,57,32,105,100,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,49,57,55,56,32,103,49,57,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,10),40,103,49,57,57,57,32,105,100,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,105,109,112,115,32,115,32,105,100,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,10),40,103,50,48,48,52,32,105,100,41,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,105,109,112,118,32,118,32,105,100,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,60),40,97,56,54,57,56,32,110,97,109,101,49,57,51,50,32,108,105,98,49,57,51,52,32,115,112,101,99,49,57,51,54,32,105,109,112,118,49,57,51,56,32,105,109,112,115,49,57,52,48,32,105,109,112,105,49,57,52,50,41,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,7),40,97,56,56,55,49,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,10),40,103,50,48,53,56,32,105,100,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,50,48,53,55,32,103,50,48,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,48,55,48,32,103,50,48,56,50,41,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,9),40,103,50,49,48,52,32,97,41,0,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,105,109,112,115,32,115,32,105,100,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,9),40,103,50,49,48,57,32,97,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,105,109,112,118,32,118,32,105,100,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,60),40,97,56,56,56,49,32,110,97,109,101,50,48,49,49,32,108,105,98,50,48,49,51,32,115,112,101,99,50,48,49,53,32,105,109,112,118,50,48,49,55,32,105,109,112,115,50,48,49,57,32,105,109,112,105,50,48,50,49,41,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,7),40,97,57,49,50,49,41,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,12),40,114,101,110,97,109,101,32,105,109,112,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,49,55,53,32,103,50,49,56,55,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,49,52,57,32,103,50,49,54,49,41,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,60),40,97,57,49,51,49,32,110,97,109,101,50,49,49,54,32,108,105,98,50,49,49,56,32,115,112,101,99,50,49,50,48,32,105,109,112,118,50,49,50,50,32,105,109,112,115,50,49,50,52,32,105,109,112,105,50,49,50,54,41,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,8),40,108,111,111,112,32,120,41};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,9),40,97,56,52,52,55,32,107,41,0,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,100,101,99,111,109,112,111,115,101,45,105,109,112,111,114,116,32,120,32,114,32,99,32,108,111,99,41,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,7),40,97,57,50,56,54,41,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,49),40,97,57,50,57,50,32,110,97,109,101,50,50,50,55,32,95,50,50,50,57,32,115,112,101,99,50,50,51,49,32,118,50,50,51,51,32,115,50,50,51,53,32,105,50,50,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,9),40,103,50,50,49,55,32,120,41,0,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,50,50,49,54,32,103,50,50,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,65),40,35,35,115,121,115,35,101,120,112,97,110,100,45,105,109,112,111,114,116,32,120,32,114,32,99,32,105,109,112,111,114,116,45,101,110,118,32,109,97,99,114,111,45,101,110,118,32,109,101,116,97,63,32,114,101,101,120,112,63,32,108,111,99,41,0,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,11),40,103,50,50,55,56,32,105,109,112,41,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,11),40,103,50,50,56,56,32,105,109,112,41,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,51,53,54,32,103,50,51,54,56,41,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,51,51,48,32,103,50,51,52,50,41,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,52,49,48,32,103,50,52,50,50,41,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,51,56,52,32,103,50,51,57,54,41,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,50,50,56,55,32,103,50,50,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,50,50,55,55,32,103,50,50,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,69),40,35,35,115,121,115,35,105,109,112,111,114,116,32,115,112,101,99,32,118,115,118,32,118,115,115,32,118,115,105,32,105,109,112,111,114,116,45,101,110,118,32,109,97,99,114,111,45,101,110,118,32,109,101,116,97,63,32,114,101,101,120,112,63,32,108,111,99,41,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,26),40,109,111,100,117,108,101,45,114,101,110,97,109,101,32,115,121,109,32,112,114,101,102,105,120,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,9),40,103,49,48,57,48,32,97,41,0,0,0,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,11),40,103,50,52,54,55,32,109,111,100,41,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,13),40,109,114,101,110,97,109,101,32,115,121,109,41,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,9),40,103,50,52,55,56,32,97,41,0,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,97,108,105,97,115,45,103,108,111,98,97,108,45,104,111,111,107,32,115,121,109,32,97,115,115,105,103,110,32,119,104,101,114,101,41,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,10),40,101,114,114,32,97,114,103,115,41,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,12),40,105,102,97,99,101,32,110,97,109,101,41,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,50,32,108,115,116,41,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,10),40,108,111,111,112,32,120,112,115,41,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,118,97,108,105,100,97,116,101,45,101,120,112,111,114,116,115,32,101,120,112,115,32,108,111,99,41,0,0,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,46),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,102,117,110,99,116,111,114,32,110,97,109,101,32,102,97,114,103,115,32,102,101,120,112,115,32,98,111,100,121,41,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,10),40,101,114,114,32,97,114,103,115,41,0,0,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,53,53,54,32,103,50,53,54,56,41,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,6),40,109,101,114,114,41,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,50,32,102,97,115,41,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,97,115,32,102,97,115,41,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,105,110,115,116,97,110,116,105,97,116,101,45,102,117,110,99,116,111,114,32,110,97,109,101,32,102,110,97,109,101,32,97,114,103,115,41,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,11),40,103,50,54,49,55,32,101,120,112,41,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,54,51,56,32,103,50,54,53,48,41,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,25),40,102,111,114,45,101,97,99,104,45,108,111,111,112,50,54,49,54,32,103,50,54,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,46),40,109,97,116,99,104,45,102,117,110,99,116,111,114,45,97,114,103,117,109,101,110,116,32,110,97,109,101,32,109,110,97,109,101,32,101,120,112,115,32,102,110,97,109,101,41,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,48),40,99,104,105,99,107,101,110,46,109,111,100,117,108,101,35,109,111,100,117,108,101,45,101,110,118,105,114,111,110,109,101,110,116,32,109,110,97,109,101,32,46,32,114,101,115,116,41};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,7),40,103,51,49,51,55,41,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,51,49,51,49,32,103,51,49,52,51,41,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,7),40,103,51,48,57,57,41,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,51,48,57,51,32,103,51,49,48,53,41,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,7),40,103,51,48,54,49,41,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,51,48,53,53,32,103,51,48,54,55,41,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,7),40,103,51,48,50,51,41,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,51,48,49,55,32,103,51,48,50,57,41,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,7),40,103,50,57,56,53,41,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,57,55,57,32,103,50,57,57,49,41,0,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,7),40,103,50,57,52,55,41,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,57,52,49,32,103,50,57,53,51,41,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,7),40,103,50,57,48,57,41,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,57,48,51,32,103,50,57,49,53,41,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,7),40,103,50,56,55,49,41,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,56,54,53,32,103,50,56,55,55,41,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,7),40,103,50,56,51,51,41,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,56,50,55,32,103,50,56,51,57,41,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,7),40,103,50,55,57,53,41,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,55,56,57,32,103,50,56,48,49,41,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,7),40,103,50,55,53,55,41,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,55,53,49,32,103,50,55,54,51,41,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,7),40,103,50,55,49,57,41,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,55,49,51,32,103,50,55,50,53,41,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,7),40,103,50,54,56,49,41,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,50,54,55,53,32,103,50,54,56,55,41,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f11852)
static void C_ccall f11852(C_word c,C_word *av) C_noret;
C_noret_decl(f_10002)
static void C_fcall f_10002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10009)
static void C_ccall f_10009(C_word c,C_word *av) C_noret;
C_noret_decl(f_10013)
static void C_ccall f_10013(C_word c,C_word *av) C_noret;
C_noret_decl(f_10039)
static void C_fcall f_10039(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10053)
static void C_ccall f_10053(C_word c,C_word *av) C_noret;
C_noret_decl(f_10095)
static void C_ccall f_10095(C_word c,C_word *av) C_noret;
C_noret_decl(f_10111)
static void C_ccall f_10111(C_word c,C_word *av) C_noret;
C_noret_decl(f_10119)
static void C_fcall f_10119(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10126)
static void C_ccall f_10126(C_word c,C_word *av) C_noret;
C_noret_decl(f_10136)
static void C_fcall f_10136(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10158)
static void C_ccall f_10158(C_word c,C_word *av) C_noret;
C_noret_decl(f_10160)
static void C_fcall f_10160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10199)
static void C_ccall f_10199(C_word c,C_word *av) C_noret;
C_noret_decl(f_10220)
static void C_fcall f_10220(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10232)
static void C_fcall f_10232(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10255)
static void C_ccall f_10255(C_word c,C_word *av) C_noret;
C_noret_decl(f_10258)
static void C_ccall f_10258(C_word c,C_word *av) C_noret;
C_noret_decl(f_10269)
static void C_ccall f_10269(C_word c,C_word *av) C_noret;
C_noret_decl(f_10275)
static void C_ccall f_10275(C_word c,C_word *av) C_noret;
C_noret_decl(f_10307)
static void C_ccall f_10307(C_word c,C_word *av) C_noret;
C_noret_decl(f_10310)
static void C_ccall f_10310(C_word c,C_word *av) C_noret;
C_noret_decl(f_10321)
static void C_ccall f_10321(C_word c,C_word *av) C_noret;
C_noret_decl(f_10337)
static void C_fcall f_10337(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10341)
static void C_ccall f_10341(C_word c,C_word *av) C_noret;
C_noret_decl(f_10348)
static void C_fcall f_10348(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10361)
static void C_fcall f_10361(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10388)
static void C_ccall f_10388(C_word c,C_word *av) C_noret;
C_noret_decl(f_10401)
static void C_ccall f_10401(C_word c,C_word *av) C_noret;
C_noret_decl(f_10405)
static void C_ccall f_10405(C_word c,C_word *av) C_noret;
C_noret_decl(f_10409)
static void C_ccall f_10409(C_word c,C_word *av) C_noret;
C_noret_decl(f_10413)
static void C_ccall f_10413(C_word c,C_word *av) C_noret;
C_noret_decl(f_10427)
static void C_ccall f_10427(C_word c,C_word *av) C_noret;
C_noret_decl(f_10433)
static void C_ccall f_10433(C_word c,C_word *av) C_noret;
C_noret_decl(f_10435)
static void C_fcall f_10435(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10460)
static void C_ccall f_10460(C_word c,C_word *av) C_noret;
C_noret_decl(f_10469)
static void C_fcall f_10469(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10479)
static void C_ccall f_10479(C_word c,C_word *av) C_noret;
C_noret_decl(f_10494)
static void C_ccall f_10494(C_word c,C_word *av) C_noret;
C_noret_decl(f_10497)
static void C_ccall f_10497(C_word c,C_word *av) C_noret;
C_noret_decl(f_10500)
static void C_ccall f_10500(C_word c,C_word *av) C_noret;
C_noret_decl(f_10503)
static void C_ccall f_10503(C_word c,C_word *av) C_noret;
C_noret_decl(f_10506)
static void C_ccall f_10506(C_word c,C_word *av) C_noret;
C_noret_decl(f_10509)
static void C_ccall f_10509(C_word c,C_word *av) C_noret;
C_noret_decl(f_10512)
static void C_ccall f_10512(C_word c,C_word *av) C_noret;
C_noret_decl(f_10515)
static void C_ccall f_10515(C_word c,C_word *av) C_noret;
C_noret_decl(f_10518)
static void C_ccall f_10518(C_word c,C_word *av) C_noret;
C_noret_decl(f_10521)
static void C_ccall f_10521(C_word c,C_word *av) C_noret;
C_noret_decl(f_10524)
static void C_ccall f_10524(C_word c,C_word *av) C_noret;
C_noret_decl(f_10527)
static void C_ccall f_10527(C_word c,C_word *av) C_noret;
C_noret_decl(f_10530)
static void C_ccall f_10530(C_word c,C_word *av) C_noret;
C_noret_decl(f_10533)
static void C_ccall f_10533(C_word c,C_word *av) C_noret;
C_noret_decl(f_10536)
static void C_ccall f_10536(C_word c,C_word *av) C_noret;
C_noret_decl(f_10539)
static void C_ccall f_10539(C_word c,C_word *av) C_noret;
C_noret_decl(f_10542)
static void C_ccall f_10542(C_word c,C_word *av) C_noret;
C_noret_decl(f_10545)
static void C_ccall f_10545(C_word c,C_word *av) C_noret;
C_noret_decl(f_10548)
static void C_ccall f_10548(C_word c,C_word *av) C_noret;
C_noret_decl(f_10551)
static void C_ccall f_10551(C_word c,C_word *av) C_noret;
C_noret_decl(f_10554)
static void C_ccall f_10554(C_word c,C_word *av) C_noret;
C_noret_decl(f_10557)
static void C_ccall f_10557(C_word c,C_word *av) C_noret;
C_noret_decl(f_10560)
static void C_ccall f_10560(C_word c,C_word *av) C_noret;
C_noret_decl(f_10563)
static void C_ccall f_10563(C_word c,C_word *av) C_noret;
C_noret_decl(f_10566)
static void C_ccall f_10566(C_word c,C_word *av) C_noret;
C_noret_decl(f_10569)
static void C_ccall f_10569(C_word c,C_word *av) C_noret;
C_noret_decl(f_10572)
static void C_ccall f_10572(C_word c,C_word *av) C_noret;
C_noret_decl(f_10575)
static void C_ccall f_10575(C_word c,C_word *av) C_noret;
C_noret_decl(f_10577)
static void C_ccall f_10577(C_word c,C_word *av) C_noret;
C_noret_decl(f_10584)
static void C_ccall f_10584(C_word c,C_word *av) C_noret;
C_noret_decl(f_10613)
static void C_ccall f_10613(C_word c,C_word *av) C_noret;
C_noret_decl(f_10616)
static void C_ccall f_10616(C_word c,C_word *av) C_noret;
C_noret_decl(f_10623)
static C_word C_fcall f_10623(C_word t0,C_word t1);
C_noret_decl(f_10635)
static void C_fcall f_10635(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10670)
static void C_ccall f_10670(C_word c,C_word *av) C_noret;
C_noret_decl(f_10677)
static C_word C_fcall f_10677(C_word t0,C_word t1);
C_noret_decl(f_10689)
static void C_fcall f_10689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10724)
static void C_ccall f_10724(C_word c,C_word *av) C_noret;
C_noret_decl(f_10731)
static C_word C_fcall f_10731(C_word t0,C_word t1);
C_noret_decl(f_10743)
static void C_fcall f_10743(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10778)
static void C_ccall f_10778(C_word c,C_word *av) C_noret;
C_noret_decl(f_10785)
static C_word C_fcall f_10785(C_word t0,C_word t1);
C_noret_decl(f_10797)
static void C_fcall f_10797(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10832)
static void C_ccall f_10832(C_word c,C_word *av) C_noret;
C_noret_decl(f_10839)
static C_word C_fcall f_10839(C_word t0,C_word t1);
C_noret_decl(f_10851)
static void C_fcall f_10851(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10886)
static void C_ccall f_10886(C_word c,C_word *av) C_noret;
C_noret_decl(f_10893)
static C_word C_fcall f_10893(C_word t0,C_word t1);
C_noret_decl(f_10905)
static void C_fcall f_10905(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10940)
static void C_ccall f_10940(C_word c,C_word *av) C_noret;
C_noret_decl(f_10947)
static C_word C_fcall f_10947(C_word t0,C_word t1);
C_noret_decl(f_10959)
static void C_fcall f_10959(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10994)
static void C_ccall f_10994(C_word c,C_word *av) C_noret;
C_noret_decl(f_11001)
static C_word C_fcall f_11001(C_word t0,C_word t1);
C_noret_decl(f_11013)
static void C_fcall f_11013(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11048)
static void C_ccall f_11048(C_word c,C_word *av) C_noret;
C_noret_decl(f_11055)
static C_word C_fcall f_11055(C_word t0,C_word t1);
C_noret_decl(f_11067)
static void C_fcall f_11067(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11102)
static void C_ccall f_11102(C_word c,C_word *av) C_noret;
C_noret_decl(f_11109)
static C_word C_fcall f_11109(C_word t0,C_word t1);
C_noret_decl(f_11121)
static void C_fcall f_11121(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11156)
static void C_ccall f_11156(C_word c,C_word *av) C_noret;
C_noret_decl(f_11163)
static C_word C_fcall f_11163(C_word t0,C_word t1);
C_noret_decl(f_11175)
static void C_fcall f_11175(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11210)
static void C_ccall f_11210(C_word c,C_word *av) C_noret;
C_noret_decl(f_11217)
static C_word C_fcall f_11217(C_word t0,C_word t1);
C_noret_decl(f_11229)
static void C_fcall f_11229(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11264)
static void C_ccall f_11264(C_word c,C_word *av) C_noret;
C_noret_decl(f_11271)
static C_word C_fcall f_11271(C_word t0,C_word t1);
C_noret_decl(f_11283)
static void C_fcall f_11283(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11318)
static void C_ccall f_11318(C_word c,C_word *av) C_noret;
C_noret_decl(f_11322)
static void C_ccall f_11322(C_word c,C_word *av) C_noret;
C_noret_decl(f_11326)
static void C_ccall f_11326(C_word c,C_word *av) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word *av) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word *av) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word *av) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word *av) C_noret;
C_noret_decl(f_4483)
static void C_fcall f_4483(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4489)
static void C_fcall f_4489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word *av) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word *av) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word *av) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word *av) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word *av) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383(C_word c,C_word *av) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word *av) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word *av) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word *av) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word *av) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word *av) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word *av) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word *av) C_noret;
C_noret_decl(f_5583)
static void C_ccall f_5583(C_word c,C_word *av) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word *av) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word *av) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word *av) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word *av) C_noret;
C_noret_decl(f_5606)
static void C_ccall f_5606(C_word c,C_word *av) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word *av) C_noret;
C_noret_decl(f_5633)
static void C_ccall f_5633(C_word c,C_word *av) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word *av) C_noret;
C_noret_decl(f_5639)
static void C_fcall f_5639(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word *av) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word *av) C_noret;
C_noret_decl(f_5683)
static void C_fcall f_5683(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5691)
static void C_fcall f_5691(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5718)
static void C_ccall f_5718(C_word c,C_word *av) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word *av) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word *av) C_noret;
C_noret_decl(f_5781)
static void C_ccall f_5781(C_word c,C_word *av) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word *av) C_noret;
C_noret_decl(f_5787)
static void C_fcall f_5787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word *av) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word *av) C_noret;
C_noret_decl(f_5809)
static void C_fcall f_5809(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5821)
static void C_ccall f_5821(C_word c,C_word *av) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word *av) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word *av) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word *av) C_noret;
C_noret_decl(f_5844)
static C_word C_fcall f_5844(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5852)
static C_word C_fcall f_5852(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word *av) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word *av) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word *av) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word *av) C_noret;
C_noret_decl(f_5886)
static void C_fcall f_5886(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word *av) C_noret;
C_noret_decl(f_5916)
static void C_ccall f_5916(C_word c,C_word *av) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word *av) C_noret;
C_noret_decl(f_5923)
static void C_ccall f_5923(C_word c,C_word *av) C_noret;
C_noret_decl(f_5939)
static void C_fcall f_5939(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5946)
static void C_ccall f_5946(C_word c,C_word *av) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word *av) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word *av) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word *av) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word *av) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word *av) C_noret;
C_noret_decl(f_5985)
static void C_ccall f_5985(C_word c,C_word *av) C_noret;
C_noret_decl(f_5988)
static void C_ccall f_5988(C_word c,C_word *av) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word *av) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word *av) C_noret;
C_noret_decl(f_6032)
static void C_ccall f_6032(C_word c,C_word *av) C_noret;
C_noret_decl(f_6036)
static void C_ccall f_6036(C_word c,C_word *av) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word *av) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word *av) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word *av) C_noret;
C_noret_decl(f_6068)
static void C_ccall f_6068(C_word c,C_word *av) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word *av) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word *av) C_noret;
C_noret_decl(f_6111)
static void C_ccall f_6111(C_word c,C_word *av) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115(C_word c,C_word *av) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word *av) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word *av) C_noret;
C_noret_decl(f_6147)
static void C_ccall f_6147(C_word c,C_word *av) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word *av) C_noret;
C_noret_decl(f_6171)
static void C_fcall f_6171(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6178)
static void C_fcall f_6178(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6223)
static void C_ccall f_6223(C_word c,C_word *av) C_noret;
C_noret_decl(f_6329)
static void C_fcall f_6329(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6337)
static void C_ccall f_6337(C_word c,C_word *av) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word *av) C_noret;
C_noret_decl(f_6352)
static void C_fcall f_6352(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6379)
static void C_fcall f_6379(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6402)
static void C_ccall f_6402(C_word c,C_word *av) C_noret;
C_noret_decl(f_6416)
static void C_fcall f_6416(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6424)
static void C_fcall f_6424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word *av) C_noret;
C_noret_decl(f_6441)
static void C_ccall f_6441(C_word c,C_word *av) C_noret;
C_noret_decl(f_6456)
static void C_fcall f_6456(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word *av) C_noret;
C_noret_decl(f_6485)
static void C_ccall f_6485(C_word c,C_word *av) C_noret;
C_noret_decl(f_6504)
static void C_ccall f_6504(C_word c,C_word *av) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word *av) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word *av) C_noret;
C_noret_decl(f_6533)
static void C_fcall f_6533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word *av) C_noret;
C_noret_decl(f_6540)
static void C_ccall f_6540(C_word c,C_word *av) C_noret;
C_noret_decl(f_6551)
static void C_fcall f_6551(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6567)
static void C_fcall f_6567(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6579)
static void C_fcall f_6579(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6593)
static void C_ccall f_6593(C_word c,C_word *av) C_noret;
C_noret_decl(f_6598)
static void C_fcall f_6598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word *av) C_noret;
C_noret_decl(f_6626)
static void C_fcall f_6626(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word *av) C_noret;
C_noret_decl(f_6656)
static void C_ccall f_6656(C_word c,C_word *av) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word *av) C_noret;
C_noret_decl(f_6709)
static void C_fcall f_6709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6713)
static void C_ccall f_6713(C_word c,C_word *av) C_noret;
C_noret_decl(f_6717)
static void C_fcall f_6717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6721)
static void C_ccall f_6721(C_word c,C_word *av) C_noret;
C_noret_decl(f_6725)
static void C_ccall f_6725(C_word c,C_word *av) C_noret;
C_noret_decl(f_6757)
static void C_fcall f_6757(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word *av) C_noret;
C_noret_decl(f_6773)
static void C_fcall f_6773(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word *av) C_noret;
C_noret_decl(f_6815)
static void C_ccall f_6815(C_word c,C_word *av) C_noret;
C_noret_decl(f_6830)
static void C_fcall f_6830(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6854)
static void C_ccall f_6854(C_word c,C_word *av) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word *av) C_noret;
C_noret_decl(f_6872)
static void C_fcall f_6872(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word *av) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959(C_word c,C_word *av) C_noret;
C_noret_decl(f_6961)
static void C_fcall f_6961(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6986)
static void C_fcall f_6986(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word *av) C_noret;
C_noret_decl(f_7037)
static void C_ccall f_7037(C_word c,C_word *av) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065(C_word c,C_word *av) C_noret;
C_noret_decl(f_7073)
static void C_ccall f_7073(C_word c,C_word *av) C_noret;
C_noret_decl(f_7103)
static void C_ccall f_7103(C_word c,C_word *av) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word *av) C_noret;
C_noret_decl(f_7138)
static void C_ccall f_7138(C_word c,C_word *av) C_noret;
C_noret_decl(f_7154)
static void C_ccall f_7154(C_word c,C_word *av) C_noret;
C_noret_decl(f_7164)
static void C_ccall f_7164(C_word c,C_word *av) C_noret;
C_noret_decl(f_7170)
static void C_ccall f_7170(C_word c,C_word *av) C_noret;
C_noret_decl(f_7171)
static void C_fcall f_7171(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7183)
static void C_ccall f_7183(C_word c,C_word *av) C_noret;
C_noret_decl(f_7196)
static void C_ccall f_7196(C_word c,C_word *av) C_noret;
C_noret_decl(f_7197)
static void C_fcall f_7197(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7209)
static void C_ccall f_7209(C_word c,C_word *av) C_noret;
C_noret_decl(f_7222)
static void C_ccall f_7222(C_word c,C_word *av) C_noret;
C_noret_decl(f_7225)
static void C_ccall f_7225(C_word c,C_word *av) C_noret;
C_noret_decl(f_7241)
static void C_ccall f_7241(C_word c,C_word *av) C_noret;
C_noret_decl(f_7245)
static void C_ccall f_7245(C_word c,C_word *av) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word *av) C_noret;
C_noret_decl(f_7251)
static void C_fcall f_7251(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7261)
static void C_ccall f_7261(C_word c,C_word *av) C_noret;
C_noret_decl(f_7274)
static void C_fcall f_7274(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word *av) C_noret;
C_noret_decl(f_7301)
static void C_fcall f_7301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7308)
static void C_ccall f_7308(C_word c,C_word *av) C_noret;
C_noret_decl(f_7312)
static void C_ccall f_7312(C_word c,C_word *av) C_noret;
C_noret_decl(f_7325)
static void C_fcall f_7325(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7350)
static void C_ccall f_7350(C_word c,C_word *av) C_noret;
C_noret_decl(f_7359)
static void C_fcall f_7359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7384)
static void C_ccall f_7384(C_word c,C_word *av) C_noret;
C_noret_decl(f_7399)
static void C_ccall f_7399(C_word c,C_word *av) C_noret;
C_noret_decl(f_7406)
static void C_ccall f_7406(C_word c,C_word *av) C_noret;
C_noret_decl(f_7412)
static void C_ccall f_7412(C_word c,C_word *av) C_noret;
C_noret_decl(f_7428)
static void C_ccall f_7428(C_word c,C_word *av) C_noret;
C_noret_decl(f_7432)
static void C_ccall f_7432(C_word c,C_word *av) C_noret;
C_noret_decl(f_7436)
static void C_ccall f_7436(C_word c,C_word *av) C_noret;
C_noret_decl(f_7449)
static void C_fcall f_7449(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7471)
static void C_ccall f_7471(C_word c,C_word *av) C_noret;
C_noret_decl(f_7473)
static void C_fcall f_7473(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7498)
static void C_ccall f_7498(C_word c,C_word *av) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word *av) C_noret;
C_noret_decl(f_7528)
static void C_fcall f_7528(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7539)
static void C_fcall f_7539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7541)
static void C_fcall f_7541(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7569)
static void C_fcall f_7569(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7606)
static void C_ccall f_7606(C_word c,C_word *av) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word *av) C_noret;
C_noret_decl(f_7644)
static void C_ccall f_7644(C_word c,C_word *av) C_noret;
C_noret_decl(f_7647)
static void C_ccall f_7647(C_word c,C_word *av) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word *av) C_noret;
C_noret_decl(f_7651)
static void C_fcall f_7651(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7665)
static void C_ccall f_7665(C_word c,C_word *av) C_noret;
C_noret_decl(f_7669)
static void C_ccall f_7669(C_word c,C_word *av) C_noret;
C_noret_decl(f_7672)
static void C_ccall f_7672(C_word c,C_word *av) C_noret;
C_noret_decl(f_7675)
static void C_ccall f_7675(C_word c,C_word *av) C_noret;
C_noret_decl(f_7678)
static void C_ccall f_7678(C_word c,C_word *av) C_noret;
C_noret_decl(f_7686)
static void C_ccall f_7686(C_word c,C_word *av) C_noret;
C_noret_decl(f_7693)
static void C_ccall f_7693(C_word c,C_word *av) C_noret;
C_noret_decl(f_7702)
static void C_ccall f_7702(C_word c,C_word *av) C_noret;
C_noret_decl(f_7705)
static void C_ccall f_7705(C_word c,C_word *av) C_noret;
C_noret_decl(f_7712)
static void C_ccall f_7712(C_word c,C_word *av) C_noret;
C_noret_decl(f_7715)
static void C_ccall f_7715(C_word c,C_word *av) C_noret;
C_noret_decl(f_7716)
static void C_fcall f_7716(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7720)
static void C_ccall f_7720(C_word c,C_word *av) C_noret;
C_noret_decl(f_7723)
static void C_ccall f_7723(C_word c,C_word *av) C_noret;
C_noret_decl(f_7735)
static void C_fcall f_7735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7745)
static void C_ccall f_7745(C_word c,C_word *av) C_noret;
C_noret_decl(f_7767)
static void C_ccall f_7767(C_word c,C_word *av) C_noret;
C_noret_decl(f_7768)
static void C_fcall f_7768(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7772)
static void C_ccall f_7772(C_word c,C_word *av) C_noret;
C_noret_decl(f_7780)
static void C_fcall f_7780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7790)
static void C_ccall f_7790(C_word c,C_word *av) C_noret;
C_noret_decl(f_7804)
static void C_ccall f_7804(C_word c,C_word *av) C_noret;
C_noret_decl(f_7810)
static void C_ccall f_7810(C_word c,C_word *av) C_noret;
C_noret_decl(f_7813)
static void C_ccall f_7813(C_word c,C_word *av) C_noret;
C_noret_decl(f_7841)
static void C_ccall f_7841(C_word c,C_word *av) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word *av) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word *av) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word *av) C_noret;
C_noret_decl(f_7858)
static void C_fcall f_7858(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7862)
static void C_ccall f_7862(C_word c,C_word *av) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word *av) C_noret;
C_noret_decl(f_7886)
static void C_ccall f_7886(C_word c,C_word *av) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word *av) C_noret;
C_noret_decl(f_7892)
static void C_ccall f_7892(C_word c,C_word *av) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word *av) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word *av) C_noret;
C_noret_decl(f_7911)
static void C_ccall f_7911(C_word c,C_word *av) C_noret;
C_noret_decl(f_7915)
static void C_ccall f_7915(C_word c,C_word *av) C_noret;
C_noret_decl(f_7921)
static void C_fcall f_7921(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7931)
static void C_ccall f_7931(C_word c,C_word *av) C_noret;
C_noret_decl(f_7946)
static void C_ccall f_7946(C_word c,C_word *av) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word *av) C_noret;
C_noret_decl(f_7952)
static void C_fcall f_7952(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7977)
static void C_ccall f_7977(C_word c,C_word *av) C_noret;
C_noret_decl(f_7989)
static void C_fcall f_7989(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7999)
static void C_ccall f_7999(C_word c,C_word *av) C_noret;
C_noret_decl(f_8016)
static void C_fcall f_8016(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8047)
static void C_fcall f_8047(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8051)
static void C_ccall f_8051(C_word c,C_word *av) C_noret;
C_noret_decl(f_8060)
static void C_ccall f_8060(C_word c,C_word *av) C_noret;
C_noret_decl(f_8063)
static void C_fcall f_8063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8075)
static void C_fcall f_8075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8091)
static void C_ccall f_8091(C_word c,C_word *av) C_noret;
C_noret_decl(f_8095)
static void C_ccall f_8095(C_word c,C_word *av) C_noret;
C_noret_decl(f_8099)
static void C_ccall f_8099(C_word c,C_word *av) C_noret;
C_noret_decl(f_8113)
static void C_ccall f_8113(C_word c,C_word *av) C_noret;
C_noret_decl(f_8146)
static void C_ccall f_8146(C_word c,C_word *av) C_noret;
C_noret_decl(f_8148)
static void C_fcall f_8148(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8161)
static void C_ccall f_8161(C_word c,C_word *av) C_noret;
C_noret_decl(f_8170)
static void C_ccall f_8170(C_word c,C_word *av) C_noret;
C_noret_decl(f_8183)
static void C_fcall f_8183(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8208)
static void C_ccall f_8208(C_word c,C_word *av) C_noret;
C_noret_decl(f_8218)
static void C_ccall f_8218(C_word c,C_word *av) C_noret;
C_noret_decl(f_8222)
static void C_ccall f_8222(C_word c,C_word *av) C_noret;
C_noret_decl(f_8228)
static void C_ccall f_8228(C_word c,C_word *av) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word *av) C_noret;
C_noret_decl(f_8236)
static void C_ccall f_8236(C_word c,C_word *av) C_noret;
C_noret_decl(f_8240)
static void C_ccall f_8240(C_word c,C_word *av) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word *av) C_noret;
C_noret_decl(f_8246)
static void C_ccall f_8246(C_word c,C_word *av) C_noret;
C_noret_decl(f_8249)
static void C_ccall f_8249(C_word c,C_word *av) C_noret;
C_noret_decl(f_8253)
static void C_ccall f_8253(C_word c,C_word *av) C_noret;
C_noret_decl(f_8257)
static void C_ccall f_8257(C_word c,C_word *av) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word *av) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word *av) C_noret;
C_noret_decl(f_8268)
static void C_ccall f_8268(C_word c,C_word *av) C_noret;
C_noret_decl(f_8271)
static void C_ccall f_8271(C_word c,C_word *av) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word *av) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word *av) C_noret;
C_noret_decl(f_8292)
static void C_ccall f_8292(C_word c,C_word *av) C_noret;
C_noret_decl(f_8298)
static void C_ccall f_8298(C_word c,C_word *av) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word *av) C_noret;
C_noret_decl(f_8307)
static void C_ccall f_8307(C_word c,C_word *av) C_noret;
C_noret_decl(f_8312)
static void C_ccall f_8312(C_word c,C_word *av) C_noret;
C_noret_decl(f_8317)
static void C_ccall f_8317(C_word c,C_word *av) C_noret;
C_noret_decl(f_8321)
static void C_ccall f_8321(C_word c,C_word *av) C_noret;
C_noret_decl(f_8324)
static void C_ccall f_8324(C_word c,C_word *av) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word *av) C_noret;
C_noret_decl(f_8330)
static void C_ccall f_8330(C_word c,C_word *av) C_noret;
C_noret_decl(f_8333)
static void C_ccall f_8333(C_word c,C_word *av) C_noret;
C_noret_decl(f_8336)
static void C_ccall f_8336(C_word c,C_word *av) C_noret;
C_noret_decl(f_8339)
static void C_ccall f_8339(C_word c,C_word *av) C_noret;
C_noret_decl(f_8342)
static void C_ccall f_8342(C_word c,C_word *av) C_noret;
C_noret_decl(f_8350)
static void C_ccall f_8350(C_word c,C_word *av) C_noret;
C_noret_decl(f_8354)
static void C_ccall f_8354(C_word c,C_word *av) C_noret;
C_noret_decl(f_8357)
static void C_fcall f_8357(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word *av) C_noret;
C_noret_decl(f_8364)
static void C_ccall f_8364(C_word c,C_word *av) C_noret;
C_noret_decl(f_8372)
static void C_ccall f_8372(C_word c,C_word *av) C_noret;
C_noret_decl(f_8376)
static void C_ccall f_8376(C_word c,C_word *av) C_noret;
C_noret_decl(f_8379)
static void C_ccall f_8379(C_word c,C_word *av) C_noret;
C_noret_decl(f_8382)
static void C_ccall f_8382(C_word c,C_word *av) C_noret;
C_noret_decl(f_8385)
static void C_ccall f_8385(C_word c,C_word *av) C_noret;
C_noret_decl(f_8387)
static void C_fcall f_8387(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8395)
static void C_ccall f_8395(C_word c,C_word *av) C_noret;
C_noret_decl(f_8399)
static void C_ccall f_8399(C_word c,C_word *av) C_noret;
C_noret_decl(f_8401)
static void C_fcall f_8401(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8414)
static void C_ccall f_8414(C_word c,C_word *av) C_noret;
C_noret_decl(f_8421)
static void C_ccall f_8421(C_word c,C_word *av) C_noret;
C_noret_decl(f_8448)
static void C_ccall f_8448(C_word c,C_word *av) C_noret;
C_noret_decl(f_8451)
static void C_fcall f_8451(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8455)
static void C_ccall f_8455(C_word c,C_word *av) C_noret;
C_noret_decl(f_8458)
static void C_ccall f_8458(C_word c,C_word *av) C_noret;
C_noret_decl(f_8499)
static void C_fcall f_8499(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8513)
static void C_ccall f_8513(C_word c,C_word *av) C_noret;
C_noret_decl(f_8531)
static void C_ccall f_8531(C_word c,C_word *av) C_noret;
C_noret_decl(f_8534)
static void C_ccall f_8534(C_word c,C_word *av) C_noret;
C_noret_decl(f_8539)
static void C_ccall f_8539(C_word c,C_word *av) C_noret;
C_noret_decl(f_8549)
static void C_ccall f_8549(C_word c,C_word *av) C_noret;
C_noret_decl(f_8553)
static void C_ccall f_8553(C_word c,C_word *av) C_noret;
C_noret_decl(f_8558)
static void C_fcall f_8558(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8566)
static void C_fcall f_8566(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8576)
static void C_ccall f_8576(C_word c,C_word *av) C_noret;
C_noret_decl(f_8589)
static void C_fcall f_8589(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8599)
static void C_ccall f_8599(C_word c,C_word *av) C_noret;
C_noret_decl(f_8617)
static void C_fcall f_8617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8639)
static void C_fcall f_8639(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8681)
static void C_ccall f_8681(C_word c,C_word *av) C_noret;
C_noret_decl(f_8684)
static void C_ccall f_8684(C_word c,C_word *av) C_noret;
C_noret_decl(f_8689)
static void C_ccall f_8689(C_word c,C_word *av) C_noret;
C_noret_decl(f_8699)
static void C_ccall f_8699(C_word c,C_word *av) C_noret;
C_noret_decl(f_8703)
static void C_ccall f_8703(C_word c,C_word *av) C_noret;
C_noret_decl(f_8708)
static void C_fcall f_8708(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8720)
static void C_fcall f_8720(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8728)
static void C_fcall f_8728(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8738)
static void C_ccall f_8738(C_word c,C_word *av) C_noret;
C_noret_decl(f_8751)
static void C_fcall f_8751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8761)
static void C_ccall f_8761(C_word c,C_word *av) C_noret;
C_noret_decl(f_8779)
static void C_fcall f_8779(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8791)
static void C_ccall f_8791(C_word c,C_word *av) C_noret;
C_noret_decl(f_8820)
static void C_fcall f_8820(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8832)
static void C_ccall f_8832(C_word c,C_word *av) C_noret;
C_noret_decl(f_8864)
static void C_ccall f_8864(C_word c,C_word *av) C_noret;
C_noret_decl(f_8867)
static void C_ccall f_8867(C_word c,C_word *av) C_noret;
C_noret_decl(f_8872)
static void C_ccall f_8872(C_word c,C_word *av) C_noret;
C_noret_decl(f_8882)
static void C_ccall f_8882(C_word c,C_word *av) C_noret;
C_noret_decl(f_8886)
static void C_ccall f_8886(C_word c,C_word *av) C_noret;
C_noret_decl(f_8891)
static void C_fcall f_8891(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8903)
static void C_fcall f_8903(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8911)
static void C_fcall f_8911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8924)
static void C_ccall f_8924(C_word c,C_word *av) C_noret;
C_noret_decl(f_8930)
static void C_ccall f_8930(C_word c,C_word *av) C_noret;
C_noret_decl(f_8943)
static void C_fcall f_8943(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8953)
static void C_ccall f_8953(C_word c,C_word *av) C_noret;
C_noret_decl(f_8966)
static void C_fcall f_8966(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9005)
static void C_fcall f_9005(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9021)
static void C_ccall f_9021(C_word c,C_word *av) C_noret;
C_noret_decl(f_9058)
static void C_fcall f_9058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9074)
static void C_ccall f_9074(C_word c,C_word *av) C_noret;
C_noret_decl(f_9114)
static void C_ccall f_9114(C_word c,C_word *av) C_noret;
C_noret_decl(f_9117)
static void C_ccall f_9117(C_word c,C_word *av) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word *av) C_noret;
C_noret_decl(f_9132)
static void C_ccall f_9132(C_word c,C_word *av) C_noret;
C_noret_decl(f_9136)
static void C_ccall f_9136(C_word c,C_word *av) C_noret;
C_noret_decl(f_9138)
static void C_ccall f_9138(C_word c,C_word *av) C_noret;
C_noret_decl(f_9146)
static void C_ccall f_9146(C_word c,C_word *av) C_noret;
C_noret_decl(f_9152)
static void C_ccall f_9152(C_word c,C_word *av) C_noret;
C_noret_decl(f_9156)
static void C_ccall f_9156(C_word c,C_word *av) C_noret;
C_noret_decl(f_9160)
static void C_ccall f_9160(C_word c,C_word *av) C_noret;
C_noret_decl(f_9181)
static void C_ccall f_9181(C_word c,C_word *av) C_noret;
C_noret_decl(f_9191)
static void C_ccall f_9191(C_word c,C_word *av) C_noret;
C_noret_decl(f_9193)
static void C_fcall f_9193(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9218)
static void C_ccall f_9218(C_word c,C_word *av) C_noret;
C_noret_decl(f_9227)
static void C_fcall f_9227(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word *av) C_noret;
C_noret_decl(f_9270)
static void C_ccall f_9270(C_word c,C_word *av) C_noret;
C_noret_decl(f_9276)
static void C_ccall f_9276(C_word c,C_word *av) C_noret;
C_noret_decl(f_9280)
static void C_ccall f_9280(C_word c,C_word *av) C_noret;
C_noret_decl(f_9281)
static void C_fcall f_9281(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9287)
static void C_ccall f_9287(C_word c,C_word *av) C_noret;
C_noret_decl(f_9293)
static void C_ccall f_9293(C_word c,C_word *av) C_noret;
C_noret_decl(f_9315)
static void C_ccall f_9315(C_word c,C_word *av) C_noret;
C_noret_decl(f_9317)
static void C_fcall f_9317(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9327)
static void C_ccall f_9327(C_word c,C_word *av) C_noret;
C_noret_decl(f_9340)
static void C_ccall f_9340(C_word c,C_word *av) C_noret;
C_noret_decl(f_9344)
static void C_ccall f_9344(C_word c,C_word *av) C_noret;
C_noret_decl(f_9347)
static void C_ccall f_9347(C_word c,C_word *av) C_noret;
C_noret_decl(f_9357)
static void C_fcall f_9357(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9395)
static void C_ccall f_9395(C_word c,C_word *av) C_noret;
C_noret_decl(f_9401)
static void C_ccall f_9401(C_word c,C_word *av) C_noret;
C_noret_decl(f_9402)
static void C_fcall f_9402(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9438)
static void C_ccall f_9438(C_word c,C_word *av) C_noret;
C_noret_decl(f_9444)
static void C_ccall f_9444(C_word c,C_word *av) C_noret;
C_noret_decl(f_9447)
static void C_fcall f_9447(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9450)
static void C_ccall f_9450(C_word c,C_word *av) C_noret;
C_noret_decl(f_9457)
static void C_ccall f_9457(C_word c,C_word *av) C_noret;
C_noret_decl(f_9461)
static void C_ccall f_9461(C_word c,C_word *av) C_noret;
C_noret_decl(f_9465)
static void C_ccall f_9465(C_word c,C_word *av) C_noret;
C_noret_decl(f_9469)
static void C_ccall f_9469(C_word c,C_word *av) C_noret;
C_noret_decl(f_9472)
static void C_ccall f_9472(C_word c,C_word *av) C_noret;
C_noret_decl(f_9478)
static void C_ccall f_9478(C_word c,C_word *av) C_noret;
C_noret_decl(f_9481)
static void C_ccall f_9481(C_word c,C_word *av) C_noret;
C_noret_decl(f_9488)
static void C_ccall f_9488(C_word c,C_word *av) C_noret;
C_noret_decl(f_9498)
static void C_ccall f_9498(C_word c,C_word *av) C_noret;
C_noret_decl(f_9505)
static void C_ccall f_9505(C_word c,C_word *av) C_noret;
C_noret_decl(f_9516)
static void C_ccall f_9516(C_word c,C_word *av) C_noret;
C_noret_decl(f_9523)
static void C_ccall f_9523(C_word c,C_word *av) C_noret;
C_noret_decl(f_9525)
static void C_fcall f_9525(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9559)
static void C_fcall f_9559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9595)
static void C_ccall f_9595(C_word c,C_word *av) C_noret;
C_noret_decl(f_9606)
static void C_ccall f_9606(C_word c,C_word *av) C_noret;
C_noret_decl(f_9620)
static void C_ccall f_9620(C_word c,C_word *av) C_noret;
C_noret_decl(f_9627)
static void C_ccall f_9627(C_word c,C_word *av) C_noret;
C_noret_decl(f_9629)
static void C_fcall f_9629(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9663)
static void C_fcall f_9663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9703)
static void C_fcall f_9703(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word *av) C_noret;
C_noret_decl(f_9726)
static void C_fcall f_9726(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9736)
static void C_ccall f_9736(C_word c,C_word *av) C_noret;
C_noret_decl(f_9757)
static void C_ccall f_9757(C_word c,C_word *av) C_noret;
C_noret_decl(f_9772)
static void C_ccall f_9772(C_word c,C_word *av) C_noret;
C_noret_decl(f_9782)
static void C_fcall f_9782(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9790)
static void C_ccall f_9790(C_word c,C_word *av) C_noret;
C_noret_decl(f_9800)
static void C_ccall f_9800(C_word c,C_word *av) C_noret;
C_noret_decl(f_9803)
static void C_fcall f_9803(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9807)
static void C_ccall f_9807(C_word c,C_word *av) C_noret;
C_noret_decl(f_9811)
static void C_fcall f_9811(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9818)
static void C_ccall f_9818(C_word c,C_word *av) C_noret;
C_noret_decl(f_9837)
static void C_ccall f_9837(C_word c,C_word *av) C_noret;
C_noret_decl(f_9852)
static void C_fcall f_9852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9878)
static void C_ccall f_9878(C_word c,C_word *av) C_noret;
C_noret_decl(f_9880)
static void C_ccall f_9880(C_word c,C_word *av) C_noret;
C_noret_decl(f_9883)
static void C_fcall f_9883(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9889)
static void C_fcall f_9889(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9930)
static void C_fcall f_9930(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9962)
static void C_ccall f_9962(C_word c,C_word *av) C_noret;
C_noret_decl(f_9988)
static void C_ccall f_9988(C_word c,C_word *av) C_noret;
C_noret_decl(C_modules_toplevel)
C_externexport void C_ccall C_modules_toplevel(C_word c,C_word *av) C_noret;

C_noret_decl(trf_10002)
static void C_ccall trf_10002(C_word c,C_word *av) C_noret;
static void C_ccall trf_10002(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10002(t0,t1);}

C_noret_decl(trf_10039)
static void C_ccall trf_10039(C_word c,C_word *av) C_noret;
static void C_ccall trf_10039(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10039(t0,t1,t2);}

C_noret_decl(trf_10119)
static void C_ccall trf_10119(C_word c,C_word *av) C_noret;
static void C_ccall trf_10119(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10119(t0,t1,t2);}

C_noret_decl(trf_10136)
static void C_ccall trf_10136(C_word c,C_word *av) C_noret;
static void C_ccall trf_10136(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10136(t0,t1);}

C_noret_decl(trf_10160)
static void C_ccall trf_10160(C_word c,C_word *av) C_noret;
static void C_ccall trf_10160(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10160(t0,t1,t2);}

C_noret_decl(trf_10220)
static void C_ccall trf_10220(C_word c,C_word *av) C_noret;
static void C_ccall trf_10220(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10220(t0,t1,t2,t3);}

C_noret_decl(trf_10232)
static void C_ccall trf_10232(C_word c,C_word *av) C_noret;
static void C_ccall trf_10232(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10232(t0,t1,t2);}

C_noret_decl(trf_10337)
static void C_ccall trf_10337(C_word c,C_word *av) C_noret;
static void C_ccall trf_10337(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_10337(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10348)
static void C_ccall trf_10348(C_word c,C_word *av) C_noret;
static void C_ccall trf_10348(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10348(t0,t1,t2);}

C_noret_decl(trf_10361)
static void C_ccall trf_10361(C_word c,C_word *av) C_noret;
static void C_ccall trf_10361(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10361(t0,t1);}

C_noret_decl(trf_10435)
static void C_ccall trf_10435(C_word c,C_word *av) C_noret;
static void C_ccall trf_10435(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10435(t0,t1,t2);}

C_noret_decl(trf_10469)
static void C_ccall trf_10469(C_word c,C_word *av) C_noret;
static void C_ccall trf_10469(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10469(t0,t1,t2);}

C_noret_decl(trf_10635)
static void C_ccall trf_10635(C_word c,C_word *av) C_noret;
static void C_ccall trf_10635(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10635(t0,t1,t2);}

C_noret_decl(trf_10689)
static void C_ccall trf_10689(C_word c,C_word *av) C_noret;
static void C_ccall trf_10689(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10689(t0,t1,t2);}

C_noret_decl(trf_10743)
static void C_ccall trf_10743(C_word c,C_word *av) C_noret;
static void C_ccall trf_10743(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10743(t0,t1,t2);}

C_noret_decl(trf_10797)
static void C_ccall trf_10797(C_word c,C_word *av) C_noret;
static void C_ccall trf_10797(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10797(t0,t1,t2);}

C_noret_decl(trf_10851)
static void C_ccall trf_10851(C_word c,C_word *av) C_noret;
static void C_ccall trf_10851(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10851(t0,t1,t2);}

C_noret_decl(trf_10905)
static void C_ccall trf_10905(C_word c,C_word *av) C_noret;
static void C_ccall trf_10905(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10905(t0,t1,t2);}

C_noret_decl(trf_10959)
static void C_ccall trf_10959(C_word c,C_word *av) C_noret;
static void C_ccall trf_10959(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10959(t0,t1,t2);}

C_noret_decl(trf_11013)
static void C_ccall trf_11013(C_word c,C_word *av) C_noret;
static void C_ccall trf_11013(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11013(t0,t1,t2);}

C_noret_decl(trf_11067)
static void C_ccall trf_11067(C_word c,C_word *av) C_noret;
static void C_ccall trf_11067(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11067(t0,t1,t2);}

C_noret_decl(trf_11121)
static void C_ccall trf_11121(C_word c,C_word *av) C_noret;
static void C_ccall trf_11121(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11121(t0,t1,t2);}

C_noret_decl(trf_11175)
static void C_ccall trf_11175(C_word c,C_word *av) C_noret;
static void C_ccall trf_11175(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11175(t0,t1,t2);}

C_noret_decl(trf_11229)
static void C_ccall trf_11229(C_word c,C_word *av) C_noret;
static void C_ccall trf_11229(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11229(t0,t1,t2);}

C_noret_decl(trf_11283)
static void C_ccall trf_11283(C_word c,C_word *av) C_noret;
static void C_ccall trf_11283(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11283(t0,t1,t2);}

C_noret_decl(trf_4483)
static void C_ccall trf_4483(C_word c,C_word *av) C_noret;
static void C_ccall trf_4483(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4483(t0,t1,t2,t3);}

C_noret_decl(trf_4489)
static void C_ccall trf_4489(C_word c,C_word *av) C_noret;
static void C_ccall trf_4489(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4489(t0,t1,t2);}

C_noret_decl(trf_5639)
static void C_ccall trf_5639(C_word c,C_word *av) C_noret;
static void C_ccall trf_5639(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5639(t0,t1,t2);}

C_noret_decl(trf_5683)
static void C_ccall trf_5683(C_word c,C_word *av) C_noret;
static void C_ccall trf_5683(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5683(t0,t1,t2,t3);}

C_noret_decl(trf_5691)
static void C_ccall trf_5691(C_word c,C_word *av) C_noret;
static void C_ccall trf_5691(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5691(t0,t1,t2);}

C_noret_decl(trf_5787)
static void C_ccall trf_5787(C_word c,C_word *av) C_noret;
static void C_ccall trf_5787(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5787(t0,t1);}

C_noret_decl(trf_5809)
static void C_ccall trf_5809(C_word c,C_word *av) C_noret;
static void C_ccall trf_5809(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5809(t0,t1,t2);}

C_noret_decl(trf_5886)
static void C_ccall trf_5886(C_word c,C_word *av) C_noret;
static void C_ccall trf_5886(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5886(t0,t1,t2);}

C_noret_decl(trf_5939)
static void C_ccall trf_5939(C_word c,C_word *av) C_noret;
static void C_ccall trf_5939(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5939(t0,t1,t2,t3);}

C_noret_decl(trf_6171)
static void C_ccall trf_6171(C_word c,C_word *av) C_noret;
static void C_ccall trf_6171(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6171(t0,t1,t2);}

C_noret_decl(trf_6178)
static void C_ccall trf_6178(C_word c,C_word *av) C_noret;
static void C_ccall trf_6178(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6178(t0,t1);}

C_noret_decl(trf_6329)
static void C_ccall trf_6329(C_word c,C_word *av) C_noret;
static void C_ccall trf_6329(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6329(t0,t1,t2,t3);}

C_noret_decl(trf_6352)
static void C_ccall trf_6352(C_word c,C_word *av) C_noret;
static void C_ccall trf_6352(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6352(t0,t1,t2);}

C_noret_decl(trf_6379)
static void C_ccall trf_6379(C_word c,C_word *av) C_noret;
static void C_ccall trf_6379(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6379(t0,t1,t2);}

C_noret_decl(trf_6416)
static void C_ccall trf_6416(C_word c,C_word *av) C_noret;
static void C_ccall trf_6416(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6416(t0,t1,t2);}

C_noret_decl(trf_6424)
static void C_ccall trf_6424(C_word c,C_word *av) C_noret;
static void C_ccall trf_6424(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6424(t0,t1);}

C_noret_decl(trf_6456)
static void C_ccall trf_6456(C_word c,C_word *av) C_noret;
static void C_ccall trf_6456(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6456(t0,t1,t2);}

C_noret_decl(trf_6533)
static void C_ccall trf_6533(C_word c,C_word *av) C_noret;
static void C_ccall trf_6533(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6533(t0,t1);}

C_noret_decl(trf_6551)
static void C_ccall trf_6551(C_word c,C_word *av) C_noret;
static void C_ccall trf_6551(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_6551(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6567)
static void C_ccall trf_6567(C_word c,C_word *av) C_noret;
static void C_ccall trf_6567(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6567(t0,t1);}

C_noret_decl(trf_6579)
static void C_ccall trf_6579(C_word c,C_word *av) C_noret;
static void C_ccall trf_6579(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6579(t0,t1,t2);}

C_noret_decl(trf_6598)
static void C_ccall trf_6598(C_word c,C_word *av) C_noret;
static void C_ccall trf_6598(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6598(t0,t1,t2);}

C_noret_decl(trf_6626)
static void C_ccall trf_6626(C_word c,C_word *av) C_noret;
static void C_ccall trf_6626(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6626(t0,t1,t2,t3);}

C_noret_decl(trf_6709)
static void C_ccall trf_6709(C_word c,C_word *av) C_noret;
static void C_ccall trf_6709(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6709(t0,t1);}

C_noret_decl(trf_6717)
static void C_ccall trf_6717(C_word c,C_word *av) C_noret;
static void C_ccall trf_6717(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6717(t0,t1);}

C_noret_decl(trf_6757)
static void C_ccall trf_6757(C_word c,C_word *av) C_noret;
static void C_ccall trf_6757(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6757(t0,t1);}

C_noret_decl(trf_6773)
static void C_ccall trf_6773(C_word c,C_word *av) C_noret;
static void C_ccall trf_6773(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6773(t0,t1,t2);}

C_noret_decl(trf_6830)
static void C_ccall trf_6830(C_word c,C_word *av) C_noret;
static void C_ccall trf_6830(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6830(t0,t1,t2);}

C_noret_decl(trf_6872)
static void C_ccall trf_6872(C_word c,C_word *av) C_noret;
static void C_ccall trf_6872(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6872(t0,t1,t2);}

C_noret_decl(trf_6961)
static void C_ccall trf_6961(C_word c,C_word *av) C_noret;
static void C_ccall trf_6961(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6961(t0,t1,t2);}

C_noret_decl(trf_6986)
static void C_ccall trf_6986(C_word c,C_word *av) C_noret;
static void C_ccall trf_6986(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6986(t0,t1);}

C_noret_decl(trf_7171)
static void C_ccall trf_7171(C_word c,C_word *av) C_noret;
static void C_ccall trf_7171(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7171(t0,t1,t2);}

C_noret_decl(trf_7197)
static void C_ccall trf_7197(C_word c,C_word *av) C_noret;
static void C_ccall trf_7197(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7197(t0,t1,t2);}

C_noret_decl(trf_7251)
static void C_ccall trf_7251(C_word c,C_word *av) C_noret;
static void C_ccall trf_7251(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7251(t0,t1,t2);}

C_noret_decl(trf_7274)
static void C_ccall trf_7274(C_word c,C_word *av) C_noret;
static void C_ccall trf_7274(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7274(t0,t1,t2);}

C_noret_decl(trf_7301)
static void C_ccall trf_7301(C_word c,C_word *av) C_noret;
static void C_ccall trf_7301(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7301(t0,t1);}

C_noret_decl(trf_7325)
static void C_ccall trf_7325(C_word c,C_word *av) C_noret;
static void C_ccall trf_7325(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7325(t0,t1,t2);}

C_noret_decl(trf_7359)
static void C_ccall trf_7359(C_word c,C_word *av) C_noret;
static void C_ccall trf_7359(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7359(t0,t1,t2);}

C_noret_decl(trf_7449)
static void C_ccall trf_7449(C_word c,C_word *av) C_noret;
static void C_ccall trf_7449(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7449(t0,t1,t2);}

C_noret_decl(trf_7473)
static void C_ccall trf_7473(C_word c,C_word *av) C_noret;
static void C_ccall trf_7473(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7473(t0,t1,t2);}

C_noret_decl(trf_7528)
static void C_ccall trf_7528(C_word c,C_word *av) C_noret;
static void C_ccall trf_7528(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7528(t0,t1,t2,t3);}

C_noret_decl(trf_7539)
static void C_ccall trf_7539(C_word c,C_word *av) C_noret;
static void C_ccall trf_7539(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7539(t0,t1);}

C_noret_decl(trf_7541)
static void C_ccall trf_7541(C_word c,C_word *av) C_noret;
static void C_ccall trf_7541(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7541(t0,t1,t2);}

C_noret_decl(trf_7569)
static void C_ccall trf_7569(C_word c,C_word *av) C_noret;
static void C_ccall trf_7569(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7569(t0,t1);}

C_noret_decl(trf_7651)
static void C_ccall trf_7651(C_word c,C_word *av) C_noret;
static void C_ccall trf_7651(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7651(t0,t1,t2);}

C_noret_decl(trf_7716)
static void C_ccall trf_7716(C_word c,C_word *av) C_noret;
static void C_ccall trf_7716(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7716(t0,t1,t2);}

C_noret_decl(trf_7735)
static void C_ccall trf_7735(C_word c,C_word *av) C_noret;
static void C_ccall trf_7735(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7735(t0,t1,t2);}

C_noret_decl(trf_7768)
static void C_ccall trf_7768(C_word c,C_word *av) C_noret;
static void C_ccall trf_7768(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7768(t0,t1,t2);}

C_noret_decl(trf_7780)
static void C_ccall trf_7780(C_word c,C_word *av) C_noret;
static void C_ccall trf_7780(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7780(t0,t1,t2);}

C_noret_decl(trf_7858)
static void C_ccall trf_7858(C_word c,C_word *av) C_noret;
static void C_ccall trf_7858(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7858(t0,t1,t2);}

C_noret_decl(trf_7921)
static void C_ccall trf_7921(C_word c,C_word *av) C_noret;
static void C_ccall trf_7921(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7921(t0,t1,t2);}

C_noret_decl(trf_7952)
static void C_ccall trf_7952(C_word c,C_word *av) C_noret;
static void C_ccall trf_7952(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7952(t0,t1,t2);}

C_noret_decl(trf_7989)
static void C_ccall trf_7989(C_word c,C_word *av) C_noret;
static void C_ccall trf_7989(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7989(t0,t1,t2);}

C_noret_decl(trf_8016)
static void C_ccall trf_8016(C_word c,C_word *av) C_noret;
static void C_ccall trf_8016(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8016(t0,t1,t2);}

C_noret_decl(trf_8047)
static void C_ccall trf_8047(C_word c,C_word *av) C_noret;
static void C_ccall trf_8047(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8047(t0,t1);}

C_noret_decl(trf_8063)
static void C_ccall trf_8063(C_word c,C_word *av) C_noret;
static void C_ccall trf_8063(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8063(t0,t1);}

C_noret_decl(trf_8075)
static void C_ccall trf_8075(C_word c,C_word *av) C_noret;
static void C_ccall trf_8075(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8075(t0,t1);}

C_noret_decl(trf_8148)
static void C_ccall trf_8148(C_word c,C_word *av) C_noret;
static void C_ccall trf_8148(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8148(t0,t1,t2);}

C_noret_decl(trf_8183)
static void C_ccall trf_8183(C_word c,C_word *av) C_noret;
static void C_ccall trf_8183(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8183(t0,t1,t2);}

C_noret_decl(trf_8357)
static void C_ccall trf_8357(C_word c,C_word *av) C_noret;
static void C_ccall trf_8357(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8357(t0,t1,t2);}

C_noret_decl(trf_8387)
static void C_ccall trf_8387(C_word c,C_word *av) C_noret;
static void C_ccall trf_8387(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_8387(t0,t1,t2,t3);}

C_noret_decl(trf_8401)
static void C_ccall trf_8401(C_word c,C_word *av) C_noret;
static void C_ccall trf_8401(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8401(t0,t1,t2);}

C_noret_decl(trf_8451)
static void C_ccall trf_8451(C_word c,C_word *av) C_noret;
static void C_ccall trf_8451(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8451(t0,t1,t2);}

C_noret_decl(trf_8499)
static void C_ccall trf_8499(C_word c,C_word *av) C_noret;
static void C_ccall trf_8499(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8499(t0,t1,t2);}

C_noret_decl(trf_8558)
static void C_ccall trf_8558(C_word c,C_word *av) C_noret;
static void C_ccall trf_8558(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_8558(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8566)
static void C_ccall trf_8566(C_word c,C_word *av) C_noret;
static void C_ccall trf_8566(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8566(t0,t1,t2);}

C_noret_decl(trf_8589)
static void C_ccall trf_8589(C_word c,C_word *av) C_noret;
static void C_ccall trf_8589(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8589(t0,t1,t2);}

C_noret_decl(trf_8617)
static void C_ccall trf_8617(C_word c,C_word *av) C_noret;
static void C_ccall trf_8617(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8617(t0,t1,t2);}

C_noret_decl(trf_8639)
static void C_ccall trf_8639(C_word c,C_word *av) C_noret;
static void C_ccall trf_8639(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8639(t0,t1,t2);}

C_noret_decl(trf_8708)
static void C_ccall trf_8708(C_word c,C_word *av) C_noret;
static void C_ccall trf_8708(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_8708(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8720)
static void C_ccall trf_8720(C_word c,C_word *av) C_noret;
static void C_ccall trf_8720(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_8720(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8728)
static void C_ccall trf_8728(C_word c,C_word *av) C_noret;
static void C_ccall trf_8728(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8728(t0,t1,t2);}

C_noret_decl(trf_8751)
static void C_ccall trf_8751(C_word c,C_word *av) C_noret;
static void C_ccall trf_8751(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8751(t0,t1,t2);}

C_noret_decl(trf_8779)
static void C_ccall trf_8779(C_word c,C_word *av) C_noret;
static void C_ccall trf_8779(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8779(t0,t1,t2);}

C_noret_decl(trf_8820)
static void C_ccall trf_8820(C_word c,C_word *av) C_noret;
static void C_ccall trf_8820(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8820(t0,t1,t2);}

C_noret_decl(trf_8891)
static void C_ccall trf_8891(C_word c,C_word *av) C_noret;
static void C_ccall trf_8891(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_8891(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8903)
static void C_ccall trf_8903(C_word c,C_word *av) C_noret;
static void C_ccall trf_8903(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_8903(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8911)
static void C_ccall trf_8911(C_word c,C_word *av) C_noret;
static void C_ccall trf_8911(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8911(t0,t1,t2);}

C_noret_decl(trf_8943)
static void C_ccall trf_8943(C_word c,C_word *av) C_noret;
static void C_ccall trf_8943(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8943(t0,t1,t2);}

C_noret_decl(trf_8966)
static void C_ccall trf_8966(C_word c,C_word *av) C_noret;
static void C_ccall trf_8966(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8966(t0,t1,t2);}

C_noret_decl(trf_9005)
static void C_ccall trf_9005(C_word c,C_word *av) C_noret;
static void C_ccall trf_9005(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9005(t0,t1,t2);}

C_noret_decl(trf_9058)
static void C_ccall trf_9058(C_word c,C_word *av) C_noret;
static void C_ccall trf_9058(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9058(t0,t1,t2);}

C_noret_decl(trf_9193)
static void C_ccall trf_9193(C_word c,C_word *av) C_noret;
static void C_ccall trf_9193(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9193(t0,t1,t2);}

C_noret_decl(trf_9227)
static void C_ccall trf_9227(C_word c,C_word *av) C_noret;
static void C_ccall trf_9227(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9227(t0,t1,t2);}

C_noret_decl(trf_9281)
static void C_ccall trf_9281(C_word c,C_word *av) C_noret;
static void C_ccall trf_9281(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9281(t0,t1,t2);}

C_noret_decl(trf_9317)
static void C_ccall trf_9317(C_word c,C_word *av) C_noret;
static void C_ccall trf_9317(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9317(t0,t1,t2);}

C_noret_decl(trf_9357)
static void C_ccall trf_9357(C_word c,C_word *av) C_noret;
static void C_ccall trf_9357(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9357(t0,t1,t2);}

C_noret_decl(trf_9402)
static void C_ccall trf_9402(C_word c,C_word *av) C_noret;
static void C_ccall trf_9402(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9402(t0,t1,t2);}

C_noret_decl(trf_9447)
static void C_ccall trf_9447(C_word c,C_word *av) C_noret;
static void C_ccall trf_9447(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9447(t0,t1);}

C_noret_decl(trf_9525)
static void C_ccall trf_9525(C_word c,C_word *av) C_noret;
static void C_ccall trf_9525(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9525(t0,t1,t2);}

C_noret_decl(trf_9559)
static void C_ccall trf_9559(C_word c,C_word *av) C_noret;
static void C_ccall trf_9559(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9559(t0,t1,t2);}

C_noret_decl(trf_9629)
static void C_ccall trf_9629(C_word c,C_word *av) C_noret;
static void C_ccall trf_9629(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9629(t0,t1,t2);}

C_noret_decl(trf_9663)
static void C_ccall trf_9663(C_word c,C_word *av) C_noret;
static void C_ccall trf_9663(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9663(t0,t1,t2);}

C_noret_decl(trf_9703)
static void C_ccall trf_9703(C_word c,C_word *av) C_noret;
static void C_ccall trf_9703(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9703(t0,t1,t2);}

C_noret_decl(trf_9726)
static void C_ccall trf_9726(C_word c,C_word *av) C_noret;
static void C_ccall trf_9726(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9726(t0,t1,t2);}

C_noret_decl(trf_9782)
static void C_ccall trf_9782(C_word c,C_word *av) C_noret;
static void C_ccall trf_9782(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9782(t0,t1,t2);}

C_noret_decl(trf_9803)
static void C_ccall trf_9803(C_word c,C_word *av) C_noret;
static void C_ccall trf_9803(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9803(t0,t1,t2);}

C_noret_decl(trf_9811)
static void C_ccall trf_9811(C_word c,C_word *av) C_noret;
static void C_ccall trf_9811(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9811(t0,t1,t2);}

C_noret_decl(trf_9852)
static void C_ccall trf_9852(C_word c,C_word *av) C_noret;
static void C_ccall trf_9852(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9852(t0,t1,t2);}

C_noret_decl(trf_9883)
static void C_ccall trf_9883(C_word c,C_word *av) C_noret;
static void C_ccall trf_9883(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9883(t0,t1,t2);}

C_noret_decl(trf_9889)
static void C_ccall trf_9889(C_word c,C_word *av) C_noret;
static void C_ccall trf_9889(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9889(t0,t1,t2);}

C_noret_decl(trf_9930)
static void C_ccall trf_9930(C_word c,C_word *av) C_noret;
static void C_ccall trf_9930(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9930(t0,t1,t2);}

/* f11852 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f11852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f11852,2,av);}
/* modules.scm:522: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[38]+1));
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[38]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k10000 in loop in ##sys#validate-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_10002,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* modules.scm:813: iface */
t4=((C_word*)((C_word*)t0)[6])[1];
f_9889(t4,t2,t3);}
else{
/* modules.scm:814: err */
t2=((C_word*)((C_word*)t0)[7])[1];
f_9883(t2,((C_word*)t0)[2],C_a_i_list(&a,3,lf[156],((C_word*)t0)[5],((C_word*)t0)[8]));}}

/* k10007 in k10000 in loop in ##sys#validate-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10009(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_10009,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10013,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* modules.scm:813: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9930(t6,t3,t5);}

/* k10011 in k10007 in k10000 in loop in ##sys#validate-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_10013,2,av);}
/* modules.scm:813: scheme#append */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* loop2 in loop in ##sys#validate-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10039(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_10039,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10053,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
/* modules.scm:817: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9930(t5,t3,t4);}
else{
t3=C_i_car(t2);
if(C_truep(C_i_symbolp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
/* modules.scm:818: loop2 */
t7=t1;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
/* modules.scm:819: err */
t4=((C_word*)((C_word*)t0)[6])[1];
f_9883(t4,t1,C_a_i_list(&a,3,lf[157],((C_word*)t0)[2],((C_word*)t0)[7]));}}}

/* k10051 in loop2 in loop in ##sys#validate-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_10053,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##sys#register-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10095(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(C_unlikely(!C_demand(C_calculate_demand(14,c,1)))){
C_save_and_reclaim((void *)f_10095,6,av);}
a=C_alloc(14);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,t3,t6);
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_a_i_putprop(&a,3,t2,lf[67],t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_10111,5,av);}
a=C_alloc(18);
t5=t3;
t6=C_i_getprop(t5,lf[67],C_SCHEME_FALSE);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10119,a[2]=t2,a[3]=((C_word)li140),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10126,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t10=t9;{
C_word *av2=av;
av2[0]=t10;
av2[1]=C_SCHEME_UNDEFINED;
f_10126(2,av2);}}
else{
/* modules.scm:828: err */
t10=t8;
f_10119(t10,t9,C_a_i_list(&a,2,lf[164],t3));}}

/* err in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10119(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_10119,3,t0,t1,t2);}{
C_word av2[5];
av2[0]=0;
av2[1]=t1;
av2[2]=*((C_word*)lf[118]+1);
av2[3]=((C_word*)t0)[2];
av2[4]=t2;
C_apply(5,av2);}}

/* k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10126(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,4)))){
C_save_and_reclaim((void *)f_10126,2,av);}
a=C_alloc(23);
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=C_u_i_cdr(((C_word*)t0)[2]);
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10136,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li142),tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10199,a[2]=t5,a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10220,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t8,a[5]=t11,a[6]=((C_word)li144),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_10220(t13,t9,((C_word*)t0)[4],t3);}

/* merr in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10136(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,0,3)))){
C_save_and_reclaim_args((void *)trf_10136,2,t0,t1);}
a=C_alloc(22);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_i_check_list_2(((C_word*)t0)[4],lf[18]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10158,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10160,a[2]=t6,a[3]=t11,a[4]=t7,a[5]=((C_word)li141),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_10160(t13,t9,((C_word*)t0)[4]);}

/* k10156 in merr in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_10158,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* modules.scm:833: err */
t3=((C_word*)t0)[3];
f_10119(t3,((C_word*)t0)[4],C_a_i_list(&a,3,lf[160],((C_word*)t0)[5],t2));}

/* map-loop2556 in merr in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_10160,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10197 in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,1)))){
C_save_and_reclaim((void *)f_10199,2,av);}
a=C_alloc(18);
t2=C_eqp(lf[150],((C_word*)t0)[2]);
t3=(C_truep(t2)?C_a_i_cons(&a,2,C_SCHEME_TRUE,((C_word*)t0)[3]):C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]));
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,lf[161],t4);
t6=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[162],t1,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* loop in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10220(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,3)))){
C_save_and_reclaim_args((void *)trf_10220,4,t0,t1,t2,t3);}
a=C_alloc(10);
if(C_truep(C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10232,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li143),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_10232(t7,t1,t3);}
else{
if(C_truep(C_i_nullp(t3))){
/* modules.scm:852: merr */
t4=((C_word*)t0)[4];
f_10136(t4,t1);}
else{
t4=C_i_car(t3);
t5=C_i_car(t4);
t6=C_u_i_cdr(t4);
t7=C_i_pairp(t5);
t8=(C_truep(t7)?C_i_car(t5):t5);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10307,a[2]=t9,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=t6,a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
t11=C_i_car(t2);
/* modules.scm:860: chicken.internal#library-id */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[23]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[23]+1);
av2[1]=t10;
av2[2]=t11;
tp(3,av2);}}}}

/* loop2 in loop in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10232(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,2)))){
C_save_and_reclaim_args((void *)trf_10232,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=C_i_car(t3);
if(C_truep(C_i_pairp(t4))){
t5=C_u_i_cdr(t3);
t6=C_i_caar(t3);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10255,a[2]=t7,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10275,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:846: scheme#cadar */
t10=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
/* modules.scm:850: merr */
t5=((C_word*)t0)[5];
f_10136(t5,t1);}}}

/* k10253 in loop2 in loop in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10255(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,5)))){
C_save_and_reclaim((void *)f_10255,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10258,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* modules.scm:847: match-functor-argument */
f_10337(t3,((C_word*)t0)[6],t2,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k10256 in k10253 in loop2 in loop in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10258(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_10258,2,av);}
a=C_alloc(10);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10269,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
/* modules.scm:848: loop2 */
t7=((C_word*)((C_word*)t0)[6])[1];
f_10232(t7,t4,t6);}

/* k10267 in k10256 in k10253 in loop2 in loop in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_10269,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10273 in loop2 in loop in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_10275,2,av);}
/* modules.scm:846: chicken.internal#library-id */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[23]+1));
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[23]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k10305 in loop in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,5)))){
C_save_and_reclaim((void *)f_10307,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10310,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:861: match-functor-argument */
f_10337(t3,((C_word*)t0)[7],t2,((C_word*)t0)[8],((C_word*)t0)[9]);}

/* k10308 in k10305 in loop in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10310(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_10310,2,av);}
a=C_alloc(10);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10321,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
t7=((C_word*)t0)[6];
t8=C_u_i_cdr(t7);
/* modules.scm:863: loop */
t9=((C_word*)((C_word*)t0)[7])[1];
f_10220(t9,t4,t6,t8);}

/* k10319 in k10308 in k10305 in loop in k10124 in ##sys#instantiate-functor in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_10321,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10337(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,3)))){
C_save_and_reclaim_args((void *)trf_10337,5,t1,t2,t3,t4,t5);}
a=C_alloc(10);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10341,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10494,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:870: ##sys#resolve-module-name */
t8=*((C_word*)lf[20]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=t3;
av2[3]=lf[4];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10341(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,3)))){
C_save_and_reclaim((void *)f_10341,2,av);}
a=C_alloc(21);
t2=t1;
t3=C_eqp(((C_word*)t0)[2],lf[150]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10348,a[2]=t2,a[3]=t5,a[4]=((C_word)li146),tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[2];
t8=C_i_check_list_2(t7,lf[33]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10388,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10469,a[2]=t11,a[3]=t6,a[4]=((C_word)li148),tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_10469(t13,t9,t7);}}

/* g2617 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10348(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_10348,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_symbolp(t2);
t4=(C_truep(t3)?t2:C_i_car(t2));
t5=t4;
t6=C_i_check_structure_2(((C_word*)t0)[2],lf[4],lf[13]);
t7=C_i_block_ref(((C_word*)t0)[2],C_fix(11));
t8=C_i_assq(t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10361,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t8)){
t10=t9;
f_10361(t10,t8);}
else{
t10=C_i_check_structure_2(((C_word*)t0)[2],lf[4],lf[14]);
t11=C_i_block_ref(((C_word*)t0)[2],C_fix(12));
t12=t9;
f_10361(t12,C_i_assq(t5,t11));}}

/* k10359 in g2617 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,1)))){
C_save_and_reclaim_args((void *)trf_10361,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10386 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10388(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_10388,2,av);}
a=C_alloc(9);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10401,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10405,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:885: scheme#symbol->string */
t4=*((C_word*)lf[96]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k10399 in k10386 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10401(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_10401,2,av);}
/* modules.scm:881: ##sys#syntax-error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[118]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[118]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[4];
av2[3]=t1;
tp(4,av2);}}

/* k10403 in k10386 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10405(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_10405,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:886: scheme#symbol->string */
t4=*((C_word*)lf[96]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10407 in k10403 in k10386 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_10409,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:887: scheme#symbol->string */
t4=*((C_word*)lf[96]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10411 in k10407 in k10403 in k10386 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10413(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,3)))){
C_save_and_reclaim((void *)f_10413,2,av);}
a=C_alloc(19);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_i_check_list_2(t7,lf[18]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10435,a[2]=t5,a[3]=t11,a[4]=t6,a[5]=((C_word)li147),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_10435(t13,t9,t7);}

/* k10425 in map-loop2638 in k10411 in k10407 in k10403 in k10386 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_10427,2,av);}
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[109]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[109]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[170];
av2[3]=t1;
tp(4,av2);}}

/* k10431 in k10411 in k10407 in k10403 in k10386 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,11)))){
C_save_and_reclaim((void *)f_10433,2,av);}{
C_word *av2;
if(c >= 12) {
  av2=av;
} else {
  av2=C_alloc(12);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[93]+1);
av2[3]=lf[165];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[166];
av2[6]=lf[167];
av2[7]=((C_word*)t0)[4];
av2[8]=lf[168];
av2[9]=((C_word*)t0)[5];
av2[10]=lf[169];
av2[11]=t1;
C_apply(12,av2);}}

/* map-loop2638 in k10411 in k10407 in k10403 in k10386 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10435(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_10435,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10460,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10427,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:888: scheme#symbol->string */
t7=*((C_word*)lf[96]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10458 in map-loop2638 in k10411 in k10407 in k10403 in k10386 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10460(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10460,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10435(t6,((C_word*)t0)[5],t5);}

/* for-each-loop2616 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_10469(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_10469,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10479,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:873: g2617 */
t5=((C_word*)t0)[3];
f_10348(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10477 in for-each-loop2616 in k10339 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10479(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_10479,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10469(t3,((C_word*)t0)[4],t2);}

/* k10492 in match-functor-argument in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10494,2,av);}
/* modules.scm:870: ##sys#find-module */
t2=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_10497,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11326,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:1023: scheme#append */
t4=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[239];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10500(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,5)))){
C_save_and_reclaim((void *)f_10500,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:1029: ##sys#register-core-module */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[238];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_END_OF_LIST;
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10503(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_10503,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10506,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:1030: ##sys#register-core-module */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[237];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_END_OF_LIST;
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_10506,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:1032: ##sys#register-module-alias */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[235];
av2[3]=lf[236];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_10509,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10512,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:1033: ##sys#register-module-alias */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[233];
av2[3]=lf[234];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_10512,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10515,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11322,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:1039: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t3;
tp(2,av2);}}

/* k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_10515,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10518,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:1041: ##sys#register-core-module */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[230];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_END_OF_LIST;
av2[5]=*((C_word*)lf[231]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10518(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_10518,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10521,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:1044: ##sys#register-core-module */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[228];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_END_OF_LIST;
av2[5]=*((C_word*)lf[229]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10521,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10524,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11318,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[203]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11271,a[2]=t4,a[3]=((C_word)li175),tmp=(C_word)a,a+=4,tmp);
t10=lf[227];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11283,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li176),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_11283(t15,t3,t10);}

/* k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10524(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10524,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10527,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11264,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[184]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11217,a[2]=t4,a[3]=((C_word)li173),tmp=(C_word)a,a+=4,tmp);
t10=lf[225];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11229,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li174),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_11229(t15,t3,t10);}

/* k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_10527,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10530,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:1053: ##sys#register-core-module */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[222];
av2[3]=lf[182];
av2[4]=lf[223];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10530(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10530,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10533,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11210,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[184]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11163,a[2]=t4,a[3]=((C_word)li171),tmp=(C_word)a,a+=4,tmp);
t10=lf[221];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11175,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li172),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_11175(t15,t3,t10);}

/* k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10533,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10536,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11156,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[184]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11109,a[2]=t4,a[3]=((C_word)li169),tmp=(C_word)a,a+=4,tmp);
t10=lf[219];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11121,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li170),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_11121(t15,t3,t10);}

/* k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10536(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_10536,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10539,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:1065: ##sys#register-core-module */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[215];
av2[3]=lf[216];
av2[4]=lf[217];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_10539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10539,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10542,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11102,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[184]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11055,a[2]=t4,a[3]=((C_word)li167),tmp=(C_word)a,a+=4,tmp);
t10=lf[214];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11067,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li168),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_11067(t15,t3,t10);}

/* k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_10542(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10542,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10545,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11048,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[211]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11001,a[2]=t4,a[3]=((C_word)li165),tmp=(C_word)a,a+=4,tmp);
t10=lf[212];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11013,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li166),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_11013(t15,t3,t10);}

/* k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in ... */
static void C_ccall f_10545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10545,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10548,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10994,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[184]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10947,a[2]=t4,a[3]=((C_word)li163),tmp=(C_word)a,a+=4,tmp);
t10=lf[208];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10959,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li164),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_10959(t15,t3,t10);}

/* k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in ... */
static void C_ccall f_10548(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10548,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10551,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10940,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[184]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10893,a[2]=t4,a[3]=((C_word)li161),tmp=(C_word)a,a+=4,tmp);
t10=lf[206];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10905,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li162),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_10905(t15,t3,t10);}

/* k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in ... */
static void C_ccall f_10551(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10551,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10554,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10886,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[203]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10839,a[2]=t4,a[3]=((C_word)li159),tmp=(C_word)a,a+=4,tmp);
t10=lf[204];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10851,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li160),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_10851(t15,t3,t10);}

/* k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in ... */
static void C_ccall f_10554(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_10554,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10557,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:1093: ##sys#register-core-module */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[200];
av2[3]=lf[182];
av2[4]=lf[201];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in ... */
static void C_ccall f_10557(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10557,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10560,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10832,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[184]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10785,a[2]=t4,a[3]=((C_word)li157),tmp=(C_word)a,a+=4,tmp);
t10=lf[199];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10797,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li158),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_10797(t15,t3,t10);}

/* k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in ... */
static void C_ccall f_10560(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_10560,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10563,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:1099: ##sys#register-core-module */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[195];
av2[3]=lf[196];
av2[4]=lf[197];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in ... */
static void C_ccall f_10563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10563,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10566,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10778,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[184]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10731,a[2]=t4,a[3]=((C_word)li155),tmp=(C_word)a,a+=4,tmp);
t10=lf[194];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10743,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li156),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_10743(t15,t3,t10);}

/* k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in ... */
static void C_ccall f_10566(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10566,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10569,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10724,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[184]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10677,a[2]=t4,a[3]=((C_word)li153),tmp=(C_word)a,a+=4,tmp);
t10=lf[192];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10689,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li154),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_10689(t15,t3,t10);}

/* k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in ... */
static void C_ccall f_10569(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10569,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10572,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10670,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[184]+1);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10623,a[2]=t4,a[3]=((C_word)li151),tmp=(C_word)a,a+=4,tmp);
t10=lf[189];
t11=C_SCHEME_UNDEFINED;
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10635,a[2]=t9,a[3]=t7,a[4]=t13,a[5]=t8,a[6]=((C_word)li152),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_10635(t15,t3,t10);}

/* k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in ... */
static void C_ccall f_10572(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_10572,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10575,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:1112: ##sys#register-core-module */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[185];
av2[3]=lf[186];
av2[4]=lf[187];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10573 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in ... */
static void C_ccall f_10575(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_10575,2,av);}
a=C_alloc(6);
t2=C_mutate((C_word*)lf[173]+1 /* (set! chicken.module#module-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10577,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10613,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.base.import.scm:26: ##sys#register-core-module */
t4=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[181];
av2[3]=lf[182];
av2[4]=lf[183];
av2[5]=*((C_word*)lf[184]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* chicken.module#module-environment in k10573 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in ... */
static void C_ccall f_10577(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,3)))){
C_save_and_reclaim((void*)f_10577,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?t2:C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10584,a[2]=t1,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:1118: find-module/import-library */
f_8357(t7,t2,lf[174]);}

/* k10582 in chicken.module#module-environment in k10573 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in ... */
static void C_ccall f_10584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_10584,2,av);}
a=C_alloc(5);
if(C_truep(C_i_not(t1))){
/* modules.scm:1120: ##sys#syntax-error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[118]+1));
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[118]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[174];
av2[3]=lf[175];
av2[4]=((C_word*)t0)[3];
tp(5,av2);}}
else{
t2=t1;
t3=C_i_check_structure_2(t2,lf[4],lf[30]);
t4=C_i_block_ref(t2,C_fix(14));
t5=C_i_car(t4);
t6=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[176],((C_word*)t0)[4],t5,C_SCHEME_TRUE);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k10611 in k10573 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in ... */
static void C_ccall f_10613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_10613,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10616,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken.syntax.import.scm:30: ##sys#register-core-module */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[177];
av2[3]=lf[178];
av2[4]=lf[179];
av2[5]=*((C_word*)lf[180]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k10614 in k10611 in k10573 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in ... */
static void C_ccall f_10616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_10616,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* g3137 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in ... */
static C_word C_fcall f_10623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop3131 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in ... */
static void C_fcall f_10635(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_10635,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g3137 */
  f_10623(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10668 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in ... */
static void C_ccall f_10670(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10670,2,av);}
/* modules.scm:1109: ##sys#register-primitive-module */
t2=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[188];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g3099 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in ... */
static C_word C_fcall f_10677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop3093 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in ... */
static void C_fcall f_10689(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_10689,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g3099 */
  f_10677(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10722 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in ... */
static void C_ccall f_10724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_10724,2,av);}
/* modules.scm:1105: ##sys#register-core-module */
t2=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[190];
av2[3]=lf[182];
av2[4]=lf[191];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* g3061 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in ... */
static C_word C_fcall f_10731(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop3055 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in ... */
static void C_fcall f_10743(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_10743,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g3061 */
  f_10731(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10776 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in ... */
static void C_ccall f_10778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10778,2,av);}
/* modules.scm:1102: ##sys#register-primitive-module */
t2=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[193];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g3023 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in ... */
static C_word C_fcall f_10785(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop3017 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in ... */
static void C_fcall f_10797(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_10797,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g3023 */
  f_10785(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10830 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in ... */
static void C_ccall f_10832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10832,2,av);}
/* modules.scm:1096: ##sys#register-primitive-module */
t2=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[198];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g2985 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in ... */
static C_word C_fcall f_10839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop2979 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in ... */
static void C_fcall f_10851(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_10851,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g2985 */
  f_10839(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10884 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in ... */
static void C_ccall f_10886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10886,2,av);}
/* modules.scm:1090: ##sys#register-primitive-module */
t2=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[202];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g2947 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in ... */
static C_word C_fcall f_10893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop2941 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in ... */
static void C_fcall f_10905(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_10905,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g2947 */
  f_10893(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10938 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in ... */
static void C_ccall f_10940(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10940,2,av);}
/* modules.scm:1087: ##sys#register-primitive-module */
t2=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[205];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g2909 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in ... */
static C_word C_fcall f_10947(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop2903 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in ... */
static void C_fcall f_10959(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_10959,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g2909 */
  f_10947(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10992 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in ... */
static void C_ccall f_10994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10994,2,av);}
/* modules.scm:1084: ##sys#register-primitive-module */
t2=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[207];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g2871 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in ... */
static C_word C_fcall f_11001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop2865 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in ... */
static void C_fcall f_11013(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_11013,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g2871 */
  f_11001(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11046 in k10540 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in ... */
static void C_ccall f_11048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_11048,2,av);}
/* modules.scm:1071: ##sys#register-core-module */
t2=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[209];
av2[3]=lf[182];
av2[4]=lf[210];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* g2833 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static C_word C_fcall f_11055(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop2827 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_fcall f_11067(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_11067,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g2833 */
  f_11055(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11100 in k10537 in k10534 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_11102(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11102,2,av);}
/* modules.scm:1068: ##sys#register-primitive-module */
t2=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[213];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g2795 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static C_word C_fcall f_11109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop2789 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_11121(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_11121,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g2795 */
  f_11109(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11154 in k10531 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_11156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11156,2,av);}
/* modules.scm:1062: ##sys#register-primitive-module */
t2=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[218];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g2757 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static C_word C_fcall f_11163(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop2751 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_11175(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_11175,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g2757 */
  f_11163(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11208 in k10528 in k10525 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_11210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11210,2,av);}
/* modules.scm:1059: ##sys#register-primitive-module */
t2=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[220];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g2719 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static C_word C_fcall f_11217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop2713 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_11229(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_11229,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g2719 */
  f_11217(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11262 in k10522 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_11264(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11264,2,av);}
/* modules.scm:1050: ##sys#register-primitive-module */
t2=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[224];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g2681 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static C_word C_fcall f_11271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)t0)[2]));}

/* map-loop2675 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_11283(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_11283,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:1035: g2681 */
  f_11271(((C_word*)t0)[2],t3)
);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11316 in k10519 in k10516 in k10513 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_11318(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_11318,2,av);}
/* modules.scm:1047: ##sys#register-primitive-module */
t2=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[226];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11320 in k10510 in k10507 in k10504 in k10501 in k10498 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_11322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_11322,2,av);}
/* modules.scm:1038: ##sys#register-core-module */
t2=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[232];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_END_OF_LIST;
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k11324 in k10495 in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_11326(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_11326,2,av);}
/* modules.scm:1021: ##sys#register-core-module */
t2=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[236];
av2[3]=lf[182];
av2[4]=t1;
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k3981 */
static void C_ccall f_3983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3983,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* k3984 in k3981 */
static void C_ccall f_3986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3986,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_internal_toplevel(2,av2);}}

/* k3987 in k3984 in k3981 */
static void C_ccall f_3989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3989,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_expand_toplevel(2,av2);}}

/* k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_3992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,5)))){
C_save_and_reclaim((void *)f_3992,2,av);}
a=C_alloc(14);
t2=C_a_i_provide(&a,1,lf[0]);
t3=C_mutate(&lf[1] /* (set! delete ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4483,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5274,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:75: chicken.base#make-parameter */
t5=*((C_word*)lf[241]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* delete in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_4483(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_4483,4,t1,t2,t3,t4);}
a=C_alloc(8);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4489,a[2]=t6,a[3]=t4,a[4]=t2,a[5]=((C_word)li0),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4489(t8,t1,t3);}

/* loop in delete in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_4489(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_4489,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4502,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* mini-srfi-1.scm:106: test */
t5=((C_word*)t0)[3];{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=t4;
((C_proc)C_fast_retrieve_proc(t5))(4,av2);}}}

/* k4500 in loop in delete in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_4502(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4502,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* mini-srfi-1.scm:107: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4489(t4,((C_word*)t0)[4],t3);}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4516,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* mini-srfi-1.scm:109: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_4489(t7,t4,t6);}}

/* k4514 in k4500 in loop in delete in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_4516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_4516,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5274,2,av);}
a=C_alloc(3);
t2=C_mutate((C_word*)lf[2]+1 /* (set! ##sys#current-module ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5278,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:76: chicken.base#make-parameter */
t4=*((C_word*)lf[241]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(113,c,11)))){
C_save_and_reclaim((void *)f_5278,2,av);}
a=C_alloc(113);
t2=C_mutate((C_word*)lf[3]+1 /* (set! ##sys#module-alias-environment ...) */,t1);
t3=C_mutate((C_word*)lf[4]+1 /* (set! module ...) */,lf[4]);
t4=C_mutate(&lf[5] /* (set! module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5293,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[7]+1 /* (set! module-undefined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5383,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[8]+1 /* (set! set-module-undefined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5392,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[10]+1 /* (set! ##sys#module-name ...) */,lf[5]);
t8=C_mutate((C_word*)lf[11]+1 /* (set! ##sys#module-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5528,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[15]+1 /* (set! ##sys#register-module-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5552,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[16]+1 /* (set! ##sys#with-module-aliases ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5570,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[20]+1 /* (set! ##sys#resolve-module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5673,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[24]+1 /* (set! ##sys#find-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5720,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_mutate((C_word*)lf[27]+1 /* (set! ##sys#switch-module ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5774,a[2]=t14,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp));
t16=C_mutate((C_word*)lf[31]+1 /* (set! ##sys#add-to-export-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5827,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[34]+1 /* (set! ##sys#toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5916,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[35]+1 /* (set! ##sys#register-meta-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5919,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[37] /* (set! check-for-redef ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5939,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[41]+1 /* (set! ##sys#register-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5960,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[46]+1 /* (set! ##sys#register-syntax-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6049,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[49]+1 /* (set! ##sys#unregister-syntax-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6130,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[50]+1 /* (set! ##sys#register-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6223,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate(&lf[51] /* (set! merge-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6533,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[56]+1 /* (set! ##sys#compiled-module-registration ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6686,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[66]+1 /* (set! ##sys#register-compiled-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7073,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[75]+1 /* (set! ##sys#register-core-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7399,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[77]+1 /* (set! ##sys#register-primitive-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7513,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate(&lf[45] /* (set! find-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7528,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[78]+1 /* (set! ##sys#finalize-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7606,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t31=C_set_block_item(lf[25] /* ##sys#module-table */,0,C_SCHEME_END_OF_LIST);
t32=C_mutate((C_word*)lf[103]+1 /* (set! ##sys#import-library-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8218,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate(&lf[111] /* (set! find-module/import-library ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8357,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[112]+1 /* (set! ##sys#decompose-import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8372,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[136]+1 /* (set! ##sys#expand-import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9276,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[138]+1 /* (set! ##sys#import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9340,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate(&lf[44] /* (set! module-rename ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9782,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[146]+1 /* (set! ##sys#alias-global-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9800,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[147]+1 /* (set! ##sys#validate-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9880,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[158]+1 /* (set! ##sys#register-functor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10095,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[159]+1 /* (set! ##sys#instantiate-functor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10111,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate(&lf[163] /* (set! match-functor-argument ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10337,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t43=lf[171];
t44=*((C_word*)lf[172]+1);
t45=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10497,a[2]=((C_word*)t0)[2],a[3]=t44,a[4]=t43,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:1020: ##sys#register-core-module */
t46=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t46;
av2[1]=t45;
av2[2]=lf[240];
av2[3]=lf[182];
av2[4]=t43;
av2[5]=*((C_word*)lf[172]+1);
((C_proc)(void*)(*((C_word*)t46+1)))(6,av2);}}

/* module-name in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5293,3,av);}
t3=C_i_check_structure_2(t2,lf[4],lf[6]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* module-undefined-list in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5383,3,av);}
t3=C_i_check_structure_2(t2,lf[4],lf[7]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(7));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* set-module-undefined-list! in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5392(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5392,4,av);}
t4=C_i_check_structure_2(t2,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t5=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(7);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* ##sys#module-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5528,3,av);}
t3=t2;
t4=C_i_check_structure_2(t3,lf[4],lf[12]);
t5=C_i_block_ref(t3,C_fix(3));
t6=t2;
t7=C_i_check_structure_2(t6,lf[4],lf[13]);
t8=C_i_block_ref(t6,C_fix(11));
t9=t2;
t10=C_i_check_structure_2(t9,lf[4],lf[14]);
t11=C_i_block_ref(t9,C_fix(12));
/* modules.scm:117: scheme#values */{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t5;
av2[3]=t8;
av2[4]=t11;
C_values(5,av2);}}

/* ##sys#register-module-alias in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_5552,4,av);}
a=C_alloc(7);
t4=C_a_i_cons(&a,2,t2,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5568,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:127: ##sys#module-alias-environment */
t7=*((C_word*)lf[3]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k5566 in ##sys#register-module-alias in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5568(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5568,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* modules.scm:126: ##sys#module-alias-environment */
t3=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5570(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(21,c,3)))){
C_save_and_reclaim((void *)f_5570,4,av);}
a=C_alloc(21);
t4=*((C_word*)lf[3]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5574,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=C_i_check_list_2(t2,lf[18]);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5633,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5639,a[2]=t8,a[3]=t13,a[4]=t9,a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_5639(t15,t11,t2);}

/* k5572 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5574(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,4)))){
C_save_and_reclaim((void *)f_5574,2,av);}
a=C_alloc(19);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_TRUE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5579,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word)li7),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5596,a[2]=((C_word*)t0)[3],a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5602,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
/* modules.scm:130: ##sys#dynamic-wind */
t9=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=((C_word*)t0)[4];
av2[2]=t6;
av2[3]=t7;
av2[4]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}

/* a5578 in k5572 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5579(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5579,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
/* modules.scm:130: ##sys#module-alias-environment890 */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=C_SCHEME_TRUE;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t3))(5,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=((C_word*)((C_word*)t0)[2])[1];
f_5583(2,av2);}}}

/* k5581 in a5578 in k5572 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5583(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_5583,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* modules.scm:130: ##sys#module-alias-environment890 */
t4=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}

/* k5585 in k5581 in a5578 in k5572 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5587(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_5587,2,av);}
a=C_alloc(4);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:130: ##sys#module-alias-environment890 */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t4))(5,av2);}}

/* k5588 in k5585 in k5581 in a5578 in k5572 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5590(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5590,2,av);}
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a5595 in k5572 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5596(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5596,2,av);}
/* modules.scm:134: thunk */
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* a5601 in k5572 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5602,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5606,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:130: ##sys#module-alias-environment890 */
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}

/* k5604 in a5601 in k5572 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5606(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_5606,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:130: ##sys#module-alias-environment890 */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t4))(5,av2);}}

/* k5607 in k5604 in a5601 in k5572 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5609(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5609,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5631 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5633(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5633,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5637,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:133: ##sys#module-alias-environment */
t4=*((C_word*)lf[3]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5635 in k5631 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5637,2,av);}
/* modules.scm:131: scheme#append */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop899 in ##sys#with-module-aliases in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_5639(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_5639,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_i_cadr(t3);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t10=C_slot(t2,C_fix(1));
t12=t1;
t13=t10;
t1=t12;
t2=t13;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##sys#resolve-module-name in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5673,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5681,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:137: chicken.internal#library-id */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[23]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[23]+1);
av2[1]=t4;
av2[2]=t2;
tp(3,av2);}}

/* k5679 in ##sys#resolve-module-name in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5681(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_5681,2,av);}
a=C_alloc(8);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li13),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5683(t5,((C_word*)t0)[4],t1,C_SCHEME_END_OF_LIST);}

/* loop in k5679 in ##sys#resolve-module-name in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_5683(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_5683,4,t0,t1,t2,t3);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5718,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* modules.scm:138: ##sys#module-alias-environment */
t5=*((C_word*)lf[3]+1);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* g943 in k5716 in loop in k5679 in ##sys#resolve-module-name in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_5691(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,4)))){
C_save_and_reclaim_args((void *)trf_5691,3,t0,t1,t2);}
a=C_alloc(3);
t3=C_i_cdr(t2);
if(C_truep(C_i_memq(t3,((C_word*)t0)[2]))){
/* modules.scm:142: chicken.base#error */
t4=*((C_word*)lf[21]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[22];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* modules.scm:143: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_5683(t5,t1,t3,t4);}}

/* k5716 in loop in k5679 in ##sys#resolve-module-name in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_5718,2,av);}
a=C_alloc(7);
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li12),tmp=(C_word)a,a+=7,tmp);
/* modules.scm:138: g943 */
t4=t3;
f_5691(t4,((C_word*)t0)[7],t2);}
else{
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[7];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##sys#find-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +0,c,4)))){
C_save_and_reclaim((void*)f_5720,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+0);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_TRUE:C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_nullp(t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:C_i_car(t7));
t10=C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:C_i_cdr(t7));
t12=C_i_assq(t2,*((C_word*)lf[25]+1));
if(C_truep(t12)){
t13=t1;{
C_word *av2=av;
av2[0]=t13;
av2[1]=C_i_cdr(t12);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
if(C_truep(t5)){
/* modules.scm:148: chicken.base#error */
t13=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t13;
av2[1]=t1;
av2[2]=t9;
av2[3]=lf[26];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t13+1)))(5,av2);}}
else{
t13=t1;{
C_word *av2=av;
av2[0]=t13;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}}}

/* ##sys#switch-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5774(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5774,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5821,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:154: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t3;
tp(2,av2);}}

/* k5779 in k5823 in k5819 in ##sys#switch-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5781(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_5781,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5809,a[2]=((C_word*)t0)[5],a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
/* modules.scm:155: g981 */
t4=t3;
f_5809(t4,t2,t1);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[5]);
t4=t2;{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
f_5784(2,av2);}}}

/* k5782 in k5779 in k5823 in k5819 in ##sys#switch-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5784(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5784,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[3];
t4=C_i_check_structure_2(t3,lf[4],lf[30]);
t5=t2;
f_5787(t5,C_i_block_ref(t3,C_fix(14)));}
else{
t3=t2;
f_5787(t3,((C_word*)((C_word*)t0)[4])[1]);}}

/* k5785 in k5782 in k5779 in k5823 in k5819 in ##sys#switch-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_5787(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_5787,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5796,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(t2);
/* modules.scm:162: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t4;
av2[2]=t5;
tp(3,av2);}}
else{
/* modules.scm:164: ##sys#current-module */
t4=*((C_word*)lf[2]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k5788 in k5785 in k5782 in k5779 in k5823 in k5819 in ##sys#switch-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5790(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5790,2,av);}
/* modules.scm:164: ##sys#current-module */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5794 in k5785 in k5782 in k5779 in k5823 in k5819 in ##sys#switch-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5796(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5796,2,av);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
/* modules.scm:163: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[28]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
tp(3,av2);}}

/* g981 in k5779 in k5823 in k5819 in ##sys#switch-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_5809(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_5809,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t4=*((C_word*)lf[9]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(14);
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k5819 in ##sys#switch-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5821(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5821,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5825,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:154: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t3;
tp(2,av2);}}

/* k5823 in k5819 in ##sys#switch-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5825(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_5825,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:155: ##sys#current-module */
t5=*((C_word*)lf[2]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* ##sys#add-to-export-list in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_5827,4,av);}
a=C_alloc(6);
t4=t2;
t5=C_i_check_structure_2(t4,lf[4],lf[12]);
t6=C_i_block_ref(t4,C_fix(3));
t7=C_eqp(t6,C_SCHEME_TRUE);
if(C_truep(t7)){
t8=t2;
t9=C_i_check_structure_2(t8,lf[4],lf[32]);
t10=C_i_block_ref(t8,C_fix(5));
t11=t10;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5843,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:170: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t12;
tp(2,av2);}}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5914,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:180: scheme#append */
t9=*((C_word*)lf[19]+1);{
C_word *av2=av;
av2[0]=t9;
av2[1]=t8;
av2[2]=t6;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}}

/* k5841 in ##sys#add-to-export-list in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5843(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,3)))){
C_save_and_reclaim((void *)f_5843,2,av);}
a=C_alloc(25);
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5852,a[2]=t4,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5844,a[2]=t2,a[3]=t5,a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[2];
t8=C_i_check_list_2(t7,lf[33]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5886,a[2]=t6,a[3]=t11,a[4]=((C_word)li20),tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_5886(t13,t9,t7);}

/* g998 in k5841 in ##sys#add-to-export-list in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static C_word C_fcall f_5844(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_overflow_check;{}
t2=C_i_assq(t1,((C_word*)t0)[2]);
if(C_truep(t2)){
return((
/* modules.scm:174: g1014 */
  f_5852(C_a_i(&a,3),((C_word*)t0)[3],t2)
));}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* g1014 in k5841 in ##sys#add-to-export-list in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static C_word C_fcall f_5852(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_overflow_check;{}
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}

/* k5864 in k5841 in ##sys#add-to-export-list in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_5866,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5880,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_i_check_structure_2(t4,lf[4],lf[14]);
t6=C_i_block_ref(t4,C_fix(12));
/* modules.scm:178: scheme#append */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[6])[1];
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k5867 in k5864 in k5841 in ##sys#add-to-export-list in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5869(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_5869,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:179: scheme#append */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5874 in k5867 in k5864 in k5841 in ##sys#add-to-export-list in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5876,2,av);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=C_i_check_structure_2(t3,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t5=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_fix(5);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k5878 in k5864 in k5841 in ##sys#add-to-export-list in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5880,2,av);}
t2=((C_word*)t0)[2];
t3=C_i_check_structure_2(t2,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t4=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_fix(12);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* for-each-loop997 in k5841 in ##sys#add-to-export-list in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_5886(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_5886,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(
/* modules.scm:172: g998 */
  f_5844(C_a_i(&a,3),((C_word*)t0)[2],t3)
);
t5=C_slot(t2,C_fix(1));
t7=t1;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5912 in ##sys#add-to-export-list in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5914,2,av);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=C_i_check_structure_2(t3,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t5=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_fix(3);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* ##sys#toplevel-definition-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5916,5,av);}
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* ##sys#register-meta-expression in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5919(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5919,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5923,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:185: ##sys#current-module */
t4=*((C_word*)lf[2]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5921 in ##sys#register-meta-expression in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_5923,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_i_check_structure_2(t1,lf[4],lf[36]);
t3=C_i_block_ref(t1,C_fix(10));
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=((C_word*)t0)[3];
t6=C_i_check_structure_2(t1,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t7=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t1;
av2[3]=C_fix(10);
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* check-for-redef in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_5939(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_5939,4,t1,t2,t3,t4);}
a=C_alloc(5);
t5=C_i_assq(t2,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5946,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
/* modules.scm:190: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[38]+1));
C_word av2[4];
av2[0]=*((C_word*)lf[38]+1);
av2[1]=t6;
av2[2]=lf[40];
av2[3]=t2;
tp(4,av2);}}
else{
t7=t6;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
f_5946(2,av2);}}}

/* k5944 in check-for-redef in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5946(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5946,2,av);}
if(C_truep(C_i_assq(((C_word*)t0)[2],((C_word*)t0)[3]))){
/* modules.scm:192: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[38]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[38]+1);
av2[1]=((C_word*)t0)[4];
av2[2]=lf[39];
av2[3]=((C_word*)t0)[2];
tp(4,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* ##sys#register-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_5960,4,av);}
a=C_alloc(5);
if(C_truep(t3)){
t4=t3;
t5=C_i_check_structure_2(t4,lf[4],lf[12]);
t6=C_i_block_ref(t4,C_fix(3));
t7=C_eqp(C_SCHEME_TRUE,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5970,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t9=t8;{
C_word *av2=av;
av2[0]=t9;
av2[1]=t7;
f_5970(2,av2);}}
else{
/* modules.scm:197: find-export */
f_7528(t8,t2,t3,C_SCHEME_TRUE);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k5968 in ##sys#register-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5970,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5973,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:198: module-undefined-list */
t4=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5971 in k5968 in ##sys#register-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_5973,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5976,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6036,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[4];
t6=C_i_check_structure_2(t5,lf[4],lf[6]);
t7=C_i_block_ref(t5,C_fix(1));
/* modules.scm:200: module-rename */
f_9782(t4,((C_word*)t0)[2],t7);}

/* k5974 in k5971 in k5968 in ##sys#register-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5976(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_5976,2,av);}
a=C_alloc(10);
t2=C_i_assq(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5982,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6032,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:202: delete */
f_4483(t4,t2,((C_word*)t0)[3],*((C_word*)lf[43]+1));}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_5982(2,av2);}}}

/* k5980 in k5974 in k5971 in k5968 in ##sys#register-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_5982,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6021,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:203: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t3;
tp(2,av2);}}

/* k5983 in k5980 in k5974 in k5971 in k5968 in ##sys#register-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5985(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_5985,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_structure_2(t3,lf[4],lf[32]);
t5=C_i_block_ref(t3,C_fix(5));
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[4];
t8=C_i_check_structure_2(t7,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t9=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=t2;
av2[2]=t7;
av2[3]=C_fix(5);
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}

/* k5986 in k5983 in k5980 in k5974 in k5971 in k5968 in ##sys#register-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_5988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5988,2,av);}
a=C_alloc(6);
if(C_truep(((C_word*)t0)[2])){
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
t4=C_i_check_structure_2(t3,lf[4],lf[42]);
t5=C_i_block_ref(t3,C_fix(4));
t6=C_a_i_cons(&a,2,t2,t5);
t7=((C_word*)t0)[5];
t8=((C_word*)t0)[4];
t9=C_i_check_structure_2(t8,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t10=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t10;
av2[1]=t7;
av2[2]=t8;
av2[3]=C_fix(4);
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6019 in k5980 in k5974 in k5971 in k5968 in ##sys#register-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_6021,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:203: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t3;
tp(2,av2);}}

/* k6023 in k6019 in k5980 in k5974 in k5971 in k5968 in ##sys#register-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6025,2,av);}
/* modules.scm:203: check-for-redef */
f_5939(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k6030 in k5974 in k5971 in k5968 in ##sys#register-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6032(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6032,2,av);}
/* modules.scm:202: set-module-undefined-list! */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6034 in k5971 in k5968 in ##sys#register-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6036(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6036,2,av);}
/* modules.scm:199: ##sys#toplevel-definition-hook */
t2=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* ##sys#register-syntax-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6049,5,av);}
a=C_alloc(6);
if(C_truep(t3)){
t5=t3;
t6=C_i_check_structure_2(t5,lf[4],lf[12]);
t7=C_i_block_ref(t5,C_fix(3));
t8=C_eqp(C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6059,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;{
C_word *av2=av;
av2[0]=t10;
av2[1]=t8;
f_6059(2,av2);}}
else{
/* modules.scm:215: find-export */
f_7528(t9,t2,t3,C_SCHEME_TRUE);}}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k6057 in ##sys#register-syntax-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6059(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_6059,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* modules.scm:216: module-undefined-list */
t4=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6060 in k6057 in ##sys#register-syntax-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_6062,2,av);}
a=C_alloc(7);
t2=((C_word*)t0)[2];
t3=C_i_check_structure_2(t2,lf[4],lf[6]);
t4=C_i_block_ref(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_assq(((C_word*)t0)[3],t1))){
/* modules.scm:219: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[38]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[38]+1);
av2[1]=t5;
av2[2]=lf[48];
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}
else{
t6=t5;{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_6068(2,av2);}}}

/* k6066 in k6060 in k6057 in ##sys#register-syntax-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_6068,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6111,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:220: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t3;
tp(2,av2);}}

/* k6069 in k6066 in k6060 in k6057 in ##sys#register-syntax-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_6071,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
t5=C_i_check_structure_2(t4,lf[4],lf[42]);
t6=C_i_block_ref(t4,C_fix(4));
t7=C_a_i_cons(&a,2,t3,t6);
t8=((C_word*)t0)[4];
t9=C_i_check_structure_2(t8,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t10=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t10;
av2[1]=t2;
av2[2]=t8;
av2[3]=C_fix(4);
av2[4]=t7;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6077(2,av2);}}}

/* k6075 in k6069 in k6066 in k6060 in k6057 in ##sys#register-syntax-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6077,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
t4=C_i_check_structure_2(t3,lf[4],lf[47]);
t5=C_i_block_ref(t3,C_fix(6));
t6=C_a_i_cons(&a,2,t2,t5);
t7=((C_word*)t0)[5];
t8=((C_word*)t0)[4];
t9=C_i_check_structure_2(t8,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t10=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t10;
av2[1]=t7;
av2[2]=t8;
av2[3]=C_fix(6);
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}

/* k6109 in k6066 in k6060 in k6057 in ##sys#register-syntax-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_6111,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:220: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t3;
tp(2,av2);}}

/* k6113 in k6109 in k6066 in k6060 in k6057 in ##sys#register-syntax-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6115,2,av);}
/* modules.scm:220: check-for-redef */
f_5939(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* ##sys#unregister-syntax-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_6130,4,av);}
a=C_alloc(7);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6141,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=t3;
t6=C_i_check_structure_2(t5,lf[4],lf[47]);
t7=C_i_block_ref(t5,C_fix(6));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6147,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
/* modules.scm:235: delete */
f_4483(t4,t2,t7,t8);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k6139 in ##sys#unregister-syntax-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6141(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6141,2,av);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=C_i_check_structure_2(t3,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t5=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_fix(6);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* a6146 in ##sys#unregister-syntax-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6147(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6147,4,av);}
t4=C_i_car(t3);
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_eqp(t2,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k6162 in g2467 in k9805 in mrename in ##sys#alias-global-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_6164,2,av);}
a=C_alloc(9);
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6171,a[2]=((C_word*)t0)[3],a[3]=((C_word)li129),tmp=(C_word)a,a+=4,tmp);
/* modules.scm:240: g1090 */
t4=t3;
f_6171(t4,((C_word*)t0)[4],t2);}
else{
if(C_truep(((C_word*)t0)[3])){
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,t1);
/* modules.scm:245: set-module-undefined-list! */
t6=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t3,t1);
/* modules.scm:245: set-module-undefined-list! */
t5=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}}

/* g1090 in k6162 in g2467 in k9805 in mrename in ##sys#alias-global-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6171(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6171,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6178,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=C_i_cdr(t2);
t5=C_i_memq(((C_word*)t0)[2],t4);
t6=t3;
f_6178(t6,C_i_not(t5));}
else{
t4=t3;
f_6178(t4,C_SCHEME_FALSE);}}

/* k6176 in g1090 in k6162 in g2467 in k9805 in mrename in ##sys#alias-global-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6178(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,1)))){
C_save_and_reclaim_args((void *)trf_6178,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_set_cdr(((C_word*)t0)[2],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##sys#register-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6223(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c<5) C_bad_min_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-5)*C_SIZEOF_PAIR +22,c,1)))){
C_save_and_reclaim((void*)f_6223,c,av);}
a=C_alloc((c-5)*C_SIZEOF_PAIR+22);
t5=C_build_rest(&a,c,5,av);
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
t6=C_i_nullp(t5);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_car(t5));
t8=C_i_nullp(t5);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t5));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:C_i_car(t9));
t12=C_i_nullp(t9);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t14=t2;
t15=C_a_i_record(&a,15,lf[4],t14,t3,t4,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t7,t11,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);
t16=C_a_i_cons(&a,2,t2,t15);
t17=C_a_i_cons(&a,2,t16,*((C_word*)lf[25]+1));
t18=C_mutate((C_word*)lf[25]+1 /* (set! ##sys#module-table ...) */,t17);
t19=t1;{
C_word *av2=av;
av2[0]=t19;
av2[1]=t15;
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}

/* warn in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6329(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_6329,4,t0,t1,t2,t3);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6337,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6341,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:266: scheme#symbol->string */
t6=*((C_word*)lf[96]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k6335 in warn in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6337(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6337,2,av);}
/* modules.scm:265: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[38]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[38]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k6339 in warn in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6341(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6341,2,av);}
/* modules.scm:266: scheme#string-append */
t2=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[94];
av2[4]=t1;
av2[5]=lf[95];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6352(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(11,0,3)))){
C_save_and_reclaim_args((void *)trf_6352,3,t0,t1,t2);}
a=C_alloc(11);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
if(C_truep(C_i_symbolp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
/* modules.scm:272: loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=C_i_cdar(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6379,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li64),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6379(t8,t1,t4);}}}

/* loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6379(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_6379,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t3=C_i_cdr(((C_word*)t0)[2]);
/* modules.scm:275: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6352(t4,t1,t3);}
else{
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6527,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* modules.scm:276: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word av2[2];
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t5;
tp(2,av2);}}}

/* k6400 in k6525 in loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6402(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6402,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* modules.scm:278: loop2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6379(t4,((C_word*)t0)[4],t3);}

/* g1148 in k6525 in loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6416(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,3)))){
C_save_and_reclaim_args((void *)trf_6416,3,t0,t1,t2);}
a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6424,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)t0)[2]);
t5=t4;
t6=C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6441,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t6)){
t8=t3;
f_6424(t8,C_a_i_cons(&a,2,t5,t6));}
else{
t8=((C_word*)t0)[2];
t9=C_u_i_car(t8);
/* modules.scm:284: module-rename */
f_9782(t7,t9,((C_word*)t0)[4]);}}

/* k6422 in g1148 in k6525 in loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_6424,2,t0,t1);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6428,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* modules.scm:285: loop2 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6379(t6,t3,t5);}

/* k6426 in k6422 in g1148 in k6525 in loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_6428,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6439 in g1148 in k6525 in loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6441(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_6441,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
f_6424(t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* g1155 in k6515 in k6525 in loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6456(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_6456,3,t0,t1,t2);}
a=C_alloc(7);
t3=C_i_cdr(t2);
if(C_truep(C_i_symbolp(t3))){
t4=C_i_car(((C_word*)t0)[2]);
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,t4,t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6474,a[2]=t1,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
/* modules.scm:289: loop2 */
t12=((C_word*)((C_word*)t0)[3])[1];
f_6379(t12,t9,t11);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(((C_word*)t0)[2]);
/* modules.scm:291: warn */
t6=((C_word*)t0)[4];
f_6329(t6,t4,lf[98],t5);}}

/* k6472 in g1155 in k6515 in k6525 in loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6474(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_6474,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6483 in g1155 in k6515 in k6525 in loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6485,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* modules.scm:292: loop2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6379(t4,((C_word*)t0)[4],t3);}

/* k6502 in k6515 in k6525 in loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6504(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6504,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* modules.scm:295: loop2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6379(t4,((C_word*)t0)[4],t3);}

/* k6515 in k6525 in loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6517,2,av);}
a=C_alloc(6);
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6456,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp);
/* modules.scm:275: g1155 */
t4=t3;
f_6456(t4,((C_word*)t0)[6],t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6504,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_car(t4);
/* modules.scm:294: warn */
t6=((C_word*)t0)[5];
f_6329(t6,t3,lf[99],t5);}}

/* k6525 in loop2 in loop in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_6527,2,av);}
a=C_alloc(7);
if(C_truep(C_i_assq(((C_word*)t0)[2],t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6402,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* modules.scm:277: warn */
t5=((C_word*)t0)[6];
f_6329(t5,t2,lf[97],t4);}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=C_i_assq(t3,((C_word*)t0)[7]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp);
/* modules.scm:275: g1148 */
t6=t5;
f_6416(t6,((C_word*)t0)[5],t4);}
else{
t5=((C_word*)t0)[3];
t6=C_u_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6517,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* modules.scm:286: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t7;
tp(2,av2);}}}}

/* merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6533(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_6533,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6537,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:298: chicken.internal#make-hash-table */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[55]+1));
C_word av2[2];
av2[0]=*((C_word*)lf[55]+1);
av2[1]=t3;
tp(2,av2);}}

/* k6535 in merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6537(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6537,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6540,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:298: scheme#reverse */
t4=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6538 in k6535 in merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,5)))){
C_save_and_reclaim((void *)f_6540,2,av);}
a=C_alloc(7);
t2=C_i_cdr(t1);
t3=C_u_i_car(t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6551,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6551(t7,((C_word*)t0)[3],t2,C_SCHEME_FALSE,t3);}

/* loop in k6538 in k6535 in merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6551(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_6551,5,t0,t1,t2,t3,t4);}
a=C_alloc(8);
if(C_truep(C_i_nullp(t2))){
t5=t4;
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_i_car(t2);
t6=C_eqp(t3,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6567,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_6567(t8,t6);}
else{
t8=t2;
t9=C_u_i_car(t8);
t10=t7;
f_6567(t10,C_i_nullp(t9));}}}

/* k6565 in loop in k6538 in k6535 in merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,0,4)))){
C_save_and_reclaim_args((void *)trf_6567,2,t0,t1);}
a=C_alloc(17);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* modules.scm:302: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6551(t4,((C_word*)t0)[4],t3,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
if(C_truep(C_i_not(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6579,a[2]=((C_word*)t0)[7],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[6];
t4=C_i_check_list_2(t3,lf[33]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6598,a[2]=t7,a[3]=t2,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_6598(t9,t5,t3);}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[7],a[6]=((C_word)li32),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_6626(t7,((C_word*)t0)[4],t3,((C_word*)t0)[6]);}}}

/* g1186 in k6565 in loop in k6538 in k6535 in merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6579(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_6579,3,t0,t1,t2);}
t3=C_i_car(t2);
/* modules.scm:305: chicken.internal#hash-table-set! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[52]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[52]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
av2[4]=C_SCHEME_TRUE;
tp(5,av2);}}

/* k6591 in k6565 in loop in k6538 in k6535 in merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6593,2,av);}
/* modules.scm:306: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6551(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[5]);}

/* for-each-loop1185 in k6565 in loop in k6538 in k6535 in merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6598,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6608,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:305: g1186 */
t5=((C_word*)t0)[3];
f_6579(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6606 in for-each-loop1185 in k6565 in loop in k6538 in k6535 in merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6608,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6598(t3,((C_word*)t0)[4],t2);}

/* lp in k6565 in loop in k6538 in k6535 in merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6626(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,4)))){
C_save_and_reclaim_args((void *)trf_6626,4,t0,t1,t2,t3);}
a=C_alloc(7);
if(C_truep(C_i_nullp(t2))){
t4=C_i_cdr(((C_word*)t0)[2]);
t5=((C_word*)t0)[2];
t6=C_u_i_car(t5);
/* modules.scm:308: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6551(t7,t1,t4,t6,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6648,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=C_i_caar(t2);
/* modules.scm:309: chicken.internal#hash-table-ref */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[53]+1));
C_word av2[4];
av2[0]=*((C_word*)lf[53]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=t5;
tp(4,av2);}}}

/* k6646 in lp in k6565 in loop in k6538 in k6535 in merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6648(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6648,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* modules.scm:310: lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6626(t4,((C_word*)t0)[4],t3,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_i_caar(((C_word*)t0)[2]);
/* modules.scm:311: chicken.internal#hash-table-set! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[52]+1));
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[52]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=t3;
av2[4]=C_SCHEME_TRUE;
tp(5,av2);}}}

/* k6654 in k6646 in lp in k6565 in loop in k6538 in k6535 in merge-se in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_6656,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
/* modules.scm:312: lp */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6626(t7,((C_word*)t0)[5],t3,t6);}

/* ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6686(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_6686,3,av);}
a=C_alloc(11);
t3=t2;
t4=C_i_check_structure_2(t3,lf[4],lf[42]);
t5=C_i_block_ref(t3,C_fix(4));
t6=t5;
t7=t2;
t8=C_i_check_structure_2(t7,lf[4],lf[6]);
t9=C_i_block_ref(t7,C_fix(1));
t10=t9;
t11=t2;
t12=C_i_check_structure_2(t11,lf[4],lf[57]);
t13=C_i_block_ref(t11,C_fix(8));
t14=t2;
t15=C_i_check_structure_2(t14,lf[4],lf[14]);
t16=C_i_block_ref(t14,C_fix(12));
t17=t16;
t18=t2;
t19=C_i_check_structure_2(t18,lf[4],lf[58]);
t20=C_i_block_ref(t18,C_fix(9));
t21=t20;
t22=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6709,a[2]=t1,a[3]=t2,a[4]=t6,a[5]=t17,a[6]=t10,a[7]=t21,tmp=(C_word)a,a+=8,tmp);
t23=C_i_pairp(t13);
t24=(C_truep(t23)?C_i_pairp(t17):C_SCHEME_FALSE);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7065,a[2]=t22,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:321: chicken.syntax#strip-syntax */
t26=*((C_word*)lf[65]+1);{
C_word *av2=av;
av2[0]=t26;
av2[1]=t25;
av2[2]=t13;
((C_proc)(void*)(*((C_word*)t26+1)))(3,av2);}}
else{
t25=t22;
f_6709(t25,C_SCHEME_END_OF_LIST);}}

/* k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,2)))){
C_save_and_reclaim_args((void *)trf_6709,2,t0,t1);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6713,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6717,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=C_i_pairp(((C_word*)t0)[7]);
t6=(C_truep(t5)?C_i_pairp(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7037,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:324: chicken.syntax#strip-syntax */
t8=*((C_word*)lf[65]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t7=t4;
f_6717(t7,C_SCHEME_END_OF_LIST);}}

/* k6711 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6713,2,av);}
/* modules.scm:320: ##sys#append */
t2=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,2)))){
C_save_and_reclaim_args((void *)trf_6717,2,t0,t1);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6721,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6725,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=C_i_getprop(((C_word*)t0)[6],lf[67],C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:C_i_pairp(((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7016,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=((C_word*)t0)[3];
t9=C_i_check_structure_2(t8,lf[4],lf[36]);
t10=C_i_block_ref(t8,C_fix(10));
/* modules.scm:327: chicken.syntax#strip-syntax */
t11=*((C_word*)lf[65]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t7;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t7=t4;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_SCHEME_END_OF_LIST;
f_6725(2,av2);}}}

/* k6719 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6721(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6721,2,av);}
/* modules.scm:320: ##sys#append */
t2=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(34,c,3)))){
C_save_and_reclaim((void *)f_6725,2,av);}
a=C_alloc(34);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_i_check_structure_2(t3,lf[4],lf[6]);
t5=C_i_block_ref(t3,C_fix(1));
t6=C_a_i_list(&a,2,lf[60],t5);
t7=t6;
t8=((C_word*)t0)[2];
t9=C_i_check_structure_2(t8,lf[4],lf[61]);
t10=C_i_block_ref(t8,C_fix(2));
t11=C_a_i_list(&a,2,lf[60],t10);
t12=t11;
t13=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t14=t13;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=((C_word*)t15)[1];
t17=((C_word*)t0)[2];
t18=C_i_check_structure_2(t17,lf[4],lf[62]);
t19=C_i_block_ref(t17,C_fix(13));
t20=C_i_check_list_2(t19,lf[18]);
t21=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t7,a[6]=t12,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6961,a[2]=t15,a[3]=t23,a[4]=t16,a[5]=((C_word)li38),tmp=(C_word)a,a+=6,tmp));
t25=((C_word*)t23)[1];
f_6961(t25,t21,t19);}

/* k6755 in k6868 in k6957 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6757(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,0,3)))){
C_save_and_reclaim_args((void *)trf_6757,2,t0,t1);}
a=C_alloc(24);
t2=C_a_i_list(&a,7,lf[66],((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t1);
t3=C_a_i_list(&a,1,t2);
/* modules.scm:320: ##sys#append */
t4=*((C_word*)lf[59]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=((C_word*)t0)[7];
av2[2]=((C_word*)t0)[8];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6759 in k6868 in k6957 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_6761,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
f_6757(t2,C_a_i_cons(&a,2,lf[63],t1));}

/* loop in k6868 in k6957 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6773(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(12,0,2)))){
C_save_and_reclaim_args((void *)trf_6773,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_caar(t2);
if(C_truep(C_i_assq(t3,((C_word*)t0)[2]))){
t4=t2;
t5=C_u_i_cdr(t4);
/* modules.scm:354: loop */
t15=t1;
t16=t5;
t1=t15;
t2=t16;
goto loop;}
else{
t4=C_i_caar(t2);
t5=t2;
t6=C_u_i_car(t5);
t7=C_u_i_car(t6);
t8=C_a_i_list(&a,2,lf[60],t7);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6815,a[2]=t9,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t11=t2;
t12=C_u_i_car(t11);
t13=C_u_i_cdr(t12);
/* modules.scm:357: chicken.syntax#strip-syntax */
t14=*((C_word*)lf[65]+1);{
C_word av2[3];
av2[0]=t14;
av2[1]=t10;
av2[2]=t13;
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}}}

/* k6803 in k6813 in loop in k6868 in k6957 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6805(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_6805,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6813 in loop in k6868 in k6957 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_6815,2,av);}
a=C_alloc(13);
t2=C_a_i_list(&a,3,lf[64],((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6805,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
/* modules.scm:358: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6773(t7,t4,t6);}

/* g1278 in k6957 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6830(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_6830,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_i_car(t2);
t4=C_i_assq(t3,((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t4))){
t5=t2;
t6=C_u_i_car(t5);
t7=C_a_i_list(&a,2,lf[60],t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6854,a[2]=t1,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=C_u_i_cdr(t4);
/* modules.scm:344: chicken.syntax#strip-syntax */
t11=*((C_word*)lf[65]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t9;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_list(&a,2,lf[60],t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k6852 in g1278 in k6957 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_6854,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[64],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6868 in k6957 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,3)))){
C_save_and_reclaim((void *)f_6870,2,av);}
a=C_alloc(22);
t2=C_a_i_cons(&a,2,lf[63],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6761,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[8]))){
t6=t4;
f_6757(t6,C_a_i_cons(&a,2,lf[63],C_SCHEME_END_OF_LIST));}
else{
t6=((C_word*)t0)[9];
t7=C_i_check_structure_2(t6,lf[4],lf[47]);
t8=C_i_block_ref(t6,C_fix(6));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6773,a[2]=((C_word*)t0)[8],a[3]=t10,a[4]=((C_word)li36),tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_6773(t12,t5,t8);}}

/* map-loop1272 in k6957 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6872(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6872,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6897,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:340: g1278 */
t5=((C_word*)t0)[4];
f_6830(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6895 in map-loop1272 in k6957 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6897(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6897,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6872(t6,((C_word*)t0)[5],t5);}

/* k6957 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_6959(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(37,c,3)))){
C_save_and_reclaim((void *)f_6959,2,av);}
a=C_alloc(37);
t2=C_a_i_cons(&a,2,lf[63],t1);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_i_check_structure_2(t4,lf[4],lf[13]);
t6=C_i_block_ref(t4,C_fix(11));
t7=C_a_i_list(&a,2,lf[60],t6);
t8=t7;
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6830,a[2]=((C_word*)t0)[3],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t14=C_i_check_list_2(((C_word*)t0)[4],lf[18]);
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6870,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t8,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[2],tmp=(C_word)a,a+=10,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6872,a[2]=t11,a[3]=t17,a[4]=t13,a[5]=t12,a[6]=((C_word)li37),tmp=(C_word)a,a+=7,tmp));
t19=((C_word*)t17)[1];
f_6872(t19,t15,((C_word*)t0)[4]);}

/* map-loop1239 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6961(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(30,0,2)))){
C_save_and_reclaim_args((void *)trf_6961,3,t0,t1,t2);}
a=C_alloc(30);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6986,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_cdr(t4);
if(C_truep(C_i_symbolp(t5))){
t6=C_u_i_car(t4);
t7=C_u_i_cdr(t4);
t8=C_a_i_cons(&a,2,t6,t7);
t9=t3;
f_6986(t9,C_a_i_list(&a,2,lf[60],t8));}
else{
t6=C_u_i_car(t4);
t7=C_a_i_list(&a,2,lf[60],t6);
t8=C_a_i_list(&a,2,lf[60],C_SCHEME_END_OF_LIST);
t9=C_u_i_cdr(t4);
t10=t3;
f_6986(t10,C_a_i_list(&a,4,lf[63],t7,t8,t9));}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6984 in map-loop1239 in k6723 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_6986(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_6986,2,t0,t1);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6961(t6,((C_word*)t0)[5],t5);}

/* k7014 in k6715 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7016,2,av);}
/* modules.scm:327: ##sys#fast-reverse */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[68]+1));
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[68]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k7035 in k6707 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_7037,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,lf[69],t1);
t3=((C_word*)t0)[2];
f_6717(t3,C_a_i_list(&a,1,t2));}

/* k7063 in ##sys#compiled-module-registration in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,1)))){
C_save_and_reclaim((void *)f_7065,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,lf[69],t1);
t3=C_a_i_list(&a,2,lf[60],t2);
t4=C_a_i_list(&a,2,lf[70],t3);
t5=((C_word*)t0)[2];
f_6709(t5,C_a_i_list(&a,1,t4));}

/* ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word *a;
if(c<7) C_bad_min_argc_2(c,7,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-7)*C_SIZEOF_PAIR +21,c,3)))){
C_save_and_reclaim((void*)f_7073,c,av);}
a=C_alloc((c-7)*C_SIZEOF_PAIR+21);
t7=C_build_rest(&a,c,7,av);
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
t8=C_i_nullp(t7);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_car(t7));
t10=t9;
t11=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t12=t11;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t13)[1];
t15=C_i_check_list_2(t6,lf[18]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7138,a[2]=t10,a[3]=t2,a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7359,a[2]=t13,a[3]=t18,a[4]=t14,a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_7359(t20,t16,t6);}

/* k7101 in map-loop1346 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7103,2,av);}
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=C_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* modules.scm:370: ##sys#error */
t4=*((C_word*)lf[72]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[73];
av2[3]=lf[74];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}
else{
/* modules.scm:370: ##sys#error */
t3=*((C_word*)lf[72]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[73];
av2[3]=lf[74];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k7126 in map-loop1346 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7128(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_7128,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list3(&a,3,((C_word*)t0)[3],C_SCHEME_FALSE,t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7138(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,3)))){
C_save_and_reclaim((void *)f_7138,2,av);}
a=C_alloc(21);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(((C_word*)t0)[2],lf[18]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7164,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7325,a[2]=t5,a[3]=t10,a[4]=t6,a[5]=((C_word)li44),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_7325(t12,t8,((C_word*)t0)[2]);}

/* k7152 in map-loop1374 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_7154,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list3(&a,3,((C_word*)t0)[3],C_SCHEME_FALSE,t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(31,c,2)))){
C_save_and_reclaim((void *)f_7164,2,av);}
a=C_alloc(31);
t2=t1;
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[5];
t7=C_a_i_record(&a,15,lf[4],t3,t4,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t5,((C_word*)t0)[6],t6,C_SCHEME_FALSE);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7170,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t10=C_i_nullp(((C_word*)t0)[6]);
t11=C_i_not(t10);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7301,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t11)){
t13=t12;
f_7301(t13,t11);}
else{
t13=C_i_nullp(t2);
t14=t12;
f_7301(t14,C_i_not(t13));}}

/* k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7170(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
C_save_and_reclaim((void *)f_7170,2,av);}
a=C_alloc(20);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7171,a[2]=t2,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t4=C_i_check_list_2(((C_word*)t0)[2],lf[33]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7196,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7274,a[2]=t7,a[3]=t3,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7274(t9,t5,((C_word*)t0)[2]);}

/* g1407 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7171(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_7171,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_i_cdr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7183,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cadr(t2);
if(C_truep(t6)){
/* modules.scm:393: merge-se */
f_6533(t5,C_a_i_list(&a,2,t6,((C_word*)t0)[2]));}
else{
/* modules.scm:393: merge-se */
f_6533(t5,C_a_i_list(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}}

/* k7181 in g1407 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7183,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_i_set_car(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7194 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_7196,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7197,a[2]=((C_word*)t0)[2],a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(((C_word*)t0)[3],lf[33]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7222,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7251,a[2]=t6,a[3]=t2,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7251(t8,t4,((C_word*)t0)[3]);}

/* g1417 in k7194 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7197(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_7197,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_i_cdr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7209,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cadr(t2);
if(C_truep(t6)){
/* modules.scm:397: merge-se */
f_6533(t5,C_a_i_list(&a,2,t6,((C_word*)t0)[2]));}
else{
/* modules.scm:397: merge-se */
f_6533(t5,C_a_i_list(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}}

/* k7207 in g1417 in k7194 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7209,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_i_set_car(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7220 in k7194 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,2)))){
C_save_and_reclaim((void *)f_7222,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7241,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7249,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:401: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t4;
tp(2,av2);}}

/* k7223 in k7220 in k7194 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7225(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_7225,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,*((C_word*)lf[25]+1));
t4=C_mutate((C_word*)lf[25]+1 /* (set! ##sys#module-table ...) */,t3);
t5=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k7239 in k7220 in k7194 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7241(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_7241,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7245,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:402: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t3;
tp(2,av2);}}

/* k7243 in k7239 in k7220 in k7194 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_7245,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_i_check_structure_2(((C_word*)t0)[3],lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t4=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(14);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k7247 in k7220 in k7194 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7249(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_7249,2,av);}
a=C_alloc(9);
/* modules.scm:401: merge-se */
f_6533(((C_word*)t0)[2],C_a_i_list(&a,3,t1,((C_word*)t0)[3],((C_word*)t0)[4]));}

/* for-each-loop1416 in k7194 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7251(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7251,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7261,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:395: g1417 */
t5=((C_word*)t0)[3];
f_7197(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7259 in for-each-loop1416 in k7194 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7261(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7261,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7251(t3,((C_word*)t0)[4],t2);}

/* for-each-loop1406 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7274(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7274,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7284,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:391: g1407 */
t5=((C_word*)t0)[3];
f_7171(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7282 in for-each-loop1406 in k7168 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7284,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7274(t3,((C_word*)t0)[4],t2);}

/* k7299 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_7301,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* modules.scm:387: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word av2[2];
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t2;
tp(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_END_OF_LIST;
f_7170(2,av2);}}}

/* k7306 in k7299 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7308(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_7308,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7312,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:388: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t3;
tp(2,av2);}}

/* k7310 in k7306 in k7299 in k7162 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7312(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,2)))){
C_save_and_reclaim((void *)f_7312,2,av);}
a=C_alloc(18);
/* modules.scm:386: merge-se */
f_6533(((C_word*)t0)[2],C_a_i_list(&a,6,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]));}

/* map-loop1374 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,3)))){
C_save_and_reclaim_args((void *)trf_7325,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7350,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_car(t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7154,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=C_u_i_cdr(t4);
t10=C_u_i_car(t4);
/* modules.scm:381: ##sys#ensure-transformer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[71]+1));
C_word av2[4];
av2[0]=*((C_word*)lf[71]+1);
av2[1]=t8;
av2[2]=t9;
av2[3]=t10;
tp(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7348 in map-loop1374 in k7136 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7350,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7325(t6,((C_word*)t0)[5],t5);}

/* map-loop1346 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,3)))){
C_save_and_reclaim_args((void *)trf_7359,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7384,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
if(C_truep(C_i_symbolp(t4))){
t6=t5;
t7=t4;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7103,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:367: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word av2[2];
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t8;
tp(2,av2);}}
else{
t6=C_i_car(t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7128,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=C_u_i_cdr(t4);
t10=C_u_i_car(t4);
/* modules.scm:377: ##sys#ensure-transformer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[71]+1));
C_word av2[4];
av2[0]=*((C_word*)lf[71]+1);
av2[1]=t8;
av2[2]=t9;
av2[3]=t10;
tp(4,av2);}}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7382 in map-loop1346 in ##sys#register-compiled-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7384,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7359(t6,((C_word*)t0)[5],t5);}

/* ##sys#register-core-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c<5) C_bad_min_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-5)*C_SIZEOF_PAIR +7,c,2)))){
C_save_and_reclaim((void*)f_7399,c,av);}
a=C_alloc((c-5)*C_SIZEOF_PAIR+7);
t5=C_build_rest(&a,c,5,av);
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t6=C_i_nullp(t5);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_car(t5));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7406,a[2]=t2,a[3]=t8,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* modules.scm:407: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t9;
tp(2,av2);}}

/* k7404 in ##sys#register-core-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,3)))){
C_save_and_reclaim((void *)f_7406,2,av);}
a=C_alloc(25);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7449,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t8=C_i_check_list_2(((C_word*)t0)[3],lf[18]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7473,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_7473(t13,t9,((C_word*)t0)[3]);}

/* k7410 in k7469 in k7404 in ##sys#register-core-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7412(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_7412,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,*((C_word*)lf[25]+1));
t4=C_mutate((C_word*)lf[25]+1 /* (set! ##sys#module-table ...) */,t3);
t5=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k7426 in k7469 in k7404 in ##sys#register-core-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_7428,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7432,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:425: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t3;
tp(2,av2);}}

/* k7430 in k7426 in k7469 in k7404 in ##sys#register-core-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7432(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_7432,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_i_check_structure_2(((C_word*)t0)[3],lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t4=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(14);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k7434 in k7469 in k7404 in ##sys#register-core-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7436(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_7436,2,av);}
a=C_alloc(9);
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[4],lf[13]);
t3=C_i_block_ref(((C_word*)t0)[2],C_fix(11));
t4=C_i_check_structure_2(((C_word*)t0)[2],lf[4],lf[14]);
t5=C_i_block_ref(((C_word*)t0)[2],C_fix(12));
/* modules.scm:422: merge-se */
f_6533(((C_word*)t0)[3],C_a_i_list(&a,3,t1,t3,t5));}

/* g1475 in k7404 in ##sys#register-core-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7449(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_7449,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=C_i_assq(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* modules.scm:414: ##sys#error */
t4=*((C_word*)lf[72]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[76];
av2[3]=t2;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7469 in k7404 in ##sys#register-core-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7471(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,2)))){
C_save_and_reclaim((void *)f_7471,2,av);}
a=C_alloc(29);
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=C_a_i_record(&a,15,lf[4],t2,t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t4,t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7412,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7428,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7436,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:422: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t9;
tp(2,av2);}}

/* map-loop1469 in k7404 in ##sys#register-core-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7473(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7473,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7498,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:411: g1475 */
t5=((C_word*)t0)[4];
f_7449(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7496 in map-loop1469 in k7404 in ##sys#register-core-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7498(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7498,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7473(t6,((C_word*)t0)[5],t5);}

/* ##sys#register-primitive-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7513(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +0,c,5)))){
C_save_and_reclaim((void*)f_7513,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+0);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* modules.scm:431: ##sys#register-core-module */
t5=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t2;
av2[4]=t3;
av2[5]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
t5=C_i_car(t4);
/* modules.scm:431: ##sys#register-core-module */
t6=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
av2[3]=t2;
av2[4]=t3;
av2[5]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}}

/* find-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7528(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7528,4,t1,t2,t3,t4);}
a=C_alloc(5);
t5=t3;
t6=C_i_check_structure_2(t5,lf[4],lf[12]);
t7=C_i_block_ref(t5,C_fix(3));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7539,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=C_eqp(C_SCHEME_TRUE,t7);
if(C_truep(t9)){
t10=t3;
t11=C_i_check_structure_2(t10,lf[4],lf[32]);
t12=t8;
f_7539(t12,C_i_block_ref(t10,C_fix(5)));}
else{
t10=t8;
f_7539(t10,t7);}}

/* k7537 in find-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_7539,2,t0,t1);}
a=C_alloc(8);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7541,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7541(t5,((C_word*)t0)[4],t1);}

/* loop in k7537 in find-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7541(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7541,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t2;
t6=C_u_i_car(t5);
if(C_truep(C_i_pairp(t6))){
t7=C_i_caar(t2);
t8=C_eqp(((C_word*)t0)[2],t7);
if(C_truep(t8)){
t9=t1;{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7569,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t10=t2;
t11=C_u_i_car(t10);
t12=C_u_i_cdr(t11);
t13=t9;
f_7569(t13,C_i_memq(((C_word*)t0)[2],t12));}
else{
t10=t9;
f_7569(t10,C_SCHEME_FALSE);}}}
else{
t7=t2;
t8=C_u_i_cdr(t7);
/* modules.scm:442: loop */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}}}

/* k7567 in loop in k7537 in find-export in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7569(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_7569,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* modules.scm:441: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_7541(t4,((C_word*)t0)[2],t3);}}

/* ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7606(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_7606,3,av);}
a=C_alloc(24);
t3=t2;
t4=C_i_check_structure_2(t3,lf[4],lf[12]);
t5=C_i_block_ref(t3,C_fix(3));
t6=t5;
t7=t2;
t8=C_i_check_structure_2(t7,lf[4],lf[6]);
t9=C_i_block_ref(t7,C_fix(1));
t10=t9;
t11=t2;
t12=C_i_check_structure_2(t11,lf[4],lf[42]);
t13=C_i_block_ref(t11,C_fix(4));
t14=t13;
t15=t2;
t16=C_i_check_structure_2(t15,lf[4],lf[32]);
t17=C_i_block_ref(t15,C_fix(5));
t18=t17;
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t22=t21;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=((C_word*)t23)[1];
t25=t2;
t26=C_i_check_structure_2(t25,lf[4],lf[47]);
t27=C_i_block_ref(t25,C_fix(6));
t28=C_i_check_list_2(t27,lf[18]);
t29=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7644,a[2]=t18,a[3]=t20,a[4]=t1,a[5]=t2,a[6]=t10,a[7]=t6,a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8183,a[2]=t23,a[3]=t31,a[4]=t24,a[5]=((C_word)li69),tmp=(C_word)a,a+=6,tmp));
t33=((C_word*)t31)[1];
f_8183(t33,t29,t27);}

/* k7633 in map-loop1546 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7635(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7635,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_i_assq(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7644(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_7644,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[7]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
t6=C_i_check_structure_2(t5,lf[4],lf[14]);
t7=C_i_block_ref(t5,C_fix(12));
/* modules.scm:457: merge-se */
f_6533(t3,C_a_i_list(&a,2,t7,t2));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8146,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:458: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t5;
tp(2,av2);}}}

/* k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7647(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,3)))){
C_save_and_reclaim((void *)f_7647,2,av);}
a=C_alloc(19);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[8]);
t5=(C_truep(t4)?((C_word*)t0)[2]:((C_word*)t0)[8]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8016,a[2]=t2,a[3]=t7,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word)li67),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_8016(t9,t3,t5);}

/* k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7650(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_7650,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7804,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* modules.scm:523: module-undefined-list */
t5=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7651(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7651,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_cdr(t2);
t4=t3;
t5=t2;
t6=C_u_i_car(t5);
if(C_truep(C_i_memq(t6,((C_word*)t0)[2]))){
t7=C_SCHEME_UNDEFINED;
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7665,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:497: chicken.base#open-output-string */
t8=*((C_word*)lf[91]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7665,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7669,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:499: display */
t5=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[90];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7669(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7669,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:500: display */
t3=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7672(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7672,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#write-char/port */
t3=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(39);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_7675,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7767,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:503: display */
t4=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[89];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_7678(2,av2);}}}

/* k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7678(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_7678,2,av);}
a=C_alloc(9);
t2=C_i_getprop(((C_word*)t0)[2],lf[79],C_SCHEME_FALSE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=C_i_length(t3);
t6=C_eqp(C_fix(1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7702,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:511: display */
t8=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[84];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7715,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:515: display */
t8=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[87];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11852,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:522: chicken.base#get-output-string */
t6=*((C_word*)lf[80]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k7684 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7686(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7686,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7693,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:522: chicken.base#get-output-string */
t3=*((C_word*)lf[80]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7691 in k7684 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7693,2,av);}
/* modules.scm:522: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[38]+1));
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[38]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k7700 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_7702,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7712,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:512: scheme#cadar */
t4=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7703 in k7700 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7705,2,av);}
/* modules.scm:513: display */
t2=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[82];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7710 in k7700 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7712(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7712,2,av);}
/* modules.scm:512: display */
t2=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7713 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_7715,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7716,a[2]=((C_word*)t0)[2],a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7735,a[2]=t4,a[3]=t2,a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7735(t6,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* g1648 in k7713 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7716(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_7716,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7720,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:518: display */
t4=*((C_word*)lf[81]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[86];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7718 in g1648 in k7713 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_7720,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* modules.scm:519: display */
t4=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7721 in k7718 in g1648 in k7713 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7723(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7723,2,av);}
/* ##sys#write-char/port */
t2=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop1647 in k7713 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7735,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7745,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:516: g1648 */
t5=((C_word*)t0)[3];
f_7716(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7743 in for-each-loop1647 in k7713 in k7676 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7745,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7735(t3,((C_word*)t0)[4],t2);}

/* k7765 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_7767,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7768,a[2]=((C_word*)t0)[2],a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7780,a[2]=t4,a[3]=t2,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7780(t6,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* g1617 in k7765 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7768(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_7768,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7772,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:506: display */
t4=*((C_word*)lf[81]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[88];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7770 in g1617 in k7765 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7772(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7772,2,av);}
/* modules.scm:507: display */
t2=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop1616 in k7765 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7780,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7790,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:504: g1617 */
t5=((C_word*)t0)[3];
f_7768(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7788 in for-each-loop1616 in k7765 in k7673 in k7670 in k7667 in k7663 in g1601 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7790(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7790,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7780(t3,((C_word*)t0)[4],t2);}

/* k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7804(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,3)))){
C_save_and_reclaim((void *)f_7804,2,av);}
a=C_alloc(16);
t2=C_i_check_list_2(t1,lf[33]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7989,a[2]=t5,a[3]=((C_word*)t0)[9],a[4]=((C_word)li66),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7989(t7,t3,t1);}

/* k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7810(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_7810,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
/* modules.scm:525: ##sys#error */
t3=*((C_word*)lf[72]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[100];
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_7813(2,av2);}}}

/* k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7813(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,4)))){
C_save_and_reclaim((void *)f_7813,2,av);}
a=C_alloc(27);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t7=((C_word*)t0)[4];
t8=C_i_check_structure_2(t7,lf[4],lf[12]);
t9=C_i_block_ref(t7,C_fix(3));
t10=C_i_check_structure_2(t7,lf[4],lf[6]);
t11=C_i_block_ref(t7,C_fix(1));
t12=t11;
t13=C_i_check_structure_2(t7,lf[4],lf[42]);
t14=C_i_block_ref(t7,C_fix(4));
t15=t14;
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6329,a[2]=t12,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
t17=C_eqp(C_SCHEME_TRUE,t9);
if(C_truep(t17)){
t18=t6;{
C_word *av2=av;
av2[0]=t18;
av2[1]=C_SCHEME_END_OF_LIST;
f_7848(2,av2);}}
else{
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6352,a[2]=t19,a[3]=t16,a[4]=t15,a[5]=t12,a[6]=((C_word)li65),tmp=(C_word)a,a+=7,tmp));
t21=((C_word*)t19)[1];
f_6352(t21,t6,t9);}}

/* k7839 in map-loop1681 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7841,2,av);}
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_u_i_car(((C_word*)t0)[4]);
/* modules.scm:530: ##sys#error */
t4=*((C_word*)lf[72]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[92];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_7848,2,av);}
a=C_alloc(15);
t2=C_i_check_list_2(t1,lf[18]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7952,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7952(t7,t3,t1);}

/* k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_7854,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7946,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* modules.scm:533: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t4;
tp(2,av2);}}

/* k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_7857,2,av);}
a=C_alloc(18);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7858,a[2]=t2,a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
t4=C_i_check_list_2(((C_word*)t0)[2],lf[33]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7921,a[2]=t7,a[3]=t3,a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7921(t9,t5,((C_word*)t0)[2]);}

/* g1717 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7858(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_7858,3,t0,t1,t2);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7862,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(t2);
/* modules.scm:538: merge-se */
f_6533(t3,C_a_i_list(&a,2,t4,((C_word*)t0)[2]));}

/* k7860 in g1717 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7862(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7862,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_set_car(t3,t1);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k7878 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_7880,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=C_i_check_structure_2(t3,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t5=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_fix(11);
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k7884 in k7878 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_7886,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=C_i_check_structure_2(t3,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t5=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_fix(12);
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k7887 in k7884 in k7878 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7889(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_7889,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7915,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_i_check_structure_2(t4,lf[4],lf[62]);
t6=C_i_block_ref(t4,C_fix(13));
/* modules.scm:553: merge-se */
f_6533(t3,C_a_i_list(&a,2,t6,((C_word*)t0)[6]));}

/* k7890 in k7887 in k7884 in k7878 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_7892,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7911,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:556: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t3;
tp(2,av2);}}

/* k7901 in k7890 in k7887 in k7884 in k7878 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7903(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_7903,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7907,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:557: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t3;
tp(2,av2);}}

/* k7905 in k7901 in k7890 in k7887 in k7884 in k7878 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_7907(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_7907,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=C_i_check_structure_2(t4,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t6=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=C_fix(14);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7909 in k7890 in k7887 in k7884 in k7878 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_7911,2,av);}
a=C_alloc(9);
/* modules.scm:556: merge-se */
f_6533(((C_word*)t0)[2],C_a_i_list(&a,3,t1,((C_word*)t0)[3],((C_word*)t0)[4]));}

/* k7913 in k7887 in k7884 in k7878 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7915(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7915,2,av);}
t2=((C_word*)t0)[2];
t3=C_i_check_structure_2(t2,lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t4=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_fix(13);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* for-each-loop1716 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7921(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7921,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7931,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:536: g1717 */
t5=((C_word*)t0)[3];
f_7858(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7929 in for-each-loop1716 in k7855 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7931(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7931,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7921(t3,((C_word*)t0)[4],t2);}

/* k7944 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7946(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_7946,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7950,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:534: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t3;
tp(2,av2);}}

/* k7948 in k7944 in k7852 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7950(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,2)))){
C_save_and_reclaim((void *)f_7950,2,av);}
a=C_alloc(18);
/* modules.scm:532: merge-se */
f_6533(((C_word*)t0)[2],C_a_i_list(&a,6,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]));}

/* map-loop1681 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7952(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,2)))){
C_save_and_reclaim_args((void *)trf_7952,3,t0,t1,t2);}
a=C_alloc(11);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7977,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=C_i_cdr(t6);
if(C_truep(C_i_symbolp(t7))){
t8=t5;{
C_word av2[2];
av2[0]=t8;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_u_i_car(t6);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7841,a[2]=t8,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:529: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word av2[2];
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t9;
tp(2,av2);}}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7975 in map-loop1681 in k7846 in k7811 in k7808 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7977(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7977,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7952(t6,((C_word*)t0)[5],t5);}

/* for-each-loop1600 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_7989(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7989,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7999,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:492: g1601 */
t5=((C_word*)t0)[3];
f_7651(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7997 in for-each-loop1600 in k7802 in k7648 in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_7999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7999,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7989(t3,((C_word*)t0)[4],t2);}

/* loop in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8016(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(17,0,2)))){
C_save_and_reclaim_args((void *)trf_8016,3,t0,t1,t2);}
a=C_alloc(17);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=C_i_symbolp(t3);
t5=(C_truep(t4)?t3:C_i_car(t3));
t6=t5;
if(C_truep(C_i_assq(t6,((C_word*)t0)[2]))){
t7=t2;
t8=C_u_i_cdr(t7);
/* modules.scm:470: loop */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8047,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=C_i_assq(t6,((C_word*)t0)[4]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8060,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8063,a[2]=t9,a[3]=t7,a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t10,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t9)){
t12=C_i_cdr(t9);
t13=t11;
f_8063(t13,C_i_symbolp(t12));}
else{
t12=t11;
f_8063(t12,C_SCHEME_FALSE);}}}}

/* k8045 in loop in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8047(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_8047,2,t0,t1);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8051,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* modules.scm:491: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8016(t6,t3,t5);}

/* k8049 in k8045 in loop in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8051(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_8051,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8058 in loop in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_8060,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
f_8047(t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k8061 in loop in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_8063,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_8047(t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8113,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:477: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word av2[2];
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t2;
tp(2,av2);}}}

/* k8073 in k8111 in k8061 in loop in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,3)))){
C_save_and_reclaim_args((void *)trf_8075,2,t0,t1);}
a=C_alloc(11);
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_8047(t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}
else{
if(C_truep(C_i_not(((C_word*)t0)[5]))){
t2=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8095,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8099,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:486: scheme#symbol->string */
t6=*((C_word*)lf[96]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
/* modules.scm:490: module-rename */
f_9782(((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[7]);}}}

/* k8089 in k8073 in k8111 in k8061 in loop in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8091(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_8091,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
f_8047(t2,C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_FALSE));}

/* k8093 in k8073 in k8111 in k8061 in loop in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8095(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8095,2,av);}
/* modules.scm:483: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[38]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[38]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k8097 in k8073 in k8111 in k8061 in loop in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8099,2,av);}
/* modules.scm:484: scheme#string-append */
t2=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[101];
av2[3]=t1;
av2[4]=lf[102];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k8111 in k8061 in loop in k7645 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8113(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_8113,2,av);}
a=C_alloc(9);
t2=C_i_assq(((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8075,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=C_i_cdr(t3);
t6=t4;
f_8075(t6,C_i_symbolp(t5));}
else{
t5=t4;
f_8075(t5,C_SCHEME_FALSE);}}

/* k8144 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8146(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_8146,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8148,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8148(t5,((C_word*)t0)[3],t1);}

/* loop in k8144 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8148(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_8148,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8161,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_caar(t2);
/* modules.scm:460: find-export */
f_7528(t3,t4,((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* k8159 in loop in k8144 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8161(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_8161,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8170,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* modules.scm:461: loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_8148(t7,t4,t6);}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* modules.scm:462: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_8148(t4,((C_word*)t0)[3],t3);}}

/* k8168 in k8159 in loop in k8144 in k7642 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8170(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_8170,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop1546 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8183(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_8183,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8208,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_car(t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7635,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:453: ##sys#macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[28]+1));
C_word av2[2];
av2[0]=*((C_word*)lf[28]+1);
av2[1]=t8;
tp(2,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8206 in map-loop1546 in ##sys#finalize-module in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8208(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8208,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8183(t6,((C_word*)t0)[5],t5);}

/* ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_8218,3,av);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8222,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8350,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8354,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* modules.scm:566: scheme#symbol->string */
t6=*((C_word*)lf[96]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_8222,2,av);}
a=C_alloc(9);
t2=t1;
if(C_truep(t2)){
t3=*((C_word*)lf[2]+1);
t4=*((C_word*)lf[29]+1);
t5=*((C_word*)lf[104]+1);
t6=*((C_word*)lf[28]+1);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8228,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
/* modules.scm:571: ##sys#current-meta-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[104]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[104]+1);
av2[1]=t7;
tp(2,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_8228,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8231,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* modules.scm:573: ##sys#meta-macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[107]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[107]+1);
av2[1]=t3;
tp(2,av2);}}

/* k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8231(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(38,c,4)))){
C_save_and_reclaim((void *)f_8231,2,av);}
a=C_alloc(38);
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[2];
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=t1;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_TRUE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8236,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t9,a[6]=t11,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word)li71),tmp=(C_word)a,a+=12,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8292,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8317,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word)li76),tmp=(C_word)a,a+=11,tmp);
/* modules.scm:568: ##sys#dynamic-wind */
t15=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t15;
av2[1]=((C_word*)t0)[9];
av2[2]=t12;
av2[3]=t13;
av2[4]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(5,av2);}}

/* a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_8236,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
/* modules.scm:568: ##sys#current-module1750 */
t3=((C_word*)t0)[10];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=C_SCHEME_TRUE;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t3))(5,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=((C_word*)((C_word*)t0)[2])[1];
f_8240(2,av2);}}}

/* k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_8240,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
/* modules.scm:568: ##sys#current-environment1751 */
t4=((C_word*)t0)[10];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=C_SCHEME_TRUE;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t4))(5,av2);}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
f_8243(2,av2);}}}

/* k8241 in k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8243(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,4)))){
C_save_and_reclaim((void *)f_8243,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
/* modules.scm:568: ##sys#current-meta-environment1752 */
t4=((C_word*)t0)[9];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=C_SCHEME_TRUE;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t4))(5,av2);}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=((C_word*)((C_word*)t0)[4])[1];
f_8246(2,av2);}}}

/* k8244 in k8241 in k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8246(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,4)))){
C_save_and_reclaim((void *)f_8246,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
/* modules.scm:568: ##sys#macro-environment1753 */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[5])[1];
av2[3]=C_SCHEME_TRUE;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t4))(5,av2);}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=((C_word*)((C_word*)t0)[5])[1];
f_8249(2,av2);}}}

/* k8247 in k8244 in k8241 in k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8249(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_8249,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* modules.scm:568: ##sys#current-module1750 */
t4=((C_word*)t0)[13];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}

/* k8251 in k8247 in k8244 in k8241 in k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_8253,2,av);}
a=C_alloc(15);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8257,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* modules.scm:568: ##sys#current-environment1751 */
t4=((C_word*)t0)[12];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}

/* k8255 in k8251 in k8247 in k8244 in k8241 in k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8257(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,2)))){
C_save_and_reclaim((void *)f_8257,2,av);}
a=C_alloc(14);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
/* modules.scm:568: ##sys#current-meta-environment1752 */
t4=((C_word*)t0)[9];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}

/* k8259 in k8255 in k8251 in k8247 in k8244 in k8241 in k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8261(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_8261,2,av);}
a=C_alloc(13);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* modules.scm:568: ##sys#macro-environment1753 */
t4=((C_word*)t0)[6];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}

/* k8263 in k8259 in k8255 in k8251 in k8247 in k8244 in k8241 in k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8265(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_8265,2,av);}
a=C_alloc(10);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8268,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* modules.scm:568: ##sys#current-module1750 */
t4=((C_word*)t0)[11];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[12];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t4))(5,av2);}}

/* k8266 in k8263 in k8259 in k8255 in k8251 in k8247 in k8244 in k8241 in k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_8268,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:568: ##sys#current-environment1751 */
t3=((C_word*)t0)[8];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t3))(5,av2);}}

/* k8269 in k8266 in k8263 in k8259 in k8255 in k8251 in k8247 in k8244 in k8241 in k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8271(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_8271,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* modules.scm:568: ##sys#current-meta-environment1752 */
t3=((C_word*)t0)[6];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t3))(5,av2);}}

/* k8272 in k8269 in k8266 in k8263 in k8259 in k8255 in k8251 in k8247 in k8244 in k8241 in k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_8274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_8274,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:568: ##sys#macro-environment1753 */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t3))(5,av2);}}

/* k8275 in k8272 in k8269 in k8266 in k8263 in k8259 in k8255 in k8251 in k8247 in k8244 in k8241 in k8238 in a8235 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in ... */
static void C_ccall f_8277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8277,2,av);}
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a8291 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(19,c,4)))){
C_save_and_reclaim((void *)f_8292,2,av);}
a=C_alloc(19);
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8298,a[2]=t5,a[3]=t3,a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8312,a[2]=t3,a[3]=t5,a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp);
/* modules.scm:574: ##sys#dynamic-wind */
t9=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=t1;
av2[2]=t6;
av2[3]=t7;
av2[4]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}

/* a8297 in a8291 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8298,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[105]+1));
t3=C_mutate((C_word*)lf[105]+1 /* (set! ##sys#notices-enabled ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a8302 in a8291 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_8303,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8307,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:575: scheme#load */
t3=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8305 in a8302 in a8291 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8307,2,av);}
/* modules.scm:576: ##sys#find-module */
t2=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[73];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a8311 in a8291 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8312(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8312,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[105]+1));
t3=C_mutate((C_word*)lf[105]+1 /* (set! ##sys#notices-enabled ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a8316 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_8317,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* modules.scm:568: ##sys#current-module1750 */
t3=((C_word*)t0)[9];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}

/* k8319 in a8316 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_8321,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8324,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* modules.scm:568: ##sys#current-environment1751 */
t4=((C_word*)t0)[9];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}

/* k8322 in k8319 in a8316 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8324(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_8324,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* modules.scm:568: ##sys#current-meta-environment1752 */
t4=((C_word*)t0)[9];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}

/* k8325 in k8322 in k8319 in a8316 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8327(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,2)))){
C_save_and_reclaim((void *)f_8327,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* modules.scm:568: ##sys#macro-environment1753 */
t4=((C_word*)t0)[9];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}

/* k8328 in k8325 in k8322 in k8319 in a8316 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,4)))){
C_save_and_reclaim((void *)f_8330,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* modules.scm:568: ##sys#current-module1750 */
t4=((C_word*)t0)[13];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t4))(5,av2);}}

/* k8331 in k8328 in k8325 in k8322 in k8319 in a8316 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8333(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_8333,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* modules.scm:568: ##sys#current-environment1751 */
t3=((C_word*)t0)[13];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t3))(5,av2);}}

/* k8334 in k8331 in k8328 in k8325 in k8322 in k8319 in a8316 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_8336,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* modules.scm:568: ##sys#current-meta-environment1752 */
t3=((C_word*)t0)[12];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[6])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t3))(5,av2);}}

/* k8337 in k8334 in k8331 in k8328 in k8325 in k8322 in k8319 in a8316 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8339(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_8339,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* modules.scm:568: ##sys#macro-environment1753 */
t3=((C_word*)t0)[11];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[8])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t3))(5,av2);}}

/* k8340 in k8337 in k8334 in k8331 in k8328 in k8325 in k8322 in k8319 in a8316 in k8229 in k8226 in k8220 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8342(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8342,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[5]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[7]);
t5=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[9]);
t6=((C_word*)t0)[10];{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k8348 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8350,2,av);}
/* modules.scm:565: chicken.load#find-dynamic-extension */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[108]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[108]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
tp(4,av2);}}

/* k8352 in ##sys#import-library-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8354(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8354,2,av);}
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[109]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[109]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[110];
tp(4,av2);}}

/* find-module/import-library in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8357(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_8357,3,t1,t2,t3);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8361,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:579: ##sys#resolve-module-name */
t5=*((C_word*)lf[20]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k8359 in find-module/import-library in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_8361,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8364,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:580: ##sys#find-module */
t4=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k8362 in k8359 in find-module/import-library in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8364,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* modules.scm:581: ##sys#import-library-hook */
t2=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8372(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_8372,6,av);}
a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8376,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* modules.scm:584: r */
t7=t3;{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[135];
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}

/* k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8376(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_8376,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* modules.scm:585: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[134];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8379(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_8379,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* modules.scm:586: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[133];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_8382,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* modules.scm:587: r */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[132];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8385(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,5)))){
C_save_and_reclaim((void *)f_8385,2,av);}
a=C_alloc(23);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8387,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8401,a[2]=((C_word*)t0)[2],a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp));
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8448,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li112),tmp=(C_word)a,a+=12,tmp);
/* modules.scm:596: scheme#call-with-current-continuation */
t10=*((C_word*)lf[131]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=((C_word*)t0)[8];
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* warn in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8387(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_8387,4,t1,t2,t3,t4);}
a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8395,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8399,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:589: scheme#symbol->string */
t7=*((C_word*)lf[96]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k8393 in warn in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8395,2,av);}
/* modules.scm:589: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[38]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[38]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k8397 in warn in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_8399,2,av);}
/* modules.scm:589: scheme#string-append */
t2=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[113];
av2[4]=t1;
av2[5]=lf[114];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* tostr in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8401(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_8401,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_stringp(t2))){
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8414,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:592: chicken.keyword#keyword? */
t4=*((C_word*)lf[120]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k8412 in tostr in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8414(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_8414,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* modules.scm:592: ##sys#symbol->string */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[116]+1));
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[116]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
/* modules.scm:593: ##sys#symbol->string */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[116]+1));
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[116]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}
else{
if(C_truep(C_i_numberp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[3];
/* ##sys#number->string */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[117]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[117]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
av2[3]=C_fix(10);
tp(4,av2);}}
else{
/* modules.scm:595: ##sys#syntax-error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[118]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[118]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[119];
tp(4,av2);}}}}}

/* k8419 in k8412 in tostr in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8421,2,av);}
/* modules.scm:592: ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[109]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[109]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[115];
tp(4,av2);}}

/* a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8448(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
C_save_and_reclaim((void *)f_8448,3,av);}
a=C_alloc(20);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8451,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8499,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word)li111),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_8499(t7,t1,((C_word*)t0)[10]);}

/* module-imports in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8451(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_8451,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8455,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:599: chicken.internal#library-id */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[23]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[23]+1);
av2[1]=t3;
av2[2]=t2;
tp(3,av2);}}

/* k8453 in module-imports in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_8455,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:600: find-module/import-library */
f_8357(t3,t2,((C_word*)t0)[4]);}

/* k8456 in k8453 in module-imports in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8458(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_8458,2,av);}
if(C_truep(C_i_not(t1))){
/* modules.scm:602: k */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[4];
av2[4]=C_SCHEME_FALSE;
av2[5]=C_SCHEME_FALSE;
av2[6]=C_SCHEME_FALSE;
av2[7]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t2))(8,av2);}}
else{
t2=C_i_check_structure_2(t1,lf[4],lf[6]);
t3=C_i_block_ref(t1,C_fix(1));
t4=C_i_check_structure_2(t1,lf[4],lf[61]);
t5=C_i_block_ref(t1,C_fix(2));
t6=C_i_check_structure_2(t1,lf[4],lf[6]);
t7=C_i_block_ref(t1,C_fix(1));
t8=C_i_check_structure_2(t1,lf[4],lf[13]);
t9=C_i_block_ref(t1,C_fix(11));
t10=C_i_check_structure_2(t1,lf[4],lf[14]);
t11=C_i_block_ref(t1,C_fix(12));
t12=C_i_check_structure_2(t1,lf[4],lf[62]);
t13=C_i_block_ref(t1,C_fix(13));
/* modules.scm:603: scheme#values */{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
av2[3]=t5;
av2[4]=t7;
av2[5]=t9;
av2[6]=t11;
av2[7]=t13;
C_values(8,av2);}}}

/* loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8499(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,4)))){
C_save_and_reclaim_args((void *)trf_8499,3,t0,t1,t2);}
a=C_alloc(14);
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8513,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:611: chicken.syntax#strip-syntax */
t4=*((C_word*)lf[65]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=C_i_pairp(t2);
if(C_truep(C_i_not(t3))){
/* modules.scm:613: ##sys#syntax-error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[118]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[118]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[121];
av2[4]=t2;
tp(5,av2);}}
else{
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8531,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[2],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* modules.scm:616: c */
t7=((C_word*)t0)[7];{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[11];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}}

/* k8511 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8513(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8513,2,av);}
/* modules.scm:611: module-imports */
t2=((C_word*)t0)[2];
f_8451(t2,((C_word*)t0)[3],t1);}

/* k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8531(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_8531,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* modules.scm:617: ##sys#check-syntax */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[123]+1));
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[123]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[124];
tp(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* modules.scm:635: c */
t3=((C_word*)t0)[10];{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[13];
av2[3]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}}

/* k8532 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8534(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,8)))){
C_save_and_reclaim((void *)f_8534,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li82),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8549,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word)li88),tmp=(C_word)a,a+=6,tmp);
/* modules.scm:618: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[6];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a8538 in k8532 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8539,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* modules.scm:618: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8499(t3,t1,t2);}

/* a8548 in k8532 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8549(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=8) C_bad_argc_2(c,8,t0);
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_8549,8,av);}
a=C_alloc(11);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8553,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[3],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t9=C_i_cddr(((C_word*)t0)[4]);
/* modules.scm:619: chicken.syntax#strip-syntax */
t10=*((C_word*)lf[65]+1);{
C_word *av2=av;
av2[0]=t10;
av2[1]=t8;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k8551 in a8548 in k8532 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,6)))){
C_save_and_reclaim((void *)f_8553,2,av);}
a=C_alloc(15);
t2=t1;
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[5];
t7=((C_word*)t0)[6];
t8=((C_word*)t0)[7];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8558,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=t4,a[8]=t8,a[9]=t6,a[10]=t10,a[11]=t7,a[12]=((C_word)li87),tmp=(C_word)a,a+=13,tmp));
t12=((C_word*)t10)[1];
f_8558(t12,((C_word*)t0)[10],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k8551 in a8548 in k8532 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8558(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(23,0,5)))){
C_save_and_reclaim_args((void *)trf_8558,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(23);
if(C_truep(C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li83),tmp=(C_word)a,a+=5,tmp);
t7=t5;
t8=C_i_check_list_2(t7,lf[33]);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8589,a[2]=t11,a[3]=t6,a[4]=((C_word)li84),tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_8589(t13,t9,t7);}
else{
t6=C_i_car(t2);
t7=C_i_assq(t6,((C_word*)t0)[9]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8617,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[10],a[5]=t4,a[6]=t5,a[7]=((C_word)li85),tmp=(C_word)a,a+=8,tmp);
/* modules.scm:621: g1921 */
t9=t8;
f_8617(t9,t1,t7);}
else{
t8=t2;
t9=C_u_i_car(t8);
t10=C_i_assq(t9,((C_word*)t0)[11]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8639,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=t3,a[6]=t5,a[7]=((C_word)li86),tmp=(C_word)a,a+=8,tmp);
/* modules.scm:621: g1925 */
t12=t11;
f_8639(t12,t1,t10);}
else{
t11=t2;
t12=C_u_i_cdr(t11);
t13=t2;
t14=C_u_i_car(t13);
t15=C_a_i_cons(&a,2,t14,t5);
/* modules.scm:634: loop */
t17=t1;
t18=t12;
t19=t3;
t20=t4;
t21=t15;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
t5=t21;
goto loop;}}}}

/* g1901 in loop in k8551 in a8548 in k8532 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8566(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_8566,3,t0,t1,t2);}
/* modules.scm:624: warn */
f_8387(t1,lf[122],((C_word*)t0)[3],t2);}

/* k8574 in loop in k8551 in a8548 in k8532 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8576(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,7)))){
C_save_and_reclaim((void *)f_8576,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
/* modules.scm:626: scheme#values */{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=0;
av2[1]=((C_word*)t0)[5];
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[7];
av2[4]=t3;
av2[5]=((C_word*)t0)[8];
av2[6]=((C_word*)t0)[9];
av2[7]=((C_word*)t0)[10];
C_values(8,av2);}}

/* for-each-loop1900 in loop in k8551 in a8548 in k8532 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8589(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_8589,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8599,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:622: g1901 */
t5=((C_word*)t0)[3];
f_8566(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8597 in for-each-loop1900 in loop in k8551 in a8548 in k8532 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8599(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8599,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8589(t3,((C_word*)t0)[4],t2);}

/* g1921 in loop in k8551 in a8548 in k8532 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,5)))){
C_save_and_reclaim_args((void *)trf_8617,3,t0,t1,t2);}
a=C_alloc(3);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
/* modules.scm:629: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8558(t5,t1,t3,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* g1925 in loop in k8551 in a8548 in k8532 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8639(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,5)))){
C_save_and_reclaim_args((void *)trf_8639,3,t0,t1,t2);}
a=C_alloc(3);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
/* modules.scm:632: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8558(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)t0)[6]);}

/* k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8681(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_8681,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* modules.scm:636: ##sys#check-syntax */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[123]+1));
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[123]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[126];
tp(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* modules.scm:658: c */
t3=((C_word*)t0)[10];{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[12];
av2[3]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}}

/* k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8684(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,8)))){
C_save_and_reclaim((void *)f_8684,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li89),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8699,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word)li96),tmp=(C_word)a,a+=6,tmp);
/* modules.scm:637: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[6];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a8688 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8689(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8689,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* modules.scm:637: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8499(t3,t1,t2);}

/* a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=8) C_bad_argc_2(c,8,t0);
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_8699,8,av);}
a=C_alloc(11);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8703,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[3],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t9=C_i_cddr(((C_word*)t0)[4]);
/* modules.scm:638: chicken.syntax#strip-syntax */
t10=*((C_word*)lf[65]+1);{
C_word *av2=av;
av2[0]=t10;
av2[1]=t8;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k8701 in a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8703(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,5)))){
C_save_and_reclaim((void *)f_8703,2,av);}
a=C_alloc(14);
t2=t1;
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[5];
t7=((C_word*)t0)[6];
t8=((C_word*)t0)[7];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8708,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[9],a[7]=t4,a[8]=t8,a[9]=t7,a[10]=t10,a[11]=((C_word)li95),tmp=(C_word)a,a+=12,tmp));
t12=((C_word*)t10)[1];
f_8708(t12,((C_word*)t0)[10],t6,C_SCHEME_END_OF_LIST,t2);}

/* loop in k8701 in a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8708(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(14,0,5)))){
C_save_and_reclaim_args((void *)trf_8708,5,t0,t1,t2,t3,t4);}
a=C_alloc(14);
if(C_truep(C_i_nullp(t2))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=t6,a[11]=((C_word)li93),tmp=(C_word)a,a+=12,tmp));
t8=((C_word*)t6)[1];
f_8720(t8,t1,((C_word*)t0)[9],C_SCHEME_END_OF_LIST,t4);}
else{
t5=C_i_caar(t2);
t6=C_i_memq(t5,t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8820,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=t4,a[6]=((C_word)li94),tmp=(C_word)a,a+=7,tmp);
/* modules.scm:640: g2004 */
t8=t7;
f_8820(t8,t1,t6);}
else{
t7=t2;
t8=C_u_i_cdr(t7);
t9=t2;
t10=C_u_i_car(t9);
t11=C_a_i_cons(&a,2,t10,t3);
/* modules.scm:657: loop */
t13=t1;
t14=t8;
t15=t11;
t16=t4;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}}}

/* loop in loop in k8701 in a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8720(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(23,0,4)))){
C_save_and_reclaim_args((void *)trf_8720,5,t0,t1,t2,t3,t4);}
a=C_alloc(23);
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li90),tmp=(C_word)a,a+=5,tmp);
t6=t4;
t7=C_i_check_list_2(t6,lf[33]);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8738,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8751,a[2]=t10,a[3]=t5,a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_8751(t12,t8,t6);}
else{
t5=C_i_caar(t2);
t6=C_i_memq(t5,t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8779,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=t4,a[6]=((C_word)li92),tmp=(C_word)a,a+=7,tmp);
/* modules.scm:642: g1999 */
t8=t7;
f_8779(t8,t1,t6);}
else{
t7=t2;
t8=C_u_i_cdr(t7);
t9=t2;
t10=C_u_i_car(t9);
t11=C_a_i_cons(&a,2,t10,t3);
/* modules.scm:652: loop */
t13=t1;
t14=t8;
t15=t11;
t16=t4;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}}}

/* g1979 in loop in loop in k8701 in a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8728(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_8728,3,t0,t1,t2);}
/* modules.scm:645: warn */
f_8387(t1,lf[125],((C_word*)t0)[3],t2);}

/* k8736 in loop in loop in k8701 in a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,7)))){
C_save_and_reclaim((void *)f_8738,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
/* modules.scm:647: scheme#values */{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=0;
av2[1]=((C_word*)t0)[5];
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[7];
av2[4]=t3;
av2[5]=((C_word*)t0)[8];
av2[6]=((C_word*)t0)[9];
av2[7]=((C_word*)t0)[10];
C_values(8,av2);}}

/* for-each-loop1978 in loop in loop in k8701 in a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_8751,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8761,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:643: g1979 */
t5=((C_word*)t0)[3];
f_8728(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8759 in for-each-loop1978 in loop in loop in k8701 in a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_8761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8761,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8751(t3,((C_word*)t0)[4],t2);}

/* g1999 in loop in loop in k8701 in a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8779(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_8779,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8791,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t2);
/* modules.scm:650: delete */
f_4483(t5,t6,((C_word*)t0)[5],*((C_word*)lf[43]+1));}

/* k8789 in g1999 in loop in loop in k8701 in a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_8791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8791,2,av);}
/* modules.scm:650: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_8720(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* g2004 in loop in k8701 in a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8820(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_8820,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8832,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t2);
/* modules.scm:655: delete */
f_4483(t5,t6,((C_word*)t0)[5],*((C_word*)lf[43]+1));}

/* k8830 in g2004 in loop in k8701 in a8698 in k8682 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8832,2,av);}
/* modules.scm:655: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_8708(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8864(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_8864,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* modules.scm:659: ##sys#check-syntax */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[123]+1));
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[123]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[128];
tp(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* modules.scm:685: c */
t3=((C_word*)t0)[10];{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[11];
av2[3]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}}

/* k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8867(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,8)))){
C_save_and_reclaim((void *)f_8867,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li97),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8882,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word)li105),tmp=(C_word)a,a+=6,tmp);
/* modules.scm:660: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[6];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a8871 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8872,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* modules.scm:660: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8499(t3,t1,t2);}

/* a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=8) C_bad_argc_2(c,8,t0);
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_8882,8,av);}
a=C_alloc(11);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8886,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[3],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t9=C_i_cddr(((C_word*)t0)[4]);
/* modules.scm:661: chicken.syntax#strip-syntax */
t10=*((C_word*)lf[65]+1);{
C_word *av2=av;
av2[0]=t10;
av2[1]=t8;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_8886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,5)))){
C_save_and_reclaim((void *)f_8886,2,av);}
a=C_alloc(14);
t2=t1;
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[5];
t7=((C_word*)t0)[6];
t8=((C_word*)t0)[7];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8891,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[9],a[7]=t4,a[8]=t8,a[9]=t7,a[10]=t10,a[11]=((C_word)li104),tmp=(C_word)a,a+=12,tmp));
t12=((C_word*)t10)[1];
f_8891(t12,((C_word*)t0)[10],t6,C_SCHEME_END_OF_LIST,t2);}

/* loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8891(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(14,0,5)))){
C_save_and_reclaim_args((void *)trf_8891,5,t0,t1,t2,t3,t4);}
a=C_alloc(14);
if(C_truep(C_i_nullp(t2))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=t6,a[11]=((C_word)li102),tmp=(C_word)a,a+=12,tmp));
t8=((C_word*)t6)[1];
f_8903(t8,t1,((C_word*)t0)[9],C_SCHEME_END_OF_LIST,t4);}
else{
t5=C_i_caar(t2);
t6=C_i_assq(t5,t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9058,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[10],a[5]=t4,a[6]=((C_word)li103),tmp=(C_word)a,a+=7,tmp);
/* modules.scm:663: g2109 */
t8=t7;
f_9058(t8,t1,t6);}
else{
t7=t2;
t8=C_u_i_cdr(t7);
t9=t2;
t10=C_u_i_car(t9);
t11=C_a_i_cons(&a,2,t10,t3);
/* modules.scm:684: loop */
t13=t1;
t14=t8;
t15=t11;
t16=t4;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}}}

/* loop in loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_8903(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(30,0,4)))){
C_save_and_reclaim_args((void *)trf_8903,5,t0,t1,t2,t3,t4);}
a=C_alloc(30);
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li98),tmp=(C_word)a,a+=5,tmp);
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=t4;
t11=C_i_check_list_2(t10,lf[18]);
t12=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8924,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=t5,tmp=(C_word)a,a+=12,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8966,a[2]=t8,a[3]=t14,a[4]=t9,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_8966(t16,t12,t10);}
else{
t5=C_i_caar(t2);
t6=C_i_assq(t5,t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9005,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[10],a[5]=t4,a[6]=((C_word)li101),tmp=(C_word)a,a+=7,tmp);
/* modules.scm:665: g2104 */
t8=t7;
f_9005(t8,t1,t6);}
else{
t7=t2;
t8=C_u_i_cdr(t7);
t9=t2;
t10=C_u_i_car(t9);
t11=C_a_i_cons(&a,2,t10,t3);
/* modules.scm:677: loop */
t17=t1;
t18=t8;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}

/* g2058 in loop in loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_fcall f_8911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_8911,3,t0,t1,t2);}
/* modules.scm:668: warn */
f_8387(t1,lf[127],((C_word*)t0)[3],t2);}

/* k8922 in loop in loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_8924(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_8924,2,av);}
a=C_alloc(18);
t2=C_i_check_list_2(t1,lf[33]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8943,a[2]=t5,a[3]=((C_word*)t0)[11],a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8943(t7,t3,t1);}

/* k8928 in k8922 in loop in loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in ... */
static void C_ccall f_8930(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,7)))){
C_save_and_reclaim((void *)f_8930,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
/* modules.scm:670: scheme#values */{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=0;
av2[1]=((C_word*)t0)[5];
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[7];
av2[4]=t3;
av2[5]=((C_word*)t0)[8];
av2[6]=((C_word*)t0)[9];
av2[7]=((C_word*)t0)[10];
C_values(8,av2);}}

/* for-each-loop2057 in k8922 in loop in loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in ... */
static void C_fcall f_8943(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_8943,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8953,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:666: g2058 */
t5=((C_word*)t0)[3];
f_8911(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8951 in for-each-loop2057 in k8922 in loop in loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in ... */
static void C_ccall f_8953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8953,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8943(t3,((C_word*)t0)[4],t2);}

/* map-loop2070 in loop in loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_fcall f_8966(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_8966,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g2104 in loop in loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_fcall f_9005(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,4)))){
C_save_and_reclaim_args((void *)trf_9005,3,t0,t1,t2);}
a=C_alloc(12);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=C_i_cadr(t2);
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_a_i_cons(&a,2,t5,t6);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9021,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t4,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:675: delete */
f_4483(t10,t2,((C_word*)t0)[5],*((C_word*)lf[43]+1));}

/* k9019 in g2104 in loop in loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in ... */
static void C_ccall f_9021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9021,2,av);}
/* modules.scm:673: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_8903(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* g2109 in loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,4)))){
C_save_and_reclaim_args((void *)trf_9058,3,t0,t1,t2);}
a=C_alloc(12);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=C_i_cadr(t2);
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_a_i_cons(&a,2,t5,t6);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9074,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t4,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:682: delete */
f_4483(t10,t2,((C_word*)t0)[5],*((C_word*)lf[43]+1));}

/* k9072 in g2109 in loop in k8884 in a8881 in k8865 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_9074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9074,2,av);}
/* modules.scm:680: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_8891(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_9114,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* modules.scm:686: ##sys#check-syntax */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[123]+1));
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[123]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[130];
tp(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9270,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:696: chicken.syntax#strip-syntax */
t3=*((C_word*)lf[65]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,8)))){
C_save_and_reclaim((void *)f_9117,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9132,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word)li110),tmp=(C_word)a,a+=6,tmp);
/* modules.scm:687: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[6];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a9121 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9122(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9122,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* modules.scm:687: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8499(t3,t1,t2);}

/* a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9132(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=8) C_bad_argc_2(c,8,t0);
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_9132,8,av);}
a=C_alloc(11);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9136,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[3],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t9=C_i_caddr(((C_word*)t0)[4]);
/* modules.scm:688: chicken.syntax#strip-syntax */
t10=*((C_word*)lf[65]+1);{
C_word *av2=av;
av2[0]=t10;
av2[1]=t8;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(37,c,3)))){
C_save_and_reclaim((void *)f_9136,2,av);}
a=C_alloc(37);
t2=t1;
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[5];
t7=((C_word*)t0)[6];
t8=((C_word*)t0)[7];
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9138,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word)li107),tmp=(C_word)a,a+=5,tmp);
t10=C_a_i_list(&a,3,((C_word*)t0)[9],t5,t2);
t11=t10;
t12=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t13=t12;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=((C_word*)t14)[1];
t16=t9;
t17=C_i_check_list_2(t6,lf[18]);
t18=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9181,a[2]=t9,a[3]=t7,a[4]=((C_word*)t0)[10],a[5]=t3,a[6]=t4,a[7]=t11,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9227,a[2]=t14,a[3]=t20,a[4]=t16,a[5]=t15,a[6]=((C_word)li109),tmp=(C_word)a,a+=7,tmp));
t22=((C_word*)t20)[1];
f_9227(t22,t18,t6);}

/* rename in k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9138(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_9138,3,av);}
a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9146,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9152,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9156,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* modules.scm:692: tostr */
t6=((C_word*)((C_word*)t0)[2])[1];
f_8401(t6,t5,((C_word*)t0)[3]);}

/* k9144 in rename in k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_9146(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_9146,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,t1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9150 in rename in k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_9152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9152,2,av);}
/* modules.scm:691: ##sys#string->symbol */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[129]+1));
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[129]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k9154 in rename in k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_9156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_9156,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9160,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[3]);
/* modules.scm:692: ##sys#symbol->string */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[116]+1));
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[116]+1);
av2[1]=t3;
av2[2]=t4;
tp(3,av2);}}

/* k9158 in k9154 in rename in k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in ... */
static void C_ccall f_9160(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9160,2,av);}
/* modules.scm:692: ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[109]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[109]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* k9179 in k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9181(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,3)))){
C_save_and_reclaim((void *)f_9181,2,av);}
a=C_alloc(22);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)t0)[2];
t8=C_i_check_list_2(((C_word*)t0)[3],lf[18]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9191,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9193,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,a[6]=((C_word)li108),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_9193(t13,t9,((C_word*)t0)[3]);}

/* k9189 in k9179 in k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_9191(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_9191,2,av);}
/* modules.scm:694: scheme#values */{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
av2[6]=t1;
av2[7]=((C_word*)t0)[7];
C_values(8,av2);}}

/* map-loop2175 in k9179 in k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_fcall f_9193(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9193,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9218,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:694: g2181 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9216 in map-loop2175 in k9179 in k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in ... */
static void C_ccall f_9218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9218,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9193(t6,((C_word*)t0)[5],t5);}

/* map-loop2149 in k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9227(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9227,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9252,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:694: g2155 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9250 in map-loop2149 in k9134 in a9131 in k9115 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_9252(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9252,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9227(t6,((C_word*)t0)[5],t5);}

/* k9268 in k9112 in k8862 in k8679 in k8529 in loop in a8447 in k8383 in k8380 in k8377 in k8374 in ##sys#decompose-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9270,2,av);}
/* modules.scm:696: module-imports */
t2=((C_word*)t0)[2];
f_8451(t2,((C_word*)t0)[3],t1);}

/* ##sys#expand-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9276(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9=av[9];
C_word t10;
C_word t11;
C_word *a;
if(c!=10) C_bad_argc_2(c,10,t0);
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_9276,10,av);}
a=C_alloc(11);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9280,a[2]=t3,a[3]=t4,a[4]=t9,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t2,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* modules.scm:699: ##sys#check-syntax */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[123]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[123]+1);
av2[1]=t10;
av2[2]=t9;
av2[3]=t2;
av2[4]=lf[140];
tp(5,av2);}}

/* k9278 in ##sys#expand-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9280(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
C_save_and_reclaim((void *)f_9280,2,av);}
a=C_alloc(20);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li116),tmp=(C_word)a,a+=10,tmp);
t3=C_i_cdr(((C_word*)t0)[9]);
t4=C_i_check_list_2(t3,lf[33]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9315,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9317,a[2]=t7,a[3]=t2,a[4]=((C_word)li117),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_9317(t9,t5,t3);}

/* g2217 in k9278 in ##sys#expand-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9281(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,0,8)))){
C_save_and_reclaim_args((void *)trf_9281,3,t0,t1,t2);}
a=C_alloc(16);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9287,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li114),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9293,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li115),tmp=(C_word)a,a+=9,tmp);
/* modules.scm:702: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}

/* a9286 in g2217 in k9278 in ##sys#expand-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_9287,2,av);}
/* modules.scm:702: ##sys#decompose-import */
t2=*((C_word*)lf[112]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
av2[5]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* a9292 in g2217 in k9278 in ##sys#expand-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8;
C_word *a;
if(c!=8) C_bad_argc_2(c,8,t0);
if(C_unlikely(!C_demand(C_calculate_demand(0,c,10)))){
C_save_and_reclaim((void *)f_9293,8,av);}
if(C_truep(C_i_not(t4))){
/* modules.scm:704: ##sys#syntax-error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[118]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[118]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[137];
av2[4]=t2;
av2[5]=((C_word*)t0)[3];
tp(6,av2);}}
else{
/* modules.scm:705: ##sys#import */
t8=*((C_word*)lf[138]+1);{
C_word *av2;
if(c >= 11) {
  av2=av;
} else {
  av2=C_alloc(11);
}
av2[0]=t8;
av2[1]=t1;
av2[2]=t4;
av2[3]=t5;
av2[4]=t6;
av2[5]=t7;
av2[6]=((C_word*)t0)[4];
av2[7]=((C_word*)t0)[5];
av2[8]=((C_word*)t0)[6];
av2[9]=((C_word*)t0)[7];
av2[10]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t8+1)))(11,av2);}}}

/* k9313 in k9278 in ##sys#expand-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_9315,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[139];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop2216 in k9278 in ##sys#expand-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9317(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_9317,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9327,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:700: g2217 */
t5=((C_word*)t0)[3];
f_9281(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k9325 in for-each-loop2216 in k9278 in ##sys#expand-import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9327(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9327,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9317(t3,((C_word*)t0)[4],t2);}

/* ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9340(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9=av[9];
C_word t10=av[10];
C_word t11;
C_word t12;
C_word *a;
if(c!=11) C_bad_argc_2(c,11,t0);
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_9340,11,av);}
a=C_alloc(12);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9344,a[2]=t6,a[3]=t3,a[4]=t7,a[5]=t4,a[6]=t1,a[7]=t9,a[8]=t5,a[9]=t10,a[10]=t8,a[11]=t2,tmp=(C_word)a,a+=12,tmp);
/* modules.scm:710: ##sys#current-module */
t12=*((C_word*)lf[2]+1);{
C_word *av2=av;
av2[0]=t12;
av2[1]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}

/* k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9344(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_9344,2,av);}
a=C_alloc(18);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[10])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9757,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_check_structure_2(t2,lf[4],lf[58]);
t6=C_i_block_ref(t2,C_fix(9));
t7=C_a_i_list1(&a,1,((C_word*)t0)[11]);
/* modules.scm:715: scheme#append */
t8=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t4;
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9772,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_check_structure_2(t2,lf[4],lf[57]);
t6=C_i_block_ref(t2,C_fix(8));
t7=C_a_i_list1(&a,1,((C_word*)t0)[11]);
/* modules.scm:718: scheme#append */
t8=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t4;
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_9347(2,av2);}}}

/* k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9347(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,3)))){
C_save_and_reclaim((void *)f_9347,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9357,a[2]=((C_word*)t0)[2],a[3]=((C_word)li119),tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_i_check_list_2(t3,lf[33]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9401,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9726,a[2]=t7,a[3]=t2,a[4]=((C_word)li126),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_9726(t9,t5,t3);}

/* g2278 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9357(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_9357,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_car(t2);
t4=t3;
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9395,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:725: import-env */
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)C_fast_retrieve_proc(t6))(2,av2);}}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k9393 in g2278 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9395,2,av);}
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
if(C_truep(t4)){
t5=C_i_cdr(t2);
t6=C_eqp(t4,t5);
if(C_truep(C_i_not(t6))){
/* modules.scm:728: ##sys#notice */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[141]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[141]+1);
av2[1]=((C_word*)t0)[4];
av2[2]=lf[142];
av2[3]=((C_word*)t0)[2];
tp(4,av2);}}
else{
t7=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t5=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9401(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,3)))){
C_save_and_reclaim((void *)f_9401,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9402,a[2]=((C_word*)t0)[2],a[3]=((C_word)li120),tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_i_check_list_2(t3,lf[33]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9703,a[2]=t7,a[3]=t2,a[4]=((C_word)li125),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_9703(t9,t5,t3);}

/* g2288 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9402(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_9402,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9438,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:732: macro-env */
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)C_fast_retrieve_proc(t6))(2,av2);}}

/* k9436 in g2288 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9438(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9438,2,av);}
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_i_cdr(t2);
t6=C_eqp(t4,t5);
if(C_truep(C_i_not(t6))){
t7=((C_word*)t0)[3];
t8=C_u_i_car(t7);
/* modules.scm:734: ##sys#notice */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[141]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[141]+1);
av2[1]=((C_word*)t0)[4];
av2[2]=lf[143];
av2[3]=t8;
tp(4,av2);}}
else{
t7=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t3=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9444(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_9444,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[7])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9472,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[8])){
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_9472(2,av2);}}
else{
/* modules.scm:738: ##sys#syntax-error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[118]+1));
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[118]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[10];
av2[3]=lf[144];
tp(4,av2);}}}
else{
t3=t2;
f_9447(t3,C_SCHEME_UNDEFINED);}}

/* k9445 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9447(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,2)))){
C_save_and_reclaim_args((void *)trf_9447,2,t0,t1);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9465,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9469,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:759: import-env */
t5=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)C_fast_retrieve_proc(t5))(2,av2);}}

/* k9448 in k9445 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9450(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_9450,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9461,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* modules.scm:760: macro-env */
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}

/* k9455 in k9448 in k9445 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9457,2,av);}
/* modules.scm:760: macro-env */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* k9459 in k9448 in k9445 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9461(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9461,2,av);}
/* modules.scm:760: scheme#append */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k9463 in k9445 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9465(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9465,2,av);}
/* modules.scm:759: import-env */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* k9467 in k9445 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9469,2,av);}
/* modules.scm:759: scheme#append */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,3)))){
C_save_and_reclaim((void *)f_9472,2,av);}
a=C_alloc(27);
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[4],lf[12]);
t3=C_i_block_ref(((C_word*)t0)[2],C_fix(3));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9478,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_eqp(C_SCHEME_TRUE,t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9498,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9595,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_structure_2(((C_word*)t0)[2],lf[4],lf[14]);
t9=C_i_block_ref(((C_word*)t0)[2],C_fix(12));
/* modules.scm:741: scheme#append */
t10=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t7;
av2[2]=((C_word*)t0)[6];
av2[3]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9606,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=C_i_check_structure_2(((C_word*)t0)[2],lf[4],lf[12]);
t8=C_i_block_ref(((C_word*)t0)[2],C_fix(3));
t9=C_eqp(C_SCHEME_TRUE,t8);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:t8);
t11=t10;
t12=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t13=t12;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=((C_word*)t14)[1];
t16=((C_word*)t0)[5];
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9620,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9663,a[2]=t14,a[3]=t19,a[4]=t15,a[5]=((C_word)li124),tmp=(C_word)a,a+=6,tmp));
t21=((C_word*)t19)[1];
f_9663(t21,t17,t16);}}

/* k9476 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_9478,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9481,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9488,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_check_structure_2(((C_word*)t0)[3],lf[4],lf[62]);
t5=C_i_block_ref(((C_word*)t0)[3],C_fix(13));
/* modules.scm:757: merge-se */
f_6533(t3,C_a_i_list(&a,2,t5,((C_word*)t0)[4]));}

/* k9479 in k9476 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9481(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_9481,2,av);}
t2=((C_word*)t0)[2];
f_9447(t2,C_SCHEME_UNDEFINED);}

/* k9486 in k9476 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9488(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9488,2,av);}
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t3=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(13);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9496 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9498(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,3)))){
C_save_and_reclaim((void *)f_9498,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_structure_2(((C_word*)t0)[2],lf[4],lf[32]);
t4=C_i_block_ref(((C_word*)t0)[2],C_fix(5));
t5=t4;
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=((C_word*)t0)[4];
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9516,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9559,a[2]=t8,a[3]=t13,a[4]=t9,a[5]=((C_word)li122),tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_9559(t15,t11,t10);}

/* k9503 in k9496 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9505,2,av);}
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t3=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(5);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9514 in k9496 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_9516,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)t0)[2];
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9523,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9525,a[2]=t5,a[3]=t10,a[4]=t6,a[5]=((C_word)li121),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9525(t12,t8,t7);}

/* k9521 in k9514 in k9496 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9523,2,av);}
/* modules.scm:744: scheme#append */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop2356 in k9514 in k9496 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9525(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_9525,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop2330 in k9496 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_9559,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9593 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9595(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9595,2,av);}
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t3=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(12);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9604 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9606(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9606,2,av);}
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t3=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(3);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9618 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9620(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_9620,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)t0)[2];
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9627,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9629,a[2]=t5,a[3]=t10,a[4]=t6,a[5]=((C_word)li123),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9629(t12,t8,t7);}

/* k9625 in k9618 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9627,2,av);}
/* modules.scm:750: scheme#append */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop2410 in k9618 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9629(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_9629,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop2384 in k9470 in k9442 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9663(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_9663,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* for-each-loop2287 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9703(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_9703,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9713,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:730: g2288 */
t5=((C_word*)t0)[3];
f_9402(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k9711 in for-each-loop2287 in k9399 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9713,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9703(t3,((C_word*)t0)[4],t2);}

/* for-each-loop2277 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9726(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_9726,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9736,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* modules.scm:722: g2278 */
t5=((C_word*)t0)[3];
f_9357(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k9734 in for-each-loop2277 in k9345 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9736(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9736,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9726(t3,((C_word*)t0)[4],t2);}

/* k9755 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9757(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9757,2,av);}
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t3=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(9);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9770 in k9342 in ##sys#import in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9772(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_9772,2,av);}
t2=C_i_check_structure_2(((C_word*)t0)[2],lf[4],C_SCHEME_FALSE);
/* modules.scm:93: ##sys#block-set! */
t3=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(8);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* module-rename in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9782(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,4)))){
C_save_and_reclaim_args((void *)trf_9782,3,t1,t2,t3);}
a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9790,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_slot(t3,C_fix(1));
t6=C_slot(t2,C_fix(1));
/* modules.scm:764: scheme#string-append */
t7=*((C_word*)lf[93]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t4;
av2[2]=t5;
av2[3]=lf[145];
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k9788 in module-rename in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9790(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9790,2,av);}
/* modules.scm:763: ##sys#string->symbol */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[129]+1));
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[129]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* ##sys#alias-global-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_9800,5,av);}
a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9803,a[2]=t3,a[3]=t4,a[4]=((C_word)li131),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9837,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* modules.scm:778: chicken.keyword#keyword? */
t7=*((C_word*)lf[120]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* mrename in ##sys#alias-global-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9803(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9803,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9807,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:771: ##sys#current-module */
t4=*((C_word*)lf[2]+1);{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9805 in mrename in ##sys#alias-global-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9807(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_9807,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li130),tmp=(C_word)a,a+=6,tmp);
/* modules.scm:771: g2467 */
t3=t2;
f_9811(t3,((C_word*)t0)[5],t1);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g2467 in k9805 in mrename in ##sys#alias-global-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9811(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,3)))){
C_save_and_reclaim_args((void *)trf_9811,3,t0,t1,t2);}
a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9818,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t2;
t5=C_i_check_structure_2(t4,lf[4],lf[6]);
t6=C_i_block_ref(t4,C_fix(1));
/* modules.scm:776: module-rename */
f_9782(t1,((C_word*)t0)[2],t6);}
else{
t4=t3;
t5=((C_word*)t0)[2];
t6=t2;
t7=((C_word*)t0)[4];
if(C_truep(t6)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6164,a[2]=t5,a[3]=t7,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* modules.scm:239: module-undefined-list */
t9=*((C_word*)lf[7]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t8=C_SCHEME_UNDEFINED;
t9=t4;{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}}

/* k9816 in g2467 in k9805 in mrename in ##sys#alias-global-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_9818,2,av);}
t2=((C_word*)t0)[2];
t3=C_i_check_structure_2(t2,lf[4],lf[6]);
t4=C_i_block_ref(t2,C_fix(1));
/* modules.scm:776: module-rename */
f_9782(((C_word*)t0)[3],((C_word*)t0)[4],t4);}

/* k9835 in ##sys#alias-global-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_9837,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];
if(C_truep(C_u_i_namespaced_symbolp(t2))){
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* modules.scm:780: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[29]+1));
C_word *av2=av;
av2[0]=*((C_word*)lf[29]+1);
av2[1]=t3;
tp(2,av2);}}}}

/* g2478 in k9876 in k9835 in ##sys#alias-global-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9852(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_9852,3,t0,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
/* modules.scm:785: mrename */
t4=((C_word*)t0)[2];
f_9803(t4,t1,((C_word*)t0)[3]);}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k9876 in k9835 in ##sys#alias-global-hook in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_9878,2,av);}
a=C_alloc(5);
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li132),tmp=(C_word)a,a+=5,tmp);
/* modules.scm:778: g2478 */
t4=t3;
f_9852(t4,((C_word*)t0)[4],t2);}
else{
/* modules.scm:786: mrename */
t3=((C_word*)t0)[3];
f_9803(t3,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* ##sys#validate-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(C_unlikely(!C_demand(C_calculate_demand(22,c,3)))){
C_save_and_reclaim((void *)f_9880,4,av);}
a=C_alloc(22);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9883,a[2]=t3,a[3]=((C_word)li134),tmp=(C_word)a,a+=4,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9889,a[2]=t5,a[3]=t2,a[4]=((C_word)li135),tmp=(C_word)a,a+=5,tmp));
t10=C_eqp(lf[150],t2);
if(C_truep(t10)){
t11=t2;
t12=t1;{
C_word *av2=av;
av2[0]=t12;
av2[1]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
/* modules.scm:796: iface */
t11=((C_word*)t7)[1];
f_9889(t11,t1,t2);}
else{
t11=C_i_listp(t2);
if(C_truep(C_i_not(t11))){
/* modules.scm:798: err */
t12=((C_word*)t5)[1];
f_9883(t12,t1,C_a_i_list(&a,2,lf[151],t2));}
else{
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9930,a[2]=t5,a[3]=t2,a[4]=t13,a[5]=t7,a[6]=((C_word)li137),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_9930(t15,t1,t2);}}}}

/* err in ##sys#validate-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9883(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_9883,3,t0,t1,t2);}{
C_word av2[5];
av2[0]=0;
av2[1]=t1;
av2[2]=*((C_word*)lf[118]+1);
av2[3]=((C_word*)t0)[2];
av2[4]=t2;
C_apply(5,av2);}}

/* iface in ##sys#validate-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9889(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_9889,3,t0,t1,t2);}
a=C_alloc(9);
t3=t2;
t4=C_i_getprop(t3,lf[148],C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
/* modules.scm:794: err */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9883(t5,t1,C_a_i_list(&a,3,lf[149],t2,((C_word*)t0)[3]));}}

/* loop in ##sys#validate-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_fcall f_9930(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(11,0,3)))){
C_save_and_reclaim_args((void *)trf_9930,3,t0,t1,t2);}
a=C_alloc(11);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_pairp(t2);
if(C_truep(C_i_not(t3))){
/* modules.scm:803: err */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9883(t4,t1,C_a_i_list(&a,2,lf[152],((C_word*)t0)[3]));}
else{
t4=C_i_car(t2);
t5=t4;
if(C_truep(C_i_symbolp(t5))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9962,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
/* modules.scm:806: loop */
t15=t6;
t16=t8;
t1=t15;
t2=t16;
goto loop;}
else{
t6=C_i_listp(t5);
if(C_truep(C_i_not(t6))){
/* modules.scm:808: err */
t7=((C_word*)((C_word*)t0)[2])[1];
f_9883(t7,t1,C_a_i_list(&a,3,lf[153],t5,((C_word*)t0)[3]));}
else{
t7=C_i_car(t5);
t8=C_eqp(lf[154],t7);
if(C_truep(t8)){
t9=C_u_i_cdr(t5);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9988,a[2]=t1,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=t2;
t12=C_u_i_cdr(t11);
/* modules.scm:810: loop */
t15=t10;
t16=t12;
t1=t15;
t2=t16;
goto loop;}
else{
t9=C_u_i_car(t5);
t10=C_eqp(lf[155],t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10002,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t12=C_u_i_cdr(t5);
if(C_truep(C_i_pairp(t12))){
t13=C_i_cadr(t5);
t14=t11;
f_10002(t14,C_i_symbolp(t13));}
else{
t13=t11;
f_10002(t13,C_SCHEME_FALSE);}}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10039,a[2]=t5,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t12,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word)li136),tmp=(C_word)a,a+=9,tmp));
t14=((C_word*)t12)[1];
f_10039(t14,t1,t5);}}}}}}}

/* k9960 in loop in ##sys#validate-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_9962,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9986 in loop in ##sys#validate-exports in k5276 in k5272 in k3990 in k3987 in k3984 in k3981 */
static void C_ccall f_9988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_9988,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_modules_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("modules"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void*)C_modules_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(7477))){
C_save(t1);
C_rereclaim2(7477*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,242);
lf[0]=C_h_intern(&lf[0],7, C_text("modules"));
lf[2]=C_h_intern(&lf[2],20, C_text("##sys#current-module"));
lf[3]=C_h_intern(&lf[3],30, C_text("##sys#module-alias-environment"));
lf[4]=C_h_intern(&lf[4],6, C_text("module"));
lf[6]=C_h_intern(&lf[6],11, C_text("module-name"));
lf[7]=C_h_intern(&lf[7],21, C_text("module-undefined-list"));
lf[8]=C_h_intern(&lf[8],26, C_text("set-module-undefined-list!"));
lf[9]=C_h_intern(&lf[9],16, C_text("##sys#block-set!"));
lf[10]=C_h_intern(&lf[10],17, C_text("##sys#module-name"));
lf[11]=C_h_intern(&lf[11],20, C_text("##sys#module-exports"));
lf[12]=C_h_intern(&lf[12],18, C_text("module-export-list"));
lf[13]=C_h_intern(&lf[13],15, C_text("module-vexports"));
lf[14]=C_h_intern(&lf[14],15, C_text("module-sexports"));
lf[15]=C_h_intern(&lf[15],27, C_text("##sys#register-module-alias"));
lf[16]=C_h_intern(&lf[16],25, C_text("##sys#with-module-aliases"));
lf[17]=C_h_intern(&lf[17],18, C_text("##sys#dynamic-wind"));
lf[18]=C_h_intern(&lf[18],3, C_text("map"));
lf[19]=C_h_intern(&lf[19],13, C_text("scheme#append"));
lf[20]=C_h_intern(&lf[20],25, C_text("##sys#resolve-module-name"));
lf[21]=C_h_intern(&lf[21],18, C_text("chicken.base#error"));
lf[22]=C_decode_literal(C_heaptop,C_text("\376B\000\000\035module alias refers to itself"));
lf[23]=C_h_intern(&lf[23],27, C_text("chicken.internal#library-id"));
lf[24]=C_h_intern(&lf[24],17, C_text("##sys#find-module"));
lf[25]=C_h_intern(&lf[25],18, C_text("##sys#module-table"));
lf[26]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020module not found"));
lf[27]=C_h_intern(&lf[27],19, C_text("##sys#switch-module"));
lf[28]=C_h_intern(&lf[28],23, C_text("##sys#macro-environment"));
lf[29]=C_h_intern(&lf[29],25, C_text("##sys#current-environment"));
lf[30]=C_h_intern(&lf[30],25, C_text("module-saved-environments"));
lf[31]=C_h_intern(&lf[31],24, C_text("##sys#add-to-export-list"));
lf[32]=C_h_intern(&lf[32],17, C_text("module-exist-list"));
lf[33]=C_h_intern(&lf[33],8, C_text("for-each"));
lf[34]=C_h_intern(&lf[34],30, C_text("##sys#toplevel-definition-hook"));
lf[35]=C_h_intern(&lf[35],30, C_text("##sys#register-meta-expression"));
lf[36]=C_h_intern(&lf[36],23, C_text("module-meta-expressions"));
lf[38]=C_h_intern(&lf[38],10, C_text("##sys#warn"));
lf[39]=C_decode_literal(C_heaptop,C_text("\376B\000\000\047redefinition of imported syntax binding"));
lf[40]=C_decode_literal(C_heaptop,C_text("\376B\000\000&redefinition of imported value binding"));
lf[41]=C_h_intern(&lf[41],21, C_text("##sys#register-export"));
lf[42]=C_h_intern(&lf[42],19, C_text("module-defined-list"));
lf[43]=C_h_intern(&lf[43],10, C_text("scheme#eq\077"));
lf[46]=C_h_intern(&lf[46],28, C_text("##sys#register-syntax-export"));
lf[47]=C_h_intern(&lf[47],26, C_text("module-defined-syntax-list"));
lf[48]=C_decode_literal(C_heaptop,C_text("\376B\000\000!use of syntax precedes definition"));
lf[49]=C_h_intern(&lf[49],30, C_text("##sys#unregister-syntax-export"));
lf[50]=C_h_intern(&lf[50],21, C_text("##sys#register-module"));
lf[52]=C_h_intern(&lf[52],32, C_text("chicken.internal#hash-table-set!"));
lf[53]=C_h_intern(&lf[53],31, C_text("chicken.internal#hash-table-ref"));
lf[54]=C_h_intern(&lf[54],14, C_text("scheme#reverse"));
lf[55]=C_h_intern(&lf[55],32, C_text("chicken.internal#make-hash-table"));
lf[56]=C_h_intern(&lf[56],34, C_text("##sys#compiled-module-registration"));
lf[57]=C_h_intern(&lf[57],19, C_text("module-import-forms"));
lf[58]=C_h_intern(&lf[58],24, C_text("module-meta-import-forms"));
lf[59]=C_h_intern(&lf[59],12, C_text("##sys#append"));
lf[60]=C_h_intern(&lf[60],5, C_text("quote"));
lf[61]=C_h_intern(&lf[61],14, C_text("module-library"));
lf[62]=C_h_intern(&lf[62],15, C_text("module-iexports"));
lf[63]=C_h_intern(&lf[63],11, C_text("scheme#list"));
lf[64]=C_h_intern(&lf[64],11, C_text("scheme#cons"));
lf[65]=C_h_intern(&lf[65],27, C_text("chicken.syntax#strip-syntax"));
lf[66]=C_h_intern(&lf[66],30, C_text("##sys#register-compiled-module"));
lf[67]=C_h_intern(&lf[67],14, C_text("##core#functor"));
lf[68]=C_h_intern(&lf[68],18, C_text("##sys#fast-reverse"));
lf[69]=C_h_intern(&lf[69],13, C_text("import-syntax"));
lf[70]=C_h_intern(&lf[70],11, C_text("scheme#eval"));
lf[71]=C_h_intern(&lf[71],24, C_text("##sys#ensure-transformer"));
lf[72]=C_h_intern(&lf[72],11, C_text("##sys#error"));
lf[73]=C_h_intern(&lf[73],6, C_text("import"));
lf[74]=C_decode_literal(C_heaptop,C_text("\376B\000\0000cannot find implementation of re-exported syntax"));
lf[75]=C_h_intern(&lf[75],26, C_text("##sys#register-core-module"));
lf[76]=C_decode_literal(C_heaptop,C_text("\376B\000\0002unknown syntax referenced while registering module"));
lf[77]=C_h_intern(&lf[77],31, C_text("##sys#register-primitive-module"));
lf[78]=C_h_intern(&lf[78],21, C_text("##sys#finalize-module"));
lf[79]=C_h_intern(&lf[79],9, C_text("##core#db"));
lf[80]=C_h_intern(&lf[80],30, C_text("chicken.base#get-output-string"));
lf[81]=C_h_intern(&lf[81],14, C_text("scheme#display"));
lf[82]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002)\047"));
lf[83]=C_h_intern(&lf[83],12, C_text("scheme#cadar"));
lf[84]=C_decode_literal(C_heaptop,C_text("\376B\000\000\042\012Warning:    suggesting: `(import "));
lf[85]=C_h_intern(&lf[85],21, C_text("##sys#write-char/port"));
lf[86]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025\012Warning:    (import "));
lf[87]=C_decode_literal(C_heaptop,C_text("\376B\000\000\037\012Warning:    suggesting one of:"));
lf[88]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015\012Warning:    "));
lf[89]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004 in:"));
lf[90]=C_decode_literal(C_heaptop,C_text("\376B\000\000\052reference to possibly unbound identifier `"));
lf[91]=C_h_intern(&lf[91],31, C_text("chicken.base#open-output-string"));
lf[92]=C_decode_literal(C_heaptop,C_text("\376B\000\000$(internal) indirect export not found"));
lf[93]=C_h_intern(&lf[93],20, C_text("scheme#string-append"));
lf[94]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014 in module `"));
lf[95]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\047"));
lf[96]=C_h_intern(&lf[96],21, C_text("scheme#symbol->string"));
lf[97]=C_decode_literal(C_heaptop,C_text("\376B\000\000!indirect export of syntax binding"));
lf[98]=C_decode_literal(C_heaptop,C_text("\376B\000\000\033indirect reexport of syntax"));
lf[99]=C_decode_literal(C_heaptop,C_text("\376B\000\000\042indirect export of unknown binding"));
lf[100]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021module unresolved"));
lf[101]=C_decode_literal(C_heaptop,C_text("\376B\000\000\037exported identifier of module `"));
lf[102]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026\047 has not been defined"));
lf[103]=C_h_intern(&lf[103],25, C_text("##sys#import-library-hook"));
lf[104]=C_h_intern(&lf[104],30, C_text("##sys#current-meta-environment"));
lf[105]=C_h_intern(&lf[105],21, C_text("##sys#notices-enabled"));
lf[106]=C_h_intern(&lf[106],11, C_text("scheme#load"));
lf[107]=C_h_intern(&lf[107],28, C_text("##sys#meta-macro-environment"));
lf[108]=C_h_intern(&lf[108],35, C_text("chicken.load#find-dynamic-extension"));
lf[109]=C_h_intern(&lf[109],19, C_text("##sys#string-append"));
lf[110]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007.import"));
lf[112]=C_h_intern(&lf[112],22, C_text("##sys#decompose-import"));
lf[113]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014 in module `"));
lf[114]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\047"));
lf[115]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001:"));
lf[116]=C_h_intern(&lf[116],20, C_text("##sys#symbol->string"));
lf[117]=C_h_intern(&lf[117],20, C_text("##sys#number->string"));
lf[118]=C_h_intern(&lf[118],23, C_text("##sys#syntax-error-hook"));
lf[119]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016invalid prefix"));
lf[120]=C_h_intern(&lf[120],24, C_text("chicken.keyword#keyword\077"));
lf[121]=C_decode_literal(C_heaptop,C_text("\376B\000\000\034invalid import specification"));
lf[122]=C_decode_literal(C_heaptop,C_text("\376B\000\000!imported identifier doesn\047t exist"));
lf[123]=C_h_intern(&lf[123],18, C_text("##sys#check-syntax"));
lf[124]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\002\376\001\000\000\006\001symbol\376\377\001\000\000\000\000"));
lf[125]=C_decode_literal(C_heaptop,C_text("\376B\000\000!excluded identifier doesn\047t exist"));
lf[126]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\002\376\001\000\000\006\001symbol\376\377\001\000\000\000\000"));
lf[127]=C_decode_literal(C_heaptop,C_text("\376B\000\000 renamed identifier doesn\047t exist"));
lf[128]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006\001symbol\376\003\000\000\002\376\001\000\000\006\001symbol\376\377\016\376\377\001\000\000\000\000"));
lf[129]=C_h_intern(&lf[129],20, C_text("##sys#string->symbol"));
lf[130]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\003\000\000\002\376\001\000\000\001\001_\376\377\016"));
lf[131]=C_h_intern(&lf[131],37, C_text("scheme#call-with-current-continuation"));
lf[132]=C_h_intern(&lf[132],6, C_text("prefix"));
lf[133]=C_h_intern(&lf[133],6, C_text("except"));
lf[134]=C_h_intern(&lf[134],6, C_text("rename"));
lf[135]=C_h_intern(&lf[135],4, C_text("only"));
lf[136]=C_h_intern(&lf[136],19, C_text("##sys#expand-import"));
lf[137]=C_decode_literal(C_heaptop,C_text("\376B\000\000#cannot import from undefined module"));
lf[138]=C_h_intern(&lf[138],12, C_text("##sys#import"));
lf[139]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\020\001##core#undefined\376\377\016"));
lf[140]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001_\376\000\000\000\002\376\001\000\000\001\001_\376\377\001\000\000\000\001"));
lf[141]=C_h_intern(&lf[141],12, C_text("##sys#notice"));
lf[142]=C_decode_literal(C_heaptop,C_text("\376B\000\000(re-importing already imported identifier"));
lf[143]=C_decode_literal(C_heaptop,C_text("\376B\000\000$re-importing already imported syntax"));
lf[144]=C_decode_literal(C_heaptop,C_text("\376B\000\000%`reexport\047 only valid inside a module"));
lf[145]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001#"));
lf[146]=C_h_intern(&lf[146],23, C_text("##sys#alias-global-hook"));
lf[147]=C_h_intern(&lf[147],22, C_text("##sys#validate-exports"));
lf[148]=C_h_intern(&lf[148],16, C_text("##core#interface"));
lf[149]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021unknown interface"));
lf[150]=C_h_intern(&lf[150],1, C_text("\052"));
lf[151]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017invalid exports"));
lf[152]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017invalid exports"));
lf[153]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016invalid export"));
lf[154]=C_h_intern_kw(&lf[154],6, C_text("syntax"));
lf[155]=C_h_intern_kw(&lf[155],9, C_text("interface"));
lf[156]=C_decode_literal(C_heaptop,C_text("\376B\000\000\037invalid interface specification"));
lf[157]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016invalid export"));
lf[158]=C_h_intern(&lf[158],22, C_text("##sys#register-functor"));
lf[159]=C_h_intern(&lf[159],25, C_text("##sys#instantiate-functor"));
lf[160]=C_decode_literal(C_heaptop,C_text("\376B\000\000/argument list mismatch in functor instantiation"));
lf[161]=C_h_intern(&lf[161],13, C_text("##core#module"));
lf[162]=C_h_intern(&lf[162],23, C_text("##core#let-module-alias"));
lf[164]=C_decode_literal(C_heaptop,C_text("\376B\000\000!instantation of undefined functor"));
lf[165]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021argument module `"));
lf[166]=C_decode_literal(C_heaptop,C_text("\376B\000\000$\047 does not match required signature\012"));
lf[167]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022in instantiation `"));
lf[168]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016\047 of functor `"));
lf[169]=C_decode_literal(C_heaptop,C_text("\376B\000\0007\047, because the following required exports are missing:\012"));
lf[170]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003\012  "));
lf[171]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001not\376\001\000\000\012\001scheme#not\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001boolean\077\376\001\000\000\017\001scheme#boolean\077"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001eq\077\376\001\000\000\012\001scheme#eq\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001eqv\077\376\001\000\000\013\001scheme#eqv\077\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006\001equal\077\376\001\000\000\015\001scheme#equal\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001pair\077\376\001\000\000\014\001scheme#pair\077\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\004\001cons\376\001\000\000\013\001scheme#cons\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001car\376\001\000\000\012\001scheme#car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001"
"cdr\376\001\000\000\012\001scheme#cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001caar\376\001\000\000\013\001scheme#caar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001cadr\376\001\000\000"
"\013\001scheme#cadr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001cdar\376\001\000\000\013\001scheme#cdar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001cddr\376\001\000\000\013\001sche"
"me#cddr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001caaar\376\001\000\000\014\001scheme#caaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001caadr\376\001\000\000\014\001scheme#"
"caadr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001cadar\376\001\000\000\014\001scheme#cadar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001caddr\376\001\000\000\014\001scheme#ca"
"ddr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001cdaar\376\001\000\000\014\001scheme#cdaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001cdadr\376\001\000\000\014\001scheme#cdad"
"r\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001cddar\376\001\000\000\014\001scheme#cddar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001cdddr\376\001\000\000\014\001scheme#cdddr\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001caaaar\376\001\000\000\015\001scheme#caaaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001caaadr\376\001\000\000\015\001scheme#caaad"
"r\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001caadar\376\001\000\000\015\001scheme#caadar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001caaddr\376\001\000\000\015\001scheme#caa"
"ddr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001cadaar\376\001\000\000\015\001scheme#cadaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001cadadr\376\001\000\000\015\001scheme#c"
"adadr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001caddar\376\001\000\000\015\001scheme#caddar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001cadddr\376\001\000\000\015\001scheme"
"#cadddr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001cdaaar\376\001\000\000\015\001scheme#cdaaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001cdaadr\376\001\000\000\015\001sche"
"me#cdaadr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001cdadar\376\001\000\000\015\001scheme#cdadar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001cdaddr\376\001\000\000\015\001sc"
"heme#cdaddr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001cddaar\376\001\000\000\015\001scheme#cddaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001cddadr\376\001\000\000\015\001"
"scheme#cddadr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001cdddar\376\001\000\000\015\001scheme#cdddar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001cddddr\376\001\000\000"
"\015\001scheme#cddddr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001set-car!\376\001\000\000\017\001scheme#set-car!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001set-"
"cdr!\376\001\000\000\017\001scheme#set-cdr!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001null\077\376\001\000\000\014\001scheme#null\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001"
"list\077\376\001\000\000\014\001scheme#list\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001list\376\001\000\000\013\001scheme#list\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001leng"
"th\376\001\000\000\015\001scheme#length\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001list-tail\376\001\000\000\020\001scheme#list-tail\376\003\000\000\002\376\003\000\000\002\376\001"
"\000\000\010\001list-ref\376\001\000\000\017\001scheme#list-ref\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001append\376\001\000\000\015\001scheme#append\376\003\000\000\002\376"
"\003\000\000\002\376\001\000\000\007\001reverse\376\001\000\000\016\001scheme#reverse\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001memq\376\001\000\000\013\001scheme#memq\376\003\000\000\002\376"
"\003\000\000\002\376\001\000\000\004\001memv\376\001\000\000\013\001scheme#memv\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001member\376\001\000\000\015\001scheme#member\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\004\001assq\376\001\000\000\013\001scheme#assq\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001assv\376\001\000\000\013\001scheme#assv\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\005\001assoc\376\001\000\000\014\001scheme#assoc\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001symbol\077\376\001\000\000\016\001scheme#symbol\077\376\003\000\000\002\376\003\000\000\002\376\001"
"\000\000\016\001symbol->string\376\001\000\000\025\001scheme#symbol->string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001string->symbol\376\001\000\000\025"
"\001scheme#string->symbol\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001number\077\376\001\000\000\016\001scheme#number\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010"
"\001integer\077\376\001\000\000\017\001scheme#integer\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001exact\077\376\001\000\000\015\001scheme#exact\077\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\005\001real\077\376\001\000\000\014\001scheme#real\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001complex\077\376\001\000\000\017\001scheme#complex\077\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\010\001inexact\077\376\001\000\000\017\001scheme#inexact\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001rational\077\376\001\000\000\020\001scheme#ra"
"tional\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001zero\077\376\001\000\000\014\001scheme#zero\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001odd\077\376\001\000\000\013\001scheme#o"
"dd\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001even\077\376\001\000\000\014\001scheme#even\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001positive\077\376\001\000\000\020\001scheme#"
"positive\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001negative\077\376\001\000\000\020\001scheme#negative\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001max\376\001\000\000\012"
"\001scheme#max\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001min\376\001\000\000\012\001scheme#min\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001\001+\376\001\000\000\010\001scheme#+\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\001\001-\376\001\000\000\010\001scheme#-\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001\001\052\376\001\000\000\010\001scheme#\052\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001\001/\376\001\000\000"
"\010\001scheme#/\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001\001=\376\001\000\000\010\001scheme#=\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001\001>\376\001\000\000\010\001scheme#>\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\001\001<\376\001\000\000\010\001scheme#<\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001>=\376\001\000\000\011\001scheme#>=\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002\001<=\376\001\000\000\011\001"
"scheme#<=\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001quotient\376\001\000\000\017\001scheme#quotient\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001remainder\376"
"\001\000\000\020\001scheme#remainder\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001modulo\376\001\000\000\015\001scheme#modulo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001gc"
"d\376\001\000\000\012\001scheme#gcd\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001lcm\376\001\000\000\012\001scheme#lcm\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001abs\376\001\000\000\012\001sch"
"eme#abs\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001floor\376\001\000\000\014\001scheme#floor\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001ceiling\376\001\000\000\016\001schem"
"e#ceiling\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001truncate\376\001\000\000\017\001scheme#truncate\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001round\376\001\000\000\014"
"\001scheme#round\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001rationalize\376\001\000\000\022\001scheme#rationalize\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001"
"exact->inexact\376\001\000\000\025\001scheme#exact->inexact\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001inexact->exact\376\001\000\000\025\001sch"
"eme#inexact->exact\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001exp\376\001\000\000\012\001scheme#exp\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001log\376\001\000\000\012\001sc"
"heme#log\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001expt\376\001\000\000\013\001scheme#expt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001sqrt\376\001\000\000\013\001scheme#sq"
"rt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001sin\376\001\000\000\012\001scheme#sin\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001cos\376\001\000\000\012\001scheme#cos\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\003\001tan\376\001\000\000\012\001scheme#tan\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001asin\376\001\000\000\013\001scheme#asin\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001"
"acos\376\001\000\000\013\001scheme#acos\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001atan\376\001\000\000\013\001scheme#atan\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001number"
"->string\376\001\000\000\025\001scheme#number->string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001string->number\376\001\000\000\025\001scheme#st"
"ring->number\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001char\077\376\001\000\000\014\001scheme#char\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001char=\077\376\001\000\000\015\001s"
"cheme#char=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001char>\077\376\001\000\000\015\001scheme#char>\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001char<\077\376\001\000\000\015"
"\001scheme#char<\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001char>=\077\376\001\000\000\016\001scheme#char>=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001char<=\077"
"\376\001\000\000\016\001scheme#char<=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001char-ci=\077\376\001\000\000\020\001scheme#char-ci=\077\376\003\000\000\002\376\003\000\000\002\376\001\000"
"\000\011\001char-ci<\077\376\001\000\000\020\001scheme#char-ci<\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001char-ci>\077\376\001\000\000\020\001scheme#char-ci>"
"\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\001char-ci>=\077\376\001\000\000\021\001scheme#char-ci>=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\001char-ci<=\077\376\001\000\000"
"\021\001scheme#char-ci<=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001char-alphabetic\077\376\001\000\000\027\001scheme#char-alphabetic\077"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001char-whitespace\077\376\001\000\000\027\001scheme#char-whitespace\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015\001cha"
"r-numeric\077\376\001\000\000\024\001scheme#char-numeric\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001char-upper-case\077\376\001\000\000\027\001scheme"
"#char-upper-case\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001char-lower-case\077\376\001\000\000\027\001scheme#char-lower-case\077\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\013\001char-upcase\376\001\000\000\022\001scheme#char-upcase\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015\001char-downcase\376\001"
"\000\000\024\001scheme#char-downcase\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015\001char->integer\376\001\000\000\024\001scheme#char->integer\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\015\001integer->char\376\001\000\000\024\001scheme#integer->char\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001string\077\376\001\000"
"\000\016\001scheme#string\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001string=\077\376\001\000\000\017\001scheme#string=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001st"
"ring>\077\376\001\000\000\017\001scheme#string>\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001string<\077\376\001\000\000\017\001scheme#string<\077\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\011\001string>=\077\376\001\000\000\020\001scheme#string>=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001string<=\077\376\001\000\000\020\001scheme#str"
"ing<=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001string-ci=\077\376\001\000\000\022\001scheme#string-ci=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001string-"
"ci<\077\376\001\000\000\022\001scheme#string-ci<\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001string-ci>\077\376\001\000\000\022\001scheme#string-ci>\077\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001string-ci>=\077\376\001\000\000\023\001scheme#string-ci>=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001string-ci<=\077"
"\376\001\000\000\023\001scheme#string-ci<=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001make-string\376\001\000\000\022\001scheme#make-string\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\015\001string-length\376\001\000\000\024\001scheme#string-length\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\001string-ref\376\001\000"
"\000\021\001scheme#string-ref\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001string-set!\376\001\000\000\022\001scheme#string-set!\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\015\001string-append\376\001\000\000\024\001scheme#string-append\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001string-copy\376\001\000\000\022\001s"
"cheme#string-copy\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001string->list\376\001\000\000\023\001scheme#string->list\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\014\001list->string\376\001\000\000\023\001scheme#list->string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001substring\376\001\000\000\020\001scheme"
"#substring\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001string-fill!\376\001\000\000\023\001scheme#string-fill!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001v"
"ector\077\376\001\000\000\016\001scheme#vector\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001make-vector\376\001\000\000\022\001scheme#make-vector\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\012\001vector-ref\376\001\000\000\021\001scheme#vector-ref\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001vector-set!\376\001\000\000\022\001s"
"cheme#vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001string\376\001\000\000\015\001scheme#string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001vector"
"\376\001\000\000\015\001scheme#vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015\001vector-length\376\001\000\000\024\001scheme#vector-length\376\003\000\000\002\376"
"\003\000\000\002\376\001\000\000\014\001vector->list\376\001\000\000\023\001scheme#vector->list\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001list->vector\376\001\000\000\023"
"\001scheme#list->vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001vector-fill!\376\001\000\000\023\001scheme#vector-fill!\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\012\001procedure\077\376\001\000\000\021\001scheme#procedure\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003\001map\376\001\000\000\012\001scheme#map\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\010\001for-each\376\001\000\000\017\001scheme#for-each\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001apply\376\001\000\000\014\001scheme#appl"
"y\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001force\376\001\000\000\014\001scheme#force\376\003\000\000\002\376\003\000\000\002\376\001\000\000\036\001call-with-current-contin"
"uation\376\001\000\000%\001scheme#call-with-current-continuation\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001input-port\077\376\001\000\000"
"\022\001scheme#input-port\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001output-port\077\376\001\000\000\023\001scheme#output-port\077\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\022\001current-input-port\376\001\000\000\031\001scheme#current-input-port\376\003\000\000\002\376\003\000\000\002\376\001\000\000\023\001curren"
"t-output-port\376\001\000\000\032\001scheme#current-output-port\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024\001call-with-input-fil"
"e\376\001\000\000\033\001scheme#call-with-input-file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025\001call-with-output-file\376\001\000\000\034\001sch"
"eme#call-with-output-file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017\001open-input-file\376\001\000\000\026\001scheme#open-input-"
"file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001open-output-file\376\001\000\000\027\001scheme#open-output-file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020"
"\001close-input-port\376\001\000\000\027\001scheme#close-input-port\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021\001close-output-port\376"
"\001\000\000\030\001scheme#close-output-port\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001load\376\001\000\000\013\001scheme#load\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\004\001read\376\001\000\000\013\001scheme#read\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001read-char\376\001\000\000\020\001scheme#read-char\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\011\001peek-char\376\001\000\000\020\001scheme#peek-char\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001write\376\001\000\000\014\001scheme#write\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\007\001display\376\001\000\000\016\001scheme#display\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\001write-char\376\001\000\000\021\001scheme#wr"
"ite-char\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001newline\376\001\000\000\016\001scheme#newline\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001eof-object\077\376\001"
"\000\000\022\001scheme#eof-object\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024\001with-input-from-file\376\001\000\000\033\001scheme#with-inpu"
"t-from-file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\023\001with-output-to-file\376\001\000\000\032\001scheme#with-output-to-file\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\013\001char-ready\077\376\001\000\000\022\001scheme#char-ready\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001imag-part\376\001\000\000\020\001"
"scheme#imag-part\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001real-part\376\001\000\000\020\001scheme#real-part\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001m"
"ake-rectangular\376\001\000\000\027\001scheme#make-rectangular\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\001make-polar\376\001\000\000\021\001sche"
"me#make-polar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001angle\376\001\000\000\014\001scheme#angle\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001magnitude\376\001\000"
"\000\020\001scheme#magnitude\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001numerator\376\001\000\000\020\001scheme#numerator\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\013\001denominator\376\001\000\000\022\001scheme#denominator\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\001scheme-report-environment\376\001"
"\000\000 \001scheme#scheme-report-environment\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001null-environment\376\001\000\000\027\001scheme"
"#null-environment\376\003\000\000\002\376\003\000\000\002\376\001\000\000\027\001interaction-environment\376\001\000\000\036\001scheme#interaction"
"-environment\376\377\016"));
lf[172]=C_h_intern(&lf[172],30, C_text("##sys#scheme-macro-environment"));
lf[173]=C_h_intern(&lf[173],33, C_text("chicken.module#module-environment"));
lf[174]=C_h_intern(&lf[174],18, C_text("module-environment"));
lf[175]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020undefined module"));
lf[176]=C_h_intern(&lf[176],11, C_text("environment"));
lf[177]=C_h_intern(&lf[177],14, C_text("chicken.syntax"));
lf[178]=C_h_intern(&lf[178],6, C_text("expand"));
lf[179]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001expand\376\001\000\000\025\001chicken.syntax#expand\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017\001get-line-number"
"\376\001\000\000\036\001chicken.syntax#get-line-number\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001strip-syntax\376\001\000\000\033\001chicken.sy"
"ntax#strip-syntax\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001syntax-error\376\001\000\000\033\001chicken.syntax#syntax-error\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\024\001er-macro-transformer\376\001\000\000#\001chicken.syntax#er-macro-transformer\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\024\001ir-macro-transformer\376\001\000\000#\001chicken.syntax#ir-macro-transformer\376\377\016"));
lf[180]=C_h_intern(&lf[180],38, C_text("##sys#chicken.syntax-macro-environment"));
lf[181]=C_h_intern(&lf[181],12, C_text("chicken.base"));
lf[182]=C_h_intern(&lf[182],7, C_text("library"));
lf[183]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001add1\376\001\000\000\021\001chicken.base#add1\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001alist-ref\376\001\000\000\026\001chicke"
"n.base#alist-ref\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001alist-update\376\001\000\000\031\001chicken.base#alist-update\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\015\001alist-update!\376\001\000\000\032\001chicken.base#alist-update!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001atom\077\376\001\000"
"\000\022\001chicken.base#atom\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001bignum\077\376\001\000\000\024\001chicken.base#bignum\077\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\007\001butlast\376\001\000\000\024\001chicken.base#butlast\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001call/cc\376\001\000\000\024\001chicken.base"
"#call/cc\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001case-sensitive\376\001\000\000\033\001chicken.base#case-sensitive\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\011\001char-name\376\001\000\000\026\001chicken.base#char-name\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001chop\376\001\000\000\021\001chicken.ba"
"se#chop\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\001complement\376\001\000\000\027\001chicken.base#complement\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001co"
"mpose\376\001\000\000\024\001chicken.base#compose\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001compress\376\001\000\000\025\001chicken.base#compre"
"ss\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001conjoin\376\001\000\000\024\001chicken.base#conjoin\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\001constantly\376\001\000"
"\000\027\001chicken.base#constantly\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001cplxnum\077\376\001\000\000\025\001chicken.base#cplxnum\077\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\022\001current-error-port\376\001\000\000\037\001chicken.base#current-error-port\376\003\000\000\002\376\003\000\000\002\376\001"
"\000\000\007\001disjoin\376\001\000\000\024\001chicken.base#disjoin\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001each\376\001\000\000\021\001chicken.base#each"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001emergency-exit\376\001\000\000\033\001chicken.base#emergency-exit\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017\001e"
"nable-warnings\376\001\000\000\034\001chicken.base#enable-warnings\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001equal=\077\376\001\000\000\024\001chi"
"cken.base#equal=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001error\376\001\000\000\022\001chicken.base#error\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001ex"
"act-integer\077\376\001\000\000\033\001chicken.base#exact-integer\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\026\001exact-integer-nth-r"
"oot\376\001\000\000#\001chicken.base#exact-integer-nth-root\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022\001exact-integer-sqrt\376\001"
"\000\000\037\001chicken.base#exact-integer-sqrt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001exit\376\001\000\000\021\001chicken.base#exit\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014\001exit-handler\376\001\000\000\031\001chicken.base#exit-handler\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001finite\077"
"\376\001\000\000\024\001chicken.base#finite\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001fixnum\077\376\001\000\000\024\001chicken.base#fixnum\077\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\007\001flatten\376\001\000\000\024\001chicken.base#flatten\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001flip\376\001\000\000\021\001chicken.ba"
"se#flip\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001flonum\077\376\001\000\000\024\001chicken.base#flonum\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001flush-ou"
"tput\376\001\000\000\031\001chicken.base#flush-output\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001foldl\376\001\000\000\022\001chicken.base#foldl"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001foldr\376\001\000\000\022\001chicken.base#foldr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001gensym\376\001\000\000\023\001chicken"
".base#gensym\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001get-call-chain\376\001\000\000\033\001chicken.base#get-call-chain\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\021\001get-output-string\376\001\000\000\036\001chicken.base#get-output-string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022\001"
"getter-with-setter\376\001\000\000\037\001chicken.base#getter-with-setter\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001identity\376"
"\001\000\000\025\001chicken.base#identity\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025\001implicit-exit-handler\376\001\000\000\042\001chicken.bas"
"e#implicit-exit-handler\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001infinite\077\376\001\000\000\026\001chicken.base#infinite\077\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\020\001input-port-open\077\376\001\000\000\035\001chicken.base#input-port-open\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001i"
"ntersperse\376\001\000\000\030\001chicken.base#intersperse\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001join\376\001\000\000\021\001chicken.base#j"
"oin\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015\001keyword-style\376\001\000\000\032\001chicken.base#keyword-style\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001"
"list-of\077\376\001\000\000\025\001chicken.base#list-of\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001make-parameter\376\001\000\000\033\001chicken.b"
"ase#make-parameter\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001make-promise\376\001\000\000\031\001chicken.base#make-promise\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\004\001nan\077\376\001\000\000\021\001chicken.base#nan\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001notice\376\001\000\000\023\001chicken.base"
"#notice\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001\001o\376\001\000\000\016\001chicken.base#o\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001on-exit\376\001\000\000\024\001chicken"
".base#on-exit\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021\001open-input-string\376\001\000\000\036\001chicken.base#open-input-stri"
"ng\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022\001open-output-string\376\001\000\000\037\001chicken.base#open-output-string\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\021\001output-port-open\077\376\001\000\000\036\001chicken.base#output-port-open\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024\001pa"
"rentheses-synonyms\376\001\000\000!\001chicken.base#parentheses-synonyms\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001port\077\376\001"
"\000\000\022\001chicken.base#port\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001port-closed\077\376\001\000\000\031\001chicken.base#port-closed"
"\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001print-call-chain\376\001\000\000\035\001chicken.base#print-call-chain\376\003\000\000\002\376\003\000\000\002\376\001"
"\000\000\005\001print\376\001\000\000\022\001chicken.base#print\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001print\052\376\001\000\000\023\001chicken.base#print\052"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025\001procedure-information\376\001\000\000\042\001chicken.base#procedure-information\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\010\001promise\077\376\001\000\000\025\001chicken.base#promise\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017\001quotient&modulo\376"
"\001\000\000\034\001chicken.base#quotient&modulo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022\001quotient&remainder\376\001\000\000\037\001chicken"
".base#quotient&remainder\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001rassoc\376\001\000\000\023\001chicken.base#rassoc\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\007\001ratnum\077\376\001\000\000\024\001chicken.base#ratnum\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001setter\376\001\000\000\023\001chicken.base"
"#setter\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001signum\376\001\000\000\023\001chicken.base#signum\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001sleep\376\001\000\000\022"
"\001chicken.base#sleep\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\001string->uninterned-symbol\376\001\000\000&\001chicken.base#s"
"tring->uninterned-symbol\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001sub1\376\001\000\000\021\001chicken.base#sub1\376\003\000\000\002\376\003\000\000\002\376\001\000"
"\000\011\001subvector\376\001\000\000\026\001chicken.base#subvector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015\001symbol-append\376\001\000\000\032\001chick"
"en.base#symbol-append\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015\001symbol-escape\376\001\000\000\032\001chicken.base#symbol-esca"
"pe\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001tail\077\376\001\000\000\022\001chicken.base#tail\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001vector-copy!\376\001\000\000\031"
"\001chicken.base#vector-copy!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015\001vector-resize\376\001\000\000\032\001chicken.base#vector"
"-resize\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001void\376\001\000\000\021\001chicken.base#void\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001warning\376\001\000\000\024\001c"
"hicken.base#warning\376\377\016"));
lf[184]=C_h_intern(&lf[184],36, C_text("##sys#chicken.base-macro-environment"));
lf[185]=C_h_intern(&lf[185],7, C_text("srfi-98"));
lf[186]=C_h_intern(&lf[186],5, C_text("posix"));
lf[187]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\030\001get-environment-variable\376\001\000\0000\001chicken.process-context#get-enviro"
"nment-variable\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\001get-environment-variables\376\001\000\0001\001chicken.process-con"
"text#get-environment-variables\376\377\016"));
lf[188]=C_h_intern(&lf[188],7, C_text("srfi-55"));
lf[189]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\021\001require-extension\376\377\016"));
lf[190]=C_h_intern(&lf[190],7, C_text("srfi-39"));
lf[191]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001make-parameter\376\001\000\000\033\001chicken.base#make-parameter\376\377\016"));
lf[192]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\014\001parameterize\376\377\016"));
lf[193]=C_h_intern(&lf[193],7, C_text("srfi-31"));
lf[194]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\003\001rec\376\377\016"));
lf[195]=C_h_intern(&lf[195],7, C_text("srfi-28"));
lf[196]=C_h_intern(&lf[196],6, C_text("extras"));
lf[197]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001format\376\001\000\000\025\001chicken.format#format\376\377\016"));
lf[198]=C_h_intern(&lf[198],7, C_text("srfi-26"));
lf[199]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\003\001cut\376\003\000\000\002\376\001\000\000\004\001cute\376\377\016"));
lf[200]=C_h_intern(&lf[200],7, C_text("srfi-23"));
lf[201]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001error\376\001\000\000\022\001chicken.base#error\376\377\016"));
lf[202]=C_h_intern(&lf[202],7, C_text("srfi-17"));
lf[203]=C_h_intern(&lf[203],31, C_text("##sys#default-macro-environment"));
lf[204]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\004\001set!\376\377\016"));
lf[205]=C_h_intern(&lf[205],7, C_text("srfi-16"));
lf[206]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\013\001case-lambda\376\377\016"));
lf[207]=C_h_intern(&lf[207],7, C_text("srfi-15"));
lf[208]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\011\001fluid-let\376\377\016"));
lf[209]=C_h_intern(&lf[209],7, C_text("srfi-12"));
lf[210]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005\001abort\376\001\000\000\027\001chicken.condition#abort\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\001condition\077\376\001\000\000"
"\034\001chicken.condition#condition\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\023\001condition-predicate\376\001\000\000%\001chicken.c"
"ondition#condition-predicate\376\003\000\000\002\376\003\000\000\002\376\001\000\000\033\001condition-property-accessor\376\001\000\000-\001chi"
"cken.condition#condition-property-accessor\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\001current-exception-hand"
"ler\376\001\000\000+\001chicken.condition#current-exception-handler\376\003\000\000\002\376\003\000\000\002\376\001\000\000\030\001make-composi"
"te-condition\376\001\000\000\052\001chicken.condition#make-composite-condition\376\003\000\000\002\376\003\000\000\002\376\001\000\000\027\001make"
"-property-condition\376\001\000\000)\001chicken.condition#make-property-condition\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\006\001signal\376\001\000\000\030\001chicken.condition#signal\376\003\000\000\002\376\003\000\000\002\376\001\000\000\026\001with-exception-handler\376\001\000\000"
"(\001chicken.condition#with-exception-handler\376\377\016"));
lf[211]=C_h_intern(&lf[211],41, C_text("##sys#chicken.condition-macro-environment"));
lf[212]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\021\001handle-exceptions\376\377\016"));
lf[213]=C_h_intern(&lf[213],7, C_text("srfi-11"));
lf[214]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\012\001let-values\376\003\000\000\002\376\001\000\000\013\001let\052-values\376\377\016"));
lf[215]=C_h_intern(&lf[215],7, C_text("srfi-10"));
lf[216]=C_h_intern(&lf[216],11, C_text("read-syntax"));
lf[217]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022\001define-reader-ctor\376\001\000\000&\001chicken.read-syntax#define-reader-ctor\376\377"
"\016"));
lf[218]=C_h_intern(&lf[218],6, C_text("srfi-9"));
lf[219]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\022\001define-record-type\376\377\016"));
lf[220]=C_h_intern(&lf[220],6, C_text("srfi-8"));
lf[221]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\007\001receive\376\377\016"));
lf[222]=C_h_intern(&lf[222],6, C_text("srfi-6"));
lf[223]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021\001get-output-string\376\001\000\000\036\001chicken.base#get-output-string\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\021\001open-input-string\376\001\000\000\036\001chicken.base#open-input-string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022\001open-o"
"utput-string\376\001\000\000\036\001chicken.base#open-input-string\376\377\016"));
lf[224]=C_h_intern(&lf[224],6, C_text("srfi-2"));
lf[225]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\010\001and-let\052\376\377\016"));
lf[226]=C_h_intern(&lf[226],6, C_text("srfi-0"));
lf[227]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\013\001cond-expand\376\377\016"));
lf[228]=C_h_intern(&lf[228],12, C_text("chicken.type"));
lf[229]=C_h_intern(&lf[229],36, C_text("##sys#chicken.type-macro-environment"));
lf[230]=C_h_intern(&lf[230],14, C_text("chicken.module"));
lf[231]=C_h_intern(&lf[231],38, C_text("##sys#chicken.module-macro-environment"));
lf[232]=C_h_intern(&lf[232],23, C_text("chicken.internal.syntax"));
lf[233]=C_h_intern(&lf[233],7, C_text("srfi-88"));
lf[234]=C_h_intern(&lf[234],15, C_text("chicken.keyword"));
lf[235]=C_h_intern(&lf[235],4, C_text("r5rs"));
lf[236]=C_h_intern(&lf[236],6, C_text("scheme"));
lf[237]=C_h_intern(&lf[237],9, C_text("r5rs-null"));
lf[238]=C_h_intern(&lf[238],9, C_text("r4rs-null"));
lf[239]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001dynamic-wind\376\001\000\000\023\001scheme#dynamic-wind\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001eval\376\001\000\000\013\001s"
"cheme#eval\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001values\376\001\000\000\015\001scheme#values\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001call-with-val"
"ues\376\001\000\000\027\001scheme#call-with-values\376\377\016"));
lf[240]=C_h_intern(&lf[240],4, C_text("r4rs"));
lf[241]=C_h_intern(&lf[241],27, C_text("chicken.base#make-parameter"));
C_register_lf2(lf,242,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3983,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[534] = {
{C_text("f11852:modules_2escm"),(void*)f11852},
{C_text("f_10002:modules_2escm"),(void*)f_10002},
{C_text("f_10009:modules_2escm"),(void*)f_10009},
{C_text("f_10013:modules_2escm"),(void*)f_10013},
{C_text("f_10039:modules_2escm"),(void*)f_10039},
{C_text("f_10053:modules_2escm"),(void*)f_10053},
{C_text("f_10095:modules_2escm"),(void*)f_10095},
{C_text("f_10111:modules_2escm"),(void*)f_10111},
{C_text("f_10119:modules_2escm"),(void*)f_10119},
{C_text("f_10126:modules_2escm"),(void*)f_10126},
{C_text("f_10136:modules_2escm"),(void*)f_10136},
{C_text("f_10158:modules_2escm"),(void*)f_10158},
{C_text("f_10160:modules_2escm"),(void*)f_10160},
{C_text("f_10199:modules_2escm"),(void*)f_10199},
{C_text("f_10220:modules_2escm"),(void*)f_10220},
{C_text("f_10232:modules_2escm"),(void*)f_10232},
{C_text("f_10255:modules_2escm"),(void*)f_10255},
{C_text("f_10258:modules_2escm"),(void*)f_10258},
{C_text("f_10269:modules_2escm"),(void*)f_10269},
{C_text("f_10275:modules_2escm"),(void*)f_10275},
{C_text("f_10307:modules_2escm"),(void*)f_10307},
{C_text("f_10310:modules_2escm"),(void*)f_10310},
{C_text("f_10321:modules_2escm"),(void*)f_10321},
{C_text("f_10337:modules_2escm"),(void*)f_10337},
{C_text("f_10341:modules_2escm"),(void*)f_10341},
{C_text("f_10348:modules_2escm"),(void*)f_10348},
{C_text("f_10361:modules_2escm"),(void*)f_10361},
{C_text("f_10388:modules_2escm"),(void*)f_10388},
{C_text("f_10401:modules_2escm"),(void*)f_10401},
{C_text("f_10405:modules_2escm"),(void*)f_10405},
{C_text("f_10409:modules_2escm"),(void*)f_10409},
{C_text("f_10413:modules_2escm"),(void*)f_10413},
{C_text("f_10427:modules_2escm"),(void*)f_10427},
{C_text("f_10433:modules_2escm"),(void*)f_10433},
{C_text("f_10435:modules_2escm"),(void*)f_10435},
{C_text("f_10460:modules_2escm"),(void*)f_10460},
{C_text("f_10469:modules_2escm"),(void*)f_10469},
{C_text("f_10479:modules_2escm"),(void*)f_10479},
{C_text("f_10494:modules_2escm"),(void*)f_10494},
{C_text("f_10497:modules_2escm"),(void*)f_10497},
{C_text("f_10500:modules_2escm"),(void*)f_10500},
{C_text("f_10503:modules_2escm"),(void*)f_10503},
{C_text("f_10506:modules_2escm"),(void*)f_10506},
{C_text("f_10509:modules_2escm"),(void*)f_10509},
{C_text("f_10512:modules_2escm"),(void*)f_10512},
{C_text("f_10515:modules_2escm"),(void*)f_10515},
{C_text("f_10518:modules_2escm"),(void*)f_10518},
{C_text("f_10521:modules_2escm"),(void*)f_10521},
{C_text("f_10524:modules_2escm"),(void*)f_10524},
{C_text("f_10527:modules_2escm"),(void*)f_10527},
{C_text("f_10530:modules_2escm"),(void*)f_10530},
{C_text("f_10533:modules_2escm"),(void*)f_10533},
{C_text("f_10536:modules_2escm"),(void*)f_10536},
{C_text("f_10539:modules_2escm"),(void*)f_10539},
{C_text("f_10542:modules_2escm"),(void*)f_10542},
{C_text("f_10545:modules_2escm"),(void*)f_10545},
{C_text("f_10548:modules_2escm"),(void*)f_10548},
{C_text("f_10551:modules_2escm"),(void*)f_10551},
{C_text("f_10554:modules_2escm"),(void*)f_10554},
{C_text("f_10557:modules_2escm"),(void*)f_10557},
{C_text("f_10560:modules_2escm"),(void*)f_10560},
{C_text("f_10563:modules_2escm"),(void*)f_10563},
{C_text("f_10566:modules_2escm"),(void*)f_10566},
{C_text("f_10569:modules_2escm"),(void*)f_10569},
{C_text("f_10572:modules_2escm"),(void*)f_10572},
{C_text("f_10575:modules_2escm"),(void*)f_10575},
{C_text("f_10577:modules_2escm"),(void*)f_10577},
{C_text("f_10584:modules_2escm"),(void*)f_10584},
{C_text("f_10613:modules_2escm"),(void*)f_10613},
{C_text("f_10616:modules_2escm"),(void*)f_10616},
{C_text("f_10623:modules_2escm"),(void*)f_10623},
{C_text("f_10635:modules_2escm"),(void*)f_10635},
{C_text("f_10670:modules_2escm"),(void*)f_10670},
{C_text("f_10677:modules_2escm"),(void*)f_10677},
{C_text("f_10689:modules_2escm"),(void*)f_10689},
{C_text("f_10724:modules_2escm"),(void*)f_10724},
{C_text("f_10731:modules_2escm"),(void*)f_10731},
{C_text("f_10743:modules_2escm"),(void*)f_10743},
{C_text("f_10778:modules_2escm"),(void*)f_10778},
{C_text("f_10785:modules_2escm"),(void*)f_10785},
{C_text("f_10797:modules_2escm"),(void*)f_10797},
{C_text("f_10832:modules_2escm"),(void*)f_10832},
{C_text("f_10839:modules_2escm"),(void*)f_10839},
{C_text("f_10851:modules_2escm"),(void*)f_10851},
{C_text("f_10886:modules_2escm"),(void*)f_10886},
{C_text("f_10893:modules_2escm"),(void*)f_10893},
{C_text("f_10905:modules_2escm"),(void*)f_10905},
{C_text("f_10940:modules_2escm"),(void*)f_10940},
{C_text("f_10947:modules_2escm"),(void*)f_10947},
{C_text("f_10959:modules_2escm"),(void*)f_10959},
{C_text("f_10994:modules_2escm"),(void*)f_10994},
{C_text("f_11001:modules_2escm"),(void*)f_11001},
{C_text("f_11013:modules_2escm"),(void*)f_11013},
{C_text("f_11048:modules_2escm"),(void*)f_11048},
{C_text("f_11055:modules_2escm"),(void*)f_11055},
{C_text("f_11067:modules_2escm"),(void*)f_11067},
{C_text("f_11102:modules_2escm"),(void*)f_11102},
{C_text("f_11109:modules_2escm"),(void*)f_11109},
{C_text("f_11121:modules_2escm"),(void*)f_11121},
{C_text("f_11156:modules_2escm"),(void*)f_11156},
{C_text("f_11163:modules_2escm"),(void*)f_11163},
{C_text("f_11175:modules_2escm"),(void*)f_11175},
{C_text("f_11210:modules_2escm"),(void*)f_11210},
{C_text("f_11217:modules_2escm"),(void*)f_11217},
{C_text("f_11229:modules_2escm"),(void*)f_11229},
{C_text("f_11264:modules_2escm"),(void*)f_11264},
{C_text("f_11271:modules_2escm"),(void*)f_11271},
{C_text("f_11283:modules_2escm"),(void*)f_11283},
{C_text("f_11318:modules_2escm"),(void*)f_11318},
{C_text("f_11322:modules_2escm"),(void*)f_11322},
{C_text("f_11326:modules_2escm"),(void*)f_11326},
{C_text("f_3983:modules_2escm"),(void*)f_3983},
{C_text("f_3986:modules_2escm"),(void*)f_3986},
{C_text("f_3989:modules_2escm"),(void*)f_3989},
{C_text("f_3992:modules_2escm"),(void*)f_3992},
{C_text("f_4483:modules_2escm"),(void*)f_4483},
{C_text("f_4489:modules_2escm"),(void*)f_4489},
{C_text("f_4502:modules_2escm"),(void*)f_4502},
{C_text("f_4516:modules_2escm"),(void*)f_4516},
{C_text("f_5274:modules_2escm"),(void*)f_5274},
{C_text("f_5278:modules_2escm"),(void*)f_5278},
{C_text("f_5293:modules_2escm"),(void*)f_5293},
{C_text("f_5383:modules_2escm"),(void*)f_5383},
{C_text("f_5392:modules_2escm"),(void*)f_5392},
{C_text("f_5528:modules_2escm"),(void*)f_5528},
{C_text("f_5552:modules_2escm"),(void*)f_5552},
{C_text("f_5568:modules_2escm"),(void*)f_5568},
{C_text("f_5570:modules_2escm"),(void*)f_5570},
{C_text("f_5574:modules_2escm"),(void*)f_5574},
{C_text("f_5579:modules_2escm"),(void*)f_5579},
{C_text("f_5583:modules_2escm"),(void*)f_5583},
{C_text("f_5587:modules_2escm"),(void*)f_5587},
{C_text("f_5590:modules_2escm"),(void*)f_5590},
{C_text("f_5596:modules_2escm"),(void*)f_5596},
{C_text("f_5602:modules_2escm"),(void*)f_5602},
{C_text("f_5606:modules_2escm"),(void*)f_5606},
{C_text("f_5609:modules_2escm"),(void*)f_5609},
{C_text("f_5633:modules_2escm"),(void*)f_5633},
{C_text("f_5637:modules_2escm"),(void*)f_5637},
{C_text("f_5639:modules_2escm"),(void*)f_5639},
{C_text("f_5673:modules_2escm"),(void*)f_5673},
{C_text("f_5681:modules_2escm"),(void*)f_5681},
{C_text("f_5683:modules_2escm"),(void*)f_5683},
{C_text("f_5691:modules_2escm"),(void*)f_5691},
{C_text("f_5718:modules_2escm"),(void*)f_5718},
{C_text("f_5720:modules_2escm"),(void*)f_5720},
{C_text("f_5774:modules_2escm"),(void*)f_5774},
{C_text("f_5781:modules_2escm"),(void*)f_5781},
{C_text("f_5784:modules_2escm"),(void*)f_5784},
{C_text("f_5787:modules_2escm"),(void*)f_5787},
{C_text("f_5790:modules_2escm"),(void*)f_5790},
{C_text("f_5796:modules_2escm"),(void*)f_5796},
{C_text("f_5809:modules_2escm"),(void*)f_5809},
{C_text("f_5821:modules_2escm"),(void*)f_5821},
{C_text("f_5825:modules_2escm"),(void*)f_5825},
{C_text("f_5827:modules_2escm"),(void*)f_5827},
{C_text("f_5843:modules_2escm"),(void*)f_5843},
{C_text("f_5844:modules_2escm"),(void*)f_5844},
{C_text("f_5852:modules_2escm"),(void*)f_5852},
{C_text("f_5866:modules_2escm"),(void*)f_5866},
{C_text("f_5869:modules_2escm"),(void*)f_5869},
{C_text("f_5876:modules_2escm"),(void*)f_5876},
{C_text("f_5880:modules_2escm"),(void*)f_5880},
{C_text("f_5886:modules_2escm"),(void*)f_5886},
{C_text("f_5914:modules_2escm"),(void*)f_5914},
{C_text("f_5916:modules_2escm"),(void*)f_5916},
{C_text("f_5919:modules_2escm"),(void*)f_5919},
{C_text("f_5923:modules_2escm"),(void*)f_5923},
{C_text("f_5939:modules_2escm"),(void*)f_5939},
{C_text("f_5946:modules_2escm"),(void*)f_5946},
{C_text("f_5960:modules_2escm"),(void*)f_5960},
{C_text("f_5970:modules_2escm"),(void*)f_5970},
{C_text("f_5973:modules_2escm"),(void*)f_5973},
{C_text("f_5976:modules_2escm"),(void*)f_5976},
{C_text("f_5982:modules_2escm"),(void*)f_5982},
{C_text("f_5985:modules_2escm"),(void*)f_5985},
{C_text("f_5988:modules_2escm"),(void*)f_5988},
{C_text("f_6021:modules_2escm"),(void*)f_6021},
{C_text("f_6025:modules_2escm"),(void*)f_6025},
{C_text("f_6032:modules_2escm"),(void*)f_6032},
{C_text("f_6036:modules_2escm"),(void*)f_6036},
{C_text("f_6049:modules_2escm"),(void*)f_6049},
{C_text("f_6059:modules_2escm"),(void*)f_6059},
{C_text("f_6062:modules_2escm"),(void*)f_6062},
{C_text("f_6068:modules_2escm"),(void*)f_6068},
{C_text("f_6071:modules_2escm"),(void*)f_6071},
{C_text("f_6077:modules_2escm"),(void*)f_6077},
{C_text("f_6111:modules_2escm"),(void*)f_6111},
{C_text("f_6115:modules_2escm"),(void*)f_6115},
{C_text("f_6130:modules_2escm"),(void*)f_6130},
{C_text("f_6141:modules_2escm"),(void*)f_6141},
{C_text("f_6147:modules_2escm"),(void*)f_6147},
{C_text("f_6164:modules_2escm"),(void*)f_6164},
{C_text("f_6171:modules_2escm"),(void*)f_6171},
{C_text("f_6178:modules_2escm"),(void*)f_6178},
{C_text("f_6223:modules_2escm"),(void*)f_6223},
{C_text("f_6329:modules_2escm"),(void*)f_6329},
{C_text("f_6337:modules_2escm"),(void*)f_6337},
{C_text("f_6341:modules_2escm"),(void*)f_6341},
{C_text("f_6352:modules_2escm"),(void*)f_6352},
{C_text("f_6379:modules_2escm"),(void*)f_6379},
{C_text("f_6402:modules_2escm"),(void*)f_6402},
{C_text("f_6416:modules_2escm"),(void*)f_6416},
{C_text("f_6424:modules_2escm"),(void*)f_6424},
{C_text("f_6428:modules_2escm"),(void*)f_6428},
{C_text("f_6441:modules_2escm"),(void*)f_6441},
{C_text("f_6456:modules_2escm"),(void*)f_6456},
{C_text("f_6474:modules_2escm"),(void*)f_6474},
{C_text("f_6485:modules_2escm"),(void*)f_6485},
{C_text("f_6504:modules_2escm"),(void*)f_6504},
{C_text("f_6517:modules_2escm"),(void*)f_6517},
{C_text("f_6527:modules_2escm"),(void*)f_6527},
{C_text("f_6533:modules_2escm"),(void*)f_6533},
{C_text("f_6537:modules_2escm"),(void*)f_6537},
{C_text("f_6540:modules_2escm"),(void*)f_6540},
{C_text("f_6551:modules_2escm"),(void*)f_6551},
{C_text("f_6567:modules_2escm"),(void*)f_6567},
{C_text("f_6579:modules_2escm"),(void*)f_6579},
{C_text("f_6593:modules_2escm"),(void*)f_6593},
{C_text("f_6598:modules_2escm"),(void*)f_6598},
{C_text("f_6608:modules_2escm"),(void*)f_6608},
{C_text("f_6626:modules_2escm"),(void*)f_6626},
{C_text("f_6648:modules_2escm"),(void*)f_6648},
{C_text("f_6656:modules_2escm"),(void*)f_6656},
{C_text("f_6686:modules_2escm"),(void*)f_6686},
{C_text("f_6709:modules_2escm"),(void*)f_6709},
{C_text("f_6713:modules_2escm"),(void*)f_6713},
{C_text("f_6717:modules_2escm"),(void*)f_6717},
{C_text("f_6721:modules_2escm"),(void*)f_6721},
{C_text("f_6725:modules_2escm"),(void*)f_6725},
{C_text("f_6757:modules_2escm"),(void*)f_6757},
{C_text("f_6761:modules_2escm"),(void*)f_6761},
{C_text("f_6773:modules_2escm"),(void*)f_6773},
{C_text("f_6805:modules_2escm"),(void*)f_6805},
{C_text("f_6815:modules_2escm"),(void*)f_6815},
{C_text("f_6830:modules_2escm"),(void*)f_6830},
{C_text("f_6854:modules_2escm"),(void*)f_6854},
{C_text("f_6870:modules_2escm"),(void*)f_6870},
{C_text("f_6872:modules_2escm"),(void*)f_6872},
{C_text("f_6897:modules_2escm"),(void*)f_6897},
{C_text("f_6959:modules_2escm"),(void*)f_6959},
{C_text("f_6961:modules_2escm"),(void*)f_6961},
{C_text("f_6986:modules_2escm"),(void*)f_6986},
{C_text("f_7016:modules_2escm"),(void*)f_7016},
{C_text("f_7037:modules_2escm"),(void*)f_7037},
{C_text("f_7065:modules_2escm"),(void*)f_7065},
{C_text("f_7073:modules_2escm"),(void*)f_7073},
{C_text("f_7103:modules_2escm"),(void*)f_7103},
{C_text("f_7128:modules_2escm"),(void*)f_7128},
{C_text("f_7138:modules_2escm"),(void*)f_7138},
{C_text("f_7154:modules_2escm"),(void*)f_7154},
{C_text("f_7164:modules_2escm"),(void*)f_7164},
{C_text("f_7170:modules_2escm"),(void*)f_7170},
{C_text("f_7171:modules_2escm"),(void*)f_7171},
{C_text("f_7183:modules_2escm"),(void*)f_7183},
{C_text("f_7196:modules_2escm"),(void*)f_7196},
{C_text("f_7197:modules_2escm"),(void*)f_7197},
{C_text("f_7209:modules_2escm"),(void*)f_7209},
{C_text("f_7222:modules_2escm"),(void*)f_7222},
{C_text("f_7225:modules_2escm"),(void*)f_7225},
{C_text("f_7241:modules_2escm"),(void*)f_7241},
{C_text("f_7245:modules_2escm"),(void*)f_7245},
{C_text("f_7249:modules_2escm"),(void*)f_7249},
{C_text("f_7251:modules_2escm"),(void*)f_7251},
{C_text("f_7261:modules_2escm"),(void*)f_7261},
{C_text("f_7274:modules_2escm"),(void*)f_7274},
{C_text("f_7284:modules_2escm"),(void*)f_7284},
{C_text("f_7301:modules_2escm"),(void*)f_7301},
{C_text("f_7308:modules_2escm"),(void*)f_7308},
{C_text("f_7312:modules_2escm"),(void*)f_7312},
{C_text("f_7325:modules_2escm"),(void*)f_7325},
{C_text("f_7350:modules_2escm"),(void*)f_7350},
{C_text("f_7359:modules_2escm"),(void*)f_7359},
{C_text("f_7384:modules_2escm"),(void*)f_7384},
{C_text("f_7399:modules_2escm"),(void*)f_7399},
{C_text("f_7406:modules_2escm"),(void*)f_7406},
{C_text("f_7412:modules_2escm"),(void*)f_7412},
{C_text("f_7428:modules_2escm"),(void*)f_7428},
{C_text("f_7432:modules_2escm"),(void*)f_7432},
{C_text("f_7436:modules_2escm"),(void*)f_7436},
{C_text("f_7449:modules_2escm"),(void*)f_7449},
{C_text("f_7471:modules_2escm"),(void*)f_7471},
{C_text("f_7473:modules_2escm"),(void*)f_7473},
{C_text("f_7498:modules_2escm"),(void*)f_7498},
{C_text("f_7513:modules_2escm"),(void*)f_7513},
{C_text("f_7528:modules_2escm"),(void*)f_7528},
{C_text("f_7539:modules_2escm"),(void*)f_7539},
{C_text("f_7541:modules_2escm"),(void*)f_7541},
{C_text("f_7569:modules_2escm"),(void*)f_7569},
{C_text("f_7606:modules_2escm"),(void*)f_7606},
{C_text("f_7635:modules_2escm"),(void*)f_7635},
{C_text("f_7644:modules_2escm"),(void*)f_7644},
{C_text("f_7647:modules_2escm"),(void*)f_7647},
{C_text("f_7650:modules_2escm"),(void*)f_7650},
{C_text("f_7651:modules_2escm"),(void*)f_7651},
{C_text("f_7665:modules_2escm"),(void*)f_7665},
{C_text("f_7669:modules_2escm"),(void*)f_7669},
{C_text("f_7672:modules_2escm"),(void*)f_7672},
{C_text("f_7675:modules_2escm"),(void*)f_7675},
{C_text("f_7678:modules_2escm"),(void*)f_7678},
{C_text("f_7686:modules_2escm"),(void*)f_7686},
{C_text("f_7693:modules_2escm"),(void*)f_7693},
{C_text("f_7702:modules_2escm"),(void*)f_7702},
{C_text("f_7705:modules_2escm"),(void*)f_7705},
{C_text("f_7712:modules_2escm"),(void*)f_7712},
{C_text("f_7715:modules_2escm"),(void*)f_7715},
{C_text("f_7716:modules_2escm"),(void*)f_7716},
{C_text("f_7720:modules_2escm"),(void*)f_7720},
{C_text("f_7723:modules_2escm"),(void*)f_7723},
{C_text("f_7735:modules_2escm"),(void*)f_7735},
{C_text("f_7745:modules_2escm"),(void*)f_7745},
{C_text("f_7767:modules_2escm"),(void*)f_7767},
{C_text("f_7768:modules_2escm"),(void*)f_7768},
{C_text("f_7772:modules_2escm"),(void*)f_7772},
{C_text("f_7780:modules_2escm"),(void*)f_7780},
{C_text("f_7790:modules_2escm"),(void*)f_7790},
{C_text("f_7804:modules_2escm"),(void*)f_7804},
{C_text("f_7810:modules_2escm"),(void*)f_7810},
{C_text("f_7813:modules_2escm"),(void*)f_7813},
{C_text("f_7841:modules_2escm"),(void*)f_7841},
{C_text("f_7848:modules_2escm"),(void*)f_7848},
{C_text("f_7854:modules_2escm"),(void*)f_7854},
{C_text("f_7857:modules_2escm"),(void*)f_7857},
{C_text("f_7858:modules_2escm"),(void*)f_7858},
{C_text("f_7862:modules_2escm"),(void*)f_7862},
{C_text("f_7880:modules_2escm"),(void*)f_7880},
{C_text("f_7886:modules_2escm"),(void*)f_7886},
{C_text("f_7889:modules_2escm"),(void*)f_7889},
{C_text("f_7892:modules_2escm"),(void*)f_7892},
{C_text("f_7903:modules_2escm"),(void*)f_7903},
{C_text("f_7907:modules_2escm"),(void*)f_7907},
{C_text("f_7911:modules_2escm"),(void*)f_7911},
{C_text("f_7915:modules_2escm"),(void*)f_7915},
{C_text("f_7921:modules_2escm"),(void*)f_7921},
{C_text("f_7931:modules_2escm"),(void*)f_7931},
{C_text("f_7946:modules_2escm"),(void*)f_7946},
{C_text("f_7950:modules_2escm"),(void*)f_7950},
{C_text("f_7952:modules_2escm"),(void*)f_7952},
{C_text("f_7977:modules_2escm"),(void*)f_7977},
{C_text("f_7989:modules_2escm"),(void*)f_7989},
{C_text("f_7999:modules_2escm"),(void*)f_7999},
{C_text("f_8016:modules_2escm"),(void*)f_8016},
{C_text("f_8047:modules_2escm"),(void*)f_8047},
{C_text("f_8051:modules_2escm"),(void*)f_8051},
{C_text("f_8060:modules_2escm"),(void*)f_8060},
{C_text("f_8063:modules_2escm"),(void*)f_8063},
{C_text("f_8075:modules_2escm"),(void*)f_8075},
{C_text("f_8091:modules_2escm"),(void*)f_8091},
{C_text("f_8095:modules_2escm"),(void*)f_8095},
{C_text("f_8099:modules_2escm"),(void*)f_8099},
{C_text("f_8113:modules_2escm"),(void*)f_8113},
{C_text("f_8146:modules_2escm"),(void*)f_8146},
{C_text("f_8148:modules_2escm"),(void*)f_8148},
{C_text("f_8161:modules_2escm"),(void*)f_8161},
{C_text("f_8170:modules_2escm"),(void*)f_8170},
{C_text("f_8183:modules_2escm"),(void*)f_8183},
{C_text("f_8208:modules_2escm"),(void*)f_8208},
{C_text("f_8218:modules_2escm"),(void*)f_8218},
{C_text("f_8222:modules_2escm"),(void*)f_8222},
{C_text("f_8228:modules_2escm"),(void*)f_8228},
{C_text("f_8231:modules_2escm"),(void*)f_8231},
{C_text("f_8236:modules_2escm"),(void*)f_8236},
{C_text("f_8240:modules_2escm"),(void*)f_8240},
{C_text("f_8243:modules_2escm"),(void*)f_8243},
{C_text("f_8246:modules_2escm"),(void*)f_8246},
{C_text("f_8249:modules_2escm"),(void*)f_8249},
{C_text("f_8253:modules_2escm"),(void*)f_8253},
{C_text("f_8257:modules_2escm"),(void*)f_8257},
{C_text("f_8261:modules_2escm"),(void*)f_8261},
{C_text("f_8265:modules_2escm"),(void*)f_8265},
{C_text("f_8268:modules_2escm"),(void*)f_8268},
{C_text("f_8271:modules_2escm"),(void*)f_8271},
{C_text("f_8274:modules_2escm"),(void*)f_8274},
{C_text("f_8277:modules_2escm"),(void*)f_8277},
{C_text("f_8292:modules_2escm"),(void*)f_8292},
{C_text("f_8298:modules_2escm"),(void*)f_8298},
{C_text("f_8303:modules_2escm"),(void*)f_8303},
{C_text("f_8307:modules_2escm"),(void*)f_8307},
{C_text("f_8312:modules_2escm"),(void*)f_8312},
{C_text("f_8317:modules_2escm"),(void*)f_8317},
{C_text("f_8321:modules_2escm"),(void*)f_8321},
{C_text("f_8324:modules_2escm"),(void*)f_8324},
{C_text("f_8327:modules_2escm"),(void*)f_8327},
{C_text("f_8330:modules_2escm"),(void*)f_8330},
{C_text("f_8333:modules_2escm"),(void*)f_8333},
{C_text("f_8336:modules_2escm"),(void*)f_8336},
{C_text("f_8339:modules_2escm"),(void*)f_8339},
{C_text("f_8342:modules_2escm"),(void*)f_8342},
{C_text("f_8350:modules_2escm"),(void*)f_8350},
{C_text("f_8354:modules_2escm"),(void*)f_8354},
{C_text("f_8357:modules_2escm"),(void*)f_8357},
{C_text("f_8361:modules_2escm"),(void*)f_8361},
{C_text("f_8364:modules_2escm"),(void*)f_8364},
{C_text("f_8372:modules_2escm"),(void*)f_8372},
{C_text("f_8376:modules_2escm"),(void*)f_8376},
{C_text("f_8379:modules_2escm"),(void*)f_8379},
{C_text("f_8382:modules_2escm"),(void*)f_8382},
{C_text("f_8385:modules_2escm"),(void*)f_8385},
{C_text("f_8387:modules_2escm"),(void*)f_8387},
{C_text("f_8395:modules_2escm"),(void*)f_8395},
{C_text("f_8399:modules_2escm"),(void*)f_8399},
{C_text("f_8401:modules_2escm"),(void*)f_8401},
{C_text("f_8414:modules_2escm"),(void*)f_8414},
{C_text("f_8421:modules_2escm"),(void*)f_8421},
{C_text("f_8448:modules_2escm"),(void*)f_8448},
{C_text("f_8451:modules_2escm"),(void*)f_8451},
{C_text("f_8455:modules_2escm"),(void*)f_8455},
{C_text("f_8458:modules_2escm"),(void*)f_8458},
{C_text("f_8499:modules_2escm"),(void*)f_8499},
{C_text("f_8513:modules_2escm"),(void*)f_8513},
{C_text("f_8531:modules_2escm"),(void*)f_8531},
{C_text("f_8534:modules_2escm"),(void*)f_8534},
{C_text("f_8539:modules_2escm"),(void*)f_8539},
{C_text("f_8549:modules_2escm"),(void*)f_8549},
{C_text("f_8553:modules_2escm"),(void*)f_8553},
{C_text("f_8558:modules_2escm"),(void*)f_8558},
{C_text("f_8566:modules_2escm"),(void*)f_8566},
{C_text("f_8576:modules_2escm"),(void*)f_8576},
{C_text("f_8589:modules_2escm"),(void*)f_8589},
{C_text("f_8599:modules_2escm"),(void*)f_8599},
{C_text("f_8617:modules_2escm"),(void*)f_8617},
{C_text("f_8639:modules_2escm"),(void*)f_8639},
{C_text("f_8681:modules_2escm"),(void*)f_8681},
{C_text("f_8684:modules_2escm"),(void*)f_8684},
{C_text("f_8689:modules_2escm"),(void*)f_8689},
{C_text("f_8699:modules_2escm"),(void*)f_8699},
{C_text("f_8703:modules_2escm"),(void*)f_8703},
{C_text("f_8708:modules_2escm"),(void*)f_8708},
{C_text("f_8720:modules_2escm"),(void*)f_8720},
{C_text("f_8728:modules_2escm"),(void*)f_8728},
{C_text("f_8738:modules_2escm"),(void*)f_8738},
{C_text("f_8751:modules_2escm"),(void*)f_8751},
{C_text("f_8761:modules_2escm"),(void*)f_8761},
{C_text("f_8779:modules_2escm"),(void*)f_8779},
{C_text("f_8791:modules_2escm"),(void*)f_8791},
{C_text("f_8820:modules_2escm"),(void*)f_8820},
{C_text("f_8832:modules_2escm"),(void*)f_8832},
{C_text("f_8864:modules_2escm"),(void*)f_8864},
{C_text("f_8867:modules_2escm"),(void*)f_8867},
{C_text("f_8872:modules_2escm"),(void*)f_8872},
{C_text("f_8882:modules_2escm"),(void*)f_8882},
{C_text("f_8886:modules_2escm"),(void*)f_8886},
{C_text("f_8891:modules_2escm"),(void*)f_8891},
{C_text("f_8903:modules_2escm"),(void*)f_8903},
{C_text("f_8911:modules_2escm"),(void*)f_8911},
{C_text("f_8924:modules_2escm"),(void*)f_8924},
{C_text("f_8930:modules_2escm"),(void*)f_8930},
{C_text("f_8943:modules_2escm"),(void*)f_8943},
{C_text("f_8953:modules_2escm"),(void*)f_8953},
{C_text("f_8966:modules_2escm"),(void*)f_8966},
{C_text("f_9005:modules_2escm"),(void*)f_9005},
{C_text("f_9021:modules_2escm"),(void*)f_9021},
{C_text("f_9058:modules_2escm"),(void*)f_9058},
{C_text("f_9074:modules_2escm"),(void*)f_9074},
{C_text("f_9114:modules_2escm"),(void*)f_9114},
{C_text("f_9117:modules_2escm"),(void*)f_9117},
{C_text("f_9122:modules_2escm"),(void*)f_9122},
{C_text("f_9132:modules_2escm"),(void*)f_9132},
{C_text("f_9136:modules_2escm"),(void*)f_9136},
{C_text("f_9138:modules_2escm"),(void*)f_9138},
{C_text("f_9146:modules_2escm"),(void*)f_9146},
{C_text("f_9152:modules_2escm"),(void*)f_9152},
{C_text("f_9156:modules_2escm"),(void*)f_9156},
{C_text("f_9160:modules_2escm"),(void*)f_9160},
{C_text("f_9181:modules_2escm"),(void*)f_9181},
{C_text("f_9191:modules_2escm"),(void*)f_9191},
{C_text("f_9193:modules_2escm"),(void*)f_9193},
{C_text("f_9218:modules_2escm"),(void*)f_9218},
{C_text("f_9227:modules_2escm"),(void*)f_9227},
{C_text("f_9252:modules_2escm"),(void*)f_9252},
{C_text("f_9270:modules_2escm"),(void*)f_9270},
{C_text("f_9276:modules_2escm"),(void*)f_9276},
{C_text("f_9280:modules_2escm"),(void*)f_9280},
{C_text("f_9281:modules_2escm"),(void*)f_9281},
{C_text("f_9287:modules_2escm"),(void*)f_9287},
{C_text("f_9293:modules_2escm"),(void*)f_9293},
{C_text("f_9315:modules_2escm"),(void*)f_9315},
{C_text("f_9317:modules_2escm"),(void*)f_9317},
{C_text("f_9327:modules_2escm"),(void*)f_9327},
{C_text("f_9340:modules_2escm"),(void*)f_9340},
{C_text("f_9344:modules_2escm"),(void*)f_9344},
{C_text("f_9347:modules_2escm"),(void*)f_9347},
{C_text("f_9357:modules_2escm"),(void*)f_9357},
{C_text("f_9395:modules_2escm"),(void*)f_9395},
{C_text("f_9401:modules_2escm"),(void*)f_9401},
{C_text("f_9402:modules_2escm"),(void*)f_9402},
{C_text("f_9438:modules_2escm"),(void*)f_9438},
{C_text("f_9444:modules_2escm"),(void*)f_9444},
{C_text("f_9447:modules_2escm"),(void*)f_9447},
{C_text("f_9450:modules_2escm"),(void*)f_9450},
{C_text("f_9457:modules_2escm"),(void*)f_9457},
{C_text("f_9461:modules_2escm"),(void*)f_9461},
{C_text("f_9465:modules_2escm"),(void*)f_9465},
{C_text("f_9469:modules_2escm"),(void*)f_9469},
{C_text("f_9472:modules_2escm"),(void*)f_9472},
{C_text("f_9478:modules_2escm"),(void*)f_9478},
{C_text("f_9481:modules_2escm"),(void*)f_9481},
{C_text("f_9488:modules_2escm"),(void*)f_9488},
{C_text("f_9498:modules_2escm"),(void*)f_9498},
{C_text("f_9505:modules_2escm"),(void*)f_9505},
{C_text("f_9516:modules_2escm"),(void*)f_9516},
{C_text("f_9523:modules_2escm"),(void*)f_9523},
{C_text("f_9525:modules_2escm"),(void*)f_9525},
{C_text("f_9559:modules_2escm"),(void*)f_9559},
{C_text("f_9595:modules_2escm"),(void*)f_9595},
{C_text("f_9606:modules_2escm"),(void*)f_9606},
{C_text("f_9620:modules_2escm"),(void*)f_9620},
{C_text("f_9627:modules_2escm"),(void*)f_9627},
{C_text("f_9629:modules_2escm"),(void*)f_9629},
{C_text("f_9663:modules_2escm"),(void*)f_9663},
{C_text("f_9703:modules_2escm"),(void*)f_9703},
{C_text("f_9713:modules_2escm"),(void*)f_9713},
{C_text("f_9726:modules_2escm"),(void*)f_9726},
{C_text("f_9736:modules_2escm"),(void*)f_9736},
{C_text("f_9757:modules_2escm"),(void*)f_9757},
{C_text("f_9772:modules_2escm"),(void*)f_9772},
{C_text("f_9782:modules_2escm"),(void*)f_9782},
{C_text("f_9790:modules_2escm"),(void*)f_9790},
{C_text("f_9800:modules_2escm"),(void*)f_9800},
{C_text("f_9803:modules_2escm"),(void*)f_9803},
{C_text("f_9807:modules_2escm"),(void*)f_9807},
{C_text("f_9811:modules_2escm"),(void*)f_9811},
{C_text("f_9818:modules_2escm"),(void*)f_9818},
{C_text("f_9837:modules_2escm"),(void*)f_9837},
{C_text("f_9852:modules_2escm"),(void*)f_9852},
{C_text("f_9878:modules_2escm"),(void*)f_9878},
{C_text("f_9880:modules_2escm"),(void*)f_9880},
{C_text("f_9883:modules_2escm"),(void*)f_9883},
{C_text("f_9889:modules_2escm"),(void*)f_9889},
{C_text("f_9930:modules_2escm"),(void*)f_9930},
{C_text("f_9962:modules_2escm"),(void*)f_9962},
{C_text("f_9988:modules_2escm"),(void*)f_9988},
{C_text("toplevel:modules_2escm"),(void*)C_modules_toplevel},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  scheme#for-each		15
S|  chicken.base#foldl		3
S|  scheme#map		33
S|  chicken.base#foldr		3
o|eliminated procedure checks: 436 
o|specializations:
o|  1 (scheme#cddr (pair * pair))
o|  1 (scheme#number->string *)
o|  2 (scheme#string-append string string)
o|  1 (scheme#= fixnum fixnum)
o|  2 (scheme#cdar (pair pair *))
o|  1 (scheme#caar (pair pair *))
o|  1 (null (not null))
o|  1 (scheme#eqv? * *)
o|  9 (##sys#check-list (or pair list) *)
o|  67 (scheme#cdr pair)
o|  35 (scheme#car pair)
(o e)|safe calls: 1110 
(o e)|dropped branches: 1 
(o e)|assignments to immediate values: 1 
o|safe globals: (posv posq make-list iota find-tail find length+ lset=/eq? lset<=/eq? list-tabulate lset-intersection/eq? lset-union/eq? lset-difference/eq? lset-adjoin/eq? list-index last unzip1 remove filter-map filter alist-cons delete-duplicates fifth fourth third second first delete concatenate cons* any every append-map split-at drop take span partition) 
o|removed side-effect free assignment to unused variable: partition 
o|removed side-effect free assignment to unused variable: span 
o|removed side-effect free assignment to unused variable: drop 
o|removed side-effect free assignment to unused variable: split-at 
o|removed side-effect free assignment to unused variable: append-map 
o|inlining procedure: k4374 
o|inlining procedure: k4374 
o|inlining procedure: k4405 
o|inlining procedure: k4405 
o|removed side-effect free assignment to unused variable: cons* 
o|removed side-effect free assignment to unused variable: concatenate 
o|inlining procedure: k4491 
o|inlining procedure: k4491 
o|removed side-effect free assignment to unused variable: first 
o|removed side-effect free assignment to unused variable: second 
o|removed side-effect free assignment to unused variable: third 
o|removed side-effect free assignment to unused variable: fourth 
o|removed side-effect free assignment to unused variable: fifth 
o|removed side-effect free assignment to unused variable: delete-duplicates 
o|removed side-effect free assignment to unused variable: alist-cons 
o|inlining procedure: k4622 
o|inlining procedure: k4622 
o|inlining procedure: k4614 
o|inlining procedure: k4614 
o|removed side-effect free assignment to unused variable: filter-map 
o|removed side-effect free assignment to unused variable: remove 
o|removed side-effect free assignment to unused variable: unzip1 
o|removed side-effect free assignment to unused variable: last 
o|removed side-effect free assignment to unused variable: list-index 
o|removed side-effect free assignment to unused variable: lset-adjoin/eq? 
o|removed side-effect free assignment to unused variable: lset-difference/eq? 
o|removed side-effect free assignment to unused variable: lset-union/eq? 
o|removed side-effect free assignment to unused variable: lset-intersection/eq? 
o|inlining procedure: k5013 
o|inlining procedure: k5013 
o|removed side-effect free assignment to unused variable: lset<=/eq? 
o|removed side-effect free assignment to unused variable: lset=/eq? 
o|removed side-effect free assignment to unused variable: length+ 
o|removed side-effect free assignment to unused variable: find 
o|removed side-effect free assignment to unused variable: find-tail 
o|removed side-effect free assignment to unused variable: iota 
o|removed side-effect free assignment to unused variable: make-list 
o|removed side-effect free assignment to unused variable: posq 
o|removed side-effect free assignment to unused variable: posv 
o|removed side-effect free assignment to unused variable: module? 
o|contracted procedure: "(modules.scm:123) %make-module" 
o|inlining procedure: k5641 
o|contracted procedure: "(modules.scm:132) g905914" 
o|inlining procedure: k5641 
o|inlining procedure: k5696 
o|inlining procedure: k5696 
o|inlining procedure: k5688 
o|inlining procedure: k5688 
o|inlining procedure: k5737 
o|inlining procedure: k5737 
o|inlining procedure: k5788 
o|inlining procedure: k5788 
o|inlining procedure: k5849 
o|inlining procedure: k5849 
o|inlining procedure: k5832 
o|inlining procedure: k5888 
o|inlining procedure: k5888 
o|inlining procedure: k5832 
o|inlining procedure: k5924 
o|contracted procedure: "(modules.scm:186) set-module-meta-expressions!" 
o|inlining procedure: k5924 
o|inlining procedure: k5950 
o|inlining procedure: k5950 
o|inlining procedure: k5962 
o|inlining procedure: k5962 
o|inlining procedure: k6051 
o|inlining procedure: k6051 
o|inlining procedure: k6132 
o|inlining procedure: k6132 
o|merged explicitly consed rest parameter: ses*1169 
o|inlining procedure: k6553 
o|inlining procedure: k6553 
o|inlining procedure: k6573 
o|inlining procedure: k6600 
o|inlining procedure: k6600 
o|inlining procedure: k6573 
o|inlining procedure: k6628 
o|inlining procedure: k6628 
o|inlining procedure: k6759 
o|inlining procedure: k6759 
o|inlining procedure: k6775 
o|inlining procedure: k6775 
o|inlining procedure: k6838 
o|inlining procedure: k6838 
o|inlining procedure: k6874 
o|inlining procedure: k6874 
o|inlining procedure: k6963 
o|contracted procedure: "(modules.scm:333) g12451254" 
o|inlining procedure: k6915 
o|inlining procedure: k6915 
o|inlining procedure: k6963 
o|contracted procedure: "(modules.scm:326) g12331234" 
o|inlining procedure: k7109 
o|contracted procedure: "(modules.scm:376) find-reexport1339" 
o|inlining procedure: k7084 
o|inlining procedure: k7084 
o|inlining procedure: k7109 
o|consed rest parameter at call site: "(modules.scm:393) merge-se" 1 
o|inlining procedure: k7188 
o|consed rest parameter at call site: "(modules.scm:393) merge-se" 1 
o|inlining procedure: k7188 
o|consed rest parameter at call site: "(modules.scm:393) merge-se" 1 
o|consed rest parameter at call site: "(modules.scm:397) merge-se" 1 
o|inlining procedure: k7214 
o|consed rest parameter at call site: "(modules.scm:397) merge-se" 1 
o|inlining procedure: k7214 
o|consed rest parameter at call site: "(modules.scm:397) merge-se" 1 
o|consed rest parameter at call site: "(modules.scm:401) merge-se" 1 
o|inlining procedure: k7253 
o|inlining procedure: k7253 
o|inlining procedure: k7276 
o|inlining procedure: k7276 
o|consed rest parameter at call site: "(modules.scm:386) merge-se" 1 
o|inlining procedure: k7327 
o|contracted procedure: "(modules.scm:380) g13801389" 
o|inlining procedure: k7327 
o|inlining procedure: k7361 
o|inlining procedure: k7361 
o|consed rest parameter at call site: "(modules.scm:422) merge-se" 1 
o|inlining procedure: k7451 
o|inlining procedure: k7451 
o|inlining procedure: k7475 
o|inlining procedure: k7475 
o|inlining procedure: k7543 
o|inlining procedure: k7543 
o|inlining procedure: k7555 
o|inlining procedure: k7570 
o|inlining procedure: k7570 
o|inlining procedure: k7555 
o|inlining procedure: k7657 
o|inlining procedure: k7657 
o|inlining procedure: k7694 
o|inlining procedure: k7694 
o|inlining procedure: k7737 
o|inlining procedure: k7737 
o|substituted constant variable: a7757 
o|contracted procedure: "(modules.scm:509) g16351636" 
o|inlining procedure: k7782 
o|inlining procedure: k7782 
o|consed rest parameter at call site: "(modules.scm:538) merge-se" 1 
o|consed rest parameter at call site: "(modules.scm:556) merge-se" 1 
o|consed rest parameter at call site: "(modules.scm:553) merge-se" 1 
o|contracted procedure: "(modules.scm:549) set-module-vexports!" 
o|inlining procedure: k7923 
o|inlining procedure: k7923 
o|consed rest parameter at call site: "(modules.scm:532) merge-se" 1 
o|inlining procedure: k7954 
o|contracted procedure: "(modules.scm:527) g16871696" 
o|inlining procedure: k7819 
o|inlining procedure: k7819 
o|inlining procedure: k7954 
o|contracted procedure: "(modules.scm:531) module-indirect-exports" 
o|removed side-effect free assignment to unused variable: indirect?1120 
o|inlining procedure: k6342 
o|inlining procedure: k6342 
o|inlining procedure: k6354 
o|inlining procedure: k6354 
o|inlining procedure: k6381 
o|inlining procedure: k6381 
o|inlining procedure: k6439 
o|inlining procedure: k6439 
o|inlining procedure: k6413 
o|inlining procedure: k6413 
o|inlining procedure: k6458 
o|inlining procedure: k6458 
o|inlining procedure: k7991 
o|inlining procedure: k7991 
o|inlining procedure: k8018 
o|inlining procedure: k8018 
o|inlining procedure: k8058 
o|inlining procedure: k8058 
o|inlining procedure: k8082 
o|inlining procedure: k8082 
o|consed rest parameter at call site: "(modules.scm:457) merge-se" 1 
o|inlining procedure: k8150 
o|inlining procedure: k8150 
o|inlining procedure: k8185 
o|contracted procedure: "(modules.scm:453) g15521561" 
o|inlining procedure: k8185 
o|substituted constant variable: saved175417551774 
o|substituted constant variable: saved175617571775 
o|inlining procedure: k8223 
o|inlining procedure: k8223 
o|substituted constant variable: a8355 
o|inlining procedure: k8365 
o|inlining procedure: k8365 
o|inlining procedure: k8403 
o|inlining procedure: k8403 
o|inlining procedure: k8422 
o|inlining procedure: k8422 
o|inlining procedure: k8459 
o|inlining procedure: k8459 
o|inlining procedure: k8501 
o|inlining procedure: k8501 
o|inlining procedure: k8526 
o|inlining procedure: k8560 
o|inlining procedure: k8591 
o|inlining procedure: k8591 
o|inlining procedure: k8560 
o|inlining procedure: k8636 
o|inlining procedure: k8636 
o|inlining procedure: k8526 
o|inlining procedure: k8710 
o|inlining procedure: k8722 
o|inlining procedure: k8753 
o|inlining procedure: k8753 
o|inlining procedure: k8722 
o|inlining procedure: k8710 
o|inlining procedure: k8859 
o|inlining procedure: k8893 
o|inlining procedure: k8905 
o|inlining procedure: k8945 
o|inlining procedure: k8945 
o|inlining procedure: k8968 
o|inlining procedure: k8968 
o|inlining procedure: k8905 
o|inlining procedure: k8893 
o|inlining procedure: k8859 
o|inlining procedure: k9195 
o|inlining procedure: k9195 
o|inlining procedure: k9229 
o|inlining procedure: k9229 
o|inlining procedure: k9295 
o|inlining procedure: k9295 
o|inlining procedure: k9319 
o|inlining procedure: k9319 
o|inlining procedure: k9362 
o|inlining procedure: k9372 
o|inlining procedure: k9372 
o|inlining procedure: k9362 
o|inlining procedure: k9407 
o|inlining procedure: k9407 
o|consed rest parameter at call site: "(modules.scm:757) merge-se" 1 
o|inlining procedure: k9527 
o|inlining procedure: k9527 
o|inlining procedure: k9561 
o|inlining procedure: k9561 
o|inlining procedure: k9631 
o|inlining procedure: k9631 
o|inlining procedure: k9665 
o|inlining procedure: k9665 
o|inlining procedure: k9705 
o|inlining procedure: k9705 
o|inlining procedure: k9728 
o|inlining procedure: k9728 
o|inlining procedure: k9748 
o|contracted procedure: "(modules.scm:713) set-module-meta-import-forms!" 
o|inlining procedure: k9748 
o|contracted procedure: "(modules.scm:716) set-module-import-forms!" 
o|contracted procedure: "(modules.scm:775) register-undefined" 
o|inlining procedure: k6159 
o|inlining procedure: k6173 
o|inlining procedure: k6173 
o|inlining procedure: k6216 
o|inlining procedure: k6216 
o|inlining procedure: k6159 
o|inlining procedure: k9808 
o|inlining procedure: k9808 
o|inlining procedure: k9832 
o|inlining procedure: k9832 
o|inlining procedure: k9860 
o|inlining procedure: k9860 
o|inlining procedure: k9849 
o|inlining procedure: k9849 
o|contracted procedure: "(modules.scm:779) g24742475" 
o|merged explicitly consed rest parameter: args2495 
o|inlining procedure: k9896 
o|inlining procedure: k9896 
o|consed rest parameter at call site: "(modules.scm:794) err2493" 1 
o|contracted procedure: "(modules.scm:793) g25002501" 
o|inlining procedure: k9902 
o|inlining procedure: k9902 
o|inlining procedure: k9917 
o|consed rest parameter at call site: "(modules.scm:798) err2493" 1 
o|inlining procedure: k9917 
o|inlining procedure: k9932 
o|inlining procedure: k9932 
o|consed rest parameter at call site: "(modules.scm:803) err2493" 1 
o|inlining procedure: k9950 
o|inlining procedure: k9950 
o|consed rest parameter at call site: "(modules.scm:808) err2493" 1 
o|inlining procedure: k9974 
o|inlining procedure: k9974 
o|inlining procedure: k9997 
o|inlining procedure: k9997 
o|consed rest parameter at call site: "(modules.scm:814) err2493" 1 
o|inlining procedure: k10041 
o|inlining procedure: k10041 
o|consed rest parameter at call site: "(modules.scm:819) err2493" 1 
o|contracted procedure: "(modules.scm:822) g25312532" 
o|merged explicitly consed rest parameter: args2546 
o|consed rest parameter at call site: "(modules.scm:833) err2545" 1 
o|inlining procedure: k10162 
o|inlining procedure: k10162 
o|inlining procedure: k10213 
o|inlining procedure: k10213 
o|inlining procedure: k10222 
o|inlining procedure: k10234 
o|inlining procedure: k10234 
o|removed unused parameter to known procedure: alias2607 "(modules.scm:847) match-functor-argument" 
o|inlining procedure: k10222 
o|removed unused parameter to known procedure: alias2607 "(modules.scm:861) match-functor-argument" 
o|consed rest parameter at call site: "(modules.scm:828) err2545" 1 
o|contracted procedure: "(modules.scm:825) g25412542" 
o|removed unused formal parameters: (alias2607) 
o|inlining procedure: k10342 
o|inlining procedure: k10353 
o|inlining procedure: k10353 
o|inlining procedure: k10342 
o|inlining procedure: k10437 
o|contracted procedure: "(modules.scm:888) g26442653" 
o|substituted constant variable: a10423 
o|inlining procedure: k10437 
o|inlining procedure: k10471 
o|inlining procedure: k10471 
o|inlining procedure: k10585 
o|inlining procedure: k10585 
o|contracted procedure: "(modules.scm:1110) g31253126" 
o|inlining procedure: k10637 
o|inlining procedure: k10637 
o|contracted procedure: "(modules.scm:1107) g30873088" 
o|inlining procedure: k10691 
o|inlining procedure: k10691 
o|contracted procedure: "(modules.scm:1103) g30493050" 
o|inlining procedure: k10745 
o|inlining procedure: k10745 
o|contracted procedure: "(modules.scm:1097) g30113012" 
o|inlining procedure: k10799 
o|inlining procedure: k10799 
o|contracted procedure: "(modules.scm:1091) g29732974" 
o|inlining procedure: k10853 
o|inlining procedure: k10853 
o|contracted procedure: "(modules.scm:1088) g29352936" 
o|inlining procedure: k10907 
o|inlining procedure: k10907 
o|contracted procedure: "(modules.scm:1085) g28972898" 
o|inlining procedure: k10961 
o|inlining procedure: k10961 
o|contracted procedure: "(modules.scm:1082) g28592860" 
o|inlining procedure: k11015 
o|inlining procedure: k11015 
o|contracted procedure: "(modules.scm:1069) g28212822" 
o|inlining procedure: k11069 
o|inlining procedure: k11069 
o|contracted procedure: "(modules.scm:1063) g27832784" 
o|inlining procedure: k11123 
o|inlining procedure: k11123 
o|contracted procedure: "(modules.scm:1060) g27452746" 
o|inlining procedure: k11177 
o|inlining procedure: k11177 
o|contracted procedure: "(modules.scm:1051) g27072708" 
o|inlining procedure: k11231 
o|inlining procedure: k11231 
o|contracted procedure: "(modules.scm:1048) g26692670" 
o|inlining procedure: k11285 
o|inlining procedure: k11285 
o|propagated global variable: r4rs-syntax2665 ##sys#scheme-macro-environment 
o|replaced variables: 975 
o|removed binding forms: 518 
o|removed side-effect free assignment to unused variable: every 
o|removed side-effect free assignment to unused variable: any 
o|removed side-effect free assignment to unused variable: filter 
o|removed side-effect free assignment to unused variable: list-tabulate 
o|substituted constant variable: defined-list742 
o|substituted constant variable: exist-list743 
o|substituted constant variable: defined-syntax-list744 
o|substituted constant variable: undefined-list745 
o|substituted constant variable: import-forms746 
o|substituted constant variable: meta-import-forms747 
o|substituted constant variable: meta-expressions748 
o|substituted constant variable: saved-environments752 
o|substituted constant variable: r592511364 
o|substituted constant variable: r595111366 
o|removed call to pure procedure with unused result: "(modules.scm:206) chicken.base#void" 
o|removed call to pure procedure with unused result: "(modules.scm:221) chicken.base#void" 
o|substituted constant variable: r676011381 
o|substituted constant variable: r676011381 
o|substituted constant variable: r677611385 
o|removed call to pure procedure with unused result: "(modules.scm:346) chicken.base#void" 
o|substituted constant variable: prop1236 
o|substituted constant variable: r718911401 
o|substituted constant variable: r718911401 
o|substituted constant variable: r721511405 
o|substituted constant variable: r721511405 
o|contracted procedure: "(modules.scm:374) g13521361" 
o|substituted constant variable: r754411419 
o|substituted constant variable: prop1638 
o|removed call to pure procedure with unused result: "(modules.scm:539) chicken.base#void" 
o|removed call to pure procedure with unused result: "(modules.scm:542) chicken.base#void" 
o|substituted constant variable: r634311439 
o|substituted constant variable: r635511441 
o|converted assignments to bindings: (warn1121) 
o|substituted constant variable: r801911455 
o|removed call to pure procedure with unused result: "(modules.scm:479) chicken.base#void" 
o|inlining procedure: k8058 
o|substituted constant variable: r808311461 
o|substituted constant variable: r815111463 
o|substituted constant variable: r822411468 
o|converted assignments to bindings: (rename2142) 
o|converted assignments to bindings: (module-imports1845) 
o|substituted constant variable: r937311513 
o|substituted constant variable: r936311514 
o|substituted constant variable: r940811516 
o|removed call to pure procedure with unused result: "(modules.scm:758) chicken.base#void" 
o|removed call to pure procedure with unused result: "(modules.scm:721) chicken.base#void" 
o|removed call to pure procedure with unused result: "(modules.scm:720) chicken.base#void" 
o|removed call to pure procedure with unused result: "(modules.scm:719) chicken.base#void" 
o|substituted constant variable: r621711536 
o|substituted constant variable: r621711536 
o|removed call to pure procedure with unused result: "(modules.scm:773) chicken.base#void" 
o|removed call to pure procedure with unused result: "(modules.scm:783) chicken.base#void" 
o|converted assignments to bindings: (mrename2459) 
o|substituted constant variable: prop2503 
o|substituted constant variable: r993311553 
o|substituted constant variable: prop2534 
o|substituted constant variable: r1021411565 
o|substituted constant variable: r1021411565 
o|substituted constant variable: r1023511570 
o|converted assignments to bindings: (merr2553) 
o|converted assignments to bindings: (err2545) 
o|substituted constant variable: prop2544 
o|substituted constant variable: names3127 
o|substituted constant variable: names3089 
o|substituted constant variable: names3051 
o|substituted constant variable: names3013 
o|substituted constant variable: names2975 
o|substituted constant variable: names2937 
o|substituted constant variable: names2899 
o|substituted constant variable: names2861 
o|substituted constant variable: names2823 
o|substituted constant variable: names2785 
o|substituted constant variable: names2747 
o|substituted constant variable: names2709 
o|substituted constant variable: names2671 
o|simplifications: ((let . 6)) 
o|replaced variables: 31 
o|removed binding forms: 1037 
o|contracted procedure: k5992 
o|contracted procedure: k6072 
o|contracted procedure: k6859 
o|inlining procedure: k7515 
o|inlining procedure: k7684 
o|contracted procedure: k7863 
o|contracted procedure: k7881 
o|contracted procedure: k8076 
o|substituted constant variable: r805911676 
o|contracted procedure: k9348 
o|contracted procedure: k9351 
o|contracted procedure: k9354 
o|contracted procedure: k9813 
o|inlining procedure: k9816 
o|contracted procedure: k9857 
o|replaced variables: 6 
o|removed binding forms: 99 
o|contracted procedure: k7004 
o|inlining procedure: k7087 
o|substituted constant variable: r751611845 
o|contracted procedure: k7681 
o|contracted procedure: k9843 
o|contracted procedure: k9893 
o|contracted procedure: k10115 
o|simplifications: ((let . 1)) 
o|replaced variables: 1 
o|removed binding forms: 25 
o|substituted constant variable: r708811980 
o|replaced variables: 1 
o|removed binding forms: 2 
o|removed conditional forms: 1 
o|removed binding forms: 2 
o|simplifications: ((if . 20) (##core#call . 735)) 
o|  call simplifications:
o|    scheme#list?	2
o|    scheme#apply	3
o|    scheme#set-cdr!
o|    scheme#caddr
o|    ##sys#call-with-values	5
o|    scheme#cddr	3
o|    scheme#string?
o|    scheme#number?
o|    scheme#cdar	3
o|    scheme#length
o|    scheme#write-char	2
o|    scheme#list	7
o|    scheme#set-car!	3
o|    scheme#symbol?	16
o|    ##sys#cons	17
o|    ##sys#list	20
o|    scheme#not	14
o|    scheme#caar	11
o|    scheme#eq?	21
o|    scheme#assq	42
o|    scheme#cdr	34
o|    scheme#memq	6
o|    ##sys#check-list	39
o|    scheme#pair?	61
o|    scheme#cadr	14
o|    ##sys#setslot	30
o|    ##sys#slot	122
o|    ##sys#make-structure	2
o|    scheme#values	6
o|    ##sys#check-structure	26
o|    ##sys#block-ref	14
o|    scheme#null?	35
o|    scheme#car	51
o|    scheme#cons	121
o|contracted procedure: k4494 
o|contracted procedure: k4520 
o|contracted procedure: k5295 
o|contracted procedure: k5304 
o|contracted procedure: k5313 
o|contracted procedure: k5322 
o|contracted procedure: k5331 
o|contracted procedure: k5340 
o|contracted procedure: k5349 
o|contracted procedure: k5358 
o|contracted procedure: k5367 
o|contracted procedure: k5376 
o|contracted procedure: k5385 
o|contracted procedure: k5394 
o|contracted procedure: k5403 
o|contracted procedure: k5421 
o|contracted procedure: k5439 
o|contracted procedure: k5457 
o|contracted procedure: k5475 
o|contracted procedure: k5484 
o|contracted procedure: k5493 
o|contracted procedure: k5502 
o|contracted procedure: k5511 
o|contracted procedure: k5520 
o|contracted procedure: k5562 
o|contracted procedure: k5558 
o|contracted procedure: k5612 
o|contracted procedure: k5628 
o|contracted procedure: k5644 
o|contracted procedure: k5647 
o|contracted procedure: k5650 
o|contracted procedure: k5658 
o|contracted procedure: k5666 
o|contracted procedure: k5621 
o|contracted procedure: k5625 
o|contracted procedure: k5685 
o|contracted procedure: k5693 
o|contracted procedure: k5699 
o|contracted procedure: k5709 
o|contracted procedure: k5767 
o|contracted procedure: k5722 
o|contracted procedure: k5761 
o|contracted procedure: k5725 
o|contracted procedure: k5755 
o|contracted procedure: k5728 
o|contracted procedure: k5749 
o|contracted procedure: k5731 
o|contracted procedure: k5734 
o|contracted procedure: k5776 
o|contracted procedure: k5803 
o|contracted procedure: k5835 
o|contracted procedure: k5846 
o|contracted procedure: k5855 
o|contracted procedure: k5861 
o|contracted procedure: k5891 
o|contracted procedure: k5901 
o|contracted procedure: k5905 
o|contracted procedure: k5931 
o|contracted procedure: k5448 
o|contracted procedure: k5941 
o|contracted procedure: k5947 
o|contracted procedure: k5965 
o|contracted procedure: k5977 
o|contracted procedure: k6003 
o|contracted procedure: k5999 
o|contracted procedure: k6011 
o|contracted procedure: k6054 
o|contracted procedure: k6086 
o|contracted procedure: k6082 
o|contracted procedure: k6101 
o|contracted procedure: k6097 
o|contracted procedure: k6116 
o|contracted procedure: k6153 
o|contracted procedure: k6266 
o|contracted procedure: k6225 
o|contracted procedure: k6260 
o|contracted procedure: k6228 
o|contracted procedure: k6254 
o|contracted procedure: k6231 
o|contracted procedure: k6248 
o|contracted procedure: k6234 
o|contracted procedure: k6245 
o|contracted procedure: k6241 
o|inlining procedure: "(modules.scm:250) make-module" 
o|contracted procedure: k6545 
o|contracted procedure: k6556 
o|contracted procedure: k6682 
o|contracted procedure: k6562 
o|contracted procedure: k6576 
o|contracted procedure: k6585 
o|contracted procedure: k6588 
o|contracted procedure: k6603 
o|contracted procedure: k6613 
o|contracted procedure: k6617 
o|contracted procedure: k6631 
o|contracted procedure: k6638 
o|contracted procedure: k6663 
o|contracted procedure: k6669 
o|contracted procedure: k6673 
o|contracted procedure: k6735 
o|contracted procedure: k6739 
o|contracted procedure: k6910 
o|contracted procedure: k6954 
o|contracted procedure: k6743 
o|contracted procedure: k6747 
o|contracted procedure: k6827 
o|contracted procedure: k6832 
o|contracted procedure: k6835 
o|contracted procedure: k6841 
o|contracted procedure: k6848 
o|contracted procedure: k6865 
o|contracted procedure: k6751 
o|contracted procedure: k6731 
o|contracted procedure: k6727 
o|contracted procedure: k6762 
o|contracted procedure: k6778 
o|contracted procedure: k6823 
o|contracted procedure: k6784 
o|contracted procedure: k6792 
o|contracted procedure: k6809 
o|contracted procedure: k6799 
o|contracted procedure: k6877 
o|contracted procedure: k6880 
o|contracted procedure: k6883 
o|contracted procedure: k6891 
o|contracted procedure: k6899 
o|contracted procedure: k6966 
o|contracted procedure: k6969 
o|contracted procedure: k6972 
o|contracted procedure: k6980 
o|contracted procedure: k6988 
o|contracted procedure: k6948 
o|contracted procedure: k6918 
o|contracted procedure: k6925 
o|contracted procedure: k6936 
o|contracted procedure: k6940 
o|contracted procedure: k7007 
o|contracted procedure: k7038 
o|contracted procedure: k7024 
o|contracted procedure: k7031 
o|contracted procedure: k7066 
o|contracted procedure: k7044 
o|contracted procedure: k7059 
o|contracted procedure: k7055 
o|contracted procedure: k7051 
o|contracted procedure: k7392 
o|contracted procedure: k7075 
o|contracted procedure: k7104 
o|contracted procedure: k7133 
o|contracted procedure: k7139 
o|contracted procedure: k7159 
o|contracted procedure: k7177 
o|contracted procedure: k7185 
o|contracted procedure: k7191 
o|contracted procedure: k7203 
o|contracted procedure: k7211 
o|contracted procedure: k7217 
o|contracted procedure: k7231 
o|contracted procedure: k7227 
o|contracted procedure: k7235 
o|contracted procedure: k7256 
o|contracted procedure: k7266 
o|contracted procedure: k7270 
o|contracted procedure: k7279 
o|contracted procedure: k7289 
o|contracted procedure: k7293 
o|contracted procedure: k7321 
o|contracted procedure: k7296 
o|contracted procedure: k7317 
o|inlining procedure: "(modules.scm:383) make-module" 
o|contracted procedure: k7330 
o|contracted procedure: k7333 
o|contracted procedure: k7336 
o|contracted procedure: k7344 
o|contracted procedure: k7352 
o|contracted procedure: k7148 
o|contracted procedure: k7364 
o|contracted procedure: k7367 
o|contracted procedure: k7370 
o|contracted procedure: k7378 
o|contracted procedure: k7386 
o|contracted procedure: k7112 
o|contracted procedure: k7081 
o|contracted procedure: k7097 
o|contracted procedure: k7087 
o|contracted procedure: k7122 
o|contracted procedure: k7506 
o|contracted procedure: k7401 
o|contracted procedure: k7418 
o|contracted procedure: k7414 
o|contracted procedure: k7422 
o|contracted procedure: k7446 
o|contracted procedure: k7454 
o|contracted procedure: k7457 
o|contracted procedure: k7466 
o|inlining procedure: "(modules.scm:408) make-module" 
o|contracted procedure: k7478 
o|contracted procedure: k7481 
o|contracted procedure: k7484 
o|contracted procedure: k7492 
o|contracted procedure: k7500 
o|contracted procedure: k7521 
o|contracted procedure: k7515 
o|contracted procedure: k7546 
o|contracted procedure: k7596 
o|contracted procedure: k7549 
o|contracted procedure: k7558 
o|contracted procedure: k7585 
o|contracted procedure: k7561 
o|contracted procedure: k7599 
o|contracted procedure: k7620 
o|contracted procedure: k7639 
o|contracted procedure: k7653 
o|contracted procedure: k7660 
o|contracted procedure: k7759 
o|contracted procedure: k7697 
o|contracted procedure: k7728 
o|contracted procedure: k7740 
o|contracted procedure: k7750 
o|contracted procedure: k7754 
o|contracted procedure: k7762 
o|contracted procedure: k7785 
o|contracted procedure: k7795 
o|contracted procedure: k7799 
o|contracted procedure: k7805 
o|contracted procedure: k7814 
o|contracted procedure: k7849 
o|contracted procedure: k7872 
o|contracted procedure: k7875 
o|contracted procedure: k7897 
o|contracted procedure: k5466 
o|contracted procedure: k7926 
o|contracted procedure: k7936 
o|contracted procedure: k7940 
o|contracted procedure: k7957 
o|contracted procedure: k7960 
o|contracted procedure: k7963 
o|contracted procedure: k7971 
o|contracted procedure: k7979 
o|contracted procedure: k7843 
o|contracted procedure: k7822 
o|contracted procedure: k7825 
o|contracted procedure: k6345 
o|contracted procedure: k6357 
o|contracted procedure: k6529 
o|contracted procedure: k6363 
o|contracted procedure: k6375 
o|contracted procedure: k6384 
o|contracted procedure: k6391 
o|contracted procedure: k6521 
o|contracted procedure: k6397 
o|contracted procedure: k6410 
o|contracted procedure: k6432 
o|contracted procedure: k6436 
o|contracted procedure: k6450 
o|contracted procedure: k6496 
o|contracted procedure: k6461 
o|contracted procedure: k6478 
o|contracted procedure: k6468 
o|contracted procedure: k6492 
o|contracted procedure: k7994 
o|contracted procedure: k8004 
o|contracted procedure: k8008 
o|contracted procedure: k8127 
o|contracted procedure: k8012 
o|contracted procedure: k8021 
o|contracted procedure: k8024 
o|contracted procedure: k8121 
o|contracted procedure: k8027 
o|contracted procedure: k8033 
o|contracted procedure: k8055 
o|inlining procedure: k8058 
o|contracted procedure: k8067 
o|inlining procedure: k8058 
o|contracted procedure: k8085 
o|contracted procedure: k8107 
o|contracted procedure: k8118 
o|contracted procedure: k8130 
o|contracted procedure: k8153 
o|contracted procedure: k8179 
o|contracted procedure: k8188 
o|contracted procedure: k8191 
o|contracted procedure: k8194 
o|contracted procedure: k8202 
o|contracted procedure: k8210 
o|contracted procedure: k7629 
o|contracted procedure: k8406 
o|contracted procedure: k8425 
o|contracted procedure: k8434 
o|contracted procedure: k8462 
o|contracted procedure: k8504 
o|contracted procedure: k9272 
o|contracted procedure: k8517 
o|contracted procedure: k8523 
o|contracted procedure: k8545 
o|contracted procedure: k8563 
o|contracted procedure: k8571 
o|contracted procedure: k8585 
o|contracted procedure: k8581 
o|contracted procedure: k8594 
o|contracted procedure: k8604 
o|contracted procedure: k8608 
o|contracted procedure: k8669 
o|contracted procedure: k8611 
o|contracted procedure: k8623 
o|contracted procedure: k8627 
o|contracted procedure: k8633 
o|contracted procedure: k8645 
o|contracted procedure: k8649 
o|contracted procedure: k8661 
o|contracted procedure: k8673 
o|contracted procedure: k8695 
o|contracted procedure: k8713 
o|contracted procedure: k8725 
o|contracted procedure: k8733 
o|contracted procedure: k8747 
o|contracted procedure: k8743 
o|contracted procedure: k8756 
o|contracted procedure: k8766 
o|contracted procedure: k8770 
o|contracted procedure: k8811 
o|contracted procedure: k8773 
o|contracted procedure: k8785 
o|contracted procedure: k8793 
o|contracted procedure: k8805 
o|contracted procedure: k8852 
o|contracted procedure: k8814 
o|contracted procedure: k8826 
o|contracted procedure: k8834 
o|contracted procedure: k8846 
o|contracted procedure: k8856 
o|contracted procedure: k8878 
o|contracted procedure: k8896 
o|contracted procedure: k8908 
o|contracted procedure: k8916 
o|contracted procedure: k8919 
o|contracted procedure: k8925 
o|contracted procedure: k8939 
o|contracted procedure: k8935 
o|contracted procedure: k8948 
o|contracted procedure: k8958 
o|contracted procedure: k8962 
o|contracted procedure: k8971 
o|contracted procedure: k8993 
o|contracted procedure: k8989 
o|contracted procedure: k8974 
o|contracted procedure: k8977 
o|contracted procedure: k8985 
o|contracted procedure: k9049 
o|contracted procedure: k8999 
o|contracted procedure: k9011 
o|contracted procedure: k9027 
o|contracted procedure: k9031 
o|contracted procedure: k9023 
o|contracted procedure: k9015 
o|contracted procedure: k9043 
o|contracted procedure: k9102 
o|contracted procedure: k9052 
o|contracted procedure: k9064 
o|contracted procedure: k9080 
o|contracted procedure: k9084 
o|contracted procedure: k9076 
o|contracted procedure: k9068 
o|contracted procedure: k9096 
o|contracted procedure: k9106 
o|contracted procedure: k9128 
o|contracted procedure: k9162 
o|contracted procedure: k9169 
o|contracted procedure: k9173 
o|contracted procedure: k9176 
o|contracted procedure: k9183 
o|contracted procedure: k9186 
o|contracted procedure: k9198 
o|contracted procedure: k9201 
o|contracted procedure: k9204 
o|contracted procedure: k9212 
o|contracted procedure: k9220 
o|contracted procedure: k9232 
o|contracted procedure: k9235 
o|contracted procedure: k9238 
o|contracted procedure: k9246 
o|contracted procedure: k9254 
o|contracted procedure: k9261 
o|contracted procedure: k9298 
o|contracted procedure: k9307 
o|contracted procedure: k9310 
o|contracted procedure: k9322 
o|contracted procedure: k9332 
o|contracted procedure: k9336 
o|contracted procedure: k9359 
o|contracted procedure: k9365 
o|contracted procedure: k9389 
o|contracted procedure: k9385 
o|contracted procedure: k9375 
o|contracted procedure: k9396 
o|contracted procedure: k9432 
o|contracted procedure: k9404 
o|contracted procedure: k9428 
o|contracted procedure: k9422 
o|contracted procedure: k9410 
o|contracted procedure: k9439 
o|contracted procedure: k9493 
o|contracted procedure: k9511 
o|contracted procedure: k9518 
o|contracted procedure: k9530 
o|contracted procedure: k9552 
o|contracted procedure: k9548 
o|contracted procedure: k9533 
o|contracted procedure: k9536 
o|contracted procedure: k9544 
o|contracted procedure: k9564 
o|contracted procedure: k9586 
o|contracted procedure: k9582 
o|contracted procedure: k9567 
o|contracted procedure: k9570 
o|contracted procedure: k9578 
o|contracted procedure: k9696 
o|contracted procedure: k9611 
o|contracted procedure: k9615 
o|contracted procedure: k9622 
o|contracted procedure: k9634 
o|contracted procedure: k9656 
o|contracted procedure: k9652 
o|contracted procedure: k9637 
o|contracted procedure: k9640 
o|contracted procedure: k9648 
o|contracted procedure: k9668 
o|contracted procedure: k9690 
o|contracted procedure: k9686 
o|contracted procedure: k9671 
o|contracted procedure: k9674 
o|contracted procedure: k9682 
o|contracted procedure: k9708 
o|contracted procedure: k9718 
o|contracted procedure: k9722 
o|contracted procedure: k9731 
o|contracted procedure: k9741 
o|contracted procedure: k9745 
o|contracted procedure: k5430 
o|contracted procedure: k9763 
o|contracted procedure: k5412 
o|contracted procedure: k9778 
o|contracted procedure: k9792 
o|contracted procedure: k9796 
o|contracted procedure: k6165 
o|contracted procedure: k6187 
o|contracted procedure: k6183 
o|contracted procedure: k6198 
o|contracted procedure: k6194 
o|contracted procedure: k6208 
o|contracted procedure: k6216 
o|contracted procedure: k9846 
o|contracted procedure: k9854 
o|contracted procedure: k9863 
o|contracted procedure: k9905 
o|contracted procedure: k9911 
o|contracted procedure: k10091 
o|contracted procedure: k9920 
o|contracted procedure: k9935 
o|contracted procedure: k10087 
o|contracted procedure: k9941 
o|contracted procedure: k9947 
o|contracted procedure: k9953 
o|contracted procedure: k10083 
o|contracted procedure: k9968 
o|contracted procedure: k10079 
o|contracted procedure: k9977 
o|contracted procedure: k9994 
o|contracted procedure: k10017 
o|contracted procedure: k10023 
o|contracted procedure: k10030 
o|contracted procedure: k10044 
o|contracted procedure: k10055 
o|contracted procedure: k10073 
o|contracted procedure: k10061 
o|contracted procedure: k10107 
o|contracted procedure: k10103 
o|contracted procedure: k10127 
o|contracted procedure: k10130 
o|contracted procedure: k10142 
o|contracted procedure: k10150 
o|contracted procedure: k10153 
o|contracted procedure: k10146 
o|contracted procedure: k10165 
o|contracted procedure: k10187 
o|contracted procedure: k10183 
o|contracted procedure: k10168 
o|contracted procedure: k10171 
o|contracted procedure: k10179 
o|contracted procedure: k10216 
o|contracted procedure: k10209 
o|contracted procedure: k10205 
o|contracted procedure: k10201 
o|contracted procedure: k10225 
o|contracted procedure: k10237 
o|contracted procedure: k10240 
o|contracted procedure: k10280 
o|contracted procedure: k10246 
o|contracted procedure: k10250 
o|contracted procedure: k10263 
o|contracted procedure: k10286 
o|contracted procedure: k10292 
o|contracted procedure: k10295 
o|contracted procedure: k10299 
o|contracted procedure: k10302 
o|contracted procedure: k10315 
o|contracted procedure: k10327 
o|contracted procedure: k10345 
o|contracted procedure: k10377 
o|contracted procedure: k10350 
o|contracted procedure: k10356 
o|contracted procedure: k10363 
o|contracted procedure: k10383 
o|contracted procedure: k10392 
o|contracted procedure: k10415 
o|contracted procedure: k10428 
o|contracted procedure: k10440 
o|contracted procedure: k10443 
o|contracted procedure: k10446 
o|contracted procedure: k10454 
o|contracted procedure: k10462 
o|contracted procedure: k10474 
o|contracted procedure: k10484 
o|contracted procedure: k10488 
o|contracted procedure: k10605 
o|contracted procedure: k10579 
o|contracted procedure: k10588 
o|contracted procedure: k10598 
o|contracted procedure: k10620 
o|contracted procedure: k10628 
o|contracted procedure: k10640 
o|contracted procedure: k10643 
o|contracted procedure: k10646 
o|contracted procedure: k10654 
o|contracted procedure: k10662 
o|contracted procedure: k10674 
o|contracted procedure: k10682 
o|contracted procedure: k10694 
o|contracted procedure: k10697 
o|contracted procedure: k10700 
o|contracted procedure: k10708 
o|contracted procedure: k10716 
o|contracted procedure: k10728 
o|contracted procedure: k10736 
o|contracted procedure: k10748 
o|contracted procedure: k10751 
o|contracted procedure: k10754 
o|contracted procedure: k10762 
o|contracted procedure: k10770 
o|contracted procedure: k10782 
o|contracted procedure: k10790 
o|contracted procedure: k10802 
o|contracted procedure: k10805 
o|contracted procedure: k10808 
o|contracted procedure: k10816 
o|contracted procedure: k10824 
o|contracted procedure: k10836 
o|contracted procedure: k10844 
o|contracted procedure: k10856 
o|contracted procedure: k10859 
o|contracted procedure: k10862 
o|contracted procedure: k10870 
o|contracted procedure: k10878 
o|contracted procedure: k10890 
o|contracted procedure: k10898 
o|contracted procedure: k10910 
o|contracted procedure: k10913 
o|contracted procedure: k10916 
o|contracted procedure: k10924 
o|contracted procedure: k10932 
o|contracted procedure: k10944 
o|contracted procedure: k10952 
o|contracted procedure: k10964 
o|contracted procedure: k10967 
o|contracted procedure: k10970 
o|contracted procedure: k10978 
o|contracted procedure: k10986 
o|contracted procedure: k10998 
o|contracted procedure: k11006 
o|contracted procedure: k11018 
o|contracted procedure: k11021 
o|contracted procedure: k11024 
o|contracted procedure: k11032 
o|contracted procedure: k11040 
o|contracted procedure: k11052 
o|contracted procedure: k11060 
o|contracted procedure: k11072 
o|contracted procedure: k11075 
o|contracted procedure: k11078 
o|contracted procedure: k11086 
o|contracted procedure: k11094 
o|contracted procedure: k11106 
o|contracted procedure: k11114 
o|contracted procedure: k11126 
o|contracted procedure: k11129 
o|contracted procedure: k11132 
o|contracted procedure: k11140 
o|contracted procedure: k11148 
o|contracted procedure: k11160 
o|contracted procedure: k11168 
o|contracted procedure: k11180 
o|contracted procedure: k11183 
o|contracted procedure: k11186 
o|contracted procedure: k11194 
o|contracted procedure: k11202 
o|contracted procedure: k11214 
o|contracted procedure: k11222 
o|contracted procedure: k11234 
o|contracted procedure: k11237 
o|contracted procedure: k11240 
o|contracted procedure: k11248 
o|contracted procedure: k11256 
o|contracted procedure: k11268 
o|contracted procedure: k11276 
o|contracted procedure: k11288 
o|contracted procedure: k11291 
o|contracted procedure: k11294 
o|contracted procedure: k11302 
o|contracted procedure: k11310 
o|simplifications: ((let . 105)) 
o|removed binding forms: 614 
o|inlining procedure: "(modules.scm:120) module-sexports" 
o|inlining procedure: "(modules.scm:119) module-vexports" 
o|inlining procedure: "(modules.scm:118) module-export-list" 
o|removed side-effect free assignment to unused variable: make-module 
o|inlining procedure: "(modules.scm:160) module-saved-environments" 
o|inlining procedure: "(modules.scm:157) set-module-saved-environments!" 
o|inlining procedure: "(modules.scm:179) set-module-exist-list!" 
o|inlining procedure: "(modules.scm:178) set-module-sexports!" 
o|inlining procedure: "(modules.scm:178) module-sexports" 
o|inlining procedure: "(modules.scm:169) module-exist-list" 
o|inlining procedure: "(modules.scm:180) set-module-export-list!" 
o|inlining procedure: "(modules.scm:167) module-export-list" 
o|inlining procedure: "(modules.scm:186) module-meta-expressions" 
o|inlining procedure: "(modules.scm:207) set-module-defined-list!" 
o|inlining procedure: "(modules.scm:210) module-defined-list" 
o|inlining procedure: "(modules.scm:204) set-module-exist-list!" 
o|inlining procedure: "(modules.scm:204) module-exist-list" 
o|inlining procedure: "(modules.scm:200) module-name" 
o|inlining procedure: "(modules.scm:196) module-export-list" 
o|inlining procedure: "(modules.scm:227) set-module-defined-syntax-list!" 
o|inlining procedure: "(modules.scm:229) module-defined-syntax-list" 
o|inlining procedure: "(modules.scm:223) set-module-defined-list!" 
o|inlining procedure: "(modules.scm:226) module-defined-list" 
o|inlining procedure: "(modules.scm:217) module-name" 
o|inlining procedure: "(modules.scm:214) module-export-list" 
o|inlining procedure: "(modules.scm:233) set-module-defined-syntax-list!" 
o|inlining procedure: "(modules.scm:235) module-defined-syntax-list" 
o|substituted constant variable: iexports88212619 
o|inlining procedure: "(modules.scm:352) module-defined-syntax-list" 
o|inlining procedure: "(modules.scm:338) module-vexports" 
o|inlining procedure: "(modules.scm:337) module-iexports" 
o|inlining procedure: "(modules.scm:331) module-library" 
o|inlining procedure: "(modules.scm:330) module-name" 
o|inlining procedure: "(modules.scm:327) module-meta-expressions" 
o|inlining procedure: "(modules.scm:319) module-meta-import-forms" 
o|inlining procedure: "(modules.scm:318) module-sexports" 
o|inlining procedure: "(modules.scm:317) module-import-forms" 
o|inlining procedure: "(modules.scm:316) module-name" 
o|inlining procedure: "(modules.scm:315) module-defined-list" 
o|inlining procedure: "(modules.scm:399) set-module-saved-environments!" 
o|substituted constant variable: explist87912639 
o|inlining procedure: "(modules.scm:420) set-module-saved-environments!" 
o|inlining procedure: "(modules.scm:424) module-sexports" 
o|inlining procedure: "(modules.scm:423) module-vexports" 
o|substituted constant variable: explist87912650 
o|substituted constant variable: iexports88212653 
o|inlining procedure: "(modules.scm:435) module-exist-list" 
o|inlining procedure: "(modules.scm:434) module-export-list" 
o|inlining procedure: "(modules.scm:554) set-module-saved-environments!" 
o|inlining procedure: "(modules.scm:551) set-module-iexports!" 
o|inlining procedure: "(modules.scm:553) module-iexports" 
o|inlining procedure: "(modules.scm:550) set-module-sexports!" 
o|inlining procedure: "(modules.scm:257) module-defined-list" 
o|inlining procedure: "(modules.scm:256) module-name" 
o|inlining procedure: "(modules.scm:255) module-export-list" 
o|inlining procedure: "(modules.scm:457) module-sexports" 
o|inlining procedure: "(modules.scm:454) module-defined-syntax-list" 
o|inlining procedure: "(modules.scm:451) module-exist-list" 
o|inlining procedure: "(modules.scm:450) module-defined-list" 
o|inlining procedure: "(modules.scm:449) module-name" 
o|inlining procedure: "(modules.scm:448) module-export-list" 
o|inlining procedure: "(modules.scm:608) module-iexports" 
o|inlining procedure: "(modules.scm:607) module-sexports" 
o|inlining procedure: "(modules.scm:606) module-vexports" 
o|inlining procedure: "(modules.scm:605) module-name" 
o|inlining procedure: "(modules.scm:604) module-library" 
o|inlining procedure: "(modules.scm:603) module-name" 
o|inlining procedure: "(modules.scm:755) set-module-iexports!" 
o|inlining procedure: "(modules.scm:757) module-iexports" 
o|inlining procedure: "(modules.scm:742) set-module-exist-list!" 
o|inlining procedure: "(modules.scm:744) module-exist-list" 
o|inlining procedure: "(modules.scm:741) set-module-sexports!" 
o|inlining procedure: "(modules.scm:741) module-sexports" 
o|inlining procedure: "(modules.scm:748) set-module-export-list!" 
o|inlining procedure: "(modules.scm:751) module-export-list" 
o|inlining procedure: "(modules.scm:739) module-export-list" 
o|inlining procedure: "(modules.scm:715) module-meta-import-forms" 
o|inlining procedure: "(modules.scm:718) module-import-forms" 
o|inlining procedure: "(modules.scm:776) module-name" 
o|inlining procedure: "(modules.scm:776) module-name" 
o|inlining procedure: k6212 
o|inlining procedure: k6212 
o|inlining procedure: "(modules.scm:877) module-sexports" 
o|inlining procedure: "(modules.scm:876) module-vexports" 
o|inlining procedure: "(modules.scm:1123) module-saved-environments" 
o|replaced variables: 232 
o|removed side-effect free assignment to unused variable: module-library 
o|removed side-effect free assignment to unused variable: module-export-list 
o|removed side-effect free assignment to unused variable: set-module-export-list! 
o|removed side-effect free assignment to unused variable: module-defined-list 
o|removed side-effect free assignment to unused variable: set-module-defined-list! 
o|removed side-effect free assignment to unused variable: module-exist-list 
o|removed side-effect free assignment to unused variable: set-module-exist-list! 
o|removed side-effect free assignment to unused variable: module-defined-syntax-list 
o|removed side-effect free assignment to unused variable: set-module-defined-syntax-list! 
o|removed side-effect free assignment to unused variable: module-import-forms 
o|removed side-effect free assignment to unused variable: module-meta-import-forms 
o|removed side-effect free assignment to unused variable: module-meta-expressions 
o|removed side-effect free assignment to unused variable: module-vexports 
o|removed side-effect free assignment to unused variable: module-sexports 
o|removed side-effect free assignment to unused variable: set-module-sexports! 
o|removed side-effect free assignment to unused variable: module-iexports 
o|removed side-effect free assignment to unused variable: set-module-iexports! 
o|removed side-effect free assignment to unused variable: module-saved-environments 
o|removed side-effect free assignment to unused variable: set-module-saved-environments! 
o|replaced variables: 146 
o|removed binding forms: 138 
o|inlining procedure: k5542 
o|contracted procedure: k5662 
o|inlining procedure: k5882 
o|inlining procedure: k6038 
o|contracted procedure: k6237 
o|inlining procedure: k7018 
o|contracted procedure: k7165 
o|contracted procedure: k7407 
o|inlining procedure: k7442 
o|inlining procedure: k7917 
o|inlining procedure: k8137 
o|inlining procedure: k8492 
o|inlining procedure: k9490 
o|inlining procedure: k9597 
o|inlining procedure: k9759 
o|inlining procedure: k9774 
o|inlining procedure: k9823 
o|inlining procedure: k982311913 
o|inlining procedure: k10370 
o|inlining procedure: k10602 
o|replaced variables: 3 
o|removed binding forms: 141 
o|contracted procedure: k5534 
o|contracted procedure: k5538 
o|contracted procedure: k5829 
o|contracted procedure: k5838 
o|contracted procedure: k5935 
o|contracted procedure: k6045 
o|contracted procedure: k6007 
o|contracted procedure: k6015 
o|contracted procedure: k6126 
o|contracted procedure: k6063 
o|contracted procedure: k6090 
o|contracted procedure: k6105 
o|contracted procedure: k6143 
o|contracted procedure: k6688 
o|contracted procedure: k6691 
o|contracted procedure: k6694 
o|contracted procedure: k6697 
o|contracted procedure: k6700 
o|contracted procedure: k6999 
o|contracted procedure: k6995 
o|contracted procedure: k6951 
o|contracted procedure: k6906 
o|contracted procedure: k6769 
o|contracted procedure: k7438 
o|contracted procedure: k7530 
o|contracted procedure: k7608 
o|contracted procedure: k7611 
o|contracted procedure: k7614 
o|contracted procedure: k7617 
o|contracted procedure: k7636 
o|contracted procedure: k6275 
o|contracted procedure: k6278 
o|contracted procedure: k6281 
o|contracted procedure: k8472 
o|contracted procedure: k8476 
o|contracted procedure: k8480 
o|contracted procedure: k8484 
o|contracted procedure: k8488 
o|contracted procedure: k9473 
o|contracted procedure: k9507 
o|contracted procedure: k9608 
o|contracted procedure: k10374 
o|removed binding forms: 59 
o|replaced variables: 37 
o|removed binding forms: 18 
o|direct leaf routine/allocation: g10141015 3 
o|direct leaf routine/allocation: g31373146 0 
o|direct leaf routine/allocation: g30993108 0 
o|direct leaf routine/allocation: g30613070 0 
o|direct leaf routine/allocation: g30233032 0 
o|direct leaf routine/allocation: g29852994 0 
o|direct leaf routine/allocation: g29472956 0 
o|direct leaf routine/allocation: g29092918 0 
o|direct leaf routine/allocation: g28712880 0 
o|direct leaf routine/allocation: g28332842 0 
o|direct leaf routine/allocation: g27952804 0 
o|direct leaf routine/allocation: g27572766 0 
o|direct leaf routine/allocation: g27192728 0 
o|direct leaf routine/allocation: g26812690 0 
o|contracted procedure: "(modules.scm:1035) k10658" 
o|contracted procedure: "(modules.scm:1035) k10712" 
o|contracted procedure: "(modules.scm:1035) k10766" 
o|contracted procedure: "(modules.scm:1035) k10820" 
o|contracted procedure: "(modules.scm:1035) k10874" 
o|contracted procedure: "(modules.scm:1035) k10928" 
o|contracted procedure: "(modules.scm:1035) k10982" 
o|contracted procedure: "(modules.scm:1035) k11036" 
o|contracted procedure: "(modules.scm:1035) k11090" 
o|contracted procedure: "(modules.scm:1035) k11144" 
o|contracted procedure: "(modules.scm:1035) k11198" 
o|contracted procedure: "(modules.scm:1035) k11252" 
o|contracted procedure: "(modules.scm:1035) k11306" 
o|removed binding forms: 13 
o|direct leaf routine with hoistable closures/allocation: g9981005 (g10141015) 3 
o|contracted procedure: "(modules.scm:172) k5894" 
o|removed binding forms: 2 
x|eliminated type checks:
x|  C_i_check_list_2:	13
o|customizable procedures: (map-loop26752700 map-loop27132738 map-loop27512776 map-loop27892814 map-loop28272852 map-loop28652890 map-loop29032928 map-loop29412966 map-loop29793004 map-loop30173042 map-loop30553080 map-loop30933118 map-loop31313156 g26172624 for-each-loop26162631 map-loop26382656 k10359 loop2580 merr2553 match-functor-argument loop22587 map-loop25562573 err2545 loop22516 k10000 loop2504 iface2494 err2493 g24782479 mrename2459 g24672468 g10901091 k6176 g22782295 for-each-loop22772305 g22882310 for-each-loop22872318 map-loop23842401 map-loop24102427 map-loop23302347 map-loop23562373 k9445 g22172224 for-each-loop22162251 map-loop21492166 map-loop21752192 tostr1835 g21092110 loop2037 g21042105 loop2046 map-loop20702087 g20582065 for-each-loop20572094 g20042005 loop1958 g19992000 loop1967 g19791986 for-each-loop19781989 g19251926 g19211922 loop1888 g19011908 for-each-loop19001911 warn1834 loop1849 module-imports1845 find-module/import-library map-loop15461564 loop1572 k8061 k8073 k8045 loop1580 g16011608 for-each-loop16001673 g11551156 g11481149 k6422 warn1121 loop21139 loop1133 map-loop16811706 g17171726 for-each-loop17161733 g16171624 for-each-loop16161628 g16481655 for-each-loop16471660 k7537 k7567 loop1517 g14751484 map-loop14691490 map-loop13461364 map-loop13741392 k7299 g14071424 for-each-loop14061430 g14171435 for-each-loop14161441 merge-se k6707 k6715 k6984 map-loop12391263 g12781287 map-loop12721305 loop1312 k6755 k6565 lp1202 g11861193 for-each-loop11851196 loop1172 find-export module-rename delete check-for-redef for-each-loop9971017 g981982 k5785 g943944 loop934 map-loop899917 loop254) 
o|calls to known targets: 296 
o|identified direct recursive calls: f_5639 1 
o|identified direct recursive calls: f_5886 1 
o|identified direct recursive calls: f_6773 1 
o|identified direct recursive calls: f_7541 1 
o|identified direct recursive calls: f_6352 1 
o|identified direct recursive calls: f_8016 1 
o|identified direct recursive calls: f_8558 1 
o|identified direct recursive calls: f_8720 1 
o|identified direct recursive calls: f_8708 1 
o|identified direct recursive calls: f_8966 1 
o|identified direct recursive calls: f_8903 1 
o|identified direct recursive calls: f_8891 1 
o|identified direct recursive calls: f_9525 1 
o|identified direct recursive calls: f_9559 1 
o|identified direct recursive calls: f_9629 1 
o|identified direct recursive calls: f_9663 1 
o|identified direct recursive calls: f_10039 1 
o|identified direct recursive calls: f_9930 2 
o|identified direct recursive calls: f_10160 1 
o|identified direct recursive calls: f_10635 1 
o|identified direct recursive calls: f_10689 1 
o|identified direct recursive calls: f_10743 1 
o|identified direct recursive calls: f_10797 1 
o|identified direct recursive calls: f_10851 1 
o|identified direct recursive calls: f_10905 1 
o|identified direct recursive calls: f_10959 1 
o|identified direct recursive calls: f_11013 1 
o|identified direct recursive calls: f_11067 1 
o|identified direct recursive calls: f_11121 1 
o|identified direct recursive calls: f_11175 1 
o|identified direct recursive calls: f_11229 1 
o|identified direct recursive calls: f_11283 1 
o|fast box initializations: 69 
o|fast global references: 34 
o|fast global assignments: 8 
o|dropping unused closure argument: f_10337 
o|dropping unused closure argument: f_4483 
o|dropping unused closure argument: f_5939 
o|dropping unused closure argument: f_6533 
o|dropping unused closure argument: f_7528 
o|dropping unused closure argument: f_8357 
o|dropping unused closure argument: f_8387 
o|dropping unused closure argument: f_9782 
*/
/* end of file */
