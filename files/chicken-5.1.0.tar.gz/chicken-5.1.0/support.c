/* Generated from support.scm by the CHICKEN compiler
   http://www.call-cc.org
   Version 5.1.0rc1 (prerelease) (rev 7358d2e5)
   linux-unix-gnu-x86-64 [ 64bit dload ptables ]
   command line: support.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -consult-types-file ./types.db -no-lambda-info -no-trace -emit-import-library chicken.compiler.support -output-file support.c
   unit: support
   uses: library eval expand data-structures extras file internal pathname port
*/
#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_file_toplevel)
C_externimport void C_ccall C_file_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_internal_toplevel)
C_externimport void C_ccall C_internal_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_pathname_toplevel)
C_externimport void C_ccall C_pathname_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_port_toplevel)
C_externimport void C_ccall C_port_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[529];
static double C_possibly_force_alignment;


#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
C_regparm static C_word C_fcall stub4065(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from k7123 */
C_regparm static C_word C_fcall stub915(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k7116 */
C_regparm static C_word C_fcall stub910(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(f18834)
static void C_ccall f18834(C_word c,C_word *av) C_noret;
C_noret_decl(f_10029)
static void C_ccall f_10029(C_word c,C_word *av) C_noret;
C_noret_decl(f_10031)
static void C_fcall f_10031(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10056)
static void C_ccall f_10056(C_word c,C_word *av) C_noret;
C_noret_decl(f_10087)
static void C_fcall f_10087(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10099)
static void C_ccall f_10099(C_word c,C_word *av) C_noret;
C_noret_decl(f_10103)
static void C_ccall f_10103(C_word c,C_word *av) C_noret;
C_noret_decl(f_10126)
static void C_ccall f_10126(C_word c,C_word *av) C_noret;
C_noret_decl(f_10137)
static void C_fcall f_10137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10144)
static void C_ccall f_10144(C_word c,C_word *av) C_noret;
C_noret_decl(f_10155)
static void C_ccall f_10155(C_word c,C_word *av) C_noret;
C_noret_decl(f_10157)
static void C_fcall f_10157(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10182)
static void C_ccall f_10182(C_word c,C_word *av) C_noret;
C_noret_decl(f_10212)
static void C_ccall f_10212(C_word c,C_word *av) C_noret;
C_noret_decl(f_10214)
static void C_fcall f_10214(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10239)
static void C_ccall f_10239(C_word c,C_word *av) C_noret;
C_noret_decl(f_10253)
static void C_ccall f_10253(C_word c,C_word *av) C_noret;
C_noret_decl(f_10263)
static void C_ccall f_10263(C_word c,C_word *av) C_noret;
C_noret_decl(f_10265)
static void C_fcall f_10265(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10290)
static void C_ccall f_10290(C_word c,C_word *av) C_noret;
C_noret_decl(f_10363)
static void C_ccall f_10363(C_word c,C_word *av) C_noret;
C_noret_decl(f_10369)
static void C_fcall f_10369(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10395)
static void C_ccall f_10395(C_word c,C_word *av) C_noret;
C_noret_decl(f_10399)
static void C_ccall f_10399(C_word c,C_word *av) C_noret;
C_noret_decl(f_10415)
static void C_ccall f_10415(C_word c,C_word *av) C_noret;
C_noret_decl(f_10421)
static void C_ccall f_10421(C_word c,C_word *av) C_noret;
C_noret_decl(f_10427)
static void C_ccall f_10427(C_word c,C_word *av) C_noret;
C_noret_decl(f_10433)
static void C_ccall f_10433(C_word c,C_word *av) C_noret;
C_noret_decl(f_10437)
static void C_ccall f_10437(C_word c,C_word *av) C_noret;
C_noret_decl(f_10440)
static void C_ccall f_10440(C_word c,C_word *av) C_noret;
C_noret_decl(f_10447)
static void C_ccall f_10447(C_word c,C_word *av) C_noret;
C_noret_decl(f_10449)
static void C_fcall f_10449(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10479)
static void C_ccall f_10479(C_word c,C_word *av) C_noret;
C_noret_decl(f_10507)
static void C_ccall f_10507(C_word c,C_word *av) C_noret;
C_noret_decl(f_10531)
static void C_ccall f_10531(C_word c,C_word *av) C_noret;
C_noret_decl(f_10553)
static void C_fcall f_10553(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10578)
static void C_ccall f_10578(C_word c,C_word *av) C_noret;
C_noret_decl(f_10600)
static void C_ccall f_10600(C_word c,C_word *av) C_noret;
C_noret_decl(f_10608)
static void C_fcall f_10608(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10659)
static void C_ccall f_10659(C_word c,C_word *av) C_noret;
C_noret_decl(f_10666)
static void C_ccall f_10666(C_word c,C_word *av) C_noret;
C_noret_decl(f_10669)
static void C_ccall f_10669(C_word c,C_word *av) C_noret;
C_noret_decl(f_10698)
static void C_ccall f_10698(C_word c,C_word *av) C_noret;
C_noret_decl(f_10706)
static void C_ccall f_10706(C_word c,C_word *av) C_noret;
C_noret_decl(f_10722)
static void C_ccall f_10722(C_word c,C_word *av) C_noret;
C_noret_decl(f_10725)
static void C_ccall f_10725(C_word c,C_word *av) C_noret;
C_noret_decl(f_10731)
static void C_ccall f_10731(C_word c,C_word *av) C_noret;
C_noret_decl(f_10751)
static void C_ccall f_10751(C_word c,C_word *av) C_noret;
C_noret_decl(f_10774)
static void C_ccall f_10774(C_word c,C_word *av) C_noret;
C_noret_decl(f_10779)
static void C_fcall f_10779(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10783)
static void C_ccall f_10783(C_word c,C_word *av) C_noret;
C_noret_decl(f_10786)
static void C_ccall f_10786(C_word c,C_word *av) C_noret;
C_noret_decl(f_10792)
static void C_ccall f_10792(C_word c,C_word *av) C_noret;
C_noret_decl(f_10795)
static void C_ccall f_10795(C_word c,C_word *av) C_noret;
C_noret_decl(f_10812)
static void C_fcall f_10812(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10822)
static void C_ccall f_10822(C_word c,C_word *av) C_noret;
C_noret_decl(f_10824)
static void C_fcall f_10824(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10849)
static void C_ccall f_10849(C_word c,C_word *av) C_noret;
C_noret_decl(f_10860)
static void C_ccall f_10860(C_word c,C_word *av) C_noret;
C_noret_decl(f_10868)
static void C_ccall f_10868(C_word c,C_word *av) C_noret;
C_noret_decl(f_10876)
static void C_ccall f_10876(C_word c,C_word *av) C_noret;
C_noret_decl(f_10889)
static void C_ccall f_10889(C_word c,C_word *av) C_noret;
C_noret_decl(f_10891)
static void C_fcall f_10891(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10939)
static void C_fcall f_10939(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10964)
static void C_ccall f_10964(C_word c,C_word *av) C_noret;
C_noret_decl(f_10983)
static void C_ccall f_10983(C_word c,C_word *av) C_noret;
C_noret_decl(f_10988)
static void C_fcall f_10988(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word *av) C_noret;
C_noret_decl(f_11000)
static void C_fcall f_11000(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11025)
static void C_ccall f_11025(C_word c,C_word *av) C_noret;
C_noret_decl(f_11047)
static void C_fcall f_11047(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11095)
static void C_ccall f_11095(C_word c,C_word *av) C_noret;
C_noret_decl(f_11101)
static void C_fcall f_11101(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11115)
static void C_ccall f_11115(C_word c,C_word *av) C_noret;
C_noret_decl(f_11119)
static void C_ccall f_11119(C_word c,C_word *av) C_noret;
C_noret_decl(f_11125)
static void C_ccall f_11125(C_word c,C_word *av) C_noret;
C_noret_decl(f_11163)
static void C_ccall f_11163(C_word c,C_word *av) C_noret;
C_noret_decl(f_11167)
static void C_ccall f_11167(C_word c,C_word *av) C_noret;
C_noret_decl(f_11170)
static void C_ccall f_11170(C_word c,C_word *av) C_noret;
C_noret_decl(f_11173)
static void C_ccall f_11173(C_word c,C_word *av) C_noret;
C_noret_decl(f_11208)
static void C_ccall f_11208(C_word c,C_word *av) C_noret;
C_noret_decl(f_11252)
static void C_ccall f_11252(C_word c,C_word *av) C_noret;
C_noret_decl(f_11254)
static void C_fcall f_11254(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11279)
static void C_ccall f_11279(C_word c,C_word *av) C_noret;
C_noret_decl(f_11294)
static void C_ccall f_11294(C_word c,C_word *av) C_noret;
C_noret_decl(f_11323)
static void C_ccall f_11323(C_word c,C_word *av) C_noret;
C_noret_decl(f_11325)
static void C_fcall f_11325(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11350)
static void C_ccall f_11350(C_word c,C_word *av) C_noret;
C_noret_decl(f_11359)
static void C_ccall f_11359(C_word c,C_word *av) C_noret;
C_noret_decl(f_11363)
static void C_ccall f_11363(C_word c,C_word *av) C_noret;
C_noret_decl(f_11366)
static void C_ccall f_11366(C_word c,C_word *av) C_noret;
C_noret_decl(f_11372)
static void C_ccall f_11372(C_word c,C_word *av) C_noret;
C_noret_decl(f_11380)
static void C_ccall f_11380(C_word c,C_word *av) C_noret;
C_noret_decl(f_11388)
static void C_fcall f_11388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11398)
static void C_ccall f_11398(C_word c,C_word *av) C_noret;
C_noret_decl(f_11426)
static void C_ccall f_11426(C_word c,C_word *av) C_noret;
C_noret_decl(f_11430)
static void C_ccall f_11430(C_word c,C_word *av) C_noret;
C_noret_decl(f_11435)
static void C_ccall f_11435(C_word c,C_word *av) C_noret;
C_noret_decl(f_11441)
static void C_ccall f_11441(C_word c,C_word *av) C_noret;
C_noret_decl(f_11444)
static void C_ccall f_11444(C_word c,C_word *av) C_noret;
C_noret_decl(f_11449)
static void C_fcall f_11449(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11459)
static void C_ccall f_11459(C_word c,C_word *av) C_noret;
C_noret_decl(f_11474)
static void C_ccall f_11474(C_word c,C_word *av) C_noret;
C_noret_decl(f_11476)
static void C_ccall f_11476(C_word c,C_word *av) C_noret;
C_noret_decl(f_11483)
static void C_ccall f_11483(C_word c,C_word *av) C_noret;
C_noret_decl(f_11504)
static void C_fcall f_11504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11538)
static void C_ccall f_11538(C_word c,C_word *av) C_noret;
C_noret_decl(f_11541)
static void C_fcall f_11541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11560)
static void C_ccall f_11560(C_word c,C_word *av) C_noret;
C_noret_decl(f_11586)
static void C_ccall f_11586(C_word c,C_word *av) C_noret;
C_noret_decl(f_11619)
static void C_ccall f_11619(C_word c,C_word *av) C_noret;
C_noret_decl(f_11621)
static void C_ccall f_11621(C_word c,C_word *av) C_noret;
C_noret_decl(f_11627)
static void C_ccall f_11627(C_word c,C_word *av) C_noret;
C_noret_decl(f_11633)
static void C_fcall f_11633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11637)
static void C_ccall f_11637(C_word c,C_word *av) C_noret;
C_noret_decl(f_11660)
static void C_ccall f_11660(C_word c,C_word *av) C_noret;
C_noret_decl(f_11671)
static void C_ccall f_11671(C_word c,C_word *av) C_noret;
C_noret_decl(f_11677)
static void C_ccall f_11677(C_word c,C_word *av) C_noret;
C_noret_decl(f_11680)
static void C_fcall f_11680(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11688)
static C_word C_fcall f_11688(C_word t0,C_word t1);
C_noret_decl(f_11714)
static void C_fcall f_11714(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11736)
static void C_ccall f_11736(C_word c,C_word *av) C_noret;
C_noret_decl(f_11761)
static void C_fcall f_11761(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11783)
static void C_ccall f_11783(C_word c,C_word *av) C_noret;
C_noret_decl(f_11801)
static void C_fcall f_11801(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11832)
static void C_ccall f_11832(C_word c,C_word *av) C_noret;
C_noret_decl(f_11884)
static void C_ccall f_11884(C_word c,C_word *av) C_noret;
C_noret_decl(f_11890)
static void C_ccall f_11890(C_word c,C_word *av) C_noret;
C_noret_decl(f_11910)
static void C_ccall f_11910(C_word c,C_word *av) C_noret;
C_noret_decl(f_11916)
static void C_ccall f_11916(C_word c,C_word *av) C_noret;
C_noret_decl(f_11942)
static void C_fcall f_11942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11956)
static void C_ccall f_11956(C_word c,C_word *av) C_noret;
C_noret_decl(f_11964)
static void C_ccall f_11964(C_word c,C_word *av) C_noret;
C_noret_decl(f_12019)
static void C_ccall f_12019(C_word c,C_word *av) C_noret;
C_noret_decl(f_12048)
static void C_ccall f_12048(C_word c,C_word *av) C_noret;
C_noret_decl(f_12145)
static void C_ccall f_12145(C_word c,C_word *av) C_noret;
C_noret_decl(f_12151)
static void C_ccall f_12151(C_word c,C_word *av) C_noret;
C_noret_decl(f_12158)
static void C_fcall f_12158(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12161)
static void C_ccall f_12161(C_word c,C_word *av) C_noret;
C_noret_decl(f_12184)
static void C_ccall f_12184(C_word c,C_word *av) C_noret;
C_noret_decl(f_12186)
static void C_ccall f_12186(C_word c,C_word *av) C_noret;
C_noret_decl(f_12192)
static void C_ccall f_12192(C_word c,C_word *av) C_noret;
C_noret_decl(f_12199)
static void C_fcall f_12199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12202)
static void C_ccall f_12202(C_word c,C_word *av) C_noret;
C_noret_decl(f_12221)
static void C_ccall f_12221(C_word c,C_word *av) C_noret;
C_noret_decl(f_12223)
static void C_ccall f_12223(C_word c,C_word *av) C_noret;
C_noret_decl(f_12229)
static void C_ccall f_12229(C_word c,C_word *av) C_noret;
C_noret_decl(f_12242)
static void C_ccall f_12242(C_word c,C_word *av) C_noret;
C_noret_decl(f_12270)
static void C_ccall f_12270(C_word c,C_word *av) C_noret;
C_noret_decl(f_12272)
static void C_ccall f_12272(C_word c,C_word *av) C_noret;
C_noret_decl(f_12293)
static void C_ccall f_12293(C_word c,C_word *av) C_noret;
C_noret_decl(f_12300)
static void C_ccall f_12300(C_word c,C_word *av) C_noret;
C_noret_decl(f_12306)
static void C_ccall f_12306(C_word c,C_word *av) C_noret;
C_noret_decl(f_12312)
static void C_ccall f_12312(C_word c,C_word *av) C_noret;
C_noret_decl(f_12321)
static void C_ccall f_12321(C_word c,C_word *av) C_noret;
C_noret_decl(f_12330)
static void C_ccall f_12330(C_word c,C_word *av) C_noret;
C_noret_decl(f_12339)
static void C_ccall f_12339(C_word c,C_word *av) C_noret;
C_noret_decl(f_12348)
static void C_ccall f_12348(C_word c,C_word *av) C_noret;
C_noret_decl(f_12357)
static void C_ccall f_12357(C_word c,C_word *av) C_noret;
C_noret_decl(f_12383)
static void C_ccall f_12383(C_word c,C_word *av) C_noret;
C_noret_decl(f_12386)
static void C_ccall f_12386(C_word c,C_word *av) C_noret;
C_noret_decl(f_12397)
static void C_ccall f_12397(C_word c,C_word *av) C_noret;
C_noret_decl(f_12399)
static void C_ccall f_12399(C_word c,C_word *av) C_noret;
C_noret_decl(f_12453)
static void C_ccall f_12453(C_word c,C_word *av) C_noret;
C_noret_decl(f_12459)
static void C_ccall f_12459(C_word c,C_word *av) C_noret;
C_noret_decl(f_12465)
static void C_ccall f_12465(C_word c,C_word *av) C_noret;
C_noret_decl(f_12471)
static void C_fcall f_12471(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12496)
static void C_fcall f_12496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12511)
static void C_fcall f_12511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12529)
static void C_ccall f_12529(C_word c,C_word *av) C_noret;
C_noret_decl(f_12579)
static void C_ccall f_12579(C_word c,C_word *av) C_noret;
C_noret_decl(f_12594)
static void C_fcall f_12594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12634)
static void C_fcall f_12634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12637)
static void C_ccall f_12637(C_word c,C_word *av) C_noret;
C_noret_decl(f_12652)
static void C_fcall f_12652(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12676)
static void C_fcall f_12676(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12702)
static void C_fcall f_12702(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12708)
static void C_ccall f_12708(C_word c,C_word *av) C_noret;
C_noret_decl(f_12714)
static void C_ccall f_12714(C_word c,C_word *av) C_noret;
C_noret_decl(f_12717)
static void C_ccall f_12717(C_word c,C_word *av) C_noret;
C_noret_decl(f_12720)
static void C_ccall f_12720(C_word c,C_word *av) C_noret;
C_noret_decl(f_12723)
static void C_ccall f_12723(C_word c,C_word *av) C_noret;
C_noret_decl(f_12745)
static void C_fcall f_12745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12751)
static void C_ccall f_12751(C_word c,C_word *av) C_noret;
C_noret_decl(f_12757)
static void C_ccall f_12757(C_word c,C_word *av) C_noret;
C_noret_decl(f_12760)
static void C_ccall f_12760(C_word c,C_word *av) C_noret;
C_noret_decl(f_12763)
static void C_ccall f_12763(C_word c,C_word *av) C_noret;
C_noret_decl(f_12766)
static void C_ccall f_12766(C_word c,C_word *av) C_noret;
C_noret_decl(f_12789)
static void C_fcall f_12789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12792)
static void C_ccall f_12792(C_word c,C_word *av) C_noret;
C_noret_decl(f_12833)
static void C_fcall f_12833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12836)
static void C_ccall f_12836(C_word c,C_word *av) C_noret;
C_noret_decl(f_12851)
static void C_fcall f_12851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12878)
static void C_fcall f_12878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12921)
static void C_ccall f_12921(C_word c,C_word *av) C_noret;
C_noret_decl(f_12925)
static void C_fcall f_12925(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12952)
static void C_fcall f_12952(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12955)
static void C_ccall f_12955(C_word c,C_word *av) C_noret;
C_noret_decl(f_12990)
static void C_ccall f_12990(C_word c,C_word *av) C_noret;
C_noret_decl(f_13026)
static void C_ccall f_13026(C_word c,C_word *av) C_noret;
C_noret_decl(f_13529)
static void C_ccall f_13529(C_word c,C_word *av) C_noret;
C_noret_decl(f_13535)
static void C_ccall f_13535(C_word c,C_word *av) C_noret;
C_noret_decl(f_13548)
static void C_ccall f_13548(C_word c,C_word *av) C_noret;
C_noret_decl(f_13562)
static void C_ccall f_13562(C_word c,C_word *av) C_noret;
C_noret_decl(f_13575)
static void C_ccall f_13575(C_word c,C_word *av) C_noret;
C_noret_decl(f_13589)
static void C_ccall f_13589(C_word c,C_word *av) C_noret;
C_noret_decl(f_13595)
static void C_ccall f_13595(C_word c,C_word *av) C_noret;
C_noret_decl(f_13599)
static void C_ccall f_13599(C_word c,C_word *av) C_noret;
C_noret_decl(f_13603)
static void C_fcall f_13603(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13622)
static void C_ccall f_13622(C_word c,C_word *av) C_noret;
C_noret_decl(f_13628)
static void C_ccall f_13628(C_word c,C_word *av) C_noret;
C_noret_decl(f_13631)
static void C_fcall f_13631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13640)
static void C_ccall f_13640(C_word c,C_word *av) C_noret;
C_noret_decl(f_13650)
static void C_fcall f_13650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13659)
static void C_fcall f_13659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13671)
static void C_fcall f_13671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13683)
static void C_fcall f_13683(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13695)
static void C_fcall f_13695(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13701)
static void C_ccall f_13701(C_word c,C_word *av) C_noret;
C_noret_decl(f_13705)
static void C_fcall f_13705(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13732)
static void C_fcall f_13732(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14097)
static void C_ccall f_14097(C_word c,C_word *av) C_noret;
C_noret_decl(f_14103)
static void C_ccall f_14103(C_word c,C_word *av) C_noret;
C_noret_decl(f_14115)
static void C_ccall f_14115(C_word c,C_word *av) C_noret;
C_noret_decl(f_14125)
static void C_fcall f_14125(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14137)
static void C_fcall f_14137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14143)
static void C_ccall f_14143(C_word c,C_word *av) C_noret;
C_noret_decl(f_14147)
static void C_fcall f_14147(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14174)
static void C_fcall f_14174(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14547)
static void C_ccall f_14547(C_word c,C_word *av) C_noret;
C_noret_decl(f_14553)
static void C_ccall f_14553(C_word c,C_word *av) C_noret;
C_noret_decl(f_14557)
static void C_ccall f_14557(C_word c,C_word *av) C_noret;
C_noret_decl(f_14673)
static void C_fcall f_14673(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14701)
static void C_ccall f_14701(C_word c,C_word *av) C_noret;
C_noret_decl(f_14821)
static void C_ccall f_14821(C_word c,C_word *av) C_noret;
C_noret_decl(f_14825)
static void C_ccall f_14825(C_word c,C_word *av) C_noret;
C_noret_decl(f_14849)
static void C_fcall f_14849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14924)
static void C_fcall f_14924(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15011)
static void C_fcall f_15011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15032)
static void C_fcall f_15032(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15050)
static void C_fcall f_15050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15072)
static void C_fcall f_15072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15427)
static void C_ccall f_15427(C_word c,C_word *av) C_noret;
C_noret_decl(f_15431)
static void C_ccall f_15431(C_word c,C_word *av) C_noret;
C_noret_decl(f_15433)
static void C_ccall f_15433(C_word c,C_word *av) C_noret;
C_noret_decl(f_15465)
static void C_fcall f_15465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15473)
static void C_fcall f_15473(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15483)
static void C_ccall f_15483(C_word c,C_word *av) C_noret;
C_noret_decl(f_15497)
static void C_fcall f_15497(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15529)
static void C_fcall f_15529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15537)
static void C_fcall f_15537(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15547)
static void C_ccall f_15547(C_word c,C_word *av) C_noret;
C_noret_decl(f_15582)
static void C_ccall f_15582(C_word c,C_word *av) C_noret;
C_noret_decl(f_15585)
static void C_fcall f_15585(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15619)
static void C_fcall f_15619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15638)
static void C_ccall f_15638(C_word c,C_word *av) C_noret;
C_noret_decl(f_15644)
static void C_ccall f_15644(C_word c,C_word *av) C_noret;
C_noret_decl(f_15648)
static void C_ccall f_15648(C_word c,C_word *av) C_noret;
C_noret_decl(f_15674)
static void C_ccall f_15674(C_word c,C_word *av) C_noret;
C_noret_decl(f_15683)
static void C_ccall f_15683(C_word c,C_word *av) C_noret;
C_noret_decl(f_15694)
static void C_ccall f_15694(C_word c,C_word *av) C_noret;
C_noret_decl(f_15713)
static void C_ccall f_15713(C_word c,C_word *av) C_noret;
C_noret_decl(f_15725)
static void C_ccall f_15725(C_word c,C_word *av) C_noret;
C_noret_decl(f_15769)
static void C_fcall f_15769(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15771)
static void C_fcall f_15771(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15783)
static void C_fcall f_15783(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15793)
static void C_ccall f_15793(C_word c,C_word *av) C_noret;
C_noret_decl(f_15807)
static void C_ccall f_15807(C_word c,C_word *av) C_noret;
C_noret_decl(f_15812)
static void C_ccall f_15812(C_word c,C_word *av) C_noret;
C_noret_decl(f_15823)
static void C_fcall f_15823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15836)
static void C_ccall f_15836(C_word c,C_word *av) C_noret;
C_noret_decl(f_15842)
static void C_ccall f_15842(C_word c,C_word *av) C_noret;
C_noret_decl(f_15848)
static void C_ccall f_15848(C_word c,C_word *av) C_noret;
C_noret_decl(f_15857)
static void C_ccall f_15857(C_word c,C_word *av) C_noret;
C_noret_decl(f_15865)
static void C_ccall f_15865(C_word c,C_word *av) C_noret;
C_noret_decl(f_15871)
static void C_ccall f_15871(C_word c,C_word *av) C_noret;
C_noret_decl(f_15874)
static void C_ccall f_15874(C_word c,C_word *av) C_noret;
C_noret_decl(f_15877)
static void C_ccall f_15877(C_word c,C_word *av) C_noret;
C_noret_decl(f_15880)
static void C_ccall f_15880(C_word c,C_word *av) C_noret;
C_noret_decl(f_15883)
static void C_ccall f_15883(C_word c,C_word *av) C_noret;
C_noret_decl(f_15888)
static void C_ccall f_15888(C_word c,C_word *av) C_noret;
C_noret_decl(f_15892)
static void C_ccall f_15892(C_word c,C_word *av) C_noret;
C_noret_decl(f_15904)
static void C_ccall f_15904(C_word c,C_word *av) C_noret;
C_noret_decl(f_15909)
static void C_ccall f_15909(C_word c,C_word *av) C_noret;
C_noret_decl(f_15911)
static void C_ccall f_15911(C_word c,C_word *av) C_noret;
C_noret_decl(f_15917)
static void C_ccall f_15917(C_word c,C_word *av) C_noret;
C_noret_decl(f_15924)
static void C_ccall f_15924(C_word c,C_word *av) C_noret;
C_noret_decl(f_15927)
static void C_fcall f_15927(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15931)
static void C_ccall f_15931(C_word c,C_word *av) C_noret;
C_noret_decl(f_15937)
static void C_ccall f_15937(C_word c,C_word *av) C_noret;
C_noret_decl(f_15943)
static void C_ccall f_15943(C_word c,C_word *av) C_noret;
C_noret_decl(f_15970)
static void C_ccall f_15970(C_word c,C_word *av) C_noret;
C_noret_decl(f_15972)
static void C_fcall f_15972(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15986)
static void C_ccall f_15986(C_word c,C_word *av) C_noret;
C_noret_decl(f_15996)
static void C_ccall f_15996(C_word c,C_word *av) C_noret;
C_noret_decl(f_16009)
static void C_ccall f_16009(C_word c,C_word *av) C_noret;
C_noret_decl(f_16024)
static void C_ccall f_16024(C_word c,C_word *av) C_noret;
C_noret_decl(f_16028)
static void C_ccall f_16028(C_word c,C_word *av) C_noret;
C_noret_decl(f_16035)
static void C_ccall f_16035(C_word c,C_word *av) C_noret;
C_noret_decl(f_16039)
static void C_ccall f_16039(C_word c,C_word *av) C_noret;
C_noret_decl(f_16044)
static void C_ccall f_16044(C_word c,C_word *av) C_noret;
C_noret_decl(f_16048)
static void C_ccall f_16048(C_word c,C_word *av) C_noret;
C_noret_decl(f_16056)
static void C_ccall f_16056(C_word c,C_word *av) C_noret;
C_noret_decl(f_16062)
static void C_ccall f_16062(C_word c,C_word *av) C_noret;
C_noret_decl(f_16069)
static void C_ccall f_16069(C_word c,C_word *av) C_noret;
C_noret_decl(f_16072)
static void C_ccall f_16072(C_word c,C_word *av) C_noret;
C_noret_decl(f_16075)
static void C_ccall f_16075(C_word c,C_word *av) C_noret;
C_noret_decl(f_16080)
static void C_ccall f_16080(C_word c,C_word *av) C_noret;
C_noret_decl(f_16100)
static void C_ccall f_16100(C_word c,C_word *av) C_noret;
C_noret_decl(f_16104)
static void C_ccall f_16104(C_word c,C_word *av) C_noret;
C_noret_decl(f_16115)
static void C_ccall f_16115(C_word c,C_word *av) C_noret;
C_noret_decl(f_16130)
static void C_ccall f_16130(C_word c,C_word *av) C_noret;
C_noret_decl(f_16142)
static void C_ccall f_16142(C_word c,C_word *av) C_noret;
C_noret_decl(f_16146)
static void C_fcall f_16146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16149)
static void C_ccall f_16149(C_word c,C_word *av) C_noret;
C_noret_decl(f_16179)
static void C_ccall f_16179(C_word c,C_word *av) C_noret;
C_noret_decl(f_16203)
static void C_ccall f_16203(C_word c,C_word *av) C_noret;
C_noret_decl(f_16218)
static void C_ccall f_16218(C_word c,C_word *av) C_noret;
C_noret_decl(f_16221)
static void C_ccall f_16221(C_word c,C_word *av) C_noret;
C_noret_decl(f_16227)
static void C_ccall f_16227(C_word c,C_word *av) C_noret;
C_noret_decl(f_16236)
static void C_ccall f_16236(C_word c,C_word *av) C_noret;
C_noret_decl(f_16239)
static void C_ccall f_16239(C_word c,C_word *av) C_noret;
C_noret_decl(f_16278)
static void C_ccall f_16278(C_word c,C_word *av) C_noret;
C_noret_decl(f_16284)
static void C_ccall f_16284(C_word c,C_word *av) C_noret;
C_noret_decl(f_16290)
static void C_ccall f_16290(C_word c,C_word *av) C_noret;
C_noret_decl(f_16293)
static void C_ccall f_16293(C_word c,C_word *av) C_noret;
C_noret_decl(f_16299)
static void C_ccall f_16299(C_word c,C_word *av) C_noret;
C_noret_decl(f_16305)
static void C_ccall f_16305(C_word c,C_word *av) C_noret;
C_noret_decl(f_16311)
static void C_ccall f_16311(C_word c,C_word *av) C_noret;
C_noret_decl(f_16317)
static void C_ccall f_16317(C_word c,C_word *av) C_noret;
C_noret_decl(f_16339)
static void C_ccall f_16339(C_word c,C_word *av) C_noret;
C_noret_decl(f_16341)
static void C_fcall f_16341(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16375)
static void C_fcall f_16375(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16409)
static void C_ccall f_16409(C_word c,C_word *av) C_noret;
C_noret_decl(f_16412)
static void C_ccall f_16412(C_word c,C_word *av) C_noret;
C_noret_decl(f_16440)
static void C_ccall f_16440(C_word c,C_word *av) C_noret;
C_noret_decl(f_16447)
static void C_ccall f_16447(C_word c,C_word *av) C_noret;
C_noret_decl(f_16462)
static void C_ccall f_16462(C_word c,C_word *av) C_noret;
C_noret_decl(f_16468)
static void C_ccall f_16468(C_word c,C_word *av) C_noret;
C_noret_decl(f_16471)
static void C_ccall f_16471(C_word c,C_word *av) C_noret;
C_noret_decl(f_16508)
static void C_ccall f_16508(C_word c,C_word *av) C_noret;
C_noret_decl(f_16523)
static void C_ccall f_16523(C_word c,C_word *av) C_noret;
C_noret_decl(f_16533)
static void C_ccall f_16533(C_word c,C_word *av) C_noret;
C_noret_decl(f_16536)
static void C_ccall f_16536(C_word c,C_word *av) C_noret;
C_noret_decl(f_16548)
static void C_ccall f_16548(C_word c,C_word *av) C_noret;
C_noret_decl(f_16554)
static void C_ccall f_16554(C_word c,C_word *av) C_noret;
C_noret_decl(f_16560)
static void C_ccall f_16560(C_word c,C_word *av) C_noret;
C_noret_decl(f_16563)
static void C_ccall f_16563(C_word c,C_word *av) C_noret;
C_noret_decl(f_16565)
static void C_fcall f_16565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16572)
static void C_fcall f_16572(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16578)
static void C_ccall f_16578(C_word c,C_word *av) C_noret;
C_noret_decl(f_16589)
static void C_ccall f_16589(C_word c,C_word *av) C_noret;
C_noret_decl(f_16637)
static void C_ccall f_16637(C_word c,C_word *av) C_noret;
C_noret_decl(f_16639)
static void C_ccall f_16639(C_word c,C_word *av) C_noret;
C_noret_decl(f_16645)
static void C_ccall f_16645(C_word c,C_word *av) C_noret;
C_noret_decl(f_16649)
static void C_ccall f_16649(C_word c,C_word *av) C_noret;
C_noret_decl(f_16654)
static void C_fcall f_16654(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16682)
static void C_ccall f_16682(C_word c,C_word *av) C_noret;
C_noret_decl(f_16690)
static void C_ccall f_16690(C_word c,C_word *av) C_noret;
C_noret_decl(f_16693)
static void C_ccall f_16693(C_word c,C_word *av) C_noret;
C_noret_decl(f_16696)
static void C_ccall f_16696(C_word c,C_word *av) C_noret;
C_noret_decl(f_16699)
static void C_ccall f_16699(C_word c,C_word *av) C_noret;
C_noret_decl(f_16702)
static void C_ccall f_16702(C_word c,C_word *av) C_noret;
C_noret_decl(f_16705)
static void C_ccall f_16705(C_word c,C_word *av) C_noret;
C_noret_decl(f_16706)
static void C_fcall f_16706(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16716)
static void C_ccall f_16716(C_word c,C_word *av) C_noret;
C_noret_decl(f_16722)
static void C_ccall f_16722(C_word c,C_word *av) C_noret;
C_noret_decl(f_16734)
static void C_ccall f_16734(C_word c,C_word *av) C_noret;
C_noret_decl(f_16737)
static void C_ccall f_16737(C_word c,C_word *av) C_noret;
C_noret_decl(f_16740)
static void C_ccall f_16740(C_word c,C_word *av) C_noret;
C_noret_decl(f_16745)
static void C_fcall f_16745(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16758)
static void C_ccall f_16758(C_word c,C_word *av) C_noret;
C_noret_decl(f_16761)
static void C_ccall f_16761(C_word c,C_word *av) C_noret;
C_noret_decl(f_16778)
static void C_fcall f_16778(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16788)
static void C_ccall f_16788(C_word c,C_word *av) C_noret;
C_noret_decl(f_16801)
static void C_ccall f_16801(C_word c,C_word *av) C_noret;
C_noret_decl(f_16805)
static void C_ccall f_16805(C_word c,C_word *av) C_noret;
C_noret_decl(f_16808)
static void C_fcall f_16808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16823)
static void C_ccall f_16823(C_word c,C_word *av) C_noret;
C_noret_decl(f_16827)
static void C_ccall f_16827(C_word c,C_word *av) C_noret;
C_noret_decl(f_16844)
static void C_ccall f_16844(C_word c,C_word *av) C_noret;
C_noret_decl(f_16850)
static void C_ccall f_16850(C_word c,C_word *av) C_noret;
C_noret_decl(f_16860)
static void C_ccall f_16860(C_word c,C_word *av) C_noret;
C_noret_decl(f_16863)
static void C_ccall f_16863(C_word c,C_word *av) C_noret;
C_noret_decl(f_16879)
static void C_ccall f_16879(C_word c,C_word *av) C_noret;
C_noret_decl(f_16884)
static void C_fcall f_16884(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16888)
static void C_ccall f_16888(C_word c,C_word *av) C_noret;
C_noret_decl(f_16905)
static void C_ccall f_16905(C_word c,C_word *av) C_noret;
C_noret_decl(f_16916)
static void C_ccall f_16916(C_word c,C_word *av) C_noret;
C_noret_decl(f_16928)
static void C_ccall f_16928(C_word c,C_word *av) C_noret;
C_noret_decl(f_16931)
static void C_ccall f_16931(C_word c,C_word *av) C_noret;
C_noret_decl(f_16939)
static void C_ccall f_16939(C_word c,C_word *av) C_noret;
C_noret_decl(f_16944)
static void C_ccall f_16944(C_word c,C_word *av) C_noret;
C_noret_decl(f_16957)
static void C_ccall f_16957(C_word c,C_word *av) C_noret;
C_noret_decl(f_16968)
static void C_ccall f_16968(C_word c,C_word *av) C_noret;
C_noret_decl(f_16990)
static void C_ccall f_16990(C_word c,C_word *av) C_noret;
C_noret_decl(f_16992)
static void C_ccall f_16992(C_word c,C_word *av) C_noret;
C_noret_decl(f_17012)
static void C_ccall f_17012(C_word c,C_word *av) C_noret;
C_noret_decl(f_17032)
static void C_ccall f_17032(C_word c,C_word *av) C_noret;
C_noret_decl(f_17040)
static void C_ccall f_17040(C_word c,C_word *av) C_noret;
C_noret_decl(f_17049)
static void C_ccall f_17049(C_word c,C_word *av) C_noret;
C_noret_decl(f_17054)
static void C_ccall f_17054(C_word c,C_word *av) C_noret;
C_noret_decl(f_17058)
static void C_ccall f_17058(C_word c,C_word *av) C_noret;
C_noret_decl(f_17079)
static void C_ccall f_17079(C_word c,C_word *av) C_noret;
C_noret_decl(f_17094)
static void C_ccall f_17094(C_word c,C_word *av) C_noret;
C_noret_decl(f_17100)
static void C_ccall f_17100(C_word c,C_word *av) C_noret;
C_noret_decl(f_17111)
static void C_ccall f_17111(C_word c,C_word *av) C_noret;
C_noret_decl(f_17122)
static void C_ccall f_17122(C_word c,C_word *av) C_noret;
C_noret_decl(f_17133)
static void C_ccall f_17133(C_word c,C_word *av) C_noret;
C_noret_decl(f_17137)
static void C_ccall f_17137(C_word c,C_word *av) C_noret;
C_noret_decl(f_17143)
static void C_ccall f_17143(C_word c,C_word *av) C_noret;
C_noret_decl(f_17155)
static void C_ccall f_17155(C_word c,C_word *av) C_noret;
C_noret_decl(f_17159)
static void C_ccall f_17159(C_word c,C_word *av) C_noret;
C_noret_decl(f_17171)
static void C_ccall f_17171(C_word c,C_word *av) C_noret;
C_noret_decl(f_17179)
static void C_fcall f_17179(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_17189)
static void C_ccall f_17189(C_word c,C_word *av) C_noret;
C_noret_decl(f_17204)
static void C_ccall f_17204(C_word c,C_word *av) C_noret;
C_noret_decl(f_17210)
static void C_ccall f_17210(C_word c,C_word *av) C_noret;
C_noret_decl(f_17213)
static void C_ccall f_17213(C_word c,C_word *av) C_noret;
C_noret_decl(f_17216)
static void C_ccall f_17216(C_word c,C_word *av) C_noret;
C_noret_decl(f_17219)
static void C_ccall f_17219(C_word c,C_word *av) C_noret;
C_noret_decl(f_17222)
static void C_ccall f_17222(C_word c,C_word *av) C_noret;
C_noret_decl(f_17226)
static void C_ccall f_17226(C_word c,C_word *av) C_noret;
C_noret_decl(f_17228)
static void C_ccall f_17228(C_word c,C_word *av) C_noret;
C_noret_decl(f_17235)
static void C_ccall f_17235(C_word c,C_word *av) C_noret;
C_noret_decl(f_17242)
static void C_ccall f_17242(C_word c,C_word *av) C_noret;
C_noret_decl(f_17253)
static void C_ccall f_17253(C_word c,C_word *av) C_noret;
C_noret_decl(f_17257)
static void C_ccall f_17257(C_word c,C_word *av) C_noret;
C_noret_decl(f_17260)
static void C_ccall f_17260(C_word c,C_word *av) C_noret;
C_noret_decl(f_17265)
static void C_ccall f_17265(C_word c,C_word *av) C_noret;
C_noret_decl(f_17271)
static void C_ccall f_17271(C_word c,C_word *av) C_noret;
C_noret_decl(f_17278)
static void C_ccall f_17278(C_word c,C_word *av) C_noret;
C_noret_decl(f_17281)
static void C_ccall f_17281(C_word c,C_word *av) C_noret;
C_noret_decl(f_17284)
static void C_ccall f_17284(C_word c,C_word *av) C_noret;
C_noret_decl(f_17287)
static void C_ccall f_17287(C_word c,C_word *av) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word *av) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word *av) C_noret;
C_noret_decl(f_5121)
static void C_ccall f_5121(C_word c,C_word *av) C_noret;
C_noret_decl(f_5124)
static void C_ccall f_5124(C_word c,C_word *av) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word *av) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word *av) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133(C_word c,C_word *av) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word *av) C_noret;
C_noret_decl(f_5139)
static void C_ccall f_5139(C_word c,C_word *av) C_noret;
C_noret_decl(f_5249)
static void C_fcall f_5249(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word *av) C_noret;
C_noret_decl(f_5307)
static void C_fcall f_5307(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word *av) C_noret;
C_noret_decl(f_5510)
static void C_fcall f_5510(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5516)
static void C_fcall f_5516(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word *av) C_noret;
C_noret_decl(f_5544)
static void C_fcall f_5544(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5550)
static void C_fcall f_5550(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word *av) C_noret;
C_noret_decl(f_5574)
static void C_fcall f_5574(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5580)
static void C_fcall f_5580(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5594)
static void C_ccall f_5594(C_word c,C_word *av) C_noret;
C_noret_decl(f_5803)
static void C_fcall f_5803(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5811)
static void C_fcall f_5811(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word *av) C_noret;
C_noret_decl(f_5819)
static C_word C_fcall f_5819(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word *av) C_noret;
C_noret_decl(f_5876)
static void C_fcall f_5876(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5910)
static void C_fcall f_5910(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5916)
static C_word C_fcall f_5916(C_word t0);
C_noret_decl(f_5969)
static void C_fcall f_5969(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5975)
static void C_fcall f_5975(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6158)
static void C_fcall f_6158(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word *av) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word *av) C_noret;
C_noret_decl(f_6271)
static void C_fcall f_6271(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6284)
static void C_ccall f_6284(C_word c,C_word *av) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word *av) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word *av) C_noret;
C_noret_decl(f_6440)
static void C_ccall f_6440(C_word c,C_word *av) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word *av) C_noret;
C_noret_decl(f_6454)
static void C_fcall f_6454(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word *av) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word *av) C_noret;
C_noret_decl(f_6478)
static void C_fcall f_6478(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word *av) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word *av) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word *av) C_noret;
C_noret_decl(f_6500)
static void C_ccall f_6500(C_word c,C_word *av) C_noret;
C_noret_decl(f_6508)
static void C_ccall f_6508(C_word c,C_word *av) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word *av) C_noret;
C_noret_decl(f_6520)
static void C_fcall f_6520(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6530)
static void C_ccall f_6530(C_word c,C_word *av) C_noret;
C_noret_decl(f_6543)
static void C_fcall f_6543(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word *av) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word *av) C_noret;
C_noret_decl(f_6562)
static void C_ccall f_6562(C_word c,C_word *av) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word *av) C_noret;
C_noret_decl(f_6568)
static void C_ccall f_6568(C_word c,C_word *av) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word *av) C_noret;
C_noret_decl(f_6574)
static void C_ccall f_6574(C_word c,C_word *av) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word *av) C_noret;
C_noret_decl(f_6583)
static void C_ccall f_6583(C_word c,C_word *av) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word *av) C_noret;
C_noret_decl(f_6593)
static void C_ccall f_6593(C_word c,C_word *av) C_noret;
C_noret_decl(f_6595)
static void C_ccall f_6595(C_word c,C_word *av) C_noret;
C_noret_decl(f_6598)
static void C_fcall f_6598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6600)
static void C_fcall f_6600(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word *av) C_noret;
C_noret_decl(f_6610)
static void C_ccall f_6610(C_word c,C_word *av) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613(C_word c,C_word *av) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word *av) C_noret;
C_noret_decl(f_6632)
static void C_fcall f_6632(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6642)
static void C_ccall f_6642(C_word c,C_word *av) C_noret;
C_noret_decl(f_6659)
static void C_ccall f_6659(C_word c,C_word *av) C_noret;
C_noret_decl(f_6662)
static void C_ccall f_6662(C_word c,C_word *av) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word *av) C_noret;
C_noret_decl(f_6668)
static void C_ccall f_6668(C_word c,C_word *av) C_noret;
C_noret_decl(f_6674)
static void C_ccall f_6674(C_word c,C_word *av) C_noret;
C_noret_decl(f_6683)
static void C_ccall f_6683(C_word c,C_word *av) C_noret;
C_noret_decl(f_6690)
static void C_ccall f_6690(C_word c,C_word *av) C_noret;
C_noret_decl(f_6692)
static void C_ccall f_6692(C_word c,C_word *av) C_noret;
C_noret_decl(f_6696)
static void C_ccall f_6696(C_word c,C_word *av) C_noret;
C_noret_decl(f_6699)
static void C_ccall f_6699(C_word c,C_word *av) C_noret;
C_noret_decl(f_6706)
static void C_ccall f_6706(C_word c,C_word *av) C_noret;
C_noret_decl(f_6708)
static void C_ccall f_6708(C_word c,C_word *av) C_noret;
C_noret_decl(f_6712)
static void C_fcall f_6712(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word *av) C_noret;
C_noret_decl(f_6716)
static void C_fcall f_6716(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6726)
static void C_ccall f_6726(C_word c,C_word *av) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word *av) C_noret;
C_noret_decl(f_6734)
static void C_fcall f_6734(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6744)
static void C_ccall f_6744(C_word c,C_word *av) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word *av) C_noret;
C_noret_decl(f_6764)
static void C_ccall f_6764(C_word c,C_word *av) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word *av) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770(C_word c,C_word *av) C_noret;
C_noret_decl(f_6773)
static void C_ccall f_6773(C_word c,C_word *av) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word *av) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word *av) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word *av) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word *av) C_noret;
C_noret_decl(f_6824)
static void C_fcall f_6824(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6847)
static void C_ccall f_6847(C_word c,C_word *av) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word *av) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word *av) C_noret;
C_noret_decl(f_6862)
static void C_fcall f_6862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word *av) C_noret;
C_noret_decl(f_6874)
static void C_ccall f_6874(C_word c,C_word *av) C_noret;
C_noret_decl(f_6883)
static void C_fcall f_6883(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word *av) C_noret;
C_noret_decl(f_6933)
static void C_fcall f_6933(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word *av) C_noret;
C_noret_decl(f_6964)
static void C_ccall f_6964(C_word c,C_word *av) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word *av) C_noret;
C_noret_decl(f_6980)
static void C_ccall f_6980(C_word c,C_word *av) C_noret;
C_noret_decl(f_6982)
static void C_fcall f_6982(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7004)
static void C_fcall f_7004(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7011)
static void C_fcall f_7011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7015)
static void C_ccall f_7015(C_word c,C_word *av) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word *av) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word *av) C_noret;
C_noret_decl(f_7047)
static void C_ccall f_7047(C_word c,C_word *av) C_noret;
C_noret_decl(f_7063)
static void C_ccall f_7063(C_word c,C_word *av) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word *av) C_noret;
C_noret_decl(f_7088)
static void C_ccall f_7088(C_word c,C_word *av) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word *av) C_noret;
C_noret_decl(f_7113)
static void C_ccall f_7113(C_word c,C_word *av) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word *av) C_noret;
C_noret_decl(f_7127)
static void C_ccall f_7127(C_word c,C_word *av) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word *av) C_noret;
C_noret_decl(f_7152)
static void C_fcall f_7152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7171)
static void C_ccall f_7171(C_word c,C_word *av) C_noret;
C_noret_decl(f_7183)
static void C_ccall f_7183(C_word c,C_word *av) C_noret;
C_noret_decl(f_7197)
static void C_ccall f_7197(C_word c,C_word *av) C_noret;
C_noret_decl(f_7199)
static void C_fcall f_7199(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7225)
static void C_ccall f_7225(C_word c,C_word *av) C_noret;
C_noret_decl(f_7239)
static void C_fcall f_7239(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7245)
static void C_fcall f_7245(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7260)
static void C_ccall f_7260(C_word c,C_word *av) C_noret;
C_noret_decl(f_7276)
static void C_ccall f_7276(C_word c,C_word *av) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word *av) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288(C_word c,C_word *av) C_noret;
C_noret_decl(f_7290)
static void C_ccall f_7290(C_word c,C_word *av) C_noret;
C_noret_decl(f_7301)
static void C_ccall f_7301(C_word c,C_word *av) C_noret;
C_noret_decl(f_7303)
static void C_fcall f_7303(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word *av) C_noret;
C_noret_decl(f_7334)
static void C_ccall f_7334(C_word c,C_word *av) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word *av) C_noret;
C_noret_decl(f_7380)
static void C_ccall f_7380(C_word c,C_word *av) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word *av) C_noret;
C_noret_decl(f_7426)
static void C_ccall f_7426(C_word c,C_word *av) C_noret;
C_noret_decl(f_7430)
static void C_fcall f_7430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_ccall f_7470(C_word c,C_word *av) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word *av) C_noret;
C_noret_decl(f_7488)
static void C_ccall f_7488(C_word c,C_word *av) C_noret;
C_noret_decl(f_7494)
static void C_ccall f_7494(C_word c,C_word *av) C_noret;
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word *av) C_noret;
C_noret_decl(f_7526)
static void C_ccall f_7526(C_word c,C_word *av) C_noret;
C_noret_decl(f_7528)
static void C_ccall f_7528(C_word c,C_word *av) C_noret;
C_noret_decl(f_7534)
static void C_fcall f_7534(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7558)
static void C_fcall f_7558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7574)
static void C_ccall f_7574(C_word c,C_word *av) C_noret;
C_noret_decl(f_7584)
static void C_ccall f_7584(C_word c,C_word *av) C_noret;
C_noret_decl(f_7589)
static void C_ccall f_7589(C_word c,C_word *av) C_noret;
C_noret_decl(f_7603)
static void C_ccall f_7603(C_word c,C_word *av) C_noret;
C_noret_decl(f_7606)
static void C_ccall f_7606(C_word c,C_word *av) C_noret;
C_noret_decl(f_7607)
static void C_ccall f_7607(C_word c,C_word *av) C_noret;
C_noret_decl(f_7611)
static void C_ccall f_7611(C_word c,C_word *av) C_noret;
C_noret_decl(f_7616)
static void C_ccall f_7616(C_word c,C_word *av) C_noret;
C_noret_decl(f_7622)
static void C_ccall f_7622(C_word c,C_word *av) C_noret;
C_noret_decl(f_7628)
static void C_ccall f_7628(C_word c,C_word *av) C_noret;
C_noret_decl(f_7636)
static void C_ccall f_7636(C_word c,C_word *av) C_noret;
C_noret_decl(f_7639)
static void C_ccall f_7639(C_word c,C_word *av) C_noret;
C_noret_decl(f_7647)
static void C_ccall f_7647(C_word c,C_word *av) C_noret;
C_noret_decl(f_7649)
static void C_fcall f_7649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7653)
static void C_ccall f_7653(C_word c,C_word *av) C_noret;
C_noret_decl(f_7675)
static void C_ccall f_7675(C_word c,C_word *av) C_noret;
C_noret_decl(f_7681)
static void C_fcall f_7681(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7685)
static void C_ccall f_7685(C_word c,C_word *av) C_noret;
C_noret_decl(f_7698)
static void C_ccall f_7698(C_word c,C_word *av) C_noret;
C_noret_decl(f_7706)
static void C_fcall f_7706(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7712)
static void C_ccall f_7712(C_word c,C_word *av) C_noret;
C_noret_decl(f_7723)
static void C_ccall f_7723(C_word c,C_word *av) C_noret;
C_noret_decl(f_7725)
static void C_ccall f_7725(C_word c,C_word *av) C_noret;
C_noret_decl(f_7728)
static void C_ccall f_7728(C_word c,C_word *av) C_noret;
C_noret_decl(f_7734)
static C_word C_fcall f_7734(C_word t0,C_word t1);
C_noret_decl(f_7773)
static void C_ccall f_7773(C_word c,C_word *av) C_noret;
C_noret_decl(f_7778)
static void C_ccall f_7778(C_word c,C_word *av) C_noret;
C_noret_decl(f_7782)
static void C_ccall f_7782(C_word c,C_word *av) C_noret;
C_noret_decl(f_7786)
static void C_ccall f_7786(C_word c,C_word *av) C_noret;
C_noret_decl(f_7837)
static void C_ccall f_7837(C_word c,C_word *av) C_noret;
C_noret_decl(f_7874)
static void C_ccall f_7874(C_word c,C_word *av) C_noret;
C_noret_decl(f_7876)
static void C_fcall f_7876(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7926)
static void C_ccall f_7926(C_word c,C_word *av) C_noret;
C_noret_decl(f_7930)
static void C_ccall f_7930(C_word c,C_word *av) C_noret;
C_noret_decl(f_7944)
static void C_ccall f_7944(C_word c,C_word *av) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word *av) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word *av) C_noret;
C_noret_decl(f_7962)
static void C_ccall f_7962(C_word c,C_word *av) C_noret;
C_noret_decl(f_7966)
static void C_ccall f_7966(C_word c,C_word *av) C_noret;
C_noret_decl(f_8008)
static void C_ccall f_8008(C_word c,C_word *av) C_noret;
C_noret_decl(f_8012)
static void C_ccall f_8012(C_word c,C_word *av) C_noret;
C_noret_decl(f_8060)
static void C_ccall f_8060(C_word c,C_word *av) C_noret;
C_noret_decl(f_8064)
static void C_ccall f_8064(C_word c,C_word *av) C_noret;
C_noret_decl(f_8069)
static void C_ccall f_8069(C_word c,C_word *av) C_noret;
C_noret_decl(f_8079)
static void C_ccall f_8079(C_word c,C_word *av) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086(C_word c,C_word *av) C_noret;
C_noret_decl(f_8089)
static void C_fcall f_8089(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8093)
static void C_fcall f_8093(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8120)
static void C_ccall f_8120(C_word c,C_word *av) C_noret;
C_noret_decl(f_8126)
static void C_ccall f_8126(C_word c,C_word *av) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word *av) C_noret;
C_noret_decl(f_8139)
static void C_ccall f_8139(C_word c,C_word *av) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word *av) C_noret;
C_noret_decl(f_8155)
static void C_ccall f_8155(C_word c,C_word *av) C_noret;
C_noret_decl(f_8157)
static void C_fcall f_8157(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8192)
static void C_ccall f_8192(C_word c,C_word *av) C_noret;
C_noret_decl(f_8198)
static void C_ccall f_8198(C_word c,C_word *av) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word *av) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word *av) C_noret;
C_noret_decl(f_8222)
static void C_ccall f_8222(C_word c,C_word *av) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word *av) C_noret;
C_noret_decl(f_8240)
static void C_ccall f_8240(C_word c,C_word *av) C_noret;
C_noret_decl(f_8249)
static void C_ccall f_8249(C_word c,C_word *av) C_noret;
C_noret_decl(f_8259)
static void C_ccall f_8259(C_word c,C_word *av) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word *av) C_noret;
C_noret_decl(f_8267)
static void C_ccall f_8267(C_word c,C_word *av) C_noret;
C_noret_decl(f_8282)
static void C_ccall f_8282(C_word c,C_word *av) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word *av) C_noret;
C_noret_decl(f_8300)
static void C_ccall f_8300(C_word c,C_word *av) C_noret;
C_noret_decl(f_8367)
static void C_ccall f_8367(C_word c,C_word *av) C_noret;
C_noret_decl(f_8369)
static void C_fcall f_8369(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8394)
static void C_ccall f_8394(C_word c,C_word *av) C_noret;
C_noret_decl(f_8417)
static void C_ccall f_8417(C_word c,C_word *av) C_noret;
C_noret_decl(f_8420)
static void C_fcall f_8420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8423)
static void C_ccall f_8423(C_word c,C_word *av) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word *av) C_noret;
C_noret_decl(f_8477)
static void C_ccall f_8477(C_word c,C_word *av) C_noret;
C_noret_decl(f_8481)
static void C_ccall f_8481(C_word c,C_word *av) C_noret;
C_noret_decl(f_8486)
static void C_fcall f_8486(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8503)
static void C_ccall f_8503(C_word c,C_word *av) C_noret;
C_noret_decl(f_8511)
static void C_ccall f_8511(C_word c,C_word *av) C_noret;
C_noret_decl(f_8513)
static void C_fcall f_8513(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8538)
static void C_ccall f_8538(C_word c,C_word *av) C_noret;
C_noret_decl(f_8574)
static void C_ccall f_8574(C_word c,C_word *av) C_noret;
C_noret_decl(f_8608)
static void C_ccall f_8608(C_word c,C_word *av) C_noret;
C_noret_decl(f_8639)
static void C_fcall f_8639(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8662)
static void C_ccall f_8662(C_word c,C_word *av) C_noret;
C_noret_decl(f_8683)
static void C_ccall f_8683(C_word c,C_word *av) C_noret;
C_noret_decl(f_8705)
static void C_ccall f_8705(C_word c,C_word *av) C_noret;
C_noret_decl(f_8713)
static void C_ccall f_8713(C_word c,C_word *av) C_noret;
C_noret_decl(f_8717)
static void C_ccall f_8717(C_word c,C_word *av) C_noret;
C_noret_decl(f_8725)
static void C_ccall f_8725(C_word c,C_word *av) C_noret;
C_noret_decl(f_8746)
static void C_ccall f_8746(C_word c,C_word *av) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750(C_word c,C_word *av) C_noret;
C_noret_decl(f_8762)
static void C_ccall f_8762(C_word c,C_word *av) C_noret;
C_noret_decl(f_8789)
static void C_fcall f_8789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8801)
static void C_ccall f_8801(C_word c,C_word *av) C_noret;
C_noret_decl(f_8803)
static void C_fcall f_8803(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8828)
static void C_ccall f_8828(C_word c,C_word *av) C_noret;
C_noret_decl(f_8862)
static void C_fcall f_8862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8888)
static void C_ccall f_8888(C_word c,C_word *av) C_noret;
C_noret_decl(f_8890)
static void C_fcall f_8890(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8915)
static void C_ccall f_8915(C_word c,C_word *av) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word *av) C_noret;
C_noret_decl(f_9001)
static void C_fcall f_9001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9026)
static void C_ccall f_9026(C_word c,C_word *av) C_noret;
C_noret_decl(f_9066)
static void C_ccall f_9066(C_word c,C_word *av) C_noret;
C_noret_decl(f_9107)
static void C_fcall f_9107(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9136)
static void C_ccall f_9136(C_word c,C_word *av) C_noret;
C_noret_decl(f_9138)
static void C_fcall f_9138(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word *av) C_noret;
C_noret_decl(f_9199)
static void C_ccall f_9199(C_word c,C_word *av) C_noret;
C_noret_decl(f_9201)
static void C_fcall f_9201(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9226)
static void C_ccall f_9226(C_word c,C_word *av) C_noret;
C_noret_decl(f_9238)
static void C_ccall f_9238(C_word c,C_word *av) C_noret;
C_noret_decl(f_9244)
static void C_ccall f_9244(C_word c,C_word *av) C_noret;
C_noret_decl(f_9267)
static void C_ccall f_9267(C_word c,C_word *av) C_noret;
C_noret_decl(f_9269)
static void C_fcall f_9269(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9294)
static void C_ccall f_9294(C_word c,C_word *av) C_noret;
C_noret_decl(f_9305)
static void C_fcall f_9305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9309)
static void C_ccall f_9309(C_word c,C_word *av) C_noret;
C_noret_decl(f_9312)
static void C_ccall f_9312(C_word c,C_word *av) C_noret;
C_noret_decl(f_9319)
static void C_ccall f_9319(C_word c,C_word *av) C_noret;
C_noret_decl(f_9333)
static void C_ccall f_9333(C_word c,C_word *av) C_noret;
C_noret_decl(f_9439)
static void C_ccall f_9439(C_word c,C_word *av) C_noret;
C_noret_decl(f_9441)
static void C_fcall f_9441(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9466)
static void C_ccall f_9466(C_word c,C_word *av) C_noret;
C_noret_decl(f_9484)
static void C_ccall f_9484(C_word c,C_word *av) C_noret;
C_noret_decl(f_9487)
static void C_ccall f_9487(C_word c,C_word *av) C_noret;
C_noret_decl(f_9493)
static void C_ccall f_9493(C_word c,C_word *av) C_noret;
C_noret_decl(f_9499)
static void C_ccall f_9499(C_word c,C_word *av) C_noret;
C_noret_decl(f_9533)
static void C_fcall f_9533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9546)
static void C_ccall f_9546(C_word c,C_word *av) C_noret;
C_noret_decl(f_9548)
static void C_fcall f_9548(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9573)
static void C_ccall f_9573(C_word c,C_word *av) C_noret;
C_noret_decl(f_9603)
static void C_ccall f_9603(C_word c,C_word *av) C_noret;
C_noret_decl(f_9605)
static void C_fcall f_9605(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9630)
static void C_ccall f_9630(C_word c,C_word *av) C_noret;
C_noret_decl(f_9703)
static void C_ccall f_9703(C_word c,C_word *av) C_noret;
C_noret_decl(f_9706)
static void C_ccall f_9706(C_word c,C_word *av) C_noret;
C_noret_decl(f_9715)
static void C_ccall f_9715(C_word c,C_word *av) C_noret;
C_noret_decl(f_9719)
static void C_ccall f_9719(C_word c,C_word *av) C_noret;
C_noret_decl(f_9723)
static void C_ccall f_9723(C_word c,C_word *av) C_noret;
C_noret_decl(f_9725)
static void C_fcall f_9725(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9773)
static void C_fcall f_9773(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9798)
static void C_ccall f_9798(C_word c,C_word *av) C_noret;
C_noret_decl(f_9826)
static void C_ccall f_9826(C_word c,C_word *av) C_noret;
C_noret_decl(f_9850)
static void C_ccall f_9850(C_word c,C_word *av) C_noret;
C_noret_decl(f_9884)
static void C_ccall f_9884(C_word c,C_word *av) C_noret;
C_noret_decl(f_9888)
static void C_ccall f_9888(C_word c,C_word *av) C_noret;
C_noret_decl(f_9898)
static void C_fcall f_9898(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9922)
static void C_ccall f_9922(C_word c,C_word *av) C_noret;
C_noret_decl(f_9937)
static void C_ccall f_9937(C_word c,C_word *av) C_noret;
C_noret_decl(f_9949)
static void C_ccall f_9949(C_word c,C_word *av) C_noret;
C_noret_decl(f_9974)
static void C_fcall f_9974(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9999)
static void C_ccall f_9999(C_word c,C_word *av) C_noret;
C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word *av) C_noret;

C_noret_decl(trf_10031)
static void C_ccall trf_10031(C_word c,C_word *av) C_noret;
static void C_ccall trf_10031(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10031(t0,t1,t2);}

C_noret_decl(trf_10087)
static void C_ccall trf_10087(C_word c,C_word *av) C_noret;
static void C_ccall trf_10087(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_10087(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10137)
static void C_ccall trf_10137(C_word c,C_word *av) C_noret;
static void C_ccall trf_10137(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10137(t0,t1);}

C_noret_decl(trf_10157)
static void C_ccall trf_10157(C_word c,C_word *av) C_noret;
static void C_ccall trf_10157(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10157(t0,t1,t2);}

C_noret_decl(trf_10214)
static void C_ccall trf_10214(C_word c,C_word *av) C_noret;
static void C_ccall trf_10214(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10214(t0,t1,t2);}

C_noret_decl(trf_10265)
static void C_ccall trf_10265(C_word c,C_word *av) C_noret;
static void C_ccall trf_10265(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10265(t0,t1,t2);}

C_noret_decl(trf_10369)
static void C_ccall trf_10369(C_word c,C_word *av) C_noret;
static void C_ccall trf_10369(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10369(t0,t1,t2);}

C_noret_decl(trf_10449)
static void C_ccall trf_10449(C_word c,C_word *av) C_noret;
static void C_ccall trf_10449(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10449(t0,t1,t2,t3);}

C_noret_decl(trf_10553)
static void C_ccall trf_10553(C_word c,C_word *av) C_noret;
static void C_ccall trf_10553(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10553(t0,t1,t2);}

C_noret_decl(trf_10608)
static void C_ccall trf_10608(C_word c,C_word *av) C_noret;
static void C_ccall trf_10608(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10608(t0,t1,t2,t3);}

C_noret_decl(trf_10779)
static void C_ccall trf_10779(C_word c,C_word *av) C_noret;
static void C_ccall trf_10779(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10779(t0,t1,t2);}

C_noret_decl(trf_10812)
static void C_ccall trf_10812(C_word c,C_word *av) C_noret;
static void C_ccall trf_10812(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10812(t0,t1,t2);}

C_noret_decl(trf_10824)
static void C_ccall trf_10824(C_word c,C_word *av) C_noret;
static void C_ccall trf_10824(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10824(t0,t1,t2);}

C_noret_decl(trf_10891)
static void C_ccall trf_10891(C_word c,C_word *av) C_noret;
static void C_ccall trf_10891(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10891(t0,t1,t2,t3);}

C_noret_decl(trf_10939)
static void C_ccall trf_10939(C_word c,C_word *av) C_noret;
static void C_ccall trf_10939(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10939(t0,t1,t2);}

C_noret_decl(trf_10988)
static void C_ccall trf_10988(C_word c,C_word *av) C_noret;
static void C_ccall trf_10988(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10988(t0,t1,t2);}

C_noret_decl(trf_11000)
static void C_ccall trf_11000(C_word c,C_word *av) C_noret;
static void C_ccall trf_11000(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11000(t0,t1,t2);}

C_noret_decl(trf_11047)
static void C_ccall trf_11047(C_word c,C_word *av) C_noret;
static void C_ccall trf_11047(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_11047(t0,t1,t2,t3);}

C_noret_decl(trf_11101)
static void C_ccall trf_11101(C_word c,C_word *av) C_noret;
static void C_ccall trf_11101(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11101(t0,t1,t2);}

C_noret_decl(trf_11254)
static void C_ccall trf_11254(C_word c,C_word *av) C_noret;
static void C_ccall trf_11254(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11254(t0,t1,t2);}

C_noret_decl(trf_11325)
static void C_ccall trf_11325(C_word c,C_word *av) C_noret;
static void C_ccall trf_11325(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11325(t0,t1,t2);}

C_noret_decl(trf_11388)
static void C_ccall trf_11388(C_word c,C_word *av) C_noret;
static void C_ccall trf_11388(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11388(t0,t1,t2);}

C_noret_decl(trf_11449)
static void C_ccall trf_11449(C_word c,C_word *av) C_noret;
static void C_ccall trf_11449(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11449(t0,t1,t2);}

C_noret_decl(trf_11504)
static void C_ccall trf_11504(C_word c,C_word *av) C_noret;
static void C_ccall trf_11504(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11504(t0,t1);}

C_noret_decl(trf_11541)
static void C_ccall trf_11541(C_word c,C_word *av) C_noret;
static void C_ccall trf_11541(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11541(t0,t1);}

C_noret_decl(trf_11633)
static void C_ccall trf_11633(C_word c,C_word *av) C_noret;
static void C_ccall trf_11633(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11633(t0,t1);}

C_noret_decl(trf_11680)
static void C_ccall trf_11680(C_word c,C_word *av) C_noret;
static void C_ccall trf_11680(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_11680(t0,t1,t2,t3);}

C_noret_decl(trf_11714)
static void C_ccall trf_11714(C_word c,C_word *av) C_noret;
static void C_ccall trf_11714(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_11714(t0,t1,t2,t3);}

C_noret_decl(trf_11761)
static void C_ccall trf_11761(C_word c,C_word *av) C_noret;
static void C_ccall trf_11761(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_11761(t0,t1,t2,t3);}

C_noret_decl(trf_11801)
static void C_ccall trf_11801(C_word c,C_word *av) C_noret;
static void C_ccall trf_11801(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_11801(t0,t1,t2,t3);}

C_noret_decl(trf_11942)
static void C_ccall trf_11942(C_word c,C_word *av) C_noret;
static void C_ccall trf_11942(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11942(t0,t1);}

C_noret_decl(trf_12158)
static void C_ccall trf_12158(C_word c,C_word *av) C_noret;
static void C_ccall trf_12158(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12158(t0,t1);}

C_noret_decl(trf_12199)
static void C_ccall trf_12199(C_word c,C_word *av) C_noret;
static void C_ccall trf_12199(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12199(t0,t1);}

C_noret_decl(trf_12471)
static void C_ccall trf_12471(C_word c,C_word *av) C_noret;
static void C_ccall trf_12471(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12471(t0,t1,t2);}

C_noret_decl(trf_12496)
static void C_ccall trf_12496(C_word c,C_word *av) C_noret;
static void C_ccall trf_12496(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12496(t0,t1);}

C_noret_decl(trf_12511)
static void C_ccall trf_12511(C_word c,C_word *av) C_noret;
static void C_ccall trf_12511(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12511(t0,t1);}

C_noret_decl(trf_12594)
static void C_ccall trf_12594(C_word c,C_word *av) C_noret;
static void C_ccall trf_12594(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12594(t0,t1);}

C_noret_decl(trf_12634)
static void C_ccall trf_12634(C_word c,C_word *av) C_noret;
static void C_ccall trf_12634(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12634(t0,t1);}

C_noret_decl(trf_12652)
static void C_ccall trf_12652(C_word c,C_word *av) C_noret;
static void C_ccall trf_12652(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12652(t0,t1);}

C_noret_decl(trf_12676)
static void C_ccall trf_12676(C_word c,C_word *av) C_noret;
static void C_ccall trf_12676(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12676(t0,t1);}

C_noret_decl(trf_12702)
static void C_ccall trf_12702(C_word c,C_word *av) C_noret;
static void C_ccall trf_12702(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12702(t0,t1);}

C_noret_decl(trf_12745)
static void C_ccall trf_12745(C_word c,C_word *av) C_noret;
static void C_ccall trf_12745(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12745(t0,t1);}

C_noret_decl(trf_12789)
static void C_ccall trf_12789(C_word c,C_word *av) C_noret;
static void C_ccall trf_12789(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12789(t0,t1);}

C_noret_decl(trf_12833)
static void C_ccall trf_12833(C_word c,C_word *av) C_noret;
static void C_ccall trf_12833(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12833(t0,t1);}

C_noret_decl(trf_12851)
static void C_ccall trf_12851(C_word c,C_word *av) C_noret;
static void C_ccall trf_12851(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12851(t0,t1);}

C_noret_decl(trf_12878)
static void C_ccall trf_12878(C_word c,C_word *av) C_noret;
static void C_ccall trf_12878(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12878(t0,t1);}

C_noret_decl(trf_12925)
static void C_ccall trf_12925(C_word c,C_word *av) C_noret;
static void C_ccall trf_12925(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12925(t0,t1,t2);}

C_noret_decl(trf_12952)
static void C_ccall trf_12952(C_word c,C_word *av) C_noret;
static void C_ccall trf_12952(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12952(t0,t1);}

C_noret_decl(trf_13603)
static void C_ccall trf_13603(C_word c,C_word *av) C_noret;
static void C_ccall trf_13603(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_13603(t0,t1,t2);}

C_noret_decl(trf_13631)
static void C_ccall trf_13631(C_word c,C_word *av) C_noret;
static void C_ccall trf_13631(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13631(t0,t1);}

C_noret_decl(trf_13650)
static void C_ccall trf_13650(C_word c,C_word *av) C_noret;
static void C_ccall trf_13650(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13650(t0,t1);}

C_noret_decl(trf_13659)
static void C_ccall trf_13659(C_word c,C_word *av) C_noret;
static void C_ccall trf_13659(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13659(t0,t1);}

C_noret_decl(trf_13671)
static void C_ccall trf_13671(C_word c,C_word *av) C_noret;
static void C_ccall trf_13671(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13671(t0,t1);}

C_noret_decl(trf_13683)
static void C_ccall trf_13683(C_word c,C_word *av) C_noret;
static void C_ccall trf_13683(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13683(t0,t1);}

C_noret_decl(trf_13695)
static void C_ccall trf_13695(C_word c,C_word *av) C_noret;
static void C_ccall trf_13695(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13695(t0,t1);}

C_noret_decl(trf_13705)
static void C_ccall trf_13705(C_word c,C_word *av) C_noret;
static void C_ccall trf_13705(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_13705(t0,t1,t2);}

C_noret_decl(trf_13732)
static void C_ccall trf_13732(C_word c,C_word *av) C_noret;
static void C_ccall trf_13732(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13732(t0,t1);}

C_noret_decl(trf_14125)
static void C_ccall trf_14125(C_word c,C_word *av) C_noret;
static void C_ccall trf_14125(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14125(t0,t1);}

C_noret_decl(trf_14137)
static void C_ccall trf_14137(C_word c,C_word *av) C_noret;
static void C_ccall trf_14137(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14137(t0,t1);}

C_noret_decl(trf_14147)
static void C_ccall trf_14147(C_word c,C_word *av) C_noret;
static void C_ccall trf_14147(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_14147(t0,t1,t2);}

C_noret_decl(trf_14174)
static void C_ccall trf_14174(C_word c,C_word *av) C_noret;
static void C_ccall trf_14174(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14174(t0,t1);}

C_noret_decl(trf_14673)
static void C_ccall trf_14673(C_word c,C_word *av) C_noret;
static void C_ccall trf_14673(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14673(t0,t1);}

C_noret_decl(trf_14849)
static void C_ccall trf_14849(C_word c,C_word *av) C_noret;
static void C_ccall trf_14849(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14849(t0,t1);}

C_noret_decl(trf_14924)
static void C_ccall trf_14924(C_word c,C_word *av) C_noret;
static void C_ccall trf_14924(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14924(t0,t1);}

C_noret_decl(trf_15011)
static void C_ccall trf_15011(C_word c,C_word *av) C_noret;
static void C_ccall trf_15011(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15011(t0,t1);}

C_noret_decl(trf_15032)
static void C_ccall trf_15032(C_word c,C_word *av) C_noret;
static void C_ccall trf_15032(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15032(t0,t1);}

C_noret_decl(trf_15050)
static void C_ccall trf_15050(C_word c,C_word *av) C_noret;
static void C_ccall trf_15050(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15050(t0,t1);}

C_noret_decl(trf_15072)
static void C_ccall trf_15072(C_word c,C_word *av) C_noret;
static void C_ccall trf_15072(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15072(t0,t1);}

C_noret_decl(trf_15465)
static void C_ccall trf_15465(C_word c,C_word *av) C_noret;
static void C_ccall trf_15465(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15465(t0,t1);}

C_noret_decl(trf_15473)
static void C_ccall trf_15473(C_word c,C_word *av) C_noret;
static void C_ccall trf_15473(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15473(t0,t1,t2);}

C_noret_decl(trf_15497)
static void C_ccall trf_15497(C_word c,C_word *av) C_noret;
static void C_ccall trf_15497(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15497(t0,t1);}

C_noret_decl(trf_15529)
static void C_ccall trf_15529(C_word c,C_word *av) C_noret;
static void C_ccall trf_15529(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15529(t0,t1);}

C_noret_decl(trf_15537)
static void C_ccall trf_15537(C_word c,C_word *av) C_noret;
static void C_ccall trf_15537(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15537(t0,t1,t2);}

C_noret_decl(trf_15585)
static void C_ccall trf_15585(C_word c,C_word *av) C_noret;
static void C_ccall trf_15585(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_15585(t0,t1,t2,t3);}

C_noret_decl(trf_15619)
static void C_ccall trf_15619(C_word c,C_word *av) C_noret;
static void C_ccall trf_15619(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15619(t0,t1);}

C_noret_decl(trf_15769)
static void C_ccall trf_15769(C_word c,C_word *av) C_noret;
static void C_ccall trf_15769(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_15769(t0,t1,t2,t3);}

C_noret_decl(trf_15771)
static void C_ccall trf_15771(C_word c,C_word *av) C_noret;
static void C_ccall trf_15771(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15771(t0,t1,t2);}

C_noret_decl(trf_15783)
static void C_ccall trf_15783(C_word c,C_word *av) C_noret;
static void C_ccall trf_15783(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15783(t0,t1,t2);}

C_noret_decl(trf_15823)
static void C_ccall trf_15823(C_word c,C_word *av) C_noret;
static void C_ccall trf_15823(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15823(t0,t1);}

C_noret_decl(trf_15927)
static void C_ccall trf_15927(C_word c,C_word *av) C_noret;
static void C_ccall trf_15927(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15927(t0,t1);}

C_noret_decl(trf_15972)
static void C_ccall trf_15972(C_word c,C_word *av) C_noret;
static void C_ccall trf_15972(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_15972(t0,t1,t2,t3,t4);}

C_noret_decl(trf_16146)
static void C_ccall trf_16146(C_word c,C_word *av) C_noret;
static void C_ccall trf_16146(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_16146(t0,t1);}

C_noret_decl(trf_16341)
static void C_ccall trf_16341(C_word c,C_word *av) C_noret;
static void C_ccall trf_16341(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_16341(t0,t1,t2);}

C_noret_decl(trf_16375)
static void C_ccall trf_16375(C_word c,C_word *av) C_noret;
static void C_ccall trf_16375(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_16375(t0,t1,t2);}

C_noret_decl(trf_16565)
static void C_ccall trf_16565(C_word c,C_word *av) C_noret;
static void C_ccall trf_16565(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_16565(t0,t1);}

C_noret_decl(trf_16572)
static void C_ccall trf_16572(C_word c,C_word *av) C_noret;
static void C_ccall trf_16572(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_16572(t0,t1,t2);}

C_noret_decl(trf_16654)
static void C_ccall trf_16654(C_word c,C_word *av) C_noret;
static void C_ccall trf_16654(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_16654(t0,t1,t2,t3);}

C_noret_decl(trf_16706)
static void C_ccall trf_16706(C_word c,C_word *av) C_noret;
static void C_ccall trf_16706(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_16706(t0,t1,t2);}

C_noret_decl(trf_16745)
static void C_ccall trf_16745(C_word c,C_word *av) C_noret;
static void C_ccall trf_16745(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_16745(t0,t1,t2);}

C_noret_decl(trf_16778)
static void C_ccall trf_16778(C_word c,C_word *av) C_noret;
static void C_ccall trf_16778(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_16778(t0,t1,t2);}

C_noret_decl(trf_16808)
static void C_ccall trf_16808(C_word c,C_word *av) C_noret;
static void C_ccall trf_16808(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_16808(t0,t1);}

C_noret_decl(trf_16884)
static void C_ccall trf_16884(C_word c,C_word *av) C_noret;
static void C_ccall trf_16884(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_16884(t0,t1);}

C_noret_decl(trf_17179)
static void C_ccall trf_17179(C_word c,C_word *av) C_noret;
static void C_ccall trf_17179(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_17179(t0,t1,t2);}

C_noret_decl(trf_5249)
static void C_ccall trf_5249(C_word c,C_word *av) C_noret;
static void C_ccall trf_5249(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5249(t0,t1,t2);}

C_noret_decl(trf_5307)
static void C_ccall trf_5307(C_word c,C_word *av) C_noret;
static void C_ccall trf_5307(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_5307(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5510)
static void C_ccall trf_5510(C_word c,C_word *av) C_noret;
static void C_ccall trf_5510(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5510(t0,t1,t2);}

C_noret_decl(trf_5516)
static void C_ccall trf_5516(C_word c,C_word *av) C_noret;
static void C_ccall trf_5516(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5516(t0,t1,t2);}

C_noret_decl(trf_5544)
static void C_ccall trf_5544(C_word c,C_word *av) C_noret;
static void C_ccall trf_5544(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5544(t0,t1,t2);}

C_noret_decl(trf_5550)
static void C_ccall trf_5550(C_word c,C_word *av) C_noret;
static void C_ccall trf_5550(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5550(t0,t1,t2);}

C_noret_decl(trf_5574)
static void C_ccall trf_5574(C_word c,C_word *av) C_noret;
static void C_ccall trf_5574(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5574(t0,t1,t2);}

C_noret_decl(trf_5580)
static void C_ccall trf_5580(C_word c,C_word *av) C_noret;
static void C_ccall trf_5580(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5580(t0,t1,t2,t3);}

C_noret_decl(trf_5803)
static void C_ccall trf_5803(C_word c,C_word *av) C_noret;
static void C_ccall trf_5803(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5803(t0,t1,t2);}

C_noret_decl(trf_5811)
static void C_ccall trf_5811(C_word c,C_word *av) C_noret;
static void C_ccall trf_5811(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5811(t0,t1,t2,t3);}

C_noret_decl(trf_5876)
static void C_ccall trf_5876(C_word c,C_word *av) C_noret;
static void C_ccall trf_5876(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5876(t0,t1,t2);}

C_noret_decl(trf_5910)
static void C_ccall trf_5910(C_word c,C_word *av) C_noret;
static void C_ccall trf_5910(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5910(t0,t1);}

C_noret_decl(trf_5969)
static void C_ccall trf_5969(C_word c,C_word *av) C_noret;
static void C_ccall trf_5969(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5969(t0,t1,t2);}

C_noret_decl(trf_5975)
static void C_ccall trf_5975(C_word c,C_word *av) C_noret;
static void C_ccall trf_5975(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5975(t0,t1,t2,t3);}

C_noret_decl(trf_6158)
static void C_ccall trf_6158(C_word c,C_word *av) C_noret;
static void C_ccall trf_6158(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6158(t0,t1,t2);}

C_noret_decl(trf_6271)
static void C_ccall trf_6271(C_word c,C_word *av) C_noret;
static void C_ccall trf_6271(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6271(t0,t1,t2);}

C_noret_decl(trf_6454)
static void C_ccall trf_6454(C_word c,C_word *av) C_noret;
static void C_ccall trf_6454(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6454(t0,t1,t2);}

C_noret_decl(trf_6478)
static void C_ccall trf_6478(C_word c,C_word *av) C_noret;
static void C_ccall trf_6478(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6478(t0,t1);}

C_noret_decl(trf_6520)
static void C_ccall trf_6520(C_word c,C_word *av) C_noret;
static void C_ccall trf_6520(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6520(t0,t1,t2);}

C_noret_decl(trf_6543)
static void C_ccall trf_6543(C_word c,C_word *av) C_noret;
static void C_ccall trf_6543(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6543(t0,t1,t2);}

C_noret_decl(trf_6598)
static void C_ccall trf_6598(C_word c,C_word *av) C_noret;
static void C_ccall trf_6598(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6598(t0,t1,t2);}

C_noret_decl(trf_6600)
static void C_ccall trf_6600(C_word c,C_word *av) C_noret;
static void C_ccall trf_6600(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6600(t0,t1,t2);}

C_noret_decl(trf_6632)
static void C_ccall trf_6632(C_word c,C_word *av) C_noret;
static void C_ccall trf_6632(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6632(t0,t1,t2);}

C_noret_decl(trf_6712)
static void C_ccall trf_6712(C_word c,C_word *av) C_noret;
static void C_ccall trf_6712(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6712(t0,t1);}

C_noret_decl(trf_6716)
static void C_ccall trf_6716(C_word c,C_word *av) C_noret;
static void C_ccall trf_6716(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6716(t0,t1,t2);}

C_noret_decl(trf_6734)
static void C_ccall trf_6734(C_word c,C_word *av) C_noret;
static void C_ccall trf_6734(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6734(t0,t1,t2);}

C_noret_decl(trf_6824)
static void C_ccall trf_6824(C_word c,C_word *av) C_noret;
static void C_ccall trf_6824(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6824(t0,t1,t2);}

C_noret_decl(trf_6862)
static void C_ccall trf_6862(C_word c,C_word *av) C_noret;
static void C_ccall trf_6862(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6862(t0,t1);}

C_noret_decl(trf_6883)
static void C_ccall trf_6883(C_word c,C_word *av) C_noret;
static void C_ccall trf_6883(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6883(t0,t1,t2,t3);}

C_noret_decl(trf_6933)
static void C_ccall trf_6933(C_word c,C_word *av) C_noret;
static void C_ccall trf_6933(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6933(t0,t1,t2,t3);}

C_noret_decl(trf_6982)
static void C_ccall trf_6982(C_word c,C_word *av) C_noret;
static void C_ccall trf_6982(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6982(t0,t1,t2);}

C_noret_decl(trf_7004)
static void C_ccall trf_7004(C_word c,C_word *av) C_noret;
static void C_ccall trf_7004(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7004(t0,t1);}

C_noret_decl(trf_7011)
static void C_ccall trf_7011(C_word c,C_word *av) C_noret;
static void C_ccall trf_7011(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7011(t0,t1);}

C_noret_decl(trf_7152)
static void C_ccall trf_7152(C_word c,C_word *av) C_noret;
static void C_ccall trf_7152(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7152(t0,t1);}

C_noret_decl(trf_7199)
static void C_ccall trf_7199(C_word c,C_word *av) C_noret;
static void C_ccall trf_7199(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7199(t0,t1,t2);}

C_noret_decl(trf_7239)
static void C_ccall trf_7239(C_word c,C_word *av) C_noret;
static void C_ccall trf_7239(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7239(t0,t1,t2,t3);}

C_noret_decl(trf_7245)
static void C_ccall trf_7245(C_word c,C_word *av) C_noret;
static void C_ccall trf_7245(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7245(t0,t1,t2,t3);}

C_noret_decl(trf_7303)
static void C_ccall trf_7303(C_word c,C_word *av) C_noret;
static void C_ccall trf_7303(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_7303(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7430)
static void C_ccall trf_7430(C_word c,C_word *av) C_noret;
static void C_ccall trf_7430(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7430(t0,t1);}

C_noret_decl(trf_7534)
static void C_ccall trf_7534(C_word c,C_word *av) C_noret;
static void C_ccall trf_7534(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7534(t0,t1,t2);}

C_noret_decl(trf_7558)
static void C_ccall trf_7558(C_word c,C_word *av) C_noret;
static void C_ccall trf_7558(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7558(t0,t1);}

C_noret_decl(trf_7649)
static void C_ccall trf_7649(C_word c,C_word *av) C_noret;
static void C_ccall trf_7649(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7649(t0,t1);}

C_noret_decl(trf_7681)
static void C_ccall trf_7681(C_word c,C_word *av) C_noret;
static void C_ccall trf_7681(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7681(t0,t1,t2);}

C_noret_decl(trf_7706)
static void C_ccall trf_7706(C_word c,C_word *av) C_noret;
static void C_ccall trf_7706(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7706(t0,t1,t2);}

C_noret_decl(trf_7876)
static void C_ccall trf_7876(C_word c,C_word *av) C_noret;
static void C_ccall trf_7876(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7876(t0,t1,t2);}

C_noret_decl(trf_8089)
static void C_ccall trf_8089(C_word c,C_word *av) C_noret;
static void C_ccall trf_8089(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8089(t0,t1);}

C_noret_decl(trf_8093)
static void C_ccall trf_8093(C_word c,C_word *av) C_noret;
static void C_ccall trf_8093(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8093(t0,t1,t2);}

C_noret_decl(trf_8157)
static void C_ccall trf_8157(C_word c,C_word *av) C_noret;
static void C_ccall trf_8157(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8157(t0,t1,t2);}

C_noret_decl(trf_8369)
static void C_ccall trf_8369(C_word c,C_word *av) C_noret;
static void C_ccall trf_8369(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8369(t0,t1,t2);}

C_noret_decl(trf_8420)
static void C_ccall trf_8420(C_word c,C_word *av) C_noret;
static void C_ccall trf_8420(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8420(t0,t1);}

C_noret_decl(trf_8486)
static void C_ccall trf_8486(C_word c,C_word *av) C_noret;
static void C_ccall trf_8486(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8486(t0,t1,t2);}

C_noret_decl(trf_8513)
static void C_ccall trf_8513(C_word c,C_word *av) C_noret;
static void C_ccall trf_8513(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8513(t0,t1,t2);}

C_noret_decl(trf_8639)
static void C_ccall trf_8639(C_word c,C_word *av) C_noret;
static void C_ccall trf_8639(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_8639(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8789)
static void C_ccall trf_8789(C_word c,C_word *av) C_noret;
static void C_ccall trf_8789(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8789(t0,t1);}

C_noret_decl(trf_8803)
static void C_ccall trf_8803(C_word c,C_word *av) C_noret;
static void C_ccall trf_8803(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8803(t0,t1,t2);}

C_noret_decl(trf_8862)
static void C_ccall trf_8862(C_word c,C_word *av) C_noret;
static void C_ccall trf_8862(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8862(t0,t1);}

C_noret_decl(trf_8890)
static void C_ccall trf_8890(C_word c,C_word *av) C_noret;
static void C_ccall trf_8890(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8890(t0,t1,t2);}

C_noret_decl(trf_9001)
static void C_ccall trf_9001(C_word c,C_word *av) C_noret;
static void C_ccall trf_9001(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9001(t0,t1,t2);}

C_noret_decl(trf_9107)
static void C_ccall trf_9107(C_word c,C_word *av) C_noret;
static void C_ccall trf_9107(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9107(t0,t1);}

C_noret_decl(trf_9138)
static void C_ccall trf_9138(C_word c,C_word *av) C_noret;
static void C_ccall trf_9138(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9138(t0,t1,t2);}

C_noret_decl(trf_9201)
static void C_ccall trf_9201(C_word c,C_word *av) C_noret;
static void C_ccall trf_9201(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9201(t0,t1,t2);}

C_noret_decl(trf_9269)
static void C_ccall trf_9269(C_word c,C_word *av) C_noret;
static void C_ccall trf_9269(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9269(t0,t1,t2);}

C_noret_decl(trf_9305)
static void C_ccall trf_9305(C_word c,C_word *av) C_noret;
static void C_ccall trf_9305(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9305(t0,t1);}

C_noret_decl(trf_9441)
static void C_ccall trf_9441(C_word c,C_word *av) C_noret;
static void C_ccall trf_9441(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9441(t0,t1,t2);}

C_noret_decl(trf_9533)
static void C_ccall trf_9533(C_word c,C_word *av) C_noret;
static void C_ccall trf_9533(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9533(t0,t1);}

C_noret_decl(trf_9548)
static void C_ccall trf_9548(C_word c,C_word *av) C_noret;
static void C_ccall trf_9548(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9548(t0,t1,t2);}

C_noret_decl(trf_9605)
static void C_ccall trf_9605(C_word c,C_word *av) C_noret;
static void C_ccall trf_9605(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9605(t0,t1,t2);}

C_noret_decl(trf_9725)
static void C_ccall trf_9725(C_word c,C_word *av) C_noret;
static void C_ccall trf_9725(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9725(t0,t1,t2,t3);}

C_noret_decl(trf_9773)
static void C_ccall trf_9773(C_word c,C_word *av) C_noret;
static void C_ccall trf_9773(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9773(t0,t1,t2);}

C_noret_decl(trf_9898)
static void C_ccall trf_9898(C_word c,C_word *av) C_noret;
static void C_ccall trf_9898(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9898(t0,t1,t2,t3);}

C_noret_decl(trf_9974)
static void C_ccall trf_9974(C_word c,C_word *av) C_noret;
static void C_ccall trf_9974(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9974(t0,t1,t2);}

/* f18834 in chicken.compiler.support#print-version in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f18834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f18834,2,av);}
/* support.scm:1680: chicken.base#print */
t2=*((C_word*)lf[220]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10027 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10029(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_10029,2,av);}
a=C_alloc(6);
/* support.scm:629: cons* */
f_5574(((C_word*)t0)[2],lf[190],C_a_i_list(&a,2,((C_word*)t0)[3],t1));}

/* map-loop1919 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10031(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10031,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10056,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:629: g1925 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10054 in map-loop1919 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10056(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10056,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10031(t6,((C_word*)t0)[5],t5);}

/* loop in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10087(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_10087,5,t0,t1,t2,t3,t4);}
a=C_alloc(36);
t5=t2;
if(C_truep(C_i_zerop(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10099,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm:634: scheme#reverse */
t7=*((C_word*)lf[82]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=C_s_a_i_minus(&a,2,t2,C_fix(1));
t7=t6;
t8=C_i_cdr(t3);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10126,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t7,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t11=t3;
t12=C_u_i_car(t11);
/* support.scm:635: walk */
t13=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t13;
av2[1]=t10;
av2[2]=t12;
f_9499(3,av2);}}}

/* k10097 in loop in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_10099,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10103,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[3]);
/* support.scm:634: walk */
t5=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
f_9499(3,av2);}}

/* k10101 in k10097 in loop in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_10103,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[199],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10124 in loop in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10126(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_10126,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:635: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10087(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,0,3)))){
C_save_and_reclaim_args((void *)trf_10137,2,t0,t1);}
a=C_alloc(21);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:637: walk */
t4=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
f_9499(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[7],lf[179]);
if(C_truep(t2)){
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_i_check_list_2(((C_word*)t0)[3],lf[127]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10212,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10214,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_10214(t13,t9,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10253,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)((C_word*)t0)[2])[1];
t9=C_i_check_list_2(((C_word*)t0)[3],lf[127]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10263,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10265,a[2]=t6,a[3]=t12,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_10265(t14,t10,((C_word*)t0)[3]);}}}

/* k10142 in k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10144(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,3)))){
C_save_and_reclaim((void *)f_10144,2,av);}
a=C_alloc(19);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_u_i_cdr(((C_word*)t0)[3]);
t9=C_i_check_list_2(t8,lf[127]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10155,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10157,a[2]=t5,a[3]=t12,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_10157(t14,t10,t8);}

/* k10153 in k10142 in k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10155(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_10155,2,av);}
a=C_alloc(9);
/* support.scm:637: cons* */
f_5574(((C_word*)t0)[2],((C_word*)t0)[3],C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[5],t1));}

/* map-loop1962 in k10142 in k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10157(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10157,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10182,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:637: g1968 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10180 in map-loop1962 in k10142 in k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10182(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10182,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10157(t6,((C_word*)t0)[5],t5);}

/* k10210 in k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10212(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_10212,2,av);}
a=C_alloc(6);
/* support.scm:639: cons* */
f_5574(((C_word*)t0)[2],((C_word*)t0)[3],C_a_i_list(&a,2,((C_word*)t0)[4],t1));}

/* map-loop1988 in k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10214(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10214,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10239,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:639: g1994 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10237 in map-loop1988 in k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10239(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10239,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10214(t6,((C_word*)t0)[5],t5);}

/* k10251 in k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_10253,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10261 in k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10263(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_10263,2,av);}
/* support.scm:640: scheme#append */
t2=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop2014 in k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10265(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10265,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10290,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:640: g2020 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10288 in map-loop2014 in k10135 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10290,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10265(t6,((C_word*)t0)[5],t5);}

/* chicken.compiler.support#fold-boolean in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10363(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_10363,4,av);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10369,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_10369(t7,t1,t3);}

/* fold in chicken.compiler.support#fold-boolean in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10369(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_10369,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
C_apply(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10395,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_i_car(t5);
t7=t2;
t8=C_i_cadr(t7);
/* support.scm:648: proc */
t9=((C_word*)t0)[2];{
C_word av2[4];
av2[0]=t9;
av2[1]=t4;
av2[2]=t6;
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}}

/* k10393 in fold in chicken.compiler.support#fold-boolean in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_10395,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10399,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:649: fold */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10369(t6,t3,t5);}

/* k10397 in k10393 in fold in chicken.compiler.support#fold-boolean in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,1)))){
C_save_and_reclaim((void *)f_10399,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[174],lf[207],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10415(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,5)))){
C_save_and_reclaim((void *)f_10415,8,av);}
a=C_alloc(7);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10421,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm:653: ##sys#decompose-lambda-list */
t9=*((C_word*)lf[215]+1);{
C_word *av2=av;
av2[0]=t9;
av2[1]=t1;
av2[2]=t2;
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}

/* a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_10421,5,av);}
a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10427,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10433,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* support.scm:656: ##sys#call-with-values */{
C_word *av2=av;
av2[0]=0;
av2[1]=t1;
av2[2]=t5;
av2[3]=t6;
C_call_with_values(4,av2);}}

/* a10426 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,5)))){
C_save_and_reclaim((void *)f_10427,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5307,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5307(t7,t1,t3,C_SCHEME_END_OF_LIST,t2);}

/* a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_10433,4,av);}
a=C_alloc(24);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10437,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=((C_word*)t0)[6];
t10=C_i_check_list_2(t9,lf[127]);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10553,a[2]=t7,a[3]=t12,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_10553(t14,t4,t9);}
else{
t5=t4;{
C_word *av2=av;
av2[0]=t5;
av2[1]=((C_word*)t0)[6];
f_10437(2,av2);}}}

/* k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(26,c,4)))){
C_save_and_reclaim((void *)f_10437,2,av);}
a=C_alloc(26);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
t4=t3;
t5=((C_word*)t0)[8];
t6=((C_word*)t0)[9];
t7=((C_word*)t0)[10];
t8=((C_word*)t0)[11];
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=C_i_check_list_2(t6,lf[127]);
t14=C_i_check_list_2(t2,lf[127]);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10600,a[2]=t8,a[3]=t7,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11047,a[2]=t11,a[3]=t17,a[4]=t12,tmp=(C_word)a,a+=5,tmp));
t19=((C_word*)t17)[1];
f_11047(t19,t15,t6,t2);}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=((C_word*)t0)[8];
f_10440(2,av2);}}}

/* k10438 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10440(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_10440,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10447,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* support.scm:661: take */
f_5249(t3,((C_word*)t0)[4],((C_word*)t0)[7]);}

/* k10445 in k10438 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_10447,2,av);}
a=C_alloc(9);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_10449(t5,((C_word*)t0)[6],t1,((C_word*)t0)[7]);}

/* loop in k10445 in k10438 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10449(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(8,0,3)))){
C_save_and_reclaim_args((void *)trf_10449,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10507,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:666: last */
f_5910(t4,((C_word*)t0)[5]);}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t4=C_i_car(t2);
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=C_i_car(t3);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10531,a[2]=t8,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t10=t2;
t11=C_u_i_cdr(t10);
t12=t3;
t13=C_u_i_cdr(t12);
/* support.scm:677: loop */
t15=t9;
t16=t11;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* k10477 in k10505 in loop in k10445 in k10438 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_10479(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,1)))){
C_save_and_reclaim((void *)f_10479,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[98],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k10505 in loop in k10445 in k10438 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10507(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(35,c,2)))){
C_save_and_reclaim((void *)f_10507,2,av);}
a=C_alloc(35);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
/* support.scm:668: qnode */
t5=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=C_i_length(((C_word*)t0)[4]);
t6=C_a_i_fixnum_times(&a,2,C_fix(3),t5);
t7=C_a_i_list2(&a,2,lf[209],t6);
t8=((C_word*)t0)[4];
t9=C_a_i_record4(&a,4,lf[143],lf[179],t7,t8);
t10=C_a_i_list2(&a,2,t9,((C_word*)t0)[2]);
t11=((C_word*)t0)[3];
t12=t11;{
C_word *av2=av;
av2[0]=t12;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[98],t3,t10);
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}}

/* k10529 in loop in k10445 in k10438 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10531(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,1)))){
C_save_and_reclaim((void *)f_10531,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[98],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* map-loop2065 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10553(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10553,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10578,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:657: g2071 */
t5=*((C_word*)lf[99]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10576 in map-loop2065 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10578(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10578,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10553(t6,((C_word*)t0)[5],t5);}

/* k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10600(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_10600,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
/* support.scm:726: walk */
t5=((C_word*)t3)[1];
f_10608(t5,((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10608(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(10,0,5)))){
C_save_and_reclaim_args((void *)trf_10608,4,t0,t1,t2,t3);}
a=C_alloc(10);
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=t11;
t13=C_eqp(t12,lf[87]);
if(C_truep(t13)){
t14=t1;
t15=t14;{
C_word av2[2];
av2[0]=t15;
av2[1]=C_a_i_record4(&a,4,lf[143],t12,t9,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t14=C_eqp(t12,lf[156]);
if(C_truep(t14)){
t15=C_i_car(t9);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10659,a[2]=t1,a[3]=t3,a[4]=t16,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10669,a[2]=((C_word*)t0)[2],a[3]=t17,a[4]=t16,tmp=(C_word)a,a+=5,tmp);
/* support.scm:692: db-get */
t19=*((C_word*)lf[129]+1);{
C_word av2[5];
av2[0]=t19;
av2[1]=t18;
av2[2]=((C_word*)t0)[3];
av2[3]=t16;
av2[4]=lf[212];
((C_proc)(void*)(*((C_word*)t19+1)))(5,av2);}}
else{
t15=C_eqp(t12,lf[126]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10706,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t17=C_i_car(t9);
t18=t3;
/* support.scm:682: chicken.base#alist-ref */
t19=*((C_word*)lf[210]+1);{
C_word av2[6];
av2[0]=t19;
av2[1]=t16;
av2[2]=t17;
av2[3]=t18;
av2[4]=*((C_word*)lf[211]+1);
av2[5]=t17;
((C_proc)(void*)(*((C_word*)t19+1)))(6,av2);}}
else{
t16=C_eqp(t12,lf[98]);
if(C_truep(t16)){
t17=C_i_car(t9);
t18=t17;
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10722,a[2]=t3,a[3]=t18,a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t20=C_i_car(t6);
/* support.scm:701: walk */
t22=t19;
t23=t20;
t24=t3;
t1=t22;
t2=t23;
t3=t24;
goto loop;}
else{
t17=C_eqp(t12,lf[120]);
if(C_truep(t17)){
t18=C_i_caddr(t9);
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10774,a[2]=((C_word*)t0)[3],a[3]=t9,a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:709: ##sys#decompose-lambda-list */
t20=*((C_word*)lf[215]+1);{
C_word av2[4];
av2[0]=t20;
av2[1]=t1;
av2[2]=t18;
av2[3]=t19;
((C_proc)(void*)(*((C_word*)t20+1)))(4,av2);}}
else{
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10983,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t6,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
/* support.scm:724: tree-copy */
t19=*((C_word*)lf[216]+1);{
C_word av2[3];
av2[0]=t19;
av2[1]=t18;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}}}}}}

/* k10657 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_10659,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10666,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
/* support.scm:682: chicken.base#alist-ref */
t4=*((C_word*)lf[210]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=t3;
av2[4]=*((C_word*)lf[211]+1);
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* k10664 in k10657 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10666(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_10666,2,av);}
/* support.scm:694: varnode */
t2=*((C_word*)lf[155]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10667 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10669(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_10669,2,av);}
if(C_truep(t1)){
/* support.scm:693: cfk */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_10659(2,av2);}}}

/* k10696 in k10704 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10698(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_10698,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[126],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k10704 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10706(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_10706,2,av);}
a=C_alloc(7);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10698,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(((C_word*)t0)[3]);
/* support.scm:698: walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10608(t6,t4,t5,((C_word*)t0)[5]);}

/* k10720 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_10722,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:702: chicken.base#gensym */
t4=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10723 in k10720 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,5)))){
C_save_and_reclaim((void *)f_10725,2,av);}
a=C_alloc(14);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=C_a_i_cons(&a,2,t4,t3);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10731,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* support.scm:704: db-put! */
t8=*((C_word*)lf[133]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[8];
av2[3]=t2;
av2[4]=lf[213];
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t8+1)))(6,av2);}}

/* k10729 in k10723 in k10720 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_10731(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_10731,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10751,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_i_cadr(((C_word*)t0)[5]);
/* support.scm:707: walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_10608(t6,t4,t5,((C_word*)t0)[7]);}

/* k10749 in k10729 in k10723 in k10720 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in ... */
static void C_ccall f_10751(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,1)))){
C_save_and_reclaim((void *)f_10751,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[98],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10774(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(26,c,3)))){
C_save_and_reclaim((void *)f_10774,5,av);}
a=C_alloc(26);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=t2;
t11=C_i_check_list_2(t10,lf[127]);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=t4,a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10939,a[2]=t7,a[3]=t14,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_10939(t16,t12,t10);}

/* g2205 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10779(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_10779,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10783,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:713: chicken.base#gensym */
t4=*((C_word*)lf[99]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10781 in g2205 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_10783(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,5)))){
C_save_and_reclaim((void *)f_10783,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10786,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:714: db-put! */
t4=*((C_word*)lf[133]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[213];
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* k10784 in k10781 in g2205 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in ... */
static void C_ccall f_10786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_10786,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10790 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10792(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,4)))){
C_save_and_reclaim((void *)f_10792,2,av);}
a=C_alloc(25);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)t0)[8];
t9=C_i_check_list_2(t2,lf[127]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10889,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10891,a[2]=t6,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_10891(t14,t10,t8,t2);}

/* k10793 in k10790 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_10795(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_10795,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* support.scm:720: chicken.base#gensym */
t4=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[214];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* g2272 in k10866 in k10858 in k10793 in k10790 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in ... */
static void C_fcall f_10812(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_10812,3,t0,t1,t2);}
/* support.scm:723: g2289 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10608(t3,t1,t2,((C_word*)t0)[3]);}

/* k10820 in k10866 in k10858 in k10793 in k10790 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in ... */
static void C_ccall f_10822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_10822,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[120],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop2266 in k10866 in k10858 in k10793 in k10790 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in ... */
static void C_fcall f_10824(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10824,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10849,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:723: g2272 */
t5=((C_word*)t0)[4];
f_10812(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10847 in map-loop2266 in k10866 in k10858 in k10793 in k10790 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in ... */
static void C_ccall f_10849(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10849,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10824(t6,((C_word*)t0)[5],t5);}

/* k10858 in k10793 in k10790 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in ... */
static void C_ccall f_10860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,5)))){
C_save_and_reclaim((void *)f_10860,2,av);}
a=C_alloc(14);
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10868,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10876,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[9])){
t7=((C_word*)t0)[9];
/* support.scm:682: chicken.base#alist-ref */
t8=*((C_word*)lf[210]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=((C_word*)t0)[4];
av2[4]=*((C_word*)lf[211]+1);
av2[5]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(6,av2);}}
else{
/* support.scm:721: build-lambda-list */
t7=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[8];
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}

/* k10866 in k10858 in k10793 in k10790 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in ... */
static void C_ccall f_10868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,c,3)))){
C_save_and_reclaim((void *)f_10868,2,av);}
a=C_alloc(33);
t2=C_i_cadddr(((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,((C_word*)t0)[3],((C_word*)t0)[4],t1,t2);
t4=t3;
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10812,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t10=C_i_check_list_2(((C_word*)t0)[7],lf[127]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10822,a[2]=((C_word*)t0)[8],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10824,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_10824(t15,t11,((C_word*)t0)[7]);}

/* k10874 in k10858 in k10793 in k10790 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in ... */
static void C_ccall f_10876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_10876,2,av);}
/* support.scm:721: build-lambda-list */
t2=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10887 in k10790 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_10889(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_10889,2,av);}
/* support.scm:717: scheme#append */
t2=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop2229 in k10790 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_fcall f_10891(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_10891,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* map-loop2199 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10939(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_10939,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10964,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:712: g2205 */
t5=((C_word*)t0)[4];
f_10779(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10962 in map-loop2199 in a10773 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_10964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_10964,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10939(t6,((C_word*)t0)[5],t5);}

/* k10981 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,3)))){
C_save_and_reclaim((void *)f_10983,2,av);}
a=C_alloc(22);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_list_2(((C_word*)t0)[4],lf[127]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10998,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11000,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_11000(t13,t9,((C_word*)t0)[4]);}

/* g2311 in k10981 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_10988(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_10988,3,t0,t1,t2);}
/* support.scm:725: g2328 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10608(t3,t1,t2,((C_word*)t0)[3]);}

/* k10996 in k10981 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_10998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_10998,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop2305 in k10981 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11000(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_11000,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11025,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:725: g2311 */
t5=((C_word*)t0)[4];
f_10988(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11023 in map-loop2305 in k10981 in walk in k10598 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_11025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_11025,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_11000(t6,((C_word*)t0)[5],t5);}

/* map-loop2118 in k10435 in a10432 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11047(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_11047,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* chicken.compiler.support#tree-copy in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11095(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_11095,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11101,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11101(t6,t1,t2);}

/* rec in chicken.compiler.support#tree-copy in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11101(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_11101,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11115,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* support.scm:732: rec */
t7=t3;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11113 in rec in chicken.compiler.support#tree-copy in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_11115,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11119,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:732: rec */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11101(t6,t3,t5);}

/* k11117 in k11113 in rec in chicken.compiler.support#tree-copy in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11119(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_11119,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* chicken.compiler.support#copy-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11125(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_11125,3,av);}
a=C_alloc(5);
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=t1;{
C_word *av2=av;
av2[0]=t9;
av2[1]=C_a_i_record4(&a,4,lf[143],t4,t6,t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}

/* chicken.compiler.support#copy-node! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_11163,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11167,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_slot(t5,C_fix(1));
/* support.scm:741: node-class-set! */
t7=*((C_word*)lf[147]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t4;
av2[2]=t3;
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k11165 in chicken.compiler.support#copy-node! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11167(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_11167,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
/* support.scm:742: node-parameters-set! */
t5=*((C_word*)lf[151]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k11168 in k11165 in chicken.compiler.support#copy-node! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11170(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_11170,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(3));
/* support.scm:743: node-subexpressions-set! */
t5=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k11171 in k11168 in k11165 in chicken.compiler.support#copy-node! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11173(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11173,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* walk in k11539 in k11536 in k11584 in k11502 in k11617 in k11481 in a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_11208(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_11208,3,av);}
a=C_alloc(18);
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=((C_word*)((C_word*)t0)[2])[1];
t14=t2;
t15=C_slot(t14,C_fix(3));
t16=C_i_check_list_2(t15,lf[127]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11252,a[2]=t8,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11254,a[2]=t11,a[3]=t19,a[4]=t13,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t21=((C_word*)t19)[1];
f_11254(t21,t17,t15);}

/* k11250 in walk in k11539 in k11536 in k11584 in k11502 in k11617 in k11481 in a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in ... */
static void C_ccall f_11252(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_11252,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop2390 in walk in k11539 in k11536 in k11584 in k11502 in k11617 in k11481 in a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in ... */
static void C_fcall f_11254(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_11254,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11279,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:750: g2396 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11277 in map-loop2390 in walk in k11539 in k11536 in k11584 in k11502 in k11617 in k11481 in a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in ... */
static void C_ccall f_11279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_11279,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_11254(t6,((C_word*)t0)[5],t5);}

/* walk in k11635 in loop in a11626 in chicken.compiler.support#load-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11294(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_11294,3,av);}
a=C_alloc(18);
t3=C_i_car(t2);
t4=t3;
t5=C_i_cadr(t2);
t6=t5;
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=((C_word*)((C_word*)t0)[2])[1];
t12=t2;
t13=C_u_i_cdr(t12);
t14=C_u_i_cdr(t13);
t15=C_i_check_list_2(t14,lf[127]);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11323,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11325,a[2]=t9,a[3]=t18,a[4]=t11,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_11325(t20,t16,t14);}

/* k11321 in walk in k11635 in loop in a11626 in chicken.compiler.support#load-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11323(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_11323,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop2429 in walk in k11635 in loop in a11626 in chicken.compiler.support#load-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_11325,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11350,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:754: g2435 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11348 in map-loop2429 in walk in k11635 in loop in a11626 in chicken.compiler.support#load-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_11350,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_11325(t6,((C_word*)t0)[5],t5);}

/* chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11359(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,4)))){
C_save_and_reclaim((void *)f_11359,7,av);}
a=C_alloc(18);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11363,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11476,a[2]=t8,a[3]=t10,a[4]=t6,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm:761: chicken.internal#hash-table-for-each */
t13=*((C_word*)lf[141]+1);{
C_word *av2=av;
av2[0]=t13;
av2[1]=t11;
av2[2]=t12;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t13+1)))(4,av2);}}

/* k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11363(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_11363,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[4])[1]))){
/* support.scm:781: chicken.file#delete-file* */
t3=*((C_word*)lf[227]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11426,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm:782: scheme#with-output-to-file */
t4=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k11364 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11366(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_11366,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
/* support.scm:793: debugging */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[225];
av2[3]=lf[226];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_11372(2,av2);}}}

/* k11370 in k11364 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11372(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_11372,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7276,tmp=(C_word)a,a+=2,tmp);
/* support.scm:288: chicken.sort#sort */
t5=*((C_word*)lf[224]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11378 in k11370 in k11364 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11380(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_11380,2,av);}
a=C_alloc(5);
t2=C_i_check_list_2(t1,lf[44]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11388,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11388(t6,((C_word*)t0)[2],t1);}

/* for-each-loop2531 in k11378 in k11370 in k11364 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_11388,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11398,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:794: g2547 */
t5=*((C_word*)lf[220]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[221];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11396 in for-each-loop2531 in k11378 in k11370 in k11364 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11398(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_11398,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11388(t3,((C_word*)t0)[4],t2);}

/* a11425 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11426(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_11426,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11430,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11474,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:784: chicken.platform#chicken-version */
t4=*((C_word*)lf[233]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k11428 in a11425 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_11430,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11441,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:790: scheme#reverse */
t3=*((C_word*)lf[82]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k11433 in for-each-loop2509 in k11439 in k11428 in a11425 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11435,2,av);}
/* support.scm:789: scheme#newline */
t2=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11439 in k11428 in a11425 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11441(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_11441,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11449,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11449(t6,t2,t1);}

/* k11442 in k11439 in k11428 in a11425 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11444(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_11444,2,av);}
/* support.scm:791: chicken.base#print */
t2=*((C_word*)lf[220]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[228];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* for-each-loop2509 in k11439 in k11428 in a11425 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11449(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_11449,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11459,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11435,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm:788: chicken.pretty-print#pp */
t7=*((C_word*)lf[229]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11457 in for-each-loop2509 in k11439 in k11428 in a11425 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11459(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_11459,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11449(t3,((C_word*)t0)[4],t2);}

/* k11472 in a11425 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11474(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,6)))){
C_save_and_reclaim((void *)f_11474,2,av);}
/* support.scm:784: chicken.base#print */
t2=*((C_word*)lf[220]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[230];
av2[3]=t1;
av2[4]=lf[231];
av2[5]=((C_word*)t0)[3];
av2[6]=lf[232];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_11476,4,av);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11483,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* support.scm:763: variable-visible? */
t5=*((C_word*)lf[244]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k11481 in a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11483(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_11483,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=C_i_assq(lf[235],((C_word*)t0)[2]);
t3=t2;
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11619,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t5=((C_word*)t0)[3];
/* tweaks.scm:60: ##sys#get */
t6=*((C_word*)lf[183]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=lf[243];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t4=((C_word*)t0)[6];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11502 in k11617 in k11481 in a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,4)))){
C_save_and_reclaim_args((void *)trf_11504,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
if(C_truep(C_i_assq(lf[237],((C_word*)t0)[2]))){
t2=C_i_cdr(((C_word*)t0)[3]);
t3=C_slot(t2,C_fix(2));
t4=t3;
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11586,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:771: db-get */
t6=*((C_word*)lf[129]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[9];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[241];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t5=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11536 in k11584 in k11502 in k11617 in k11481 in a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11538(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_11538,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(t1,lf[238]);
if(C_truep(t3)){
t4=t2;
f_11541(t4,C_SCHEME_TRUE);}
else{
t4=C_eqp(t1,lf[239]);
if(C_truep(t4)){
t5=t2;
f_11541(t5,C_SCHEME_FALSE);}
else{
t5=C_i_cadddr(((C_word*)t0)[7]);
t6=t2;
f_11541(t6,C_i_lessp(t5,((C_word*)t0)[8]));}}}

/* k11539 in k11536 in k11584 in k11502 in k11617 in k11481 in a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,3)))){
C_save_and_reclaim_args((void *)trf_11541,2,t0,t1);}
a=C_alloc(13);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_u_i_cdr(((C_word*)t0)[6]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11208,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];{
C_word av2[3];
av2[0]=t9;
av2[1]=t4;
av2[2]=t5;
f_11208(3,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11558 in k11539 in k11536 in k11584 in k11502 in k11617 in k11481 in a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_11560(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_11560,2,av);}
a=C_alloc(9);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k11584 in k11502 in k11617 in k11481 in a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_11586,2,av);}
a=C_alloc(9);
if(C_truep(C_i_not(t1))){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[2];
/* tweaks.scm:60: ##sys#get */
t4=*((C_word*)lf[183]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=lf[240];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11617 in k11481 in a11475 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_11619,2,av);}
a=C_alloc(10);
t2=C_i_structurep(t1,lf[143]);
if(C_truep(C_i_not(t2))){
t3=C_i_assq(lf[236],((C_word*)t0)[2]);
t4=C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t4)){
t6=t5;
f_11504(t6,t4);}
else{
t6=C_i_cdr(t3);
t7=C_eqp(lf[242],t6);
t8=t5;
f_11504(t8,C_i_not(t7));}}
else{
t3=((C_word*)t0)[7];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.compiler.support#load-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,3)))){
C_save_and_reclaim((void *)f_11621,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11627,tmp=(C_word)a,a+=2,tmp);
/* support.scm:798: scheme#with-input-from-file */
t4=*((C_word*)lf[247]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a11626 in chicken.compiler.support#load-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_11627,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11633,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_11633(t5,t1);}

/* loop in a11626 in chicken.compiler.support#load-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_11633,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11637,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:801: scheme#read */
t3=*((C_word*)lf[85]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k11635 in loop in a11626 in chicken.compiler.support#load-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_11637,2,av);}
a=C_alloc(13);
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11660,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(t1);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11671,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cadr(t1);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11294,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=((C_word*)t8)[1];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t5;
av2[2]=t6;
f_11294(3,av2);}}}

/* k11658 in k11635 in loop in a11626 in chicken.compiler.support#load-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11660(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11660,2,av);}
/* support.scm:807: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_11633(t2,((C_word*)t0)[3]);}

/* k11669 in k11635 in loop in a11626 in chicken.compiler.support#load-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_11671,2,av);}
a=C_alloc(3);
t2=C_a_i_list(&a,1,t1);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:57: ##sys#put! */
t3=*((C_word*)lf[246]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[243];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=C_i_car(t2);
/* tweaks.scm:57: ##sys#put! */
t4=*((C_word*)lf[246]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[243];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* chicken.compiler.support#match-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,4)))){
C_save_and_reclaim((void *)f_11677,5,av);}
a=C_alloc(27);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11680,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11714,a[2]=t8,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t15=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11761,a[2]=t8,a[3]=t12,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11884,a[2]=t6,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:841: matchn */
t17=((C_word*)t12)[1];
f_11761(t17,t16,t2,t3);}

/* resolve in chicken.compiler.support#match-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11680(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_11680,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11688,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:816: g2592 */
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=(
/* support.scm:816: g2592 */
  f_11688(t5,t4)
);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
if(C_truep(C_i_memq(t2,((C_word*)t0)[3]))){
t5=t2;
t6=t3;
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_a_i_cons(&a,2,t5,t6);
t9=C_a_i_cons(&a,2,t8,t7);
t10=C_mutate(((C_word *)((C_word*)t0)[2])+1,t9);
t11=t1;{
C_word av2[2];
av2[0]=t11;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_eqp(t2,t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}

/* g2592 in resolve in chicken.compiler.support#match-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static C_word C_fcall f_11688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_cdr(t1);
return(C_i_equalp(((C_word*)t0)[2],t2));}

/* match1 in chicken.compiler.support#match-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11714(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_11714,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t3);
if(C_truep(C_i_not(t4))){
/* support.scm:823: resolve */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11680(t5,t1,t3,t2);}
else{
t5=C_i_pairp(t2);
if(C_truep(C_i_not(t5))){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11736,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_i_car(t2);
t8=C_i_car(t3);
/* support.scm:825: match1 */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}}

/* k11734 in match1 in chicken.compiler.support#match-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11736(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11736,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:825: match1 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11714(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* matchn in chicken.compiler.support#match-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11761(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_11761,4,t0,t1,t2,t3);}
a=C_alloc(7);
t4=C_i_pairp(t3);
if(C_truep(C_i_not(t4))){
/* support.scm:830: resolve */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11680(t5,t1,t3,t2);}
else{
t5=t2;
t6=C_slot(t5,C_fix(1));
t7=t3;
t8=C_i_car(t7);
t9=C_eqp(t6,t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11783,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=C_slot(t11,C_fix(2));
t13=t3;
t14=C_i_cadr(t13);
/* support.scm:832: match1 */
t15=((C_word*)((C_word*)t0)[4])[1];
f_11714(t15,t10,t12,t14);}
else{
t10=t1;{
C_word av2[2];
av2[0]=t10;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}}

/* k11781 in matchn in chicken.compiler.support#match-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11783(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_11783,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_slot(t2,C_fix(3));
t4=C_i_cddr(((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11801,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_11801(t8,((C_word*)t0)[6],t3,t4);}
else{
t2=((C_word*)t0)[6];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* loop in k11781 in matchn in chicken.compiler.support#match-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11801(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_11801,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_nullp(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_pairp(t3);
if(C_truep(C_i_not(t4))){
/* support.scm:836: resolve */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11680(t5,t1,t3,t2);}
else{
if(C_truep(C_i_nullp(t2))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11832,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t2);
t7=C_i_car(t3);
/* support.scm:838: matchn */
t8=((C_word*)((C_word*)t0)[4])[1];
f_11761(t8,t5,t6,t7);}}}}

/* k11830 in loop in k11781 in matchn in chicken.compiler.support#match-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_11832,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:839: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11801(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11882 in chicken.compiler.support#match-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,6)))){
C_save_and_reclaim((void *)f_11884,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(1));
t5=((C_word*)t0)[4];
t6=C_slot(t5,C_fix(2));
/* support.scm:844: debugging */
t7=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=lf[249];
av2[3]=lf[250];
av2[4]=t4;
av2[5]=t6;
av2[6]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11888 in k11882 in chicken.compiler.support#match-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11890,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#expression-has-side-effects? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_11910,4,av);}
a=C_alloc(5);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11916,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];{
C_word *av2=av;
av2[0]=t7;
av2[1]=t1;
av2[2]=t2;
f_11916(3,av2);}}

/* walk in chicken.compiler.support#expression-has-side-effects? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_11916,3,av);}
a=C_alloc(7);
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(1));
t8=t7;
t9=C_eqp(t8,lf[156]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11942,a[2]=t1,a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_11942(t11,t9);}
else{
t11=C_eqp(t8,lf[87]);
if(C_truep(t11)){
t12=t10;
f_11942(t12,t11);}
else{
t12=C_eqp(t8,lf[161]);
t13=t10;
f_11942(t13,(C_truep(t12)?t12:C_eqp(t8,lf[176])));}}}

/* k11940 in walk in chicken.compiler.support#expression-has-side-effects? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_11942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_11942,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[120]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11956,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=((C_word*)t0)[2];
t9=t7;
t10=*((C_word*)lf[253]+1);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6271,a[2]=t12,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_6271(t14,t8,*((C_word*)lf[253]+1));}
else{
t3=C_eqp(((C_word*)t0)[3],lf[160]);
if(C_truep(t3)){
if(C_truep(t3)){
/* support.scm:860: any */
f_5544(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6]);}
else{
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[98]);
if(C_truep(t4)){
/* support.scm:860: any */
f_5544(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6]);}
else{
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}}}

/* a11955 in k11940 in walk in chicken.compiler.support#expression-has-side-effects? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11956(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_11956,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11964,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:858: foreign-callback-stub-id */
t4=*((C_word*)lf[252]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k11962 in a11955 in k11940 in walk in chicken.compiler.support#expression-has-side-effects? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_11964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_11964,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_eqp(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* chicken.compiler.support#simple-lambda-node? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_12019,3,av);}
a=C_alloc(6);
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=C_i_caddr(t4);
t6=C_i_pairp(t5);
t7=(C_truep(t6)?C_i_car(t5):C_SCHEME_FALSE);
t8=t7;
if(C_truep(t8)){
if(C_truep(C_i_cadr(t4))){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12048,a[2]=t8,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];{
C_word *av2=av;
av2[0]=t12;
av2[1]=t1;
av2[2]=t2;
f_12048(3,av2);}}
else{
t9=t1;{
C_word *av2=av;
av2[0]=t9;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t9=t1;{
C_word *av2=av;
av2[0]=t9;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* rec in chicken.compiler.support#simple-lambda-node? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_12048,3,av);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(t4,lf[181]);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(3));
t8=C_i_car(t7);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[156],t9);
if(C_truep(t10)){
t11=C_slot(t8,C_fix(2));
t12=C_i_car(t11);
t13=C_eqp(((C_word*)t0)[2],t12);
if(C_truep(t13)){
t14=C_i_cdr(t7);
/* support.scm:876: every */
f_5510(t1,((C_word*)((C_word*)t0)[3])[1],t14);}
else{
t14=t1;{
C_word *av2=av;
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t11=t1;{
C_word *av2=av;
av2[0]=t11;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}
else{
t6=C_eqp(t4,lf[190]);
if(C_truep(t6)){
t7=t1;{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=t2;
t8=C_slot(t7,C_fix(3));
/* support.scm:878: every */
f_5510(t1,((C_word*)((C_word*)t0)[3])[1],t8);}}}

/* chicken.compiler.support#dump-undefined-globals in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12145(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_12145,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12151,tmp=(C_word)a,a+=2,tmp);
/* support.scm:884: chicken.internal#hash-table-for-each */
t4=*((C_word*)lf[141]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a12150 in chicken.compiler.support#dump-undefined-globals in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_12151,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12158,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12184,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:886: chicken.keyword#keyword? */
t6=*((C_word*)lf[259]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k12156 in a12150 in chicken.compiler.support#dump-undefined-globals in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_12158(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_12158,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12161,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:889: scheme#write */
t3=*((C_word*)lf[256]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12159 in k12156 in a12150 in chicken.compiler.support#dump-undefined-globals in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12161(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12161,2,av);}
/* support.scm:890: scheme#newline */
t2=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k12182 in a12150 in chicken.compiler.support#dump-undefined-globals in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12184(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12184,2,av);}
if(C_truep(C_i_not(t1))){
if(C_truep(C_i_assq(lf[257],((C_word*)t0)[2]))){
t2=C_i_assq(lf[258],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_12158(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[3];
f_12158(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_12158(t2,C_SCHEME_FALSE);}}

/* chicken.compiler.support#dump-defined-globals in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_12186,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12192,tmp=(C_word)a,a+=2,tmp);
/* support.scm:894: chicken.internal#hash-table-for-each */
t4=*((C_word*)lf[141]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a12191 in chicken.compiler.support#dump-defined-globals in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_12192,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12199,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12221,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:896: chicken.keyword#keyword? */
t6=*((C_word*)lf[259]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k12197 in a12191 in chicken.compiler.support#dump-defined-globals in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_12199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_12199,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12202,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:899: scheme#write */
t3=*((C_word*)lf[256]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12200 in k12197 in a12191 in chicken.compiler.support#dump-defined-globals in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12202,2,av);}
/* support.scm:900: scheme#newline */
t2=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k12219 in a12191 in chicken.compiler.support#dump-defined-globals in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12221(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12221,2,av);}
if(C_truep(C_i_not(t1))){
t2=C_i_assq(lf[257],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_12199(t3,(C_truep(t2)?C_i_assq(lf[258],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[3];
f_12199(t2,C_SCHEME_FALSE);}}

/* chicken.compiler.support#dump-global-refs in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12223(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_12223,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12229,tmp=(C_word)a,a+=2,tmp);
/* support.scm:904: chicken.internal#hash-table-for-each */
t4=*((C_word*)lf[141]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a12228 in chicken.compiler.support#dump-global-refs in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_12229,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12270,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:906: chicken.keyword#keyword? */
t5=*((C_word*)lf[259]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k12240 in k12268 in a12228 in chicken.compiler.support#dump-global-refs in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12242,2,av);}
/* support.scm:909: scheme#newline */
t2=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k12268 in a12228 in chicken.compiler.support#dump-global-refs in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_12270,2,av);}
a=C_alloc(9);
t2=C_i_not(t1);
t3=(C_truep(t2)?C_i_assq(lf[257],((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_i_assq(lf[262],((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12242,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t4)){
t6=C_i_cdr(t4);
t7=C_i_length(t6);
t8=C_a_i_list2(&a,2,((C_word*)t0)[4],t7);
/* support.scm:908: scheme#write */
t9=*((C_word*)lf[256]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t5;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t6=C_a_i_list2(&a,2,((C_word*)t0)[4],C_fix(0));
/* support.scm:908: scheme#write */
t7=*((C_word*)lf[256]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* ##sys#toplevel-definition-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12272(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_12272,5,av);}
a=C_alloc(4);
t5=t2;
if(C_truep(C_u_i_namespaced_symbolp(t5))){
t6=t1;
t7=t2;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17049,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1638: variable-hidden? */
t9=*((C_word*)lf[266]+1);{
C_word *av2=av;
av2[0]=t9;
av2[1]=t8;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
if(C_truep(C_i_not(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12293,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:920: debugging */
t7=*((C_word*)lf[22]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[191];
av2[3]=lf[268];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t6=t1;{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}

/* k12291 in ##sys#toplevel-definition-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_12293,2,av);}
/* support.scm:921: hide-variable */
t2=*((C_word*)lf[267]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* chicken.compiler.support#make-foreign-callback-stub in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12300(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,1)))){
C_save_and_reclaim((void *)f_12300,7,av);}
a=C_alloc(7);
t7=t1;{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_a_i_record6(&a,6,lf[270],t2,t3,t4,t5,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* chicken.compiler.support#foreign-callback-stub? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12306(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12306,3,av);}
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[270]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#foreign-callback-stub-id in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12312(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12312,3,av);}
t3=C_i_check_structure_2(t2,lf[270],lf[272]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#foreign-callback-stub-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12321,3,av);}
t3=C_i_check_structure_2(t2,lf[270],lf[274]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(2));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#foreign-callback-stub-qualifiers in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12330,3,av);}
t3=C_i_check_structure_2(t2,lf[270],lf[276]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(3));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#foreign-callback-stub-return-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12339(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12339,3,av);}
t3=C_i_check_structure_2(t2,lf[270],lf[278]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(4));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#foreign-callback-stub-argument-types in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12348(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12348,3,av);}
t3=C_i_check_structure_2(t2,lf[270],lf[280]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(5));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#register-foreign-callback-stub! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12357(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_12357,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12383,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t4;
av2[2]=*((C_word*)lf[269]+1);
av2[3]=t2;
av2[4]=t3;
C_apply(5,av2);}}

/* k12381 in chicken.compiler.support#register-foreign-callback-stub! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_12383,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,*((C_word*)lf[253]+1));
t3=C_mutate((C_word*)lf[253]+1 /* (set! chicken.compiler.support#foreign-callback-stubs ...) */,t2);
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];
t6=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t6))){
/* tweaks.scm:57: ##sys#put! */
t7=*((C_word*)lf[246]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t5;
av2[3]=lf[282];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t7=C_i_car(t6);
/* tweaks.scm:57: ##sys#put! */
t8=*((C_word*)lf[246]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t4;
av2[2]=t5;
av2[3]=lf[282];
av2[4]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}

/* chicken.compiler.support#clear-foreign-type-table! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12386(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_12386,2,av);}
a=C_alloc(3);
if(C_truep(lf[283])){
/* support.scm:949: scheme#vector-fill! */
t2=*((C_word*)lf[285]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[283];
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12397,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:950: scheme#make-vector */
t3=*((C_word*)lf[286]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(301);
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k12395 in chicken.compiler.support#clear-foreign-type-table! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12397(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_12397,2,av);}
t2=C_mutate(&lf[283] /* (set! chicken.compiler.support#foreign-type-table ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#register-foreign-type! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +4,c,4)))){
C_save_and_reclaim((void*)f_12399,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+4);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=(C_truep(t10)?t6:C_SCHEME_FALSE);
t14=(C_truep(t6)?C_a_i_vector3(&a,3,t3,t13,t10):C_a_i_vector3(&a,3,t3,t13,C_SCHEME_FALSE));
/* support.scm:958: chicken.internal#hash-table-set! */
t15=*((C_word*)lf[134]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t15;
av2[1]=t1;
av2[2]=lf[283];
av2[3]=t2;
av2[4]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(5,av2);}}

/* chicken.compiler.support#lookup-foreign-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12453(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_12453,3,av);}
/* support.scm:966: chicken.internal#hash-table-ref */
t3=*((C_word*)lf[130]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[283];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12459(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_12459,4,av);}
a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12465,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13529,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:983: follow-without-loop */
f_7239(t1,t3,t4,t5);}

/* a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12465(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_12465,4,av);}
a=C_alloc(8);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_12471(t7,t1,t2);}

/* repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_12471(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_12471,3,t0,t1,t2);}
a=C_alloc(9);
t3=t2;
t4=C_eqp(t3,lf[291]);
t5=(C_truep(t4)?t4:C_eqp(t3,lf[292]));
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(*((C_word*)lf[10]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[293],((C_word*)t0)[2]));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(t3,lf[294]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12496,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t6)){
t8=t7;
f_12496(t8,t6);}
else{
t8=C_eqp(t3,lf[381]);
if(C_truep(t8)){
t9=t7;
f_12496(t9,t8);}
else{
t9=C_eqp(t3,lf[382]);
if(C_truep(t9)){
t10=t7;
f_12496(t10,t9);}
else{
t10=C_eqp(t3,lf[383]);
if(C_truep(t10)){
t11=t7;
f_12496(t11,t10);}
else{
t11=C_eqp(t3,lf[384]);
t12=t7;
f_12496(t12,(C_truep(t11)?t11:C_eqp(t3,lf[385])));}}}}}}

/* k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_12496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_12496,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[10]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[295],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[296]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12511,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_12511(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[379]);
t5=t3;
f_12511(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[380])));}}}

/* k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_12511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,2)))){
C_save_and_reclaim_args((void *)trf_12511,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=(C_truep(*((C_word*)lf[10]+1))?((C_word*)t0)[3]:C_a_i_list(&a,2,lf[297],((C_word*)t0)[3]));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[298]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[299]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:994: chicken.base#gensym */
t5=*((C_word*)lf[99]+1);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[304]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[305]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(*((C_word*)lf[10]+1))?((C_word*)t0)[3]:C_a_i_list(&a,2,lf[300],((C_word*)t0)[3]));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(((C_word*)t0)[4],lf[306]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1006: chicken.base#gensym */
t8=*((C_word*)lf[99]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[4],lf[308]);
if(C_truep(t7)){
if(C_truep(*((C_word*)lf[10]+1))){
t8=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t8;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_a_i_list(&a,2,lf[301],lf[306]);
t9=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t9;
av2[1]=C_a_i_list(&a,3,lf[307],t8,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t8=C_eqp(((C_word*)t0)[4],lf[309]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t8)){
t10=t9;
f_12634(t10,t8);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[370]);
if(C_truep(t10)){
t11=t9;
f_12634(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[371]);
if(C_truep(t11)){
t12=t9;
f_12634(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t12)){
t13=t9;
f_12634(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t13)){
t14=t9;
f_12634(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t14)){
t15=t9;
f_12634(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t15)){
t16=t9;
f_12634(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[376]);
if(C_truep(t16)){
t17=t9;
f_12634(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[4],lf[377]);
t18=t9;
f_12634(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[4],lf[378])));}}}}}}}}}}}}}}

/* k12527 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(42,c,1)))){
C_save_and_reclaim((void *)f_12529,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(C_truep(*((C_word*)lf[10]+1))?t1:C_a_i_list(&a,2,lf[300],t1));
t5=C_a_i_list(&a,2,lf[301],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[302],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[303],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k12577 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12579(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,2)))){
C_save_and_reclaim((void *)f_12579,2,av);}
a=C_alloc(29);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12594,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[10]+1))){
t7=t6;
f_12594(t7,t2);}
else{
t7=C_a_i_list(&a,2,lf[301],lf[306]);
t8=t6;
f_12594(t8,C_a_i_list(&a,3,lf[307],t7,t2));}}

/* k12592 in k12577 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_12594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,0,1)))){
C_save_and_reclaim_args((void *)trf_12594,2,t0,t1);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,lf[301],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[302],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[303],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_12634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_12634,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1019: chicken.base#gensym */
t3=*((C_word*)lf[99]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[310]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12676,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_12676(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[361]);
if(C_truep(t4)){
t5=t3;
f_12676(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[362]);
if(C_truep(t5)){
t6=t3;
f_12676(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[363]);
if(C_truep(t6)){
t7=t3;
f_12676(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[364]);
if(C_truep(t7)){
t8=t3;
f_12676(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[365]);
if(C_truep(t8)){
t9=t3;
f_12676(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[366]);
if(C_truep(t9)){
t10=t3;
f_12676(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[367]);
if(C_truep(t10)){
t11=t3;
f_12676(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[5],lf[368]);
t12=t3;
f_12676(t12,(C_truep(t11)?t11:C_eqp(((C_word*)t0)[5],lf[369])));}}}}}}}}}}

/* k12635 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_12637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,2)))){
C_save_and_reclaim((void *)f_12637,2,av);}
a=C_alloc(29);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12652,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[10]+1))){
t7=t6;
f_12652(t7,t2);}
else{
t7=C_a_i_list(&a,2,lf[301],((C_word*)t0)[4]);
t8=t6;
f_12652(t8,C_a_i_list(&a,3,lf[307],t7,t2));}}

/* k12650 in k12635 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_12652(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,0,1)))){
C_save_and_reclaim_args((void *)trf_12652,2,t0,t1);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,lf[301],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[302],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[303],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_12676(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,2)))){
C_save_and_reclaim_args((void *)trf_12676,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[10]+1))){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_assq(t2,lf[311]);
t4=C_slot(t3,C_fix(1));
t5=C_a_i_list(&a,2,lf[301],t4);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[307],t5,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[312]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12702,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_12702(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[356]);
if(C_truep(t4)){
t5=t3;
f_12702(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[357]);
if(C_truep(t5)){
t6=t3;
f_12702(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[358]);
if(C_truep(t6)){
t7=t3;
f_12702(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[359]);
t8=t3;
f_12702(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[5],lf[360])));}}}}}}

/* k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_12702(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_12702,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_assq(t2,((C_word*)t0)[3]);
t4=C_slot(t3,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12708,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1038: chicken.base#open-output-string */
t7=*((C_word*)lf[319]+1);{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[6],lf[320]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_12745(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[6],lf[351]);
if(C_truep(t4)){
t5=t3;
f_12745(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[6],lf[352]);
if(C_truep(t5)){
t6=t3;
f_12745(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[6],lf[353]);
if(C_truep(t6)){
t7=t3;
f_12745(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[6],lf[354]);
t8=t3;
f_12745(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[6],lf[355])));}}}}}}

/* k12706 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_12708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_12708,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_fix(2),C_SCHEME_TRUE,lf[313]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1038: ##sys#print */
t6=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[318];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k12712 in k12706 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in ... */
static void C_ccall f_12714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_12714,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1038: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k12715 in k12712 in k12706 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in ... */
static void C_ccall f_12717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_12717,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1038: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[317];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k12718 in k12715 in k12712 in k12706 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in ... */
static void C_ccall f_12720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_12720,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1038: chicken.base#get-output-string */
t3=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k12721 in k12718 in k12715 in k12712 in k12706 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in ... */
static void C_ccall f_12723(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,1)))){
C_save_and_reclaim((void *)f_12723,2,av);}
a=C_alloc(18);
if(C_truep(*((C_word*)lf[10]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_a_i_list(&a,3,lf[314],t1,lf[294]);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[315],((C_word*)t0)[2],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_fcall f_12745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_12745,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_slot(t2,C_fix(1));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12751,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1046: chicken.base#open-output-string */
t6=*((C_word*)lf[319]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[6],lf[324]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12789,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_12789(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[6],lf[349]);
t5=t3;
f_12789(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[6],lf[350])));}}}

/* k12749 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in ... */
static void C_ccall f_12751(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_12751,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_fix(2),C_SCHEME_TRUE,lf[313]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1046: ##sys#print */
t6=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[323];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k12755 in k12749 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in ... */
static void C_ccall f_12757(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_12757,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1046: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k12758 in k12755 in k12749 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in ... */
static void C_ccall f_12760(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_12760,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1046: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[322];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k12761 in k12758 in k12755 in k12749 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in ... */
static void C_ccall f_12763(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_12763,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1046: chicken.base#get-output-string */
t3=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k12764 in k12761 in k12758 in k12755 in k12749 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in ... */
static void C_ccall f_12766(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,1)))){
C_save_and_reclaim((void *)f_12766,2,av);}
a=C_alloc(18);
if(C_truep(*((C_word*)lf[10]+1))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_a_i_list(&a,3,lf[314],t1,lf[294]);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[321],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in ... */
static void C_fcall f_12789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_12789,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1052: chicken.base#gensym */
t3=*((C_word*)lf[99]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[326]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[325],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[4],lf[327]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12833,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_12833(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[346]);
if(C_truep(t5)){
t6=t4;
f_12833(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[347]);
t7=t4;
f_12833(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[348])));}}}}}

/* k12790 in k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in ... */
static void C_ccall f_12792(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(42,c,1)))){
C_save_and_reclaim((void *)f_12792,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[325],t1);
t5=C_a_i_list(&a,2,lf[301],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[302],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[303],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k12831 in k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in ... */
static void C_fcall f_12833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_12833,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1060: chicken.base#gensym */
t3=*((C_word*)lf[99]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[330]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_12878(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[344]);
t5=t3;
f_12878(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[345])));}}}

/* k12834 in k12831 in k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in ... */
static void C_ccall f_12836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(26,c,2)))){
C_save_and_reclaim((void *)f_12836,2,av);}
a=C_alloc(26);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12851,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[10]+1))){
t7=t6;
f_12851(t7,C_a_i_list(&a,2,lf[328],t2));}
else{
t7=C_a_i_list(&a,2,lf[329],t2);
t8=t6;
f_12851(t8,C_a_i_list(&a,2,lf[328],t7));}}

/* k12849 in k12834 in k12831 in k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in ... */
static void C_fcall f_12851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,0,1)))){
C_save_and_reclaim_args((void *)trf_12851,2,t0,t1);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,lf[301],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[302],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[303],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k12876 in k12831 in k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in ... */
static void C_fcall f_12878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,2)))){
C_save_and_reclaim_args((void *)trf_12878,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[10]+1))){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[328],((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_a_i_list(&a,2,lf[329],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[328],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[331]);
if(C_truep(t2)){
if(C_truep(*((C_word*)lf[10]+1))){
t3=C_a_i_list(&a,2,lf[182],((C_word*)t0)[3]);
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[328],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_a_i_list(&a,2,lf[182],((C_word*)t0)[3]);
t4=C_a_i_list(&a,2,lf[329],t3);
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_list(&a,2,lf[328],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12921,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
/* support.scm:1076: lookup-foreign-type */
t4=*((C_word*)lf[288]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_12921(2,av2);}}}}}

/* k12919 in k12876 in k12831 in k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in ... */
static void C_ccall f_12921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_12921,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1076: g3079 */
t3=t2;
f_12925(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[332]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12952,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_12952(t6,t4);}
else{
t6=C_eqp(t3,lf[342]);
if(C_truep(t6)){
t7=t5;
f_12952(t7,t6);}
else{
t7=C_eqp(t3,lf[343]);
t8=t5;
f_12952(t8,(C_truep(t7)?t7:C_eqp(t3,lf[324])));}}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* g3079 in k12919 in k12876 in k12831 in k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in ... */
static void C_fcall f_12925(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_12925,3,t0,t1,t2);}
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1077: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k12950 in k12919 in k12876 in k12831 in k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in ... */
static void C_fcall f_12952(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,2)))){
C_save_and_reclaim_args((void *)trf_12952,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1081: chicken.base#gensym */
t3=*((C_word*)lf[99]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[333]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[334]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1087: chicken.base#gensym */
t5=*((C_word*)lf[99]+1);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[299]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1093: chicken.base#gensym */
t6=*((C_word*)lf[99]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[4],lf[304]);
if(C_truep(t5)){
if(C_truep(*((C_word*)lf[10]+1))){
t6=((C_word*)t0)[2];
t7=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_list(&a,2,lf[300],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t6=C_eqp(((C_word*)t0)[4],lf[337]);
if(C_truep(t6)){
t7=C_a_i_list(&a,2,lf[301],lf[335]);
t8=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t8;
av2[1]=C_a_i_list(&a,3,lf[336],((C_word*)t0)[2],t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[4],lf[338]);
if(C_truep(t7)){
t8=C_i_cadr(((C_word*)t0)[5]);
/* support.scm:1106: repeat */
t9=((C_word*)((C_word*)t0)[6])[1];
f_12471(t9,((C_word*)t0)[3],t8);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[339]);
if(C_truep(t8)){
if(C_truep(*((C_word*)lf[10]+1))){
t9=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t9;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=C_a_i_list(&a,3,lf[314],lf[340],lf[294]);
t10=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t10;
av2[1]=C_a_i_list(&a,3,lf[315],((C_word*)t0)[2],t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}
else{
t9=C_eqp(((C_word*)t0)[4],lf[341]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t10;
av2[1]=(C_truep(t9)?C_a_i_list(&a,2,lf[325],((C_word*)t0)[2]):((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(((C_word*)t0)[4],lf[326]);
t11=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t11;
av2[1]=(C_truep(t10)?C_a_i_list(&a,2,lf[325],((C_word*)t0)[2]):((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}}}}}}}}

/* k12953 in k12950 in k12919 in k12876 in k12831 in k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in ... */
static void C_ccall f_12955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(42,c,1)))){
C_save_and_reclaim((void *)f_12955,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[325],t1);
t5=C_a_i_list(&a,2,lf[301],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[302],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[303],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k12988 in k12950 in k12919 in k12876 in k12831 in k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in ... */
static void C_ccall f_12990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(51,c,1)))){
C_save_and_reclaim((void *)f_12990,2,av);}
a=C_alloc(51);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[301],lf[335]);
t5=C_a_i_list(&a,3,lf[336],((C_word*)t0)[2],t4);
t6=C_a_i_list(&a,2,lf[301],C_SCHEME_FALSE);
t7=C_a_i_list(&a,4,lf[302],t1,t5,t6);
t8=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_a_i_list(&a,3,lf[303],t3,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* k13024 in k12950 in k12919 in k12876 in k12831 in k12787 in k12743 in k12700 in k12674 in k12632 in k12509 in k12494 in repeat in a12464 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in ... */
static void C_ccall f_13026(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(42,c,1)))){
C_save_and_reclaim((void *)f_13026,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(C_truep(*((C_word*)lf[10]+1))?t1:C_a_i_list(&a,2,lf[300],t1));
t5=C_a_i_list(&a,2,lf[301],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[302],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[303],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* a13528 in chicken.compiler.support#foreign-type-check in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_13529,2,av);}
/* support.scm:1118: quit-compiling */
t2=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[386];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* chicken.compiler.support#foreign-type-convert-result in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_13535,4,av);}
a=C_alloc(4);
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13548,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1125: lookup-foreign-type */
t5=*((C_word*)lf[288]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t2;
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k13546 in chicken.compiler.support#foreign-type-convert-result in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13548(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_13548,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_vector_ref(t1,C_fix(2));
if(C_truep(t2)){
t3=C_a_i_list2(&a,2,t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.compiler.support#foreign-type-convert-argument in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_13562,4,av);}
a=C_alloc(4);
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13575,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1132: lookup-foreign-type */
t5=*((C_word*)lf[288]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t2;
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k13573 in chicken.compiler.support#foreign-type-convert-argument in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13575(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_13575,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_vector_ref(t1,C_fix(1));
if(C_truep(t2)){
t3=C_a_i_list2(&a,2,t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.compiler.support#final-foreign-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_13589,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13595,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13622,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1138: follow-without-loop */
f_7239(t1,t2,t3,t4);}

/* a13594 in chicken.compiler.support#final-foreign-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13595(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_13595,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13599,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(t2))){
/* support.scm:1141: lookup-foreign-type */
t5=*((C_word*)lf[288]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=t4;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_13599(2,av2);}}}

/* k13597 in a13594 in chicken.compiler.support#final-foreign-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13599(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_13599,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13603,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1141: g3166 */
t3=t2;
f_13603(t3,((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g3166 in k13597 in a13594 in chicken.compiler.support#final-foreign-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_13603(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_13603,3,t0,t1,t2);}
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1142: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a13621 in chicken.compiler.support#final-foreign-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_13622,2,av);}
/* support.scm:1144: quit-compiling */
t2=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[390];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_13628,3,av);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13631,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13640,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14097,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1152: follow-without-loop */
f_7239(t1,t2,t4,t5);}

/* err in chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_13631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_13631,2,t0,t1);}
/* support.scm:1151: quit-compiling */
t2=*((C_word*)lf[37]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[392];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a13639 in chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_13640,4,av);}
a=C_alloc(7);
t4=t2;
t5=C_eqp(t4,lf[291]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13650,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_13650(t7,t5);}
else{
t7=C_eqp(t4,lf[294]);
if(C_truep(t7)){
t8=t6;
f_13650(t8,t7);}
else{
t8=C_eqp(t4,lf[358]);
if(C_truep(t8)){
t9=t6;
f_13650(t9,t8);}
else{
t9=C_eqp(t4,lf[393]);
if(C_truep(t9)){
t10=t6;
f_13650(t10,t9);}
else{
t10=C_eqp(t4,lf[394]);
if(C_truep(t10)){
t11=t6;
f_13650(t11,t10);}
else{
t11=C_eqp(t4,lf[320]);
if(C_truep(t11)){
t12=t6;
f_13650(t12,t11);}
else{
t12=C_eqp(t4,lf[395]);
if(C_truep(t12)){
t13=t6;
f_13650(t13,t12);}
else{
t13=C_eqp(t4,lf[292]);
if(C_truep(t13)){
t14=t6;
f_13650(t14,t13);}
else{
t14=C_eqp(t4,lf[381]);
if(C_truep(t14)){
t15=t6;
f_13650(t15,t14);}
else{
t15=C_eqp(t4,lf[382]);
if(C_truep(t15)){
t16=t6;
f_13650(t16,t15);}
else{
t16=C_eqp(t4,lf[383]);
if(C_truep(t16)){
t17=t6;
f_13650(t17,t16);}
else{
t17=C_eqp(t4,lf[384]);
t18=t6;
f_13650(t18,(C_truep(t17)?t17:C_eqp(t4,lf[385])));}}}}}}}}}}}}

/* k13648 in a13639 in chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_13650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_13650,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[327]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_13659(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[330]);
if(C_truep(t4)){
t5=t3;
f_13659(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[324]);
if(C_truep(t5)){
t6=t3;
f_13659(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[326]);
if(C_truep(t6)){
t7=t3;
f_13659(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[331]);
if(C_truep(t7)){
t8=t3;
f_13659(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[346]);
if(C_truep(t8)){
t9=t3;
f_13659(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[3],lf[344]);
if(C_truep(t9)){
t10=t3;
f_13659(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[3],lf[347]);
if(C_truep(t10)){
t11=t3;
f_13659(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[3],lf[348]);
if(C_truep(t11)){
t12=t3;
f_13659(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[3],lf[345]);
if(C_truep(t12)){
t13=t3;
f_13659(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[3],lf[349]);
t14=t3;
f_13659(t14,(C_truep(t13)?t13:C_eqp(((C_word*)t0)[3],lf[350])));}}}}}}}}}}}}

/* k13657 in k13648 in a13639 in chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_13659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_13659,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
/* support.scm:1162: words->bytes */
t2=*((C_word*)lf[70]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[352]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_13671(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[359]);
if(C_truep(t4)){
t5=t3;
f_13671(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[357]);
if(C_truep(t5)){
t6=t3;
f_13671(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[351]);
if(C_truep(t6)){
t7=t3;
f_13671(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[312]);
t8=t3;
f_13671(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[3],lf[354])));}}}}}}

/* k13669 in k13657 in k13648 in a13639 in chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_13671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_13671,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
/* support.scm:1164: words->bytes */
t2=*((C_word*)lf[70]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(6);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[296]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_13683(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[379]);
t5=t3;
f_13683(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[3],lf[380])));}}}

/* k13681 in k13669 in k13657 in k13648 in a13639 in chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_13683(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_13683,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
/* support.scm:1166: words->bytes */
t2=*((C_word*)lf[70]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(4);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[356]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_13695(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[355]);
if(C_truep(t4)){
t5=t3;
f_13695(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[353]);
t6=t3;
f_13695(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[3],lf[360])));}}}}

/* k13693 in k13681 in k13669 in k13657 in k13648 in a13639 in chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_13695(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_13695,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
/* support.scm:1168: words->bytes */
t2=*((C_word*)lf[70]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(7);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13701,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* support.scm:1170: lookup-foreign-type */
t3=*((C_word*)lf[288]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_13701(2,av2);}}}}

/* k13699 in k13693 in k13681 in k13669 in k13657 in k13648 in a13639 in chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_13701(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_13701,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13705,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1170: g3287 */
t3=t2;
f_13705(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[332]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13732,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_13732(t6,t4);}
else{
t6=C_eqp(t3,lf[341]);
if(C_truep(t6)){
t7=t5;
f_13732(t7,t6);}
else{
t7=C_eqp(t3,lf[342]);
if(C_truep(t7)){
t8=t5;
f_13732(t8,t7);}
else{
t8=C_eqp(t3,lf[324]);
if(C_truep(t8)){
t9=t5;
f_13732(t9,t8);}
else{
t9=C_eqp(t3,lf[326]);
if(C_truep(t9)){
t10=t5;
f_13732(t10,t9);}
else{
t10=C_eqp(t3,lf[343]);
if(C_truep(t10)){
t11=t5;
f_13732(t11,t10);}
else{
t11=C_eqp(t3,lf[333]);
if(C_truep(t11)){
t12=t5;
f_13732(t12,t11);}
else{
t12=C_eqp(t3,lf[334]);
t13=t5;
f_13732(t13,(C_truep(t12)?t12:C_eqp(t3,lf[337])));}}}}}}}}
else{
/* support.scm:1179: err */
t2=((C_word*)t0)[5];
f_13631(t2,((C_word*)t0)[3]);}}}

/* g3287 in k13699 in k13693 in k13681 in k13669 in k13657 in k13648 in a13639 in chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_fcall f_13705(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_13705,3,t0,t1,t2);}
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1171: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k13730 in k13699 in k13693 in k13681 in k13669 in k13657 in k13648 in a13639 in chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_fcall f_13732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_13732,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:1175: words->bytes */
t2=*((C_word*)lf[70]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[338]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[4]);
/* support.scm:1176: next */
t4=((C_word*)t0)[5];{
C_word av2[3];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[339]);
if(C_truep(t3)){
/* support.scm:1177: words->bytes */
t4=*((C_word*)lf[70]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(6);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* support.scm:1178: err */
t4=((C_word*)t0)[6];
f_13631(t4,((C_word*)t0)[2]);}}}}

/* a14096 in chicken.compiler.support#estimate-foreign-result-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_14097(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_14097,2,av);}
/* support.scm:1180: quit-compiling */
t2=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[396];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* chicken.compiler.support#estimate-foreign-result-location-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_14103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_14103,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14115,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14547,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1185: follow-without-loop */
f_7239(t1,t2,t3,t4);}

/* a14114 in chicken.compiler.support#estimate-foreign-result-location-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_14115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_14115,4,av);}
a=C_alloc(6);
t4=t2;
t5=C_eqp(t4,lf[291]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14125,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_14125(t7,t5);}
else{
t7=C_eqp(t4,lf[294]);
if(C_truep(t7)){
t8=t6;
f_14125(t8,t7);}
else{
t8=C_eqp(t4,lf[358]);
if(C_truep(t8)){
t9=t6;
f_14125(t9,t8);}
else{
t9=C_eqp(t4,lf[393]);
if(C_truep(t9)){
t10=t6;
f_14125(t10,t9);}
else{
t10=C_eqp(t4,lf[320]);
if(C_truep(t10)){
t11=t6;
f_14125(t11,t10);}
else{
t11=C_eqp(t4,lf[292]);
if(C_truep(t11)){
t12=t6;
f_14125(t12,t11);}
else{
t12=C_eqp(t4,lf[381]);
if(C_truep(t12)){
t13=t6;
f_14125(t13,t12);}
else{
t13=C_eqp(t4,lf[359]);
if(C_truep(t13)){
t14=t6;
f_14125(t14,t13);}
else{
t14=C_eqp(t4,lf[351]);
if(C_truep(t14)){
t15=t6;
f_14125(t15,t14);}
else{
t15=C_eqp(t4,lf[382]);
if(C_truep(t15)){
t16=t6;
f_14125(t16,t15);}
else{
t16=C_eqp(t4,lf[383]);
if(C_truep(t16)){
t17=t6;
f_14125(t17,t16);}
else{
t17=C_eqp(t4,lf[324]);
if(C_truep(t17)){
t18=t6;
f_14125(t18,t17);}
else{
t18=C_eqp(t4,lf[326]);
if(C_truep(t18)){
t19=t6;
f_14125(t19,t18);}
else{
t19=C_eqp(t4,lf[352]);
if(C_truep(t19)){
t20=t6;
f_14125(t20,t19);}
else{
t20=C_eqp(t4,lf[357]);
if(C_truep(t20)){
t21=t6;
f_14125(t21,t20);}
else{
t21=C_eqp(t4,lf[296]);
if(C_truep(t21)){
t22=t6;
f_14125(t22,t21);}
else{
t22=C_eqp(t4,lf[327]);
if(C_truep(t22)){
t23=t6;
f_14125(t23,t22);}
else{
t23=C_eqp(t4,lf[331]);
if(C_truep(t23)){
t24=t6;
f_14125(t24,t23);}
else{
t24=C_eqp(t4,lf[299]);
if(C_truep(t24)){
t25=t6;
f_14125(t25,t24);}
else{
t25=C_eqp(t4,lf[304]);
if(C_truep(t25)){
t26=t6;
f_14125(t26,t25);}
else{
t26=C_eqp(t4,lf[384]);
if(C_truep(t26)){
t27=t6;
f_14125(t27,t26);}
else{
t27=C_eqp(t4,lf[385]);
if(C_truep(t27)){
t28=t6;
f_14125(t28,t27);}
else{
t28=C_eqp(t4,lf[312]);
if(C_truep(t28)){
t29=t6;
f_14125(t29,t28);}
else{
t29=C_eqp(t4,lf[354]);
if(C_truep(t29)){
t30=t6;
f_14125(t30,t29);}
else{
t30=C_eqp(t4,lf[347]);
if(C_truep(t30)){
t31=t6;
f_14125(t31,t30);}
else{
t31=C_eqp(t4,lf[348]);
if(C_truep(t31)){
t32=t6;
f_14125(t32,t31);}
else{
t32=C_eqp(t4,lf[345]);
if(C_truep(t32)){
t33=t6;
f_14125(t33,t32);}
else{
t33=C_eqp(t4,lf[330]);
if(C_truep(t33)){
t34=t6;
f_14125(t34,t33);}
else{
t34=C_eqp(t4,lf[346]);
if(C_truep(t34)){
t35=t6;
f_14125(t35,t34);}
else{
t35=C_eqp(t4,lf[344]);
if(C_truep(t35)){
t36=t6;
f_14125(t36,t35);}
else{
t36=C_eqp(t4,lf[349]);
t37=t6;
f_14125(t37,(C_truep(t36)?t36:C_eqp(t4,lf[350])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k14123 in a14114 in chicken.compiler.support#estimate-foreign-result-location-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_14125(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_14125,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:1194: words->bytes */
t2=*((C_word*)lf[70]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[379]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_14137(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[356]);
if(C_truep(t4)){
t5=t3;
f_14137(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[355]);
if(C_truep(t5)){
t6=t3;
f_14137(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[353]);
t7=t3;
f_14137(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[360])));}}}}}

/* k14135 in k14123 in a14114 in chicken.compiler.support#estimate-foreign-result-location-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_14137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_14137,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:1196: words->bytes */
t2=*((C_word*)lf[70]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(2);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* support.scm:1198: lookup-foreign-type */
t3=*((C_word*)lf[288]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_14143(2,av2);}}}}

/* k14141 in k14135 in k14123 in a14114 in chicken.compiler.support#estimate-foreign-result-location-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_14143(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_14143,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14147,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1198: g3445 */
t3=t2;
f_14147(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[332]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14174,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_14174(t6,t4);}
else{
t6=C_eqp(t3,lf[341]);
if(C_truep(t6)){
t7=t5;
f_14174(t7,t6);}
else{
t7=C_eqp(t3,lf[342]);
if(C_truep(t7)){
t8=t5;
f_14174(t8,t7);}
else{
t8=C_eqp(t3,lf[324]);
if(C_truep(t8)){
t9=t5;
f_14174(t9,t8);}
else{
t9=C_eqp(t3,lf[326]);
if(C_truep(t9)){
t10=t5;
f_14174(t10,t9);}
else{
t10=C_eqp(t3,lf[343]);
if(C_truep(t10)){
t11=t5;
f_14174(t11,t10);}
else{
t11=C_eqp(t3,lf[299]);
if(C_truep(t11)){
t12=t5;
f_14174(t12,t11);}
else{
t12=C_eqp(t3,lf[304]);
t13=t5;
f_14174(t13,(C_truep(t12)?t12:C_eqp(t3,lf[339])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
/* support.scm:1184: quit-compiling */
t4=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[398];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}}

/* g3445 in k14141 in k14135 in k14123 in a14114 in chicken.compiler.support#estimate-foreign-result-location-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_14147(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_14147,3,t0,t1,t2);}
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1199: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k14172 in k14141 in k14135 in k14123 in a14114 in chicken.compiler.support#estimate-foreign-result-location-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_14174(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_14174,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:1204: words->bytes */
t2=*((C_word*)lf[70]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[338]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[4]);
/* support.scm:1205: next */
t4=((C_word*)t0)[5];{
C_word av2[3];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[4];
/* support.scm:1184: quit-compiling */
t5=*((C_word*)lf[37]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[398];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}}

/* a14546 in chicken.compiler.support#estimate-foreign-result-location-size in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_14547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_14547,2,av);}
/* support.scm:1208: quit-compiling */
t2=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[399];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* chicken.compiler.support#finish-foreign-result in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_14553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_14553,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14557,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1214: chicken.syntax#strip-syntax */
t5=*((C_word*)lf[413]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k14555 in chicken.compiler.support#finish-foreign-result in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_14557(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,2)))){
C_save_and_reclaim((void *)f_14557,2,av);}
a=C_alloc(21);
t2=t1;
t3=C_eqp(t2,lf[327]);
t4=(C_truep(t3)?t3:C_eqp(t2,lf[347]));
if(C_truep(t4)){
t5=C_a_i_list(&a,2,lf[301],C_fix(0));
t6=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[401],((C_word*)t0)[3],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_eqp(t2,lf[330]);
if(C_truep(t5)){
t6=C_a_i_list(&a,2,lf[301],C_fix(0));
t7=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[402],((C_word*)t0)[3],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_eqp(t2,lf[346]);
t7=(C_truep(t6)?t6:C_eqp(t2,lf[348]));
if(C_truep(t7)){
t8=C_a_i_list(&a,2,lf[301],C_fix(0));
t9=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t9;
av2[1]=C_a_i_list(&a,3,lf[403],((C_word*)t0)[3],t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=C_eqp(t2,lf[344]);
t9=(C_truep(t8)?t8:C_eqp(t2,lf[345]));
if(C_truep(t9)){
t10=C_a_i_list(&a,2,lf[301],C_fix(0));
t11=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t11;
av2[1]=C_a_i_list(&a,3,lf[404],((C_word*)t0)[3],t10);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t10=C_eqp(t2,lf[331]);
if(C_truep(t10)){
t11=C_a_i_list(&a,2,lf[301],C_fix(0));
t12=C_a_i_list(&a,3,lf[401],((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t13;
av2[1]=C_a_i_list(&a,2,lf[405],t12);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t11=C_eqp(t2,lf[349]);
if(C_truep(t11)){
t12=C_a_i_list(&a,2,lf[301],C_SCHEME_FALSE);
t13=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t13;
av2[1]=C_a_i_list(&a,3,lf[406],((C_word*)t0)[3],t12);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t12=C_eqp(t2,lf[350]);
if(C_truep(t12)){
t13=C_a_i_list(&a,2,lf[301],C_SCHEME_FALSE);
t14=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t14;
av2[1]=C_a_i_list(&a,3,lf[407],((C_word*)t0)[3],t13);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
if(C_truep(C_i_listp(t2))){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14673,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=C_i_car(t2);
t15=C_eqp(t14,lf[338]);
if(C_truep(t15)){
t16=C_i_length(t2);
t17=C_eqp(C_fix(2),t16);
if(C_truep(t17)){
t18=C_i_cadr(t2);
t19=C_u_i_memq(t18,lf[412]);
t20=t13;
f_14673(t20,t19);}
else{
t18=t13;
f_14673(t18,C_SCHEME_FALSE);}}
else{
t16=t13;
f_14673(t16,C_SCHEME_FALSE);}}
else{
t13=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t13;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}}}}}}}}}

/* k14671 in k14555 in chicken.compiler.support#finish-foreign-result in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_14673(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,3)))){
C_save_and_reclaim_args((void *)trf_14673,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
/* support.scm:1231: finish-foreign-result */
t3=*((C_word*)lf[400]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=C_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(3),t2);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[2]);
t5=C_eqp(t4,lf[333]);
t6=(C_truep(t5)?t5:C_eqp(t4,lf[334]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14701,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1235: chicken.base#gensym */
t8=*((C_word*)lf[99]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(t4,lf[337]);
if(C_truep(t7)){
t8=C_i_caddr(((C_word*)t0)[2]);
t9=C_a_i_list(&a,2,lf[301],lf[335]);
t10=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t10;
av2[1]=C_a_i_list(&a,4,lf[410],t8,t9,((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t8=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t8;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}
else{
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* k14699 in k14671 in k14555 in chicken.compiler.support#finish-foreign-result in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_14701(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(60,c,1)))){
C_save_and_reclaim((void *)f_14701,2,av);}
a=C_alloc(60);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[408],t1);
t5=C_a_i_list(&a,2,lf[409],t4);
t6=C_i_caddr(((C_word*)t0)[3]);
t7=C_a_i_list(&a,2,lf[301],lf[335]);
t8=C_a_i_list(&a,4,lf[410],t6,t7,t1);
t9=C_a_i_list(&a,4,lf[411],t1,t5,t8);
t10=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t10;
av2[1]=C_a_i_list(&a,3,lf[98],t3,t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}

/* chicken.compiler.support#foreign-type->scrutiny-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_14821(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_14821,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14825,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1252: final-foreign-type */
t5=*((C_word*)lf[389]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k14823 in chicken.compiler.support#foreign-type->scrutiny-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_14825(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_14825,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_eqp(t3,lf[394]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t5;
av2[1]=lf[415];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(t3,lf[291]);
t6=(C_truep(t5)?t5:C_eqp(t3,lf[292]));
if(C_truep(t6)){
t7=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t7;
av2[1]=lf[291];
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_eqp(t3,lf[294]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14849,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_14849(t9,t7);}
else{
t9=C_eqp(t3,lf[381]);
if(C_truep(t9)){
t10=t8;
f_14849(t10,t9);}
else{
t10=C_eqp(t3,lf[358]);
if(C_truep(t10)){
t11=t8;
f_14849(t11,t10);}
else{
t11=C_eqp(t3,lf[320]);
if(C_truep(t11)){
t12=t8;
f_14849(t12,t11);}
else{
t12=C_eqp(t3,lf[382]);
if(C_truep(t12)){
t13=t8;
f_14849(t13,t12);}
else{
t13=C_eqp(t3,lf[383]);
if(C_truep(t13)){
t14=t8;
f_14849(t14,t13);}
else{
t14=C_eqp(t3,lf[384]);
t15=t8;
f_14849(t15,(C_truep(t14)?t14:C_eqp(t3,lf[385])));}}}}}}}}}

/* k14847 in k14823 in chicken.compiler.support#foreign-type->scrutiny-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_14849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_14849,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[166];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[296]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[379]));
if(C_truep(t3)){
t4=((C_word*)t0)[4];
t5=C_eqp(t4,lf[416]);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(t5)?lf[380]:lf[296]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[299]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[3],lf[304]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=lf[172];
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(((C_word*)t0)[3],lf[298]);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
t8=C_eqp(t7,lf[416]);
t9=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t9;
av2[1]=(C_truep(t8)?lf[417]:lf[298]);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[3],lf[305]);
if(C_truep(t7)){
t8=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t8;
av2[1]=lf[298];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_eqp(((C_word*)t0)[3],lf[306]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=C_eqp(t9,lf[416]);
t11=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t11;
av2[1]=(C_truep(t10)?lf[418]:lf[306]);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t9=C_eqp(((C_word*)t0)[3],lf[308]);
if(C_truep(t9)){
t10=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t10;
av2[1]=lf[306];
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(((C_word*)t0)[3],lf[309]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14924,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t10)){
t12=t11;
f_14924(t12,t10);}
else{
t12=C_eqp(((C_word*)t0)[3],lf[370]);
if(C_truep(t12)){
t13=t11;
f_14924(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[3],lf[371]);
if(C_truep(t13)){
t14=t11;
f_14924(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[3],lf[372]);
if(C_truep(t14)){
t15=t11;
f_14924(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[3],lf[373]);
if(C_truep(t15)){
t16=t11;
f_14924(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[3],lf[374]);
if(C_truep(t16)){
t17=t11;
f_14924(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[3],lf[375]);
if(C_truep(t17)){
t18=t11;
f_14924(t18,t17);}
else{
t18=C_eqp(((C_word*)t0)[3],lf[376]);
if(C_truep(t18)){
t19=t11;
f_14924(t19,t18);}
else{
t19=C_eqp(((C_word*)t0)[3],lf[377]);
t20=t11;
f_14924(t20,(C_truep(t19)?t19:C_eqp(((C_word*)t0)[3],lf[378])));}}}}}}}}}}}}}}}}

/* k14922 in k14847 in k14823 in chicken.compiler.support#foreign-type->scrutiny-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_14924(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,2)))){
C_save_and_reclaim_args((void *)trf_14924,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[416]);
if(C_truep(t3)){
t4=C_a_i_list(&a,2,lf[419],((C_word*)t0)[3]);
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[420],lf[421],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[419],((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[310]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[422];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[5],lf[362]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[423];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[5],lf[361]);
if(C_truep(t4)){
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=lf[424];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[5],lf[363]);
if(C_truep(t5)){
t6=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t6;
av2[1]=lf[425];
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(((C_word*)t0)[5],lf[364]);
if(C_truep(t6)){
t7=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t7;
av2[1]=lf[426];
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[5],lf[365]);
if(C_truep(t7)){
t8=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t8;
av2[1]=lf[427];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_eqp(((C_word*)t0)[5],lf[366]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t9;
av2[1]=lf[428];
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=C_eqp(((C_word*)t0)[5],lf[367]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t10;
av2[1]=lf[429];
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(((C_word*)t0)[5],lf[368]);
if(C_truep(t10)){
t11=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t11;
av2[1]=lf[430];
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t11=C_eqp(((C_word*)t0)[5],lf[369]);
if(C_truep(t11)){
t12=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t12;
av2[1]=lf[431];
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
else{
t12=C_eqp(((C_word*)t0)[5],lf[357]);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15011,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t12)){
t14=t13;
f_15011(t14,t12);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[359]);
if(C_truep(t14)){
t15=t13;
f_15011(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[5],lf[353]);
if(C_truep(t15)){
t16=t13;
f_15011(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[5],lf[360]);
if(C_truep(t16)){
t17=t13;
f_15011(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[5],lf[312]);
if(C_truep(t17)){
t18=t13;
f_15011(t18,t17);}
else{
t18=C_eqp(((C_word*)t0)[5],lf[354]);
if(C_truep(t18)){
t19=t13;
f_15011(t19,t18);}
else{
t19=C_eqp(((C_word*)t0)[5],lf[356]);
if(C_truep(t19)){
t20=t13;
f_15011(t20,t19);}
else{
t20=C_eqp(((C_word*)t0)[5],lf[355]);
t21=t13;
f_15011(t21,(C_truep(t20)?t20:C_eqp(((C_word*)t0)[5],lf[351])));}}}}}}}}}}}}}}}}}}}

/* k15009 in k14922 in k14847 in k14823 in chicken.compiler.support#foreign-type->scrutiny-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_15011,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[357];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[324]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[432];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[326]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[342];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[327]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_15032(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[346]);
if(C_truep(t6)){
t7=t5;
f_15032(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[347]);
t8=t5;
f_15032(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[3],lf[348])));}}}}}}

/* k15030 in k15009 in k14922 in k14847 in k14823 in chicken.compiler.support#foreign-type->scrutiny-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_15032,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[433];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[349]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[350]));
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[434];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[330]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_15050(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[344]);
t7=t5;
f_15050(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[345])));}}}}

/* k15048 in k15030 in k15009 in k14922 in k14847 in k14823 in chicken.compiler.support#foreign-type->scrutiny-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_15050,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[435];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[331]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[331];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[4];
t4=C_u_i_car(t3);
t5=C_eqp(t4,lf[332]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15072,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_15072(t7,t5);}
else{
t7=C_eqp(t4,lf[342]);
if(C_truep(t7)){
t8=t6;
f_15072(t8,t7);}
else{
t8=C_eqp(t4,lf[343]);
t9=t6;
f_15072(t9,(C_truep(t8)?t8:C_eqp(t4,lf[324])));}}}
else{
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[172];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}}

/* k15070 in k15048 in k15030 in k15009 in k14922 in k14847 in k14823 in chicken.compiler.support#foreign-type->scrutiny-type in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_15072,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[436];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[338]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[4]);
/* support.scm:1304: foreign-type->scrutiny-type */
t4=*((C_word*)lf[414]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[339]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[357];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[341]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=(C_truep(t4)?lf[342]:lf[172]);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[3],lf[326]);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(t5)?lf[342]:lf[172]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}}}

/* chicken.compiler.support#scan-used-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_15427,4,av);}
a=C_alloc(13);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15431,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15433,a[2]=t8,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];{
C_word *av2=av;
av2[0]=t10;
av2[1]=t6;
av2[2]=t2;
f_15433(3,av2);}}

/* k15429 in chicken.compiler.support#scan-used-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15431(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15431,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* walk in chicken.compiler.support#scan-used-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_15433,3,av);}
a=C_alloc(10);
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(1));
t8=C_eqp(t7,lf[156]);
t9=(C_truep(t8)?t8:C_eqp(t7,lf[126]));
if(C_truep(t9)){
t10=t2;
t11=C_slot(t10,C_fix(2));
t12=C_i_car(t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15465,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15497,a[2]=t13,a[3]=((C_word*)t0)[3],a[4]=t14,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(t13,((C_word*)t0)[4]))){
t16=C_i_memq(t13,((C_word*)((C_word*)t0)[3])[1]);
t17=t15;
f_15497(t17,C_i_not(t16));}
else{
t16=t15;
f_15497(t16,C_SCHEME_FALSE);}}
else{
t10=C_eqp(t7,lf[87]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15529,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t10)){
t12=t11;
f_15529(t12,t10);}
else{
t12=C_eqp(t7,lf[161]);
t13=t11;
f_15529(t13,(C_truep(t12)?t12:C_eqp(t7,lf[173])));}}}

/* k15463 in walk in chicken.compiler.support#scan-used-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15465(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_15465,2,t0,t1);}
a=C_alloc(6);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_i_check_list_2(((C_word*)t0)[3],lf[44]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15473,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_15473(t7,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* for-each-loop3726 in k15463 in walk in chicken.compiler.support#scan-used-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15473(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_15473,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15483,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1322: g3727 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k15481 in for-each-loop3726 in k15463 in walk in chicken.compiler.support#scan-used-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15483(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_15483,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_15473(t3,((C_word*)t0)[4],t2);}

/* k15495 in walk in chicken.compiler.support#scan-used-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15497(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,1)))){
C_save_and_reclaim_args((void *)trf_15497,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
f_15465(t4,t3);}
else{
t2=((C_word*)t0)[4];
f_15465(t2,C_SCHEME_UNDEFINED);}}

/* k15527 in walk in chicken.compiler.support#scan-used-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_15529,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=C_i_check_list_2(((C_word*)t0)[4],lf[44]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15537,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_15537(t7,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* for-each-loop3751 in k15527 in walk in chicken.compiler.support#scan-used-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15537(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_15537,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15547,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1324: g3752 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k15545 in for-each-loop3751 in k15527 in walk in chicken.compiler.support#scan-used-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_15547,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_15537(t3,((C_word*)t0)[4],t2);}

/* chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15582(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,4)))){
C_save_and_reclaim((void *)f_15582,4,av);}
a=C_alloc(23);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15585,a[2]=t5,a[3]=t7,a[4]=t3,a[5]=t9,a[6]=t11,tmp=(C_word)a,a+=7,tmp));
t13=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15769,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15807,a[2]=t1,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1362: walk */
t15=((C_word*)t9)[1];
f_15585(t15,t14,t2,C_SCHEME_END_OF_LIST);}

/* walk in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15585(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,2)))){
C_save_and_reclaim_args((void *)trf_15585,4,t0,t1,t2,t3);}
a=C_alloc(12);
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=t11;
t13=C_eqp(t12,lf[87]);
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_15619,a[2]=t1,a[3]=t12,a[4]=t9,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t6,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t13)){
t15=t14;
f_15619(t15,t13);}
else{
t15=C_eqp(t12,lf[161]);
if(C_truep(t15)){
t16=t14;
f_15619(t16,t15);}
else{
t16=C_eqp(t12,lf[173]);
if(C_truep(t16)){
t17=t14;
f_15619(t17,t16);}
else{
t17=C_eqp(t12,lf[176]);
t18=t14;
f_15619(t18,(C_truep(t17)?t17:C_eqp(t12,lf[185])));}}}}

/* k15617 in walk in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,5)))){
C_save_and_reclaim_args((void *)trf_15619,2,t0,t1);}
a=C_alloc(10);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[156]);
if(C_truep(t2)){
t3=C_i_car(((C_word*)t0)[4]);
t4=t3;
if(C_truep(C_i_memq(t4,((C_word*)t0)[5]))){
t5=C_SCHEME_UNDEFINED;
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15638,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=t4,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1342: lset-adjoin/eq? */
f_5969(t5,((C_word*)((C_word*)t0)[6])[1],C_a_i_list(&a,1,t4));}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[126]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
if(C_truep(C_i_memq(t4,((C_word*)t0)[5]))){
t5=C_i_car(((C_word*)t0)[9]);
/* support.scm:1348: walk */
t6=((C_word*)((C_word*)t0)[10])[1];
f_15585(t6,((C_word*)t0)[2],t5,((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15674,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1347: lset-adjoin/eq? */
f_5969(t5,((C_word*)((C_word*)t0)[6])[1],C_a_i_list(&a,1,t4));}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[98]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15683,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(((C_word*)t0)[9]);
/* support.scm:1350: walk */
t7=((C_word*)((C_word*)t0)[10])[1];
f_15585(t7,t5,t6,((C_word*)t0)[5]);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[120]);
if(C_truep(t5)){
t6=C_i_caddr(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15713,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1353: ##sys#decompose-lambda-list */
t8=*((C_word*)lf[215]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=((C_word*)t0)[2];
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
/* support.scm:1357: walkeach */
t6=((C_word*)((C_word*)t0)[11])[1];
f_15769(t6,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[5]);}}}}}}

/* k15636 in k15617 in walk in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15638(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_15638,2,av);}
a=C_alloc(5);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15644,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1343: variable-visible? */
t4=*((C_word*)lf[244]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k15642 in k15636 in k15617 in walk in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15644(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_15644,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1344: lset-adjoin/eq? */
f_5969(t2,((C_word*)((C_word*)t0)[3])[1],C_a_i_list(&a,1,((C_word*)t0)[4]));}}

/* k15646 in k15642 in k15636 in k15617 in walk in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15648(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15648,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k15672 in k15617 in walk in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15674(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15674,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:1348: walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_15585(t4,((C_word*)t0)[5],t3,((C_word*)t0)[6]);}

/* k15681 in k15617 in walk in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_15683,2,av);}
a=C_alloc(5);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1351: scheme#append */
t5=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k15692 in k15681 in k15617 in walk in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15694,2,av);}
/* support.scm:1351: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15585(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* a15712 in k15617 in walk in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_15713,5,av);}
a=C_alloc(5);
t5=C_i_car(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15725,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1356: scheme#append */
t8=*((C_word*)lf[60]+1);{
C_word *av2=av;
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k15723 in a15712 in k15617 in walk in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15725,2,av);}
/* support.scm:1356: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15585(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* walkeach in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15769(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,3)))){
C_save_and_reclaim_args((void *)trf_15769,4,t0,t1,t2,t3);}
a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15771,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_check_list_2(t2,lf[44]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15783,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_15783(t9,t1,t2);}

/* g3819 in walkeach in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15771(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_15771,3,t0,t1,t2);}
/* support.scm:1360: walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_15585(t3,t1,t2,((C_word*)t0)[3]);}

/* for-each-loop3818 in walkeach in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15783(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_15783,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15793,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1360: g3819 */
t5=((C_word*)t0)[3];
f_15771(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k15791 in for-each-loop3818 in walkeach in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_15793,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_15783(t3,((C_word*)t0)[4],t2);}

/* k15805 in chicken.compiler.support#scan-free-variables in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15807(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15807,2,av);}
/* support.scm:1363: scheme#values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)((C_word*)t0)[4])[1];
C_values(4,av2);}}

/* chicken.compiler.support#chop-separator in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_15812,3,av);}
a=C_alloc(10);
t3=C_i_string_length(t2);
t4=C_a_i_fixnum_difference(&a,2,t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15823,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_integer_greaterp(t4,C_fix(0)))){
t6=C_i_string_ref(t2,t4);
t7=t5;
f_15823(t7,C_u_i_memq(t6,lf[441]));}
else{
t6=t5;
f_15823(t6,C_SCHEME_FALSE);}}

/* k15821 in chicken.compiler.support#chop-separator in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_15823,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:1372: scheme#substring */
t2=*((C_word*)lf[440]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(0);
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.compiler.support#make-block-variable-literal in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_15836,3,av);}
a=C_alloc(3);
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record2(&a,2,lf[443],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#block-variable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15842,3,av);}
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[443]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#block-variable-literal-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15848,3,av);}
t3=C_i_check_structure_2(t2,lf[443],lf[446]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#make-random-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2)))){
C_save_and_reclaim((void*)f_15857,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15865,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1388: chicken.base#open-output-string */
t4=*((C_word*)lf[319]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k15863 in chicken.compiler.support#make-random-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15865(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_15865,2,av);}
a=C_alloc(9);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_fix(2),C_SCHEME_TRUE,lf[313]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15871,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15892,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* support.scm:1389: chicken.base#gensym */
t8=*((C_word*)lf[99]+1);{
C_word *av2=av;
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_i_car(t6);
/* support.scm:1388: ##sys#print */
t9=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=t5;
av2[2]=t8;
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}}

/* k15869 in k15863 in chicken.compiler.support#make-random-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_15871,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1388: ##sys#write-char-0 */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(45);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k15872 in k15869 in k15863 in chicken.compiler.support#make-random-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_15874,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15888,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1390: chicken.time#current-seconds */
t4=*((C_word*)lf[448]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k15875 in k15872 in k15869 in k15863 in chicken.compiler.support#make-random-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_15877,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_random_fixnum(C_fix(1000));
/* support.scm:1388: ##sys#print */
t4=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k15878 in k15875 in k15872 in k15869 in k15863 in chicken.compiler.support#make-random-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_15880,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15883,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1388: chicken.base#get-output-string */
t3=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k15881 in k15878 in k15875 in k15872 in k15869 in k15863 in chicken.compiler.support#make-random-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15883(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_15883,2,av);}
/* support.scm:1387: scheme#string->symbol */
t2=*((C_word*)lf[447]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k15886 in k15872 in k15869 in k15863 in chicken.compiler.support#make-random-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_15888,2,av);}
/* support.scm:1388: ##sys#print */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k15890 in k15863 in chicken.compiler.support#make-random-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_15892,2,av);}
/* support.scm:1388: ##sys#print */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* chicken.compiler.support#clear-real-name-table! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15904(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_15904,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15909,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1406: scheme#make-vector */
t3=*((C_word*)lf[286]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(997);
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k15907 in chicken.compiler.support#clear-real-name-table! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15909,2,av);}
t2=C_mutate(&lf[449] /* (set! chicken.compiler.support#real-name-table ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#set-real-name! in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_15911,4,av);}
/* support.scm:1409: chicken.internal#hash-table-set! */
t4=*((C_word*)lf[134]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[449];
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* chicken.compiler.support#get-real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15917,3,av);}
/* support.scm:1414: chicken.internal#hash-table-ref */
t3=*((C_word*)lf[130]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[449];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15924(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,3)))){
C_save_and_reclaim((void*)f_15924,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15927,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15943,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1426: resolve */
f_15927(t5,t2);}

/* resolve in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15927(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_15927,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15931,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1421: chicken.internal#hash-table-ref */
t4=*((C_word*)lf[130]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[449];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k15929 in resolve in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15931(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_15931,2,av);}
a=C_alloc(4);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15937,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1423: chicken.internal#hash-table-ref */
t4=*((C_word*)lf[130]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[449];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k15935 in k15929 in resolve in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15937(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_15937,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=(C_truep(t1)?t1:((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k15941 in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15943(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_15943,2,av);}
a=C_alloc(6);
if(C_truep(C_i_not(t1))){
/* support.scm:1427: ##sys#symbol->string */
t2=*((C_word*)lf[182]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16039,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1430: ##sys#symbol->string */
t5=*((C_word*)lf[182]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* support.scm:1444: ##sys#symbol->string */
t2=*((C_word*)lf[182]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}}

/* k15968 in k16037 in k15941 in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,5)))){
C_save_and_reclaim((void *)f_15970,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15972,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_15972(t5,((C_word*)t0)[4],((C_word*)t0)[5],C_fix(0),t1);}

/* loop in k15968 in k16037 in k15941 in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_15972(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_15972,5,t0,t1,t2,t3,t4);}
a=C_alloc(8);
if(C_truep(C_i_greaterp(t3,C_fix(20)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15986,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_cons(&a,2,lf[455],t2);
/* support.scm:1435: scheme#reverse */
t7=*((C_word*)lf[82]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15996,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1437: resolve */
f_15927(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16035,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1443: scheme#reverse */
t6=*((C_word*)lf[82]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}

/* k15984 in loop in k15968 in k16037 in k15941 in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_15986,2,av);}
/* support.scm:1435: chicken.string#string-intersperse */
t2=*((C_word*)lf[453]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[454];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k15994 in loop in k15968 in k16037 in k15941 in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_15996(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_15996,2,av);}
a=C_alloc(8);
t2=C_eqp(t1,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16009,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1439: scheme#reverse */
t4=*((C_word*)lf[82]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16028,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1440: scheme#symbol->string */
t4=*((C_word*)lf[223]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k16007 in k15994 in loop in k15968 in k16037 in k15941 in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16009(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16009,2,av);}
/* support.scm:1439: chicken.string#string-intersperse */
t2=*((C_word*)lf[453]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[456];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k16022 in k16026 in k15994 in loop in k15968 in k16037 in k15941 in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_16024,2,av);}
/* support.scm:1440: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15972(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k16026 in k15994 in loop in k15968 in k16037 in k15941 in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_16028,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=t2;
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16024,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1442: db-get */
t7=*((C_word*)lf[129]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[7];
av2[4]=lf[457];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k16033 in loop in k15968 in k16037 in k15941 in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16035(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16035,2,av);}
/* support.scm:1443: chicken.string#string-intersperse */
t2=*((C_word*)lf[453]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[458];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k16037 in k15941 in chicken.compiler.support#real-name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16039(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_16039,2,av);}
a=C_alloc(9);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1432: db-get */
t5=*((C_word*)lf[129]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[457];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* chicken.compiler.support#real-name2 in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_16044,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16048,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1447: chicken.internal#hash-table-ref */
t5=*((C_word*)lf[130]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[449];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k16046 in chicken.compiler.support#real-name2 in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16048,2,av);}
if(C_truep(t1)){
/* support.scm:1448: real-name */
t2=*((C_word*)lf[55]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* chicken.compiler.support#display-real-name-table in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16056(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_16056,2,av);}
a=C_alloc(2);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16062,tmp=(C_word)a,a+=2,tmp);
/* support.scm:1451: chicken.internal#hash-table-for-each */
t3=*((C_word*)lf[141]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[449];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a16061 in chicken.compiler.support#display-real-name-table in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_16062,4,av);}
a=C_alloc(5);
t4=*((C_word*)lf[24]+1);
t5=*((C_word*)lf[24]+1);
t6=C_i_check_port_2(*((C_word*)lf[24]+1),C_fix(2),C_SCHEME_TRUE,lf[25]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16069,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1453: ##sys#print */
t8=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=*((C_word*)lf[24]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}

/* k16067 in a16061 in chicken.compiler.support#display-real-name-table in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_16069,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1453: ##sys#write-char-0 */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(9);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k16070 in k16067 in a16061 in chicken.compiler.support#display-real-name-table in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16072(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_16072,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1453: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k16073 in k16070 in k16067 in a16061 in chicken.compiler.support#display-real-name-table in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16075(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16075,2,av);}
/* support.scm:1453: ##sys#write-char-0 */
t2=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* chicken.compiler.support#source-info->string in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_16080,3,av);}
a=C_alloc(13);
if(C_truep(C_i_listp(t2))){
t3=C_i_car(t2);
t4=t3;
t5=C_i_cadr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16100,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16104,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_i_string_length(t4);
t10=C_a_i_fixnum_difference(&a,2,C_fix(4),t9);
/* support.scm:1460: scheme#max */
t11=*((C_word*)lf[466]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t11;
av2[1]=t8;
av2[2]=C_fix(0);
av2[3]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
/* support.scm:1461: chicken.string#->string */
t3=*((C_word*)lf[68]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k16098 in chicken.compiler.support#source-info->string in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,6)))){
C_save_and_reclaim((void *)f_16100,2,av);}
/* support.scm:1460: chicken.string#conc */
t2=*((C_word*)lf[462]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[463];
av2[4]=t1;
av2[5]=lf[464];
av2[6]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k16102 in chicken.compiler.support#source-info->string in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16104(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16104,2,av);}
/* support.scm:1460: scheme#make-string */
t2=*((C_word*)lf[465]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* chicken.compiler.support#source-info->name in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_16115,3,av);}
if(C_truep(C_i_listp(t2))){
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_i_cadr(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* support.scm:1464: chicken.string#->string */
t3=*((C_word*)lf[68]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* chicken.compiler.support#source-info->line in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16130,3,av);}
t3=C_i_listp(t2);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=(C_truep(t3)?C_i_car(t2):C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#call-info in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_16142,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16146,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(t2);
if(C_truep(C_i_pairp(t5))){
t6=t2;
t7=t4;
f_16146(t7,C_i_cadr(t6));}
else{
t6=t4;
f_16146(t6,C_SCHEME_FALSE);}}

/* k16144 in chicken.compiler.support#call-info in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_16146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,5)))){
C_save_and_reclaim_args((void *)trf_16146,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
if(C_truep(C_i_listp(t1))){
t3=C_i_car(t1);
t4=C_i_cadr(t1);
/* support.scm:1474: chicken.string#conc */
t5=*((C_word*)lf[462]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[470];
av2[3]=t3;
av2[4]=lf[471];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k16147 in k16144 in chicken.compiler.support#call-info in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16149(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16149,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16179(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,3)))){
C_save_and_reclaim((void *)f_16179,5,av);}
a=C_alloc(17);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=C_i_check_list_2(t3,lf[127]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16203,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16375,a[2]=t7,a[3]=t12,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_16375(t14,t10,t3);}

/* k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16203(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_16203,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(t2,lf[127]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16341,a[2]=t5,a[3]=t10,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_16341(t12,t8,t2);}

/* k16216 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_16218,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1486: g4016 */
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k16219 in k16216 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16221(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_16221,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1487: chicken.condition#condition? */
t4=*((C_word*)lf[476]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k16225 in k16219 in k16216 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_16227,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
/* support.scm:1487: k */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_FALSE;
av2[3]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16236,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_length(((C_word*)t0)[4]);
t4=C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[4]);
/* support.scm:1489: encodeable-literal? */
t6=lf[475];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=t5;
f_16508(3,av2);}}
else{
t5=t2;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_16236(2,av2);}}}}

/* k16234 in k16225 in k16219 in k16216 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_16236,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1490: debugging */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[191];
av2[3]=lf[473];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=C_u_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
/* support.scm:1493: k */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_FALSE;
av2[3]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
/* support.scm:1495: bomb */
t4=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[474];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}}

/* k16237 in k16234 in k16225 in k16219 in k16216 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16239(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16239,2,av);}
t2=C_i_car(((C_word*)t0)[2]);
/* support.scm:1491: k */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_TRUE;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a16277 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_16278,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16284,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1486: chicken.condition#with-exception-handler */
t5=*((C_word*)lf[108]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a16283 in a16277 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_16284,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16290,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1486: k4013 */
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a16289 in a16283 in a16277 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16290,2,av);}
t2=t1;{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a16292 in a16277 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_16293,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16311,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1486: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a16298 in a16292 in a16277 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_16299,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1486: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=*((C_word*)lf[477]+1);
C_call_with_values(4,av2);}}

/* a16304 in a16298 in a16292 in a16277 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16305(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16305,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
C_apply(4,av2);}}

/* a16310 in a16292 in a16277 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16311(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2)))){
C_save_and_reclaim((void*)f_16311,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16317,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1486: k4013 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a16316 in a16310 in a16292 in a16277 in k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_16317,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k16337 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16339(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_16339,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_slot(((C_word*)t0)[2],C_fix(0));
t5=t4;
if(C_truep(C_i_closurep(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16218,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16278,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1486: scheme#call-with-current-continuation */
t8=*((C_word*)lf[109]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
/* support.scm:1496: bomb */
t6=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[478];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* map-loop3983 in k16201 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_16341(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_16341,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,lf[87],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop3952 in chicken.compiler.support#constant-form-eval in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_16375(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_16375,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t11=t1;
t12=t9;
t1=t11;
t2=t12;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.compiler.support#maybe-constant-fold-call in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,4)))){
C_save_and_reclaim((void *)f_16409,5,av);}
a=C_alloc(14);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16412,tmp=(C_word)a,a+=2,tmp);
t6=C_i_car(t3);
t7=C_slot(t6,C_fix(1));
t8=C_eqp(lf[156],t7);
if(C_truep(t8)){
t9=t3;
t10=C_u_i_car(t9);
t11=C_slot(t10,C_fix(2));
t12=C_i_car(t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16440,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16462,a[2]=t3,a[3]=t14,a[4]=t5,a[5]=t13,tmp=(C_word)a,a+=6,tmp);
/* tweaks.scm:51: ##sys#get */
t16=*((C_word*)lf[183]+1);{
C_word *av2=av;
av2[0]=t16;
av2[1]=t15;
av2[2]=t13;
av2[3]=lf[482];
((C_proc)(void*)(*((C_word*)t16+1)))(4,av2);}}
else{
/* support.scm:1508: k */
t9=t4;{
C_word *av2=av;
av2[0]=t9;
av2[1]=t1;
av2[2]=C_SCHEME_FALSE;
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}}

/* constant-node? in chicken.compiler.support#maybe-constant-fold-call in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16412(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16412,3,av);}
t3=C_slot(t2,C_fix(1));
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_eqp(lf[87],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k16438 in chicken.compiler.support#maybe-constant-fold-call in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16440(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_16440,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16447,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1506: constant-form-eval */
t5=*((C_word*)lf[472]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=t3;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
/* support.scm:1507: k */
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_FALSE;
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* a16446 in k16438 in chicken.compiler.support#maybe-constant-fold-call in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_16447,4,av);}
/* support.scm:1506: k */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k16460 in chicken.compiler.support#maybe-constant-fold-call in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_16462,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1503: foldable? */
t3=*((C_word*)lf[481]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_16440(2,av2);}}}

/* k16466 in k16460 in chicken.compiler.support#maybe-constant-fold-call in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_16468,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=t1;
f_16471(2,av2);}}
else{
/* support.scm:1504: predicate? */
t3=*((C_word*)lf[480]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k16469 in k16466 in k16460 in chicken.compiler.support#maybe-constant-fold-call in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16471(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16471,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:1505: every */
f_5510(((C_word*)t0)[3],((C_word*)t0)[4],t3);}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_16440(2,av2);}}}

/* chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_16508,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16523,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1518: immediate? */
t4=*((C_word*)lf[91]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_16523,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
if(C_truep(C_i_exact_integerp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16533,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16548,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1523: scheme#call-with-current-continuation */
t5=*((C_word*)lf[109]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_i_flonump(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t4=C_slot(((C_word*)t0)[3],C_fix(1));
t5=C_i_string_length(t4);
t6=((C_word*)t0)[2];
t7=C_i_integer_length(t5);
t8=t6;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_fixnum_less_or_equal_p(t7,C_fix(24));
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
if(C_truep(C_byteblockp(((C_word*)t0)[3]))){
t4=((C_word*)t0)[3];
t5=stub4065(C_SCHEME_UNDEFINED,t4);
t6=((C_word*)t0)[2];
t7=C_i_integer_length(t5);
t8=t6;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_fixnum_less_or_equal_p(t7,C_fix(24));
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t4=((C_word*)t0)[3];
t5=stub4065(C_SCHEME_UNDEFINED,t4);
t6=C_i_integer_length(t5);
if(C_truep(C_fixnum_less_or_equal_p(t6,C_fix(24)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16639,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t9=t5;
t10=t8;
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6158,a[2]=t9,a[3]=t12,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_6158(t14,t7,C_fix(0));}
else{
t7=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}}}}}}

/* k16531 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_16533,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16536,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1523: g4074 */
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k16534 in k16531 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16536(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16536,2,av);}
if(C_truep(t1)){
t2=C_i_string_length(t1);
t3=((C_word*)t0)[2];
t4=C_i_integer_length(t2);
t5=t3;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_fixnum_less_or_equal_p(t4,C_fix(24));
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a16547 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16548(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_16548,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16554,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16563,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1523: chicken.condition#with-exception-handler */
t5=*((C_word*)lf[108]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a16553 in a16547 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16554(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,2)))){
C_save_and_reclaim((void *)f_16554,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16560,tmp=(C_word)a,a+=2,tmp);
/* support.scm:1523: k4071 */
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a16559 in a16553 in a16547 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16560(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16560,2,av);}
t2=t1;{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a16562 in a16547 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_16563,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16565,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16572,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16589,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tmp15102 */
t5=t2;
f_16565(t5,t4);}

/* tmp15102 in a16562 in a16547 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_16565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_16565,2,t0,t1);}
t2=((C_word*)t0)[2];
/* ##sys#number->string */
t3=*((C_word*)lf[483]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(16);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* tmp25103 in a16562 in a16547 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_16572(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_16572,3,t0,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16578,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1523: k4071 */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a16577 in tmp25103 in a16562 in a16547 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16578(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_16578,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k16587 in a16562 in a16547 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_16589,2,av);}
a=C_alloc(3);
/* tmp25103 */
t2=((C_word*)t0)[2];
f_16572(t2,((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* k16635 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16637,2,av);}
/* support.scm:1534: every */
f_5510(((C_word*)t0)[2],lf[475],t1);}

/* a16638 in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16639,3,av);}
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[2],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16645(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_16645,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16649,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16654,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_16654(t7,t3,C_fix(0),t2);}

/* k16647 in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16649,2,av);}
/* support.scm:1559: scheme#newline */
t2=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_16654(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_16654,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=t3;
t5=C_slot(t4,C_fix(1));
t6=t5;
t7=t3;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t3;
t11=C_slot(t10,C_fix(3));
t12=t11;
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16682,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t12,a[5]=t3,a[6]=t1,a[7]=t9,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* support.scm:1547: scheme#make-string */
t14=*((C_word*)lf[465]+1);{
C_word av2[4];
av2[0]=t14;
av2[1]=t13;
av2[2]=t2;
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}

/* k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16682(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,3)))){
C_save_and_reclaim((void *)f_16682,2,av);}
a=C_alloc(16);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_a_i_fixnum_plus(&a,2,t3,C_fix(2));
t5=*((C_word*)lf[24]+1);
t6=*((C_word*)lf[24]+1);
t7=C_i_check_port_2(*((C_word*)lf[24]+1),C_fix(2),C_SCHEME_TRUE,lf[25]);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_16690,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t5,a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* support.scm:1549: ##sys#write-char-0 */
t9=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[24]+1);
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}

/* k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_16690,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_16693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:1549: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[10];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_16693,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_16696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:1549: ##sys#write-char-0 */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(60);
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_16696,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:1549: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_16699,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:1549: ##sys#write-char-0 */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_16702,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1549: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_16705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_16705,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(((C_word*)t0)[4],lf[44]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16716,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16778,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_16778(t8,t4,((C_word*)t0)[4]);}

/* g4114 in k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in ... */
static void C_fcall f_16706(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_16706,3,t0,t1,t2);}
/* support.scm:1550: g4136 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_16654(t3,t1,((C_word*)t0)[3],t2);}

/* k16714 in k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in ... */
static void C_ccall f_16716(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_16716,2,av);}
a=C_alloc(9);
t2=C_block_size(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16722,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_greaterp(t3,C_fix(4)))){
t5=*((C_word*)lf[24]+1);
t6=*((C_word*)lf[24]+1);
t7=C_i_check_port_2(*((C_word*)lf[24]+1),C_fix(2),C_SCHEME_TRUE,lf[25]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16734,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1553: ##sys#write-char-0 */
t9=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=C_make_character(91);
av2[3]=*((C_word*)lf[24]+1);
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
/* ##sys#write-char/port */
t5=*((C_word*)lf[485]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(62);
av2[3]=*((C_word*)lf[24]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k16720 in k16714 in k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in ... */
static void C_ccall f_16722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16722,2,av);}
/* ##sys#write-char/port */
t2=*((C_word*)lf[485]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(62);
av2[3]=*((C_word*)lf[24]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k16732 in k16714 in k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in ... */
static void C_ccall f_16734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_16734,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[4],C_fix(4));
/* support.scm:1553: ##sys#print */
t4=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k16735 in k16732 in k16714 in k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in ... */
static void C_ccall f_16737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_16737,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16740,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16745,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_16745(t6,t2,C_fix(5));}

/* k16738 in k16735 in k16732 in k16714 in k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in ... */
static void C_ccall f_16740(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16740,2,av);}
/* ##sys#write-char/port */
t2=*((C_word*)lf[485]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(93);
av2[3]=*((C_word*)lf[24]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* doloop4150 in k16735 in k16732 in k16714 in k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in ... */
static void C_fcall f_16745(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_16745,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=*((C_word*)lf[24]+1);
t4=*((C_word*)lf[24]+1);
t5=C_i_check_port_2(*((C_word*)lf[24]+1),C_fix(2),C_SCHEME_TRUE,lf[25]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16758,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:1556: ##sys#write-char-0 */
t7=*((C_word*)lf[26]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=C_make_character(32);
av2[3]=*((C_word*)lf[24]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}

/* k16756 in doloop4150 in k16735 in k16732 in k16714 in k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in ... */
static void C_ccall f_16758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_16758,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[5],((C_word*)t0)[2]);
/* support.scm:1556: ##sys#print */
t4=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k16759 in k16756 in doloop4150 in k16735 in k16732 in k16714 in k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in ... */
static void C_ccall f_16761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_16761,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_16745(t3,((C_word*)t0)[4],t2);}

/* for-each-loop4113 in k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in ... */
static void C_fcall f_16778(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_16778,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16788,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1550: g4114 */
t5=((C_word*)t0)[3];
f_16706(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k16786 in for-each-loop4113 in k16703 in k16700 in k16697 in k16694 in k16691 in k16688 in k16680 in loop in chicken.compiler.support#dump-nodes in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in ... */
static void C_ccall f_16788(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_16788,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_16778(t3,((C_word*)t0)[4],t2);}

/* chicken.compiler.support#read-info-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16801(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_16801,5,av);}
a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16805,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16808,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_eqp(lf[489],t2);
if(C_truep(t7)){
t8=C_i_car(t3);
t9=t6;
f_16808(t9,C_i_symbolp(t8));}
else{
t8=t6;
f_16808(t8,C_SCHEME_FALSE);}}

/* k16803 in chicken.compiler.support#read-info-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16805(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16805,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k16806 in chicken.compiler.support#read-info-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_16808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_16808,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1570: chicken.string#conc */
t5=*((C_word*)lf[462]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[487]+1);
av2[3]=lf[488];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k16821 in k16806 in chicken.compiler.support#read-info-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_16823,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16827,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
/* support.scm:1571: chicken.internal#hash-table-ref */
t6=*((C_word*)lf[130]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=*((C_word*)lf[138]+1);
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k16825 in k16821 in k16806 in chicken.compiler.support#read-info-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_16827,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t4,t2);
/* support.scm:1566: chicken.internal#hash-table-set! */
t6=*((C_word*)lf[134]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[4];
av2[2]=*((C_word*)lf[138]+1);
av2[3]=((C_word*)t0)[5];
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=((C_word*)t0)[2];
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* support.scm:1566: chicken.internal#hash-table-set! */
t5=*((C_word*)lf[134]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[4];
av2[2]=*((C_word*)lf[138]+1);
av2[3]=((C_word*)t0)[5];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* chicken.compiler.support#read/source-info in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16844(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_16844,3,av);}
/* support.scm:1576: ##sys#read */
t3=*((C_word*)lf[491]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=*((C_word*)lf[486]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* ##sys#user-read-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_16850,4,av);}
a=C_alloc(4);
if(C_truep(C_i_char_equalp(C_make_character(62),t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16860,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#read-char/port */
t5=*((C_word*)lf[496]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* support.scm:1588: old-hook */
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k16858 in ##sys#user-read-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_16860,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=t2;
t4=((C_word*)t0)[3];
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16879,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1591: chicken.base#open-output-string */
t6=*((C_word*)lf[319]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k16861 in k16858 in ##sys#user-read-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,1)))){
C_save_and_reclaim((void *)f_16863,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,2,lf[493],t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[494],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k16877 in k16858 in ##sys#user-read-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16879(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_16879,2,av);}
a=C_alloc(7);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16884,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_16884(t6,((C_word*)t0)[3]);}

/* loop in k16877 in k16858 in ##sys#user-read-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_16884(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_16884,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16888,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#read-char/port */
t3=*((C_word*)lf[496]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k16886 in loop in k16877 in k16858 in ##sys#user-read-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_16888,2,av);}
a=C_alloc(5);
if(C_truep(C_eofp(t1))){
/* support.scm:1595: quit-compiling */
t2=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[495];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
if(C_truep(C_u_i_char_equalp(t1,C_make_character(10)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1597: scheme#newline */
t3=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
if(C_truep(C_u_i_char_equalp(t1,C_make_character(60)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#read-char/port */
t3=*((C_word*)lf[496]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#write-char/port */
t3=*((C_word*)lf[485]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}}}

/* k16903 in k16886 in loop in k16877 in k16858 in ##sys#user-read-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16905,2,av);}
/* support.scm:1598: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_16884(t2,((C_word*)t0)[3]);}

/* k16914 in k16886 in loop in k16877 in k16858 in ##sys#user-read-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_16916,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_eqp(C_make_character(35),t2);
if(C_truep(t3)){
/* support.scm:1602: chicken.base#get-output-string */
t4=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16928,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#write-char/port */
t5=*((C_word*)lf[485]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_make_character(60);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k16926 in k16914 in k16886 in loop in k16877 in k16858 in ##sys#user-read-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16928(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_16928,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#write-char/port */
t3=*((C_word*)lf[485]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k16929 in k16926 in k16914 in k16886 in loop in k16877 in k16858 in ##sys#user-read-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16931(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16931,2,av);}
/* support.scm:1606: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_16884(t2,((C_word*)t0)[3]);}

/* k16937 in k16886 in loop in k16877 in k16858 in ##sys#user-read-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16939(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16939,2,av);}
/* support.scm:1609: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_16884(t2,((C_word*)t0)[3]);}

/* chicken.compiler.support#big-fixnum? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_16944,3,av);}
a=C_alloc(4);
if(C_truep(C_fixnump(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16957,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1616: chicken.platform#feature? */
t4=*((C_word*)lf[497]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[498];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k16955 in chicken.compiler.support#big-fixnum? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16957(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16957,2,av);}
if(C_truep(t1)){
t2=C_fixnum_greaterp(((C_word*)t0)[2],C_fix(1073741823));
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=(C_truep(t2)?t2:C_fixnum_lessp(((C_word*)t0)[2],C_fix(-1073741824)));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* chicken.compiler.support#small-bignum? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16968(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_16968,3,av);}
a=C_alloc(4);
if(C_truep(C_i_bignump(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16990,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1622: chicken.platform#feature? */
t4=*((C_word*)lf[497]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[498];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k16988 in chicken.compiler.support#small-bignum? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_16990,2,av);}
if(C_truep(C_i_not(t1))){
t2=((C_word*)t0)[2];
t3=C_i_integer_length(t2);
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_fixnum_less_or_equal_p(t3,C_fix(62));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* chicken.compiler.support#hide-variable in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_16992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_16992,3,av);}
a=C_alloc(3);
t3=C_a_i_list(&a,1,lf[500]);
if(C_truep(C_i_nullp(t3))){
/* tweaks.scm:57: ##sys#put! */
t4=*((C_word*)lf[246]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[265];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=C_i_car(t3);
/* tweaks.scm:57: ##sys#put! */
t5=*((C_word*)lf[246]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[265];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* chicken.compiler.support#export-variable in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_17012,3,av);}
a=C_alloc(3);
t3=C_a_i_list(&a,1,lf[502]);
if(C_truep(C_i_nullp(t3))){
/* tweaks.scm:57: ##sys#put! */
t4=*((C_word*)lf[246]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[265];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=C_i_car(t3);
/* tweaks.scm:57: ##sys#put! */
t5=*((C_word*)lf[246]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[265];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* chicken.compiler.support#variable-hidden? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17032(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_17032,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17040,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1635: ##sys#get */
t4=*((C_word*)lf[183]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[265];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k17038 in chicken.compiler.support#variable-hidden? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_17040,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_eqp(t1,lf[500]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k17047 in ##sys#toplevel-definition-hook in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_17049,2,av);}
if(C_truep(t1)){
/* support.scm:1638: chicken.plist#remprop! */
t2=*((C_word*)lf[264]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[265];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.compiler.support#variable-visible? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17054(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_17054,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17058,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1641: ##sys#get */
t5=*((C_word*)lf[183]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=lf[265];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k17056 in chicken.compiler.support#variable-visible? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_17058,2,av);}
t2=C_eqp(t1,lf[500]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(t1,lf[502]);
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=(C_truep(t3)?C_SCHEME_TRUE:C_i_not(((C_word*)t0)[3]));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* chicken.compiler.support#mark-variable in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +0,c,4)))){
C_save_and_reclaim((void*)f_17079,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+0);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* support.scm:1651: ##sys#put! */
t5=*((C_word*)lf[246]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t5=C_i_car(t4);
/* support.scm:1651: ##sys#put! */
t6=*((C_word*)lf[246]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}

/* chicken.compiler.support#variable-mark in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17094(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_17094,4,av);}
/* support.scm:1654: ##sys#get */
t4=*((C_word*)lf[183]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* chicken.compiler.support#intrinsic? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_17100,3,av);}
/* tweaks.scm:60: ##sys#get */
t3=*((C_word*)lf[183]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[482];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* chicken.compiler.support#foldable? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_17111,3,av);}
/* tweaks.scm:60: ##sys#get */
t3=*((C_word*)lf[183]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[506];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* chicken.compiler.support#predicate? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17122(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_17122,3,av);}
/* tweaks.scm:60: ##sys#get */
t3=*((C_word*)lf[183]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[507];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_17133,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17137,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17226,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1665: chicken.platform#repository-path */
t5=*((C_word*)lf[515]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17137(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_17137,2,av);}
a=C_alloc(8);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17143,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17204,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1666: chicken.base#open-output-string */
t5=*((C_word*)lf[319]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k17141 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17143(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_17143,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17171,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1673: scheme#call-with-input-file */
t3=*((C_word*)lf[510]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=*((C_word*)lf[84]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k17153 in for-each-loop4326 in k17169 in k17141 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17155(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_17155,2,av);}
/* support.scm:1670: ##sys#put! */
t2=*((C_word*)lf[246]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[509];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k17157 in for-each-loop4326 in k17169 in k17141 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17159(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_17159,2,av);}
a=C_alloc(3);
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_list1(&a,1,t3);
/* support.scm:1672: scheme#append */
t5=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k17169 in k17141 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_17171,2,av);}
a=C_alloc(5);
t2=C_i_check_list_2(t1,lf[44]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17179,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_17179(t6,((C_word*)t0)[2],t1);}

/* for-each-loop4326 in k17169 in k17141 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_17179(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,3)))){
C_save_and_reclaim_args((void *)trf_17179,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17189,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17155,a[2]=t5,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17159,a[2]=t6,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1672: ##sys#get */
t11=*((C_word*)lf[183]+1);{
C_word av2[4];
av2[0]=t11;
av2[1]=t10;
av2[2]=t8;
av2[3]=lf[509];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k17187 in for-each-loop4326 in k17169 in k17141 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_17189,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_17179(t3,((C_word*)t0)[4],t2);}

/* k17202 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17204(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_17204,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_fix(2),C_SCHEME_TRUE,lf[313]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17210,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1666: ##sys#print */
t6=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[513];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k17208 in k17202 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_17210,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1666: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k17211 in k17208 in k17202 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17213(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_17213,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1666: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[512];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k17214 in k17211 in k17208 in k17202 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17216(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_17216,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1666: ##sys#write-char-0 */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k17217 in k17214 in k17211 in k17208 in k17202 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17219(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_17219,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17222,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1666: chicken.base#get-output-string */
t3=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k17220 in k17217 in k17214 in k17211 in k17208 in k17202 in k17135 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_17222,2,av);}
/* support.scm:1666: debugging */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[511];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k17224 in chicken.compiler.support#load-identifier-database in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17226(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_17226,2,av);}
/* support.scm:1665: chicken.load#find-file */
t2=*((C_word*)lf[514]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* chicken.compiler.support#print-version in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +6,c,2)))){
C_save_and_reclaim((void*)f_17228,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+6);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17235,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t4)){
/* support.scm:1679: chicken.base#print* */
t6=*((C_word*)lf[517]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[518];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f18834,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1680: chicken.platform#chicken-version */
t7=*((C_word*)lf[233]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}

/* k17233 in chicken.compiler.support#print-version in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17235(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_17235,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17242,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1680: chicken.platform#chicken-version */
t3=*((C_word*)lf[233]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k17240 in k17233 in chicken.compiler.support#print-version in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_17242,2,av);}
/* support.scm:1680: chicken.base#print */
t2=*((C_word*)lf[220]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* chicken.compiler.support#print-usage in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_17253,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17257,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1685: print-version */
t3=*((C_word*)lf[516]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k17255 in chicken.compiler.support#print-usage in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17257(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_17257,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17260,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1686: scheme#newline */
t3=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k17258 in k17255 in chicken.compiler.support#print-usage in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17260(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_17260,2,av);}
/* support.scm:1687: scheme#display */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[520];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* chicken.compiler.support#print-debug-options in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17265(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_17265,2,av);}
/* support.scm:1816: scheme#display */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[522];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a17270 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17271(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_17271,4,av);}
a=C_alloc(5);
t4=t3;
t5=C_i_check_port_2(t4,C_fix(2),C_SCHEME_TRUE,lf[32]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17278,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:483: ##sys#print */
t7=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[523];
av2[3]=C_SCHEME_FALSE;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k17276 in a17270 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_17278,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(1));
/* support.scm:483: ##sys#print */
t5=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k17279 in k17276 in a17270 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17281(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_17281,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:483: ##sys#write-char-0 */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k17282 in k17279 in k17276 in a17270 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_17284,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
/* support.scm:483: ##sys#print */
t5=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k17285 in k17282 in k17279 in k17276 in a17270 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_17287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_17287,2,av);}
/* support.scm:483: ##sys#write-char-0 */
t2=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(62);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5113 */
static void C_ccall f_5115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5115,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k5116 in k5113 */
static void C_ccall f_5118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5118,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5121,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_expand_toplevel(2,av2);}}

/* k5119 in k5116 in k5113 */
static void C_ccall f_5121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5121,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_data_2dstructures_toplevel(2,av2);}}

/* k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5124(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5124,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5127,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_file_toplevel(2,av2);}}

/* k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5130,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_internal_toplevel(2,av2);}}

/* k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5133,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_pathname_toplevel(2,av2);}}

/* k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5136,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_port_toplevel(2,av2);}}

/* k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(35,c,4)))){
C_save_and_reclaim((void *)f_5139,2,av);}
a=C_alloc(35);
t2=C_a_i_provide(&a,1,lf[0]);
t3=C_a_i_provide(&a,1,lf[1]);
t4=C_mutate(&lf[2] /* (set! chicken.compiler.support#take ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5249,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[3] /* (set! chicken.compiler.support#every ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5510,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[4] /* (set! chicken.compiler.support#any ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5544,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[5] /* (set! chicken.compiler.support#cons* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5574,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[6] /* (set! chicken.compiler.support#last ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5910,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[7] /* (set! chicken.compiler.support#lset-adjoin/eq? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5969,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[8]+1 /* (set! chicken.compiler.support#number-type ...) */,lf[9]);
t11=C_set_block_item(lf[10] /* chicken.compiler.support#unsafe */,0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[11]+1 /* (set! chicken.compiler.support#compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6422,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[12] /* chicken.compiler.support#debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t14=C_mutate((C_word*)lf[13]+1 /* (set! chicken.compiler.support#bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6426,tmp=(C_word)a,a+=2,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:121: chicken.base#open-output-string */
t16=*((C_word*)lf[319]+1);{
C_word *av2=av;
av2[0]=t16;
av2[1]=t15;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}

/* chicken.compiler.support#take in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5249(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_5249,3,t1,t2,t3);}
a=C_alloc(4);
if(C_truep(C_fixnum_less_or_equal_p(t3,C_fix(0)))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5267,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_fixnum_difference(t3,C_fix(1));
/* mini-srfi-1.scm:56: take */
t11=t6;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k5265 in chicken.compiler.support#take in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5267(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_5267,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in a10426 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5307(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,4)))){
C_save_and_reclaim_args((void *)trf_5307,5,t0,t1,t2,t3,t4);}
a=C_alloc(4);
if(C_truep(C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5321,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* mini-srfi-1.scm:67: scheme#reverse */
t6=*((C_word*)lf[82]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=C_fixnum_difference(t2,C_fix(1));
t6=C_i_car(t4);
t7=C_a_i_cons(&a,2,t6,t3);
t8=t4;
t9=C_u_i_cdr(t8);
/* mini-srfi-1.scm:68: loop */
t11=t1;
t12=t5;
t13=t7;
t14=t9;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}

/* k5319 in loop in a10426 in a10420 in chicken.compiler.support#inline-lambda-bindings in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5321,2,av);}
/* mini-srfi-1.scm:67: scheme#values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
C_values(4,av2);}}

/* chicken.compiler.support#every in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5510(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_5510,3,t1,t2,t3);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5516,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5516(t7,t1,t3);}

/* loop in chicken.compiler.support#every in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5516(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_5516,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5538,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(t2);
/* mini-srfi-1.scm:82: pred */
t6=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k5536 in loop in chicken.compiler.support#every in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5538(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5538,2,av);}
if(C_truep(C_i_not(t1))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* mini-srfi-1.scm:83: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5516(t4,((C_word*)t0)[2],t3);}}

/* chicken.compiler.support#any in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5544(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_5544,3,t1,t2,t3);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5550,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5550(t7,t1,t3);}

/* loop in chicken.compiler.support#any in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5550(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_5550,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5560,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* mini-srfi-1.scm:88: pred */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k5558 in loop in chicken.compiler.support#any in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5560(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5560,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* mini-srfi-1.scm:89: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5550(t4,((C_word*)t0)[2],t3);}}

/* chicken.compiler.support#cons* in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5574(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_5574,3,t1,t2,t3);}
a=C_alloc(5);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5580,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5580(t7,t1,t2,t3);}

/* loop in chicken.compiler.support#cons* in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5580(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_5580,4,t0,t1,t2,t3);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5594,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(t3);
t6=t3;
t7=C_u_i_cdr(t6);
/* mini-srfi-1.scm:95: loop */
t9=t4;
t10=t5;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k5592 in loop in chicken.compiler.support#cons* in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_5594,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* foldr389 in k7946 in chicken.compiler.support#db-get-all in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5803(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_5803,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5811,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5837,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g394 in foldr389 in k7946 in chicken.compiler.support#db-get-all in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5811(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_5811,4,t0,t1,t2,t3);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5815,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* mini-srfi-1.scm:135: pred */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5813 in g394 in foldr389 in k7946 in chicken.compiler.support#db-get-all in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5815,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* mini-srfi-1.scm:135: g404 */
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=(
/* mini-srfi-1.scm:135: g404 */
  f_5819(C_a_i(&a,3),t2,t1)
);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g404 in k5813 in g394 in foldr389 in k7946 in chicken.compiler.support#db-get-all in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static C_word C_fcall f_5819(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5835 in foldr389 in k7946 in chicken.compiler.support#db-get-all in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_5837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5837,2,av);}
/* mini-srfi-1.scm:134: g394 */
t2=((C_word*)t0)[2];
f_5811(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* map-loop417 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5876(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_5876,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.compiler.support#last in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5910(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,0,2)))){
C_save_and_reclaim_args((void *)trf_5910,2,t1,t2);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5916,tmp=(C_word)a,a+=2,tmp);
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=(
  f_5916(t2)
);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* loop in chicken.compiler.support#last in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static C_word C_fcall f_5916(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:{}
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=t1;
t4=C_u_i_car(t3);
return(t4);}
else{
t3=t1;
t4=C_u_i_cdr(t3);
t6=t4;
t1=t6;
goto loop;}}

/* chicken.compiler.support#lset-adjoin/eq? in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5969(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_5969,3,t1,t2,t3);}
a=C_alloc(5);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5975,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5975(t7,t1,t3,t2);}

/* loop in chicken.compiler.support#lset-adjoin/eq? in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_5975(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,3)))){
C_save_and_reclaim_args((void *)trf_5975,4,t0,t1,t2,t3);}
a=C_alloc(3);
if(C_truep(C_i_nullp(t2))){
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_i_car(t2);
if(C_truep(C_i_memq(t4,t3))){
t5=t2;
t6=C_u_i_cdr(t5);
/* mini-srfi-1.scm:160: loop */
t11=t1;
t12=t6;
t13=t3;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t5=t2;
t6=C_u_i_cdr(t5);
t7=t2;
t8=C_u_i_car(t7);
t9=C_a_i_cons(&a,2,t8,t3);
/* mini-srfi-1.scm:161: loop */
t11=t1;
t12=t6;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6158(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6158,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6172,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* mini-srfi-1.scm:190: proc */
t4=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k6170 in loop in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6172(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6172,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6176,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* mini-srfi-1.scm:190: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6158(t5,t3,t4);}

/* k6174 in k6170 in loop in k16521 in chicken.compiler.support#encodeable-literal? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6176(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_6176,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k11940 in walk in chicken.compiler.support#expression-has-side-effects? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6271(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6271,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6284,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* mini-srfi-1.scm:216: pred */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k6282 in loop in k11940 in walk in chicken.compiler.support#expression-has-side-effects? in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6284,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_u_i_car(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* mini-srfi-1.scm:217: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_6271(t4,((C_word*)t0)[3],t3);}}

/* chicken.compiler.support#compiler-cleanup-hook in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6422,2,av);}
t2=t1;{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* chicken.compiler.support#bomb in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6426(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,3)))){
C_save_and_reclaim((void*)f_6426,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6440,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* support.scm:117: scheme#string-append */
t6=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=lf[16];
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
/* support.scm:118: chicken.base#error */
t3=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[17];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k6438 in chicken.compiler.support#bomb in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6440(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6440,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=*((C_word*)lf[14]+1);
av2[3]=t1;
av2[4]=t3;
C_apply(5,av2);}}

/* k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(47,c,5)))){
C_save_and_reclaim((void *)f_6451,2,av);}
a=C_alloc(47);
t2=C_mutate((C_word*)lf[18]+1 /* (set! chicken.compiler.support#collected-debugging-output ...) */,t1);
t3=C_mutate(&lf[19] /* (set! chicken.compiler.support#+logged-debugging-modes+ ...) */,lf[20]);
t4=C_mutate(&lf[21] /* (set! chicken.compiler.support#test-debugging-mode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6454,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[22]+1 /* (set! chicken.compiler.support#debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6475,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[34]+1 /* (set! chicken.compiler.support#with-debugging-output ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6595,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[37]+1 /* (set! chicken.compiler.support#quit-compiling ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6692,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[42]+1 /* (set! ##sys#syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6708,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[51]+1 /* (set! chicken.syntax#syntax-error ...) */,*((C_word*)lf[42]+1));
t10=C_mutate((C_word*)lf[52]+1 /* (set! chicken.compiler.support#emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6805,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[53]+1 /* (set! chicken.compiler.support#check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6859,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[56]+1 /* (set! chicken.compiler.support#build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6927,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[57]+1 /* (set! chicken.compiler.support#c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6964,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[67]+1 /* (set! chicken.compiler.support#valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7063,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[69]+1 /* (set! chicken.compiler.support#bytes->words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7113,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[70]+1 /* (set! chicken.compiler.support#words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7120,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[71]+1 /* (set! chicken.compiler.support#check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7127,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[78]+1 /* (set! chicken.compiler.support#close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7171,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[81]+1 /* (set! chicken.compiler.support#fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7183,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[83] /* (set! chicken.compiler.support#follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7239,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[84]+1 /* (set! chicken.compiler.support#read-expressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7290,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[86]+1 /* (set! chicken.compiler.support#constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7334,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[90]+1 /* (set! chicken.compiler.support#collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7396,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[91]+1 /* (set! chicken.compiler.support#immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7426,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[93]+1 /* (set! chicken.compiler.support#basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7472,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[95]+1 /* (set! chicken.compiler.support#canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7528,tmp=(C_word)a,a+=2,tmp));
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7603,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:351: chicken.condition#condition-predicate */
t28=*((C_word*)lf[528]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t28;
av2[1]=t27;
av2[2]=lf[526];
((C_proc)(void*)(*((C_word*)t28+1)))(3,av2);}}

/* chicken.compiler.support#test-debugging-mode in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6454(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,3)))){
C_save_and_reclaim_args((void *)trf_6454,3,t1,t2,t3);}
a=C_alloc(3);
if(C_truep(C_i_symbolp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_memq(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6469,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:128: any */
f_5544(t1,t4,t2);}}

/* a6468 in chicken.compiler.support#test-debugging-mode in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6469,3,av);}
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_i_memq(t2,((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6475(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +17,c,3)))){
C_save_and_reclaim((void*)f_6475,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+17);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6478,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6543,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6562,a[2]=t1,a[3]=t8,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* support.scm:143: test-debugging-mode */
f_6454(t11,t2,*((C_word*)lf[12]+1));}

/* text in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_6478,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:132: chicken.port#with-output-to-string */
t3=*((C_word*)lf[31]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* a6483 in text in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6484(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6484,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6488,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:134: scheme#display */
t3=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6486 in a6483 in text in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6488(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_6488,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6491,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6500,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:136: scheme#display */
t4=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[30];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* support.scm:140: scheme#newline */
t3=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6489 in k6486 in a6483 in text in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6491(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6491,2,av);}
/* support.scm:140: scheme#newline */
t2=*((C_word*)lf[23]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6498 in k6486 in a6483 in text in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6500(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6500,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6520,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6520(t6,((C_word*)t0)[3],t2);}

/* k6506 in for-each-loop685 in k6498 in k6486 in a6483 in text in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6508,2,av);}
/* support.scm:138: ##sys#write-char-0 */
t2=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6513 in for-each-loop685 in k6498 in k6486 in a6483 in text in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6515,2,av);}
/* support.scm:138: ##sys#print */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* for-each-loop685 in k6498 in k6486 in a6483 in text in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6520(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,2)))){
C_save_and_reclaim_args((void *)trf_6520,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6530,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=*((C_word*)lf[24]+1);
t7=*((C_word*)lf[24]+1);
t8=C_i_check_port_2(*((C_word*)lf[24]+1),C_fix(2),C_SCHEME_TRUE,lf[25]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6508,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6515,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm:138: scheme#force */
t11=*((C_word*)lf[28]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t10;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6528 in for-each-loop685 in k6498 in k6486 in a6483 in text in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6530(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6530,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6520(t3,((C_word*)t0)[4],t2);}

/* dump in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6543(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_6543,3,t0,t1,t2);}
a=C_alloc(5);
t3=*((C_word*)lf[18]+1);
t4=*((C_word*)lf[18]+1);
t5=C_i_check_port_2(*((C_word*)lf[18]+1),C_fix(2),C_SCHEME_TRUE,lf[32]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6550,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:142: ##sys#print */
t7=*((C_word*)lf[27]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[2];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[18]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k6548 in dump in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6550(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6550,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:142: ##sys#write-char-0 */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(124);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6551 in k6548 in dump in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6553,2,av);}
/* support.scm:142: ##sys#print */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6560 in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_6562,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:144: text */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6478(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6583,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6586,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* support.scm:151: test-debugging-mode */
f_6454(t3,((C_word*)t0)[4],lf[19]);}}

/* k6563 in k6560 in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6565(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6565,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:145: scheme#display */
t4=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6566 in k6563 in k6560 in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6568(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6568,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:146: chicken.base#flush-output */
t3=*((C_word*)lf[33]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6569 in k6566 in k6563 in k6560 in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6571(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_6571,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6574,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6577,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* support.scm:147: test-debugging-mode */
f_6454(t3,((C_word*)t0)[5],lf[19]);}

/* k6572 in k6569 in k6566 in k6563 in k6560 in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6574(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6574,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6575 in k6569 in k6566 in k6563 in k6560 in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6577(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6577,2,av);}
if(C_truep(t1)){
/* support.scm:148: dump */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6543(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6581 in k6560 in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6583(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6583,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6584 in k6560 in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6586,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:152: text */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6478(t3,t2);}
else{
t2=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6591 in k6584 in k6560 in chicken.compiler.support#debugging in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6593,2,av);}
/* support.scm:152: dump */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6543(t2,((C_word*)t0)[3],t1);}

/* chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6595(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_6595,4,av);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6598,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6659,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:163: test-debugging-mode */
f_6454(t5,t2,*((C_word*)lf[12]+1));}

/* collect in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_6598,3,t0,t1,t2);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6600,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6627,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:162: chicken.string#string-split */
t5=*((C_word*)lf[35]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=lf[36];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* g737 in collect in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6600(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_6600,3,t0,t1,t2);}
a=C_alloc(5);
t3=*((C_word*)lf[18]+1);
t4=*((C_word*)lf[18]+1);
t5=C_i_check_port_2(*((C_word*)lf[18]+1),C_fix(2),C_SCHEME_TRUE,lf[32]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6607,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t7=((C_word*)t0)[2];
t8=C_u_i_car(t7);
/* support.scm:159: ##sys#print */
t9=*((C_word*)lf[27]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t6;
av2[2]=t8;
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[18]+1);
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t7=((C_word*)t0)[2];
/* support.scm:159: ##sys#print */
t8=*((C_word*)lf[27]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}

/* k6605 in g737 in collect in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6607,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:159: ##sys#write-char-0 */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(124);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6608 in k6605 in g737 in collect in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_6610,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:159: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6611 in k6608 in k6605 in g737 in collect in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6613,2,av);}
/* support.scm:159: ##sys#write-char-0 */
t2=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6625 in collect in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6627,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6632,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6632(t5,((C_word*)t0)[3],t1);}

/* for-each-loop736 in k6625 in collect in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6632(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6632,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6642,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:157: g737 */
t5=((C_word*)t0)[3];
f_6600(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6640 in for-each-loop736 in k6625 in collect in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6642(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6642,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6632(t3,((C_word*)t0)[4],t2);}

/* k6657 in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6659,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:164: chicken.port#with-output-to-string */
t3=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:169: test-debugging-mode */
f_6454(t2,((C_word*)t0)[4],lf[19]);}}

/* k6660 in k6657 in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6662,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:165: scheme#display */
t4=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6663 in k6660 in k6657 in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6665,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:166: chicken.base#flush-output */
t3=*((C_word*)lf[33]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6666 in k6663 in k6660 in k6657 in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6668,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:167: test-debugging-mode */
f_6454(t2,((C_word*)t0)[5],lf[19]);}

/* k6672 in k6666 in k6663 in k6660 in k6657 in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6674(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6674,2,av);}
if(C_truep(t1)){
/* support.scm:168: collect */
t2=((C_word*)t0)[2];
f_6598(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6681 in k6657 in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6683,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:170: chicken.port#with-output-to-string */
t3=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6688 in k6681 in k6657 in chicken.compiler.support#with-debugging-output in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6690,2,av);}
/* support.scm:170: collect */
t2=((C_word*)t0)[2];
f_6598(t2,((C_word*)t0)[3],t1);}

/* chicken.compiler.support#quit-compiling in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +9,c,3)))){
C_save_and_reclaim((void*)f_6692,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+9);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=*((C_word*)lf[38]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6696,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6706,a[2]=t5,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:174: scheme#string-append */
t7=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[41];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k6694 in chicken.compiler.support#quit-compiling in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6696,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6699,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:175: scheme#newline */
t3=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6697 in k6694 in chicken.compiler.support#quit-compiling in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6699,2,av);}
/* support.scm:176: chicken.base#exit */
t2=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6704 in chicken.compiler.support#quit-compiling in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6706(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6706,2,av);}{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[40]+1);
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
av2[5]=((C_word*)t0)[4];
C_apply(6,av2);}}

/* ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +10,c,2)))){
C_save_and_reclaim((void*)f_6708,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+10);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[38]+1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6712,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)t4)[1]))){
t8=((C_word*)t4)[1];
t9=C_i_car(((C_word*)t5)[1]);
t10=C_set_block_item(t4,0,t9);
t11=C_i_cdr(((C_word*)t5)[1]);
t12=C_set_block_item(t5,0,t11);
t13=t7;
f_6712(t13,t8);}
else{
t8=t7;
f_6712(t8,C_SCHEME_FALSE);}}

/* k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6712(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,4)))){
C_save_and_reclaim_args((void *)trf_6712,2,t0,t1);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=((C_word*)t0)[2];
t5=C_i_check_port_2(t4,C_fix(2),C_SCHEME_TRUE,lf[32]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6761,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:187: ##sys#print */
t7=*((C_word*)lf[27]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[49];
av2[3]=C_SCHEME_FALSE;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t4=((C_word*)t0)[2];
t5=C_i_check_port_2(t4,C_fix(2),C_SCHEME_TRUE,lf[32]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6782,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:188: ##sys#print */
t7=*((C_word*)lf[27]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[50];
av2[3]=C_SCHEME_FALSE;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}

/* k6713 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,3)))){
C_save_and_reclaim((void *)f_6715,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6716,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_i_check_list_2(t3,lf[44]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6726,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6734,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6734(t9,t5,t3);}

/* g781 in k6713 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6716(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_6716,3,t0,t1,t2);}
/* support.scm:189: g814 */
t3=*((C_word*)lf[40]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[43];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6724 in k6713 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6726(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_6726,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6729,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:190: chicken.base#print-call-chain */
t3=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(0);
av2[4]=*((C_word*)lf[46]+1);
av2[5]=lf[47];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k6727 in k6724 in k6713 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6729(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6729,2,av);}
/* support.scm:191: chicken.base#exit */
t2=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(70);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* for-each-loop780 in k6713 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6734(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6734,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6744,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:189: g781 */
t5=((C_word*)t0)[3];
f_6716(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6742 in for-each-loop780 in k6713 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6744(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6744,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6734(t3,((C_word*)t0)[4],t2);}

/* k6759 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_6761,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:187: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6762 in k6759 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_6764,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:187: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[48];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6765 in k6762 in k6759 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_6767,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:187: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6768 in k6765 in k6762 in k6759 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_6770,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:187: ##sys#write-char-0 */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6771 in k6768 in k6765 in k6762 in k6759 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6773,2,av);}
/* support.scm:187: ##sys#write-char-0 */
t2=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6780 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_6782,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:188: ##sys#print */
t3=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6783 in k6780 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6785(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_6785,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:188: ##sys#write-char-0 */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6786 in k6783 in k6780 in k6710 in ##sys#syntax-error-hook in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6788(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6788,2,av);}
/* support.scm:188: ##sys#write-char-0 */
t2=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* chicken.compiler.support#emit-syntax-trace-info in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6805(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6805,4,av);}
t4=*((C_word*)lf[46]+1);
t5=C_slot(*((C_word*)lf[46]+1),C_fix(14));
t6=t1;{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_emit_syntax_trace_info(t2,t3,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* loop in k6868 in err in chicken.compiler.support#check-signature in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6824(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_6824,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm:204: proc */
t3=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6847,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* support.scm:205: proc */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}}

/* k6845 in loop in k6868 in err in chicken.compiler.support#check-signature in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6847(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6847,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6851,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:205: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6824(t6,t3,t5);}

/* k6849 in k6845 in loop in k6868 in err in chicken.compiler.support#check-signature in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_6851,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* chicken.compiler.support#check-signature in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_6859,5,av);}
a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6862,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6883,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6883(t9,t1,t3,t4);}

/* err in chicken.compiler.support#check-signature in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_6862,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6870,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:212: real-name */
t3=*((C_word*)lf[55]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6868 in err in chicken.compiler.support#check-signature in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_6870,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6874,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
t5=*((C_word*)lf[55]+1);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6824,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6824(t9,t3,t4);}

/* k6872 in k6868 in err in chicken.compiler.support#check-signature in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6874,2,av);}
/* support.scm:210: quit-compiling */
t2=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[54];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* loop in chicken.compiler.support#check-signature in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6883(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_6883,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* support.scm:215: err */
t4=((C_word*)t0)[2];
f_6862(t4,t1);}}
else{
t4=C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
if(C_truep(C_i_nullp(t2))){
/* support.scm:217: err */
t5=((C_word*)t0)[2];
f_6862(t5,t1);}
else{
t5=C_i_cdr(t2);
t6=C_i_cdr(t3);
/* support.scm:218: loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* chicken.compiler.support#build-lambda-list in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6927,5,av);}
a=C_alloc(6);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6933,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_6933(t8,t1,t2,t3);}

/* loop in chicken.compiler.support#build-lambda-list in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6933(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(33,0,3)))){
C_save_and_reclaim_args((void *)trf_6933,4,t0,t1,t2,t3);}
a=C_alloc(33);
t4=t3;
t5=C_i_zerop(t4);
t6=(C_truep(t5)?t5:C_i_nullp(t2));
if(C_truep(t6)){
t7=((C_word*)t0)[2];
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=(C_truep(t7)?t7:C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_i_car(t2);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6955,a[2]=t1,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=C_u_i_cdr(t10);
t12=t3;
t13=C_s_a_i_minus(&a,2,t12,C_fix(1));
/* support.scm:226: loop */
t15=t9;
t16=t11;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* k6953 in loop in chicken.compiler.support#build-lambda-list in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_6955,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* chicken.compiler.support#c-ify-string in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6964,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6976,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6980,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#string->list */
t5=*((C_word*)lf[62]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6974 in chicken.compiler.support#c-ify-string in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6976(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6976,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,C_make_character(34),t1);
/* ##sys#list->string */
t3=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6978 in chicken.compiler.support#c-ify-string in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_6980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6980,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6982,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6982(t5,((C_word*)t0)[2],t1);}

/* loop in k6978 in chicken.compiler.support#c-ify-string in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_6982(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_6982,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[59];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
t5=C_fix(C_character_code(t4));
t6=t5;
t7=C_fixnum_lessp(t6,C_fix(32));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7004,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_7004(t9,t7);}
else{
t9=C_fixnum_greater_or_equal_p(t6,C_fix(127));
if(C_truep(t9)){
t10=t8;
f_7004(t10,t9);}
else{
t10=C_u_i_memq(t4,lf[66]);
t11=t8;
f_7004(t11,t10);}}}}

/* k7002 in loop in k6978 in chicken.compiler.support#c-ify-string in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7004(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7004,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(8)))){
t3=t2;
f_7011(t3,lf[64]);}
else{
t3=C_fixnum_lessp(((C_word*)t0)[5],C_fix(64));
t4=t2;
f_7011(t4,(C_truep(t3)?lf[65]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* support.scm:245: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6982(t5,t2,t4);}}

/* k7009 in k7002 in loop in k6978 in chicken.compiler.support#c-ify-string in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_7011,2,t0,t1);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7015,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7025,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#fixnum->string */
t5=*((C_word*)lf[63]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=C_fix(8);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k7013 in k7009 in k7002 in loop in k6978 in chicken.compiler.support#c-ify-string in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_7015,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
/* support.scm:244: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_6982(t6,t3,t5);}

/* k7017 in k7013 in k7009 in k7002 in loop in k6978 in chicken.compiler.support#c-ify-string in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_7019,2,av);}
/* support.scm:239: scheme#append */
t2=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[61];
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k7023 in k7009 in k7002 in loop in k6978 in chicken.compiler.support#c-ify-string in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7025,2,av);}
/* ##sys#string->list */
t2=*((C_word*)lf[62]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7045 in k7002 in loop in k6978 in chicken.compiler.support#c-ify-string in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7047(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_7047,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* chicken.compiler.support#valid-c-identifier? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7063(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_7063,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7067,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7111,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:249: chicken.string#->string */
t5=*((C_word*)lf[68]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7065 in chicken.compiler.support#valid-c-identifier? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,3)))){
C_save_and_reclaim((void *)f_7067,2,av);}
a=C_alloc(2);
if(C_truep(C_i_pairp(t1))){
t2=C_u_i_car(t1);
t3=C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:C_u_i_char_equalp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7088,tmp=(C_word)a,a+=2,tmp);
t6=C_u_i_cdr(t1);
/* support.scm:253: every */
f_5510(((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a7087 in k7065 in chicken.compiler.support#valid-c-identifier? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7088,3,av);}
t3=C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_u_i_char_numericp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t2;
t6=t1;{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_u_i_char_equalp(C_make_character(95),t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}

/* k7109 in chicken.compiler.support#valid-c-identifier? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7111,2,av);}
/* ##sys#string->list */
t2=*((C_word*)lf[62]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* chicken.compiler.support#bytes->words in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7113(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7113,3,av);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=stub910(C_SCHEME_UNDEFINED,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#words->bytes in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7120(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7120,3,av);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=stub915(C_SCHEME_UNDEFINED,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#check-and-open-input-file in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,2)))){
C_save_and_reclaim((void*)f_7127,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
if(C_truep(C_i_string_equal_p(t2,lf[72]))){
t4=*((C_word*)lf[73]+1);
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=*((C_word*)lf[73]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7140,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:263: chicken.file#file-exists? */
t5=*((C_word*)lf[77]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k7138 in chicken.compiler.support#check-and-open-input-file in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_7140,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:263: scheme#open-input-file */
t2=*((C_word*)lf[74]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_i_nullp(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_7152(t4,t2);}
else{
t4=C_i_car(((C_word*)t0)[4]);
t5=t3;
f_7152(t5,C_i_not(t4));}}}

/* k7150 in k7138 in chicken.compiler.support#check-and-open-input-file in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_7152,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:265: quit-compiling */
t2=*((C_word*)lf[37]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[75];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=C_i_car(((C_word*)t0)[4]);
/* support.scm:266: quit-compiling */
t3=*((C_word*)lf[37]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[76];
av2[3]=t2;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* chicken.compiler.support#close-checked-input-file in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7171,4,av);}
if(C_truep(C_i_string_equal_p(t3,lf[79]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
/* support.scm:269: scheme#close-input-port */
t4=*((C_word*)lf[80]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* chicken.compiler.support#fold-inner in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7183,4,av);}
a=C_alloc(4);
t4=C_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=t3;
t6=t1;{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7197,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:274: scheme#reverse */
t6=*((C_word*)lf[82]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k7195 in chicken.compiler.support#fold-inner in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7197(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7197,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7199,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7199(t5,((C_word*)t0)[3],t1);}

/* fold in k7195 in chicken.compiler.support#fold-inner in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7199(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_7199,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
t6=C_u_i_car(t5);
t7=t2;
t8=C_u_i_car(t7);
t9=C_a_i_list2(&a,2,t6,t8);{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t9;
C_apply(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7225,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_u_i_cdr(t5);
/* support.scm:279: fold */
t11=t4;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}

/* k7223 in fold in k7195 in chicken.compiler.support#fold-inner in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7225(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_7225,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list2(&a,2,t1,t3);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t4;
C_apply(4,av2);}}

/* chicken.compiler.support#follow-without-loop in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7239(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,4)))){
C_save_and_reclaim_args((void *)trf_7239,4,t1,t2,t3,t4);}
a=C_alloc(7);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7245,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7245(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in chicken.compiler.support#follow-without-loop in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7245(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_7245,4,t0,t1,t2,t3);}
a=C_alloc(5);
if(C_truep(C_i_member(t2,t3))){
/* support.scm:284: abort */
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7260,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:285: proc */
t5=((C_word*)t0)[4];{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* a7259 in loop in chicken.compiler.support#follow-without-loop in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7260(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_7260,3,av);}
a=C_alloc(3);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* support.scm:285: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_7245(t4,t1,t2,t3);}

/* a7275 in k11370 in k11364 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7276(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7276,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7284,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:288: scheme#symbol->string */
t5=*((C_word*)lf[223]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7282 in a7275 in k11370 in k11364 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7284,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7288,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:288: scheme#symbol->string */
t4=*((C_word*)lf[223]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7286 in k7282 in a7275 in k11370 in k11364 in k11361 in chicken.compiler.support#emit-global-inline-file in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7288(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7288,2,av);}
/* support.scm:288: scheme#string<? */
t2=*((C_word*)lf[222]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* chicken.compiler.support#read-expressions in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2)))){
C_save_and_reclaim((void*)f_7290,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t3=C_i_nullp(t2);
t4=(C_truep(t3)?*((C_word*)lf[73]+1):C_i_car(t2));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7301,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:291: scheme#read */
t7=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k7299 in chicken.compiler.support#read-expressions in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7301(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_7301,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7303,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7303(t5,((C_word*)t0)[3],t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* doloop961 in k7299 in chicken.compiler.support#read-expressions in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7303(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_7303,5,t0,t1,t2,t3,t4);}
a=C_alloc(7);
if(C_truep(C_eofp(t2))){
/* support.scm:294: scheme#reverse */
t5=*((C_word*)lf[82]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t1;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7320,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm:291: scheme#read */
t6=*((C_word*)lf[85]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k7318 in doloop961 in k7299 in chicken.compiler.support#read-expressions in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7320(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(32,c,4)))){
C_save_and_reclaim((void *)f_7320,2,av);}
a=C_alloc(32);
t2=((C_word*)t0)[2];
t3=C_s_a_i_plus(&a,2,t2,C_fix(1));
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t5=((C_word*)((C_word*)t0)[5])[1];
f_7303(t5,((C_word*)t0)[6],t1,t3,t4);}

/* chicken.compiler.support#constant? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7334,3,av);}
a=C_alloc(4);
t3=C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_booleanp(t2);
if(C_truep(t6)){
t7=t1;{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_eofp(t2);
if(C_truep(t7)){
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7368,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:305: chicken.blob#blob? */
t9=*((C_word*)lf[89]+1);{
C_word *av2=av;
av2[0]=t9;
av2[1]=t8;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}}}}}

/* k7366 in chicken.compiler.support#constant? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7368,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_vectorp(((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:307: ##sys#srfi-4-vector? */
t4=*((C_word*)lf[88]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}}

/* k7378 in k7366 in chicken.compiler.support#constant? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7380(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7380,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_eqp(lf[87],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* chicken.compiler.support#collapsable-literal? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7396(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7396,3,av);}
t3=C_booleanp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eofp(t2);
if(C_truep(t5)){
t6=t1;{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_numberp(t2);
t7=t1;{
C_word *av2=av;
av2[0]=t7;
av2[1]=(C_truep(t6)?t6:C_i_symbolp(t2));
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}}}

/* chicken.compiler.support#immediate? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7426(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_7426,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7430,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7470,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:318: big-fixnum? */
t5=*((C_word*)lf[92]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t3;
f_7430(t4,C_SCHEME_FALSE);}}

/* k7428 in chicken.compiler.support#immediate? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,1)))){
C_save_and_reclaim_args((void *)trf_7430,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_nullp(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eofp(((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_charp(((C_word*)t0)[3]);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(t5)?t5:C_booleanp(((C_word*)t0)[3]));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}}}

/* k7468 in chicken.compiler.support#immediate? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7470(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7470,2,av);}
t2=((C_word*)t0)[2];
f_7430(t2,C_i_not(t1));}

/* chicken.compiler.support#basic-literal? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7472,3,av);}
a=C_alloc(4);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7488,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:328: constant? */
t6=*((C_word*)lf[86]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}

/* k7486 in chicken.compiler.support#basic-literal? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7488(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_7488,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7526,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:329: scheme#vector->list */
t4=*((C_word*)lf[94]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_7494(2,av2);}}}}

/* k7492 in k7486 in chicken.compiler.support#basic-literal? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7494,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* support.scm:331: basic-literal? */
t5=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* k7507 in k7492 in k7486 in chicken.compiler.support#basic-literal? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7509,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:332: basic-literal? */
t4=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k7524 in k7486 in chicken.compiler.support#basic-literal? in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7526,2,av);}
/* support.scm:329: every */
f_5510(((C_word*)t0)[2],*((C_word*)lf[93]+1),t1);}

/* chicken.compiler.support#canonicalize-begin-body in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_7528,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7534,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7534(t6,t1,t2);}

/* loop in chicken.compiler.support#canonicalize-begin-body in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7534(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_7534,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[96];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_u_i_car(t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t2;
t5=C_u_i_car(t4);
t6=C_i_equalp(t5,lf[97]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7558,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_7558(t8,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7589,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:343: constant? */
t9=*((C_word*)lf[86]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}}}

/* k7556 in loop in chicken.compiler.support#canonicalize-begin-body in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7558,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:345: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7534(t4,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:346: chicken.base#gensym */
t3=*((C_word*)lf[99]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[100];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k7572 in k7582 in k7556 in loop in chicken.compiler.support#canonicalize-begin-body in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7574(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_7574,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[98],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7582 in k7556 in loop in chicken.compiler.support#canonicalize-begin-body in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_7584,2,av);}
a=C_alloc(13);
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list(&a,2,t1,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7574,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:347: loop */
t10=((C_word*)((C_word*)t0)[4])[1];
f_7534(t10,t7,t9);}

/* k7587 in loop in chicken.compiler.support#canonicalize-begin-body in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7589,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_7558(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7558(t2,C_i_equalp(((C_word*)t0)[3],lf[101]));}}

/* k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7603(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_7603,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7606,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:352: chicken.condition#condition-property-accessor */
t4=*((C_word*)lf[525]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[526];
av2[3]=lf[527];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7606(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(51,c,6)))){
C_save_and_reclaim((void *)f_7606,2,av);}
a=C_alloc(51);
t2=t1;
t3=C_mutate((C_word*)lf[102]+1 /* (set! chicken.compiler.support#string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7607,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[110]+1 /* (set! chicken.compiler.support#llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7725,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[111]+1 /* (set! chicken.compiler.support#llist-match? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7728,tmp=(C_word)a,a+=2,tmp));
t6=lf[112] /* chicken.compiler.support#profile-info-vector-name */ =C_SCHEME_FALSE;;
t7=C_mutate((C_word*)lf[113]+1 /* (set! chicken.compiler.support#reset-profile-info-vector-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7773,tmp=(C_word)a,a+=2,tmp));
t8=lf[116] /* chicken.compiler.support#profile-lambda-list */ =C_SCHEME_END_OF_LIST;;
t9=lf[117] /* chicken.compiler.support#profile-lambda-index */ =C_fix(0);;
t10=C_mutate((C_word*)lf[118]+1 /* (set! chicken.compiler.support#expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7782,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[124]+1 /* (set! chicken.compiler.support#profiling-prelude-exps ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7837,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[129]+1 /* (set! chicken.compiler.support#db-get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7926,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[131]+1 /* (set! chicken.compiler.support#db-get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7944,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[133]+1 /* (set! chicken.compiler.support#db-put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7962,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[135]+1 /* (set! chicken.compiler.support#collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8008,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[136]+1 /* (set! chicken.compiler.support#db-get-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8060,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[137]+1 /* (set! chicken.compiler.support#get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8069,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[139]+1 /* (set! chicken.compiler.support#get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8079,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[140]+1 /* (set! chicken.compiler.support#display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8120,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[142]+1 /* (set! chicken.compiler.support#make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8192,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[144]+1 /* (set! chicken.compiler.support#node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8198,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[145]+1 /* (set! chicken.compiler.support#node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8204,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[147]+1 /* (set! chicken.compiler.support#node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8213,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[149]+1 /* (set! chicken.compiler.support#node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8222,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[151]+1 /* (set! chicken.compiler.support#node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8231,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[152]+1 /* (set! chicken.compiler.support#node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8240,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[154]+1 /* (set! chicken.compiler.support#node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8249,tmp=(C_word)a,a+=2,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8259,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17271,tmp=(C_word)a,a+=2,tmp);
/* support.scm:482: ##sys#register-record-printer */
t30=*((C_word*)lf[524]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t30;
av2[1]=t28;
av2[2]=lf[143];
av2[3]=t29;
((C_proc)(void*)(*((C_word*)t30+1)))(4,av2);}}

/* chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_7607,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7611,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7616,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:354: scheme#call-with-current-continuation */
t5=*((C_word*)lf[109]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7609 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7611(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7611,2,av);}
/* support.scm:353: g1069 */
t2=t1;{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_7616,3,av);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7647,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:354: chicken.condition#with-exception-handler */
t5=*((C_word*)lf[108]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a7621 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_7622,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:354: k1066 */
t4=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a7627 in a7621 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_7628,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7636,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7639,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:357: exn? */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7634 in a7627 in a7621 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7636(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7636,2,av);}
/* support.scm:355: quit-compiling */
t2=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7637 in a7627 in a7621 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7639,2,av);}
if(C_truep(t1)){
/* support.scm:358: exn-msg */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
/* support.scm:359: chicken.string#->string */
t2=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* a7646 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7647(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_7647,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7706,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7723,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tmp14742 */
t5=t2;
f_7649(t5,t4);}

/* tmp14742 in a7646 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7649(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_7649,2,t0,t1);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7653,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7675,tmp=(C_word)a,a+=2,tmp);
/* support.scm:360: chicken.port#with-input-from-string */
t4=*((C_word*)lf[107]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7651 in tmp14742 in a7646 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7653(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_7653,2,av);}
a=C_alloc(3);
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[104];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_cdr(t1);
t3=C_i_nullp(t2);
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=(C_truep(t3)?C_u_i_car(t1):C_a_i_cons(&a,2,lf[105],t1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a7674 in tmp14742 in a7646 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_7675,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7681,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7681(t5,t1,C_SCHEME_END_OF_LIST);}

/* loop in a7674 in tmp14742 in a7646 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7681(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7681,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7685,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm:364: scheme#read */
t4=*((C_word*)lf[85]+1);{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k7683 in loop in a7674 in tmp14742 in a7646 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7685,2,av);}
a=C_alloc(3);
if(C_truep(C_eofp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7698,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:366: scheme#reverse */
t3=*((C_word*)lf[82]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* support.scm:367: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7681(t3,((C_word*)t0)[2],t2);}}

/* k7696 in k7683 in loop in a7674 in tmp14742 in a7646 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7698(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7698,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[106]+1);
av2[3]=t1;
C_apply(4,av2);}}

/* tmp24743 in a7646 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7706(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_7706,3,t0,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7712,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:354: k1066 */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a7711 in tmp24743 in a7646 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7712(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7712,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k7721 in a7646 in a7615 in chicken.compiler.support#string->expr in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7723(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7723,2,av);}
a=C_alloc(3);
/* tmp24743 */
t2=((C_word*)t0)[2];
f_7706(t2,((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* chicken.compiler.support#llist-length in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7725,3,av);}
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_u_i_length(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#llist-match? in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,3)))){
C_save_and_reclaim((void *)f_7728,4,av);}
a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7734,tmp=(C_word)a,a+=2,tmp);
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=(
  f_7734(t2,t3)
);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* loop in chicken.compiler.support#llist-match? in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static C_word C_fcall f_7734(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_nullp(t1))){
return(C_i_nullp(t2));}
else{
t3=C_i_symbolp(t1);
if(C_truep(t3)){
return(t3);}
else{
if(C_truep(C_i_nullp(t2))){
return(C_i_not_pair_p(t1));}
else{
t4=C_i_cdr(t1);
t5=C_i_cdr(t2);
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}}}

/* chicken.compiler.support#reset-profile-info-vector-name! in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7773,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7778,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:388: make-random-name */
t3=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[115];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7776 in chicken.compiler.support#reset-profile-info-vector-name! in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7778,2,av);}
t2=C_mutate(&lf[112] /* (set! chicken.compiler.support#profile-info-vector-name ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#expand-profile-lambda in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_7782,5,av);}
a=C_alloc(7);
t5=lf[117];
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7786,a[2]=t2,a[3]=t5,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm:395: chicken.base#gensym */
t7=*((C_word*)lf[99]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k7784 in chicken.compiler.support#expand-profile-lambda in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(131,c,1)))){
C_save_and_reclaim((void *)f_7786,2,av);}
a=C_alloc(131);
t2=((C_word*)t0)[2];
t3=lf[116];
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=C_a_i_cons(&a,2,t4,lf[116]);
t6=C_mutate(&lf[116] /* (set! chicken.compiler.support#profile-lambda-list ...) */,t5);
t7=C_mutate(&lf[117] /* (set! chicken.compiler.support#profile-lambda-index ...) */,C_s_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1)));
t8=C_a_i_list(&a,2,lf[87],((C_word*)t0)[3]);
t9=C_a_i_list(&a,3,lf[119],t8,lf[112]);
t10=C_a_i_list(&a,3,lf[120],C_SCHEME_END_OF_LIST,t9);
t11=C_a_i_list(&a,3,lf[120],((C_word*)t0)[4],((C_word*)t0)[5]);
t12=C_a_i_list(&a,3,lf[121],t11,t1);
t13=C_a_i_list(&a,3,lf[120],C_SCHEME_END_OF_LIST,t12);
t14=C_a_i_list(&a,2,lf[87],((C_word*)t0)[3]);
t15=C_a_i_list(&a,3,lf[122],t14,lf[112]);
t16=C_a_i_list(&a,3,lf[120],C_SCHEME_END_OF_LIST,t15);
t17=C_a_i_list(&a,4,lf[123],t10,t13,t16);
t18=((C_word*)t0)[6];{
C_word *av2=av;
av2[0]=t18;
av2[1]=C_a_i_list(&a,3,lf[120],t1,t17);
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}

/* chicken.compiler.support#profiling-prelude-exps in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(46,c,3)))){
C_save_and_reclaim((void *)f_7837,3,av);}
a=C_alloc(46);
t3=C_i_length(lf[116]);
t4=C_a_i_list(&a,2,lf[87],t3);
t5=C_a_i_list(&a,2,lf[87],t2);
t6=C_a_i_list(&a,3,lf[125],t4,t5);
t7=C_a_i_list(&a,3,lf[126],lf[112],t6);
t8=t7;
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=lf[116];
t14=C_i_check_list_2(lf[116],lf[127]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7874,a[2]=t1,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7876,a[2]=t11,a[3]=t17,a[4]=t12,tmp=(C_word)a,a+=5,tmp));
t19=((C_word*)t17)[1];
f_7876(t19,t15,lf[116]);}

/* k7872 in chicken.compiler.support#profiling-prelude-exps in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_7874,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop1124 in chicken.compiler.support#profiling-prelude-exps in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_7876(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(27,0,2)))){
C_save_and_reclaim_args((void *)trf_7876,3,t0,t1,t2);}
a=C_alloc(27);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_list(&a,2,lf[87],t4);
t6=C_u_i_cdr(t3);
t7=C_a_i_list(&a,2,lf[87],t6);
t8=C_a_i_list(&a,4,lf[128],lf[112],t5,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t14=t1;
t15=t12;
t1=t14;
t2=t15;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.compiler.support#db-get in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_7926,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7930,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:420: chicken.internal#hash-table-ref */
t6=*((C_word*)lf[130]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k7928 in chicken.compiler.support#db-get in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7930(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7930,2,av);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=(C_truep(t2)?C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* chicken.compiler.support#db-get-all in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +4,c,3)))){
C_save_and_reclaim((void*)f_7944,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+4);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7948,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:426: chicken.internal#hash-table-ref */
t6=*((C_word*)lf[130]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k7946 in chicken.compiler.support#db-get-all in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7948(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_7948,2,av);}
a=C_alloc(9);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7956,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
t5=t3;
t6=((C_word*)t0)[3];
t7=C_i_check_list_2(t6,lf[132]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5803,a[2]=t5,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_5803(t11,t4,t6);}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a7955 in k7946 in chicken.compiler.support#db-get-all in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7956(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7956,3,av);}
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_i_assq(t2,((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#db-put! in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_7962,6,av);}
a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7966,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:432: chicken.internal#hash-table-ref */
t7=*((C_word*)lf[130]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k7964 in chicken.compiler.support#db-put! in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_7966(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_7966,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(((C_word*)t0)[4])){
t3=C_slot(t1,C_fix(1));
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[4];
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,t6,t3);
t8=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_i_setslot(t1,C_fix(1),t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:437: chicken.internal#hash-table-set! */
t4=*((C_word*)lf[134]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* chicken.compiler.support#collect! in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8008(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_8008,6,av);}
a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8012,a[2]=t4,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:440: chicken.internal#hash-table-ref */
t7=*((C_word*)lf[130]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k8010 in chicken.compiler.support#collect! in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_8012,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_i_setslot(t2,C_fix(1),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t4=C_slot(t1,C_fix(1));
t5=((C_word*)t0)[2];
t6=C_a_i_cons(&a,2,t5,t3);
t7=C_a_i_cons(&a,2,t6,t4);
t8=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_i_setslot(t1,C_fix(1),t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:445: chicken.internal#hash-table-set! */
t4=*((C_word*)lf[134]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* chicken.compiler.support#db-get-list in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_8060,5,av);}
a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8064,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:448: db-get */
t6=*((C_word*)lf[129]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k8062 in chicken.compiler.support#db-get-list in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8064(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8064,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* chicken.compiler.support#get-line in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8069,3,av);}
t3=C_i_car(t2);
/* support.scm:455: db-get */
t4=*((C_word*)lf[129]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=*((C_word*)lf[138]+1);
av2[3]=t3;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* chicken.compiler.support#get-line-2 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_8079,3,av);}
a=C_alloc(5);
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8086,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:459: chicken.internal#hash-table-ref */
t6=*((C_word*)lf[130]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=*((C_word*)lf[138]+1);
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k8084 in chicken.compiler.support#get-line-2 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8086(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_8086,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8089,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=C_i_cdr(t2);
t5=t3;
f_8089(t5,C_i_assq(((C_word*)t0)[4],t4));}
else{
t4=t3;
f_8089(t4,C_SCHEME_FALSE);}}

/* k8087 in k8084 in chicken.compiler.support#get-line-2 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,3)))){
C_save_and_reclaim_args((void *)trf_8089,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8093,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:460: g1207 */
t3=t2;
f_8093(t3,((C_word*)t0)[3],t1);}
else{
/* support.scm:462: scheme#values */{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}

/* g1207 in k8087 in k8084 in chicken.compiler.support#get-line-2 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8093(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_8093,3,t0,t1,t2);}
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_cdr(t2);
/* support.scm:461: scheme#values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
C_values(4,av2);}}

/* chicken.compiler.support#display-line-number-database in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8120(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,4)))){
C_save_and_reclaim((void *)f_8120,2,av);}
a=C_alloc(2);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8126,tmp=(C_word)a,a+=2,tmp);
/* support.scm:465: chicken.internal#hash-table-for-each */
t3=*((C_word*)lf[141]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=*((C_word*)lf[138]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a8125 in chicken.compiler.support#display-line-number-database in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8126(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_8126,4,av);}
a=C_alloc(5);
if(C_truep(t3)){
t4=*((C_word*)lf[24]+1);
t5=*((C_word*)lf[24]+1);
t6=C_i_check_port_2(*((C_word*)lf[24]+1),C_fix(2),C_SCHEME_TRUE,lf[25]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8136,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:467: ##sys#print */
t8=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=*((C_word*)lf[24]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k8134 in a8125 in chicken.compiler.support#display-line-number-database in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_8136,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:467: ##sys#write-char-0 */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k8137 in k8134 in a8125 in chicken.compiler.support#display-line-number-database in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
C_save_and_reclaim((void *)f_8139,2,av);}
a=C_alloc(20);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)t0)[4];
t8=C_i_check_list_2(t7,lf[127]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8155,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8157,a[2]=t5,a[3]=t11,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_8157(t13,t9,t7);}

/* k8140 in k8137 in k8134 in a8125 in chicken.compiler.support#display-line-number-database in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_8142,2,av);}
/* support.scm:467: ##sys#write-char-0 */
t2=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8153 in k8137 in k8134 in a8125 in chicken.compiler.support#display-line-number-database in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8155(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8155,2,av);}
/* support.scm:467: ##sys#print */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop1219 in k8137 in k8134 in a8125 in chicken.compiler.support#display-line-number-database in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8157(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_8157,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* chicken.compiler.support#make-node in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8192,5,av);}
a=C_alloc(5);
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[143],t2,t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* chicken.compiler.support#node? in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8198,3,av);}
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[143]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* chicken.compiler.support#node-class in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8204(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8204,3,av);}
t3=C_i_check_structure_2(t2,lf[143],lf[146]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#node-class-set! in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8213(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8213,4,av);}
t4=C_i_check_structure_2(t2,lf[143],C_SCHEME_FALSE);
/* support.scm:475: ##sys#block-set! */
t5=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(1);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* chicken.compiler.support#node-parameters in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8222,3,av);}
t3=C_i_check_structure_2(t2,lf[143],lf[150]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(2));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#node-parameters-set! in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8231(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8231,4,av);}
t4=C_i_check_structure_2(t2,lf[143],C_SCHEME_FALSE);
/* support.scm:475: ##sys#block-set! */
t5=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(2);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* chicken.compiler.support#node-subexpressions in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_8240,3,av);}
t3=C_i_check_structure_2(t2,lf[143],lf[153]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(3));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#node-subexpressions-set! in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8249(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8249,4,av);}
t4=C_i_check_structure_2(t2,lf[143],C_SCHEME_FALSE);
/* support.scm:475: ##sys#block-set! */
t5=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(3);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(156,c,8)))){
C_save_and_reclaim((void *)f_8259,2,av);}
a=C_alloc(156);
t2=C_mutate((C_word*)lf[142]+1 /* (set! chicken.compiler.support#make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8261,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[155]+1 /* (set! chicken.compiler.support#varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8267,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[157]+1 /* (set! chicken.compiler.support#qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8282,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[158]+1 /* (set! chicken.compiler.support#build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8297,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[193]+1 /* (set! chicken.compiler.support#build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9493,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[206]+1 /* (set! chicken.compiler.support#fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10363,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[208]+1 /* (set! chicken.compiler.support#inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10415,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[216]+1 /* (set! chicken.compiler.support#tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11095,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[217]+1 /* (set! chicken.compiler.support#copy-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11125,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[218]+1 /* (set! chicken.compiler.support#copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11163,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[219]+1 /* (set! chicken.compiler.support#emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11359,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[245]+1 /* (set! chicken.compiler.support#load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11621,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[248]+1 /* (set! chicken.compiler.support#match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11677,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[251]+1 /* (set! chicken.compiler.support#expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11910,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[254]+1 /* (set! chicken.compiler.support#simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12019,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[255]+1 /* (set! chicken.compiler.support#dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12145,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[260]+1 /* (set! chicken.compiler.support#dump-defined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12186,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[261]+1 /* (set! chicken.compiler.support#dump-global-refs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12223,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[263]+1 /* (set! ##sys#toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12272,tmp=(C_word)a,a+=2,tmp));
t21=C_set_block_item(lf[253] /* chicken.compiler.support#foreign-callback-stubs */,0,C_SCHEME_END_OF_LIST);
t22=C_mutate((C_word*)lf[269]+1 /* (set! chicken.compiler.support#make-foreign-callback-stub ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12300,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[271]+1 /* (set! chicken.compiler.support#foreign-callback-stub? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12306,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[252]+1 /* (set! chicken.compiler.support#foreign-callback-stub-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12312,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[273]+1 /* (set! chicken.compiler.support#foreign-callback-stub-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12321,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[275]+1 /* (set! chicken.compiler.support#foreign-callback-stub-qualifiers ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12330,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[277]+1 /* (set! chicken.compiler.support#foreign-callback-stub-return-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12339,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[279]+1 /* (set! chicken.compiler.support#foreign-callback-stub-argument-types ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12348,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[281]+1 /* (set! chicken.compiler.support#register-foreign-callback-stub! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12357,tmp=(C_word)a,a+=2,tmp));
t30=lf[283] /* chicken.compiler.support#foreign-type-table */ =C_SCHEME_FALSE;;
t31=C_mutate((C_word*)lf[284]+1 /* (set! chicken.compiler.support#clear-foreign-type-table! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12386,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[287]+1 /* (set! chicken.compiler.support#register-foreign-type! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12399,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[288]+1 /* (set! chicken.compiler.support#lookup-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12453,tmp=(C_word)a,a+=2,tmp));
t34=lf[289];
t35=C_mutate((C_word*)lf[290]+1 /* (set! chicken.compiler.support#foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12459,a[2]=t34,tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[387]+1 /* (set! chicken.compiler.support#foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13535,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[388]+1 /* (set! chicken.compiler.support#foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13562,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[389]+1 /* (set! chicken.compiler.support#final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13589,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[391]+1 /* (set! chicken.compiler.support#estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13628,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[397]+1 /* (set! chicken.compiler.support#estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14103,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[400]+1 /* (set! chicken.compiler.support#finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14553,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[414]+1 /* (set! chicken.compiler.support#foreign-type->scrutiny-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14821,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[437]+1 /* (set! chicken.compiler.support#scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15427,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[438]+1 /* (set! chicken.compiler.support#scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15582,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[439]+1 /* (set! chicken.compiler.support#chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15812,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[442]+1 /* (set! chicken.compiler.support#make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15836,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[444]+1 /* (set! chicken.compiler.support#block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15842,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[445]+1 /* (set! chicken.compiler.support#block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15848,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[114]+1 /* (set! chicken.compiler.support#make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15857,tmp=(C_word)a,a+=2,tmp));
t50=lf[449] /* chicken.compiler.support#real-name-table */ =C_SCHEME_FALSE;;
t51=C_mutate((C_word*)lf[450]+1 /* (set! chicken.compiler.support#clear-real-name-table! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15904,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[451]+1 /* (set! chicken.compiler.support#set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15911,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[452]+1 /* (set! chicken.compiler.support#get-real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15917,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[55]+1 /* (set! chicken.compiler.support#real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15924,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[459]+1 /* (set! chicken.compiler.support#real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16044,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[460]+1 /* (set! chicken.compiler.support#display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16056,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[461]+1 /* (set! chicken.compiler.support#source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16080,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[467]+1 /* (set! chicken.compiler.support#source-info->name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16115,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[468]+1 /* (set! chicken.compiler.support#source-info->line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16130,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[469]+1 /* (set! chicken.compiler.support#call-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16142,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[472]+1 /* (set! chicken.compiler.support#constant-form-eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16179,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[479]+1 /* (set! chicken.compiler.support#maybe-constant-fold-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16409,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate(&lf[475] /* (set! chicken.compiler.support#encodeable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16508,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[484]+1 /* (set! chicken.compiler.support#dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16645,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[486]+1 /* (set! chicken.compiler.support#read-info-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16801,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[490]+1 /* (set! chicken.compiler.support#read/source-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16844,tmp=(C_word)a,a+=2,tmp));
t67=*((C_word*)lf[492]+1);
t68=C_mutate((C_word*)lf[492]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16850,a[2]=t67,tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[92]+1 /* (set! chicken.compiler.support#big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16944,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[499]+1 /* (set! chicken.compiler.support#small-bignum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16968,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[267]+1 /* (set! chicken.compiler.support#hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16992,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[501]+1 /* (set! chicken.compiler.support#export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17012,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[266]+1 /* (set! chicken.compiler.support#variable-hidden? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17032,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[244]+1 /* (set! chicken.compiler.support#variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17054,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[503]+1 /* (set! chicken.compiler.support#mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17079,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[504]+1 /* (set! chicken.compiler.support#variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17094,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[505]+1 /* (set! chicken.compiler.support#intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17100,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[481]+1 /* (set! chicken.compiler.support#foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17111,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[480]+1 /* (set! chicken.compiler.support#predicate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17122,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[508]+1 /* (set! chicken.compiler.support#load-identifier-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17133,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[516]+1 /* (set! chicken.compiler.support#print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17228,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[519]+1 /* (set! chicken.compiler.support#print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17253,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[521]+1 /* (set! chicken.compiler.support#print-debug-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17265,tmp=(C_word)a,a+=2,tmp));
t84=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t84;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t84+1)))(2,av2);}}

/* chicken.compiler.support#make-node in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8261(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8261,5,av);}
a=C_alloc(5);
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[143],t2,t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* chicken.compiler.support#varnode in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8267(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_8267,3,av);}
a=C_alloc(8);
t3=C_a_i_list1(&a,1,t2);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[156],t3,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#qnode in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_8282,3,av);}
a=C_alloc(8);
t3=C_a_i_list1(&a,1,t2);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[87],t3,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_8297,3,av);}
a=C_alloc(12);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8300,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9484,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:584: walk */
t9=((C_word*)t6)[1];{
C_word *av2=av;
av2[0]=t9;
av2[1]=t8;
av2[2]=t2;
f_8300(3,av2);}}

/* walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8300(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
av[0]=t0;
av[1]=t1;
av[2]=t2;
C_save_and_reclaim((void *)f_8300,3,av);}
a=C_alloc(20);
if(C_truep(C_i_symbolp(t2))){
/* support.scm:494: varnode */
t3=*((C_word*)lf[155]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;
if(C_truep(C_i_structurep(t3,lf[143]))){
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_pairp(t2);
if(C_truep(C_i_not(t4))){
/* support.scm:496: bomb */
t5=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=lf[159];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=C_i_car(t2);
if(C_truep(C_i_symbolp(t5))){
t6=t2;
t7=C_u_i_car(t6);
t8=C_eqp(t7,lf[160]);
t9=(C_truep(t8)?t8:C_eqp(t7,lf[161]));
if(C_truep(t9)){
t10=t2;
t11=C_u_i_car(t10);
t12=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t13=t12;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=((C_word*)t14)[1];
t16=((C_word*)((C_word*)t0)[2])[1];
t17=t2;
t18=C_u_i_cdr(t17);
t19=C_i_check_list_2(t18,lf[127]);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8367,a[2]=t1,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8369,a[2]=t14,a[3]=t22,a[4]=t16,a[5]=t15,tmp=(C_word)a,a+=6,tmp));
t24=((C_word*)t22)[1];
f_8369(t24,t20,t18);}
else{
t10=C_eqp(t7,lf[87]);
if(C_truep(t10)){
t11=C_i_cadr(t2);
t12=t11;
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8417,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8420,a[2]=t13,a[3]=t12,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_numberp(t12))){
t15=C_eqp(lf[166],*((C_word*)lf[8]+1));
if(C_truep(t15)){
t16=C_i_integerp(t12);
t17=t14;
f_8420(t17,C_i_not(t16));}
else{
t16=t14;
f_8420(t16,C_SCHEME_FALSE);}}
else{
t15=t14;
f_8420(t15,C_SCHEME_FALSE);}}
else{
t11=C_eqp(t7,lf[98]);
if(C_truep(t11)){
t12=C_i_cadr(t2);
t13=C_i_caddr(t2);
t14=t13;
if(C_truep(C_i_nullp(t12))){
/* support.scm:514: walk */
t25=t1;
t26=t14;
t1=t25;
t2=t26;
c=3;
goto loop;}
else{
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8477,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t14,tmp=(C_word)a,a+=6,tmp);
t16=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t17=t16;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=((C_word*)t18)[1];
t20=C_i_check_list_2(t12,lf[127]);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5876,a[2]=t18,a[3]=t22,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t24=((C_word*)t22)[1];
f_5876(t24,t15,t12);}}
else{
t12=C_eqp(t7,lf[167]);
t13=(C_truep(t12)?t12:C_eqp(t7,lf[120]));
if(C_truep(t13)){
t14=C_i_cadr(t2);
t15=C_a_i_list1(&a,1,t14);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8574,a[2]=t1,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t18=C_i_caddr(t2);
/* support.scm:520: walk */
t25=t17;
t26=t18;
t1=t25;
t2=t26;
c=3;
goto loop;}
else{
t14=C_eqp(t7,lf[168]);
if(C_truep(t14)){
t15=t2;
t16=C_i_cadr(t15);
t17=t2;
t18=C_i_caddr(t17);
t19=C_a_i_list2(&a,2,t16,t18);
t20=t19;
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8608,a[2]=t1,a[3]=t20,tmp=(C_word)a,a+=4,tmp);
t22=t2;
t23=C_i_cadddr(t22);
/* support.scm:524: walk */
t25=t21;
t26=t23;
t1=t25;
t2=t26;
c=3;
goto loop;}
else{
t15=C_eqp(t7,lf[169]);
if(C_truep(t15)){
t16=C_i_cdddr(t2);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8762,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t17,tmp=(C_word)a,a+=6,tmp);
t19=t2;
t20=C_u_i_cdr(t19);
t21=C_u_i_cdr(t20);
t22=C_u_i_car(t21);
/* support.scm:527: walk */
t25=t18;
t26=t22;
t1=t25;
t2=t26;
c=3;
goto loop;}
else{
t16=C_eqp(t7,lf[173]);
if(C_truep(t16)){
t17=C_i_cadr(t2);
t18=t2;
t19=C_u_i_car(t18);
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8789,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t19,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t17))){
t21=C_u_i_car(t17);
t22=C_eqp(lf[87],t21);
if(C_truep(t22)){
t23=C_i_cadr(t17);
t24=t20;
f_8789(t24,C_a_i_list1(&a,1,t23));}
else{
t23=t20;
f_8789(t23,C_a_i_list1(&a,1,t17));}}
else{
t21=t20;
f_8789(t21,C_a_i_list1(&a,1,t17));}}
else{
t17=C_eqp(t7,lf[174]);
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8862,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t7,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t17)){
t19=t18;
f_8862(t19,t17);}
else{
t19=C_eqp(t7,lf[189]);
t20=t18;
f_8862(t20,(C_truep(t19)?t19:C_eqp(t7,lf[190])));}}}}}}}}}
else{
t6=C_a_i_list1(&a,1,C_SCHEME_FALSE);
t7=t6;
t8=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=((C_word*)t10)[1];
t12=((C_word*)((C_word*)t0)[2])[1];
t13=t2;
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9439,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9441,a[2]=t10,a[3]=t16,a[4]=t12,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_9441(t18,t14,t13);}}}}}

/* k8365 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8367(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8367,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],((C_word*)t0)[3],C_SCHEME_END_OF_LIST,t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1349 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8369(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8369,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8394,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:499: g1355 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8392 in map-loop1349 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8394(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8394,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8369(t6,((C_word*)t0)[5],t5);}

/* k8415 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8417(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8417,2,av);}
/* support.scm:502: qnode */
t2=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8418 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_8420,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:506: chicken.base#warning */
t3=*((C_word*)lf[164]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[165];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
/* support.scm:502: qnode */
t2=*((C_word*)lf[157]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k8421 in k8418 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8423(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8423,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:508: scheme#truncate */
t3=*((C_word*)lf[163]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8428 in k8421 in k8418 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8430,2,av);}
/* support.scm:508: scheme#inexact->exact */
t2=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8475 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8477(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,3)))){
C_save_and_reclaim((void *)f_8477,2,av);}
a=C_alloc(25);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8481,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8486,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t9=C_i_cadr(((C_word*)t0)[4]);
t10=C_i_check_list_2(t9,lf[127]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8503,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8513,a[2]=t6,a[3]=t13,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_8513(t15,t11,t9);}

/* k8479 in k8475 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8481(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8481,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[98],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* g1392 in k8475 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8486(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_8486,3,t0,t1,t2);}
t3=C_i_cadr(t2);
/* support.scm:517: walk */
t4=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
f_8300(3,av2);}}

/* k8501 in k8475 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8503(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_8503,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8511,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:518: walk */
t4=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
f_8300(3,av2);}}

/* k8509 in k8501 in k8475 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8511(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_8511,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* support.scm:517: scheme#append */
t3=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* map-loop1386 in k8475 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8513(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8513,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8538,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:517: g1392 */
t5=((C_word*)t0)[4];
f_8486(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8536 in map-loop1386 in k8475 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8538(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8538,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8513(t6,((C_word*)t0)[5],t5);}

/* k8572 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8574(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_8574,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[167],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k8606 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_8608,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[168],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* loop in k8760 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8639(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,2)))){
C_save_and_reclaim_args((void *)trf_8639,5,t0,t1,t2,t3,t4);}
a=C_alloc(14);
if(C_truep(C_i_nullp(t2))){
t5=C_i_cadr(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8683,a[2]=t6,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* support.scm:531: scheme#reverse */
t8=*((C_word*)lf[82]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t5=C_i_caar(t2);
t6=C_eqp(lf[170],t5);
if(C_truep(t6)){
t7=C_i_cadr(((C_word*)t0)[2]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8725,a[2]=t8,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t10=C_a_i_cons(&a,2,lf[172],t3);
/* support.scm:537: scheme#reverse */
t11=*((C_word*)lf[82]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t9;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_i_caar(t2);
t10=C_a_i_cons(&a,2,t9,t3);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8746,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t8,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8750,a[2]=((C_word*)t0)[3],a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* support.scm:541: scheme#cadar */
t14=*((C_word*)lf[171]+1);{
C_word av2[3];
av2[0]=t14;
av2[1]=t13;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}}}

/* k8660 in k8681 in loop in k8760 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8662,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[169],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8681 in loop in k8760 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_8683,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8662,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_a_i_record4(&a,4,lf[143],lf[161],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[4]);
/* support.scm:532: scheme#reverse */
t7=*((C_word*)lf[82]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k8703 in k8723 in loop in k8760 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8705,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[169],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8711 in k8723 in loop in k8760 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8713,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:538: scheme#reverse */
t3=*((C_word*)lf[82]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8715 in k8723 in loop in k8760 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8717,2,av);}
/* support.scm:538: walk */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_8300(3,av2);}}

/* k8723 in loop in k8760 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_8725,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8705,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8713,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8717,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:538: scheme#cadar */
t7=*((C_word*)lf[171]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k8744 in loop in k8760 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8746(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_8746,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:539: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8639(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k8748 in loop in k8760 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8750(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8750,2,av);}
/* support.scm:541: walk */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_8300(3,av2);}}

/* k8760 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8762(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,5)))){
C_save_and_reclaim((void *)f_8762,2,av);}
a=C_alloc(10);
t2=C_a_i_list1(&a,1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8639(t6,((C_word*)t0)[4],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,t2);}

/* k8787 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,3)))){
C_save_and_reclaim_args((void *)trf_8789,2,t0,t1);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)((C_word*)t0)[2])[1];
t8=((C_word*)t0)[3];
t9=C_u_i_cdr(t8);
t10=C_u_i_cdr(t9);
t11=C_i_check_list_2(t10,lf[127]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8801,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8803,a[2]=t5,a[3]=t14,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_8803(t16,t12,t10);}

/* k8799 in k8787 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8801(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8801,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1457 in k8787 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8803(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8803,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8828,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:547: g1463 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8826 in map-loop1457 in k8787 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8828(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8828,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8803(t6,((C_word*)t0)[5],t5);}

/* k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,0,3)))){
C_save_and_reclaim_args((void *)trf_8862,2,t0,t1);}
a=C_alloc(21);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=((C_word*)((C_word*)t0)[3])[1];
t12=((C_word*)t0)[2];
t13=C_u_i_cdr(t12);
t14=C_u_i_cdr(t13);
t15=C_i_check_list_2(t14,lf[127]);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8888,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8890,a[2]=t9,a[3]=t18,a[4]=t11,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_8890(t20,t16,t14);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[175]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=((C_word*)t0)[4];
t8=t7;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_a_i_record4(&a,4,lf[143],t4,t6,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[5],lf[176]);
if(C_truep(t3)){
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_list2(&a,2,t4,C_SCHEME_TRUE);
t6=((C_word*)t0)[4];
t7=t6;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[176],t5,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[5],lf[126]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[177]));
if(C_truep(t5)){
t6=C_i_cadr(((C_word*)t0)[2]);
t7=C_a_i_list1(&a,1,t6);
t8=t7;
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=((C_word*)((C_word*)t0)[3])[1];
t14=((C_word*)t0)[2];
t15=C_u_i_cdr(t14);
t16=C_u_i_cdr(t15);
t17=C_i_check_list_2(t16,lf[127]);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8999,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9001,a[2]=t11,a[3]=t20,a[4]=t13,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t22=((C_word*)t20)[1];
f_9001(t22,t18,t16);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[178]);
if(C_truep(t6)){
t7=((C_word*)t0)[2];
t8=C_i_cadr(t7);
t9=C_i_cadr(t8);
t10=((C_word*)t0)[2];
t11=C_i_caddr(t10);
t12=C_i_cadr(t11);
t13=((C_word*)t0)[2];
t14=C_i_cadddr(t13);
t15=C_i_cadr(t14);
t16=((C_word*)t0)[2];
t17=C_i_cddddr(t16);
t18=C_i_car(t17);
t19=C_i_cadr(t18);
t20=C_a_i_list4(&a,4,t9,t12,t15,t19);
t21=t20;
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9066,a[2]=((C_word*)t0)[4],a[3]=t21,tmp=(C_word)a,a+=4,tmp);
t23=C_i_list_ref(((C_word*)t0)[2],C_fix(5));
/* support.scm:563: walk */
t24=((C_word*)((C_word*)t0)[3])[1];{
C_word av2[3];
av2[0]=t24;
av2[1]=t22;
av2[2]=t23;
f_8300(3,av2);}}
else{
t7=C_eqp(((C_word*)t0)[5],lf[179]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_9107(t9,t7);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[185]);
if(C_truep(t9)){
t10=t8;
f_9107(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[186]);
if(C_truep(t10)){
t11=t8;
f_9107(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[5],lf[187]);
t12=t8;
f_9107(t12,(C_truep(t11)?t11:C_eqp(((C_word*)t0)[5],lf[188])));}}}}}}}}}

/* k8886 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8888,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1494 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_8890(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_8890,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8915,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:549: g1500 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8913 in map-loop1494 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8915(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_8915,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8890(t6,((C_word*)t0)[5],t5);}

/* k8997 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_8999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_8999,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[126],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1538 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9001,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9026,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:557: g1544 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9024 in map-loop1538 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9026(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9026,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9001(t6,((C_word*)t0)[5],t5);}

/* k9064 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,1)))){
C_save_and_reclaim((void *)f_9066,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[178],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9107(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,0,4)))){
C_save_and_reclaim_args((void *)trf_9107,2,t0,t1);}
a=C_alloc(20);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_car(t2);
t4=t3;
t5=((C_word*)t0)[2];
t6=C_i_cadr(t5);
t7=t6;
t8=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=((C_word*)t10)[1];
t12=((C_word*)((C_word*)t0)[3])[1];
t13=C_i_cddr(((C_word*)t0)[2]);
t14=C_i_check_list_2(t13,lf[127]);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9136,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9138,a[2]=t10,a[3]=t17,a[4]=t12,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_9138(t19,t15,t13);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[180]);
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=((C_word*)((C_word*)t0)[3])[1];
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
t12=C_i_check_list_2(t11,lf[127]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9199,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9201,a[2]=t7,a[3]=t15,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_9201(t17,t13,t11);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9238,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9244,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* support.scm:570: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}}}

/* k9134 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_9136,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1587 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9138(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9138,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9163,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:566: g1593 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9161 in map-loop1587 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9163,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9138(t6,((C_word*)t0)[5],t5);}

/* k9197 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_9199,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[181],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1618 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9201(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9201,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9226,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:568: g1624 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9224 in map-loop1618 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9226(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9226,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9201(t6,((C_word*)t0)[5],t5);}

/* a9237 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9238(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9238,2,av);}
/* support.scm:570: get-line-2 */
t2=*((C_word*)lf[139]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a9243 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9244(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_9244,4,av);}
a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9333,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=t2;
/* tweaks.scm:60: ##sys#get */
t7=*((C_word*)lf[183]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=lf[184];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k9265 in k9307 in k9303 in a9243 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9267(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_9267,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[181],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1664 in k9307 in k9303 in a9243 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9269(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9269,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9294,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:582: g1670 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9292 in map-loop1664 in k9307 in k9303 in a9243 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 in ... */
static void C_ccall f_9294(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9294,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9269(t6,((C_word*)t0)[5],t5);}

/* k9303 in a9243 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9305(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,2)))){
C_save_and_reclaim_args((void *)trf_9305,2,t0,t1);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9309,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9312,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* support.scm:578: real-name */
t5=*((C_word*)lf[55]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* support.scm:581: ##sys#symbol->string */
t4=*((C_word*)lf[182]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k9307 in k9303 in a9243 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9309(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,3)))){
C_save_and_reclaim((void *)f_9309,2,av);}
a=C_alloc(23);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)((C_word*)t0)[3])[1];
t9=((C_word*)t0)[4];
t10=C_i_check_list_2(t9,lf[127]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9267,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9269,a[2]=t6,a[3]=t13,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_9269(t15,t11,t9);}

/* k9310 in k9303 in a9243 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9312(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_9312,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t1;
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
f_9309(2,av2);}}
else{
/* support.scm:580: ##sys#symbol->string */
t3=*((C_word*)lf[182]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k9317 in k9310 in k9303 in a9243 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9319(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_9319,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list2(&a,2,((C_word*)t0)[3],t1);
f_9309(2,av2);}}

/* k9331 in a9243 in k9105 in k8860 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9333(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,1)))){
C_save_and_reclaim((void *)f_9333,2,av);}
a=C_alloc(29);
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_s_a_i_plus(&a,2,t2,C_fix(1)));
t4=((C_word*)t0)[3];
f_9305(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_9305(t2,C_SCHEME_FALSE);}}

/* k9437 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,1)))){
C_save_and_reclaim((void *)f_9439,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[143],lf[181],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1695 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9441(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9441,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9466,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:583: g1701 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9464 in map-loop1695 in walk in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9466(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9466,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9441(t6,((C_word*)t0)[5],t5);}

/* k9482 in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9484(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_9484,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9487,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(C_i_positivep(t4))){
/* support.scm:586: debugging */
t5=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[191];
av2[3]=lf[192];
av2[4]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t5=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t5;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k9485 in k9482 in chicken.compiler.support#build-node-graph in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_9487,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9493(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_9493,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9499,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];{
C_word *av2=av;
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
f_9499(3,av2);}}

/* walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9499(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_9499,3,av);}
a=C_alloc(8);
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=t2;
t10=C_slot(t9,C_fix(1));
t11=t10;
t12=t11;
t13=C_eqp(t12,lf[160]);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9533,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=t11,a[6]=t12,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t13)){
t15=t14;
f_9533(t15,t13);}
else{
t15=C_eqp(t12,lf[204]);
t16=t14;
f_9533(t16,(C_truep(t15)?t15:C_eqp(t12,lf[205])));}}

/* k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,0,5)))){
C_save_and_reclaim_args((void *)trf_9533,2,t0,t1);}
a=C_alloc(21);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=((C_word*)((C_word*)t0)[2])[1];
t7=C_i_check_list_2(((C_word*)t0)[3],lf[127]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9546,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9548,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9548(t12,t8,((C_word*)t0)[3]);}
else{
t2=C_eqp(((C_word*)t0)[6],lf[194]);
if(C_truep(t2)){
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_i_check_list_2(((C_word*)t0)[3],lf[127]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9603,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9605,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_9605(t13,t9,((C_word*)t0)[3]);}
else{
t3=C_eqp(((C_word*)t0)[6],lf[156]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_car(((C_word*)t0)[7]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[6],lf[87]);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[7]);
t6=C_booleanp(t5);
if(C_truep(t6)){
if(C_truep(t6)){
t7=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t7;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_u_i_car(((C_word*)t0)[7]);
t8=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t8;
av2[1]=C_a_i_list(&a,2,lf[87],t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t7=C_i_stringp(t5);
if(C_truep(t7)){
if(C_truep(t7)){
t8=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t8;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_u_i_car(((C_word*)t0)[7]);
t9=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t9;
av2[1]=C_a_i_list(&a,2,lf[87],t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t8=C_i_numberp(t5);
t9=(C_truep(t8)?t8:C_charp(t5));
if(C_truep(t9)){
t10=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t10;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_u_i_car(((C_word*)t0)[7]);
t11=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t11;
av2[1]=C_a_i_list(&a,2,lf[87],t10);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}}}
else{
t5=C_eqp(((C_word*)t0)[6],lf[98]);
if(C_truep(t5)){
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=((C_word*)t0)[7];
t11=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t12=t11;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t13)[1];
t15=((C_word*)((C_word*)t0)[2])[1];
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9703,a[2]=t10,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t8,a[7]=t9,a[8]=t13,a[9]=t15,a[10]=t14,tmp=(C_word)a,a+=11,tmp);
/* support.scm:605: chicken.base#butlast */
t17=*((C_word*)lf[195]+1);{
C_word av2[3];
av2[0]=t17;
av2[1]=t16;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t17+1)))(3,av2);}}
else{
t6=C_eqp(((C_word*)t0)[6],lf[120]);
if(C_truep(t6)){
t7=C_i_cadr(((C_word*)t0)[7]);
t8=(C_truep(t7)?lf[167]:lf[120]);
t9=t8;
t10=C_i_caddr(((C_word*)t0)[7]);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9826,a[2]=((C_word*)t0)[4],a[3]=t9,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t13=C_i_car(((C_word*)t0)[3]);
/* support.scm:612: walk */
t14=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
f_9499(3,av2);}}
else{
t7=C_eqp(((C_word*)t0)[6],lf[168]);
if(C_truep(t7)){
t8=C_i_car(((C_word*)t0)[7]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9850,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=C_i_car(((C_word*)t0)[3]);
/* support.scm:614: walk */
t12=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
f_9499(3,av2);}}
else{
t8=C_eqp(((C_word*)t0)[6],lf[197]);
if(C_truep(t8)){
t9=C_i_car(((C_word*)t0)[3]);
/* support.scm:616: walk */
t10=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t10;
av2[1]=((C_word*)t0)[4];
av2[2]=t9;
f_9499(3,av2);}}
else{
t9=C_eqp(((C_word*)t0)[6],lf[169]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9884,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t11=C_i_car(((C_word*)t0)[3]);
/* support.scm:619: walk */
t12=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
f_9499(3,av2);}}
else{
t10=C_eqp(((C_word*)t0)[6],lf[181]);
if(C_truep(t10)){
t11=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t12=t11;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t13)[1];
t15=((C_word*)((C_word*)t0)[2])[1];
t16=C_i_check_list_2(((C_word*)t0)[3],lf[127]);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9974,a[2]=t13,a[3]=t18,a[4]=t15,a[5]=t14,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_9974(t20,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=C_eqp(((C_word*)t0)[6],lf[190]);
if(C_truep(t11)){
t12=C_i_car(((C_word*)t0)[7]);
t13=t12;
t14=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t15=t14;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=((C_word*)t16)[1];
t18=((C_word*)((C_word*)t0)[2])[1];
t19=C_i_check_list_2(((C_word*)t0)[3],lf[127]);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10029,a[2]=((C_word*)t0)[4],a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10031,a[2]=t16,a[3]=t22,a[4]=t18,a[5]=t17,tmp=(C_word)a,a+=6,tmp));
t24=((C_word*)t22)[1];
f_10031(t24,t20,((C_word*)t0)[3]);}
else{
t12=C_eqp(((C_word*)t0)[6],lf[161]);
if(C_truep(t12)){
t13=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t13;
av2[1]=C_a_i_list1(&a,1,((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t13=C_eqp(((C_word*)t0)[6],lf[199]);
if(C_truep(t13)){
t14=C_i_car(((C_word*)t0)[7]);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10087,a[2]=((C_word*)t0)[2],a[3]=t16,tmp=(C_word)a,a+=4,tmp));
t18=((C_word*)t16)[1];
f_10087(t18,((C_word*)t0)[4],t14,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t14=C_eqp(((C_word*)t0)[6],lf[200]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_10137(t16,t14);}
else{
t16=C_eqp(((C_word*)t0)[6],lf[201]);
if(C_truep(t16)){
t17=t15;
f_10137(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[6],lf[202]);
t18=t15;
f_10137(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[6],lf[203])));}}}}}}}}}}}}}}}}

/* k9544 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_9546,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop1752 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9548,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9573,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:595: g1758 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9571 in map-loop1752 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9573,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9548(t6,((C_word*)t0)[5],t5);}

/* k9601 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9603(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_9603,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[194],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1781 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9605(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9605,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9630,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:597: g1787 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9628 in map-loop1781 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9630,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9605(t6,((C_word*)t0)[5],t5);}

/* k9701 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9703(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,3)))){
C_save_and_reclaim((void *)f_9703,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9773,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9773(t6,t2,t1);}

/* k9704 in k9701 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9706(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_9706,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[127]);
t3=C_i_check_list_2(t1,lf[127]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9725,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_9725(t8,t4,((C_word*)t0)[2],t1);}

/* k9713 in k9704 in k9701 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_9715,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9719,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9723,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:606: last */
f_5910(t4,((C_word*)t0)[4]);}

/* k9717 in k9713 in k9704 in k9701 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9719(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9719,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[98],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9721 in k9713 in k9704 in k9701 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9723(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_9723,2,av);}
/* support.scm:606: walk */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_9499(3,av2);}}

/* map-loop1823 in k9704 in k9701 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9725(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_9725,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* map-loop1844 in k9701 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9773(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9773,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9798,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:605: g1850 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9796 in map-loop1844 in k9701 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9798,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9773(t6,((C_word*)t0)[5],t5);}

/* k9824 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9826,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list3(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9848 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9850,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[196],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9882 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_9884,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9888,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
t5=C_i_cdr(((C_word*)t0)[4]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9898,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_9898(t9,t3,t4,t5);}

/* k9886 in k9882 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_9888,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[198],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* loop in k9882 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9898(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_9898,4,t0,t1,t2,t3);}
a=C_alloc(7);
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9922,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_i_car(t3);
/* support.scm:624: walk */
t6=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
f_9499(3,av2);}}}
else{
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9949,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=C_i_car(t3);
/* support.scm:625: walk */
t8=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
f_9499(3,av2);}}}

/* k9920 in loop in k9882 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9922(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,1)))){
C_save_and_reclaim((void *)f_9922,2,av);}
a=C_alloc(9);
t2=C_a_i_list(&a,2,lf[170],t1);
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_a_i_list(&a,1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9935 in k9947 in loop in k9882 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9937(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_9937,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9947 in loop in k9882 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_9949,2,av);}
a=C_alloc(10);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9937,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
t7=((C_word*)t0)[5];
t8=C_u_i_cdr(t7);
/* support.scm:626: loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_9898(t9,t4,t6,t8);}

/* map-loop1893 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_fcall f_9974(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_9974,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9999,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:628: g1899 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9997 in map-loop1893 in k9531 in walk in chicken.compiler.support#build-expression-tree in k8257 in k7604 in k7601 in k6449 in k5137 in k5134 in k5131 in k5128 in k5125 in k5122 in k5119 in k5116 in k5113 */
static void C_ccall f_9999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_9999,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9974(t6,((C_word*)t0)[5],t5);}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_support_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("support"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void*)C_support_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(3900))){
C_save(t1);
C_rereclaim2(3900*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,529);
lf[0]=C_h_intern(&lf[0],7, C_text("support"));
lf[1]=C_h_intern(&lf[1],25, C_text("chicken.compiler.support#"));
lf[8]=C_h_intern(&lf[8],36, C_text("chicken.compiler.support#number-type"));
lf[9]=C_h_intern(&lf[9],7, C_text("generic"));
lf[10]=C_h_intern(&lf[10],31, C_text("chicken.compiler.support#unsafe"));
lf[11]=C_h_intern(&lf[11],46, C_text("chicken.compiler.support#compiler-cleanup-hook"));
lf[12]=C_h_intern(&lf[12],42, C_text("chicken.compiler.support#debugging-chicken"));
lf[13]=C_h_intern(&lf[13],29, C_text("chicken.compiler.support#bomb"));
lf[14]=C_h_intern(&lf[14],18, C_text("chicken.base#error"));
lf[15]=C_h_intern(&lf[15],20, C_text("scheme#string-append"));
lf[16]=C_decode_literal(C_heaptop,C_text("\376B\000\000\032[internal compiler error] "));
lf[17]=C_decode_literal(C_heaptop,C_text("\376B\000\000\031[internal compiler error]"));
lf[18]=C_h_intern(&lf[18],51, C_text("chicken.compiler.support#collected-debugging-output"));
lf[20]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001o\376\003\000\000\002\376\001\000\000\001\001x\376\003\000\000\002\376\001\000\000\001\001S\376\377\016"));
lf[22]=C_h_intern(&lf[22],34, C_text("chicken.compiler.support#debugging"));
lf[23]=C_h_intern(&lf[23],14, C_text("scheme#newline"));
lf[24]=C_h_intern(&lf[24],21, C_text("##sys#standard-output"));
lf[25]=C_h_intern(&lf[25],6, C_text("printf"));
lf[26]=C_h_intern(&lf[26],18, C_text("##sys#write-char-0"));
lf[27]=C_h_intern(&lf[27],11, C_text("##sys#print"));
lf[28]=C_h_intern(&lf[28],12, C_text("scheme#force"));
lf[29]=C_h_intern(&lf[29],14, C_text("scheme#display"));
lf[30]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002: "));
lf[31]=C_h_intern(&lf[31],34, C_text("chicken.port#with-output-to-string"));
lf[32]=C_h_intern(&lf[32],7, C_text("fprintf"));
lf[33]=C_h_intern(&lf[33],25, C_text("chicken.base#flush-output"));
lf[34]=C_h_intern(&lf[34],46, C_text("chicken.compiler.support#with-debugging-output"));
lf[35]=C_h_intern(&lf[35],27, C_text("chicken.string#string-split"));
lf[36]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\012"));
lf[37]=C_h_intern(&lf[37],39, C_text("chicken.compiler.support#quit-compiling"));
lf[38]=C_h_intern(&lf[38],20, C_text("##sys#standard-error"));
lf[39]=C_h_intern(&lf[39],17, C_text("chicken.base#exit"));
lf[40]=C_h_intern(&lf[40],22, C_text("chicken.format#fprintf"));
lf[41]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010\012Error: "));
lf[42]=C_h_intern(&lf[42],23, C_text("##sys#syntax-error-hook"));
lf[43]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005\011~s~%"));
lf[44]=C_h_intern(&lf[44],8, C_text("for-each"));
lf[45]=C_h_intern(&lf[45],29, C_text("chicken.base#print-call-chain"));
lf[46]=C_h_intern(&lf[46],20, C_text("##sys#current-thread"));
lf[47]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025\012\011Expansion history:\012"));
lf[48]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003): "));
lf[49]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017\012Syntax error ("));
lf[50]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017\012Syntax error: "));
lf[51]=C_h_intern(&lf[51],27, C_text("chicken.syntax#syntax-error"));
lf[52]=C_h_intern(&lf[52],47, C_text("chicken.compiler.support#emit-syntax-trace-info"));
lf[53]=C_h_intern(&lf[53],40, C_text("chicken.compiler.support#check-signature"));
lf[54]=C_decode_literal(C_heaptop,C_text("\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A"));
lf[55]=C_h_intern(&lf[55],34, C_text("chicken.compiler.support#real-name"));
lf[56]=C_h_intern(&lf[56],42, C_text("chicken.compiler.support#build-lambda-list"));
lf[57]=C_h_intern(&lf[57],37, C_text("chicken.compiler.support#c-ify-string"));
lf[58]=C_h_intern(&lf[58],18, C_text("##sys#list->string"));
lf[59]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\377\012\000\000\042\376\377\016"));
lf[60]=C_h_intern(&lf[60],13, C_text("scheme#append"));
lf[61]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\377\012\000\000\134\376\377\016"));
lf[62]=C_h_intern(&lf[62],18, C_text("##sys#string->list"));
lf[63]=C_h_intern(&lf[63],20, C_text("##sys#fixnum->string"));
lf[64]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016"));
lf[65]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\377\012\000\0000\376\377\016"));
lf[66]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\003\000\000\002\376\377\012\000\000\052\376\377\016"));
lf[67]=C_h_intern(&lf[67],44, C_text("chicken.compiler.support#valid-c-identifier\077"));
lf[68]=C_h_intern(&lf[68],23, C_text("chicken.string#->string"));
lf[69]=C_h_intern(&lf[69],37, C_text("chicken.compiler.support#bytes->words"));
lf[70]=C_h_intern(&lf[70],37, C_text("chicken.compiler.support#words->bytes"));
lf[71]=C_h_intern(&lf[71],50, C_text("chicken.compiler.support#check-and-open-input-file"));
lf[72]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001-"));
lf[73]=C_h_intern(&lf[73],20, C_text("##sys#standard-input"));
lf[74]=C_h_intern(&lf[74],22, C_text("scheme#open-input-file"));
lf[75]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024Can not open file ~s"));
lf[76]=C_decode_literal(C_heaptop,C_text("\376B\000\000\031(~a) can not open file ~s"));
lf[77]=C_h_intern(&lf[77],25, C_text("chicken.file#file-exists\077"));
lf[78]=C_h_intern(&lf[78],49, C_text("chicken.compiler.support#close-checked-input-file"));
lf[79]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001-"));
lf[80]=C_h_intern(&lf[80],23, C_text("scheme#close-input-port"));
lf[81]=C_h_intern(&lf[81],35, C_text("chicken.compiler.support#fold-inner"));
lf[82]=C_h_intern(&lf[82],14, C_text("scheme#reverse"));
lf[84]=C_h_intern(&lf[84],41, C_text("chicken.compiler.support#read-expressions"));
lf[85]=C_h_intern(&lf[85],11, C_text("scheme#read"));
lf[86]=C_h_intern(&lf[86],34, C_text("chicken.compiler.support#constant\077"));
lf[87]=C_h_intern(&lf[87],5, C_text("quote"));
lf[88]=C_h_intern(&lf[88],20, C_text("##sys#srfi-4-vector\077"));
lf[89]=C_h_intern(&lf[89],18, C_text("chicken.blob#blob\077"));
lf[90]=C_h_intern(&lf[90],45, C_text("chicken.compiler.support#collapsable-literal\077"));
lf[91]=C_h_intern(&lf[91],35, C_text("chicken.compiler.support#immediate\077"));
lf[92]=C_h_intern(&lf[92],36, C_text("chicken.compiler.support#big-fixnum\077"));
lf[93]=C_h_intern(&lf[93],39, C_text("chicken.compiler.support#basic-literal\077"));
lf[94]=C_h_intern(&lf[94],19, C_text("scheme#vector->list"));
lf[95]=C_h_intern(&lf[95],48, C_text("chicken.compiler.support#canonicalize-begin-body"));
lf[96]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\020\001##core#undefined\376\377\016"));
lf[97]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\020\001##core#undefined\376\377\016"));
lf[98]=C_h_intern(&lf[98],3, C_text("let"));
lf[99]=C_h_intern(&lf[99],19, C_text("chicken.base#gensym"));
lf[100]=C_h_intern(&lf[100],1, C_text("t"));
lf[101]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\012\001##sys#void\376\377\016"));
lf[102]=C_h_intern(&lf[102],37, C_text("chicken.compiler.support#string->expr"));
lf[103]=C_decode_literal(C_heaptop,C_text("\376B\000\000\042cannot parse expression: ~s [~a]~%"));
lf[104]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\020\001##core#undefined\376\377\016"));
lf[105]=C_h_intern(&lf[105],5, C_text("begin"));
lf[106]=C_h_intern(&lf[106],13, C_text("scheme#values"));
lf[107]=C_h_intern(&lf[107],35, C_text("chicken.port#with-input-from-string"));
lf[108]=C_h_intern(&lf[108],40, C_text("chicken.condition#with-exception-handler"));
lf[109]=C_h_intern(&lf[109],37, C_text("scheme#call-with-current-continuation"));
lf[110]=C_h_intern(&lf[110],37, C_text("chicken.compiler.support#llist-length"));
lf[111]=C_h_intern(&lf[111],37, C_text("chicken.compiler.support#llist-match\077"));
lf[113]=C_h_intern(&lf[113],56, C_text("chicken.compiler.support#reset-profile-info-vector-name!"));
lf[114]=C_h_intern(&lf[114],41, C_text("chicken.compiler.support#make-random-name"));
lf[115]=C_h_intern(&lf[115],12, C_text("profile-info"));
lf[118]=C_h_intern(&lf[118],46, C_text("chicken.compiler.support#expand-profile-lambda"));
lf[119]=C_h_intern(&lf[119],19, C_text("##sys#profile-entry"));
lf[120]=C_h_intern(&lf[120],13, C_text("##core#lambda"));
lf[121]=C_h_intern(&lf[121],11, C_text("##sys#apply"));
lf[122]=C_h_intern(&lf[122],18, C_text("##sys#profile-exit"));
lf[123]=C_h_intern(&lf[123],18, C_text("##sys#dynamic-wind"));
lf[124]=C_h_intern(&lf[124],47, C_text("chicken.compiler.support#profiling-prelude-exps"));
lf[125]=C_h_intern(&lf[125],27, C_text("##sys#register-profile-info"));
lf[126]=C_h_intern(&lf[126],4, C_text("set!"));
lf[127]=C_h_intern(&lf[127],3, C_text("map"));
lf[128]=C_h_intern(&lf[128],30, C_text("##sys#set-profile-info-vector!"));
lf[129]=C_h_intern(&lf[129],31, C_text("chicken.compiler.support#db-get"));
lf[130]=C_h_intern(&lf[130],31, C_text("chicken.internal#hash-table-ref"));
lf[131]=C_h_intern(&lf[131],35, C_text("chicken.compiler.support#db-get-all"));
lf[132]=C_h_intern(&lf[132],5, C_text("foldr"));
lf[133]=C_h_intern(&lf[133],32, C_text("chicken.compiler.support#db-put!"));
lf[134]=C_h_intern(&lf[134],32, C_text("chicken.internal#hash-table-set!"));
lf[135]=C_h_intern(&lf[135],33, C_text("chicken.compiler.support#collect!"));
lf[136]=C_h_intern(&lf[136],36, C_text("chicken.compiler.support#db-get-list"));
lf[137]=C_h_intern(&lf[137],33, C_text("chicken.compiler.support#get-line"));
lf[138]=C_h_intern(&lf[138],26, C_text("##sys#line-number-database"));
lf[139]=C_h_intern(&lf[139],35, C_text("chicken.compiler.support#get-line-2"));
lf[140]=C_h_intern(&lf[140],53, C_text("chicken.compiler.support#display-line-number-database"));
lf[141]=C_h_intern(&lf[141],36, C_text("chicken.internal#hash-table-for-each"));
lf[142]=C_h_intern(&lf[142],34, C_text("chicken.compiler.support#make-node"));
lf[143]=C_h_intern(&lf[143],29, C_text("chicken.compiler.support#node"));
lf[144]=C_h_intern(&lf[144],30, C_text("chicken.compiler.support#node\077"));
lf[145]=C_h_intern(&lf[145],35, C_text("chicken.compiler.support#node-class"));
lf[146]=C_h_intern(&lf[146],10, C_text("node-class"));
lf[147]=C_h_intern(&lf[147],40, C_text("chicken.compiler.support#node-class-set!"));
lf[148]=C_h_intern(&lf[148],16, C_text("##sys#block-set!"));
lf[149]=C_h_intern(&lf[149],40, C_text("chicken.compiler.support#node-parameters"));
lf[150]=C_h_intern(&lf[150],15, C_text("node-parameters"));
lf[151]=C_h_intern(&lf[151],45, C_text("chicken.compiler.support#node-parameters-set!"));
lf[152]=C_h_intern(&lf[152],44, C_text("chicken.compiler.support#node-subexpressions"));
lf[153]=C_h_intern(&lf[153],19, C_text("node-subexpressions"));
lf[154]=C_h_intern(&lf[154],49, C_text("chicken.compiler.support#node-subexpressions-set!"));
lf[155]=C_h_intern(&lf[155],32, C_text("chicken.compiler.support#varnode"));
lf[156]=C_h_intern(&lf[156],15, C_text("##core#variable"));
lf[157]=C_h_intern(&lf[157],30, C_text("chicken.compiler.support#qnode"));
lf[158]=C_h_intern(&lf[158],41, C_text("chicken.compiler.support#build-node-graph"));
lf[159]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016bad expression"));
lf[160]=C_h_intern(&lf[160],2, C_text("if"));
lf[161]=C_h_intern(&lf[161],16, C_text("##core#undefined"));
lf[162]=C_h_intern(&lf[162],21, C_text("scheme#inexact->exact"));
lf[163]=C_h_intern(&lf[163],15, C_text("scheme#truncate"));
lf[164]=C_h_intern(&lf[164],20, C_text("chicken.base#warning"));
lf[165]=C_decode_literal(C_heaptop,C_text("\376B\000\0006literal is out of range - will be truncated to integer"));
lf[166]=C_h_intern(&lf[166],6, C_text("fixnum"));
lf[167]=C_h_intern(&lf[167],6, C_text("lambda"));
lf[168]=C_h_intern(&lf[168],10, C_text("##core#the"));
lf[169]=C_h_intern(&lf[169],15, C_text("##core#typecase"));
lf[170]=C_h_intern(&lf[170],4, C_text("else"));
lf[171]=C_h_intern(&lf[171],12, C_text("scheme#cadar"));
lf[172]=C_h_intern(&lf[172],1, C_text("\052"));
lf[173]=C_h_intern(&lf[173],16, C_text("##core#primitive"));
lf[174]=C_h_intern(&lf[174],13, C_text("##core#inline"));
lf[175]=C_h_intern(&lf[175],18, C_text("##core#debug-event"));
lf[176]=C_h_intern(&lf[176],11, C_text("##core#proc"));
lf[177]=C_h_intern(&lf[177],11, C_text("##core#set!"));
lf[178]=C_h_intern(&lf[178],31, C_text("##core#foreign-callback-wrapper"));
lf[179]=C_h_intern(&lf[179],22, C_text("##core#inline_allocate"));
lf[180]=C_h_intern(&lf[180],10, C_text("##core#app"));
lf[181]=C_h_intern(&lf[181],11, C_text("##core#call"));
lf[182]=C_h_intern(&lf[182],20, C_text("##sys#symbol->string"));
lf[183]=C_h_intern(&lf[183],9, C_text("##sys#get"));
lf[184]=C_h_intern(&lf[184],36, C_text("##compiler#always-bound-to-procedure"));
lf[185]=C_h_intern(&lf[185],17, C_text("##core#inline_ref"));
lf[186]=C_h_intern(&lf[186],20, C_text("##core#inline_update"));
lf[187]=C_h_intern(&lf[187],21, C_text("##core#inline_loc_ref"));
lf[188]=C_h_intern(&lf[188],24, C_text("##core#inline_loc_update"));
lf[189]=C_h_intern(&lf[189],14, C_text("##core#provide"));
lf[190]=C_h_intern(&lf[190],15, C_text("##core#callunit"));
lf[191]=C_h_intern(&lf[191],1, C_text("o"));
lf[192]=C_decode_literal(C_heaptop,C_text("\376B\000\000\033eliminated procedure checks"));
lf[193]=C_h_intern(&lf[193],46, C_text("chicken.compiler.support#build-expression-tree"));
lf[194]=C_h_intern(&lf[194],14, C_text("##core#closure"));
lf[195]=C_h_intern(&lf[195],20, C_text("chicken.base#butlast"));
lf[196]=C_h_intern(&lf[196],3, C_text("the"));
lf[197]=C_h_intern(&lf[197],17, C_text("##core#the/result"));
lf[198]=C_h_intern(&lf[198],17, C_text("compiler-typecase"));
lf[199]=C_h_intern(&lf[199],11, C_text("##core#bind"));
lf[200]=C_h_intern(&lf[200],12, C_text("##core#unbox"));
lf[201]=C_h_intern(&lf[201],10, C_text("##core#ref"));
lf[202]=C_h_intern(&lf[202],13, C_text("##core#update"));
lf[203]=C_h_intern(&lf[203],15, C_text("##core#update_i"));
lf[204]=C_h_intern(&lf[204],10, C_text("##core#box"));
lf[205]=C_h_intern(&lf[205],11, C_text("##core#cond"));
lf[206]=C_h_intern(&lf[206],37, C_text("chicken.compiler.support#fold-boolean"));
lf[207]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\005C_and\376\377\016"));
lf[208]=C_h_intern(&lf[208],47, C_text("chicken.compiler.support#inline-lambda-bindings"));
lf[209]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_a_i_list"));
lf[210]=C_h_intern(&lf[210],22, C_text("chicken.base#alist-ref"));
lf[211]=C_h_intern(&lf[211],10, C_text("scheme#eq\077"));
lf[212]=C_h_intern(&lf[212],12, C_text("contractable"));
lf[213]=C_h_intern(&lf[213],16, C_text("inline-transient"));
lf[214]=C_h_intern(&lf[214],1, C_text("f"));
lf[215]=C_h_intern(&lf[215],27, C_text("##sys#decompose-lambda-list"));
lf[216]=C_h_intern(&lf[216],34, C_text("chicken.compiler.support#tree-copy"));
lf[217]=C_h_intern(&lf[217],34, C_text("chicken.compiler.support#copy-node"));
lf[218]=C_h_intern(&lf[218],35, C_text("chicken.compiler.support#copy-node!"));
lf[219]=C_h_intern(&lf[219],48, C_text("chicken.compiler.support#emit-global-inline-file"));
lf[220]=C_h_intern(&lf[220],18, C_text("chicken.base#print"));
lf[221]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002  "));
lf[222]=C_h_intern(&lf[222],15, C_text("scheme#string<\077"));
lf[223]=C_h_intern(&lf[223],21, C_text("scheme#symbol->string"));
lf[224]=C_h_intern(&lf[224],17, C_text("chicken.sort#sort"));
lf[225]=C_h_intern(&lf[225],1, C_text("i"));
lf[226]=C_decode_literal(C_heaptop,C_text("\376B\000\0001the following procedures can be globally inlined:"));
lf[227]=C_h_intern(&lf[227],25, C_text("chicken.file#delete-file\052"));
lf[228]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015; END OF FILE"));
lf[229]=C_h_intern(&lf[229],23, C_text("chicken.pretty-print#pp"));
lf[230]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027; GENERATED BY CHICKEN "));
lf[231]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006 FROM "));
lf[232]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001\012"));
lf[233]=C_h_intern(&lf[233],32, C_text("chicken.platform#chicken-version"));
lf[234]=C_h_intern(&lf[234],26, C_text("scheme#with-output-to-file"));
lf[235]=C_h_intern(&lf[235],11, C_text("local-value"));
lf[236]=C_h_intern(&lf[236],5, C_text("value"));
lf[237]=C_h_intern(&lf[237],9, C_text("inlinable"));
lf[238]=C_h_intern(&lf[238],3, C_text("yes"));
lf[239]=C_h_intern(&lf[239],2, C_text("no"));
lf[240]=C_h_intern(&lf[240],17, C_text("##compiler#inline"));
lf[241]=C_h_intern(&lf[241],11, C_text("hidden-refs"));
lf[242]=C_h_intern(&lf[242],7, C_text("unknown"));
lf[243]=C_h_intern(&lf[243],24, C_text("##compiler#inline-global"));
lf[244]=C_h_intern(&lf[244],42, C_text("chicken.compiler.support#variable-visible\077"));
lf[245]=C_h_intern(&lf[245],41, C_text("chicken.compiler.support#load-inline-file"));
lf[246]=C_h_intern(&lf[246],10, C_text("##sys#put!"));
lf[247]=C_h_intern(&lf[247],27, C_text("scheme#with-input-from-file"));
lf[248]=C_h_intern(&lf[248],35, C_text("chicken.compiler.support#match-node"));
lf[249]=C_h_intern(&lf[249],1, C_text("a"));
lf[250]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007matched"));
lf[251]=C_h_intern(&lf[251],53, C_text("chicken.compiler.support#expression-has-side-effects\077"));
lf[252]=C_h_intern(&lf[252],49, C_text("chicken.compiler.support#foreign-callback-stub-id"));
lf[253]=C_h_intern(&lf[253],47, C_text("chicken.compiler.support#foreign-callback-stubs"));
lf[254]=C_h_intern(&lf[254],44, C_text("chicken.compiler.support#simple-lambda-node\077"));
lf[255]=C_h_intern(&lf[255],47, C_text("chicken.compiler.support#dump-undefined-globals"));
lf[256]=C_h_intern(&lf[256],12, C_text("scheme#write"));
lf[257]=C_h_intern(&lf[257],6, C_text("global"));
lf[258]=C_h_intern(&lf[258],8, C_text("assigned"));
lf[259]=C_h_intern(&lf[259],24, C_text("chicken.keyword#keyword\077"));
lf[260]=C_h_intern(&lf[260],45, C_text("chicken.compiler.support#dump-defined-globals"));
lf[261]=C_h_intern(&lf[261],41, C_text("chicken.compiler.support#dump-global-refs"));
lf[262]=C_h_intern(&lf[262],10, C_text("references"));
lf[263]=C_h_intern(&lf[263],30, C_text("##sys#toplevel-definition-hook"));
lf[264]=C_h_intern(&lf[264],22, C_text("chicken.plist#remprop!"));
lf[265]=C_h_intern(&lf[265],21, C_text("##compiler#visibility"));
lf[266]=C_h_intern(&lf[266],41, C_text("chicken.compiler.support#variable-hidden\077"));
lf[267]=C_h_intern(&lf[267],38, C_text("chicken.compiler.support#hide-variable"));
lf[268]=C_decode_literal(C_heaptop,C_text("\376B\000\000 hiding unexported module binding"));
lf[269]=C_h_intern(&lf[269],51, C_text("chicken.compiler.support#make-foreign-callback-stub"));
lf[270]=C_h_intern(&lf[270],46, C_text("chicken.compiler.support#foreign-callback-stub"));
lf[271]=C_h_intern(&lf[271],47, C_text("chicken.compiler.support#foreign-callback-stub\077"));
lf[272]=C_h_intern(&lf[272],24, C_text("foreign-callback-stub-id"));
lf[273]=C_h_intern(&lf[273],51, C_text("chicken.compiler.support#foreign-callback-stub-name"));
lf[274]=C_h_intern(&lf[274],26, C_text("foreign-callback-stub-name"));
lf[275]=C_h_intern(&lf[275],57, C_text("chicken.compiler.support#foreign-callback-stub-qualifiers"));
lf[276]=C_h_intern(&lf[276],32, C_text("foreign-callback-stub-qualifiers"));
lf[277]=C_h_intern(&lf[277],58, C_text("chicken.compiler.support#foreign-callback-stub-return-type"));
lf[278]=C_h_intern(&lf[278],33, C_text("foreign-callback-stub-return-type"));
lf[279]=C_h_intern(&lf[279],61, C_text("chicken.compiler.support#foreign-callback-stub-argument-types"));
lf[280]=C_h_intern(&lf[280],36, C_text("foreign-callback-stub-argument-types"));
lf[281]=C_h_intern(&lf[281],56, C_text("chicken.compiler.support#register-foreign-callback-stub!"));
lf[282]=C_h_intern(&lf[282],26, C_text("##compiler#callback-lambda"));
lf[284]=C_h_intern(&lf[284],50, C_text("chicken.compiler.support#clear-foreign-type-table!"));
lf[285]=C_h_intern(&lf[285],19, C_text("scheme#vector-fill!"));
lf[286]=C_h_intern(&lf[286],18, C_text("scheme#make-vector"));
lf[287]=C_h_intern(&lf[287],47, C_text("chicken.compiler.support#register-foreign-type!"));
lf[288]=C_h_intern(&lf[288],44, C_text("chicken.compiler.support#lookup-foreign-type"));
lf[289]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007\001integer\376B\000\000\003int\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001unsigned-integer\376B\000\000\014unsigned int"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001integer32\376B\000\000\005C_s32\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022\001unsigned-integer32\376B\000\000\005C_u32\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001integer64\376B\000\000\005C_s64\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022\001unsigned-integer64\376B\000\000\005C_u64\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\005\001short\376B\000\000\005short\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001unsigned-short\376B\000\000\016unsigned short\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\004\001long\376B\000\000\004long\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015\001unsigned-long\376B\000\000\015unsigned long\376\003\000\000\002\376"
"\003\000\000\002\376\001\000\000\007\001ssize_t\376B\000\000\007ssize_t\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001size_t\376B\000\000\006size_t\376\377\016"));
lf[290]=C_h_intern(&lf[290],43, C_text("chicken.compiler.support#foreign-type-check"));
lf[291]=C_h_intern(&lf[291],4, C_text("char"));
lf[292]=C_h_intern(&lf[292],13, C_text("unsigned-char"));
lf[293]=C_h_intern(&lf[293],27, C_text("##sys#foreign-char-argument"));
lf[294]=C_h_intern(&lf[294],3, C_text("int"));
lf[295]=C_h_intern(&lf[295],29, C_text("##sys#foreign-fixnum-argument"));
lf[296]=C_h_intern(&lf[296],5, C_text("float"));
lf[297]=C_h_intern(&lf[297],29, C_text("##sys#foreign-flonum-argument"));
lf[298]=C_h_intern(&lf[298],4, C_text("blob"));
lf[299]=C_h_intern(&lf[299],14, C_text("scheme-pointer"));
lf[300]=C_h_intern(&lf[300],28, C_text("##sys#foreign-block-argument"));
lf[301]=C_h_intern(&lf[301],12, C_text("##core#quote"));
lf[302]=C_h_intern(&lf[302],9, C_text("##core#if"));
lf[303]=C_h_intern(&lf[303],10, C_text("##core#let"));
lf[304]=C_h_intern(&lf[304],22, C_text("nonnull-scheme-pointer"));
lf[305]=C_h_intern(&lf[305],12, C_text("nonnull-blob"));
lf[306]=C_h_intern(&lf[306],14, C_text("pointer-vector"));
lf[307]=C_h_intern(&lf[307],37, C_text("##sys#foreign-struct-wrapper-argument"));
lf[308]=C_h_intern(&lf[308],22, C_text("nonnull-pointer-vector"));
lf[309]=C_h_intern(&lf[309],8, C_text("u8vector"));
lf[310]=C_h_intern(&lf[310],16, C_text("nonnull-u8vector"));
lf[311]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001nonnull-u8vector\376\001\000\000\010\001u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021\001nonnull-u16vector\376"
"\001\000\000\011\001u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001nonnull-s8vector\376\001\000\000\010\001s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021\001nonn"
"ull-s16vector\376\001\000\000\011\001s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021\001nonnull-u32vector\376\001\000\000\011\001u32vector\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\021\001nonnull-s32vector\376\001\000\000\011\001s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021\001nonnull-u64vector\376\001\000"
"\000\011\001u64vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021\001nonnull-s64vector\376\001\000\000\011\001s64vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021\001nonn"
"ull-f32vector\376\001\000\000\011\001f32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021\001nonnull-f64vector\376\001\000\000\011\001f64vector\376\377\016"));
lf[312]=C_h_intern(&lf[312],9, C_text("integer32"));
lf[313]=C_h_intern(&lf[313],6, C_text("format"));
lf[314]=C_h_intern(&lf[314],13, C_text("foreign-value"));
lf[315]=C_h_intern(&lf[315],37, C_text("##sys#foreign-ranged-integer-argument"));
lf[316]=C_h_intern(&lf[316],30, C_text("chicken.base#get-output-string"));
lf[317]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014) \052 CHAR_BIT"));
lf[318]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007sizeof("));
lf[319]=C_h_intern(&lf[319],31, C_text("chicken.base#open-output-string"));
lf[320]=C_h_intern(&lf[320],14, C_text("unsigned-short"));
lf[321]=C_h_intern(&lf[321],46, C_text("##sys#foreign-unsigned-ranged-integer-argument"));
lf[322]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014) \052 CHAR_BIT"));
lf[323]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007sizeof("));
lf[324]=C_h_intern(&lf[324],9, C_text("c-pointer"));
lf[325]=C_h_intern(&lf[325],30, C_text("##sys#foreign-pointer-argument"));
lf[326]=C_h_intern(&lf[326],17, C_text("nonnull-c-pointer"));
lf[327]=C_h_intern(&lf[327],8, C_text("c-string"));
lf[328]=C_h_intern(&lf[328],19, C_text("##sys#make-c-string"));
lf[329]=C_h_intern(&lf[329],29, C_text("##sys#foreign-string-argument"));
lf[330]=C_h_intern(&lf[330],16, C_text("nonnull-c-string"));
lf[331]=C_h_intern(&lf[331],6, C_text("symbol"));
lf[332]=C_h_intern(&lf[332],3, C_text("ref"));
lf[333]=C_h_intern(&lf[333],8, C_text("instance"));
lf[334]=C_h_intern(&lf[334],12, C_text("instance-ref"));
lf[335]=C_h_intern(&lf[335],4, C_text("this"));
lf[336]=C_h_intern(&lf[336],8, C_text("slot-ref"));
lf[337]=C_h_intern(&lf[337],16, C_text("nonnull-instance"));
lf[338]=C_h_intern(&lf[338],5, C_text("const"));
lf[339]=C_h_intern(&lf[339],4, C_text("enum"));
lf[340]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026sizeof(int) \052 CHAR_BIT"));
lf[341]=C_h_intern(&lf[341],15, C_text("nonnull-pointer"));
lf[342]=C_h_intern(&lf[342],7, C_text("pointer"));
lf[343]=C_h_intern(&lf[343],8, C_text("function"));
lf[344]=C_h_intern(&lf[344],17, C_text("nonnull-c-string\052"));
lf[345]=C_h_intern(&lf[345],26, C_text("nonnull-unsigned-c-string\052"));
lf[346]=C_h_intern(&lf[346],9, C_text("c-string\052"));
lf[347]=C_h_intern(&lf[347],17, C_text("unsigned-c-string"));
lf[348]=C_h_intern(&lf[348],18, C_text("unsigned-c-string\052"));
lf[349]=C_h_intern(&lf[349],13, C_text("c-string-list"));
lf[350]=C_h_intern(&lf[350],14, C_text("c-string-list\052"));
lf[351]=C_h_intern(&lf[351],13, C_text("unsigned-long"));
lf[352]=C_h_intern(&lf[352],16, C_text("unsigned-integer"));
lf[353]=C_h_intern(&lf[353],6, C_text("size_t"));
lf[354]=C_h_intern(&lf[354],18, C_text("unsigned-integer32"));
lf[355]=C_h_intern(&lf[355],18, C_text("unsigned-integer64"));
lf[356]=C_h_intern(&lf[356],9, C_text("integer64"));
lf[357]=C_h_intern(&lf[357],7, C_text("integer"));
lf[358]=C_h_intern(&lf[358],5, C_text("short"));
lf[359]=C_h_intern(&lf[359],4, C_text("long"));
lf[360]=C_h_intern(&lf[360],7, C_text("ssize_t"));
lf[361]=C_h_intern(&lf[361],17, C_text("nonnull-u16vector"));
lf[362]=C_h_intern(&lf[362],16, C_text("nonnull-s8vector"));
lf[363]=C_h_intern(&lf[363],17, C_text("nonnull-s16vector"));
lf[364]=C_h_intern(&lf[364],17, C_text("nonnull-u32vector"));
lf[365]=C_h_intern(&lf[365],17, C_text("nonnull-s32vector"));
lf[366]=C_h_intern(&lf[366],17, C_text("nonnull-u64vector"));
lf[367]=C_h_intern(&lf[367],17, C_text("nonnull-s64vector"));
lf[368]=C_h_intern(&lf[368],17, C_text("nonnull-f32vector"));
lf[369]=C_h_intern(&lf[369],17, C_text("nonnull-f64vector"));
lf[370]=C_h_intern(&lf[370],9, C_text("u16vector"));
lf[371]=C_h_intern(&lf[371],8, C_text("s8vector"));
lf[372]=C_h_intern(&lf[372],9, C_text("s16vector"));
lf[373]=C_h_intern(&lf[373],9, C_text("u32vector"));
lf[374]=C_h_intern(&lf[374],9, C_text("s32vector"));
lf[375]=C_h_intern(&lf[375],9, C_text("u64vector"));
lf[376]=C_h_intern(&lf[376],9, C_text("s64vector"));
lf[377]=C_h_intern(&lf[377],9, C_text("f32vector"));
lf[378]=C_h_intern(&lf[378],9, C_text("f64vector"));
lf[379]=C_h_intern(&lf[379],6, C_text("double"));
lf[380]=C_h_intern(&lf[380],6, C_text("number"));
lf[381]=C_h_intern(&lf[381],12, C_text("unsigned-int"));
lf[382]=C_h_intern(&lf[382],4, C_text("byte"));
lf[383]=C_h_intern(&lf[383],13, C_text("unsigned-byte"));
lf[384]=C_h_intern(&lf[384],5, C_text("int32"));
lf[385]=C_h_intern(&lf[385],14, C_text("unsigned-int32"));
lf[386]=C_decode_literal(C_heaptop,C_text("\376B\000\000\042foreign type `~S\047 refers to itself"));
lf[387]=C_h_intern(&lf[387],52, C_text("chicken.compiler.support#foreign-type-convert-result"));
lf[388]=C_h_intern(&lf[388],54, C_text("chicken.compiler.support#foreign-type-convert-argument"));
lf[389]=C_h_intern(&lf[389],43, C_text("chicken.compiler.support#final-foreign-type"));
lf[390]=C_decode_literal(C_heaptop,C_text("\376B\000\000\042foreign type `~S\047 refers to itself"));
lf[391]=C_h_intern(&lf[391],53, C_text("chicken.compiler.support#estimate-foreign-result-size"));
lf[392]=C_decode_literal(C_heaptop,C_text("\376B\000\0008cannot compute size for unknown foreign type `~S\047 result"));
lf[393]=C_h_intern(&lf[393],4, C_text("bool"));
lf[394]=C_h_intern(&lf[394],4, C_text("void"));
lf[395]=C_h_intern(&lf[395],13, C_text("scheme-object"));
lf[396]=C_decode_literal(C_heaptop,C_text("\376B\000\000\042foreign type `~S\047 refers to itself"));
lf[397]=C_h_intern(&lf[397],62, C_text("chicken.compiler.support#estimate-foreign-result-location-size"));
lf[398]=C_decode_literal(C_heaptop,C_text("\376B\000\0005cannot compute size of location for foreign type `~S\047"));
lf[399]=C_decode_literal(C_heaptop,C_text("\376B\000\000\042foreign type `~S\047 refers to itself"));
lf[400]=C_h_intern(&lf[400],46, C_text("chicken.compiler.support#finish-foreign-result"));
lf[401]=C_h_intern(&lf[401],19, C_text("##sys#peek-c-string"));
lf[402]=C_h_intern(&lf[402],27, C_text("##sys#peek-nonnull-c-string"));
lf[403]=C_h_intern(&lf[403],28, C_text("##sys#peek-and-free-c-string"));
lf[404]=C_h_intern(&lf[404],36, C_text("##sys#peek-and-free-nonnull-c-string"));
lf[405]=C_h_intern(&lf[405],19, C_text("##sys#intern-symbol"));
lf[406]=C_h_intern(&lf[406],24, C_text("##sys#peek-c-string-list"));
lf[407]=C_h_intern(&lf[407],33, C_text("##sys#peek-and-free-c-string-list"));
lf[408]=C_h_intern(&lf[408],19, C_text("##sys#null-pointer\077"));
lf[409]=C_h_intern(&lf[409],3, C_text("not"));
lf[410]=C_h_intern(&lf[410],4, C_text("make"));
lf[411]=C_h_intern(&lf[411],3, C_text("and"));
lf[412]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\010\001c-string\376\003\000\000\002\376\001\000\000\011\001c-string\052\376\003\000\000\002\376\001\000\000\021\001unsigned-c-string\376\003\000\000\002\376\001\000\000\022\001un"
"signed-c-string\052\376\003\000\000\002\376\001\000\000\020\001nonnull-c-string\376\003\000\000\002\376\001\000\000\021\001nonnull-c-string\052\376\003\000\000\002\376\001\000\000"
"\030\001nonnull-unsigned-string\052\376\377\016"));
lf[413]=C_h_intern(&lf[413],27, C_text("chicken.syntax#strip-syntax"));
lf[414]=C_h_intern(&lf[414],52, C_text("chicken.compiler.support#foreign-type->scrutiny-type"));
lf[415]=C_h_intern(&lf[415],9, C_text("undefined"));
lf[416]=C_h_intern(&lf[416],3, C_text("arg"));
lf[417]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\002\001or\376\003\000\000\002\376\001\000\000\007\001boolean\376\003\000\000\002\376\001\000\000\004\001blob\376\377\016"));
lf[418]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\002\001or\376\003\000\000\002\376\001\000\000\007\001boolean\376\003\000\000\002\376\001\000\000\016\001pointer-vector\376\377\016"));
lf[419]=C_h_intern(&lf[419],6, C_text("struct"));
lf[420]=C_h_intern(&lf[420],2, C_text("or"));
lf[421]=C_h_intern(&lf[421],7, C_text("boolean"));
lf[422]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001struct\376\003\000\000\002\376\001\000\000\010\001u8vector\376\377\016"));
lf[423]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001struct\376\003\000\000\002\376\001\000\000\010\001s8vector\376\377\016"));
lf[424]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001struct\376\003\000\000\002\376\001\000\000\011\001u16vector\376\377\016"));
lf[425]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001struct\376\003\000\000\002\376\001\000\000\011\001s16vector\376\377\016"));
lf[426]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001struct\376\003\000\000\002\376\001\000\000\011\001u32vector\376\377\016"));
lf[427]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001struct\376\003\000\000\002\376\001\000\000\011\001s32vector\376\377\016"));
lf[428]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001struct\376\003\000\000\002\376\001\000\000\011\001u64vector\376\377\016"));
lf[429]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001struct\376\003\000\000\002\376\001\000\000\011\001s64vector\376\377\016"));
lf[430]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001struct\376\003\000\000\002\376\001\000\000\011\001f32vector\376\377\016"));
lf[431]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\006\001struct\376\003\000\000\002\376\001\000\000\011\001f64vector\376\377\016"));
lf[432]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\002\001or\376\003\000\000\002\376\001\000\000\007\001boolean\376\003\000\000\002\376\001\000\000\007\001pointer\376\003\000\000\002\376\001\000\000\010\001locative\376\377\016"));
lf[433]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\002\001or\376\003\000\000\002\376\001\000\000\007\001boolean\376\003\000\000\002\376\001\000\000\006\001string\376\377\016"));
lf[434]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\007\001list-of\376\003\000\000\002\376\001\000\000\006\001string\376\377\016"));
lf[435]=C_h_intern(&lf[435],6, C_text("string"));
lf[436]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\002\001or\376\003\000\000\002\376\001\000\000\007\001boolean\376\003\000\000\002\376\001\000\000\007\001pointer\376\003\000\000\002\376\001\000\000\010\001locative\376\377\016"));
lf[437]=C_h_intern(&lf[437],44, C_text("chicken.compiler.support#scan-used-variables"));
lf[438]=C_h_intern(&lf[438],44, C_text("chicken.compiler.support#scan-free-variables"));
lf[439]=C_h_intern(&lf[439],39, C_text("chicken.compiler.support#chop-separator"));
lf[440]=C_h_intern(&lf[440],16, C_text("scheme#substring"));
lf[441]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016"));
lf[442]=C_h_intern(&lf[442],52, C_text("chicken.compiler.support#make-block-variable-literal"));
lf[443]=C_h_intern(&lf[443],47, C_text("chicken.compiler.support#block-variable-literal"));
lf[444]=C_h_intern(&lf[444],48, C_text("chicken.compiler.support#block-variable-literal\077"));
lf[445]=C_h_intern(&lf[445],52, C_text("chicken.compiler.support#block-variable-literal-name"));
lf[446]=C_h_intern(&lf[446],27, C_text("block-variable-literal-name"));
lf[447]=C_h_intern(&lf[447],21, C_text("scheme#string->symbol"));
lf[448]=C_h_intern(&lf[448],28, C_text("chicken.time#current-seconds"));
lf[450]=C_h_intern(&lf[450],47, C_text("chicken.compiler.support#clear-real-name-table!"));
lf[451]=C_h_intern(&lf[451],39, C_text("chicken.compiler.support#set-real-name!"));
lf[452]=C_h_intern(&lf[452],38, C_text("chicken.compiler.support#get-real-name"));
lf[453]=C_h_intern(&lf[453],33, C_text("chicken.string#string-intersperse"));
lf[454]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004 in "));
lf[455]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003..."));
lf[456]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004 in "));
lf[457]=C_h_intern(&lf[457],12, C_text("contained-in"));
lf[458]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004 in "));
lf[459]=C_h_intern(&lf[459],35, C_text("chicken.compiler.support#real-name2"));
lf[460]=C_h_intern(&lf[460],48, C_text("chicken.compiler.support#display-real-name-table"));
lf[461]=C_h_intern(&lf[461],44, C_text("chicken.compiler.support#source-info->string"));
lf[462]=C_h_intern(&lf[462],19, C_text("chicken.string#conc"));
lf[463]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001:"));
lf[464]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001 "));
lf[465]=C_h_intern(&lf[465],18, C_text("scheme#make-string"));
lf[466]=C_h_intern(&lf[466],10, C_text("scheme#max"));
lf[467]=C_h_intern(&lf[467],42, C_text("chicken.compiler.support#source-info->name"));
lf[468]=C_h_intern(&lf[468],42, C_text("chicken.compiler.support#source-info->line"));
lf[469]=C_h_intern(&lf[469],34, C_text("chicken.compiler.support#call-info"));
lf[470]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001("));
lf[471]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002) "));
lf[472]=C_h_intern(&lf[472],43, C_text("chicken.compiler.support#constant-form-eval"));
lf[473]=C_decode_literal(C_heaptop,C_text("\376B\000\000\032folded constant expression"));
lf[474]=C_decode_literal(C_heaptop,C_text("\376B\000\000Dattempt to constant-fold call to procedure that has multiple results"));
lf[476]=C_h_intern(&lf[476],28, C_text("chicken.condition#condition\077"));
lf[477]=C_h_intern(&lf[477],10, C_text("##sys#list"));
lf[478]=C_decode_literal(C_heaptop,C_text("\376B\000\000.attempt to constant-fold call to non-procedure"));
lf[479]=C_h_intern(&lf[479],49, C_text("chicken.compiler.support#maybe-constant-fold-call"));
lf[480]=C_h_intern(&lf[480],35, C_text("chicken.compiler.support#predicate\077"));
lf[481]=C_h_intern(&lf[481],34, C_text("chicken.compiler.support#foldable\077"));
lf[482]=C_h_intern(&lf[482],20, C_text("##compiler#intrinsic"));
lf[483]=C_h_intern(&lf[483],20, C_text("##sys#number->string"));
lf[484]=C_h_intern(&lf[484],35, C_text("chicken.compiler.support#dump-nodes"));
lf[485]=C_h_intern(&lf[485],21, C_text("##sys#write-char/port"));
lf[486]=C_h_intern(&lf[486],39, C_text("chicken.compiler.support#read-info-hook"));
lf[487]=C_h_intern(&lf[487],29, C_text("##sys#current-source-filename"));
lf[488]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001:"));
lf[489]=C_h_intern(&lf[489],9, C_text("list-info"));
lf[490]=C_h_intern(&lf[490],41, C_text("chicken.compiler.support#read/source-info"));
lf[491]=C_h_intern(&lf[491],10, C_text("##sys#read"));
lf[492]=C_h_intern(&lf[492],20, C_text("##sys#user-read-hook"));
lf[493]=C_h_intern(&lf[493],15, C_text("foreign-declare"));
lf[494]=C_h_intern(&lf[494],7, C_text("declare"));
lf[495]=C_decode_literal(C_heaptop,C_text("\376B\000\000&unexpected end of `#> ... <#\047 sequence"));
lf[496]=C_h_intern(&lf[496],20, C_text("##sys#read-char/port"));
lf[497]=C_h_intern(&lf[497],25, C_text("chicken.platform#feature\077"));
lf[498]=C_h_intern_kw(&lf[498],5, C_text("64bit"));
lf[499]=C_h_intern(&lf[499],38, C_text("chicken.compiler.support#small-bignum\077"));
lf[500]=C_h_intern(&lf[500],6, C_text("hidden"));
lf[501]=C_h_intern(&lf[501],40, C_text("chicken.compiler.support#export-variable"));
lf[502]=C_h_intern(&lf[502],8, C_text("exported"));
lf[503]=C_h_intern(&lf[503],38, C_text("chicken.compiler.support#mark-variable"));
lf[504]=C_h_intern(&lf[504],38, C_text("chicken.compiler.support#variable-mark"));
lf[505]=C_h_intern(&lf[505],35, C_text("chicken.compiler.support#intrinsic\077"));
lf[506]=C_h_intern(&lf[506],19, C_text("##compiler#foldable"));
lf[507]=C_h_intern(&lf[507],20, C_text("##compiler#predicate"));
lf[508]=C_h_intern(&lf[508],49, C_text("chicken.compiler.support#load-identifier-database"));
lf[509]=C_h_intern(&lf[509],9, C_text("##core#db"));
lf[510]=C_h_intern(&lf[510],27, C_text("scheme#call-with-input-file"));
lf[511]=C_h_intern(&lf[511],1, C_text("p"));
lf[512]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004 ..."));
lf[513]=C_decode_literal(C_heaptop,C_text("\376B\000\000\034loading identifier database "));
lf[514]=C_h_intern(&lf[514],22, C_text("chicken.load#find-file"));
lf[515]=C_h_intern(&lf[515],32, C_text("chicken.platform#repository-path"));
lf[516]=C_h_intern(&lf[516],38, C_text("chicken.compiler.support#print-version"));
lf[517]=C_h_intern(&lf[517],19, C_text("chicken.base#print\052"));
lf[518]=C_decode_literal(C_heaptop,C_text("\376B\000\000KCHICKEN\012(c) 2008-2019, The CHICKEN Team\012(c) 2000-2007, Felix L. Winkelmann\012"
));
lf[519]=C_h_intern(&lf[519],36, C_text("chicken.compiler.support#print-usage"));
lf[520]=C_decode_literal(C_heaptop,C_text("\376B\000\030\356Usage: chicken FILENAME [OPTION ...]\012\012  `chicken\047 is the CHICKEN compiler.\012"
"  \012  FILENAME should be a complete source file name with extension, or \042-\042 for\012 "
" standard input. OPTION may be one of the following:\012\012  General options:\012\012    -h"
"elp                        display this text and exit\012    -version              "
"       display compiler version and exit\012    -release                     print "
"release number and exit\012    -verbose                     display information on "
"compilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME   "
"     specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME   "
"    specifies alternative path for included files\012    -to-stdout                "
"   write compiled file to stdout instead of file\012\012  Language options:\012\012    -feat"
"ure SYMBOL              register feature identifier\012    -no-feature SYMBOL      "
"     disable built-in feature identifier\012\012  Syntax related options:\012\012    -case-i"
"nsensitive            don\047t preserve case of read symbols\012    -keyword-style STY"
"LE         allow alternative keyword syntax\012                                  (p"
"refix, suffix or none)\012    -no-parentheses-synonyms     disables list delimiter "
"synonyms\012    -no-symbol-escape            disables support for escaped symbols\012 "
"   -r5rs-syntax                 disables the CHICKEN extensions to\012             "
"                     R5RS syntax\012    -compile-syntax              macros are mad"
"e available at run-time\012    -emit-import-library MODULE  write compile-time modu"
"le information into\012                                  separate file\012    -emit-al"
"l-import-libraries   emit import-libraries for all defined modules\012    -no-modul"
"e-registration      do not generate module registration code\012    -no-compiler-sy"
"ntax          disable expansion of compiler-macros\012    -module NAME             "
"    wrap compiled code in a module\012\012  Translation options:\012\012    -explicit-use   "
"             do not use units \047library\047 and \047eval\047 by\012                          "
"        default\012    -check-syntax                stop compilation after macro-ex"
"pansion\012    -analyze-only                stop compilation after first analysis p"
"ass\012\012  Debugging options:\012\012    -no-warnings                 disable warnings\012   "
" -debug-level NUMBER          set level of available debugging information\012    -"
"no-trace                    disable tracing information\012    -debug-info         "
"         enable debug-information in compiled code for use\012                     "
"             with an external debugger\012    -profile                     executab"
"le emits profiling information \012    -profile-name FILENAME       name of the gen"
"erated profile information file\012    -accumulate-profile          executable emit"
"s profiling information in\012                                  append mode\012    -no"
"-lambda-info              omit additional procedure-information\012    -emit-types-"
"file FILENAME    write type-declaration information into file\012    -consult-types"
"-file FILENAME load additional type database\012\012  Optimization options:\012\012    -opti"
"mize-level NUMBER       enable certain sets of optimization options\012    -optimiz"
"e-leaf-routines      enable leaf routine optimization\012    -no-usual-integrations"
"       standard procedures may be redefined\012    -unsafe                      dis"
"able all safety checks\012    -local                       assume globals are only "
"modified in current\012                                  file\012    -block           "
"            enable block-compilation\012    -disable-interrupts          disable in"
"terrupts in compiled code\012    -fixnum-arithmetic           assume all numbers ar"
"e fixnums\012    -disable-stack-overflow-checks  disables detection of stack-overfl"
"ows\012    -inline                      enable inlining\012    -inline-limit LIMIT    "
"      set inlining threshold\012    -inline-global               enable cross-modul"
"e inlining\012    -specialize                  perform type-based specialization of"
" primitive calls\012    -emit-inline-file FILENAME   generate file with globally in"
"linable\012                                  procedures (implies -inline -local)\012  "
"  -consult-inline-file FILENAME  explicitly load inline file\012    -no-argc-checks"
"              disable argument count checks\012    -no-bound-checks             dis"
"able bound variable checks\012    -no-procedure-checks         disable procedure ca"
"ll checks\012    -no-procedure-checks-for-usual-bindings\012                          "
"         disable procedure call checks only for usual\012                          "
"         bindings\012    -no-procedure-checks-for-toplevel-bindings\012               "
"                    disable procedure call checks for toplevel\012                 "
"                  bindings\012    -strict-types                assume variable do n"
"ot change their type\012    -clustering                  combine groups of local pr"
"ocedures into dispatch\012                                   loop\012    -lfa2        "
"                perform additional lightweight flow-analysis pass\012\012  Configurati"
"on options:\012\012    -unit NAME                   compile file as a library unit\012   "
" -uses NAME                   declare library unit as used.\012    -heap-size NUMBE"
"R            specifies heap-size of compiled executable\012    -nursery NUMBER  -st"
"ack-size NUMBER\012                                 specifies nursery size of compi"
"led executable\012    -extend FILENAME             load file before compilation com"
"mences\012    -prelude EXPRESSION          add expression to front of source file\012 "
"   -postlude EXPRESSION         add expression to end of source file\012    -prolog"
"ue FILENAME           include file before main source file\012    -epilogue FILENAM"
"E           include file after main source file\012    -dynamic                    "
" compile as dynamically loadable code\012    -require-extension NAME      require a"
"nd import extension NAME\012\012  Obscure options:\012\012    -debug MODES                 d"
"isplay debugging output for the given modes\012    -raw                         do "
"not generate implicit init- and exit code                           \012    -emit-e"
"xternal-prototypes-first\012                                 emit prototypes for ca"
"llbacks before foreign\012                                  declarations\012    -regen"
"erate-import-libraries emit import libraries even when unchanged\012    -ignore-rep"
"ository           do not refer to repository for extensions\012    -setup-mode     "
"             prefer the current directory when locating extensions\012"));
lf[521]=C_h_intern(&lf[521],44, C_text("chicken.compiler.support#print-debug-options"));
lf[522]=C_decode_literal(C_heaptop,C_text("\376B\000\007\026\012Available debugging options:\012\012     a          show node-matching during si"
"mplification\012     b          show breakdown of time needed for each compiler pas"
"s\012     c          print every expression before macro-expansion\012     d          "
"lists all assigned global variables\012     e          show information about speci"
"alizations\012     h          you already figured that out\012     i          show inf"
"ormation about inlining\012     m          show GC statistics during compilation\012  "
"   n          print the line-number database \012     o          show performed opt"
"imizations\012     p          display information about what the compiler is curren"
"tly doing\012     r          show invocation parameters\012     s          show progra"
"m-size information and other statistics\012     t          show time needed for com"
"pilation\012     u          lists all unassigned global variable references\012     x "
"         display information about experimental features\012     D          when pr"
"inting nodes, use node-tree output\012     I          show inferred type informatio"
"n for unexported globals\012     M          show syntax-/runtime-requirements\012     "
"N          show the real-name mapping table\012     P          show expressions aft"
"er specialization\012     S          show applications of compiler syntax\012     T   "
"       show expressions after converting to node tree\012     1          show sourc"
"e expressions\012     2          show canonicalized expressions\012     3          sho"
"w expressions converted into CPS\012     4          show database after each analys"
"is pass\012     5          show expressions after each optimization pass\012     6    "
"      show expressions after each inlining pass\012     7          show expressions"
" after complete optimization\012     8          show database after final analysis\012"
"     9          show expressions after closure conversion\012\012"));
lf[523]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007#<node "));
lf[524]=C_h_intern(&lf[524],29, C_text("##sys#register-record-printer"));
lf[525]=C_h_intern(&lf[525],45, C_text("chicken.condition#condition-property-accessor"));
lf[526]=C_h_intern(&lf[526],3, C_text("exn"));
lf[527]=C_h_intern(&lf[527],7, C_text("message"));
lf[528]=C_h_intern(&lf[528],37, C_text("chicken.condition#condition-predicate"));
C_register_lf2(lf,529,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5115,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[755] = {
{C_text("f18834:support_2escm"),(void*)f18834},
{C_text("f_10029:support_2escm"),(void*)f_10029},
{C_text("f_10031:support_2escm"),(void*)f_10031},
{C_text("f_10056:support_2escm"),(void*)f_10056},
{C_text("f_10087:support_2escm"),(void*)f_10087},
{C_text("f_10099:support_2escm"),(void*)f_10099},
{C_text("f_10103:support_2escm"),(void*)f_10103},
{C_text("f_10126:support_2escm"),(void*)f_10126},
{C_text("f_10137:support_2escm"),(void*)f_10137},
{C_text("f_10144:support_2escm"),(void*)f_10144},
{C_text("f_10155:support_2escm"),(void*)f_10155},
{C_text("f_10157:support_2escm"),(void*)f_10157},
{C_text("f_10182:support_2escm"),(void*)f_10182},
{C_text("f_10212:support_2escm"),(void*)f_10212},
{C_text("f_10214:support_2escm"),(void*)f_10214},
{C_text("f_10239:support_2escm"),(void*)f_10239},
{C_text("f_10253:support_2escm"),(void*)f_10253},
{C_text("f_10263:support_2escm"),(void*)f_10263},
{C_text("f_10265:support_2escm"),(void*)f_10265},
{C_text("f_10290:support_2escm"),(void*)f_10290},
{C_text("f_10363:support_2escm"),(void*)f_10363},
{C_text("f_10369:support_2escm"),(void*)f_10369},
{C_text("f_10395:support_2escm"),(void*)f_10395},
{C_text("f_10399:support_2escm"),(void*)f_10399},
{C_text("f_10415:support_2escm"),(void*)f_10415},
{C_text("f_10421:support_2escm"),(void*)f_10421},
{C_text("f_10427:support_2escm"),(void*)f_10427},
{C_text("f_10433:support_2escm"),(void*)f_10433},
{C_text("f_10437:support_2escm"),(void*)f_10437},
{C_text("f_10440:support_2escm"),(void*)f_10440},
{C_text("f_10447:support_2escm"),(void*)f_10447},
{C_text("f_10449:support_2escm"),(void*)f_10449},
{C_text("f_10479:support_2escm"),(void*)f_10479},
{C_text("f_10507:support_2escm"),(void*)f_10507},
{C_text("f_10531:support_2escm"),(void*)f_10531},
{C_text("f_10553:support_2escm"),(void*)f_10553},
{C_text("f_10578:support_2escm"),(void*)f_10578},
{C_text("f_10600:support_2escm"),(void*)f_10600},
{C_text("f_10608:support_2escm"),(void*)f_10608},
{C_text("f_10659:support_2escm"),(void*)f_10659},
{C_text("f_10666:support_2escm"),(void*)f_10666},
{C_text("f_10669:support_2escm"),(void*)f_10669},
{C_text("f_10698:support_2escm"),(void*)f_10698},
{C_text("f_10706:support_2escm"),(void*)f_10706},
{C_text("f_10722:support_2escm"),(void*)f_10722},
{C_text("f_10725:support_2escm"),(void*)f_10725},
{C_text("f_10731:support_2escm"),(void*)f_10731},
{C_text("f_10751:support_2escm"),(void*)f_10751},
{C_text("f_10774:support_2escm"),(void*)f_10774},
{C_text("f_10779:support_2escm"),(void*)f_10779},
{C_text("f_10783:support_2escm"),(void*)f_10783},
{C_text("f_10786:support_2escm"),(void*)f_10786},
{C_text("f_10792:support_2escm"),(void*)f_10792},
{C_text("f_10795:support_2escm"),(void*)f_10795},
{C_text("f_10812:support_2escm"),(void*)f_10812},
{C_text("f_10822:support_2escm"),(void*)f_10822},
{C_text("f_10824:support_2escm"),(void*)f_10824},
{C_text("f_10849:support_2escm"),(void*)f_10849},
{C_text("f_10860:support_2escm"),(void*)f_10860},
{C_text("f_10868:support_2escm"),(void*)f_10868},
{C_text("f_10876:support_2escm"),(void*)f_10876},
{C_text("f_10889:support_2escm"),(void*)f_10889},
{C_text("f_10891:support_2escm"),(void*)f_10891},
{C_text("f_10939:support_2escm"),(void*)f_10939},
{C_text("f_10964:support_2escm"),(void*)f_10964},
{C_text("f_10983:support_2escm"),(void*)f_10983},
{C_text("f_10988:support_2escm"),(void*)f_10988},
{C_text("f_10998:support_2escm"),(void*)f_10998},
{C_text("f_11000:support_2escm"),(void*)f_11000},
{C_text("f_11025:support_2escm"),(void*)f_11025},
{C_text("f_11047:support_2escm"),(void*)f_11047},
{C_text("f_11095:support_2escm"),(void*)f_11095},
{C_text("f_11101:support_2escm"),(void*)f_11101},
{C_text("f_11115:support_2escm"),(void*)f_11115},
{C_text("f_11119:support_2escm"),(void*)f_11119},
{C_text("f_11125:support_2escm"),(void*)f_11125},
{C_text("f_11163:support_2escm"),(void*)f_11163},
{C_text("f_11167:support_2escm"),(void*)f_11167},
{C_text("f_11170:support_2escm"),(void*)f_11170},
{C_text("f_11173:support_2escm"),(void*)f_11173},
{C_text("f_11208:support_2escm"),(void*)f_11208},
{C_text("f_11252:support_2escm"),(void*)f_11252},
{C_text("f_11254:support_2escm"),(void*)f_11254},
{C_text("f_11279:support_2escm"),(void*)f_11279},
{C_text("f_11294:support_2escm"),(void*)f_11294},
{C_text("f_11323:support_2escm"),(void*)f_11323},
{C_text("f_11325:support_2escm"),(void*)f_11325},
{C_text("f_11350:support_2escm"),(void*)f_11350},
{C_text("f_11359:support_2escm"),(void*)f_11359},
{C_text("f_11363:support_2escm"),(void*)f_11363},
{C_text("f_11366:support_2escm"),(void*)f_11366},
{C_text("f_11372:support_2escm"),(void*)f_11372},
{C_text("f_11380:support_2escm"),(void*)f_11380},
{C_text("f_11388:support_2escm"),(void*)f_11388},
{C_text("f_11398:support_2escm"),(void*)f_11398},
{C_text("f_11426:support_2escm"),(void*)f_11426},
{C_text("f_11430:support_2escm"),(void*)f_11430},
{C_text("f_11435:support_2escm"),(void*)f_11435},
{C_text("f_11441:support_2escm"),(void*)f_11441},
{C_text("f_11444:support_2escm"),(void*)f_11444},
{C_text("f_11449:support_2escm"),(void*)f_11449},
{C_text("f_11459:support_2escm"),(void*)f_11459},
{C_text("f_11474:support_2escm"),(void*)f_11474},
{C_text("f_11476:support_2escm"),(void*)f_11476},
{C_text("f_11483:support_2escm"),(void*)f_11483},
{C_text("f_11504:support_2escm"),(void*)f_11504},
{C_text("f_11538:support_2escm"),(void*)f_11538},
{C_text("f_11541:support_2escm"),(void*)f_11541},
{C_text("f_11560:support_2escm"),(void*)f_11560},
{C_text("f_11586:support_2escm"),(void*)f_11586},
{C_text("f_11619:support_2escm"),(void*)f_11619},
{C_text("f_11621:support_2escm"),(void*)f_11621},
{C_text("f_11627:support_2escm"),(void*)f_11627},
{C_text("f_11633:support_2escm"),(void*)f_11633},
{C_text("f_11637:support_2escm"),(void*)f_11637},
{C_text("f_11660:support_2escm"),(void*)f_11660},
{C_text("f_11671:support_2escm"),(void*)f_11671},
{C_text("f_11677:support_2escm"),(void*)f_11677},
{C_text("f_11680:support_2escm"),(void*)f_11680},
{C_text("f_11688:support_2escm"),(void*)f_11688},
{C_text("f_11714:support_2escm"),(void*)f_11714},
{C_text("f_11736:support_2escm"),(void*)f_11736},
{C_text("f_11761:support_2escm"),(void*)f_11761},
{C_text("f_11783:support_2escm"),(void*)f_11783},
{C_text("f_11801:support_2escm"),(void*)f_11801},
{C_text("f_11832:support_2escm"),(void*)f_11832},
{C_text("f_11884:support_2escm"),(void*)f_11884},
{C_text("f_11890:support_2escm"),(void*)f_11890},
{C_text("f_11910:support_2escm"),(void*)f_11910},
{C_text("f_11916:support_2escm"),(void*)f_11916},
{C_text("f_11942:support_2escm"),(void*)f_11942},
{C_text("f_11956:support_2escm"),(void*)f_11956},
{C_text("f_11964:support_2escm"),(void*)f_11964},
{C_text("f_12019:support_2escm"),(void*)f_12019},
{C_text("f_12048:support_2escm"),(void*)f_12048},
{C_text("f_12145:support_2escm"),(void*)f_12145},
{C_text("f_12151:support_2escm"),(void*)f_12151},
{C_text("f_12158:support_2escm"),(void*)f_12158},
{C_text("f_12161:support_2escm"),(void*)f_12161},
{C_text("f_12184:support_2escm"),(void*)f_12184},
{C_text("f_12186:support_2escm"),(void*)f_12186},
{C_text("f_12192:support_2escm"),(void*)f_12192},
{C_text("f_12199:support_2escm"),(void*)f_12199},
{C_text("f_12202:support_2escm"),(void*)f_12202},
{C_text("f_12221:support_2escm"),(void*)f_12221},
{C_text("f_12223:support_2escm"),(void*)f_12223},
{C_text("f_12229:support_2escm"),(void*)f_12229},
{C_text("f_12242:support_2escm"),(void*)f_12242},
{C_text("f_12270:support_2escm"),(void*)f_12270},
{C_text("f_12272:support_2escm"),(void*)f_12272},
{C_text("f_12293:support_2escm"),(void*)f_12293},
{C_text("f_12300:support_2escm"),(void*)f_12300},
{C_text("f_12306:support_2escm"),(void*)f_12306},
{C_text("f_12312:support_2escm"),(void*)f_12312},
{C_text("f_12321:support_2escm"),(void*)f_12321},
{C_text("f_12330:support_2escm"),(void*)f_12330},
{C_text("f_12339:support_2escm"),(void*)f_12339},
{C_text("f_12348:support_2escm"),(void*)f_12348},
{C_text("f_12357:support_2escm"),(void*)f_12357},
{C_text("f_12383:support_2escm"),(void*)f_12383},
{C_text("f_12386:support_2escm"),(void*)f_12386},
{C_text("f_12397:support_2escm"),(void*)f_12397},
{C_text("f_12399:support_2escm"),(void*)f_12399},
{C_text("f_12453:support_2escm"),(void*)f_12453},
{C_text("f_12459:support_2escm"),(void*)f_12459},
{C_text("f_12465:support_2escm"),(void*)f_12465},
{C_text("f_12471:support_2escm"),(void*)f_12471},
{C_text("f_12496:support_2escm"),(void*)f_12496},
{C_text("f_12511:support_2escm"),(void*)f_12511},
{C_text("f_12529:support_2escm"),(void*)f_12529},
{C_text("f_12579:support_2escm"),(void*)f_12579},
{C_text("f_12594:support_2escm"),(void*)f_12594},
{C_text("f_12634:support_2escm"),(void*)f_12634},
{C_text("f_12637:support_2escm"),(void*)f_12637},
{C_text("f_12652:support_2escm"),(void*)f_12652},
{C_text("f_12676:support_2escm"),(void*)f_12676},
{C_text("f_12702:support_2escm"),(void*)f_12702},
{C_text("f_12708:support_2escm"),(void*)f_12708},
{C_text("f_12714:support_2escm"),(void*)f_12714},
{C_text("f_12717:support_2escm"),(void*)f_12717},
{C_text("f_12720:support_2escm"),(void*)f_12720},
{C_text("f_12723:support_2escm"),(void*)f_12723},
{C_text("f_12745:support_2escm"),(void*)f_12745},
{C_text("f_12751:support_2escm"),(void*)f_12751},
{C_text("f_12757:support_2escm"),(void*)f_12757},
{C_text("f_12760:support_2escm"),(void*)f_12760},
{C_text("f_12763:support_2escm"),(void*)f_12763},
{C_text("f_12766:support_2escm"),(void*)f_12766},
{C_text("f_12789:support_2escm"),(void*)f_12789},
{C_text("f_12792:support_2escm"),(void*)f_12792},
{C_text("f_12833:support_2escm"),(void*)f_12833},
{C_text("f_12836:support_2escm"),(void*)f_12836},
{C_text("f_12851:support_2escm"),(void*)f_12851},
{C_text("f_12878:support_2escm"),(void*)f_12878},
{C_text("f_12921:support_2escm"),(void*)f_12921},
{C_text("f_12925:support_2escm"),(void*)f_12925},
{C_text("f_12952:support_2escm"),(void*)f_12952},
{C_text("f_12955:support_2escm"),(void*)f_12955},
{C_text("f_12990:support_2escm"),(void*)f_12990},
{C_text("f_13026:support_2escm"),(void*)f_13026},
{C_text("f_13529:support_2escm"),(void*)f_13529},
{C_text("f_13535:support_2escm"),(void*)f_13535},
{C_text("f_13548:support_2escm"),(void*)f_13548},
{C_text("f_13562:support_2escm"),(void*)f_13562},
{C_text("f_13575:support_2escm"),(void*)f_13575},
{C_text("f_13589:support_2escm"),(void*)f_13589},
{C_text("f_13595:support_2escm"),(void*)f_13595},
{C_text("f_13599:support_2escm"),(void*)f_13599},
{C_text("f_13603:support_2escm"),(void*)f_13603},
{C_text("f_13622:support_2escm"),(void*)f_13622},
{C_text("f_13628:support_2escm"),(void*)f_13628},
{C_text("f_13631:support_2escm"),(void*)f_13631},
{C_text("f_13640:support_2escm"),(void*)f_13640},
{C_text("f_13650:support_2escm"),(void*)f_13650},
{C_text("f_13659:support_2escm"),(void*)f_13659},
{C_text("f_13671:support_2escm"),(void*)f_13671},
{C_text("f_13683:support_2escm"),(void*)f_13683},
{C_text("f_13695:support_2escm"),(void*)f_13695},
{C_text("f_13701:support_2escm"),(void*)f_13701},
{C_text("f_13705:support_2escm"),(void*)f_13705},
{C_text("f_13732:support_2escm"),(void*)f_13732},
{C_text("f_14097:support_2escm"),(void*)f_14097},
{C_text("f_14103:support_2escm"),(void*)f_14103},
{C_text("f_14115:support_2escm"),(void*)f_14115},
{C_text("f_14125:support_2escm"),(void*)f_14125},
{C_text("f_14137:support_2escm"),(void*)f_14137},
{C_text("f_14143:support_2escm"),(void*)f_14143},
{C_text("f_14147:support_2escm"),(void*)f_14147},
{C_text("f_14174:support_2escm"),(void*)f_14174},
{C_text("f_14547:support_2escm"),(void*)f_14547},
{C_text("f_14553:support_2escm"),(void*)f_14553},
{C_text("f_14557:support_2escm"),(void*)f_14557},
{C_text("f_14673:support_2escm"),(void*)f_14673},
{C_text("f_14701:support_2escm"),(void*)f_14701},
{C_text("f_14821:support_2escm"),(void*)f_14821},
{C_text("f_14825:support_2escm"),(void*)f_14825},
{C_text("f_14849:support_2escm"),(void*)f_14849},
{C_text("f_14924:support_2escm"),(void*)f_14924},
{C_text("f_15011:support_2escm"),(void*)f_15011},
{C_text("f_15032:support_2escm"),(void*)f_15032},
{C_text("f_15050:support_2escm"),(void*)f_15050},
{C_text("f_15072:support_2escm"),(void*)f_15072},
{C_text("f_15427:support_2escm"),(void*)f_15427},
{C_text("f_15431:support_2escm"),(void*)f_15431},
{C_text("f_15433:support_2escm"),(void*)f_15433},
{C_text("f_15465:support_2escm"),(void*)f_15465},
{C_text("f_15473:support_2escm"),(void*)f_15473},
{C_text("f_15483:support_2escm"),(void*)f_15483},
{C_text("f_15497:support_2escm"),(void*)f_15497},
{C_text("f_15529:support_2escm"),(void*)f_15529},
{C_text("f_15537:support_2escm"),(void*)f_15537},
{C_text("f_15547:support_2escm"),(void*)f_15547},
{C_text("f_15582:support_2escm"),(void*)f_15582},
{C_text("f_15585:support_2escm"),(void*)f_15585},
{C_text("f_15619:support_2escm"),(void*)f_15619},
{C_text("f_15638:support_2escm"),(void*)f_15638},
{C_text("f_15644:support_2escm"),(void*)f_15644},
{C_text("f_15648:support_2escm"),(void*)f_15648},
{C_text("f_15674:support_2escm"),(void*)f_15674},
{C_text("f_15683:support_2escm"),(void*)f_15683},
{C_text("f_15694:support_2escm"),(void*)f_15694},
{C_text("f_15713:support_2escm"),(void*)f_15713},
{C_text("f_15725:support_2escm"),(void*)f_15725},
{C_text("f_15769:support_2escm"),(void*)f_15769},
{C_text("f_15771:support_2escm"),(void*)f_15771},
{C_text("f_15783:support_2escm"),(void*)f_15783},
{C_text("f_15793:support_2escm"),(void*)f_15793},
{C_text("f_15807:support_2escm"),(void*)f_15807},
{C_text("f_15812:support_2escm"),(void*)f_15812},
{C_text("f_15823:support_2escm"),(void*)f_15823},
{C_text("f_15836:support_2escm"),(void*)f_15836},
{C_text("f_15842:support_2escm"),(void*)f_15842},
{C_text("f_15848:support_2escm"),(void*)f_15848},
{C_text("f_15857:support_2escm"),(void*)f_15857},
{C_text("f_15865:support_2escm"),(void*)f_15865},
{C_text("f_15871:support_2escm"),(void*)f_15871},
{C_text("f_15874:support_2escm"),(void*)f_15874},
{C_text("f_15877:support_2escm"),(void*)f_15877},
{C_text("f_15880:support_2escm"),(void*)f_15880},
{C_text("f_15883:support_2escm"),(void*)f_15883},
{C_text("f_15888:support_2escm"),(void*)f_15888},
{C_text("f_15892:support_2escm"),(void*)f_15892},
{C_text("f_15904:support_2escm"),(void*)f_15904},
{C_text("f_15909:support_2escm"),(void*)f_15909},
{C_text("f_15911:support_2escm"),(void*)f_15911},
{C_text("f_15917:support_2escm"),(void*)f_15917},
{C_text("f_15924:support_2escm"),(void*)f_15924},
{C_text("f_15927:support_2escm"),(void*)f_15927},
{C_text("f_15931:support_2escm"),(void*)f_15931},
{C_text("f_15937:support_2escm"),(void*)f_15937},
{C_text("f_15943:support_2escm"),(void*)f_15943},
{C_text("f_15970:support_2escm"),(void*)f_15970},
{C_text("f_15972:support_2escm"),(void*)f_15972},
{C_text("f_15986:support_2escm"),(void*)f_15986},
{C_text("f_15996:support_2escm"),(void*)f_15996},
{C_text("f_16009:support_2escm"),(void*)f_16009},
{C_text("f_16024:support_2escm"),(void*)f_16024},
{C_text("f_16028:support_2escm"),(void*)f_16028},
{C_text("f_16035:support_2escm"),(void*)f_16035},
{C_text("f_16039:support_2escm"),(void*)f_16039},
{C_text("f_16044:support_2escm"),(void*)f_16044},
{C_text("f_16048:support_2escm"),(void*)f_16048},
{C_text("f_16056:support_2escm"),(void*)f_16056},
{C_text("f_16062:support_2escm"),(void*)f_16062},
{C_text("f_16069:support_2escm"),(void*)f_16069},
{C_text("f_16072:support_2escm"),(void*)f_16072},
{C_text("f_16075:support_2escm"),(void*)f_16075},
{C_text("f_16080:support_2escm"),(void*)f_16080},
{C_text("f_16100:support_2escm"),(void*)f_16100},
{C_text("f_16104:support_2escm"),(void*)f_16104},
{C_text("f_16115:support_2escm"),(void*)f_16115},
{C_text("f_16130:support_2escm"),(void*)f_16130},
{C_text("f_16142:support_2escm"),(void*)f_16142},
{C_text("f_16146:support_2escm"),(void*)f_16146},
{C_text("f_16149:support_2escm"),(void*)f_16149},
{C_text("f_16179:support_2escm"),(void*)f_16179},
{C_text("f_16203:support_2escm"),(void*)f_16203},
{C_text("f_16218:support_2escm"),(void*)f_16218},
{C_text("f_16221:support_2escm"),(void*)f_16221},
{C_text("f_16227:support_2escm"),(void*)f_16227},
{C_text("f_16236:support_2escm"),(void*)f_16236},
{C_text("f_16239:support_2escm"),(void*)f_16239},
{C_text("f_16278:support_2escm"),(void*)f_16278},
{C_text("f_16284:support_2escm"),(void*)f_16284},
{C_text("f_16290:support_2escm"),(void*)f_16290},
{C_text("f_16293:support_2escm"),(void*)f_16293},
{C_text("f_16299:support_2escm"),(void*)f_16299},
{C_text("f_16305:support_2escm"),(void*)f_16305},
{C_text("f_16311:support_2escm"),(void*)f_16311},
{C_text("f_16317:support_2escm"),(void*)f_16317},
{C_text("f_16339:support_2escm"),(void*)f_16339},
{C_text("f_16341:support_2escm"),(void*)f_16341},
{C_text("f_16375:support_2escm"),(void*)f_16375},
{C_text("f_16409:support_2escm"),(void*)f_16409},
{C_text("f_16412:support_2escm"),(void*)f_16412},
{C_text("f_16440:support_2escm"),(void*)f_16440},
{C_text("f_16447:support_2escm"),(void*)f_16447},
{C_text("f_16462:support_2escm"),(void*)f_16462},
{C_text("f_16468:support_2escm"),(void*)f_16468},
{C_text("f_16471:support_2escm"),(void*)f_16471},
{C_text("f_16508:support_2escm"),(void*)f_16508},
{C_text("f_16523:support_2escm"),(void*)f_16523},
{C_text("f_16533:support_2escm"),(void*)f_16533},
{C_text("f_16536:support_2escm"),(void*)f_16536},
{C_text("f_16548:support_2escm"),(void*)f_16548},
{C_text("f_16554:support_2escm"),(void*)f_16554},
{C_text("f_16560:support_2escm"),(void*)f_16560},
{C_text("f_16563:support_2escm"),(void*)f_16563},
{C_text("f_16565:support_2escm"),(void*)f_16565},
{C_text("f_16572:support_2escm"),(void*)f_16572},
{C_text("f_16578:support_2escm"),(void*)f_16578},
{C_text("f_16589:support_2escm"),(void*)f_16589},
{C_text("f_16637:support_2escm"),(void*)f_16637},
{C_text("f_16639:support_2escm"),(void*)f_16639},
{C_text("f_16645:support_2escm"),(void*)f_16645},
{C_text("f_16649:support_2escm"),(void*)f_16649},
{C_text("f_16654:support_2escm"),(void*)f_16654},
{C_text("f_16682:support_2escm"),(void*)f_16682},
{C_text("f_16690:support_2escm"),(void*)f_16690},
{C_text("f_16693:support_2escm"),(void*)f_16693},
{C_text("f_16696:support_2escm"),(void*)f_16696},
{C_text("f_16699:support_2escm"),(void*)f_16699},
{C_text("f_16702:support_2escm"),(void*)f_16702},
{C_text("f_16705:support_2escm"),(void*)f_16705},
{C_text("f_16706:support_2escm"),(void*)f_16706},
{C_text("f_16716:support_2escm"),(void*)f_16716},
{C_text("f_16722:support_2escm"),(void*)f_16722},
{C_text("f_16734:support_2escm"),(void*)f_16734},
{C_text("f_16737:support_2escm"),(void*)f_16737},
{C_text("f_16740:support_2escm"),(void*)f_16740},
{C_text("f_16745:support_2escm"),(void*)f_16745},
{C_text("f_16758:support_2escm"),(void*)f_16758},
{C_text("f_16761:support_2escm"),(void*)f_16761},
{C_text("f_16778:support_2escm"),(void*)f_16778},
{C_text("f_16788:support_2escm"),(void*)f_16788},
{C_text("f_16801:support_2escm"),(void*)f_16801},
{C_text("f_16805:support_2escm"),(void*)f_16805},
{C_text("f_16808:support_2escm"),(void*)f_16808},
{C_text("f_16823:support_2escm"),(void*)f_16823},
{C_text("f_16827:support_2escm"),(void*)f_16827},
{C_text("f_16844:support_2escm"),(void*)f_16844},
{C_text("f_16850:support_2escm"),(void*)f_16850},
{C_text("f_16860:support_2escm"),(void*)f_16860},
{C_text("f_16863:support_2escm"),(void*)f_16863},
{C_text("f_16879:support_2escm"),(void*)f_16879},
{C_text("f_16884:support_2escm"),(void*)f_16884},
{C_text("f_16888:support_2escm"),(void*)f_16888},
{C_text("f_16905:support_2escm"),(void*)f_16905},
{C_text("f_16916:support_2escm"),(void*)f_16916},
{C_text("f_16928:support_2escm"),(void*)f_16928},
{C_text("f_16931:support_2escm"),(void*)f_16931},
{C_text("f_16939:support_2escm"),(void*)f_16939},
{C_text("f_16944:support_2escm"),(void*)f_16944},
{C_text("f_16957:support_2escm"),(void*)f_16957},
{C_text("f_16968:support_2escm"),(void*)f_16968},
{C_text("f_16990:support_2escm"),(void*)f_16990},
{C_text("f_16992:support_2escm"),(void*)f_16992},
{C_text("f_17012:support_2escm"),(void*)f_17012},
{C_text("f_17032:support_2escm"),(void*)f_17032},
{C_text("f_17040:support_2escm"),(void*)f_17040},
{C_text("f_17049:support_2escm"),(void*)f_17049},
{C_text("f_17054:support_2escm"),(void*)f_17054},
{C_text("f_17058:support_2escm"),(void*)f_17058},
{C_text("f_17079:support_2escm"),(void*)f_17079},
{C_text("f_17094:support_2escm"),(void*)f_17094},
{C_text("f_17100:support_2escm"),(void*)f_17100},
{C_text("f_17111:support_2escm"),(void*)f_17111},
{C_text("f_17122:support_2escm"),(void*)f_17122},
{C_text("f_17133:support_2escm"),(void*)f_17133},
{C_text("f_17137:support_2escm"),(void*)f_17137},
{C_text("f_17143:support_2escm"),(void*)f_17143},
{C_text("f_17155:support_2escm"),(void*)f_17155},
{C_text("f_17159:support_2escm"),(void*)f_17159},
{C_text("f_17171:support_2escm"),(void*)f_17171},
{C_text("f_17179:support_2escm"),(void*)f_17179},
{C_text("f_17189:support_2escm"),(void*)f_17189},
{C_text("f_17204:support_2escm"),(void*)f_17204},
{C_text("f_17210:support_2escm"),(void*)f_17210},
{C_text("f_17213:support_2escm"),(void*)f_17213},
{C_text("f_17216:support_2escm"),(void*)f_17216},
{C_text("f_17219:support_2escm"),(void*)f_17219},
{C_text("f_17222:support_2escm"),(void*)f_17222},
{C_text("f_17226:support_2escm"),(void*)f_17226},
{C_text("f_17228:support_2escm"),(void*)f_17228},
{C_text("f_17235:support_2escm"),(void*)f_17235},
{C_text("f_17242:support_2escm"),(void*)f_17242},
{C_text("f_17253:support_2escm"),(void*)f_17253},
{C_text("f_17257:support_2escm"),(void*)f_17257},
{C_text("f_17260:support_2escm"),(void*)f_17260},
{C_text("f_17265:support_2escm"),(void*)f_17265},
{C_text("f_17271:support_2escm"),(void*)f_17271},
{C_text("f_17278:support_2escm"),(void*)f_17278},
{C_text("f_17281:support_2escm"),(void*)f_17281},
{C_text("f_17284:support_2escm"),(void*)f_17284},
{C_text("f_17287:support_2escm"),(void*)f_17287},
{C_text("f_5115:support_2escm"),(void*)f_5115},
{C_text("f_5118:support_2escm"),(void*)f_5118},
{C_text("f_5121:support_2escm"),(void*)f_5121},
{C_text("f_5124:support_2escm"),(void*)f_5124},
{C_text("f_5127:support_2escm"),(void*)f_5127},
{C_text("f_5130:support_2escm"),(void*)f_5130},
{C_text("f_5133:support_2escm"),(void*)f_5133},
{C_text("f_5136:support_2escm"),(void*)f_5136},
{C_text("f_5139:support_2escm"),(void*)f_5139},
{C_text("f_5249:support_2escm"),(void*)f_5249},
{C_text("f_5267:support_2escm"),(void*)f_5267},
{C_text("f_5307:support_2escm"),(void*)f_5307},
{C_text("f_5321:support_2escm"),(void*)f_5321},
{C_text("f_5510:support_2escm"),(void*)f_5510},
{C_text("f_5516:support_2escm"),(void*)f_5516},
{C_text("f_5538:support_2escm"),(void*)f_5538},
{C_text("f_5544:support_2escm"),(void*)f_5544},
{C_text("f_5550:support_2escm"),(void*)f_5550},
{C_text("f_5560:support_2escm"),(void*)f_5560},
{C_text("f_5574:support_2escm"),(void*)f_5574},
{C_text("f_5580:support_2escm"),(void*)f_5580},
{C_text("f_5594:support_2escm"),(void*)f_5594},
{C_text("f_5803:support_2escm"),(void*)f_5803},
{C_text("f_5811:support_2escm"),(void*)f_5811},
{C_text("f_5815:support_2escm"),(void*)f_5815},
{C_text("f_5819:support_2escm"),(void*)f_5819},
{C_text("f_5837:support_2escm"),(void*)f_5837},
{C_text("f_5876:support_2escm"),(void*)f_5876},
{C_text("f_5910:support_2escm"),(void*)f_5910},
{C_text("f_5916:support_2escm"),(void*)f_5916},
{C_text("f_5969:support_2escm"),(void*)f_5969},
{C_text("f_5975:support_2escm"),(void*)f_5975},
{C_text("f_6158:support_2escm"),(void*)f_6158},
{C_text("f_6172:support_2escm"),(void*)f_6172},
{C_text("f_6176:support_2escm"),(void*)f_6176},
{C_text("f_6271:support_2escm"),(void*)f_6271},
{C_text("f_6284:support_2escm"),(void*)f_6284},
{C_text("f_6422:support_2escm"),(void*)f_6422},
{C_text("f_6426:support_2escm"),(void*)f_6426},
{C_text("f_6440:support_2escm"),(void*)f_6440},
{C_text("f_6451:support_2escm"),(void*)f_6451},
{C_text("f_6454:support_2escm"),(void*)f_6454},
{C_text("f_6469:support_2escm"),(void*)f_6469},
{C_text("f_6475:support_2escm"),(void*)f_6475},
{C_text("f_6478:support_2escm"),(void*)f_6478},
{C_text("f_6484:support_2escm"),(void*)f_6484},
{C_text("f_6488:support_2escm"),(void*)f_6488},
{C_text("f_6491:support_2escm"),(void*)f_6491},
{C_text("f_6500:support_2escm"),(void*)f_6500},
{C_text("f_6508:support_2escm"),(void*)f_6508},
{C_text("f_6515:support_2escm"),(void*)f_6515},
{C_text("f_6520:support_2escm"),(void*)f_6520},
{C_text("f_6530:support_2escm"),(void*)f_6530},
{C_text("f_6543:support_2escm"),(void*)f_6543},
{C_text("f_6550:support_2escm"),(void*)f_6550},
{C_text("f_6553:support_2escm"),(void*)f_6553},
{C_text("f_6562:support_2escm"),(void*)f_6562},
{C_text("f_6565:support_2escm"),(void*)f_6565},
{C_text("f_6568:support_2escm"),(void*)f_6568},
{C_text("f_6571:support_2escm"),(void*)f_6571},
{C_text("f_6574:support_2escm"),(void*)f_6574},
{C_text("f_6577:support_2escm"),(void*)f_6577},
{C_text("f_6583:support_2escm"),(void*)f_6583},
{C_text("f_6586:support_2escm"),(void*)f_6586},
{C_text("f_6593:support_2escm"),(void*)f_6593},
{C_text("f_6595:support_2escm"),(void*)f_6595},
{C_text("f_6598:support_2escm"),(void*)f_6598},
{C_text("f_6600:support_2escm"),(void*)f_6600},
{C_text("f_6607:support_2escm"),(void*)f_6607},
{C_text("f_6610:support_2escm"),(void*)f_6610},
{C_text("f_6613:support_2escm"),(void*)f_6613},
{C_text("f_6627:support_2escm"),(void*)f_6627},
{C_text("f_6632:support_2escm"),(void*)f_6632},
{C_text("f_6642:support_2escm"),(void*)f_6642},
{C_text("f_6659:support_2escm"),(void*)f_6659},
{C_text("f_6662:support_2escm"),(void*)f_6662},
{C_text("f_6665:support_2escm"),(void*)f_6665},
{C_text("f_6668:support_2escm"),(void*)f_6668},
{C_text("f_6674:support_2escm"),(void*)f_6674},
{C_text("f_6683:support_2escm"),(void*)f_6683},
{C_text("f_6690:support_2escm"),(void*)f_6690},
{C_text("f_6692:support_2escm"),(void*)f_6692},
{C_text("f_6696:support_2escm"),(void*)f_6696},
{C_text("f_6699:support_2escm"),(void*)f_6699},
{C_text("f_6706:support_2escm"),(void*)f_6706},
{C_text("f_6708:support_2escm"),(void*)f_6708},
{C_text("f_6712:support_2escm"),(void*)f_6712},
{C_text("f_6715:support_2escm"),(void*)f_6715},
{C_text("f_6716:support_2escm"),(void*)f_6716},
{C_text("f_6726:support_2escm"),(void*)f_6726},
{C_text("f_6729:support_2escm"),(void*)f_6729},
{C_text("f_6734:support_2escm"),(void*)f_6734},
{C_text("f_6744:support_2escm"),(void*)f_6744},
{C_text("f_6761:support_2escm"),(void*)f_6761},
{C_text("f_6764:support_2escm"),(void*)f_6764},
{C_text("f_6767:support_2escm"),(void*)f_6767},
{C_text("f_6770:support_2escm"),(void*)f_6770},
{C_text("f_6773:support_2escm"),(void*)f_6773},
{C_text("f_6782:support_2escm"),(void*)f_6782},
{C_text("f_6785:support_2escm"),(void*)f_6785},
{C_text("f_6788:support_2escm"),(void*)f_6788},
{C_text("f_6805:support_2escm"),(void*)f_6805},
{C_text("f_6824:support_2escm"),(void*)f_6824},
{C_text("f_6847:support_2escm"),(void*)f_6847},
{C_text("f_6851:support_2escm"),(void*)f_6851},
{C_text("f_6859:support_2escm"),(void*)f_6859},
{C_text("f_6862:support_2escm"),(void*)f_6862},
{C_text("f_6870:support_2escm"),(void*)f_6870},
{C_text("f_6874:support_2escm"),(void*)f_6874},
{C_text("f_6883:support_2escm"),(void*)f_6883},
{C_text("f_6927:support_2escm"),(void*)f_6927},
{C_text("f_6933:support_2escm"),(void*)f_6933},
{C_text("f_6955:support_2escm"),(void*)f_6955},
{C_text("f_6964:support_2escm"),(void*)f_6964},
{C_text("f_6976:support_2escm"),(void*)f_6976},
{C_text("f_6980:support_2escm"),(void*)f_6980},
{C_text("f_6982:support_2escm"),(void*)f_6982},
{C_text("f_7004:support_2escm"),(void*)f_7004},
{C_text("f_7011:support_2escm"),(void*)f_7011},
{C_text("f_7015:support_2escm"),(void*)f_7015},
{C_text("f_7019:support_2escm"),(void*)f_7019},
{C_text("f_7025:support_2escm"),(void*)f_7025},
{C_text("f_7047:support_2escm"),(void*)f_7047},
{C_text("f_7063:support_2escm"),(void*)f_7063},
{C_text("f_7067:support_2escm"),(void*)f_7067},
{C_text("f_7088:support_2escm"),(void*)f_7088},
{C_text("f_7111:support_2escm"),(void*)f_7111},
{C_text("f_7113:support_2escm"),(void*)f_7113},
{C_text("f_7120:support_2escm"),(void*)f_7120},
{C_text("f_7127:support_2escm"),(void*)f_7127},
{C_text("f_7140:support_2escm"),(void*)f_7140},
{C_text("f_7152:support_2escm"),(void*)f_7152},
{C_text("f_7171:support_2escm"),(void*)f_7171},
{C_text("f_7183:support_2escm"),(void*)f_7183},
{C_text("f_7197:support_2escm"),(void*)f_7197},
{C_text("f_7199:support_2escm"),(void*)f_7199},
{C_text("f_7225:support_2escm"),(void*)f_7225},
{C_text("f_7239:support_2escm"),(void*)f_7239},
{C_text("f_7245:support_2escm"),(void*)f_7245},
{C_text("f_7260:support_2escm"),(void*)f_7260},
{C_text("f_7276:support_2escm"),(void*)f_7276},
{C_text("f_7284:support_2escm"),(void*)f_7284},
{C_text("f_7288:support_2escm"),(void*)f_7288},
{C_text("f_7290:support_2escm"),(void*)f_7290},
{C_text("f_7301:support_2escm"),(void*)f_7301},
{C_text("f_7303:support_2escm"),(void*)f_7303},
{C_text("f_7320:support_2escm"),(void*)f_7320},
{C_text("f_7334:support_2escm"),(void*)f_7334},
{C_text("f_7368:support_2escm"),(void*)f_7368},
{C_text("f_7380:support_2escm"),(void*)f_7380},
{C_text("f_7396:support_2escm"),(void*)f_7396},
{C_text("f_7426:support_2escm"),(void*)f_7426},
{C_text("f_7430:support_2escm"),(void*)f_7430},
{C_text("f_7470:support_2escm"),(void*)f_7470},
{C_text("f_7472:support_2escm"),(void*)f_7472},
{C_text("f_7488:support_2escm"),(void*)f_7488},
{C_text("f_7494:support_2escm"),(void*)f_7494},
{C_text("f_7509:support_2escm"),(void*)f_7509},
{C_text("f_7526:support_2escm"),(void*)f_7526},
{C_text("f_7528:support_2escm"),(void*)f_7528},
{C_text("f_7534:support_2escm"),(void*)f_7534},
{C_text("f_7558:support_2escm"),(void*)f_7558},
{C_text("f_7574:support_2escm"),(void*)f_7574},
{C_text("f_7584:support_2escm"),(void*)f_7584},
{C_text("f_7589:support_2escm"),(void*)f_7589},
{C_text("f_7603:support_2escm"),(void*)f_7603},
{C_text("f_7606:support_2escm"),(void*)f_7606},
{C_text("f_7607:support_2escm"),(void*)f_7607},
{C_text("f_7611:support_2escm"),(void*)f_7611},
{C_text("f_7616:support_2escm"),(void*)f_7616},
{C_text("f_7622:support_2escm"),(void*)f_7622},
{C_text("f_7628:support_2escm"),(void*)f_7628},
{C_text("f_7636:support_2escm"),(void*)f_7636},
{C_text("f_7639:support_2escm"),(void*)f_7639},
{C_text("f_7647:support_2escm"),(void*)f_7647},
{C_text("f_7649:support_2escm"),(void*)f_7649},
{C_text("f_7653:support_2escm"),(void*)f_7653},
{C_text("f_7675:support_2escm"),(void*)f_7675},
{C_text("f_7681:support_2escm"),(void*)f_7681},
{C_text("f_7685:support_2escm"),(void*)f_7685},
{C_text("f_7698:support_2escm"),(void*)f_7698},
{C_text("f_7706:support_2escm"),(void*)f_7706},
{C_text("f_7712:support_2escm"),(void*)f_7712},
{C_text("f_7723:support_2escm"),(void*)f_7723},
{C_text("f_7725:support_2escm"),(void*)f_7725},
{C_text("f_7728:support_2escm"),(void*)f_7728},
{C_text("f_7734:support_2escm"),(void*)f_7734},
{C_text("f_7773:support_2escm"),(void*)f_7773},
{C_text("f_7778:support_2escm"),(void*)f_7778},
{C_text("f_7782:support_2escm"),(void*)f_7782},
{C_text("f_7786:support_2escm"),(void*)f_7786},
{C_text("f_7837:support_2escm"),(void*)f_7837},
{C_text("f_7874:support_2escm"),(void*)f_7874},
{C_text("f_7876:support_2escm"),(void*)f_7876},
{C_text("f_7926:support_2escm"),(void*)f_7926},
{C_text("f_7930:support_2escm"),(void*)f_7930},
{C_text("f_7944:support_2escm"),(void*)f_7944},
{C_text("f_7948:support_2escm"),(void*)f_7948},
{C_text("f_7956:support_2escm"),(void*)f_7956},
{C_text("f_7962:support_2escm"),(void*)f_7962},
{C_text("f_7966:support_2escm"),(void*)f_7966},
{C_text("f_8008:support_2escm"),(void*)f_8008},
{C_text("f_8012:support_2escm"),(void*)f_8012},
{C_text("f_8060:support_2escm"),(void*)f_8060},
{C_text("f_8064:support_2escm"),(void*)f_8064},
{C_text("f_8069:support_2escm"),(void*)f_8069},
{C_text("f_8079:support_2escm"),(void*)f_8079},
{C_text("f_8086:support_2escm"),(void*)f_8086},
{C_text("f_8089:support_2escm"),(void*)f_8089},
{C_text("f_8093:support_2escm"),(void*)f_8093},
{C_text("f_8120:support_2escm"),(void*)f_8120},
{C_text("f_8126:support_2escm"),(void*)f_8126},
{C_text("f_8136:support_2escm"),(void*)f_8136},
{C_text("f_8139:support_2escm"),(void*)f_8139},
{C_text("f_8142:support_2escm"),(void*)f_8142},
{C_text("f_8155:support_2escm"),(void*)f_8155},
{C_text("f_8157:support_2escm"),(void*)f_8157},
{C_text("f_8192:support_2escm"),(void*)f_8192},
{C_text("f_8198:support_2escm"),(void*)f_8198},
{C_text("f_8204:support_2escm"),(void*)f_8204},
{C_text("f_8213:support_2escm"),(void*)f_8213},
{C_text("f_8222:support_2escm"),(void*)f_8222},
{C_text("f_8231:support_2escm"),(void*)f_8231},
{C_text("f_8240:support_2escm"),(void*)f_8240},
{C_text("f_8249:support_2escm"),(void*)f_8249},
{C_text("f_8259:support_2escm"),(void*)f_8259},
{C_text("f_8261:support_2escm"),(void*)f_8261},
{C_text("f_8267:support_2escm"),(void*)f_8267},
{C_text("f_8282:support_2escm"),(void*)f_8282},
{C_text("f_8297:support_2escm"),(void*)f_8297},
{C_text("f_8300:support_2escm"),(void*)f_8300},
{C_text("f_8367:support_2escm"),(void*)f_8367},
{C_text("f_8369:support_2escm"),(void*)f_8369},
{C_text("f_8394:support_2escm"),(void*)f_8394},
{C_text("f_8417:support_2escm"),(void*)f_8417},
{C_text("f_8420:support_2escm"),(void*)f_8420},
{C_text("f_8423:support_2escm"),(void*)f_8423},
{C_text("f_8430:support_2escm"),(void*)f_8430},
{C_text("f_8477:support_2escm"),(void*)f_8477},
{C_text("f_8481:support_2escm"),(void*)f_8481},
{C_text("f_8486:support_2escm"),(void*)f_8486},
{C_text("f_8503:support_2escm"),(void*)f_8503},
{C_text("f_8511:support_2escm"),(void*)f_8511},
{C_text("f_8513:support_2escm"),(void*)f_8513},
{C_text("f_8538:support_2escm"),(void*)f_8538},
{C_text("f_8574:support_2escm"),(void*)f_8574},
{C_text("f_8608:support_2escm"),(void*)f_8608},
{C_text("f_8639:support_2escm"),(void*)f_8639},
{C_text("f_8662:support_2escm"),(void*)f_8662},
{C_text("f_8683:support_2escm"),(void*)f_8683},
{C_text("f_8705:support_2escm"),(void*)f_8705},
{C_text("f_8713:support_2escm"),(void*)f_8713},
{C_text("f_8717:support_2escm"),(void*)f_8717},
{C_text("f_8725:support_2escm"),(void*)f_8725},
{C_text("f_8746:support_2escm"),(void*)f_8746},
{C_text("f_8750:support_2escm"),(void*)f_8750},
{C_text("f_8762:support_2escm"),(void*)f_8762},
{C_text("f_8789:support_2escm"),(void*)f_8789},
{C_text("f_8801:support_2escm"),(void*)f_8801},
{C_text("f_8803:support_2escm"),(void*)f_8803},
{C_text("f_8828:support_2escm"),(void*)f_8828},
{C_text("f_8862:support_2escm"),(void*)f_8862},
{C_text("f_8888:support_2escm"),(void*)f_8888},
{C_text("f_8890:support_2escm"),(void*)f_8890},
{C_text("f_8915:support_2escm"),(void*)f_8915},
{C_text("f_8999:support_2escm"),(void*)f_8999},
{C_text("f_9001:support_2escm"),(void*)f_9001},
{C_text("f_9026:support_2escm"),(void*)f_9026},
{C_text("f_9066:support_2escm"),(void*)f_9066},
{C_text("f_9107:support_2escm"),(void*)f_9107},
{C_text("f_9136:support_2escm"),(void*)f_9136},
{C_text("f_9138:support_2escm"),(void*)f_9138},
{C_text("f_9163:support_2escm"),(void*)f_9163},
{C_text("f_9199:support_2escm"),(void*)f_9199},
{C_text("f_9201:support_2escm"),(void*)f_9201},
{C_text("f_9226:support_2escm"),(void*)f_9226},
{C_text("f_9238:support_2escm"),(void*)f_9238},
{C_text("f_9244:support_2escm"),(void*)f_9244},
{C_text("f_9267:support_2escm"),(void*)f_9267},
{C_text("f_9269:support_2escm"),(void*)f_9269},
{C_text("f_9294:support_2escm"),(void*)f_9294},
{C_text("f_9305:support_2escm"),(void*)f_9305},
{C_text("f_9309:support_2escm"),(void*)f_9309},
{C_text("f_9312:support_2escm"),(void*)f_9312},
{C_text("f_9319:support_2escm"),(void*)f_9319},
{C_text("f_9333:support_2escm"),(void*)f_9333},
{C_text("f_9439:support_2escm"),(void*)f_9439},
{C_text("f_9441:support_2escm"),(void*)f_9441},
{C_text("f_9466:support_2escm"),(void*)f_9466},
{C_text("f_9484:support_2escm"),(void*)f_9484},
{C_text("f_9487:support_2escm"),(void*)f_9487},
{C_text("f_9493:support_2escm"),(void*)f_9493},
{C_text("f_9499:support_2escm"),(void*)f_9499},
{C_text("f_9533:support_2escm"),(void*)f_9533},
{C_text("f_9546:support_2escm"),(void*)f_9546},
{C_text("f_9548:support_2escm"),(void*)f_9548},
{C_text("f_9573:support_2escm"),(void*)f_9573},
{C_text("f_9603:support_2escm"),(void*)f_9603},
{C_text("f_9605:support_2escm"),(void*)f_9605},
{C_text("f_9630:support_2escm"),(void*)f_9630},
{C_text("f_9703:support_2escm"),(void*)f_9703},
{C_text("f_9706:support_2escm"),(void*)f_9706},
{C_text("f_9715:support_2escm"),(void*)f_9715},
{C_text("f_9719:support_2escm"),(void*)f_9719},
{C_text("f_9723:support_2escm"),(void*)f_9723},
{C_text("f_9725:support_2escm"),(void*)f_9725},
{C_text("f_9773:support_2escm"),(void*)f_9773},
{C_text("f_9798:support_2escm"),(void*)f_9798},
{C_text("f_9826:support_2escm"),(void*)f_9826},
{C_text("f_9850:support_2escm"),(void*)f_9850},
{C_text("f_9884:support_2escm"),(void*)f_9884},
{C_text("f_9888:support_2escm"),(void*)f_9888},
{C_text("f_9898:support_2escm"),(void*)f_9898},
{C_text("f_9922:support_2escm"),(void*)f_9922},
{C_text("f_9937:support_2escm"),(void*)f_9937},
{C_text("f_9949:support_2escm"),(void*)f_9949},
{C_text("f_9974:support_2escm"),(void*)f_9974},
{C_text("f_9999:support_2escm"),(void*)f_9999},
{C_text("toplevel:support_2escm"),(void*)C_support_toplevel},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding unexported module binding: chicken.compiler.support#partition 
o|hiding unexported module binding: chicken.compiler.support#span 
o|hiding unexported module binding: chicken.compiler.support#take 
o|hiding unexported module binding: chicken.compiler.support#drop 
o|hiding unexported module binding: chicken.compiler.support#split-at 
o|hiding unexported module binding: chicken.compiler.support#append-map 
o|hiding unexported module binding: chicken.compiler.support#every 
o|hiding unexported module binding: chicken.compiler.support#any 
o|hiding unexported module binding: chicken.compiler.support#cons* 
o|hiding unexported module binding: chicken.compiler.support#concatenate 
o|hiding unexported module binding: chicken.compiler.support#delete 
o|hiding unexported module binding: chicken.compiler.support#first 
o|hiding unexported module binding: chicken.compiler.support#second 
o|hiding unexported module binding: chicken.compiler.support#third 
o|hiding unexported module binding: chicken.compiler.support#fourth 
o|hiding unexported module binding: chicken.compiler.support#fifth 
o|hiding unexported module binding: chicken.compiler.support#delete-duplicates 
o|hiding unexported module binding: chicken.compiler.support#alist-cons 
o|hiding unexported module binding: chicken.compiler.support#filter 
o|hiding unexported module binding: chicken.compiler.support#filter-map 
o|hiding unexported module binding: chicken.compiler.support#remove 
o|hiding unexported module binding: chicken.compiler.support#unzip1 
o|hiding unexported module binding: chicken.compiler.support#last 
o|hiding unexported module binding: chicken.compiler.support#list-index 
o|hiding unexported module binding: chicken.compiler.support#lset-adjoin/eq? 
o|hiding unexported module binding: chicken.compiler.support#lset-difference/eq? 
o|hiding unexported module binding: chicken.compiler.support#lset-union/eq? 
o|hiding unexported module binding: chicken.compiler.support#lset-intersection/eq? 
o|hiding unexported module binding: chicken.compiler.support#list-tabulate 
o|hiding unexported module binding: chicken.compiler.support#lset<=/eq? 
o|hiding unexported module binding: chicken.compiler.support#lset=/eq? 
o|hiding unexported module binding: chicken.compiler.support#length+ 
o|hiding unexported module binding: chicken.compiler.support#find 
o|hiding unexported module binding: chicken.compiler.support#find-tail 
o|hiding unexported module binding: chicken.compiler.support#iota 
o|hiding unexported module binding: chicken.compiler.support#make-list 
o|hiding unexported module binding: chicken.compiler.support#posq 
o|hiding unexported module binding: chicken.compiler.support#posv 
o|hiding unexported module binding: chicken.compiler.support#constant659 
o|hiding unexported module binding: chicken.compiler.support#+logged-debugging-modes+ 
o|hiding unexported module binding: chicken.compiler.support#test-debugging-mode 
o|hiding unexported module binding: chicken.compiler.support#map-llist 
o|hiding unexported module binding: chicken.compiler.support#follow-without-loop 
o|hiding unexported module binding: chicken.compiler.support#sort-symbols 
o|hiding unexported module binding: chicken.compiler.support#profile-info-vector-name 
o|hiding unexported module binding: chicken.compiler.support#profile-lambda-list 
o|hiding unexported module binding: chicken.compiler.support#profile-lambda-index 
o|hiding unexported module binding: chicken.compiler.support#node 
o|hiding unexported module binding: chicken.compiler.support#copy-node-tree-and-rename 
o|hiding unexported module binding: chicken.compiler.support#node->sexpr 
o|hiding unexported module binding: chicken.compiler.support#sexpr->node 
o|hiding unexported module binding: chicken.compiler.support#foreign-callback-stub 
o|hiding unexported module binding: chicken.compiler.support#foreign-type-table 
o|hiding unexported module binding: chicken.compiler.support#block-variable-literal 
o|hiding unexported module binding: chicken.compiler.support#real-name-table 
o|hiding unexported module binding: chicken.compiler.support#real-name-max-depth 
o|hiding unexported module binding: chicken.compiler.support#encodeable-literal? 
o|hiding unexported module binding: chicken.compiler.support#scan-sharp-greater-string 
o|hiding unexported module binding: chicken.compiler.support#unhide-variable 
S|applied compiler syntax:
S|  chicken.format#sprintf		4
S|  chicken.format#fprintf		5
S|  chicken.format#printf		6
S|  scheme#for-each		10
S|  chicken.base#foldl		3
S|  scheme#map		33
S|  chicken.base#foldr		3
o|eliminated procedure checks: 438 
o|specializations:
o|  1 (scheme#eqv? (or eof null fixnum char boolean symbol keyword) *)
o|  1 (scheme#+ fixnum fixnum)
o|  1 (scheme#number->string * *)
o|  1 (chicken.base#exact-integer? *)
o|  2 (chicken.bitwise#integer-length *)
o|  1 (scheme#length list)
o|  1 (scheme#- fixnum fixnum)
o|  1 (scheme#> integer integer)
o|  1 (chicken.base#sub1 fixnum)
o|  4 (scheme#= fixnum fixnum)
o|  2 (scheme#assq * (list-of pair))
o|  1 (scheme#* fixnum fixnum)
o|  1 (scheme#positive? *)
o|  4 (scheme#cddr (pair * pair))
o|  1 (scheme#caddr (pair * (pair * pair)))
o|  1 (scheme#integer? *)
o|  330 (scheme#eqv? * (or eof null fixnum char boolean symbol keyword))
o|  2 (##sys#call-with-values (procedure () *) *)
o|  3 (chicken.base#add1 *)
o|  1 (scheme#cadr (pair * pair))
o|  2 (scheme#current-input-port)
o|  4 (scheme#char=? char char)
o|  1 (scheme#number->string fixnum fixnum)
o|  3 (scheme#memq * list)
o|  1 (scheme#>= fixnum fixnum)
o|  3 (scheme#< fixnum fixnum)
o|  1 (chicken.base#sub1 *)
o|  2 (scheme#zero? *)
o|  2 (chicken.base#current-error-port)
o|  15 (##sys#check-output-port * * *)
o|  1 (scheme#eqv? * *)
o|  9 (##sys#check-list (or pair list) *)
o|  52 (scheme#cdr pair)
o|  34 (scheme#car pair)
(o e)|safe calls: 1805 
(o e)|assignments to immediate values: 5 
o|safe globals: (chicken.compiler.support#bomb chicken.compiler.support#debugging-chicken chicken.compiler.support#compiler-cleanup-hook chicken.compiler.support#unsafe chicken.compiler.support#number-type chicken.compiler.support#constant659 chicken.compiler.support#posv chicken.compiler.support#posq chicken.compiler.support#make-list chicken.compiler.support#iota chicken.compiler.support#find-tail chicken.compiler.support#find chicken.compiler.support#length+ chicken.compiler.support#lset=/eq? chicken.compiler.support#lset<=/eq? chicken.compiler.support#list-tabulate chicken.compiler.support#lset-intersection/eq? chicken.compiler.support#lset-union/eq? chicken.compiler.support#lset-difference/eq? chicken.compiler.support#lset-adjoin/eq? chicken.compiler.support#list-index chicken.compiler.support#last chicken.compiler.support#unzip1 chicken.compiler.support#remove chicken.compiler.support#filter-map chicken.compiler.support#filter chicken.compiler.support#alist-cons chicken.compiler.support#delete-duplicates chicken.compiler.support#fifth chicken.compiler.support#fourth chicken.compiler.support#third chicken.compiler.support#second chicken.compiler.support#first chicken.compiler.support#delete chicken.compiler.support#concatenate chicken.compiler.support#cons* chicken.compiler.support#any chicken.compiler.support#every chicken.compiler.support#append-map chicken.compiler.support#split-at chicken.compiler.support#drop chicken.compiler.support#take chicken.compiler.support#span chicken.compiler.support#partition) 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#partition 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#span 
o|inlining procedure: k5251 
o|inlining procedure: k5251 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#drop 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#append-map 
o|inlining procedure: k5521 
o|inlining procedure: k5521 
o|inlining procedure: k5552 
o|inlining procedure: k5552 
o|merged explicitly consed rest parameter: xs320 
o|inlining procedure: k5582 
o|inlining procedure: k5582 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#concatenate 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#delete-duplicates 
o|inlining procedure: k5769 
o|inlining procedure: k5769 
o|inlining procedure: k5761 
o|inlining procedure: k5761 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#remove 
o|inlining procedure: k5918 
o|inlining procedure: k5918 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#list-index 
o|merged explicitly consed rest parameter: vals460 
o|inlining procedure: k5977 
o|inlining procedure: k5977 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#lset-difference/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#lset-union/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#lset-intersection/eq? 
o|inlining procedure: k6160 
o|inlining procedure: k6160 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#lset<=/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#lset=/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#length+ 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#find-tail 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#iota 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#make-list 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#posq 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#posv 
o|inlining procedure: k6428 
o|inlining procedure: k6428 
o|inlining procedure: k6456 
o|inlining procedure: k6456 
o|inlining procedure: k6489 
o|inlining procedure: k6522 
o|contracted procedure: "(support.scm:137) g686693" 
o|propagated global variable: out696699 ##sys#standard-output 
o|substituted constant variable: a6504 
o|substituted constant variable: a6505 
o|inlining procedure: k6522 
o|inlining procedure: k6489 
o|propagated global variable: out711714 chicken.compiler.support#collected-debugging-output 
o|substituted constant variable: a6546 
o|substituted constant variable: a6547 
o|propagated global variable: out711714 chicken.compiler.support#collected-debugging-output 
o|inlining procedure: k6557 
o|inlining procedure: k6557 
o|propagated global variable: out747750 chicken.compiler.support#collected-debugging-output 
o|substituted constant variable: a6603 
o|substituted constant variable: a6604 
o|inlining procedure: k6618 
o|inlining procedure: k6618 
o|inlining procedure: k6634 
o|inlining procedure: k6634 
o|inlining procedure: k6654 
o|inlining procedure: k6654 
o|inlining procedure: k6736 
o|inlining procedure: k6736 
o|substituted constant variable: a6757 
o|substituted constant variable: a6758 
o|substituted constant variable: a6778 
o|substituted constant variable: a6779 
o|contracted procedure: "(support.scm:199) thread-id827" 
o|propagated global variable: t828 ##sys#current-thread 
o|contracted procedure: "(support.scm:213) chicken.compiler.support#map-llist" 
o|inlining procedure: k6826 
o|inlining procedure: k6826 
o|inlining procedure: k6885 
o|inlining procedure: k6885 
o|inlining procedure: k6906 
o|inlining procedure: k6906 
o|inlining procedure: k6935 
o|inlining procedure: k6935 
o|inlining procedure: k6984 
o|inlining procedure: k6984 
o|substituted constant variable: a7027 
o|inlining procedure: k7031 
o|inlining procedure: k7031 
o|substituted constant variable: a7038 
o|substituted constant variable: a7040 
o|inlining procedure: k7053 
o|inlining procedure: k7053 
o|substituted constant variable: a7057 
o|substituted constant variable: a7059 
o|substituted constant variable: a7061 
o|inlining procedure: k7068 
o|inlining procedure: k7093 
o|inlining procedure: k7093 
o|substituted constant variable: a7102 
o|substituted constant variable: a7106 
o|inlining procedure: k7068 
o|inlining procedure: k7129 
o|propagated global variable: r713017373 ##sys#standard-input 
o|inlining procedure: k7129 
o|inlining procedure: k7144 
o|inlining procedure: k7144 
o|inlining procedure: k7173 
o|inlining procedure: k7173 
o|inlining procedure: k7185 
o|inlining procedure: k7185 
o|inlining procedure: k7205 
o|inlining procedure: k7205 
o|inlining procedure: k7247 
o|inlining procedure: k7247 
o|inlining procedure: k7305 
o|inlining procedure: k7305 
o|inlining procedure: k7339 
o|inlining procedure: k7339 
o|inlining procedure: k7351 
o|inlining procedure: k7351 
o|inlining procedure: k7363 
o|inlining procedure: k7363 
o|inlining procedure: k7375 
o|inlining procedure: k7375 
o|inlining procedure: k7384 
o|inlining procedure: k7384 
o|inlining procedure: k7401 
o|inlining procedure: k7401 
o|inlining procedure: k7413 
o|inlining procedure: k7413 
o|inlining procedure: k7431 
o|inlining procedure: k7431 
o|inlining procedure: k7443 
o|inlining procedure: k7443 
o|inlining procedure: k7455 
o|inlining procedure: k7455 
o|inlining procedure: k7477 
o|inlining procedure: k7477 
o|inlining procedure: k7489 
o|inlining procedure: k7489 
o|inlining procedure: k7498 
o|inlining procedure: k7498 
o|inlining procedure: k7536 
o|inlining procedure: k7536 
o|inlining procedure: k7549 
o|inlining procedure: k7549 
o|inlining procedure: k7590 
o|inlining procedure: k7590 
o|inlining procedure: k7634 
o|inlining procedure: k7634 
o|inlining procedure: k7654 
o|inlining procedure: k7654 
o|inlining procedure: k7686 
o|inlining procedure: k7686 
o|merged explicitly consed rest parameter: args10671085 
o|consed rest parameter at call site: tmp24743 1 
o|inlining procedure: k7736 
o|inlining procedure: k7736 
o|inlining procedure: k7751 
o|inlining procedure: k7751 
o|inlining procedure: k7878 
o|contracted procedure: "(support.scm:410) g11301139" 
o|inlining procedure: k7878 
o|propagated global variable: g11361140 chicken.compiler.support#profile-lambda-list 
o|inlining procedure: k7931 
o|inlining procedure: k7931 
o|inlining procedure: k7949 
o|contracted procedure: "(support.scm:428) chicken.compiler.support#filter-map" 
o|inlining procedure: k5816 
o|inlining procedure: k5816 
o|inlining procedure: k5805 
o|inlining procedure: k5805 
o|inlining procedure: k7949 
o|inlining procedure: k7967 
o|inlining procedure: k7979 
o|inlining procedure: k7979 
o|inlining procedure: k7967 
o|inlining procedure: k8013 
o|inlining procedure: k8013 
o|inlining procedure: k8065 
o|inlining procedure: k8065 
o|inlining procedure: k8090 
o|inlining procedure: k8090 
o|propagated global variable: out12131216 ##sys#standard-output 
o|substituted constant variable: a8132 
o|substituted constant variable: a8133 
o|inlining procedure: k8128 
o|inlining procedure: k8159 
o|inlining procedure: k8159 
o|propagated global variable: out12131216 ##sys#standard-output 
o|inlining procedure: k8128 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#node 
o|contracted procedure: "(support.scm:488) g13091310" 
o|contracted procedure: "(support.scm:489) g13161317" 
o|inlining procedure: k8302 
o|inlining procedure: k8302 
o|inlining procedure: k8322 
o|inlining procedure: k8322 
o|inlining procedure: k8338 
o|contracted procedure: "(support.scm:499) g13421343" 
o|inlining procedure: k8371 
o|inlining procedure: k8371 
o|inlining procedure: k8338 
o|inlining procedure: k8415 
o|inlining procedure: k8415 
o|inlining procedure: k8434 
o|inlining procedure: k8434 
o|inlining procedure: k8445 
o|contracted procedure: "(support.scm:515) g13791380" 
o|inlining procedure: k8515 
o|inlining procedure: k8515 
o|contracted procedure: "(support.scm:516) chicken.compiler.support#unzip1" 
o|inlining procedure: k5878 
o|contracted procedure: "(mini-srfi-1.scm:143) g423432" 
o|inlining procedure: k5878 
o|inlining procedure: k8445 
o|contracted procedure: "(support.scm:520) g14141415" 
o|inlining procedure: k8583 
o|contracted procedure: "(support.scm:522) g14191420" 
o|inlining procedure: "(support.scm:524) chicken.compiler.support#fourth" 
o|inlining procedure: "(support.scm:523) chicken.compiler.support#third" 
o|inlining procedure: "(support.scm:523) chicken.compiler.support#second" 
o|inlining procedure: k8583 
o|inlining procedure: k8641 
o|contracted procedure: "(support.scm:529) g14321433" 
o|contracted procedure: "(support.scm:533) g14371438" 
o|inlining procedure: k8641 
o|contracted procedure: "(support.scm:535) g14421443" 
o|inlining procedure: k8767 
o|contracted procedure: "(support.scm:544) g14491450" 
o|inlining procedure: k8805 
o|inlining procedure: k8805 
o|inlining procedure: k8837 
o|inlining procedure: k8837 
o|inlining procedure: k8767 
o|contracted procedure: "(support.scm:549) g14871488" 
o|inlining procedure: k8892 
o|inlining procedure: k8892 
o|inlining procedure: k8927 
o|contracted procedure: "(support.scm:551) g15181519" 
o|inlining procedure: k8927 
o|contracted procedure: "(support.scm:553) g15231524" 
o|inlining procedure: k8967 
o|contracted procedure: "(support.scm:555) g15311532" 
o|inlining procedure: k9003 
o|inlining procedure: k9003 
o|inlining procedure: k8967 
o|contracted procedure: "(support.scm:560) g15631564" 
o|contracted procedure: "(support.scm:562) chicken.compiler.support#fifth" 
o|inlining procedure: "(support.scm:562) chicken.compiler.support#fourth" 
o|inlining procedure: "(support.scm:562) chicken.compiler.support#third" 
o|inlining procedure: "(support.scm:559) chicken.compiler.support#second" 
o|inlining procedure: k9099 
o|contracted procedure: "(support.scm:566) g15801581" 
o|inlining procedure: k9140 
o|inlining procedure: k9140 
o|inlining procedure: "(support.scm:566) chicken.compiler.support#second" 
o|inlining procedure: "(support.scm:566) chicken.compiler.support#first" 
o|inlining procedure: k9099 
o|contracted procedure: "(support.scm:568) g16111612" 
o|inlining procedure: k9203 
o|inlining procedure: k9203 
o|contracted procedure: "(support.scm:571) g16441645" 
o|inlining procedure: k9271 
o|inlining procedure: k9271 
o|inlining procedure: k9307 
o|inlining procedure: k9317 
o|inlining procedure: k9317 
o|inlining procedure: k9307 
o|contracted procedure: "(support.scm:573) g16531654" 
o|substituted constant variable: a9337 
o|inlining procedure: k9341 
o|inlining procedure: k9341 
o|inlining procedure: k9353 
o|inlining procedure: k9353 
o|substituted constant variable: a9360 
o|substituted constant variable: a9362 
o|substituted constant variable: a9364 
o|substituted constant variable: a9366 
o|substituted constant variable: a9368 
o|substituted constant variable: a9370 
o|substituted constant variable: a9375 
o|substituted constant variable: a9377 
o|substituted constant variable: a9379 
o|substituted constant variable: a9381 
o|inlining procedure: k9385 
o|inlining procedure: k9385 
o|substituted constant variable: a9392 
o|substituted constant variable: a9394 
o|substituted constant variable: a9396 
o|substituted constant variable: a9398 
o|substituted constant variable: a9400 
o|substituted constant variable: a9402 
o|substituted constant variable: a9407 
o|substituted constant variable: a9409 
o|substituted constant variable: a9411 
o|substituted constant variable: a9413 
o|substituted constant variable: a9418 
o|substituted constant variable: a9420 
o|contracted procedure: "(support.scm:583) g16881689" 
o|inlining procedure: k9443 
o|inlining procedure: k9443 
o|contracted procedure: "(support.scm:495) g13301331" 
o|inlining procedure: k9485 
o|inlining procedure: k9485 
o|inlining procedure: k9525 
o|inlining procedure: k9550 
o|inlining procedure: k9550 
o|inlining procedure: k9525 
o|inlining procedure: k9607 
o|inlining procedure: k9607 
o|inlining procedure: k9638 
o|inlining procedure: k9638 
o|inlining procedure: k9656 
o|inlining procedure: k9656 
o|inlining procedure: k9673 
o|inlining procedure: k9673 
o|inlining procedure: k9685 
o|inlining procedure: k9727 
o|inlining procedure: k9727 
o|inlining procedure: k9775 
o|inlining procedure: k9775 
o|inlining procedure: k9685 
o|inlining procedure: "(support.scm:611) chicken.compiler.support#third" 
o|inlining procedure: "(support.scm:608) chicken.compiler.support#second" 
o|inlining procedure: k9834 
o|inlining procedure: "(support.scm:614) chicken.compiler.support#first" 
o|inlining procedure: "(support.scm:614) chicken.compiler.support#first" 
o|inlining procedure: k9834 
o|inlining procedure: "(support.scm:616) chicken.compiler.support#first" 
o|inlining procedure: k9868 
o|inlining procedure: k9900 
o|inlining procedure: k9900 
o|inlining procedure: "(support.scm:619) chicken.compiler.support#first" 
o|inlining procedure: k9868 
o|inlining procedure: k9976 
o|inlining procedure: k9976 
o|inlining procedure: k10007 
o|consed rest parameter at call site: "(support.scm:629) chicken.compiler.support#cons*" 2 
o|inlining procedure: k10033 
o|inlining procedure: k10033 
o|inlining procedure: k10007 
o|inlining procedure: k10073 
o|inlining procedure: k10089 
o|inlining procedure: k10089 
o|inlining procedure: k10073 
o|consed rest parameter at call site: "(support.scm:637) chicken.compiler.support#cons*" 2 
o|inlining procedure: k10159 
o|inlining procedure: k10159 
o|inlining procedure: k10194 
o|consed rest parameter at call site: "(support.scm:639) chicken.compiler.support#cons*" 2 
o|inlining procedure: k10216 
o|inlining procedure: k10216 
o|inlining procedure: k10194 
o|inlining procedure: k10267 
o|inlining procedure: k10267 
o|substituted constant variable: a10299 
o|inlining procedure: k10303 
o|inlining procedure: k10303 
o|substituted constant variable: a10316 
o|substituted constant variable: a10318 
o|substituted constant variable: a10320 
o|substituted constant variable: a10322 
o|substituted constant variable: a10324 
o|substituted constant variable: a10326 
o|substituted constant variable: a10328 
o|substituted constant variable: a10330 
o|substituted constant variable: a10332 
o|substituted constant variable: a10334 
o|substituted constant variable: a10336 
o|substituted constant variable: a10338 
o|substituted constant variable: a10340 
o|substituted constant variable: a10342 
o|substituted constant variable: a10344 
o|substituted constant variable: a10346 
o|inlining procedure: k10350 
o|inlining procedure: k10350 
o|substituted constant variable: a10357 
o|substituted constant variable: a10359 
o|substituted constant variable: a10361 
o|contracted procedure: "(support.scm:593) g17351736" 
o|contracted procedure: "(support.scm:592) g17321733" 
o|contracted procedure: "(support.scm:591) g17291730" 
o|inlining procedure: k10371 
o|inlining procedure: k10371 
o|contracted procedure: "(support.scm:646) g20442045" 
o|inlining procedure: "(support.scm:648) chicken.compiler.support#second" 
o|inlining procedure: "(support.scm:648) chicken.compiler.support#first" 
o|contracted procedure: "(support.scm:656) chicken.compiler.support#split-at" 
o|inlining procedure: k5309 
o|inlining procedure: k5309 
o|inlining procedure: k10451 
o|contracted procedure: "(support.scm:665) g20932094" 
o|inlining procedure: k10477 
o|inlining procedure: k10477 
o|contracted procedure: "(support.scm:669) g20982099" 
o|substituted constant variable: a10499 
o|inlining procedure: k10451 
o|contracted procedure: "(support.scm:675) g21032104" 
o|contracted procedure: "(support.scm:659) chicken.compiler.support#copy-node-tree-and-rename" 
o|inlining procedure: k10634 
o|contracted procedure: "(support.scm:689) g21712172" 
o|inlining procedure: k10634 
o|inlining procedure: "(support.scm:694) rename2147" 
o|inlining procedure: "(support.scm:691) chicken.compiler.support#first" 
o|inlining procedure: k10673 
o|contracted procedure: "(support.scm:696) g21782179" 
o|inlining procedure: "(support.scm:698) chicken.compiler.support#first" 
o|inlining procedure: "(support.scm:697) rename2147" 
o|inlining procedure: "(support.scm:697) chicken.compiler.support#first" 
o|inlining procedure: k10673 
o|contracted procedure: "(support.scm:705) g21872188" 
o|inlining procedure: "(support.scm:707) chicken.compiler.support#second" 
o|inlining procedure: "(support.scm:701) chicken.compiler.support#first" 
o|inlining procedure: "(support.scm:700) chicken.compiler.support#first" 
o|inlining procedure: k10760 
o|contracted procedure: "(support.scm:718) g22582259" 
o|inlining procedure: k10826 
o|inlining procedure: k10826 
o|inlining procedure: "(support.scm:722) chicken.compiler.support#fourth" 
o|inlining procedure: k10874 
o|inlining procedure: "(support.scm:721) rename2147" 
o|inlining procedure: k10874 
o|inlining procedure: "(support.scm:720) chicken.compiler.support#second" 
o|inlining procedure: k10893 
o|inlining procedure: k10893 
o|inlining procedure: k10941 
o|inlining procedure: k10941 
o|inlining procedure: "(support.scm:710) chicken.compiler.support#third" 
o|inlining procedure: k10760 
o|contracted procedure: "(support.scm:724) g22982299" 
o|inlining procedure: k11002 
o|inlining procedure: k11002 
o|substituted constant variable: a11034 
o|substituted constant variable: a11036 
o|substituted constant variable: a11038 
o|substituted constant variable: a11040 
o|substituted constant variable: a11042 
o|contracted procedure: "(support.scm:686) g21622163" 
o|contracted procedure: "(support.scm:685) g21592160" 
o|contracted procedure: "(support.scm:684) g21562157" 
o|inlining procedure: k11049 
o|inlining procedure: k11049 
o|inlining procedure: k10555 
o|inlining procedure: k10555 
o|inlining procedure: k11103 
o|inlining procedure: k11103 
o|contracted procedure: "(support.scm:736) g23462347" 
o|contracted procedure: "(support.scm:738) g23572358" 
o|contracted procedure: "(support.scm:737) g23542355" 
o|contracted procedure: "(support.scm:736) g23512352" 
o|contracted procedure: "(support.scm:743) g23692370" 
o|contracted procedure: "(support.scm:742) g23662367" 
o|contracted procedure: "(support.scm:741) g23632364" 
o|inlining procedure: k11367 
o|inlining procedure: k11390 
o|contracted procedure: "(support.scm:794) g25322539" 
o|inlining procedure: k11390 
o|contracted procedure: "(support.scm:794) chicken.compiler.support#sort-symbols" 
o|inlining procedure: k11367 
o|inlining procedure: k11451 
o|contracted procedure: "(support.scm:786) g25102517" 
o|inlining procedure: k11451 
o|inlining procedure: k11478 
o|inlining procedure: k11493 
o|inlining procedure: k11511 
o|inlining procedure: k11528 
o|contracted procedure: "(support.scm:778) chicken.compiler.support#node->sexpr" 
o|inlining procedure: k11256 
o|inlining procedure: k11256 
o|contracted procedure: "(support.scm:750) g24072408" 
o|contracted procedure: "(support.scm:749) g23852386" 
o|contracted procedure: "(support.scm:748) g23822383" 
o|inlining procedure: k11566 
o|inlining procedure: k11566 
o|inlining procedure: "(support.scm:776) chicken.compiler.support#fourth" 
o|substituted constant variable: a11580 
o|substituted constant variable: a11582 
o|contracted procedure: "(support.scm:772) g25012502" 
o|inlining procedure: k11528 
o|contracted procedure: "(support.scm:770) g24902491" 
o|inlining procedure: k11511 
o|inlining procedure: k11493 
o|contracted procedure: "(support.scm:765) g24762477" 
o|contracted procedure: "(support.scm:765) g24792480" 
o|inlining procedure: k11478 
o|inlining procedure: k11638 
o|inlining procedure: k11638 
o|contracted procedure: "(support.scm:803) g25602561" 
o|contracted procedure: "(support.scm:806) chicken.compiler.support#sexpr->node" 
o|contracted procedure: "(support.scm:754) g24222423" 
o|inlining procedure: k11327 
o|inlining procedure: k11327 
o|inlining procedure: k11685 
o|inlining procedure: k11685 
o|inlining procedure: k11716 
o|inlining procedure: k11716 
o|inlining procedure: k11731 
o|inlining procedure: k11731 
o|inlining procedure: k11763 
o|inlining procedure: k11763 
o|inlining procedure: k11778 
o|inlining procedure: k11803 
o|inlining procedure: k11803 
o|inlining procedure: k11821 
o|inlining procedure: k11821 
o|contracted procedure: "(support.scm:833) g26212622" 
o|inlining procedure: k11778 
o|inlining procedure: "(support.scm:832) chicken.compiler.support#second" 
o|contracted procedure: "(support.scm:832) g26092610" 
o|inlining procedure: "(support.scm:831) chicken.compiler.support#first" 
o|contracted procedure: "(support.scm:831) g26052606" 
o|inlining procedure: k11885 
o|contracted procedure: "(support.scm:844) g26292630" 
o|contracted procedure: "(support.scm:844) g26262627" 
o|inlining procedure: k11885 
o|inlining procedure: k11934 
o|inlining procedure: k11934 
o|contracted procedure: "(support.scm:857) chicken.compiler.support#find" 
o|inlining procedure: k6273 
o|inlining procedure: k6273 
o|propagated global variable: lst566 chicken.compiler.support#foreign-callback-stubs 
o|inlining procedure: "(support.scm:856) chicken.compiler.support#first" 
o|contracted procedure: "(support.scm:856) g26642665" 
o|inlining procedure: k11974 
o|inlining procedure: k11974 
o|substituted constant variable: a11990 
o|substituted constant variable: a11992 
o|substituted constant variable: a11994 
o|inlining procedure: k11998 
o|inlining procedure: k11998 
o|substituted constant variable: a12011 
o|substituted constant variable: a12013 
o|substituted constant variable: a12015 
o|substituted constant variable: a12017 
o|contracted procedure: "(support.scm:853) g26512652" 
o|contracted procedure: "(support.scm:852) g26422643" 
o|inlining procedure: k12035 
o|inlining procedure: k12058 
o|inlining procedure: k12081 
o|inlining procedure: k12081 
o|inlining procedure: "(support.scm:875) chicken.compiler.support#first" 
o|contracted procedure: "(support.scm:875) g27042705" 
o|contracted procedure: "(support.scm:874) g27002701" 
o|inlining procedure: "(support.scm:873) chicken.compiler.support#first" 
o|contracted procedure: "(support.scm:872) g26952696" 
o|inlining procedure: k12058 
o|contracted procedure: "(support.scm:878) g27072708" 
o|substituted constant variable: a12135 
o|substituted constant variable: a12137 
o|contracted procedure: "(support.scm:870) g26912692" 
o|inlining procedure: "(support.scm:868) chicken.compiler.support#second" 
o|inlining procedure: k12035 
o|inlining procedure: "(support.scm:866) chicken.compiler.support#first" 
o|inlining procedure: "(support.scm:865) chicken.compiler.support#third" 
o|contracted procedure: "(support.scm:864) g26752676" 
o|inlining procedure: k12153 
o|inlining procedure: k12153 
o|inlining procedure: k12168 
o|inlining procedure: k12168 
o|inlining procedure: k12194 
o|inlining procedure: k12194 
o|inlining procedure: k12209 
o|inlining procedure: k12209 
o|inlining procedure: k12231 
o|inlining procedure: k12251 
o|inlining procedure: k12251 
o|inlining procedure: k12231 
o|inlining procedure: k12274 
o|contracted procedure: "(support.scm:918) chicken.compiler.support#unhide-variable" 
o|inlining procedure: k17044 
o|inlining procedure: k17044 
o|inlining procedure: k12274 
o|contracted procedure: "(support.scm:917) g27392740" 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#foreign-callback-stub 
o|contracted procedure: "(support.scm:941) g27812782" 
o|inlining procedure: k12388 
o|inlining procedure: k12388 
o|inlining procedure: k12425 
o|inlining procedure: k12425 
o|inlining procedure: k12473 
o|inlining procedure: k12473 
o|inlining procedure: k12497 
o|inlining procedure: k12497 
o|inlining procedure: k12503 
o|inlining procedure: k12503 
o|inlining procedure: k12556 
o|inlining procedure: k12556 
o|inlining procedure: k12610 
o|inlining procedure: k12610 
o|inlining procedure: k12668 
o|substituted constant variable: tmap2821 
o|substituted constant variable: tmap2821 
o|inlining procedure: k12668 
o|substituted constant variable: a12710 
o|substituted constant variable: a12711 
o|inlining procedure: k12724 
o|inlining procedure: k12724 
o|substituted constant variable: a12753 
o|substituted constant variable: a12754 
o|inlining procedure: k12737 
o|inlining procedure: k12737 
o|inlining procedure: k12816 
o|inlining procedure: k12816 
o|inlining procedure: k12870 
o|inlining procedure: k12870 
o|inlining procedure: k12898 
o|inlining procedure: k12898 
o|inlining procedure: k12922 
o|inlining procedure: k12922 
o|inlining procedure: k12944 
o|inlining procedure: k12944 
o|inlining procedure: k13018 
o|inlining procedure: k13018 
o|inlining procedure: k13059 
o|inlining procedure: k13059 
o|inlining procedure: k13065 
o|inlining procedure: k13065 
o|inlining procedure: k13091 
o|inlining procedure: k13091 
o|substituted constant variable: a13123 
o|substituted constant variable: a13125 
o|substituted constant variable: a13127 
o|substituted constant variable: a13129 
o|substituted constant variable: a13131 
o|substituted constant variable: a13133 
o|substituted constant variable: a13135 
o|substituted constant variable: a13140 
o|substituted constant variable: a13142 
o|inlining procedure: k13146 
o|inlining procedure: k13146 
o|substituted constant variable: a13159 
o|substituted constant variable: a13161 
o|substituted constant variable: a13163 
o|substituted constant variable: a13165 
o|substituted constant variable: a13173 
o|inlining procedure: k13177 
o|inlining procedure: k13177 
o|substituted constant variable: a13184 
o|substituted constant variable: a13186 
o|substituted constant variable: a13188 
o|inlining procedure: k13192 
o|inlining procedure: k13192 
o|substituted constant variable: a13205 
o|substituted constant variable: a13207 
o|substituted constant variable: a13209 
o|substituted constant variable: a13211 
o|substituted constant variable: a13213 
o|inlining procedure: k13217 
o|inlining procedure: k13217 
o|substituted constant variable: a13224 
o|substituted constant variable: a13226 
o|substituted constant variable: a13228 
o|inlining procedure: k13232 
o|inlining procedure: k13232 
o|inlining procedure: k13244 
o|inlining procedure: k13244 
o|substituted constant variable: a13257 
o|substituted constant variable: a13259 
o|substituted constant variable: a13261 
o|substituted constant variable: a13263 
o|substituted constant variable: a13265 
o|substituted constant variable: a13267 
o|inlining procedure: k13271 
o|inlining procedure: k13271 
o|inlining procedure: k13283 
o|inlining procedure: k13283 
o|substituted constant variable: a13296 
o|substituted constant variable: a13298 
o|substituted constant variable: a13300 
o|substituted constant variable: a13302 
o|substituted constant variable: a13304 
o|substituted constant variable: a13306 
o|inlining procedure: k13310 
o|inlining procedure: k13310 
o|inlining procedure: k13322 
o|inlining procedure: k13322 
o|inlining procedure: k13334 
o|inlining procedure: k13334 
o|inlining procedure: k13346 
o|inlining procedure: k13346 
o|substituted constant variable: a13359 
o|substituted constant variable: a13361 
o|substituted constant variable: a13363 
o|substituted constant variable: a13365 
o|substituted constant variable: a13367 
o|substituted constant variable: a13369 
o|substituted constant variable: a13371 
o|substituted constant variable: a13373 
o|substituted constant variable: a13375 
o|substituted constant variable: a13377 
o|inlining procedure: k13381 
o|inlining procedure: k13381 
o|inlining procedure: k13393 
o|inlining procedure: k13393 
o|inlining procedure: k13405 
o|inlining procedure: k13405 
o|inlining procedure: k13417 
o|inlining procedure: k13417 
o|substituted constant variable: a13430 
o|substituted constant variable: a13432 
o|substituted constant variable: a13434 
o|substituted constant variable: a13436 
o|substituted constant variable: a13438 
o|substituted constant variable: a13440 
o|substituted constant variable: a13442 
o|substituted constant variable: a13444 
o|substituted constant variable: a13446 
o|substituted constant variable: a13448 
o|substituted constant variable: a13450 
o|substituted constant variable: a13452 
o|substituted constant variable: a13457 
o|substituted constant variable: a13459 
o|substituted constant variable: a13464 
o|substituted constant variable: a13466 
o|inlining procedure: k13470 
o|inlining procedure: k13470 
o|substituted constant variable: a13477 
o|substituted constant variable: a13479 
o|substituted constant variable: a13481 
o|inlining procedure: k13485 
o|inlining procedure: k13485 
o|inlining procedure: k13497 
o|inlining procedure: k13497 
o|substituted constant variable: a13510 
o|substituted constant variable: a13512 
o|substituted constant variable: a13514 
o|substituted constant variable: a13516 
o|substituted constant variable: a13518 
o|substituted constant variable: a13520 
o|substituted constant variable: a13525 
o|substituted constant variable: a13527 
o|inlining procedure: k13543 
o|inlining procedure: k13543 
o|inlining procedure: k13549 
o|inlining procedure: k13549 
o|inlining procedure: k13570 
o|inlining procedure: k13570 
o|inlining procedure: k13576 
o|inlining procedure: k13576 
o|inlining procedure: k13600 
o|inlining procedure: k13600 
o|removed unused formal parameters: (t3172) 
o|inlining procedure: k13642 
o|inlining procedure: k13642 
o|inlining procedure: k13663 
o|inlining procedure: k13663 
o|inlining procedure: k13687 
o|inlining procedure: k13687 
o|inlining procedure: k13717 
o|inlining procedure: k13736 
o|inlining procedure: k13736 
o|removed unused parameter to known procedure: t3172 "(support.scm:1178) err3171" 
o|substituted constant variable: a13762 
o|substituted constant variable: a13764 
o|inlining procedure: k13768 
o|inlining procedure: k13768 
o|inlining procedure: k13780 
o|inlining procedure: k13780 
o|inlining procedure: k13792 
o|inlining procedure: k13792 
o|inlining procedure: k13804 
o|inlining procedure: k13804 
o|substituted constant variable: a13811 
o|substituted constant variable: a13813 
o|substituted constant variable: a13815 
o|substituted constant variable: a13817 
o|substituted constant variable: a13819 
o|substituted constant variable: a13821 
o|substituted constant variable: a13823 
o|substituted constant variable: a13825 
o|substituted constant variable: a13827 
o|inlining procedure: k13717 
o|removed unused parameter to known procedure: t3172 "(support.scm:1179) err3171" 
o|inlining procedure: k13840 
o|inlining procedure: k13840 
o|substituted constant variable: a13853 
o|substituted constant variable: a13855 
o|substituted constant variable: a13857 
o|substituted constant variable: a13859 
o|inlining procedure: k13863 
o|inlining procedure: k13863 
o|substituted constant variable: a13870 
o|substituted constant variable: a13872 
o|substituted constant variable: a13874 
o|inlining procedure: k13878 
o|inlining procedure: k13878 
o|inlining procedure: k13890 
o|inlining procedure: k13890 
o|substituted constant variable: a13903 
o|substituted constant variable: a13905 
o|substituted constant variable: a13907 
o|substituted constant variable: a13909 
o|substituted constant variable: a13911 
o|substituted constant variable: a13913 
o|inlining procedure: k13917 
o|inlining procedure: k13917 
o|inlining procedure: k13929 
o|inlining procedure: k13929 
o|inlining procedure: k13941 
o|inlining procedure: k13941 
o|inlining procedure: k13953 
o|inlining procedure: k13953 
o|inlining procedure: k13965 
o|inlining procedure: k13965 
o|substituted constant variable: a13978 
o|substituted constant variable: a13980 
o|substituted constant variable: a13982 
o|substituted constant variable: a13984 
o|substituted constant variable: a13986 
o|substituted constant variable: a13988 
o|substituted constant variable: a13990 
o|substituted constant variable: a13992 
o|substituted constant variable: a13994 
o|substituted constant variable: a13996 
o|substituted constant variable: a13998 
o|substituted constant variable: a14000 
o|inlining procedure: k14004 
o|inlining procedure: k14004 
o|inlining procedure: k14016 
o|inlining procedure: k14016 
o|inlining procedure: k14028 
o|inlining procedure: k14028 
o|inlining procedure: k14040 
o|inlining procedure: k14040 
o|inlining procedure: k14052 
o|inlining procedure: k14052 
o|inlining procedure: k14064 
o|inlining procedure: k14064 
o|substituted constant variable: a14071 
o|substituted constant variable: a14073 
o|substituted constant variable: a14075 
o|substituted constant variable: a14077 
o|substituted constant variable: a14079 
o|substituted constant variable: a14081 
o|substituted constant variable: a14083 
o|substituted constant variable: a14085 
o|substituted constant variable: a14087 
o|substituted constant variable: a14089 
o|substituted constant variable: a14091 
o|substituted constant variable: a14093 
o|substituted constant variable: a14095 
o|inlining procedure: k14117 
o|inlining procedure: k14117 
o|inlining procedure: k14144 
o|inlining procedure: k14144 
o|inlining procedure: k14166 
o|inlining procedure: k14166 
o|inlining procedure: "(support.scm:1206) err3323" 
o|substituted constant variable: a14195 
o|inlining procedure: k14199 
o|inlining procedure: k14199 
o|inlining procedure: k14211 
o|inlining procedure: k14211 
o|inlining procedure: k14223 
o|inlining procedure: k14223 
o|inlining procedure: k14235 
o|inlining procedure: k14235 
o|substituted constant variable: a14242 
o|substituted constant variable: a14244 
o|substituted constant variable: a14246 
o|substituted constant variable: a14248 
o|substituted constant variable: a14250 
o|substituted constant variable: a14252 
o|substituted constant variable: a14254 
o|substituted constant variable: a14256 
o|substituted constant variable: a14258 
o|inlining procedure: "(support.scm:1207) err3323" 
o|inlining procedure: k14271 
o|inlining procedure: k14271 
o|inlining procedure: k14283 
o|inlining procedure: k14283 
o|substituted constant variable: a14290 
o|substituted constant variable: a14292 
o|substituted constant variable: a14294 
o|substituted constant variable: a14296 
o|substituted constant variable: a14298 
o|inlining procedure: k14302 
o|inlining procedure: k14302 
o|inlining procedure: k14314 
o|inlining procedure: k14314 
o|inlining procedure: k14326 
o|inlining procedure: k14326 
o|inlining procedure: k14338 
o|inlining procedure: k14338 
o|inlining procedure: k14350 
o|inlining procedure: k14350 
o|inlining procedure: k14362 
o|inlining procedure: k14362 
o|inlining procedure: k14374 
o|inlining procedure: k14374 
o|inlining procedure: k14386 
o|inlining procedure: k14386 
o|inlining procedure: k14398 
o|inlining procedure: k14398 
o|inlining procedure: k14410 
o|inlining procedure: k14410 
o|inlining procedure: k14422 
o|inlining procedure: k14422 
o|inlining procedure: k14434 
o|inlining procedure: k14434 
o|inlining procedure: k14446 
o|inlining procedure: k14446 
o|inlining procedure: k14458 
o|inlining procedure: k14458 
o|inlining procedure: k14470 
o|inlining procedure: k14470 
o|substituted constant variable: a14483 
o|substituted constant variable: a14485 
o|substituted constant variable: a14487 
o|substituted constant variable: a14489 
o|substituted constant variable: a14491 
o|substituted constant variable: a14493 
o|substituted constant variable: a14495 
o|substituted constant variable: a14497 
o|substituted constant variable: a14499 
o|substituted constant variable: a14501 
o|substituted constant variable: a14503 
o|substituted constant variable: a14505 
o|substituted constant variable: a14507 
o|substituted constant variable: a14509 
o|substituted constant variable: a14511 
o|substituted constant variable: a14513 
o|substituted constant variable: a14515 
o|substituted constant variable: a14517 
o|substituted constant variable: a14519 
o|substituted constant variable: a14521 
o|substituted constant variable: a14523 
o|substituted constant variable: a14525 
o|substituted constant variable: a14527 
o|substituted constant variable: a14529 
o|substituted constant variable: a14531 
o|substituted constant variable: a14533 
o|substituted constant variable: a14535 
o|substituted constant variable: a14537 
o|substituted constant variable: a14539 
o|substituted constant variable: a14541 
o|substituted constant variable: a14543 
o|substituted constant variable: a14545 
o|inlining procedure: k14558 
o|inlining procedure: k14558 
o|inlining procedure: k14587 
o|inlining procedure: k14587 
o|inlining procedure: k14619 
o|inlining procedure: k14619 
o|inlining procedure: k14649 
o|inlining procedure: k14649 
o|inlining procedure: k14668 
o|inlining procedure: k14668 
o|inlining procedure: k14690 
o|inlining procedure: k14690 
o|substituted constant variable: a14755 
o|substituted constant variable: a14760 
o|substituted constant variable: a14762 
o|substituted constant variable: a14763 
o|inlining procedure: k14771 
o|substituted constant variable: a14781 
o|inlining procedure: k14771 
o|substituted constant variable: a14782 
o|substituted constant variable: a14792 
o|substituted constant variable: a14794 
o|substituted constant variable: a14796 
o|substituted constant variable: a14801 
o|substituted constant variable: a14803 
o|substituted constant variable: a14808 
o|substituted constant variable: a14810 
o|substituted constant variable: a14812 
o|substituted constant variable: a14817 
o|substituted constant variable: a14819 
o|inlining procedure: k14826 
o|inlining procedure: k14826 
o|inlining procedure: k14841 
o|inlining procedure: k14841 
o|inlining procedure: k14859 
o|inlining procedure: k14859 
o|substituted constant variable: a14866 
o|inlining procedure: k14867 
o|inlining procedure: k14867 
o|inlining procedure: k14882 
o|inlining procedure: k14882 
o|substituted constant variable: a14889 
o|inlining procedure: k14890 
o|inlining procedure: k14890 
o|inlining procedure: k14902 
o|inlining procedure: k14902 
o|substituted constant variable: a14909 
o|inlining procedure: k14910 
o|inlining procedure: k14910 
o|inlining procedure: k14925 
o|inlining procedure: k14925 
o|substituted constant variable: a14942 
o|inlining procedure: k14943 
o|inlining procedure: k14943 
o|inlining procedure: k14955 
o|inlining procedure: k14955 
o|inlining procedure: k14967 
o|inlining procedure: k14967 
o|inlining procedure: k14979 
o|inlining procedure: k14979 
o|inlining procedure: k14991 
o|inlining procedure: k14991 
o|inlining procedure: k15003 
o|inlining procedure: k15003 
o|inlining procedure: k15018 
o|inlining procedure: k15018 
o|inlining procedure: k15033 
o|inlining procedure: k15033 
o|inlining procedure: k15051 
o|inlining procedure: k15051 
o|inlining procedure: k15064 
o|inlining procedure: k15064 
o|inlining procedure: k15086 
o|inlining procedure: k15086 
o|inlining procedure: k15098 
o|inlining procedure: k15098 
o|substituted constant variable: a15105 
o|substituted constant variable: a15107 
o|substituted constant variable: a15109 
o|substituted constant variable: a15111 
o|inlining procedure: k15115 
o|inlining procedure: k15115 
o|substituted constant variable: a15128 
o|substituted constant variable: a15130 
o|substituted constant variable: a15132 
o|substituted constant variable: a15134 
o|substituted constant variable: a15136 
o|inlining procedure: k15140 
o|inlining procedure: k15140 
o|substituted constant variable: a15147 
o|substituted constant variable: a15149 
o|substituted constant variable: a15151 
o|substituted constant variable: a15156 
o|substituted constant variable: a15158 
o|inlining procedure: k15162 
o|inlining procedure: k15162 
o|substituted constant variable: a15175 
o|substituted constant variable: a15177 
o|substituted constant variable: a15179 
o|substituted constant variable: a15181 
o|substituted constant variable: a15183 
o|substituted constant variable: a15185 
o|inlining procedure: k15189 
o|inlining procedure: k15189 
o|inlining procedure: k15201 
o|inlining procedure: k15201 
o|inlining procedure: k15213 
o|inlining procedure: k15213 
o|inlining procedure: k15225 
o|inlining procedure: k15225 
o|substituted constant variable: a15232 
o|substituted constant variable: a15234 
o|substituted constant variable: a15236 
o|substituted constant variable: a15238 
o|substituted constant variable: a15240 
o|substituted constant variable: a15242 
o|substituted constant variable: a15244 
o|substituted constant variable: a15246 
o|substituted constant variable: a15248 
o|substituted constant variable: a15250 
o|substituted constant variable: a15252 
o|substituted constant variable: a15254 
o|substituted constant variable: a15256 
o|substituted constant variable: a15258 
o|substituted constant variable: a15260 
o|substituted constant variable: a15262 
o|substituted constant variable: a15264 
o|substituted constant variable: a15266 
o|substituted constant variable: a15268 
o|inlining procedure: k15272 
o|inlining procedure: k15272 
o|inlining procedure: k15284 
o|inlining procedure: k15284 
o|inlining procedure: k15296 
o|inlining procedure: k15296 
o|inlining procedure: k15308 
o|inlining procedure: k15308 
o|substituted constant variable: a15321 
o|substituted constant variable: a15323 
o|substituted constant variable: a15325 
o|substituted constant variable: a15327 
o|substituted constant variable: a15329 
o|substituted constant variable: a15331 
o|substituted constant variable: a15333 
o|substituted constant variable: a15335 
o|substituted constant variable: a15337 
o|substituted constant variable: a15339 
o|substituted constant variable: a15341 
o|substituted constant variable: a15343 
o|substituted constant variable: a15345 
o|substituted constant variable: a15347 
o|substituted constant variable: a15352 
o|substituted constant variable: a15354 
o|substituted constant variable: a15359 
o|substituted constant variable: a15361 
o|inlining procedure: k15365 
o|inlining procedure: k15365 
o|inlining procedure: k15377 
o|inlining procedure: k15377 
o|inlining procedure: k15389 
o|inlining procedure: k15389 
o|substituted constant variable: a15402 
o|substituted constant variable: a15404 
o|substituted constant variable: a15406 
o|substituted constant variable: a15408 
o|substituted constant variable: a15410 
o|substituted constant variable: a15412 
o|substituted constant variable: a15414 
o|substituted constant variable: a15416 
o|substituted constant variable: a15421 
o|substituted constant variable: a15423 
o|substituted constant variable: a15425 
o|inlining procedure: k15451 
o|inlining procedure: k15475 
o|inlining procedure: k15475 
o|inlining procedure: "(support.scm:1319) chicken.compiler.support#first" 
o|contracted procedure: "(support.scm:1319) g37213722" 
o|inlining procedure: k15451 
o|inlining procedure: k15539 
o|inlining procedure: k15539 
o|inlining procedure: k15562 
o|inlining procedure: k15562 
o|substituted constant variable: a15569 
o|substituted constant variable: a15571 
o|substituted constant variable: a15573 
o|substituted constant variable: a15578 
o|substituted constant variable: a15580 
o|contracted procedure: "(support.scm:1317) g37143715" 
o|contracted procedure: "(support.scm:1316) g37053706" 
o|inlining procedure: k15611 
o|inlining procedure: k15611 
o|inlining procedure: k15629 
o|inlining procedure: k15629 
o|consed rest parameter at call site: "(support.scm:1344) chicken.compiler.support#lset-adjoin/eq?" 2 
o|consed rest parameter at call site: "(support.scm:1342) chicken.compiler.support#lset-adjoin/eq?" 2 
o|inlining procedure: "(support.scm:1340) chicken.compiler.support#first" 
o|inlining procedure: k15649 
o|consed rest parameter at call site: "(support.scm:1347) chicken.compiler.support#lset-adjoin/eq?" 2 
o|inlining procedure: "(support.scm:1346) chicken.compiler.support#first" 
o|inlining procedure: k15649 
o|inlining procedure: "(support.scm:1351) chicken.compiler.support#second" 
o|inlining procedure: "(support.scm:1350) chicken.compiler.support#first" 
o|inlining procedure: k15699 
o|inlining procedure: "(support.scm:1356) chicken.compiler.support#first" 
o|inlining procedure: "(support.scm:1354) chicken.compiler.support#third" 
o|inlining procedure: k15699 
o|substituted constant variable: a15730 
o|substituted constant variable: a15732 
o|substituted constant variable: a15734 
o|substituted constant variable: a15736 
o|inlining procedure: k15740 
o|inlining procedure: k15740 
o|inlining procedure: k15752 
o|inlining procedure: k15752 
o|substituted constant variable: a15759 
o|substituted constant variable: a15761 
o|substituted constant variable: a15763 
o|substituted constant variable: a15765 
o|substituted constant variable: a15767 
o|contracted procedure: "(support.scm:1337) g37913792" 
o|contracted procedure: "(support.scm:1336) g37823783" 
o|contracted procedure: "(support.scm:1335) g37793780" 
o|inlining procedure: k15785 
o|inlining procedure: k15785 
o|inlining procedure: k15818 
o|inlining procedure: k15818 
o|substituted constant variable: a15828 
o|substituted constant variable: a15833 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#block-variable-literal 
o|substituted constant variable: a15867 
o|substituted constant variable: a15868 
o|inlining procedure: k15890 
o|inlining procedure: k15890 
o|inlining procedure: k15932 
o|inlining procedure: k15932 
o|inlining procedure: k15944 
o|inlining procedure: k15944 
o|inlining procedure: k15974 
o|inlining procedure: k15974 
o|inlining procedure: k15997 
o|inlining procedure: k15997 
o|substituted constant variable: chicken.compiler.support#real-name-max-depth 
o|inlining procedure: k16049 
o|inlining procedure: k16049 
o|propagated global variable: out39163919 ##sys#standard-output 
o|substituted constant variable: a16065 
o|substituted constant variable: a16066 
o|propagated global variable: out39163919 ##sys#standard-output 
o|inlining procedure: k16082 
o|substituted constant variable: a16106 
o|inlining procedure: k16082 
o|inlining procedure: k16117 
o|inlining procedure: k16117 
o|inlining procedure: k16132 
o|inlining procedure: k16132 
o|inlining procedure: k16150 
o|inlining procedure: k16150 
o|inlining procedure: k16153 
o|inlining procedure: k16153 
o|inlining procedure: "(support.scm:1470) chicken.compiler.support#second" 
o|inlining procedure: k16210 
o|inlining procedure: k16231 
o|inlining procedure: k16231 
o|substituted constant variable: a16259 
o|substituted constant variable: a16272 
o|inlining procedure: k16210 
o|inlining procedure: k16343 
o|contracted procedure: "(support.scm:1482) g39893998" 
o|inlining procedure: k16343 
o|inlining procedure: k16377 
o|contracted procedure: "(support.scm:1481) g39583967" 
o|inlining procedure: "(support.scm:1481) chicken.compiler.support#first" 
o|contracted procedure: "(support.scm:1481) g39703971" 
o|inlining procedure: k16377 
o|contracted procedure: "(support.scm:1499) g40334034" 
o|inlining procedure: k16426 
o|inlining procedure: k16463 
o|inlining procedure: k16463 
o|contracted procedure: "(support.scm:1502) g40444045" 
o|inlining procedure: "(support.scm:1501) chicken.compiler.support#first" 
o|contracted procedure: "(support.scm:1501) g40404041" 
o|inlining procedure: k16426 
o|contracted procedure: "(support.scm:1500) g40364037" 
o|inlining procedure: k16524 
o|inlining procedure: k16524 
o|inlining procedure: k16537 
o|inlining procedure: k16537 
o|substituted constant variable: a16571 
o|merged explicitly consed rest parameter: args40724078 
o|consed rest parameter at call site: tmp25103 1 
o|inlining procedure: k16593 
o|inlining procedure: k16593 
o|inlining procedure: k16612 
o|inlining procedure: "(support.scm:1530) getsize4062" 
o|inlining procedure: k16612 
o|inlining procedure: "(support.scm:1532) getsize4062" 
o|substituted constant variable: a16684 
o|propagated global variable: out41084121 ##sys#standard-output 
o|substituted constant variable: a16686 
o|substituted constant variable: a16687 
o|propagated global variable: out41444147 ##sys#standard-output 
o|substituted constant variable: a16730 
o|substituted constant variable: a16731 
o|inlining procedure: k16720 
o|inlining procedure: k16747 
o|propagated global variable: out41534156 ##sys#standard-output 
o|substituted constant variable: a16754 
o|substituted constant variable: a16755 
o|inlining procedure: k16747 
o|propagated global variable: out41534156 ##sys#standard-output 
o|propagated global variable: out41444147 ##sys#standard-output 
o|inlining procedure: k16720 
o|inlining procedure: k16780 
o|inlining procedure: k16780 
o|propagated global variable: out41084121 ##sys#standard-output 
o|contracted procedure: "(support.scm:1546) g41054106" 
o|contracted procedure: "(support.scm:1545) g41024103" 
o|contracted procedure: "(support.scm:1544) g40994100" 
o|inlining procedure: k16803 
o|inlining procedure: k16828 
o|inlining procedure: k16828 
o|inlining procedure: k16803 
o|inlining procedure: k16852 
o|contracted procedure: "(support.scm:1586) chicken.compiler.support#scan-sharp-greater-string" 
o|inlining procedure: k16889 
o|inlining procedure: k16889 
o|substituted constant variable: a16902 
o|substituted constant variable: a16913 
o|inlining procedure: k16909 
o|substituted constant variable: a16935 
o|inlining procedure: k16909 
o|inlining procedure: k16852 
o|inlining procedure: k16946 
o|inlining procedure: k16961 
o|inlining procedure: k16961 
o|inlining procedure: k16946 
o|inlining procedure: k16970 
o|inlining procedure: k16970 
o|contracted procedure: "(support.scm:1629) g42154216" 
o|contracted procedure: "(support.scm:1632) g42314232" 
o|inlining procedure: k17059 
o|inlining procedure: k17059 
o|substituted constant variable: a17075 
o|substituted constant variable: a17077 
o|contracted procedure: "(support.scm:1656) g42824283" 
o|contracted procedure: "(support.scm:1658) g42934294" 
o|contracted procedure: "(support.scm:1659) g43044305" 
o|inlining procedure: k17138 
o|inlining procedure: k17181 
o|contracted procedure: "(support.scm:1667) g43274334" 
o|inlining procedure: k17181 
o|substituted constant variable: a17206 
o|substituted constant variable: a17207 
o|inlining procedure: k17138 
o|substituted constant variable: chicken.compiler.support#constant659 
o|substituted constant variable: a17274 
o|substituted constant variable: a17275 
o|contracted procedure: "(support.scm:483) g12951296" 
o|contracted procedure: "(support.scm:483) g12921293" 
o|replaced variables: 2848 
o|removed binding forms: 646 
o|substituted constant variable: r525217309 
o|substituted constant variable: r555317313 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#first 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#second 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#third 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#fourth 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#filter 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#constant659 
o|propagated global variable: out696699 ##sys#standard-output 
o|propagated global variable: out711714 chicken.compiler.support#collected-debugging-output 
o|substituted constant variable: r655817343 
o|inlining procedure: k6572 
o|substituted constant variable: r655817344 
o|inlining procedure: k6581 
o|propagated global variable: out747750 chicken.compiler.support#collected-debugging-output 
o|converted assignments to bindings: (collect732) 
o|substituted constant variable: r682717355 
o|converted assignments to bindings: (err844) 
o|substituted constant variable: r698517363 
o|substituted constant variable: r703217365 
o|substituted constant variable: r703217366 
o|substituted constant variable: r706917372 
o|substituted constant variable: r738517398 
o|substituted constant variable: r749917414 
o|substituted constant variable: r753717415 
o|substituted constant variable: r765517425 
o|substituted constant variable: r793217436 
o|substituted constant variable: r580617441 
o|substituted constant variable: r795017442 
o|substituted constant variable: r806617450 
o|propagated global variable: out12131216 ##sys#standard-output 
o|substituted constant variable: c1311 
o|substituted constant variable: s1313 
o|substituted constant variable: c1318 
o|substituted constant variable: s1320 
o|substituted constant variable: p1345 
o|substituted constant variable: r843517470 
o|substituted constant variable: c1381 
o|substituted constant variable: c1416 
o|substituted constant variable: c1421 
o|substituted constant variable: c1434 
o|substituted constant variable: c1439 
o|substituted constant variable: p1440 
o|substituted constant variable: s1441 
o|substituted constant variable: c1444 
o|substituted constant variable: s1522 
o|substituted constant variable: c1525 
o|substituted constant variable: s1527 
o|substituted constant variable: c1533 
o|substituted constant variable: c1565 
o|substituted constant variable: c1613 
o|substituted constant variable: c1646 
o|substituted constant variable: mark1656 
o|substituted constant variable: c1690 
o|substituted constant variable: c2046 
o|substituted constant variable: p2047 
o|substituted constant variable: c2095 
o|substituted constant variable: c2100 
o|substituted constant variable: c2105 
o|removed side-effect free assignment to unused variable: rename2147 
o|substituted constant variable: s2175 
o|substituted constant variable: c2180 
o|substituted constant variable: c2189 
o|substituted constant variable: c2260 
o|substituted constant variable: r1087517723 
o|substituted constant variable: r1087517723 
o|substituted constant variable: r1156717760 
o|substituted constant variable: mark2504 
o|substituted constant variable: r1152917767 
o|substituted constant variable: r1151217768 
o|substituted constant variable: r1149417769 
o|substituted constant variable: mark2482 
o|substituted constant variable: mark2567 
o|substituted constant variable: r1173217780 
o|substituted constant variable: r1182217786 
o|substituted constant variable: r1177917788 
o|substituted constant variable: r1188617800 
o|substituted constant variable: r1193517801 
o|substituted constant variable: r627417803 
o|substituted constant variable: r1197517811 
o|substituted constant variable: r1208217817 
o|substituted constant variable: r1203617834 
o|substituted constant variable: r1216917848 
o|substituted constant variable: r1221017852 
o|substituted constant variable: r1225217856 
o|substituted constant variable: r1225217856 
o|substituted constant variable: rest27862789 
o|substituted constant variable: mark2788 
o|substituted constant variable: r1242617867 
o|substituted constant variable: r1242617867 
o|substituted constant variable: r1355017944 
o|substituted constant variable: r1357717948 
o|substituted constant variable: r1364317951 
o|converted assignments to bindings: (err3171) 
o|removed side-effect free assignment to unused variable: err3323 
o|substituted constant variable: r1477218070 
o|substituted constant variable: r1482718071 
o|substituted constant variable: r1484218073 
o|substituted constant variable: r1486018075 
o|substituted constant variable: r1486018076 
o|substituted constant variable: r1486818077 
o|substituted constant variable: r1488318079 
o|substituted constant variable: r1488318080 
o|substituted constant variable: r1489118081 
o|substituted constant variable: r1490318083 
o|substituted constant variable: r1490318084 
o|substituted constant variable: r1491118085 
o|substituted constant variable: r1494418089 
o|substituted constant variable: r1495618091 
o|substituted constant variable: r1496818093 
o|substituted constant variable: r1498018095 
o|substituted constant variable: r1499218097 
o|substituted constant variable: r1500418099 
o|substituted constant variable: r1501918101 
o|substituted constant variable: r1503418103 
o|substituted constant variable: r1505218105 
o|substituted constant variable: r1506518107 
o|substituted constant variable: r1508718109 
o|substituted constant variable: r1561218154 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#real-name-max-depth 
o|converted assignments to bindings: (resolve3885) 
o|substituted constant variable: r1605018213 
o|propagated global variable: out39163919 ##sys#standard-output 
o|substituted constant variable: r1613318219 
o|substituted constant variable: r1615418223 
o|substituted constant variable: r1646418244 
o|converted assignments to bindings: (constant-node?4031) 
o|removed side-effect free assignment to unused variable: getsize4062 
o|substituted constant variable: r1653818254 
o|contracted procedure: "(support.scm:1536) chicken.compiler.support#list-tabulate" 
o|substituted constant variable: r616117325 
o|propagated global variable: out41084121 ##sys#standard-output 
o|propagated global variable: out41444147 ##sys#standard-output 
o|propagated global variable: out41534156 ##sys#standard-output 
o|substituted constant variable: r1682918281 
o|substituted constant variable: r1682918281 
o|substituted constant variable: r1694718294 
o|substituted constant variable: r1697118296 
o|substituted constant variable: mark4222 
o|substituted constant variable: mark4238 
o|substituted constant variable: r1706018297 
o|substituted constant variable: mark4285 
o|substituted constant variable: mark4296 
o|substituted constant variable: mark4307 
o|substituted constant variable: r1713918302 
o|simplifications: ((let . 5)) 
o|replaced variables: 139 
o|removed binding forms: 2811 
o|substituted constant variable: r65581734318328 
o|substituted constant variable: r65581734418330 
o|inlining procedure: "(support.scm:396) chicken.compiler.support#alist-cons" 
o|inlining procedure: "(support.scm:436) chicken.compiler.support#alist-cons" 
o|inlining procedure: "(support.scm:444) chicken.compiler.support#alist-cons" 
o|inlining procedure: "(support.scm:703) chicken.compiler.support#alist-cons" 
o|inlining procedure: k11646 
o|inlining procedure: "(support.scm:818) chicken.compiler.support#alist-cons" 
o|inlining procedure: k11980 
o|inlining procedure: k12365 
o|inlining procedure: k13113 
o|inlining procedure: k13540 
o|inlining procedure: k13540 
o|inlining procedure: k13540 
o|inlining procedure: k13567 
o|inlining procedure: k13567 
o|inlining procedure: k13567 
o|inlining procedure: k15658 
o|inlining procedure: k15658 
o|inlining procedure: k16147 
o|inlining procedure: k16147 
o|inlining procedure: "(support.scm:1524) fits?4063" 
o|inlining procedure: "(support.scm:1528) fits?4063" 
o|inlining procedure: "(support.scm:1530) fits?4063" 
o|inlining procedure: "(support.scm:1533) fits?4063" 
o|converted assignments to bindings: (fits?4063) 
o|inlining procedure: "(support.scm:1569) chicken.compiler.support#alist-cons" 
o|inlining procedure: "(support.scm:1569) chicken.compiler.support#alist-cons" 
o|inlining procedure: k16996 
o|inlining procedure: k17016 
o|inlining procedure: k17081 
o|inlining procedure: k17233 
o|simplifications: ((let . 1)) 
o|replaced variables: 113 
o|removed binding forms: 277 
o|removed side-effect free assignment to unused variable: chicken.compiler.support#alist-cons 
o|inlining procedure: k8840 
o|substituted constant variable: r1164718716 
o|contracted procedure: k12279 
o|substituted constant variable: r1236618740 
o|substituted constant variable: r1354118744 
o|substituted constant variable: r1354118744 
o|substituted constant variable: r1354118744 
o|substituted constant variable: r1354118747 
o|substituted constant variable: r1354118747 
o|substituted constant variable: r1354118747 
o|substituted constant variable: r1354118750 
o|substituted constant variable: r1354118750 
o|substituted constant variable: r1354118750 
o|substituted constant variable: r1356818753 
o|substituted constant variable: r1356818753 
o|substituted constant variable: r1356818753 
o|substituted constant variable: r1356818756 
o|substituted constant variable: r1356818756 
o|substituted constant variable: r1356818756 
o|substituted constant variable: r1356818759 
o|substituted constant variable: r1356818759 
o|substituted constant variable: r1356818759 
o|substituted constant variable: r1614818780 
o|substituted constant variable: r1614818780 
o|substituted constant variable: r1614818780 
o|substituted constant variable: r1614818783 
o|substituted constant variable: r1614818783 
o|substituted constant variable: r1614818783 
o|contracted procedure: k16619 
o|contracted procedure: k16622 
o|substituted constant variable: z36318821 
o|substituted constant variable: r1699718827 
o|substituted constant variable: r1701718828 
o|substituted constant variable: r1708218829 
o|simplifications: ((let . 1)) 
o|replaced variables: 58 
o|removed binding forms: 122 
o|removed conditional forms: 8 
o|substituted constant variable: r884118890 
o|removed binding forms: 73 
o|removed conditional forms: 1 
o|removed binding forms: 1 
o|simplifications: ((if . 72) (##core#call . 1440)) 
o|  call simplifications:
o|    chicken.base#bignum?
o|    scheme#char=?
o|    scheme#read-char	3
o|    ##sys#size
o|    chicken.fixnum#fx>	2
o|    scheme#write-char	6
o|    chicken.base#flonum?
o|    scheme#procedure?
o|    scheme#>
o|    chicken.fixnum#fx+	3
o|    scheme#string-length	4
o|    scheme#string-ref
o|    scheme#list?	5
o|    scheme#vector-ref	6
o|    scheme#vector	2
o|    scheme#<
o|    scheme#-
o|    ##sys#call-with-values	4
o|    scheme#cddddr
o|    scheme#list-ref
o|    scheme#cdddr
o|    scheme#caar	2
o|    scheme#cadddr	4
o|    scheme#caddr	10
o|    scheme#cadr	38
o|    ##sys#check-structure	12
o|    ##sys#block-ref	9
o|    ##sys#structure?	5
o|    ##sys#make-structure	34
o|    scheme#values	4
o|    scheme#assq	16
o|    scheme#length	6
o|    ##sys#setslot	35
o|    chicken.base#atom?
o|    ##sys#apply	3
o|    ##sys#cons	8
o|    scheme#equal?	3
o|    ##sys#list	139
o|    chicken.base#fixnum?	2
o|    scheme#number?	4
o|    scheme#char?	4
o|    scheme#string?	2
o|    scheme#boolean?	4
o|    scheme#vector?	2
o|    scheme#eq?	352
o|    scheme#eof-object?	7
o|    scheme#member
o|    scheme#cddr	4
o|    scheme#list	49
o|    scheme#string=?	2
o|    ##sys#foreign-fixnum-argument	2
o|    scheme#char-alphabetic?	2
o|    scheme#char-numeric?
o|    scheme#char->integer
o|    chicken.fixnum#fx>=	3
o|    chicken.fixnum#fx<	4
o|    scheme#string->list	3
o|    scheme#list->string
o|    ##sys#check-list	39
o|    ##sys#slot	179
o|    scheme#symbol?	17
o|    scheme#pair?	66
o|    scheme#apply	7
o|    scheme#memq	8
o|    scheme#cdr	24
o|    scheme#null?	47
o|    scheme#not	22
o|    chicken.fixnum#fx<=	7
o|    scheme#car	84
o|    chicken.fixnum#fx-	2
o|    scheme#cons	112
o|contracted procedure: k5254 
o|contracted procedure: k5261 
o|contracted procedure: k5271 
o|contracted procedure: k5518 
o|contracted procedure: k5527 
o|contracted procedure: k5540 
o|contracted procedure: k5555 
o|contracted procedure: k5570 
o|contracted procedure: k5585 
o|contracted procedure: k5596 
o|contracted procedure: k5931 
o|contracted procedure: k5921 
o|contracted procedure: k5980 
o|contracted procedure: k6006 
o|contracted procedure: k5986 
o|contracted procedure: k6000 
o|contracted procedure: k6431 
o|contracted procedure: k6459 
o|contracted procedure: k6495 
o|contracted procedure: k6525 
o|contracted procedure: k6535 
o|contracted procedure: k6539 
o|contracted procedure: k6621 
o|propagated global variable: out747750 chicken.compiler.support#collected-debugging-output 
o|contracted procedure: k6637 
o|contracted procedure: k6647 
o|contracted procedure: k6651 
o|contracted procedure: k6721 
o|contracted procedure: k6739 
o|contracted procedure: k6749 
o|contracted procedure: k6753 
o|contracted procedure: k6792 
o|contracted procedure: k6796 
o|contracted procedure: k6800 
o|contracted procedure: k6814 
o|contracted procedure: k6876 
o|contracted procedure: k6829 
o|contracted procedure: k6835 
o|contracted procedure: k6855 
o|contracted procedure: k6888 
o|contracted procedure: k6894 
o|contracted procedure: k6900 
o|contracted procedure: k6909 
o|contracted procedure: k6919 
o|contracted procedure: k6923 
o|contracted procedure: k6939 
o|contracted procedure: k6949 
o|contracted procedure: k6970 
o|contracted procedure: k6987 
o|contracted procedure: k6990 
o|contracted procedure: k6993 
o|contracted procedure: k6999 
o|contracted procedure: k7028 
o|contracted procedure: k7034 
o|contracted procedure: k7050 
o|contracted procedure: k7071 
o|contracted procedure: k7078 
o|contracted procedure: k7081 
o|contracted procedure: k7090 
o|contracted procedure: k7096 
o|contracted procedure: k7116 
o|contracted procedure: k7123 
o|contracted procedure: k7132 
o|contracted procedure: k7147 
o|contracted procedure: k7160 
o|contracted procedure: k7167 
o|contracted procedure: k7176 
o|contracted procedure: k7235 
o|contracted procedure: k7188 
o|contracted procedure: k7231 
o|contracted procedure: k7208 
o|inlining procedure: k7205 
o|inlining procedure: k7205 
o|contracted procedure: k7250 
o|contracted procedure: k7266 
o|contracted procedure: k7327 
o|contracted procedure: k7292 
o|contracted procedure: k7308 
o|contracted procedure: k7324 
o|contracted procedure: k7336 
o|contracted procedure: k7342 
o|contracted procedure: k7348 
o|contracted procedure: k7354 
o|contracted procedure: k7360 
o|contracted procedure: k7372 
o|contracted procedure: k7387 
o|contracted procedure: k7398 
o|contracted procedure: k7404 
o|contracted procedure: k7410 
o|contracted procedure: k7416 
o|contracted procedure: k7434 
o|contracted procedure: k7440 
o|contracted procedure: k7446 
o|contracted procedure: k7452 
o|contracted procedure: k7461 
o|contracted procedure: k7474 
o|contracted procedure: k7480 
o|contracted procedure: k7501 
o|contracted procedure: k7517 
o|contracted procedure: k7539 
o|contracted procedure: k7597 
o|contracted procedure: k7545 
o|contracted procedure: k7553 
o|contracted procedure: k7578 
o|contracted procedure: k7568 
o|contracted procedure: k7657 
o|contracted procedure: k7671 
o|contracted procedure: k7663 
o|contracted procedure: k7689 
o|contracted procedure: k7703 
o|contracted procedure: k7739 
o|contracted procedure: k7745 
o|contracted procedure: k7754 
o|contracted procedure: k7764 
o|contracted procedure: k7768 
o|contracted procedure: k7833 
o|contracted procedure: k7829 
o|contracted procedure: k7801 
o|contracted procedure: k7825 
o|contracted procedure: k7821 
o|contracted procedure: k7805 
o|contracted procedure: k7817 
o|contracted procedure: k7813 
o|contracted procedure: k7809 
o|contracted procedure: k7797 
o|contracted procedure: k574618606 
o|propagated global variable: z36318603 chicken.compiler.support#profile-lambda-list 
o|contracted procedure: k7922 
o|contracted procedure: k7914 
o|contracted procedure: k7918 
o|contracted procedure: k7910 
o|contracted procedure: k7843 
o|contracted procedure: k7847 
o|contracted procedure: k7869 
o|contracted procedure: k7881 
o|contracted procedure: k7884 
o|contracted procedure: k7887 
o|contracted procedure: k7895 
o|contracted procedure: k7903 
o|contracted procedure: k7866 
o|contracted procedure: k7856 
o|contracted procedure: k7860 
o|propagated global variable: g11361140 chicken.compiler.support#profile-lambda-list 
o|contracted procedure: k7934 
o|contracted procedure: k5796 
o|contracted procedure: k5808 
o|contracted procedure: k5831 
o|contracted procedure: k5839 
o|contracted procedure: k7970 
o|contracted procedure: k7990 
o|contracted procedure: k574618617 
o|contracted procedure: k8004 
o|contracted procedure: k8000 
o|contracted procedure: k8016 
o|contracted procedure: k8030 
o|contracted procedure: k8026 
o|contracted procedure: k8041 
o|contracted procedure: k8045 
o|contracted procedure: k574618624 
o|contracted procedure: k8056 
o|contracted procedure: k8052 
o|contracted procedure: k8075 
o|contracted procedure: k8081 
o|contracted procedure: k8099 
o|contracted procedure: k8103 
o|contracted procedure: k8116 
o|contracted procedure: k8147 
o|contracted procedure: k8150 
o|contracted procedure: k8162 
o|contracted procedure: k8184 
o|contracted procedure: k8180 
o|contracted procedure: k8165 
o|contracted procedure: k8168 
o|contracted procedure: k8176 
o|contracted procedure: k8206 
o|contracted procedure: k8215 
o|contracted procedure: k8224 
o|contracted procedure: k8233 
o|contracted procedure: k8242 
o|contracted procedure: k8251 
o|contracted procedure: k8278 
o|contracted procedure: k8293 
o|contracted procedure: k8305 
o|contracted procedure: k8319 
o|contracted procedure: k9479 
o|contracted procedure: k8325 
o|contracted procedure: k9475 
o|contracted procedure: k8334 
o|contracted procedure: k8341 
o|contracted procedure: k8344 
o|contracted procedure: k8358 
o|contracted procedure: k8362 
o|contracted procedure: k8374 
o|contracted procedure: k8377 
o|contracted procedure: k8380 
o|contracted procedure: k8388 
o|contracted procedure: k8396 
o|contracted procedure: k8405 
o|contracted procedure: k8408 
o|contracted procedure: k8431 
o|contracted procedure: k8437 
o|contracted procedure: k8448 
o|contracted procedure: k8451 
o|contracted procedure: k8454 
o|contracted procedure: k8460 
o|contracted procedure: k8483 
o|contracted procedure: k8492 
o|contracted procedure: k8495 
o|contracted procedure: k8498 
o|contracted procedure: k8505 
o|contracted procedure: k8518 
o|contracted procedure: k8521 
o|contracted procedure: k8524 
o|contracted procedure: k8532 
o|contracted procedure: k8540 
o|contracted procedure: k5861 
o|contracted procedure: k5869 
o|contracted procedure: k5881 
o|contracted procedure: k5903 
o|contracted procedure: k5899 
o|contracted procedure: k5884 
o|contracted procedure: k5887 
o|contracted procedure: k5895 
o|contracted procedure: k8549 
o|contracted procedure: k8552 
o|contracted procedure: k8580 
o|contracted procedure: k8564 
o|contracted procedure: k8568 
o|contracted procedure: k8576 
o|contracted procedure: k8586 
o|contracted procedure: k8614 
o|contracted procedure: k8618 
o|contracted procedure: k8598 
o|contracted procedure: k8602 
o|contracted procedure: k8610 
o|contracted procedure: k8624 
o|contracted procedure: k8631 
o|contracted procedure: k8635 
o|contracted procedure: k8644 
o|contracted procedure: k8677 
o|contracted procedure: k8656 
o|contracted procedure: k8673 
o|contracted procedure: k8664 
o|contracted procedure: k8756 
o|contracted procedure: k8687 
o|contracted procedure: k8719 
o|contracted procedure: k8699 
o|contracted procedure: k8707 
o|contracted procedure: k8727 
o|contracted procedure: k8752 
o|contracted procedure: k8736 
o|contracted procedure: k8740 
o|contracted procedure: k8770 
o|contracted procedure: k8773 
o|contracted procedure: k8791 
o|contracted procedure: k8796 
o|contracted procedure: k8808 
o|contracted procedure: k8811 
o|contracted procedure: k8814 
o|contracted procedure: k8822 
o|contracted procedure: k8830 
o|contracted procedure: k8846 
o|contracted procedure: k8840 
o|contracted procedure: k8837 
o|contracted procedure: k8857 
o|contracted procedure: k8924 
o|contracted procedure: k8874 
o|contracted procedure: k8878 
o|contracted procedure: k8883 
o|contracted procedure: k8895 
o|contracted procedure: k8898 
o|contracted procedure: k8901 
o|contracted procedure: k8909 
o|contracted procedure: k8917 
o|contracted procedure: k8930 
o|contracted procedure: k8948 
o|contracted procedure: k8964 
o|contracted procedure: k8960 
o|contracted procedure: k8970 
o|contracted procedure: k8973 
o|contracted procedure: k9035 
o|contracted procedure: k8985 
o|contracted procedure: k8989 
o|contracted procedure: k8994 
o|contracted procedure: k9006 
o|contracted procedure: k9009 
o|contracted procedure: k9012 
o|contracted procedure: k9020 
o|contracted procedure: k9028 
o|contracted procedure: k9041 
o|contracted procedure: k9096 
o|contracted procedure: k9044 
o|contracted procedure: k9092 
o|contracted procedure: k9072 
o|contracted procedure: k9088 
o|contracted procedure: k9076 
o|contracted procedure: k9080 
o|contracted procedure: k9056 
o|contracted procedure: k9060 
o|contracted procedure: k9068 
o|contracted procedure: k5701 
o|contracted procedure: k9102 
o|contracted procedure: k9117 
o|contracted procedure: k9121 
o|contracted procedure: k9125 
o|contracted procedure: k9128 
o|contracted procedure: k9131 
o|contracted procedure: k9143 
o|contracted procedure: k9146 
o|contracted procedure: k9149 
o|contracted procedure: k9157 
o|contracted procedure: k9165 
o|contracted procedure: k9174 
o|contracted procedure: k9186 
o|contracted procedure: k9190 
o|contracted procedure: k9194 
o|contracted procedure: k9206 
o|contracted procedure: k9209 
o|contracted procedure: k9212 
o|contracted procedure: k9220 
o|contracted procedure: k9228 
o|contracted procedure: k9255 
o|contracted procedure: k9259 
o|contracted procedure: k9262 
o|contracted procedure: k9274 
o|contracted procedure: k9277 
o|contracted procedure: k9280 
o|contracted procedure: k9288 
o|contracted procedure: k9296 
o|contracted procedure: k9338 
o|contracted procedure: k9344 
o|contracted procedure: k9350 
o|contracted procedure: k9382 
o|contracted procedure: k9430 
o|contracted procedure: k9434 
o|contracted procedure: k9446 
o|contracted procedure: k9449 
o|contracted procedure: k9452 
o|contracted procedure: k9460 
o|contracted procedure: k9468 
o|contracted procedure: k9506 
o|contracted procedure: k9514 
o|contracted procedure: k9522 
o|contracted procedure: k9528 
o|contracted procedure: k9538 
o|contracted procedure: k9541 
o|contracted procedure: k9553 
o|contracted procedure: k9556 
o|contracted procedure: k9559 
o|contracted procedure: k9567 
o|contracted procedure: k9575 
o|contracted procedure: k9584 
o|contracted procedure: k9595 
o|contracted procedure: k9598 
o|contracted procedure: k9591 
o|contracted procedure: k9610 
o|contracted procedure: k9613 
o|contracted procedure: k9616 
o|contracted procedure: k9624 
o|contracted procedure: k9632 
o|contracted procedure: k9641 
o|contracted procedure: k9650 
o|contracted procedure: k9653 
o|contracted procedure: k9659 
o|inlining procedure: k9662 
o|contracted procedure: k9670 
o|inlining procedure: k9662 
o|contracted procedure: k9676 
o|inlining procedure: k9662 
o|contracted procedure: k9688 
o|contracted procedure: k9695 
o|contracted procedure: k9698 
o|contracted procedure: k9707 
o|contracted procedure: k9710 
o|contracted procedure: k9766 
o|contracted procedure: k9730 
o|contracted procedure: k9756 
o|contracted procedure: k9760 
o|contracted procedure: k9752 
o|contracted procedure: k9733 
o|contracted procedure: k9736 
o|contracted procedure: k9744 
o|contracted procedure: k9748 
o|contracted procedure: k9778 
o|contracted procedure: k9781 
o|contracted procedure: k9784 
o|contracted procedure: k9792 
o|contracted procedure: k9800 
o|contracted procedure: k9809 
o|contracted procedure: k9831 
o|contracted procedure: k9816 
o|contracted procedure: k9820 
o|contracted procedure: k9828 
o|contracted procedure: k9837 
o|contracted procedure: k9844 
o|contracted procedure: k9852 
o|contracted procedure: k9858 
o|contracted procedure: k9865 
o|contracted procedure: k9871 
o|contracted procedure: k9878 
o|contracted procedure: k9890 
o|contracted procedure: k9894 
o|contracted procedure: k9903 
o|contracted procedure: k9909 
o|contracted procedure: k9916 
o|contracted procedure: k9924 
o|contracted procedure: k9943 
o|contracted procedure: k9931 
o|contracted procedure: k9951 
o|contracted procedure: k9955 
o|contracted procedure: k9961 
o|contracted procedure: k9964 
o|contracted procedure: k9967 
o|contracted procedure: k9979 
o|contracted procedure: k9982 
o|contracted procedure: k9985 
o|contracted procedure: k9993 
o|contracted procedure: k10001 
o|contracted procedure: k10010 
o|contracted procedure: k10017 
o|contracted procedure: k10021 
o|contracted procedure: k10024 
o|contracted procedure: k10036 
o|contracted procedure: k10039 
o|contracted procedure: k10042 
o|contracted procedure: k10050 
o|contracted procedure: k10058 
o|contracted procedure: k10067 
o|contracted procedure: k10076 
o|contracted procedure: k10083 
o|contracted procedure: k10105 
o|contracted procedure: k10112 
o|contracted procedure: k10116 
o|contracted procedure: k10120 
o|contracted procedure: k10132 
o|contracted procedure: k10146 
o|contracted procedure: k10150 
o|contracted procedure: k10162 
o|contracted procedure: k10165 
o|contracted procedure: k10168 
o|contracted procedure: k10176 
o|contracted procedure: k10184 
o|contracted procedure: k10191 
o|contracted procedure: k10197 
o|contracted procedure: k10204 
o|contracted procedure: k10207 
o|contracted procedure: k10219 
o|contracted procedure: k10222 
o|contracted procedure: k10225 
o|contracted procedure: k10233 
o|contracted procedure: k10241 
o|contracted procedure: k10255 
o|contracted procedure: k10258 
o|contracted procedure: k10270 
o|contracted procedure: k10273 
o|contracted procedure: k10276 
o|contracted procedure: k10284 
o|contracted procedure: k10292 
o|contracted procedure: k10300 
o|contracted procedure: k10306 
o|contracted procedure: k10347 
o|contracted procedure: k10411 
o|contracted procedure: k10374 
o|contracted procedure: k10389 
o|contracted procedure: k10403 
o|contracted procedure: k10407 
o|contracted procedure: k5312 
o|contracted procedure: k5326 
o|contracted procedure: k5336 
o|contracted procedure: k5330 
o|contracted procedure: k10454 
o|contracted procedure: k10469 
o|contracted procedure: k10473 
o|contracted procedure: k10480 
o|contracted procedure: k10501 
o|contracted procedure: k10495 
o|contracted procedure: k10537 
o|contracted procedure: k10517 
o|contracted procedure: k10525 
o|contracted procedure: k10521 
o|contracted procedure: k10589 
o|contracted procedure: k10592 
o|contracted procedure: k10595 
o|contracted procedure: k10615 
o|contracted procedure: k10623 
o|contracted procedure: k10631 
o|contracted procedure: k10637 
o|contracted procedure: k10651 
o|contracted procedure: k10654 
o|contracted procedure: k10676 
o|contracted procedure: k10688 
o|contracted procedure: k10692 
o|contracted procedure: k10700 
o|contracted procedure: k10708 
o|contracted procedure: k10714 
o|contracted procedure: k10717 
o|contracted procedure: k10741 
o|contracted procedure: k10745 
o|contracted procedure: k10753 
o|contracted procedure: k574618687 
o|contracted procedure: k10757 
o|contracted procedure: k10763 
o|contracted procedure: k10770 
o|contracted procedure: k10776 
o|contracted procedure: k10787 
o|contracted procedure: k10862 
o|contracted procedure: k10870 
o|contracted procedure: k10805 
o|contracted procedure: k10809 
o|contracted procedure: k10817 
o|contracted procedure: k10829 
o|contracted procedure: k10832 
o|contracted procedure: k10835 
o|contracted procedure: k10843 
o|contracted procedure: k10851 
o|contracted procedure: k10881 
o|contracted procedure: k10884 
o|contracted procedure: k10932 
o|contracted procedure: k10896 
o|contracted procedure: k10922 
o|contracted procedure: k10926 
o|contracted procedure: k10918 
o|contracted procedure: k10899 
o|contracted procedure: k10902 
o|contracted procedure: k10910 
o|contracted procedure: k10914 
o|contracted procedure: k10944 
o|contracted procedure: k10947 
o|contracted procedure: k10950 
o|contracted procedure: k10958 
o|contracted procedure: k10966 
o|contracted procedure: k10985 
o|contracted procedure: k10993 
o|contracted procedure: k11005 
o|contracted procedure: k11008 
o|contracted procedure: k11011 
o|contracted procedure: k11019 
o|contracted procedure: k11027 
o|contracted procedure: k11088 
o|contracted procedure: k11052 
o|contracted procedure: k11078 
o|contracted procedure: k11082 
o|contracted procedure: k11074 
o|contracted procedure: k11055 
o|contracted procedure: k11058 
o|contracted procedure: k11066 
o|contracted procedure: k11070 
o|contracted procedure: k10543 
o|contracted procedure: k10546 
o|contracted procedure: k10558 
o|contracted procedure: k10561 
o|contracted procedure: k10564 
o|contracted procedure: k10572 
o|contracted procedure: k10580 
o|contracted procedure: k11106 
o|contracted procedure: k11141 
o|contracted procedure: k11150 
o|contracted procedure: k11159 
o|contracted procedure: k11180 
o|contracted procedure: k11189 
o|contracted procedure: k11198 
o|contracted procedure: k11381 
o|contracted procedure: k11393 
o|contracted procedure: k11403 
o|contracted procedure: k11407 
o|contracted procedure: k11410 
o|contracted procedure: k11416 
o|contracted procedure: k11454 
o|contracted procedure: k11464 
o|contracted procedure: k11468 
o|contracted procedure: k11484 
o|contracted procedure: k11608 
o|contracted procedure: k11490 
o|contracted procedure: k11496 
o|contracted procedure: k11499 
o|contracted procedure: k11508 
o|contracted procedure: k11588 
o|contracted procedure: k11519 
o|contracted procedure: k11525 
o|contracted procedure: k11546 
o|contracted procedure: k11554 
o|contracted procedure: k11550 
o|contracted procedure: k11219 
o|contracted procedure: k11232 
o|contracted procedure: k11236 
o|contracted procedure: k11244 
o|contracted procedure: k11247 
o|contracted procedure: k11223 
o|contracted procedure: k11259 
o|contracted procedure: k11262 
o|contracted procedure: k11265 
o|contracted procedure: k11273 
o|contracted procedure: k11281 
o|contracted procedure: k11563 
o|contracted procedure: k11569 
o|contracted procedure: k11576 
o|contracted procedure: k11599 
o|contracted procedure: k11595 
o|contracted procedure: k11641 
o|contracted procedure: k11665 
o|contracted procedure: k11652 
o|contracted procedure: k11646 
o|contracted procedure: k11673 
o|contracted procedure: k11305 
o|contracted procedure: k11309 
o|contracted procedure: k11313 
o|contracted procedure: k11318 
o|contracted procedure: k11330 
o|contracted procedure: k11333 
o|contracted procedure: k11336 
o|contracted procedure: k11344 
o|contracted procedure: k11352 
o|contracted procedure: k11682 
o|contracted procedure: k11694 
o|contracted procedure: k11703 
o|contracted procedure: k574618729 
o|contracted procedure: k11757 
o|contracted procedure: k11719 
o|contracted procedure: k11753 
o|contracted procedure: k11728 
o|contracted procedure: k11745 
o|contracted procedure: k11749 
o|contracted procedure: k11879 
o|contracted procedure: k11766 
o|contracted procedure: k11871 
o|contracted procedure: k11875 
o|contracted procedure: k11775 
o|contracted procedure: k11793 
o|contracted procedure: k11797 
o|contracted procedure: k11806 
o|contracted procedure: k11849 
o|contracted procedure: k11815 
o|contracted procedure: k11824 
o|contracted procedure: k11841 
o|contracted procedure: k11845 
o|contracted procedure: k11858 
o|contracted procedure: k11862 
o|contracted procedure: k11897 
o|contracted procedure: k11906 
o|contracted procedure: k11923 
o|contracted procedure: k11931 
o|contracted procedure: k11937 
o|contracted procedure: k11946 
o|contracted procedure: k11971 
o|contracted procedure: k11949 
o|contracted procedure: k6276 
o|contracted procedure: k6292 
o|contracted procedure: k11977 
o|contracted procedure: k11980 
o|contracted procedure: k11995 
o|contracted procedure: k12001 
o|contracted procedure: k12026 
o|contracted procedure: k12029 
o|contracted procedure: k12138 
o|contracted procedure: k12032 
o|contracted procedure: k12041 
o|contracted procedure: k12055 
o|contracted procedure: k12061 
o|contracted procedure: k12069 
o|contracted procedure: k12072 
o|contracted procedure: k12113 
o|contracted procedure: k12078 
o|contracted procedure: k12104 
o|contracted procedure: k12095 
o|contracted procedure: k12084 
o|contracted procedure: k12091 
o|contracted procedure: k12119 
o|contracted procedure: k12131 
o|contracted procedure: k12165 
o|contracted procedure: k12171 
o|contracted procedure: k12178 
o|contracted procedure: k12206 
o|contracted procedure: k12212 
o|contracted procedure: k12261 
o|contracted procedure: k12234 
o|contracted procedure: k12237 
o|contracted procedure: k12258 
o|contracted procedure: k12251 
o|inlining procedure: k12247 
o|inlining procedure: k12247 
o|contracted procedure: k12288 
o|contracted procedure: k12314 
o|contracted procedure: k12323 
o|contracted procedure: k12332 
o|contracted procedure: k12341 
o|contracted procedure: k12350 
o|contracted procedure: k12360 
o|contracted procedure: k12371 
o|contracted procedure: k12365 
o|contracted procedure: k12446 
o|contracted procedure: k12401 
o|contracted procedure: k12440 
o|contracted procedure: k12404 
o|contracted procedure: k12434 
o|contracted procedure: k12407 
o|contracted procedure: k12428 
o|contracted procedure: k12410 
o|contracted procedure: k12421 
o|contracted procedure: k12417 
o|contracted procedure: k12476 
o|contracted procedure: k12479 
o|contracted procedure: k12491 
o|contracted procedure: k12506 
o|contracted procedure: k12521 
o|contracted procedure: k12524 
o|contracted procedure: k12553 
o|contracted procedure: k12534 
o|contracted procedure: k12542 
o|contracted procedure: k12546 
o|contracted procedure: k12538 
o|contracted procedure: k12559 
o|contracted procedure: k12562 
o|contracted procedure: k12574 
o|contracted procedure: k12607 
o|contracted procedure: k12584 
o|contracted procedure: k12596 
o|contracted procedure: k12588 
o|contracted procedure: k12603 
o|contracted procedure: k12613 
o|contracted procedure: k12623 
o|contracted procedure: k12629 
o|contracted procedure: k12665 
o|contracted procedure: k12642 
o|contracted procedure: k12654 
o|contracted procedure: k12646 
o|contracted procedure: k12661 
o|contracted procedure: k12671 
o|contracted procedure: k12688 
o|contracted procedure: k12684 
o|contracted procedure: k12697 
o|contracted procedure: k12703 
o|contracted procedure: k12731 
o|contracted procedure: k12740 
o|contracted procedure: k12778 
o|contracted procedure: k12746 
o|contracted procedure: k12774 
o|contracted procedure: k12784 
o|contracted procedure: k12813 
o|contracted procedure: k12797 
o|contracted procedure: k12805 
o|contracted procedure: k12809 
o|contracted procedure: k12801 
o|contracted procedure: k12819 
o|contracted procedure: k12828 
o|contracted procedure: k12867 
o|contracted procedure: k12841 
o|contracted procedure: k12853 
o|contracted procedure: k12845 
o|contracted procedure: k12863 
o|contracted procedure: k12873 
o|contracted procedure: k12889 
o|contracted procedure: k12895 
o|contracted procedure: k12905 
o|contracted procedure: k12916 
o|contracted procedure: k12912 
o|contracted procedure: k12931 
o|contracted procedure: k12940 
o|contracted procedure: k12947 
o|contracted procedure: k12976 
o|contracted procedure: k12960 
o|contracted procedure: k12968 
o|contracted procedure: k12972 
o|contracted procedure: k12964 
o|contracted procedure: k12982 
o|contracted procedure: k12985 
o|contracted procedure: k13015 
o|contracted procedure: k12995 
o|contracted procedure: k13011 
o|contracted procedure: k13003 
o|contracted procedure: k13007 
o|contracted procedure: k12999 
o|contracted procedure: k13021 
o|contracted procedure: k13050 
o|contracted procedure: k13031 
o|contracted procedure: k13039 
o|contracted procedure: k13043 
o|contracted procedure: k13035 
o|contracted procedure: k13056 
o|contracted procedure: k13068 
o|contracted procedure: k13075 
o|contracted procedure: k13081 
o|contracted procedure: k13088 
o|contracted procedure: k13094 
o|contracted procedure: k13104 
o|contracted procedure: k13110 
o|contracted procedure: k13113 
o|contracted procedure: k13143 
o|contracted procedure: k13149 
o|contracted procedure: k13166 
o|contracted procedure: k13174 
o|contracted procedure: k13189 
o|contracted procedure: k13195 
o|contracted procedure: k13214 
o|contracted procedure: k13229 
o|contracted procedure: k13235 
o|contracted procedure: k13241 
o|contracted procedure: k13247 
o|contracted procedure: k13268 
o|contracted procedure: k13274 
o|contracted procedure: k13280 
o|contracted procedure: k13286 
o|contracted procedure: k13307 
o|contracted procedure: k13313 
o|contracted procedure: k13319 
o|contracted procedure: k13325 
o|contracted procedure: k13331 
o|contracted procedure: k13337 
o|contracted procedure: k13343 
o|contracted procedure: k13349 
o|contracted procedure: k13378 
o|contracted procedure: k13384 
o|contracted procedure: k13390 
o|contracted procedure: k13396 
o|contracted procedure: k13402 
o|contracted procedure: k13408 
o|contracted procedure: k13414 
o|contracted procedure: k13420 
o|contracted procedure: k13467 
o|contracted procedure: k13482 
o|contracted procedure: k13488 
o|contracted procedure: k13494 
o|contracted procedure: k13500 
o|contracted procedure: k13537 
o|contracted procedure: k13552 
o|contracted procedure: k13540 
o|contracted procedure: k13564 
o|contracted procedure: k13579 
o|contracted procedure: k13567 
o|contracted procedure: k13609 
o|contracted procedure: k13615 
o|contracted procedure: k13645 
o|contracted procedure: k13654 
o|contracted procedure: k13666 
o|contracted procedure: k13678 
o|contracted procedure: k13690 
o|contracted procedure: k13711 
o|contracted procedure: k13720 
o|contracted procedure: k13727 
o|contracted procedure: k13739 
o|contracted procedure: k13746 
o|contracted procedure: k13752 
o|contracted procedure: k13765 
o|contracted procedure: k13771 
o|contracted procedure: k13777 
o|contracted procedure: k13783 
o|contracted procedure: k13789 
o|contracted procedure: k13795 
o|contracted procedure: k13801 
o|contracted procedure: k13831 
o|contracted procedure: k13837 
o|contracted procedure: k13843 
o|contracted procedure: k13860 
o|contracted procedure: k13875 
o|contracted procedure: k13881 
o|contracted procedure: k13887 
o|contracted procedure: k13893 
o|contracted procedure: k13914 
o|contracted procedure: k13920 
o|contracted procedure: k13926 
o|contracted procedure: k13932 
o|contracted procedure: k13938 
o|contracted procedure: k13944 
o|contracted procedure: k13950 
o|contracted procedure: k13956 
o|contracted procedure: k13962 
o|contracted procedure: k13968 
o|contracted procedure: k14001 
o|contracted procedure: k14007 
o|contracted procedure: k14013 
o|contracted procedure: k14019 
o|contracted procedure: k14025 
o|contracted procedure: k14031 
o|contracted procedure: k14037 
o|contracted procedure: k14043 
o|contracted procedure: k14049 
o|contracted procedure: k14055 
o|contracted procedure: k14061 
o|contracted procedure: k14120 
o|contracted procedure: k14132 
o|contracted procedure: k14153 
o|contracted procedure: k14162 
o|contracted procedure: k14169 
o|contracted procedure: k14181 
o|contracted procedure: k14188 
o|contracted procedure: k14196 
o|contracted procedure: k14202 
o|contracted procedure: k14208 
o|contracted procedure: k14214 
o|contracted procedure: k14220 
o|contracted procedure: k14226 
o|contracted procedure: k14232 
o|contracted procedure: k14262 
o|contracted procedure: k14268 
o|contracted procedure: k14274 
o|contracted procedure: k14280 
o|contracted procedure: k14299 
o|contracted procedure: k14305 
o|contracted procedure: k14311 
o|contracted procedure: k14317 
o|contracted procedure: k14323 
o|contracted procedure: k14329 
o|contracted procedure: k14335 
o|contracted procedure: k14341 
o|contracted procedure: k14347 
o|contracted procedure: k14353 
o|contracted procedure: k14359 
o|contracted procedure: k14365 
o|contracted procedure: k14371 
o|contracted procedure: k14377 
o|contracted procedure: k14383 
o|contracted procedure: k14389 
o|contracted procedure: k14395 
o|contracted procedure: k14401 
o|contracted procedure: k14407 
o|contracted procedure: k14413 
o|contracted procedure: k14419 
o|contracted procedure: k14425 
o|contracted procedure: k14431 
o|contracted procedure: k14437 
o|contracted procedure: k14443 
o|contracted procedure: k14449 
o|contracted procedure: k14455 
o|contracted procedure: k14461 
o|contracted procedure: k14467 
o|contracted procedure: k14473 
o|contracted procedure: k14561 
o|contracted procedure: k14564 
o|contracted procedure: k14571 
o|contracted procedure: k14577 
o|contracted procedure: k14584 
o|contracted procedure: k14590 
o|contracted procedure: k14593 
o|contracted procedure: k14600 
o|contracted procedure: k14606 
o|contracted procedure: k14609 
o|contracted procedure: k14616 
o|contracted procedure: k14622 
o|contracted procedure: k14633 
o|contracted procedure: k14629 
o|contracted procedure: k14639 
o|contracted procedure: k14646 
o|contracted procedure: k14652 
o|contracted procedure: k14659 
o|contracted procedure: k14665 
o|contracted procedure: k14678 
o|contracted procedure: k14765 
o|contracted procedure: k14684 
o|contracted procedure: k14687 
o|contracted procedure: k14693 
o|contracted procedure: k14696 
o|contracted procedure: k14734 
o|contracted procedure: k14706 
o|contracted procedure: k14730 
o|contracted procedure: k14714 
o|contracted procedure: k14722 
o|contracted procedure: k14726 
o|contracted procedure: k14718 
o|contracted procedure: k14710 
o|contracted procedure: k14740 
o|contracted procedure: k14747 
o|contracted procedure: k14751 
o|contracted procedure: k14788 
o|contracted procedure: k14768 
o|contracted procedure: k14784 
o|contracted procedure: k14774 
o|contracted procedure: k14778 
o|contracted procedure: k14829 
o|contracted procedure: k14835 
o|contracted procedure: k14838 
o|contracted procedure: k14844 
o|contracted procedure: k14853 
o|contracted procedure: k14856 
o|contracted procedure: k14862 
o|contracted procedure: k14870 
o|contracted procedure: k14873 
o|contracted procedure: k14879 
o|contracted procedure: k14885 
o|contracted procedure: k14893 
o|contracted procedure: k14899 
o|contracted procedure: k14905 
o|contracted procedure: k14913 
o|contracted procedure: k14919 
o|contracted procedure: k14928 
o|contracted procedure: k14935 
o|contracted procedure: k14946 
o|contracted procedure: k14952 
o|contracted procedure: k14958 
o|contracted procedure: k14964 
o|contracted procedure: k14970 
o|contracted procedure: k14976 
o|contracted procedure: k14982 
o|contracted procedure: k14988 
o|contracted procedure: k14994 
o|contracted procedure: k15000 
o|contracted procedure: k15006 
o|contracted procedure: k15015 
o|contracted procedure: k15021 
o|contracted procedure: k15027 
o|contracted procedure: k15036 
o|contracted procedure: k15039 
o|contracted procedure: k15045 
o|contracted procedure: k15054 
o|contracted procedure: k15060 
o|contracted procedure: k15067 
o|contracted procedure: k15076 
o|contracted procedure: k15083 
o|contracted procedure: k15089 
o|contracted procedure: k15095 
o|contracted procedure: k15098 
o|contracted procedure: k15112 
o|contracted procedure: k15118 
o|contracted procedure: k15137 
o|contracted procedure: k15159 
o|contracted procedure: k15165 
o|contracted procedure: k15186 
o|contracted procedure: k15192 
o|contracted procedure: k15198 
o|contracted procedure: k15204 
o|contracted procedure: k15210 
o|contracted procedure: k15216 
o|contracted procedure: k15222 
o|contracted procedure: k15269 
o|contracted procedure: k15275 
o|contracted procedure: k15281 
o|contracted procedure: k15287 
o|contracted procedure: k15293 
o|contracted procedure: k15299 
o|contracted procedure: k15305 
o|contracted procedure: k15311 
o|contracted procedure: k15362 
o|contracted procedure: k15368 
o|contracted procedure: k15374 
o|contracted procedure: k15380 
o|contracted procedure: k15386 
o|contracted procedure: k15392 
o|contracted procedure: k15440 
o|contracted procedure: k15448 
o|contracted procedure: k15454 
o|contracted procedure: k15457 
o|contracted procedure: k15518 
o|contracted procedure: k15460 
o|contracted procedure: k15466 
o|contracted procedure: k15478 
o|contracted procedure: k15488 
o|contracted procedure: k15492 
o|contracted procedure: k15499 
o|contracted procedure: k15502 
o|contracted procedure: k15509 
o|contracted procedure: k15524 
o|contracted procedure: k15530 
o|contracted procedure: k15542 
o|contracted procedure: k15552 
o|contracted procedure: k15556 
o|contracted procedure: k15559 
o|contracted procedure: k15592 
o|contracted procedure: k15600 
o|contracted procedure: k15608 
o|contracted procedure: k15614 
o|contracted procedure: k15623 
o|contracted procedure: k15626 
o|contracted procedure: k15632 
o|contracted procedure: k15652 
o|contracted procedure: k15655 
o|contracted procedure: k15668 
o|contracted procedure: k1566518771 
o|contracted procedure: k1566518775 
o|contracted procedure: k15678 
o|contracted procedure: k15688 
o|contracted procedure: k15696 
o|contracted procedure: k15702 
o|contracted procedure: k15709 
o|contracted procedure: k15719 
o|contracted procedure: k15737 
o|contracted procedure: k15743 
o|contracted procedure: k15749 
o|contracted procedure: k15776 
o|contracted procedure: k15788 
o|contracted procedure: k15798 
o|contracted procedure: k15802 
o|contracted procedure: k15815 
o|contracted procedure: k15830 
o|contracted procedure: k15850 
o|contracted procedure: k15893 
o|inlining procedure: k15890 
o|contracted procedure: k15947 
o|contracted procedure: k15956 
o|contracted procedure: k15964 
o|contracted procedure: k15977 
o|contracted procedure: k15988 
o|contracted procedure: k16000 
o|contracted procedure: k16014 
o|contracted procedure: k16018 
o|contracted procedure: k16085 
o|contracted procedure: k16088 
o|contracted procedure: k16091 
o|contracted procedure: k16108 
o|contracted procedure: k16120 
o|contracted procedure: k16135 
o|contracted procedure: k16156 
o|contracted procedure: k16159 
o|contracted procedure: k16162 
o|contracted procedure: k16175 
o|contracted procedure: k16168 
o|contracted procedure: k16181 
o|contracted procedure: k16198 
o|contracted procedure: k16326 
o|contracted procedure: k16334 
o|contracted procedure: k16204 
o|contracted procedure: k16207 
o|contracted procedure: k16213 
o|contracted procedure: k16244 
o|contracted procedure: k16250 
o|contracted procedure: k16274 
o|contracted procedure: k16262 
o|contracted procedure: k16269 
o|contracted procedure: k16346 
o|contracted procedure: k16368 
o|contracted procedure: k16364 
o|contracted procedure: k16349 
o|contracted procedure: k16352 
o|contracted procedure: k16360 
o|contracted procedure: k16380 
o|contracted procedure: k16383 
o|contracted procedure: k16386 
o|contracted procedure: k16394 
o|contracted procedure: k16402 
o|contracted procedure: k16195 
o|contracted procedure: k16423 
o|contracted procedure: k16504 
o|contracted procedure: k16500 
o|contracted procedure: k16429 
o|contracted procedure: k16486 
o|contracted procedure: k16432 
o|contracted procedure: k16544 
o|contracted procedure: k16590 
o|contracted procedure: k16599 
o|contracted procedure: k16602 
o|contracted procedure: k16609 
o|contracted procedure: k16628 
o|contracted procedure: k6163 
o|contracted procedure: k6178 
o|contracted procedure: k16661 
o|contracted procedure: k16669 
o|contracted procedure: k16677 
o|contracted procedure: k16711 
o|contracted procedure: k16717 
o|contracted procedure: k16726 
o|contracted procedure: k16750 
o|contracted procedure: k16766 
o|contracted procedure: k16770 
o|contracted procedure: k16774 
o|contracted procedure: k16783 
o|contracted procedure: k16793 
o|contracted procedure: k16797 
o|contracted procedure: k16813 
o|contracted procedure: k574618817 
o|contracted procedure: k574618824 
o|contracted procedure: k16833 
o|contracted procedure: k16840 
o|contracted procedure: k16855 
o|contracted procedure: k16868 
o|contracted procedure: k16892 
o|contracted procedure: k16920 
o|contracted procedure: k16949 
o|contracted procedure: k16958 
o|contracted procedure: k16973 
o|contracted procedure: k16979 
o|contracted procedure: k17002 
o|contracted procedure: k16996 
o|contracted procedure: k17022 
o|contracted procedure: k17016 
o|contracted procedure: k17062 
o|contracted procedure: k17068 
o|contracted procedure: k17087 
o|contracted procedure: k17081 
o|contracted procedure: k17172 
o|contracted procedure: k17184 
o|contracted procedure: k17194 
o|contracted procedure: k17198 
o|contracted procedure: k17146 
o|contracted procedure: k17160 
o|contracted procedure: k17164 
o|contracted procedure: k17246 
o|contracted procedure: k17230 
o|contracted procedure: k17297 
o|contracted procedure: k17306 
o|simplifications: ((let . 147)) 
o|removed binding forms: 1175 
o|inlining procedure: k10477 
o|replaced variables: 418 
o|removed binding forms: 3 
o|inlining procedure: k7986 
o|inlining procedure: k8037 
o|inlining procedure: k11707 
o|inlining procedure: k16817 
o|inlining procedure: k16817 
o|simplifications: ((if . 17)) 
o|replaced variables: 7 
o|removed binding forms: 274 
o|contracted procedure: k7788 
o|contracted procedure: k7899 
o|contracted procedure: k9084 
o|contracted procedure: k10726 
o|contracted procedure: k16398 
o|removed binding forms: 10 
o|replaced variables: 13 
o|removed binding forms: 6 
o|direct leaf routine/allocation: loop444 0 
o|direct leaf routine/allocation: loop1091 0 
o|direct leaf routine/allocation: g404405 3 
o|direct leaf routine/allocation: g25922593 0 
o|converted assignments to bindings: (loop444) 
o|converted assignments to bindings: (loop1091) 
o|simplifications: ((let . 2)) 
o|customizable procedures: (for-each-loop43264341 loop4190 k16806 g41144128 for-each-loop41134138 doloop41504151 loop4091 loop539 tmp15102 tmp25103 map-loop39523973 map-loop39834004 k16144 resolve3885 loop3897 k15821 g38193826 for-each-loop38183829 k15617 walkeach3774 walk3773 chicken.compiler.support#lset-adjoin/eq? k15527 for-each-loop37513761 k15495 k15463 for-each-loop37263737 k14847 k14922 k15009 k15030 k15048 k15070 k14671 k14123 k14135 k14172 g34453446 k13648 k13657 k13669 k13681 k13693 k13730 err3171 g32873288 g31663167 chicken.compiler.support#follow-without-loop k12494 k12509 k12632 k12674 k12700 k12743 k12787 k12831 k12876 k12950 repeat2827 g30793080 k12849 k12650 k12592 k12197 k12156 k11940 loop567 matchn2583 loop2612 match12582 resolve2581 map-loop24292446 loop2558 k11502 k11539 map-loop23902410 for-each-loop25092521 for-each-loop25312549 rec2341 map-loop20652082 map-loop21182137 g23112320 map-loop23052330 g22052214 map-loop21992219 map-loop22292248 g22722281 map-loop22662291 walk2148 loop2090 loop211 fold2042 k9531 k10135 map-loop20142031 map-loop19882005 map-loop19621979 loop1943 map-loop19191936 chicken.compiler.support#cons* map-loop18931910 loop1884 map-loop18441861 map-loop18231868 chicken.compiler.support#last map-loop17811798 map-loop17521769 map-loop16951712 k8860 k9105 k9303 map-loop16641681 map-loop16181635 map-loop15871604 map-loop15381555 map-loop14941511 k8787 map-loop14571474 loop1424 map-loop417435 g13921401 map-loop13861404 k8418 map-loop13491366 map-loop12191236 k8087 g12071208 foldr389392 g394395 map-loop11241145 tmp14742 tmp24743 loop1074 k7556 loop1045 k7428 doloop961962 loop941 fold934 k7150 chicken.compiler.support#every k7002 k7009 loop877 loop861 loop845 err844 loop833 k6710 g781806 for-each-loop780816 collect732 g737744 for-each-loop736755 text681 chicken.compiler.support#test-debugging-mode dump682 for-each-loop685702 chicken.compiler.support#any loop461 loop321 loop308 loop295 chicken.compiler.support#take) 
o|calls to known targets: 505 
o|identified direct recursive calls: f_5249 1 
o|identified direct recursive calls: f_5580 1 
o|identified direct recursive calls: f_5916 1 
o|identified direct recursive calls: f_5975 2 
o|identified direct recursive calls: f_6883 1 
o|identified direct recursive calls: f_6933 1 
o|identified direct recursive calls: f_7199 1 
o|identified direct recursive calls: f_7734 1 
o|identified direct recursive calls: f_7876 1 
o|identified direct recursive calls: f_5803 1 
o|identified direct recursive calls: f_8157 1 
o|identified direct recursive calls: f_5876 1 
o|identified direct recursive calls: f_8300 4 
o|identified direct recursive calls: f_9725 1 
o|identified direct recursive calls: f_5307 1 
o|identified direct recursive calls: f_10449 1 
o|identified direct recursive calls: f_10891 1 
o|identified direct recursive calls: f_10608 1 
o|identified direct recursive calls: f_11047 1 
o|identified direct recursive calls: f_11101 1 
o|identified direct recursive calls: f_11714 1 
o|identified direct recursive calls: f_16341 1 
o|identified direct recursive calls: f_16375 1 
o|fast box initializations: 88 
o|fast global references: 56 
o|fast global assignments: 20 
o|dropping unused closure argument: f_15927 
o|dropping unused closure argument: f_5249 
o|dropping unused closure argument: f_5510 
o|dropping unused closure argument: f_5544 
o|dropping unused closure argument: f_5574 
o|dropping unused closure argument: f_5910 
o|dropping unused closure argument: f_5916 
o|dropping unused closure argument: f_5969 
o|dropping unused closure argument: f_6454 
o|dropping unused closure argument: f_7239 
o|dropping unused closure argument: f_7734 
*/
/* end of file */
