/* Generated from c-platform.scm by the CHICKEN compiler
   http://www.call-cc.org
   Version 5.1.0rc1 (prerelease) (rev 7358d2e5)
   linux-unix-gnu-x86-64 [ 64bit dload ptables ]
   command line: c-platform.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -consult-types-file ./types.db -no-lambda-info -no-trace -emit-import-library chicken.compiler.c-platform -output-file c-platform.c
   unit: c-platform
   uses: library eval expand internal optimizer support compiler
*/
#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_internal_toplevel)
C_externimport void C_ccall C_internal_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[944];
static double C_possibly_force_alignment;


C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word *av) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word *av) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word *av) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word *av) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word *av) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word *av) C_noret;
C_noret_decl(f_1682)
static void C_ccall f_1682(C_word c,C_word *av) C_noret;
C_noret_decl(f_2117)
static void C_fcall f_2117(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2123)
static void C_fcall f_2123(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word *av) C_noret;
C_noret_decl(f_2293)
static void C_fcall f_2293(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2302)
static void C_fcall f_2302(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2310)
static void C_fcall f_2310(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word *av) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word *av) C_noret;
C_noret_decl(f_2459)
static C_word C_fcall f_2459(C_word t0);
C_noret_decl(f_2701)
static void C_fcall f_2701(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word *av) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word *av) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word *av) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word *av) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word *av) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word *av) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word *av) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word *av) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word *av) C_noret;
C_noret_decl(f_3009)
static void C_fcall f_3009(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word *av) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word *av) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word *av) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word *av) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word *av) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word *av) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word *av) C_noret;
C_noret_decl(f_3104)
static void C_fcall f_3104(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_fcall f_3107(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word *av) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word *av) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word *av) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word *av) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word *av) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word *av) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word *av) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word *av) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word *av) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word *av) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word *av) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word *av) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word *av) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word *av) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word *av) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word *av) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word *av) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word *av) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word *av) C_noret;
C_noret_decl(f_3296)
static void C_fcall f_3296(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word *av) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word *av) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word *av) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word *av) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word *av) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word *av) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word *av) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word *av) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word *av) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word *av) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word *av) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word *av) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word *av) C_noret;
C_noret_decl(f_3424)
static void C_fcall f_3424(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word *av) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word *av) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word *av) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word *av) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word *av) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word *av) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word *av) C_noret;
C_noret_decl(f_3504)
static void C_ccall f_3504(C_word c,C_word *av) C_noret;
C_noret_decl(f_3507)
static void C_ccall f_3507(C_word c,C_word *av) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word *av) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word *av) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word *av) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word *av) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word *av) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word *av) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word *av) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word *av) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word *av) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word *av) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word *av) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word *av) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word *av) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word *av) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word *av) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word *av) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word *av) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word *av) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word *av) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word *av) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word *av) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word *av) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word *av) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word *av) C_noret;
C_noret_decl(f_3716)
static void C_ccall f_3716(C_word c,C_word *av) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word *av) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word *av) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word *av) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word *av) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word *av) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word *av) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word *av) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word *av) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word *av) C_noret;
C_noret_decl(f_3746)
static void C_ccall f_3746(C_word c,C_word *av) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word *av) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word *av) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word *av) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word *av) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word *av) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word *av) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word *av) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word *av) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word *av) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776(C_word c,C_word *av) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word *av) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word *av) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word *av) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word *av) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word *av) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word *av) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word *av) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word *av) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word *av) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word *av) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word *av) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word *av) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word *av) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word *av) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word *av) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word *av) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word *av) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word *av) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word *av) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word *av) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word *av) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word *av) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word *av) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word *av) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word *av) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word *av) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word *av) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word *av) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word *av) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word *av) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word *av) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word *av) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word *av) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word *av) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word *av) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word *av) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word *av) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word *av) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word *av) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word *av) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word *av) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word *av) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word *av) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word *av) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word *av) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914(C_word c,C_word *av) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word *av) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word *av) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word *av) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word *av) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word *av) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word *av) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word *av) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word *av) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word *av) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word *av) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word *av) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word *av) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word *av) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word *av) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word *av) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word *av) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word *av) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word *av) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word *av) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word *av) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word *av) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word *av) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word *av) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word *av) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word *av) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word *av) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word *av) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word *av) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word *av) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word *av) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word *av) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word *av) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word *av) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word *av) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word *av) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word *av) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word *av) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word *av) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word *av) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word *av) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word *av) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word *av) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word *av) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word *av) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word *av) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word *av) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word *av) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word *av) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word *av) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word *av) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word *av) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word *av) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word *av) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word *av) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word *av) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word *av) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word *av) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word *av) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word *av) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word *av) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word *av) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word *av) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103(C_word c,C_word *av) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word *av) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word *av) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word *av) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word *av) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word *av) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word *av) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word *av) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word *av) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word *av) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word *av) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word *av) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word *av) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word *av) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word *av) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word *av) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word *av) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word *av) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word *av) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word *av) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word *av) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word *av) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word *av) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word *av) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word *av) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word *av) C_noret;
C_noret_decl(f_4181)
static void C_ccall f_4181(C_word c,C_word *av) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word *av) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word *av) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190(C_word c,C_word *av) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word *av) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word *av) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word *av) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word *av) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word *av) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word *av) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word *av) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word *av) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word *av) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word *av) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word *av) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word *av) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word *av) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word *av) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word *av) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word *av) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word *av) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word *av) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word *av) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word *av) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word *av) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word *av) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word *av) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word *av) C_noret;
C_noret_decl(f_4265)
static void C_ccall f_4265(C_word c,C_word *av) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word *av) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word *av) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word *av) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word *av) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word *av) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word *av) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word *av) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word *av) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word *av) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word *av) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word *av) C_noret;
C_noret_decl(f_4301)
static void C_ccall f_4301(C_word c,C_word *av) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word *av) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word *av) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word *av) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word *av) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word *av) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word *av) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word *av) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word *av) C_noret;
C_noret_decl(f_4328)
static void C_ccall f_4328(C_word c,C_word *av) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word *av) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word *av) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word *av) C_noret;
C_noret_decl(f_4340)
static void C_ccall f_4340(C_word c,C_word *av) C_noret;
C_noret_decl(f_4343)
static void C_ccall f_4343(C_word c,C_word *av) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word *av) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word *av) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word *av) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word *av) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word *av) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word *av) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word *av) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word *av) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word *av) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word *av) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word *av) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word *av) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word *av) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word *av) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word *av) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word *av) C_noret;
C_noret_decl(f_4394)
static void C_ccall f_4394(C_word c,C_word *av) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word *av) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word *av) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word *av) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word *av) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word *av) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word *av) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word *av) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word *av) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word *av) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word *av) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word *av) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word *av) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word *av) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word *av) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word *av) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word *av) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word *av) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word *av) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word *av) C_noret;
C_noret_decl(f_4490)
static void C_fcall f_4490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501(C_word c,C_word *av) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word *av) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word *av) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word *av) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word *av) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word *av) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word *av) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word *av) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word *av) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word *av) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word *av) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word *av) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word *av) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word *av) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word *av) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word *av) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word *av) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word *av) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word *av) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word *av) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word *av) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word *av) C_noret;
C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word *av) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word *av) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word *av) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word *av) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word *av) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word *av) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word *av) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word *av) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word *av) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word *av) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word *av) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word *av) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word *av) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word *av) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word *av) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word *av) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word *av) C_noret;
C_noret_decl(f_4673)
static void C_ccall f_4673(C_word c,C_word *av) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word *av) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word *av) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word *av) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word *av) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word *av) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word *av) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word *av) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word *av) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word *av) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word *av) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word *av) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word *av) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word *av) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word *av) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word *av) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word *av) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word *av) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word *av) C_noret;
C_noret_decl(f_4730)
static void C_ccall f_4730(C_word c,C_word *av) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word *av) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word *av) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word *av) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word *av) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word *av) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word *av) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word *av) C_noret;
C_noret_decl(f_4754)
static void C_ccall f_4754(C_word c,C_word *av) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word *av) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word *av) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word *av) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word *av) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word *av) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word *av) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word *av) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word *av) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word *av) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word *av) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word *av) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word *av) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word *av) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word *av) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word *av) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word *av) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word *av) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word *av) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word *av) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word *av) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word *av) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word *av) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word *av) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word *av) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word *av) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832(C_word c,C_word *av) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word *av) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word *av) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word *av) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word *av) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word *av) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word *av) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word *av) C_noret;
C_noret_decl(f_4856)
static void C_ccall f_4856(C_word c,C_word *av) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word *av) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word *av) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word *av) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word *av) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word *av) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word *av) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word *av) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word *av) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word *av) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word *av) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word *av) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word *av) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word *av) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word *av) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word *av) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word *av) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word *av) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word *av) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word *av) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word *av) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word *av) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word *av) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word *av) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word *av) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word *av) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word *av) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word *av) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word *av) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word *av) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word *av) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word *av) C_noret;
C_noret_decl(f_4952)
static void C_ccall f_4952(C_word c,C_word *av) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word *av) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word *av) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word *av) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word *av) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word *av) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word *av) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word *av) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word *av) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word *av) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word *av) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word *av) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word *av) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word *av) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word *av) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word *av) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word *av) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word *av) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word *av) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word *av) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word *av) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word *av) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word *av) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word *av) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word *av) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word *av) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word *av) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word *av) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word *av) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word *av) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word *av) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word *av) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word *av) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word *av) C_noret;
C_noret_decl(f_5054)
static void C_ccall f_5054(C_word c,C_word *av) C_noret;
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word *av) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word *av) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word *av) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word *av) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word *av) C_noret;
C_noret_decl(f_5072)
static void C_ccall f_5072(C_word c,C_word *av) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word *av) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word *av) C_noret;
C_noret_decl(f_5081)
static void C_ccall f_5081(C_word c,C_word *av) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word *av) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word *av) C_noret;
C_noret_decl(f_5090)
static void C_ccall f_5090(C_word c,C_word *av) C_noret;
C_noret_decl(f_5093)
static void C_ccall f_5093(C_word c,C_word *av) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word *av) C_noret;
C_noret_decl(f_5099)
static void C_ccall f_5099(C_word c,C_word *av) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word *av) C_noret;
C_noret_decl(f_5105)
static void C_ccall f_5105(C_word c,C_word *av) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word *av) C_noret;
C_noret_decl(f_5111)
static void C_ccall f_5111(C_word c,C_word *av) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word *av) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117(C_word c,C_word *av) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word *av) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word *av) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word *av) C_noret;
C_noret_decl(f_5129)
static void C_ccall f_5129(C_word c,C_word *av) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word *av) C_noret;
C_noret_decl(f_5135)
static void C_ccall f_5135(C_word c,C_word *av) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word *av) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word *av) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word *av) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word *av) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149(C_word c,C_word *av) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word *av) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word *av) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word *av) C_noret;
C_noret_decl(f_5204)
static void C_ccall f_5204(C_word c,C_word *av) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word *av) C_noret;
C_noret_decl(f_5224)
static void C_ccall f_5224(C_word c,C_word *av) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word *av) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word *av) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word *av) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word *av) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word *av) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word *av) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word *av) C_noret;
C_noret_decl(f_5295)
static void C_ccall f_5295(C_word c,C_word *av) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word *av) C_noret;
C_noret_decl(f_5342)
static void C_ccall f_5342(C_word c,C_word *av) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word *av) C_noret;
C_noret_decl(f_5350)
static void C_ccall f_5350(C_word c,C_word *av) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word *av) C_noret;
C_noret_decl(f_5361)
static void C_ccall f_5361(C_word c,C_word *av) C_noret;
C_noret_decl(f_5369)
static void C_ccall f_5369(C_word c,C_word *av) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word *av) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word *av) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word *av) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word *av) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word *av) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word *av) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word *av) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word *av) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word *av) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word *av) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word *av) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word *av) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word *av) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word *av) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word *av) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word *av) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word *av) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word *av) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word *av) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word *av) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word *av) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word *av) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word *av) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word *av) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word *av) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word *av) C_noret;
C_noret_decl(f_5569)
static void C_ccall f_5569(C_word c,C_word *av) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word *av) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word *av) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word *av) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word *av) C_noret;
C_noret_decl(f_5642)
static void C_fcall f_5642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5664)
static void C_ccall f_5664(C_word c,C_word *av) C_noret;
C_noret_decl(f_5687)
static void C_ccall f_5687(C_word c,C_word *av) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word *av) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word *av) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word *av) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word *av) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word *av) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word *av) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word *av) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word *av) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word *av) C_noret;
C_noret_decl(f_5793)
static void C_fcall f_5793(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word *av) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word *av) C_noret;
C_noret_decl(f_5829)
static void C_ccall f_5829(C_word c,C_word *av) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word *av) C_noret;
C_noret_decl(f_5846)
static void C_fcall f_5846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word *av) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word *av) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word *av) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word *av) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word *av) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word *av) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word *av) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word *av) C_noret;
C_noret_decl(f_5970)
static void C_fcall f_5970(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word *av) C_noret;
C_noret_decl(f_6019)
static void C_ccall f_6019(C_word c,C_word *av) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word *av) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word *av) C_noret;
C_noret_decl(f_6046)
static void C_ccall f_6046(C_word c,C_word *av) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word *av) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word *av) C_noret;
C_noret_decl(f_6084)
static void C_ccall f_6084(C_word c,C_word *av) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088(C_word c,C_word *av) C_noret;
C_noret_decl(f_6109)
static void C_ccall f_6109(C_word c,C_word *av) C_noret;
C_noret_decl(f_6151)
static void C_ccall f_6151(C_word c,C_word *av) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word *av) C_noret;
C_noret_decl(f_6160)
static void C_fcall f_6160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word *av) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word *av) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word *av) C_noret;
C_noret_decl(f_6202)
static void C_ccall f_6202(C_word c,C_word *av) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word *av) C_noret;
C_noret_decl(f_6228)
static void C_ccall f_6228(C_word c,C_word *av) C_noret;
C_noret_decl(f_6230)
static void C_ccall f_6230(C_word c,C_word *av) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word *av) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word *av) C_noret;
C_noret_decl(f_6270)
static void C_ccall f_6270(C_word c,C_word *av) C_noret;
C_noret_decl(f_6273)
static void C_fcall f_6273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6276)
static void C_fcall f_6276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word *av) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word *av) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word *av) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word *av) C_noret;
C_noret_decl(f_6326)
static void C_ccall f_6326(C_word c,C_word *av) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word *av) C_noret;
C_noret_decl(f_6340)
static void C_ccall f_6340(C_word c,C_word *av) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word *av) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word *av) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word *av) C_noret;
C_noret_decl(f_6382)
static void C_ccall f_6382(C_word c,C_word *av) C_noret;
C_noret_decl(f_6386)
static void C_ccall f_6386(C_word c,C_word *av) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word *av) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word *av) C_noret;
C_noret_decl(f_6401)
static void C_fcall f_6401(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word *av) C_noret;
C_noret_decl(f_6424)
static void C_fcall f_6424(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word *av) C_noret;
C_noret_decl(C_c_2dplatform_toplevel)
C_externexport void C_ccall C_c_2dplatform_toplevel(C_word c,C_word *av) C_noret;

C_noret_decl(trf_2117)
static void C_ccall trf_2117(C_word c,C_word *av) C_noret;
static void C_ccall trf_2117(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2117(t0,t1,t2);}

C_noret_decl(trf_2123)
static void C_ccall trf_2123(C_word c,C_word *av) C_noret;
static void C_ccall trf_2123(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2123(t0,t1,t2,t3);}

C_noret_decl(trf_2293)
static void C_ccall trf_2293(C_word c,C_word *av) C_noret;
static void C_ccall trf_2293(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2293(t0,t1,t2);}

C_noret_decl(trf_2302)
static void C_ccall trf_2302(C_word c,C_word *av) C_noret;
static void C_ccall trf_2302(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2302(t0,t1,t2);}

C_noret_decl(trf_2310)
static void C_ccall trf_2310(C_word c,C_word *av) C_noret;
static void C_ccall trf_2310(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2310(t0,t1,t2,t3);}

C_noret_decl(trf_2701)
static void C_ccall trf_2701(C_word c,C_word *av) C_noret;
static void C_ccall trf_2701(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2701(t0,t1,t2);}

C_noret_decl(trf_3009)
static void C_ccall trf_3009(C_word c,C_word *av) C_noret;
static void C_ccall trf_3009(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3009(t0,t1,t2,t3);}

C_noret_decl(trf_3104)
static void C_ccall trf_3104(C_word c,C_word *av) C_noret;
static void C_ccall trf_3104(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3104(t0,t1);}

C_noret_decl(trf_3107)
static void C_ccall trf_3107(C_word c,C_word *av) C_noret;
static void C_ccall trf_3107(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3107(t0,t1);}

C_noret_decl(trf_3296)
static void C_ccall trf_3296(C_word c,C_word *av) C_noret;
static void C_ccall trf_3296(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3296(t0,t1,t2);}

C_noret_decl(trf_3424)
static void C_ccall trf_3424(C_word c,C_word *av) C_noret;
static void C_ccall trf_3424(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3424(t0,t1,t2,t3);}

C_noret_decl(trf_4490)
static void C_ccall trf_4490(C_word c,C_word *av) C_noret;
static void C_ccall trf_4490(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4490(t0,t1);}

C_noret_decl(trf_5642)
static void C_ccall trf_5642(C_word c,C_word *av) C_noret;
static void C_ccall trf_5642(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5642(t0,t1);}

C_noret_decl(trf_5793)
static void C_ccall trf_5793(C_word c,C_word *av) C_noret;
static void C_ccall trf_5793(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5793(t0,t1);}

C_noret_decl(trf_5846)
static void C_ccall trf_5846(C_word c,C_word *av) C_noret;
static void C_ccall trf_5846(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5846(t0,t1);}

C_noret_decl(trf_5970)
static void C_ccall trf_5970(C_word c,C_word *av) C_noret;
static void C_ccall trf_5970(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5970(t0,t1);}

C_noret_decl(trf_6160)
static void C_ccall trf_6160(C_word c,C_word *av) C_noret;
static void C_ccall trf_6160(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6160(t0,t1);}

C_noret_decl(trf_6273)
static void C_ccall trf_6273(C_word c,C_word *av) C_noret;
static void C_ccall trf_6273(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6273(t0,t1);}

C_noret_decl(trf_6276)
static void C_ccall trf_6276(C_word c,C_word *av) C_noret;
static void C_ccall trf_6276(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6276(t0,t1);}

C_noret_decl(trf_6401)
static void C_ccall trf_6401(C_word c,C_word *av) C_noret;
static void C_ccall trf_6401(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6401(t0,t1,t2);}

C_noret_decl(trf_6424)
static void C_ccall trf_6424(C_word c,C_word *av) C_noret;
static void C_ccall trf_6424(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6424(t0,t1,t2);}

/* k1662 */
static void C_ccall f_1664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1664,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k1665 in k1662 */
static void C_ccall f_1667(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1667,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_expand_toplevel(2,av2);}}

/* k1668 in k1665 in k1662 */
static void C_ccall f_1670(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1670,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1673,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_internal_toplevel(2,av2);}}

/* k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_1673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1673,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_optimizer_toplevel(2,av2);}}

/* k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_1676(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1676,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_support_toplevel(2,av2);}}

/* k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_1679(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1679,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_compiler_toplevel(2,av2);}}

/* k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_1682(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,4)))){
C_save_and_reclaim((void *)f_1682,2,av);}
a=C_alloc(23);
t2=C_a_i_provide(&a,1,lf[0]);
t3=C_a_i_provide(&a,1,lf[1]);
t4=C_mutate(&lf[2] /* (set! chicken.compiler.c-platform#cons* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2117,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[3] /* (set! chicken.compiler.c-platform#filter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2293,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:55: chicken.compiler.optimizer#default-optimization-passes */
t7=*((C_word*)lf[943]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* chicken.compiler.c-platform#cons* in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_fcall f_2117(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_2117,3,t1,t2,t3);}
a=C_alloc(5);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2123,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_2123(t7,t1,t2,t3);}

/* loop in chicken.compiler.c-platform#cons* in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_fcall f_2123(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_2123,4,t0,t1,t2,t3);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2137,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(t3);
t6=t3;
t7=C_u_i_cdr(t6);
/* mini-srfi-1.scm:95: loop */
t9=t4;
t10=t5;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k2135 in loop in chicken.compiler.c-platform#cons* in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_2137(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_2137,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* chicken.compiler.c-platform#filter in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_fcall f_2293(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_2293,3,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_check_list_2(t3,lf[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2302,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2302(t8,t1,t3);}

/* foldr254 in chicken.compiler.c-platform#filter in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_fcall f_2302(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_2302,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2331,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g259 in foldr254 in chicken.compiler.c-platform#filter in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_fcall f_2310(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_2310,4,t0,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2317,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* mini-srfi-1.scm:131: pred */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2315 in g259 in foldr254 in chicken.compiler.c-platform#filter in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_2317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_2317,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2329 in foldr254 in chicken.compiler.c-platform#filter in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_2331(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2331,2,av);}
/* mini-srfi-1.scm:131: g259 */
t2=((C_word*)t0)[2];
f_2310(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* loop in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static C_word C_fcall f_2459(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:{}
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=t1;
t4=C_u_i_car(t3);
return(t4);}
else{
t3=t1;
t4=C_u_i_cdr(t3);
t6=t4;
t1=t6;
goto loop;}}

/* loop in k5187 in k5184 in k5245 in k5169 in k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in ... */
static void C_fcall f_2701(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_2701,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2715,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* mini-srfi-1.scm:190: proc */
t4=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k2713 in loop in k5187 in k5184 in k5245 in k5169 in k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in ... */
static void C_ccall f_2715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2715,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2719,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* mini-srfi-1.scm:190: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2701(t5,t3,t4);}

/* k2717 in k2713 in loop in k5187 in k5184 in k5245 in k5169 in k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in ... */
static void C_ccall f_2719(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_2719,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_2963(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2963,2,av);}
a=C_alloc(3);
t2=C_mutate((C_word*)lf[5]+1 /* (set! chicken.compiler.c-platform#default-declarations ...) */,lf[6]);
t3=C_mutate((C_word*)lf[7]+1 /* (set! chicken.compiler.c-platform#default-profiling-declarations ...) */,lf[8]);
t4=C_mutate((C_word*)lf[9]+1 /* (set! chicken.compiler.c-platform#default-units ...) */,lf[10]);
t5=C_set_block_item(lf[11] /* chicken.compiler.c-platform#words-per-flonum */,0,C_fix(4));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:82: chicken.compiler.optimizer#eq-inline-operator */
t7=*((C_word*)lf[941]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[942];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_2970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2970,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:83: chicken.compiler.optimizer#membership-test-operators */
t3=*((C_word*)lf[939]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[940];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_2973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2973,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:86: chicken.compiler.optimizer#membership-unfold-limit */
t3=*((C_word*)lf[938]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(20);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_2976(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_2976,2,av);}
a=C_alloc(15);
t2=C_mutate((C_word*)lf[12]+1 /* (set! chicken.compiler.c-platform#target-include-file ...) */,lf[13]);
t3=C_mutate((C_word*)lf[14]+1 /* (set! chicken.compiler.c-platform#valid-compiler-options ...) */,lf[15]);
t4=C_mutate((C_word*)lf[16]+1 /* (set! chicken.compiler.c-platform#valid-compiler-options-with-argument ...) */,lf[17]);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6424,a[2]=t7,a[3]=t11,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6424(t13,t9,lf[937]);}

/* k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_2991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_2991,2,av);}
a=C_alloc(3);
t2=C_mutate((C_word*)lf[18]+1 /* (set! chicken.compiler.core#default-standard-bindings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:258: scheme#append */
t4=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[932];
av2[3]=lf[933];
av2[4]=lf[934];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_2998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_2998,2,av);}
a=C_alloc(8);
t2=C_mutate((C_word*)lf[19]+1 /* (set! chicken.compiler.core#default-extended-bindings ...) */,t1);
t3=C_mutate((C_word*)lf[20]+1 /* (set! chicken.compiler.core#internal-bindings ...) */,lf[21]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6401,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6401(t8,t4,lf[931]);}

/* k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_3007,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3009,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3074,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6399,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:312: op1 */
f_3009(t4,lf[926],lf[927],lf[928]);}

/* op1 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_fcall f_3009(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,6)))){
C_save_and_reclaim_args((void *)trf_3009,4,t1,t2,t3,t4);}
a=C_alloc(5);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3011,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* f_3011 in op1 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3011(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,4)))){
C_save_and_reclaim((void *)f_3011,6,av);}
a=C_alloc(19);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(1));
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3033,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=C_eqp(lf[24],*((C_word*)lf[25]+1));
if(C_truep(t11)){
if(C_truep(*((C_word*)lf[26]+1))){
t12=((C_word*)t0)[2];
t13=C_a_i_list1(&a,1,t12);
/* c-platform.scm:308: chicken.compiler.support#make-node */
t14=*((C_word*)lf[22]+1);{
C_word *av2=av;
av2[0]=t14;
av2[1]=t10;
av2[2]=lf[27];
av2[3]=t13;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t14+1)))(5,av2);}}
else{
t12=((C_word*)t0)[3];
t13=C_a_i_list1(&a,1,t12);
/* c-platform.scm:308: chicken.compiler.support#make-node */
t14=*((C_word*)lf[22]+1);{
C_word *av2=av;
av2[0]=t14;
av2[1]=t10;
av2[2]=lf[27];
av2[3]=t13;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t14+1)))(5,av2);}}}
else{
t12=C_a_i_list2(&a,2,((C_word*)t0)[4],C_fix(36));
t13=t12;
t14=C_i_car(t5);
t15=t14;
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3066,a[2]=t15,a[3]=t10,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:311: chicken.compiler.support#qnode */
t17=*((C_word*)lf[29]+1);{
C_word *av2=av;
av2[0]=t17;
av2[1]=t16;
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t17+1)))(3,av2);}}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k3031 */
static void C_ccall f_3033(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3033,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:303: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3064 */
static void C_ccall f_3066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3066,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:309: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[28];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3074,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6395,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:313: op1 */
f_3009(t3,lf[922],lf[923],lf[924]);}

/* k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_3077,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3079,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:336: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[825];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_3079,6,av);}
a=C_alloc(13);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(2));
if(C_truep(t7)){
t8=t5;
t9=C_i_car(t8);
t10=t9;
t11=t5;
t12=C_i_cadr(t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3095,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t13,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3225,a[2]=t4,a[3]=t14,a[4]=t13,a[5]=t10,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:323: chicken.compiler.support#node-class */
t16=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t16;
av2[1]=t15;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t16+1)))(3,av2);}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k3093 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3095(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_3095,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3104,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3179,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:327: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k3102 in k3093 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_fcall f_3104(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_3104,2,t0,t1);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3107(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3152,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:330: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k3105 in k3102 in k3093 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_fcall f_3107(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_3107,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:335: chicken.compiler.support#make-node */
t5=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[27];
av2[3]=lf[30];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3120 in k3105 in k3102 in k3093 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3122(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3122,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:333: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3132 in k3146 in k3150 in k3102 in k3093 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_3134(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3134,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_3107(t2,t1);}
else{
t2=C_i_numberp(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3107(t3,C_i_not(t2));}}

/* k3146 in k3150 in k3102 in k3093 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3148(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3148,2,av);}
a=C_alloc(4);
t2=C_i_car(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:332: chicken.compiler.support#immediate? */
t5=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3150 in k3102 in k3093 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3152,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:331: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];
f_3107(t3,C_SCHEME_FALSE);}}

/* k3159 in k3173 in k3177 in k3093 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3161(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3161,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_3104(t3,t2);}
else{
t2=C_i_numberp(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3104(t3,C_i_not(t2));}}

/* k3173 in k3177 in k3093 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3175(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3175,2,av);}
a=C_alloc(4);
t2=C_i_car(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:329: chicken.compiler.support#immediate? */
t5=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3177 in k3093 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3179(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3179,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:328: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];
f_3104(t3,C_SCHEME_FALSE);}}

/* k3207 in k3215 in k3211 in k3219 in k3223 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_3209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3209,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:326: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3211 in k3219 in k3223 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3213(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3213,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3217,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:325: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3215 in k3211 in k3219 in k3223 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3217(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_3217,2,av);}
a=C_alloc(8);
if(C_truep(C_i_equalp(((C_word*)t0)[2],t1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3209,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:326: chicken.compiler.support#qnode */
t5=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_3095(2,av2);}}}

/* k3219 in k3223 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3221(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3221,2,av);}
a=C_alloc(5);
t2=C_eqp(lf[35],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:325: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_3095(2,av2);}}}

/* k3223 in eqv?-id in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3225(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_3225,2,av);}
a=C_alloc(6);
t2=C_eqp(lf[35],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:324: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_3095(2,av2);}}}

/* k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3233,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:337: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[823];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_3236,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3239,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6230,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:339: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[920];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3239(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_3239,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3241,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3419,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:394: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[917];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3241(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_3241,6,av);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t5))){
t6=t5;
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2459,tmp=(C_word)a,a+=2,tmp);
t8=(
  f_2459(t6)
);
t9=t8;
t10=t5;
t11=C_u_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3416,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t9,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:374: chicken.compiler.support#node-class */
t13=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t13;
av2[1]=t12;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t13+1)))(3,av2);}}
else{
t6=t1;{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k3267 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_3269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3269,2,av);}
/* c-platform.scm:375: chicken.compiler.support#make-node */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3275 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_3277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_3277,2,av);}
a=C_alloc(6);
/* c-platform.scm:377: cons* */
f_2117(((C_word*)t0)[2],((C_word*)t0)[3],C_a_i_list(&a,2,((C_word*)t0)[4],t1));}

/* k3292 in k3330 in k3334 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in ... */
static void C_ccall f_3294(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3294,2,av);}
/* c-platform.scm:379: scheme#append */
t2=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop693 in k3330 in k3334 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in ... */
static void C_fcall f_3296(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_3296,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3321,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* c-platform.scm:379: g699 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3319 in map-loop693 in k3330 in k3334 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in ... */
static void C_ccall f_3321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3321,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3296(t6,((C_word*)t0)[5],t5);}

/* k3330 in k3334 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in ... */
static void C_ccall f_3332(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_3332,2,av);}
a=C_alloc(12);
t2=C_i_car(t1);
t3=C_i_check_list_2(t2,lf[36]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3296,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3296(t8,t4,t2);}

/* k3334 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_3336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_3336,2,av);}
a=C_alloc(12);
t2=C_i_cdr(t1);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=*((C_word*)lf[29]+1);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t6,a[5]=t8,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:379: chicken.compiler.support#node-parameters */
t10=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k3337 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_3339(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_3339,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3353,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3357,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:392: chicken.compiler.support#make-node */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[39];
av2[3]=lf[40];
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}

/* k3351 in k3337 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in ... */
static void C_ccall f_3353(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3353,2,av);}
/* c-platform.scm:390: chicken.compiler.support#make-node */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3355 in k3337 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in ... */
static void C_ccall f_3357(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_3357,2,av);}
a=C_alloc(6);
/* c-platform.scm:392: cons* */
f_2117(((C_word*)t0)[2],t1,C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]));}

/* k3378 in k3401 in k3410 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in ... */
static void C_ccall f_3380(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_3380,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:387: chicken.compiler.support#make-node */
t5=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[39];
av2[3]=lf[43];
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_3339(2,av2);}}}

/* k3393 in k3378 in k3401 in k3410 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in ... */
static void C_ccall f_3395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_3395,2,av);}
a=C_alloc(9);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list3(&a,3,t1,((C_word*)t0)[3],t2);
/* c-platform.scm:385: chicken.compiler.support#make-node */
t4=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[5];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3401 in k3410 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in ... */
static void C_ccall f_3403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3403,2,av);}
a=C_alloc(5);
t2=C_i_car(t1);
if(C_truep((C_truep(C_eqp(t2,lf[41]))?C_SCHEME_TRUE:(C_truep(C_eqp(t2,lf[42]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:384: chicken.compiler.support#intrinsic? */
t4=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_3339(2,av2);}}}

/* k3410 in k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_3412(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3412,2,av);}
a=C_alloc(5);
t2=C_eqp(lf[35],t1);
if(C_truep(t2)){
t3=C_i_length(((C_word*)t0)[2]);
t4=C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:382: chicken.compiler.support#node-parameters */
t6=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_3339(2,av2);}}}
else{
t3=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_3339(2,av2);}}}

/* k3414 in rewrite-apply in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3416(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_3416,2,av);}
a=C_alloc(16);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,C_SCHEME_FALSE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3277,a[2]=t5,a[3]=t8,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3336,a[2]=t9,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:379: chicken.base#butlast */
t11=*((C_word*)lf[38]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3412,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:380: chicken.compiler.support#node-class */
t5=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3419(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3419,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3422,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:395: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[916];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_3422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_3422,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3424,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3492,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:416: rewrite-c..r */
f_3424(t3,lf[913],lf[914],lf[915]);}

/* rewrite-c..r in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_fcall f_3424(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,6)))){
C_save_and_reclaim_args((void *)trf_3424,4,t1,t2,t3,t4);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3430,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:399: chicken.compiler.optimizer#rewrite */
t6=*((C_word*)lf[46]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(8);
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* a3429 in rewrite-c..r in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in ... */
static void C_ccall f_3430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_3430,6,av);}
a=C_alloc(6);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(1));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3442,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:405: scheme#call-with-current-continuation */
t9=*((C_word*)lf[45]+1);{
C_word *av2=av;
av2[0]=t9;
av2[1]=t1;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* a3441 in a3429 in rewrite-c..r in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in ... */
static void C_ccall f_3442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_3442,3,av);}
a=C_alloc(11);
t3=((C_word*)t0)[2];
t4=C_i_car(t3);
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3461,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_truep(*((C_word*)lf[26]+1))?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_a_i_list1(&a,1,((C_word*)t0)[4]);
/* c-platform.scm:412: chicken.compiler.support#make-node */
t10=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t10;
av2[1]=t7;
av2[2]=lf[27];
av2[3]=t9;
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}
else{
if(C_truep(((C_word*)t0)[5])){
t9=C_a_i_list1(&a,1,((C_word*)t0)[5]);
/* c-platform.scm:413: chicken.compiler.support#make-node */
t10=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t10;
av2[1]=t7;
av2[2]=lf[27];
av2[3]=t9;
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}
else{
/* c-platform.scm:414: return */
t9=t2;{
C_word *av2=av;
av2[0]=t9;
av2[1]=t7;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}}

/* k3459 in a3441 in a3429 in rewrite-c..r in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in ... */
static void C_ccall f_3461(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3461,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:408: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_3492(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3492,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:417: rewrite-c..r */
f_3424(t2,lf[910],lf[911],lf[912]);}

/* k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in ... */
static void C_ccall f_3495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3495,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:418: rewrite-c..r */
f_3424(t2,lf[907],lf[908],lf[909]);}

/* k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in ... */
static void C_ccall f_3498(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3498,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:419: rewrite-c..r */
f_3424(t2,lf[904],lf[905],lf[906]);}

/* k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in ... */
static void C_ccall f_3501(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_3501,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:420: rewrite-c..r */
f_3424(t2,lf[880],lf[902],lf[903]);}

/* k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in ... */
static void C_ccall f_3504(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3504,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3507,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:421: rewrite-c..r */
f_3424(t2,lf[859],lf[900],lf[901]);}

/* k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in ... */
static void C_ccall f_3507(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_3507,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3508,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3534,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:428: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[898];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* rvalues in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in ... */
static void C_ccall f_3508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3508,6,av);}
a=C_alloc(6);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(1));
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=C_a_i_cons(&a,2,t4,t5);
/* c-platform.scm:427: chicken.compiler.support#make-node */
t10=*((C_word*)lf[22]+1);{
C_word *av2=av;
av2[0]=t10;
av2[1]=t1;
av2[2]=lf[23];
av2[3]=t8;
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in ... */
static void C_ccall f_3534(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3534,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3537,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:429: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[42];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in ... */
static void C_ccall f_3537(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_3537,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3539,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3704,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:460: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[894];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in ... */
static void C_ccall f_3539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_3539,6,av);}
a=C_alloc(7);
t6=C_i_length(t5);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=C_i_cadr(t5);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3696,a[2]=t1,a[3]=t9,a[4]=t11,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:438: chicken.compiler.support#node-class */
t13=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t13;
av2[1]=t12;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t13+1)))(3,av2);}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in ... */
static void C_ccall f_3573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_3573,2,av);}
a=C_alloc(7);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:442: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3598 in k3678 in k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in ... */
static void C_ccall f_3600(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_3600,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3603,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-platform.scm:447: chicken.base#gensym */
t4=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[55];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3601 in k3598 in k3678 in k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in ... */
static void C_ccall f_3603(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_3603,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3673,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:448: chicken.compiler.support#node-parameters */
t5=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3604 in k3601 in k3598 in k3678 in k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in ... */
static void C_ccall f_3606(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_3606,2,av);}
a=C_alloc(15);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3621,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:453: chicken.base#gensym */
t6=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[51];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k3619 in k3604 in k3601 in k3598 in k3678 in k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in ... */
static void C_ccall f_3621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_3621,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3625,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:459: chicken.compiler.support#varnode */
t7=*((C_word*)lf[49]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k3623 in k3619 in k3604 in k3601 in k3598 in k3678 in k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in ... */
static void C_ccall f_3625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3625,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:449: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[48];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3635 in k3619 in k3604 in k3601 in k3598 in k3678 in k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in ... */
static void C_ccall f_3637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3637,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:457: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3647 in k3663 in k3604 in k3601 in k3598 in k3678 in k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in ... */
static void C_ccall f_3649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3649,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* c-platform.scm:451: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[47];
av2[3]=((C_word*)t0)[3];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3659 in k3663 in k3604 in k3601 in k3598 in k3678 in k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in ... */
static void C_ccall f_3661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_3661,2,av);}
a=C_alloc(9);
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t1);
/* c-platform.scm:454: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[5];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3663 in k3604 in k3601 in k3598 in k3678 in k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in ... */
static void C_ccall f_3665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,2)))){
C_save_and_reclaim((void *)f_3665,2,av);}
a=C_alloc(28);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3649,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:456: chicken.compiler.support#varnode */
t9=*((C_word*)lf[49]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k3671 in k3601 in k3598 in k3678 in k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in ... */
static void C_ccall f_3673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3673,2,av);}
/* c-platform.scm:448: chicken.compiler.support#debugging */
t2=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[53];
av2[3]=lf[54];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3678 in k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in ... */
static void C_ccall f_3680(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_3680,2,av);}
a=C_alloc(7);
t2=C_i_caddr(t1);
if(C_truep(C_i_listp(t2))){
t3=C_u_i_length(t2);
t4=C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:446: chicken.base#gensym */
t6=*((C_word*)lf[50]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3682 in k3571 in k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in ... */
static void C_ccall f_3684(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_3684,2,av);}
a=C_alloc(7);
t2=C_eqp(lf[47],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:443: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3686 in k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in ... */
static void C_ccall f_3688(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_3688,2,av);}
a=C_alloc(6);
t2=C_i_car(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:441: chicken.compiler.support#db-get */
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
av2[3]=t2;
av2[4]=lf[57];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3690 in k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in ... */
static void C_ccall f_3692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_3692,2,av);}
a=C_alloc(7);
t2=C_eqp(lf[35],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:440: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3694 in rewrite-c-w-v in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in ... */
static void C_ccall f_3696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_3696,2,av);}
a=C_alloc(7);
t2=C_eqp(lf[35],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3692,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:439: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in ... */
static void C_ccall f_3704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3704,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3707,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:461: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[891];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in ... */
static void C_ccall f_3707(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3707,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3710,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:463: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[898];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[899];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in ... */
static void C_ccall f_3710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3710,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3713,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:464: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[42];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[897];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in ... */
static void C_ccall f_3713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3713,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3716,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:465: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[894];
av2[3]=C_fix(13);
av2[4]=C_fix(2);
av2[5]=lf[896];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in ... */
static void C_ccall f_3716(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3716,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3719,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:466: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[894];
av2[3]=C_fix(13);
av2[4]=C_fix(2);
av2[5]=lf[895];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in k3005 in ... */
static void C_ccall f_3719(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3719,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3722,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:467: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[891];
av2[3]=C_fix(13);
av2[4]=C_fix(2);
av2[5]=lf[893];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in k3072 in ... */
static void C_ccall f_3722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3722,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:468: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[891];
av2[3]=C_fix(13);
av2[4]=C_fix(2);
av2[5]=lf[892];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in k3075 in ... */
static void C_ccall f_3725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3725,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:469: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[889];
av2[3]=C_fix(13);
av2[4]=C_fix(2);
av2[5]=lf[890];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in k3231 in ... */
static void C_ccall f_3728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3728,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:471: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[842];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[888];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in k3234 in ... */
static void C_ccall f_3731(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3731,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:472: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[840];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[887];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in k3237 in ... */
static void C_ccall f_3734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3734,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3737,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:473: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[838];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[886];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in k3417 in ... */
static void C_ccall f_3737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3737,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3740,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:474: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[884];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[885];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3420 in ... */
static void C_ccall f_3740(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3740,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3743,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:475: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[882];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[883];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in ... */
static void C_ccall f_3743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3743,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3746,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:476: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[880];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[881];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in k3493 in ... */
static void C_ccall f_3746(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3746,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3749,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:477: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[878];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[879];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in k3496 in ... */
static void C_ccall f_3749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3749,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3752,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:478: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[876];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[877];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in k3499 in ... */
static void C_ccall f_3752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3752,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:479: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[874];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[875];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in k3502 in ... */
static void C_ccall f_3755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3755,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:480: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[836];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[873];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in k3505 in ... */
static void C_ccall f_3758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3758,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3761,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:481: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[871];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[872];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in k3532 in ... */
static void C_ccall f_3761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3761,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:482: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[869];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[870];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in k3535 in ... */
static void C_ccall f_3764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3764,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3767,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:483: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[867];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[868];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in k3702 in ... */
static void C_ccall f_3767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3767,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:484: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[865];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[866];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in k3705 in ... */
static void C_ccall f_3770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3770,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3773,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:485: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[863];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[864];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in k3708 in ... */
static void C_ccall f_3773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3773,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:486: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[861];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[862];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in k3711 in ... */
static void C_ccall f_3776(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3776,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:487: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[859];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[860];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in k3714 in ... */
static void C_ccall f_3779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3779,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:488: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[857];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[858];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in k3717 in ... */
static void C_ccall f_3782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3782,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:489: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[855];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[856];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in k3720 in ... */
static void C_ccall f_3785(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3785,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:490: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[853];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[854];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in k3723 in ... */
static void C_ccall f_3788(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3788,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:491: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[851];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[852];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in ... */
static void C_ccall f_3791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3791,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3794,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:492: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[849];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[850];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in k3729 in ... */
static void C_ccall f_3794(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3794,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:493: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[847];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[848];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in k3732 in ... */
static void C_ccall f_3797(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3797,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3800,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:494: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[845];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[846];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in k3735 in ... */
static void C_ccall f_3800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3800,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:495: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[834];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[844];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in k3738 in ... */
static void C_ccall f_3803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3803,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:497: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[842];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[843];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in k3741 in ... */
static void C_ccall f_3806(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3806,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:498: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[840];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[841];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in k3744 in ... */
static void C_ccall f_3809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3809,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3812,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:499: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[838];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[839];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3747 in ... */
static void C_ccall f_3812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3812,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:500: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[836];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[837];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in ... */
static void C_ccall f_3815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3815,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:501: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[834];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[835];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in k3753 in ... */
static void C_ccall f_3818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_3818,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3821,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:503: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[831];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[833];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in k3756 in ... */
static void C_ccall f_3821(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3821,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:504: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[831];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[832];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in k3759 in ... */
static void C_ccall f_3824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_3824,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3827,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:506: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[829];
av2[3]=C_fix(1);
av2[4]=C_fix(2);
av2[5]=lf[830];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in k3762 in ... */
static void C_ccall f_3827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_3827,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:507: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[827];
av2[3]=C_fix(1);
av2[4]=C_fix(2);
av2[5]=lf[828];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in k3765 in ... */
static void C_ccall f_3830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_3830,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3833,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:508: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[825];
av2[3]=C_fix(1);
av2[4]=C_fix(2);
av2[5]=lf[826];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in k3768 in ... */
static void C_ccall f_3833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_3833,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:509: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[823];
av2[3]=C_fix(1);
av2[4]=C_fix(2);
av2[5]=lf[824];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in k3771 in ... */
static void C_ccall f_3836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3836,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:511: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[820];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[822];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in k3774 in ... */
static void C_ccall f_3839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3839,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:512: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[820];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[821];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in k3777 in ... */
static void C_ccall f_3842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3842,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:513: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[818];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[819];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3780 in ... */
static void C_ccall f_3845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3845,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3848,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:514: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[816];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[817];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in ... */
static void C_ccall f_3848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3848,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3851,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:515: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[814];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[815];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in ... */
static void C_ccall f_3851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3851,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:516: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[812];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[813];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in ... */
static void C_ccall f_3854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3854,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3857,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:517: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[810];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[811];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in k3792 in ... */
static void C_ccall f_3857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3857,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:518: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[808];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[809];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in k3795 in ... */
static void C_ccall f_3860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3860,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:519: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[806];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[807];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in k3798 in ... */
static void C_ccall f_3863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3863,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:520: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[804];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[805];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in k3801 in ... */
static void C_ccall f_3866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3866,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3869,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:521: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[802];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[803];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in k3804 in ... */
static void C_ccall f_3869(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3869,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3872,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:522: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[800];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[801];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in k3807 in ... */
static void C_ccall f_3872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3872,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:523: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[798];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[799];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in k3810 in ... */
static void C_ccall f_3875(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3875,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:524: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[796];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[797];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in k3813 in ... */
static void C_ccall f_3878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3878,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3881,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:525: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[794];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[795];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in k3816 in ... */
static void C_ccall f_3881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3881,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:526: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[792];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[793];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in k3819 in ... */
static void C_ccall f_3884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3884,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:527: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[790];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[791];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in k3822 in ... */
static void C_ccall f_3887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3887,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:528: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[788];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[789];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in k3825 in ... */
static void C_ccall f_3890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3890,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:529: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[786];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[787];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in k3828 in ... */
static void C_ccall f_3893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3893,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3896,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:530: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[784];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[785];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in k3831 in ... */
static void C_ccall f_3896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3896,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3899,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:531: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[782];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[783];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in k3834 in ... */
static void C_ccall f_3899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3899,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:532: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[780];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[781];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in k3837 in ... */
static void C_ccall f_3902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3902,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:533: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[778];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[779];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in k3840 in ... */
static void C_ccall f_3905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3905,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:534: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[776];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[777];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in k3843 in ... */
static void C_ccall f_3908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3908,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:535: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[774];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[775];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in k3846 in ... */
static void C_ccall f_3911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3911,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3914,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:536: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[772];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[773];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in k3849 in ... */
static void C_ccall f_3914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3914,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:537: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[770];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[771];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in k3852 in ... */
static void C_ccall f_3917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3917,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:538: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[768];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[769];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in k3855 in ... */
static void C_ccall f_3920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3920,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3923,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:539: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[766];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[767];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in k3858 in ... */
static void C_ccall f_3923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3923,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3926,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:540: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[764];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[765];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 in ... */
static void C_ccall f_3926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3926,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:541: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[762];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[763];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in k3864 in ... */
static void C_ccall f_3929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3929,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3932,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:542: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[760];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[761];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in k3867 in ... */
static void C_ccall f_3932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3932,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:543: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[758];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[759];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in k3870 in ... */
static void C_ccall f_3935(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3935,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:544: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[756];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[757];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in k3873 in ... */
static void C_ccall f_3938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3938,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:545: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[754];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[755];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in k3876 in ... */
static void C_ccall f_3941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3941,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:546: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[752];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[753];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in k3879 in ... */
static void C_ccall f_3944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3944,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:547: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[750];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[751];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in k3882 in ... */
static void C_ccall f_3947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3947,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:548: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[748];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[749];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in ... */
static void C_ccall f_3950(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3950,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:549: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[746];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[747];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in k3888 in ... */
static void C_ccall f_3953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3953,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3956,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:550: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[744];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[745];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3891 in ... */
static void C_ccall f_3956(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3956,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:551: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[742];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[743];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in ... */
static void C_ccall f_3959(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3959,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:552: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[740];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[741];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in ... */
static void C_ccall f_3962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3962,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:553: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[738];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[739];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in ... */
static void C_ccall f_3965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3965,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3968,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:554: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[736];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[737];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in k3903 in ... */
static void C_ccall f_3968(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3968,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:555: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[734];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[735];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in k3906 in ... */
static void C_ccall f_3971(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3971,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:556: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[732];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[733];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in k3909 in ... */
static void C_ccall f_3974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3974,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:557: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[729];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[731];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in k3912 in ... */
static void C_ccall f_3977(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3977,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3980,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:558: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[729];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[730];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in ... */
static void C_ccall f_3980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3980,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3983,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:559: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[726];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[728];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in ... */
static void C_ccall f_3983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3983,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:560: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[726];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[727];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in k3921 in ... */
static void C_ccall f_3986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3986,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:561: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[724];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[725];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in k3924 in ... */
static void C_ccall f_3989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3989,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:562: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[722];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[723];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in k3927 in ... */
static void C_ccall f_3992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3992,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:563: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[719];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[721];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k3930 in ... */
static void C_ccall f_3995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3995,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3998,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:564: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[719];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[720];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in ... */
static void C_ccall f_3998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_3998,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4001,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:565: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[716];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[718];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3936 in ... */
static void C_ccall f_4001(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4001,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:566: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[716];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[717];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in ... */
static void C_ccall f_4004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4004,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:567: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[713];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[715];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in ... */
static void C_ccall f_4007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4007,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:568: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[713];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[714];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in ... */
static void C_ccall f_4010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4010,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4013,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:569: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[710];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[712];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in ... */
static void C_ccall f_4013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4013,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:570: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[710];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[711];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in ... */
static void C_ccall f_4016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4016,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:571: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[707];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[709];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in ... */
static void C_ccall f_4019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4019,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:572: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[707];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[708];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in ... */
static void C_ccall f_4022(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4022,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4025,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:573: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[704];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[706];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in ... */
static void C_ccall f_4025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4025,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:574: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[704];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[705];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in ... */
static void C_ccall f_4028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4028,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:575: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[701];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[703];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in ... */
static void C_ccall f_4031(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4031,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:576: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[701];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[702];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in ... */
static void C_ccall f_4034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4034,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:577: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[698];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[700];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in ... */
static void C_ccall f_4037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4037,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:578: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[698];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[699];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in ... */
static void C_ccall f_4040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4040,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:579: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[696];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[697];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in ... */
static void C_ccall f_4043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4043,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:580: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[694];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[695];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in ... */
static void C_ccall f_4046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4046,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:581: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[692];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[693];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in ... */
static void C_ccall f_4049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4049,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:582: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[690];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[691];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in ... */
static void C_ccall f_4052(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4052,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:583: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[688];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[689];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in ... */
static void C_ccall f_4055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4055,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:584: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[686];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[687];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in ... */
static void C_ccall f_4058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4058,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4061,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:585: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[684];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[685];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in ... */
static void C_ccall f_4061(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4061,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:586: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[682];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[683];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in ... */
static void C_ccall f_4064(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4064,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:587: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[680];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[681];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in ... */
static void C_ccall f_4067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4067,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:588: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[678];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[679];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in ... */
static void C_ccall f_4070(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4070,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:589: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[676];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[677];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in ... */
static void C_ccall f_4073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4073,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:590: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[674];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[675];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in ... */
static void C_ccall f_4076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4076,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:591: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[672];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[673];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in ... */
static void C_ccall f_4079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4079,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4082,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:592: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[670];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[671];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in ... */
static void C_ccall f_4082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4082,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:593: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[668];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[669];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in ... */
static void C_ccall f_4085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4085,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:594: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[666];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[667];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in ... */
static void C_ccall f_4088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4088,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4091,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:595: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[664];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[665];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4026 in ... */
static void C_ccall f_4091(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4091,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4094,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:596: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[662];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[663];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in ... */
static void C_ccall f_4094(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4094,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:597: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[660];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[661];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in ... */
static void C_ccall f_4097(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4097,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:598: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[658];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[659];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in ... */
static void C_ccall f_4100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4100,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:599: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[656];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[657];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in ... */
static void C_ccall f_4103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4103,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:600: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[654];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[655];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in ... */
static void C_ccall f_4106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4106,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4109,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:601: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[652];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[653];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in ... */
static void C_ccall f_4109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4109,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4112,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:602: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[650];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[651];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in ... */
static void C_ccall f_4112(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4112,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:603: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[648];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[649];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in ... */
static void C_ccall f_4115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4115,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:604: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[646];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[647];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in ... */
static void C_ccall f_4118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4118,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4121,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:605: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[644];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[645];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in ... */
static void C_ccall f_4121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4121,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:606: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[642];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[643];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in k4059 in ... */
static void C_ccall f_4124(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4124,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:607: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[640];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[641];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in k4062 in ... */
static void C_ccall f_4127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4127,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:608: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[638];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[639];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in k4065 in ... */
static void C_ccall f_4130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4130,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:609: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[636];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[637];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in ... */
static void C_ccall f_4133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4133,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:610: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[634];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[635];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in ... */
static void C_ccall f_4136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4136,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:611: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[632];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[633];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in ... */
static void C_ccall f_4139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4139,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4142,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:612: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[630];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[631];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in ... */
static void C_ccall f_4142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4142,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4145,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:613: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[628];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[629];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in ... */
static void C_ccall f_4145(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4145,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4148,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:614: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[626];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[627];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in ... */
static void C_ccall f_4148(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4148,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4151,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:615: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[624];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[625];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in ... */
static void C_ccall f_4151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4151,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:617: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[620];
av2[3]=C_fix(14);
av2[4]=lf[24];
av2[5]=C_fix(2);
av2[6]=lf[622];
av2[7]=lf[623];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in k4089 in ... */
static void C_ccall f_4154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4154,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:618: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[620];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[621];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in k4092 in ... */
static void C_ccall f_4157(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4157,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4160,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:619: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[616];
av2[3]=C_fix(14);
av2[4]=lf[24];
av2[5]=C_fix(2);
av2[6]=lf[618];
av2[7]=lf[619];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in k4095 in ... */
static void C_ccall f_4160(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4160,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4163,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:620: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[616];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[617];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in k4098 in ... */
static void C_ccall f_4163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4163,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4166,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:621: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[613];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[614];
av2[6]=lf[615];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in k4101 in ... */
static void C_ccall f_4166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4166,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4169,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:622: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[610];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[611];
av2[6]=lf[612];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in k4104 in ... */
static void C_ccall f_4169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4169,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:623: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[608];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[609];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in k4107 in ... */
static void C_ccall f_4172(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4172,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4175,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:624: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[606];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[607];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in k4110 in ... */
static void C_ccall f_4175(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4175,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4178,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:626: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[603];
av2[3]=C_fix(4);
av2[4]=lf[297];
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in k4113 in ... */
static void C_ccall f_4178(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4178,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4181,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:627: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[600];
av2[3]=C_fix(4);
av2[4]=lf[297];
av2[5]=C_fix(1);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in k4116 in ... */
static void C_ccall f_4181(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4181,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4184,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:628: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[603];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[604];
av2[6]=lf[605];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in k4119 in ... */
static void C_ccall f_4184(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4184,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4187,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:629: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[600];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[601];
av2[6]=lf[602];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in k4122 in ... */
static void C_ccall f_4187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4187,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4190,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:631: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[597];
av2[3]=C_fix(14);
av2[4]=lf[24];
av2[5]=C_fix(1);
av2[6]=lf[598];
av2[7]=lf[599];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in k4125 in ... */
static void C_ccall f_4190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4190,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4193,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:633: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[593];
av2[3]=C_fix(19);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in k4128 in ... */
static void C_ccall f_4193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4193,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4196,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:634: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[589];
av2[3]=C_fix(19);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in k4131 in ... */
static void C_ccall f_4196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4196,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4199,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:635: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[585];
av2[3]=C_fix(19);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in k4134 in ... */
static void C_ccall f_4199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,8)))){
C_save_and_reclaim((void *)f_4199,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4202,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:637: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 9) {
  av2=av;
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[593];
av2[3]=C_fix(21);
av2[4]=C_fix(-1);
av2[5]=lf[594];
av2[6]=lf[595];
av2[7]=lf[596];
av2[8]=C_fix(5);
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in k4137 in ... */
static void C_ccall f_4202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,8)))){
C_save_and_reclaim((void *)f_4202,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4205,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:638: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 9) {
  av2=av;
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[589];
av2[3]=C_fix(21);
av2[4]=C_fix(0);
av2[5]=lf[590];
av2[6]=lf[591];
av2[7]=lf[592];
av2[8]=C_fix(5);
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in k4140 in ... */
static void C_ccall f_4205(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,8)))){
C_save_and_reclaim((void *)f_4205,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4208,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:639: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 9) {
  av2=av;
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[585];
av2[3]=C_fix(21);
av2[4]=C_fix(0);
av2[5]=lf[586];
av2[6]=lf[587];
av2[7]=lf[588];
av2[8]=C_fix(5);
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in k4143 in ... */
static void C_ccall f_4208(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,8)))){
C_save_and_reclaim((void *)f_4208,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4211,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:641: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 9) {
  av2=av;
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[582];
av2[3]=C_fix(22);
av2[4]=C_fix(1);
av2[5]=lf[583];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(5);
av2[8]=lf[584];
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in k4146 in ... */
static void C_ccall f_4211(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4211,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4214,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:643: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[580];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[581];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in k4149 in ... */
static void C_ccall f_4214(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4214,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:644: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[578];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[579];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in k4152 in ... */
static void C_ccall f_4217(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4217,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:645: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[576];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[577];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in k4155 in ... */
static void C_ccall f_4220(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4220,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:646: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[574];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[575];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in k4158 in ... */
static void C_ccall f_4223(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4223,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4226,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:647: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[572];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[573];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in k4161 in ... */
static void C_ccall f_4226(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4226,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4229,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:648: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[570];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[571];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in k4164 in ... */
static void C_ccall f_4229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4229,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4232,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:649: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[568];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[569];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in k4167 in ... */
static void C_ccall f_4232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4232,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4235,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:651: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[564];
av2[3]=C_fix(5);
av2[4]=lf[567];
av2[5]=C_fix(0);
av2[6]=lf[24];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in k4170 in ... */
static void C_ccall f_4235(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4235,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4238,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:652: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[564];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[566];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in k4173 in ... */
static void C_ccall f_4238(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4238,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4241,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:653: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[564];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[565];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in k4176 in ... */
static void C_ccall f_4241(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4241,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4244,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:654: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[560];
av2[3]=C_fix(5);
av2[4]=lf[563];
av2[5]=C_fix(0);
av2[6]=lf[24];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in k4179 in ... */
static void C_ccall f_4244(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4244,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4247,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:655: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[560];
av2[3]=C_fix(5);
av2[4]=lf[562];
av2[5]=C_fix(0);
av2[6]=lf[388];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in k4182 in ... */
static void C_ccall f_4247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4247,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:656: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[560];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[561];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in k4185 in ... */
static void C_ccall f_4250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4250,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4253,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:657: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[556];
av2[3]=C_fix(5);
av2[4]=lf[559];
av2[5]=C_fix(0);
av2[6]=lf[24];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in k4188 in ... */
static void C_ccall f_4253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4253,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:658: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[556];
av2[3]=C_fix(5);
av2[4]=lf[558];
av2[5]=C_fix(0);
av2[6]=lf[388];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in k4191 in ... */
static void C_ccall f_4256(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4256,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:659: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[556];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[557];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in k4194 in ... */
static void C_ccall f_4259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4259,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4262,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:661: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[544];
av2[3]=C_fix(6);
av2[4]=lf[554];
av2[5]=lf[555];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in k4197 in ... */
static void C_ccall f_4262(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4262,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4265,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:662: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[540];
av2[3]=C_fix(6);
av2[4]=lf[552];
av2[5]=lf[553];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in k4200 in ... */
static void C_ccall f_4265(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4265,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:663: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[549];
av2[3]=C_fix(6);
av2[4]=lf[550];
av2[5]=lf[551];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in k4203 in ... */
static void C_ccall f_4268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4268,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4271,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:664: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[546];
av2[3]=C_fix(6);
av2[4]=lf[547];
av2[5]=lf[548];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in k4206 in ... */
static void C_ccall f_4271(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4271,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:666: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[544];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[545];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4209 in ... */
static void C_ccall f_4274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4274,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:667: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[542];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[543];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in ... */
static void C_ccall f_4277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4277,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:668: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[540];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[541];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in ... */
static void C_ccall f_4280(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4280,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4283,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:670: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[525];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[539];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in ... */
static void C_ccall f_4283(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4283,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4286,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:671: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[523];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[538];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in ... */
static void C_ccall f_4286(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4286,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:672: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[521];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[537];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in ... */
static void C_ccall f_4289(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4289,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4292,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:673: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[519];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[536];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in k4227 in ... */
static void C_ccall f_4292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4292,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4295,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:674: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[517];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[535];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in k4230 in ... */
static void C_ccall f_4295(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4295,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:675: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[515];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[534];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in k4233 in ... */
static void C_ccall f_4298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4298,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4301,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:676: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[513];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[533];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in k4236 in ... */
static void C_ccall f_4301(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4301,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:677: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[511];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[532];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in k4239 in ... */
static void C_ccall f_4304(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4304,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:678: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[509];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[531];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in k4242 in ... */
static void C_ccall f_4307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4307,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:679: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[507];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[530];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in k4245 in ... */
static void C_ccall f_4310(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4310,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:680: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[505];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[529];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in k4248 in ... */
static void C_ccall f_4313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4313,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4316,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:681: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[503];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[528];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in k4251 in ... */
static void C_ccall f_4316(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4316,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:682: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[501];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[527];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in k4254 in ... */
static void C_ccall f_4319(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4319,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:683: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[525];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[526];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in k4257 in ... */
static void C_ccall f_4322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4322,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4325,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:684: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[523];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[524];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in k4260 in ... */
static void C_ccall f_4325(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4325,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4328,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:685: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[521];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[522];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in k4263 in ... */
static void C_ccall f_4328(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4328,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:686: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[519];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[520];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in k4266 in ... */
static void C_ccall f_4331(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4331,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:687: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[517];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[518];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in k4269 in ... */
static void C_ccall f_4334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4334,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:688: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[515];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[516];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in ... */
static void C_ccall f_4337(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4337,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:689: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[513];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[514];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in ... */
static void C_ccall f_4340(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4340,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:690: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[511];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[512];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in ... */
static void C_ccall f_4343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4343,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:691: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[509];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[510];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in ... */
static void C_ccall f_4346(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4346,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:692: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[507];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[508];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in ... */
static void C_ccall f_4349(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4349,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:693: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[505];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[506];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in ... */
static void C_ccall f_4352(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4352,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:694: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[503];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[504];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in k4290 in ... */
static void C_ccall f_4355(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4355,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:695: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[501];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[502];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in k4293 in ... */
static void C_ccall f_4358(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4358,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:697: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[439];
av2[3]=C_fix(9);
av2[4]=lf[499];
av2[5]=lf[500];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in k4296 in ... */
static void C_ccall f_4361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4361,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:698: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[437];
av2[3]=C_fix(9);
av2[4]=lf[497];
av2[5]=lf[498];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in k4299 in ... */
static void C_ccall f_4364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4364,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:699: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[435];
av2[3]=C_fix(9);
av2[4]=lf[495];
av2[5]=lf[496];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in k4302 in ... */
static void C_ccall f_4367(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4367,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:700: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[433];
av2[3]=C_fix(9);
av2[4]=lf[493];
av2[5]=lf[494];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in k4305 in ... */
static void C_ccall f_4370(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4370,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:701: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[431];
av2[3]=C_fix(9);
av2[4]=lf[491];
av2[5]=lf[492];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in k4308 in ... */
static void C_ccall f_4373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4373,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:703: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[490];
av2[3]=C_fix(11);
av2[4]=C_fix(1);
av2[5]=lf[99];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in ... */
static void C_ccall f_4376(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4376,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:704: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[488];
av2[3]=C_fix(11);
av2[4]=C_fix(2);
av2[5]=lf[489];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in ... */
static void C_ccall f_4379(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4379,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:705: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[486];
av2[3]=C_fix(11);
av2[4]=C_fix(2);
av2[5]=lf[487];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in ... */
static void C_ccall f_4382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4382,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:706: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[485];
av2[3]=C_fix(11);
av2[4]=C_fix(3);
av2[5]=lf[297];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in ... */
static void C_ccall f_4385(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4385,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:707: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[484];
av2[3]=C_fix(11);
av2[4]=C_fix(3);
av2[5]=lf[297];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in ... */
static void C_ccall f_4388(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4388,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:708: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[483];
av2[3]=C_fix(11);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[340];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in ... */
static void C_ccall f_4391(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4391,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:709: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[481];
av2[3]=C_fix(11);
av2[4]=C_fix(3);
av2[5]=lf[482];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in ... */
static void C_ccall f_4394(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4394,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:710: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[479];
av2[3]=C_fix(11);
av2[4]=C_fix(2);
av2[5]=lf[480];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in ... */
static void C_ccall f_4397(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4397,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:711: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[477];
av2[3]=C_fix(11);
av2[4]=C_fix(1);
av2[5]=lf[478];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in ... */
static void C_ccall f_4400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4400,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:712: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[475];
av2[3]=C_fix(11);
av2[4]=C_fix(1);
av2[5]=lf[476];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in ... */
static void C_ccall f_4403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4403,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:714: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[473];
av2[3]=C_fix(11);
av2[4]=C_fix(3);
av2[5]=lf[297];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in ... */
static void C_ccall f_4406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4406,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:715: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[473];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[474];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in ... */
static void C_ccall f_4409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4409,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:717: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[469];
av2[3]=C_fix(12);
av2[4]=lf[472];
av2[5]=C_SCHEME_TRUE;
av2[6]=C_fix(2);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in ... */
static void C_ccall f_4412(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4412,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4415,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:718: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[468];
av2[3]=C_fix(12);
av2[4]=lf[471];
av2[5]=C_SCHEME_TRUE;
av2[6]=C_fix(2);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in ... */
static void C_ccall f_4415(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4415,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:719: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[470];
av2[3]=C_fix(12);
av2[4]=C_SCHEME_FALSE;
av2[5]=C_SCHEME_TRUE;
av2[6]=C_fix(1);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in k4353 in ... */
static void C_ccall f_4418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4418,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:721: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[469];
av2[3]=C_fix(19);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in k4356 in ... */
static void C_ccall f_4421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4421,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:722: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[468];
av2[3]=C_fix(19);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4359 in ... */
static void C_ccall f_4424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4424,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:724: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[469];
av2[3]=C_fix(18);
av2[4]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in ... */
static void C_ccall f_4427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4427,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:725: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[468];
av2[3]=C_fix(18);
av2[4]=C_fix(1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in k4365 in ... */
static void C_ccall f_4430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4430,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:726: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[349];
av2[3]=C_fix(18);
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in k4368 in ... */
static void C_ccall f_4433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_4433,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6084,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:728: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[429];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in ... */
static void C_ccall f_4436(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_4436,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5960,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:758: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[427];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in ... */
static void C_ccall f_4439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_4439,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5836,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:794: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[424];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in ... */
static void C_ccall f_4442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_4442,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4444,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4577,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:856: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[454];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* rewrite-div in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in ... */
static void C_ccall f_4444(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_4444,6,av);}
a=C_alloc(7);
t6=C_eqp(*((C_word*)lf[25]+1),lf[24]);
if(C_truep(t6)){
t7=C_i_length(t5);
if(C_truep(C_fixnum_greater_or_equal_p(t7,C_fix(2)))){
t8=C_i_car(t5);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4539,a[2]=t9,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4541,tmp=(C_word)a,a+=2,tmp);
t12=t5;
t13=C_u_i_cdr(t12);
/* c-platform.scm:840: filter */
f_2293(t10,t11,t13);}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t7=t1;{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k4479 in k4537 in rewrite-div in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in ... */
static void C_ccall f_4481(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_4481,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:846: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a4482 in k4537 in rewrite-div in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in ... */
static void C_ccall f_4483(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_4483,4,av);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4490,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4526,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:852: chicken.compiler.support#node-class */
t6=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k4488 in a4482 in k4537 in rewrite-div in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in ... */
static void C_fcall f_4490(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_4490,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:853: chicken.compiler.support#qnode */
t3=*((C_word*)lf[29]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
/* c-platform.scm:854: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[27];
av2[3]=lf[59];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k4499 in k4488 in a4482 in k4537 in rewrite-div in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in ... */
static void C_ccall f_4501(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_4501,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:853: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[27];
av2[3]=lf[58];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4520 in k4524 in a4482 in k4537 in rewrite-div in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in ... */
static void C_ccall f_4522(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4522,2,av);}
t2=C_i_car(t1);
t3=((C_word*)t0)[2];
f_4490(t3,C_eqp(C_fix(2),t2));}

/* k4524 in a4482 in k4537 in rewrite-div in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in ... */
static void C_ccall f_4526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4526,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4522,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:852: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];
f_4490(t3,C_SCHEME_FALSE);}}

/* k4537 in rewrite-div in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in ... */
static void C_ccall f_4539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_4539,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_i_length(t2);
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(2)))){
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4483,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:850: chicken.compiler.support#fold-inner */
t8=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t4=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a4540 in rewrite-div in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in ... */
static void C_ccall f_4541(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4541,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4567,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:842: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4561 in k4565 in a4540 in rewrite-div in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in ... */
static void C_ccall f_4563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4563,2,av);}
t2=C_i_car(t1);
t3=C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_not(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4565 in a4540 in rewrite-div in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in ... */
static void C_ccall f_4567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4567,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:843: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in ... */
static void C_ccall f_4577(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4577,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4580,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:857: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[457];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in ... */
static void C_ccall f_4580(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_4580,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4583,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5759,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:859: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[449];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in ... */
static void C_ccall f_4583(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4583,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4586,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:877: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[427];
av2[3]=C_fix(19);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in ... */
static void C_ccall f_4586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4586,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4589,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:878: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[424];
av2[3]=C_fix(19);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in ... */
static void C_ccall f_4589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4589,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4592,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:879: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[429];
av2[3]=C_fix(19);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in ... */
static void C_ccall f_4592(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4592,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:880: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[454];
av2[3]=C_fix(19);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in ... */
static void C_ccall f_4595(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4595,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:882: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[427];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[453];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(29);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in ... */
static void C_ccall f_4598(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4598,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:883: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[424];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[452];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(29);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in ... */
static void C_ccall f_4601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4601,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:884: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[429];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[451];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(33);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in ... */
static void C_ccall f_4604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4604,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:885: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[449];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[450];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(5);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in ... */
static void C_ccall f_4607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4607,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:886: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[400];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[448];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(5);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in ... */
static void C_ccall f_4610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4610,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4613,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:887: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[446];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[447];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(5);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in ... */
static void C_ccall f_4613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4613,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4616,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:889: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[439];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[445];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in ... */
static void C_ccall f_4616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4616,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4619,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:890: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[437];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[444];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ... */
static void C_ccall f_4619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4619,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:891: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[435];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[443];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in ... */
static void C_ccall f_4622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4622,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4625,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:892: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[433];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[442];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in ... */
static void C_ccall f_4625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4625,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:893: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[431];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[441];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in ... */
static void C_ccall f_4628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4628,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:895: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[439];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[440];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in k4434 in ... */
static void C_ccall f_4631(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4631,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:896: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[437];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[438];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in k4437 in ... */
static void C_ccall f_4634(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4634,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:897: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[435];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[436];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in k4440 in ... */
static void C_ccall f_4637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4637,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:898: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[433];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[434];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 in ... */
static void C_ccall f_4640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4640,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4643,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:899: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[431];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[432];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in ... */
static void C_ccall f_4643(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4643,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:901: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[429];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[430];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in ... */
static void C_ccall f_4646(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4646,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:902: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[427];
av2[3]=C_fix(13);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[428];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in ... */
static void C_ccall f_4649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4649,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:903: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[424];
av2[3]=C_fix(13);
av2[4]=lf[425];
av2[5]=lf[426];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in ... */
static void C_ccall f_4652(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4652,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:905: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[421];
av2[3]=C_fix(13);
av2[4]=lf[422];
av2[5]=lf[423];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in ... */
static void C_ccall f_4655(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4655,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:906: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[419];
av2[3]=C_fix(13);
av2[4]=C_fix(1);
av2[5]=lf[420];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in ... */
static void C_ccall f_4658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4658,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:907: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[417];
av2[3]=C_fix(13);
av2[4]=C_fix(4);
av2[5]=lf[418];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in ... */
static void C_ccall f_4661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4661,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:908: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[415];
av2[3]=C_fix(13);
av2[4]=C_fix(1);
av2[5]=lf[416];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in ... */
static void C_ccall f_4664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4664,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:909: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[413];
av2[3]=C_fix(13);
av2[4]=C_fix(0);
av2[5]=lf[414];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in ... */
static void C_ccall f_4667(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4667,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:910: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[411];
av2[3]=C_fix(13);
av2[4]=C_fix(1);
av2[5]=lf[412];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in ... */
static void C_ccall f_4670(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4670,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4673,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:911: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[409];
av2[3]=C_fix(13);
av2[4]=C_fix(1);
av2[5]=lf[410];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in ... */
static void C_ccall f_4673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4673,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:912: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[407];
av2[3]=C_fix(13);
av2[4]=C_fix(1);
av2[5]=lf[408];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in ... */
static void C_ccall f_4676(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4676,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:914: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[398];
av2[3]=C_fix(14);
av2[4]=lf[24];
av2[5]=C_fix(1);
av2[6]=lf[405];
av2[7]=lf[406];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in ... */
static void C_ccall f_4679(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4679,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:915: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[396];
av2[3]=C_fix(14);
av2[4]=lf[24];
av2[5]=C_fix(1);
av2[6]=lf[403];
av2[7]=lf[404];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in ... */
static void C_ccall f_4682(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4682,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:916: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[400];
av2[3]=C_fix(14);
av2[4]=lf[24];
av2[5]=C_fix(2);
av2[6]=lf[401];
av2[7]=lf[402];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in ... */
static void C_ccall f_4685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4685,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4688,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:918: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[398];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[399];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in ... */
static void C_ccall f_4688(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4688,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4691,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:919: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[396];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[397];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in k4626 in ... */
static void C_ccall f_4691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4691,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:921: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[394];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[395];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in k4629 in ... */
static void C_ccall f_4694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4694,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:922: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[392];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[393];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in k4632 in ... */
static void C_ccall f_4697(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4697,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:924: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[390];
av2[3]=C_fix(15);
av2[4]=lf[388];
av2[5]=lf[24];
av2[6]=lf[391];
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in k4635 in ... */
static void C_ccall f_4700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4700,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:925: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[389];
av2[3]=C_fix(15);
av2[4]=lf[388];
av2[5]=lf[24];
av2[6]=lf[358];
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in k4638 in ... */
static void C_ccall f_4703(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4703,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:926: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[387];
av2[3]=C_fix(15);
av2[4]=lf[388];
av2[5]=lf[24];
av2[6]=lf[361];
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in k4641 in ... */
static void C_ccall f_4706(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4706,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:928: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[385];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[386];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in k4644 in ... */
static void C_ccall f_4709(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4709,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:929: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[383];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[384];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in k4647 in ... */
static void C_ccall f_4712(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4712,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:930: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[381];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[382];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in k4650 in ... */
static void C_ccall f_4715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4715,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:931: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[379];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[380];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4653 in ... */
static void C_ccall f_4718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4718,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:932: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[377];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[378];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in ... */
static void C_ccall f_4721(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4721,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4724,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:933: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[375];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[376];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in ... */
static void C_ccall f_4724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4724,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:934: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[373];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[374];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in ... */
static void C_ccall f_4727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4727,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4730,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:935: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[371];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[372];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in ... */
static void C_ccall f_4730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4730,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:936: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[369];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[370];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in k4668 in ... */
static void C_ccall f_4733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4733,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:937: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[367];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[368];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in k4671 in ... */
static void C_ccall f_4736(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4736,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:938: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[365];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[366];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in k4674 in ... */
static void C_ccall f_4739(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4739,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4742,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:939: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[363];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[364];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in k4677 in ... */
static void C_ccall f_4742(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4742,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:940: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[361];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[362];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 in ... */
static void C_ccall f_4745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4745,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:941: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[356];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[360];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in ... */
static void C_ccall f_4748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4748,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4751,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:942: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[358];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[359];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in ... */
static void C_ccall f_4751(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4751,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4754,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:943: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[356];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[357];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in ... */
static void C_ccall f_4754(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4754,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4757,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:945: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[354];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[355];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(3);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in ... */
static void C_ccall f_4757(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4757,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:946: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[352];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[353];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(3);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in ... */
static void C_ccall f_4760(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,8)))){
C_save_and_reclaim((void *)f_4760,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4763,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:947: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 9) {
  av2=av;
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[349];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[350];
av2[6]=C_SCHEME_TRUE;
av2[7]=lf[351];
av2[8]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in ... */
static void C_ccall f_4763(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4763,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:948: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[346];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[347];
av2[6]=C_SCHEME_TRUE;
av2[7]=lf[348];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in ... */
static void C_ccall f_4766(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,8)))){
C_save_and_reclaim((void *)f_4766,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4769,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:949: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 9) {
  av2=av;
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[344];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[345];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_TRUE;
av2[8]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in ... */
static void C_ccall f_4769(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4769,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4772,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:950: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[342];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[343];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in ... */
static void C_ccall f_4772(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,8)))){
C_save_and_reclaim((void *)f_4772,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4775,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:951: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 9) {
  av2=av;
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[340];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[341];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_TRUE;
av2[8]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in ... */
static void C_ccall f_4775(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4775,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:952: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[338];
av2[3]=C_fix(16);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[339];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in ... */
static void C_ccall f_4778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4778,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:953: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[336];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[337];
av2[6]=C_SCHEME_FALSE;
av2[7]=C_fix(2);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in ... */
static void C_ccall f_4781(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4781,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:954: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[334];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[335];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in ... */
static void C_ccall f_4784(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4784,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:955: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[332];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[333];
av2[6]=C_SCHEME_FALSE;
av2[7]=C_fix(2);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in ... */
static void C_ccall f_4787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4787,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4790,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:956: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[330];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[331];
av2[6]=C_SCHEME_TRUE;
av2[7]=C_fix(6);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in k4725 in ... */
static void C_ccall f_4790(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4790,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4793,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:958: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[328];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[329];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4728 in ... */
static void C_ccall f_4793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4793,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4796,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:959: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[326];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[327];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in ... */
static void C_ccall f_4796(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4796,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:960: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[324];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[325];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 in ... */
static void C_ccall f_4799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4799,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4802,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:961: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[322];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[323];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in ... */
static void C_ccall f_4802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4802,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:962: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[320];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[321];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in ... */
static void C_ccall f_4805(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4805,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:963: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[318];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[319];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in ... */
static void C_ccall f_4808(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4808,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4811,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:964: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[316];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[317];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in ... */
static void C_ccall f_4811(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4811,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4814,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:965: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[314];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[315];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in ... */
static void C_ccall f_4814(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4814,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4817,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:966: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[312];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[313];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in ... */
static void C_ccall f_4817(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4817,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4820,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:967: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[310];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[311];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in ... */
static void C_ccall f_4820(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4820,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4823,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:968: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[308];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[309];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in ... */
static void C_ccall f_4823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4823,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:969: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[306];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[307];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in ... */
static void C_ccall f_4826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4826,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4829,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:971: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[304];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[305];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in ... */
static void C_ccall f_4829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4829,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4832,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:972: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[302];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[303];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in ... */
static void C_ccall f_4832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4832,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4835,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:973: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[300];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[301];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in k4770 in ... */
static void C_ccall f_4835(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4835,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4838,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:974: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[298];
av2[3]=C_fix(16);
av2[4]=C_fix(1);
av2[5]=lf[299];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in k4773 in ... */
static void C_ccall f_4838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_4838,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5702,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:976: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[297];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in ... */
static void C_ccall f_4841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4841,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:994: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[292];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[293];
av2[6]=lf[294];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in ... */
static void C_ccall f_4844(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4844,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4847,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:995: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[289];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[290];
av2[6]=lf[291];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in ... */
static void C_ccall f_4847(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4847,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4850,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:996: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[287];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[288];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in ... */
static void C_ccall f_4850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4850,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:997: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[285];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[286];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in ... */
static void C_ccall f_4853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4853,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4856,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:998: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[282];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[283];
av2[6]=lf[284];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in ... */
static void C_ccall f_4856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4856,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:999: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[279];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[280];
av2[6]=lf[281];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in ... */
static void C_ccall f_4859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4859,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4862,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1000: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[276];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[277];
av2[6]=lf[278];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in ... */
static void C_ccall f_4862(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4862,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4865,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1001: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[273];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[274];
av2[6]=lf[275];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in ... */
static void C_ccall f_4865(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4865,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1002: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[270];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[271];
av2[6]=lf[272];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in ... */
static void C_ccall f_4868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4868,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1003: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[267];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[268];
av2[6]=lf[269];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in ... */
static void C_ccall f_4871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4871,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1004: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[265];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[266];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in ... */
static void C_ccall f_4874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_4874,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5580,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1006: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[264];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in ... */
static void C_ccall f_4877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4877,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4880,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1040: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[257];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[258];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in ... */
static void C_ccall f_4880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4880,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1041: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[255];
av2[3]=C_fix(17);
av2[4]=C_fix(3);
av2[5]=lf[256];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in ... */
static void C_ccall f_4883(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4883,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1042: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[253];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[254];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in ... */
static void C_ccall f_4886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4886,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4889,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1043: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[251];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[252];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ... */
static void C_ccall f_4889(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4889,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1044: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[249];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[250];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in ... */
static void C_ccall f_4892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4892,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4895,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1045: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[247];
av2[3]=C_fix(17);
av2[4]=C_fix(3);
av2[5]=lf[248];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in ... */
static void C_ccall f_4895(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4895,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4898,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1046: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[245];
av2[3]=C_fix(17);
av2[4]=C_fix(3);
av2[5]=lf[246];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in ... */
static void C_ccall f_4898(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4898,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1047: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[243];
av2[3]=C_fix(17);
av2[4]=C_fix(3);
av2[5]=lf[244];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in ... */
static void C_ccall f_4901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4901,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4904,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1048: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[240];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[241];
av2[6]=lf[242];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in ... */
static void C_ccall f_4904(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4904,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1049: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[238];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[239];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in ... */
static void C_ccall f_4907(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4907,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1050: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[236];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[237];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in ... */
static void C_ccall f_4910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4910,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1051: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[233];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[234];
av2[6]=lf[235];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in ... */
static void C_ccall f_4913(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4913,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4916,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1052: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[231];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[232];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in ... */
static void C_ccall f_4916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4916,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4919,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1053: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[229];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[230];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in ... */
static void C_ccall f_4919(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4919,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1054: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[227];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[228];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in ... */
static void C_ccall f_4922(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4922,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1055: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[225];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[226];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in ... */
static void C_ccall f_4925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4925,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4928,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1056: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[223];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[224];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in ... */
static void C_ccall f_4928(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4928,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1057: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[221];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[222];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in ... */
static void C_ccall f_4931(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4931,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4934,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1058: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[219];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[220];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in ... */
static void C_ccall f_4934(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4934,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4937,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1059: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[217];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[218];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in k4872 in ... */
static void C_ccall f_4937(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4937,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4940,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1060: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[215];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[216];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in k4875 in ... */
static void C_ccall f_4940(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4940,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4943,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1061: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[213];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[214];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in k4878 in ... */
static void C_ccall f_4943(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4943,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1062: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[211];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[212];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in k4881 in ... */
static void C_ccall f_4946(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_4946,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1063: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[209];
av2[3]=C_fix(17);
av2[4]=C_fix(2);
av2[5]=lf[210];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in k4884 in ... */
static void C_ccall f_4949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4949,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4952,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1065: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[207];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[208];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4887 in ... */
static void C_ccall f_4952(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4952,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1068: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[204];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[206];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in ... */
static void C_ccall f_4955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4955,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1069: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[204];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[205];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in ... */
static void C_ccall f_4958(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4958,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4961,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1070: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[201];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[203];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in ... */
static void C_ccall f_4961(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4961,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1071: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[201];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[202];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in ... */
static void C_ccall f_4964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4964,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1072: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[198];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[200];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in ... */
static void C_ccall f_4967(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4967,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1073: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[198];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[199];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in ... */
static void C_ccall f_4970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4970,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4973,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1074: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[195];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[197];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in ... */
static void C_ccall f_4973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4973,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1075: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[195];
av2[3]=C_fix(2);
av2[4]=C_fix(2);
av2[5]=lf[196];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in ... */
static void C_ccall f_4976(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4976,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1077: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[193];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[194];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in ... */
static void C_ccall f_4979(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4979,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1078: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[191];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[192];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in ... */
static void C_ccall f_4982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4982,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1080: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[188];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[190];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in ... */
static void C_ccall f_4985(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4985,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1081: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[188];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[189];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in ... */
static void C_ccall f_4988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4988,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1082: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[185];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[187];
av2[6]=C_SCHEME_FALSE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in ... */
static void C_ccall f_4991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_4991,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1083: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[185];
av2[3]=C_fix(16);
av2[4]=C_fix(2);
av2[5]=lf[186];
av2[6]=C_SCHEME_TRUE;
av2[7]=*((C_word*)lf[11]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in ... */
static void C_ccall f_4994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4994,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1085: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[182];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[184];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in ... */
static void C_ccall f_4997(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_4997,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5000,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1086: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[182];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[183];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in ... */
static void C_ccall f_5000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5000,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1087: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[179];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[181];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in ... */
static void C_ccall f_5003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5003,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5006,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1088: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[179];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[180];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in ... */
static void C_ccall f_5006(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5006,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1089: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[176];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[178];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in ... */
static void C_ccall f_5009(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5009,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1090: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[176];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[177];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in ... */
static void C_ccall f_5012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5012,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1091: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[173];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[175];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in ... */
static void C_ccall f_5015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5015,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1092: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[173];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[174];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in ... */
static void C_ccall f_5018(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5018,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1093: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[170];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[172];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in ... */
static void C_ccall f_5021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5021,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1094: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[170];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[171];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in ... */
static void C_ccall f_5024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5024,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1095: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[167];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[169];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in ... */
static void C_ccall f_5027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5027,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1096: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[167];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[168];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in ... */
static void C_ccall f_5030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5030,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1097: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[164];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[166];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in ... */
static void C_ccall f_5033(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5033,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5036,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1098: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[164];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[165];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in ... */
static void C_ccall f_5036(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5036,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5039,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1099: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[161];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[163];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in ... */
static void C_ccall f_5039(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5039,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5042,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1100: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[161];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[162];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in ... */
static void C_ccall f_5042(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5042,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5045,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1101: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[158];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[160];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in ... */
static void C_ccall f_5045(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5045,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5048,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1102: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[158];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[159];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in ... */
static void C_ccall f_5048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5048,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5051,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1103: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[155];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[157];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in ... */
static void C_ccall f_5051(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5051,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1104: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[155];
av2[3]=C_fix(2);
av2[4]=C_fix(3);
av2[5]=lf[156];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in ... */
static void C_ccall f_5054(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5054,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5057,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1106: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[152];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[154];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in ... */
static void C_ccall f_5057(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5057,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5060,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1107: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[152];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[153];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in ... */
static void C_ccall f_5060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5060,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5063,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1108: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[149];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[151];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in ... */
static void C_ccall f_5063(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5063,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5066,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1109: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[149];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[150];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in ... */
static void C_ccall f_5066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5066,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5069,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1110: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[146];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[148];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in ... */
static void C_ccall f_5069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5069,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5072,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1111: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[146];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[147];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in ... */
static void C_ccall f_5072(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5072,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1112: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[143];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[145];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in ... */
static void C_ccall f_5075(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5075,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5078,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1113: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[143];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[144];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in ... */
static void C_ccall f_5078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5078,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5081,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1114: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[140];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[142];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in ... */
static void C_ccall f_5081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5081,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5084,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1115: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[140];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[141];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in ... */
static void C_ccall f_5084(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5084,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5087,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1116: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[137];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[139];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in ... */
static void C_ccall f_5087(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5087,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5090,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1117: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[137];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[138];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in k5025 in ... */
static void C_ccall f_5090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5090,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5093,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1118: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[134];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[136];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5028 in ... */
static void C_ccall f_5093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5093,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5096,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1119: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[134];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[135];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in ... */
static void C_ccall f_5096(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5096,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5099,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1120: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[131];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[133];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in k5034 in ... */
static void C_ccall f_5099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5099,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5102,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1121: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[131];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[132];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in k5037 in ... */
static void C_ccall f_5102(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5102,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5105,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1122: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[128];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[130];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in k5040 in ... */
static void C_ccall f_5105(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5105,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5108,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1123: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[128];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[129];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in k5043 in ... */
static void C_ccall f_5108(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5108,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5111,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1124: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[125];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[127];
av2[6]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in k5046 in ... */
static void C_ccall f_5111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5111,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1125: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[125];
av2[3]=C_fix(2);
av2[4]=C_fix(1);
av2[5]=lf[126];
av2[6]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in k5049 in ... */
static void C_ccall f_5114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_5114,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5117,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1127: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[123];
av2[3]=C_fix(17);
av2[4]=C_fix(1);
av2[5]=lf[124];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in k5052 in ... */
static void C_ccall f_5117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5117,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1129: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[121];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[122];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in k5055 in ... */
static void C_ccall f_5120(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5120,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5123,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1130: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[119];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[120];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in k5058 in ... */
static void C_ccall f_5123(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5123,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5126,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1131: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[117];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[118];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in ... */
static void C_ccall f_5126(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5126,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5129,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1132: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[115];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[116];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in ... */
static void C_ccall f_5129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5129,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5132,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1133: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[113];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[114];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in ... */
static void C_ccall f_5132(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5132,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5135,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1134: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[111];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[112];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in ... */
static void C_ccall f_5135(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5135,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5138,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1135: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[109];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[110];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in ... */
static void C_ccall f_5138(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5138,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5141,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1136: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[107];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[108];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in ... */
static void C_ccall f_5141(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5141,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1137: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[105];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[106];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in ... */
static void C_ccall f_5144(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5144,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5147,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1138: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[103];
av2[3]=C_fix(7);
av2[4]=C_fix(1);
av2[5]=lf[104];
av2[6]=C_fix(1);
av2[7]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in ... */
static void C_ccall f_5147(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_5147,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5149,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5254,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:1166: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[102];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in ... */
static void C_ccall f_5149(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5149,6,av);}
a=C_alloc(6);
t6=C_i_length(t5);
if(C_truep(C_i_pairp(t5))){
t7=t5;
t8=C_i_car(t7);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5251,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1147: chicken.compiler.support#node-class */
t11=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t11;
av2[1]=t10;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t7=t1;{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k5169 in k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in ... */
static void C_ccall f_5171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5171,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5247,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1149: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5184 in k5245 in k5169 in k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in ... */
static void C_ccall f_5186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5186,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[6];
t4=C_u_i_cdr(t3);
if(C_truep(C_i_pairp(t4))){
t5=((C_word*)t0)[6];
t6=t2;{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_i_cadr(t5);
f_5189(2,av2);}}
else{
/* c-platform.scm:1154: chicken.compiler.support#make-node */
t5=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[62];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5187 in k5184 in k5245 in k5169 in k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in ... */
static void C_ccall f_5189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(41,c,3)))){
C_save_and_reclaim((void *)f_5189,2,av);}
a=C_alloc(41);
t2=t1;
t3=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5204,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5216,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=C_a_i_fixnum_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t10=C_a_i_list2(&a,2,lf[61],t9);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5224,a[2]=t8,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5226,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=((C_word*)t0)[5];
t15=t13;
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2701,a[2]=t14,a[3]=t17,a[4]=t15,tmp=(C_word)a,a+=5,tmp));
t19=((C_word*)t17)[1];
f_2701(t19,t12,C_fix(0));}

/* k5202 in k5187 in k5184 in k5245 in k5169 in k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in ... */
static void C_ccall f_5204(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5204,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:1155: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[48];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5214 in k5187 in k5184 in k5245 in k5169 in k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in ... */
static void C_ccall f_5216(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5216,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:1159: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5222 in k5187 in k5184 in k5245 in k5169 in k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in ... */
static void C_ccall f_5224(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5224,2,av);}
/* c-platform.scm:1162: chicken.compiler.support#make-node */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[28];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a5225 in k5187 in k5184 in k5245 in k5169 in k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in ... */
static void C_ccall f_5226(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5226,3,av);}
/* c-platform.scm:1165: chicken.compiler.support#varnode */
t3=*((C_word*)lf[49]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5245 in k5169 in k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in ... */
static void C_ccall f_5247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_5247,2,av);}
a=C_alloc(7);
t2=C_i_car(t1);
t3=t2;
if(C_truep(C_fixnump(t3))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:1151: scheme#<= */{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t4;
av2[2]=C_fix(0);
av2[3]=t3;
av2[4]=C_fix(32);
C_less_or_equal_p(5,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5249 in rewrite-make-vector in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in ... */
static void C_ccall f_5251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5251,2,av);}
a=C_alloc(6);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1148: chicken.base#gensym */
t4=*((C_word*)lf[50]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in ... */
static void C_ccall f_5254(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_5254,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5257,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1167: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[101];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in ... */
static void C_ccall f_5257(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,6)))){
C_save_and_reclaim((void *)f_5257,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5259,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5381,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:1189: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[45];
av2[3]=C_fix(8);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* rewrite-call/cc in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in ... */
static void C_ccall f_5259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5259,6,av);}
a=C_alloc(6);
t6=C_i_length(t5);
t7=C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=t5;
t9=C_i_car(t8);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5373,a[2]=t10,a[3]=t4,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1174: chicken.compiler.support#node-class */
t12=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t12;
av2[1]=t11;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k5276 in k5371 in rewrite-call/cc in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in ... */
static void C_ccall f_5278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_5278,2,av);}
a=C_alloc(7);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:1176: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a5294 in k5355 in k5359 in k5276 in k5371 in rewrite-call/cc in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in ... */
static void C_ccall f_5295(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_5295,5,av);}
a=C_alloc(7);
if(C_truep(C_i_nequalp(t3,C_fix(2)))){
t5=(C_truep(t4)?t4:C_i_cadr(((C_word*)t0)[2]));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:1183: chicken.compiler.support#db-get */
t8=*((C_word*)lf[56]+1);{
C_word *av2=av;
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[5];
av2[3]=t6;
av2[4]=lf[65];
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k5336 in k5340 in k5344 in k5348 in a5294 in k5355 in k5359 in k5276 in k5371 in rewrite-call/cc in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in ... */
static void C_ccall f_5338(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_5338,2,av);}
a=C_alloc(9);
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t1);
/* c-platform.scm:1186: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[5];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5340 in k5344 in k5348 in a5294 in k5355 in k5359 in k5276 in k5371 in rewrite-call/cc in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in ... */
static void C_ccall f_5342(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_5342,2,av);}
a=C_alloc(9);
if(C_truep(C_i_not(t1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1188: chicken.compiler.support#qnode */
t5=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5344 in k5348 in a5294 in k5355 in k5359 in k5276 in k5371 in rewrite-call/cc in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in ... */
static void C_ccall f_5346(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_5346,2,av);}
a=C_alloc(5);
if(C_truep(C_i_not(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:1185: chicken.compiler.support#db-get */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=lf[63];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5348 in a5294 in k5355 in k5359 in k5276 in k5371 in rewrite-call/cc in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in ... */
static void C_ccall f_5350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_5350,2,av);}
a=C_alloc(7);
if(C_truep(C_i_not(t1))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:1184: chicken.compiler.support#db-get */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=lf[64];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5355 in k5359 in k5276 in k5371 in rewrite-call/cc in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in ... */
static void C_ccall f_5357(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,5)))){
C_save_and_reclaim((void *)f_5357,2,av);}
a=C_alloc(6);
t2=C_i_caddr(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5295,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1178: ##sys#decompose-lambda-list */
t5=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[5];
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k5359 in k5276 in k5371 in rewrite-call/cc in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in ... */
static void C_ccall f_5361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5361,2,av);}
a=C_alloc(6);
t2=C_eqp(lf[47],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1177: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5367 in k5371 in rewrite-call/cc in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in ... */
static void C_ccall f_5369(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5369,2,av);}
t2=C_i_car(t1);
/* c-platform.scm:1175: chicken.compiler.support#db-get */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
av2[4]=lf[57];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5371 in rewrite-call/cc in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in ... */
static void C_ccall f_5373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_5373,2,av);}
a=C_alloc(10);
t2=C_eqp(lf[35],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5369,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:1175: chicken.compiler.support#node-parameters */
t5=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=((C_word*)t0)[5];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in ... */
static void C_ccall f_5381(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_5381,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5384,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1190: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[100];
av2[3]=C_fix(8);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in k5094 in ... */
static void C_ccall f_5384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_5384,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5515,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1218: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[99];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in ... */
static void C_ccall f_5388(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_5388,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5391,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1232: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[97];
av2[3]=C_fix(3);
av2[4]=lf[96];
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in ... */
static void C_ccall f_5391(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_5391,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1233: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[95];
av2[3]=C_fix(3);
av2[4]=lf[96];
av2[5]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in ... */
static void C_ccall f_5394(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_5394,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1234: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[94];
av2[3]=C_fix(3);
av2[4]=lf[84];
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in ... */
static void C_ccall f_5397(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_5397,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1235: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[93];
av2[3]=C_fix(3);
av2[4]=lf[81];
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in ... */
static void C_ccall f_5400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,5)))){
C_save_and_reclaim((void *)f_5400,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1236: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[91];
av2[3]=C_fix(3);
av2[4]=lf[92];
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in ... */
static void C_ccall f_5403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_5403,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5475,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1238: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[90];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in ... */
static void C_ccall f_5406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,6)))){
C_save_and_reclaim((void *)f_5406,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5435,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1250: chicken.compiler.optimizer#rewrite */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[87];
av2[3]=C_fix(8);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k5407 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in ... */
static void C_ccall f_5409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5409,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5412,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1262: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[82];
av2[3]=C_fix(23);
av2[4]=C_fix(0);
av2[5]=lf[83];
av2[6]=lf[84];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in ... */
static void C_ccall f_5412(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5412,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5415,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1263: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[79];
av2[3]=C_fix(23);
av2[4]=C_fix(1);
av2[5]=lf[80];
av2[6]=lf[81];
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in ... */
static void C_ccall f_5415(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,8)))){
C_save_and_reclaim((void *)f_5415,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1264: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 9) {
  av2=av;
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[77];
av2[3]=C_fix(23);
av2[4]=C_fix(2);
av2[5]=lf[78];
av2[6]=C_fix(0);
av2[7]=C_fix(0);
av2[8]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k5416 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in ... */
static void C_ccall f_5418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,8)))){
C_save_and_reclaim((void *)f_5418,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1265: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 9) {
  av2=av;
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[75];
av2[3]=C_fix(23);
av2[4]=C_fix(2);
av2[5]=lf[76];
av2[6]=C_fix(0);
av2[7]=C_fix(0);
av2[8]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k5419 in k5416 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in ... */
static void C_ccall f_5421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5421,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5424,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1266: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[73];
av2[3]=C_fix(23);
av2[4]=C_fix(2);
av2[5]=lf[74];
av2[6]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5422 in k5419 in k5416 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in ... */
static void C_ccall f_5424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,6)))){
C_save_and_reclaim((void *)f_5424,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5427,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1267: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[71];
av2[3]=C_fix(23);
av2[4]=C_fix(2);
av2[5]=lf[72];
av2[6]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in ... */
static void C_ccall f_5427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5427,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1269: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[69];
av2[3]=C_fix(7);
av2[4]=C_fix(2);
av2[5]=lf[70];
av2[6]=C_SCHEME_FALSE;
av2[7]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in ... */
static void C_ccall f_5430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,7)))){
C_save_and_reclaim((void *)f_5430,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1270: chicken.compiler.optimizer#rewrite */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[67];
av2[3]=C_fix(7);
av2[4]=C_fix(2);
av2[5]=lf[68];
av2[6]=C_SCHEME_FALSE;
av2[7]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in ... */
static void C_ccall f_5433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5433,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a5434 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in ... */
static void C_ccall f_5435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_5435,6,av);}
a=C_alloc(11);
t6=C_i_length(t5);
t7=C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5457,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=C_eqp(*((C_word*)lf[25]+1),lf[24]);
t12=(C_truep(t11)?C_a_i_list1(&a,1,lf[85]):C_a_i_list1(&a,1,lf[86]));
/* c-platform.scm:1257: chicken.compiler.support#make-node */
t13=*((C_word*)lf[22]+1);{
C_word *av2=av;
av2[0]=t13;
av2[1]=t10;
av2[2]=lf[27];
av2[3]=t12;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t13+1)))(5,av2);}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k5455 in a5434 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in ... */
static void C_ccall f_5457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5457,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:1254: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a5474 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in ... */
static void C_ccall f_5475(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_5475,6,av);}
a=C_alloc(11);
t6=C_i_length(t5);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5497,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=C_eqp(*((C_word*)lf[25]+1),lf[24]);
t12=(C_truep(t11)?C_a_i_list1(&a,1,lf[88]):C_a_i_list1(&a,1,lf[89]));
/* c-platform.scm:1245: chicken.compiler.support#make-node */
t13=*((C_word*)lf[22]+1);{
C_word *av2=av;
av2[0]=t13;
av2[1]=t10;
av2[2]=lf[27];
av2[3]=t12;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t13+1)))(5,av2);}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k5495 in a5474 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in ... */
static void C_ccall f_5497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5497,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:1242: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a5514 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in k5097 in ... */
static void C_ccall f_5515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5515,6,av);}
a=C_alloc(5);
t6=C_i_length(t5);
t7=C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5573,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:1224: chicken.compiler.support#node-class */
t11=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t11;
av2[1]=t10;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k5538 in k5567 in k5571 in a5514 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in ... */
static void C_ccall f_5540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_5540,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],lf[98]);
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cdr(t2);
/* c-platform.scm:1230: chicken.compiler.support#varnode */
t7=*((C_word*)lf[49]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5559 in k5538 in k5567 in k5571 in a5514 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in ... */
static void C_ccall f_5561(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5561,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:1228: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5567 in k5571 in a5514 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in ... */
static void C_ccall f_5569(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5569,2,av);}
a=C_alloc(5);
t2=C_i_car(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5540,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:1226: chicken.compiler.support#intrinsic? */
t5=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5571 in a5514 in k5382 in k5379 in k5255 in k5252 in k5145 in k5142 in k5139 in k5136 in k5133 in k5130 in k5127 in k5124 in k5121 in k5118 in k5115 in k5112 in k5109 in k5106 in k5103 in k5100 in ... */
static void C_ccall f_5573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5573,2,av);}
a=C_alloc(4);
t2=C_eqp(lf[35],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:1225: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a5579 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in ... */
static void C_ccall f_5580(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_5580,6,av);}
a=C_alloc(10);
t6=C_i_length(t5);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=t5;
t9=C_i_cadr(t8);
t10=t9;
t11=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t12=t11;
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5695,a[2]=t4,a[3]=t1,a[4]=t12,a[5]=t5,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:1022: chicken.compiler.support#node-class */
t14=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t14;
av2[1]=t13;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k5606 in k5693 in a5579 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in ... */
static void C_ccall f_5608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_5608,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t1;
t4=C_a_i_list2(&a,2,((C_word*)t0)[2],t3);
/* c-platform.scm:1019: chicken.compiler.support#make-node */
t5=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t3=C_eqp(*((C_word*)lf[25]+1),lf[24]);
if(C_truep(t3)){
/* c-platform.scm:1034: chicken.compiler.support#make-node */
t4=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[27];
av2[3]=lf[259];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=C_a_i_list2(&a,2,lf[260],C_fix(5));
/* c-platform.scm:1036: chicken.compiler.support#make-node */
t5=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[28];
av2[3]=t4;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}}

/* k5609 in k5606 in k5693 in a5579 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in ... */
static void C_ccall f_5611(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5611,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:1019: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5640 in k5689 in k5693 in a5579 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in ... */
static void C_fcall f_5642(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,0,4)))){
C_save_and_reclaim_args((void *)trf_5642,2,t0,t1);}
a=C_alloc(33);
if(C_truep(t1)){
if(C_truep(C_i_negativep(((C_word*)t0)[2]))){
t2=((C_word*)t0)[3];
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5664,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=C_s_a_i_negate(&a,1,((C_word*)t0)[2]);
/* c-platform.scm:1029: chicken.compiler.support#qnode */
t7=*((C_word*)lf[29]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_i_car(t2);
t4=C_a_i_list2(&a,2,t3,((C_word*)t0)[5]);
/* c-platform.scm:1030: chicken.compiler.support#make-node */
t5=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[27];
av2[3]=lf[262];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}
else{
t2=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_5608(2,av2);}}}

/* k5662 in k5640 in k5689 in k5693 in a5579 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ... */
static void C_ccall f_5664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5664,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:1027: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[27];
av2[3]=lf[261];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5685 in k5689 in k5693 in a5579 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in ... */
static void C_ccall f_5687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5687,2,av);}
t2=((C_word*)t0)[2];
f_5642(t2,C_i_not(t1));}

/* k5689 in k5693 in a5579 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in ... */
static void C_ccall f_5691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_5691,2,av);}
a=C_alloc(9);
t2=C_i_car(t1);
t3=t2;
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5642,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnump(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5687,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1025: chicken.compiler.support#big-fixnum? */
t6=*((C_word*)lf[263]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t4;
f_5642(t5,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_5608(2,av2);}}}

/* k5693 in a5579 in k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in ... */
static void C_ccall f_5695(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_5695,2,av);}
a=C_alloc(11);
t2=C_eqp(lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=C_eqp(*((C_word*)lf[25]+1),lf[24]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:1024: chicken.compiler.support#node-parameters */
t6=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t3;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_5608(2,av2);}}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_5608(2,av2);}}}

/* a5701 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in k4776 in ... */
static void C_ccall f_5702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_5702,6,av);}
a=C_alloc(16);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(3));
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5724,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=t5;
t12=C_i_caddr(t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5734,a[2]=t10,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5752,a[2]=t14,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:988: chicken.compiler.support#node-class */
t16=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t16;
av2[1]=t15;
av2[2]=t13;
((C_proc)(void*)(*((C_word*)t16+1)))(3,av2);}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k5722 in a5701 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in ... */
static void C_ccall f_5724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5724,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:982: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5732 in a5701 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in ... */
static void C_ccall f_5734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5734,2,av);}
if(C_truep(t1)){
/* c-platform.scm:985: chicken.compiler.support#make-node */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[27];
av2[3]=lf[295];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
/* c-platform.scm:985: chicken.compiler.support#make-node */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[27];
av2[3]=lf[296];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* k5746 in k5750 in a5701 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in ... */
static void C_ccall f_5748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5748,2,av);}
t2=C_i_car(t1);
/* c-platform.scm:989: chicken.compiler.support#immediate? */
t3=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5750 in a5701 in k4836 in k4833 in k4830 in k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4791 in k4788 in k4785 in k4782 in k4779 in ... */
static void C_ccall f_5752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5752,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:989: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_5734(2,av2);}}}

/* a5758 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in ... */
static void C_ccall f_5759(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_5759,6,av);}
a=C_alloc(16);
t6=C_eqp(lf[24],*((C_word*)lf[25]+1));
if(C_truep(t6)){
t7=C_i_length(t5);
t8=C_eqp(t7,C_fix(2));
if(C_truep(t8)){
t9=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t10=t9;
t11=t5;
t12=C_i_cadr(t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5790,a[2]=t4,a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5793,a[2]=t5,a[3]=t14,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5829,a[2]=t15,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:870: chicken.compiler.support#node-class */
t17=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t17;
av2[1]=t16;
av2[2]=t13;
((C_proc)(void*)(*((C_word*)t17+1)))(3,av2);}}
else{
t9=t1;{
C_word *av2=av;
av2[0]=t9;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t7=t1;{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k5788 in a5758 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in ... */
static void C_ccall f_5790(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5790,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:866: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5791 in a5758 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in ... */
static void C_fcall f_5793(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,4)))){
C_save_and_reclaim_args((void *)trf_5793,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5808,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:874: chicken.compiler.support#qnode */
t6=*((C_word*)lf[29]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
/* c-platform.scm:875: chicken.compiler.support#make-node */
t2=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[27];
av2[3]=lf[456];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* k5806 in k5791 in a5758 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in ... */
static void C_ccall f_5808(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5808,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:872: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[27];
av2[3]=lf[455];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5823 in k5827 in a5758 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in ... */
static void C_ccall f_5825(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5825,2,av);}
t2=C_i_car(t1);
t3=((C_word*)t0)[2];
f_5793(t3,C_eqp(C_fix(2),t2));}

/* k5827 in a5758 in k4578 in k4575 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in ... */
static void C_ccall f_5829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5829,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5825,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:871: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];
f_5793(t3,C_SCHEME_FALSE);}}

/* a5835 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in ... */
static void C_ccall f_5836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5836,6,av);}
a=C_alloc(5);
t6=C_i_nullp(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5846,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_5846(t8,t6);}
else{
t8=C_eqp(*((C_word*)lf[25]+1),lf[24]);
t9=t7;
f_5846(t9,C_i_not(t8));}}

/* k5844 in a5835 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in ... */
static void C_fcall f_5846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_5846,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[26]+1))){
/* c-platform.scm:808: chicken.compiler.support#make-node */
t6=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[27];
av2[3]=lf[458];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
/* c-platform.scm:808: chicken.compiler.support#make-node */
t6=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[27];
av2[3]=lf[459];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}
else{
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5920,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5922,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t0)[3];
t8=C_u_i_cdr(t7);
/* c-platform.scm:814: filter */
f_2293(t5,t6,t8);}}}

/* k5865 in k5844 in a5835 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in ... */
static void C_ccall f_5867(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5867,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:805: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5893 in k5918 in k5844 in a5835 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in ... */
static void C_ccall f_5895(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5895,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:820: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a5896 in k5918 in k5844 in a5835 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in ... */
static void C_ccall f_5897(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5897,4,av);}
a=C_alloc(6);
t4=(C_truep(*((C_word*)lf[26]+1))?lf[460]:lf[461]);
t5=C_a_i_list2(&a,2,t2,t3);
/* c-platform.scm:826: chicken.compiler.support#make-node */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=lf[27];
av2[3]=t4;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5918 in k5844 in a5835 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in ... */
static void C_ccall f_5920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_5920,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_i_length(t2);
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(2)))){
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5895,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5897,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:824: chicken.compiler.support#fold-inner */
t8=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t4=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a5921 in k5844 in a5835 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in ... */
static void C_ccall f_5922(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5922,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5945,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:816: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5939 in k5943 in a5921 in k5844 in a5835 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in ... */
static void C_ccall f_5941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5941,2,av);}
t2=C_i_car(t1);
t3=C_i_zerop(t2);
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_not(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5943 in a5921 in k5844 in a5835 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in ... */
static void C_ccall f_5945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5945,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5941,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:817: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a5959 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in ... */
static void C_ccall f_5960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_5960,6,av);}
a=C_alloc(5);
t6=C_i_nullp(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5970,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_5970(t8,t6);}
else{
t8=C_eqp(*((C_word*)lf[25]+1),lf[24]);
t9=t7;
f_5970(t9,C_i_not(t8));}}

/* k5968 in a5959 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in ... */
static void C_fcall f_5970(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_5970,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5991,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[26]+1))){
/* c-platform.scm:771: chicken.compiler.support#make-node */
t6=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[27];
av2[3]=lf[462];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
/* c-platform.scm:771: chicken.compiler.support#make-node */
t6=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[27];
av2[3]=lf[463];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}
else{
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6044,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6046,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t0)[3];
t8=C_u_i_cdr(t7);
/* c-platform.scm:777: filter */
f_2293(t5,t6,t8);}}}

/* k5989 in k5968 in a5959 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in ... */
static void C_ccall f_5991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_5991,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:768: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6017 in k6042 in k5968 in a5959 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in ... */
static void C_ccall f_6019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6019,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:783: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a6020 in k6042 in k5968 in a5959 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in ... */
static void C_ccall f_6021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6021,4,av);}
a=C_alloc(6);
t4=(C_truep(*((C_word*)lf[26]+1))?lf[464]:lf[465]);
t5=C_a_i_list2(&a,2,t2,t3);
/* c-platform.scm:789: chicken.compiler.support#make-node */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=lf[27];
av2[3]=t4;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k6042 in k5968 in a5959 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in ... */
static void C_ccall f_6044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_6044,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_i_length(t2);
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(2)))){
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6021,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:787: chicken.compiler.support#fold-inner */
t8=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t4=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a6045 in k5968 in a5959 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in ... */
static void C_ccall f_6046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6046,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6069,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:779: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6063 in k6067 in a6045 in k5968 in a5959 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in ... */
static void C_ccall f_6065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6065,2,av);}
t2=C_i_car(t1);
t3=C_i_zerop(t2);
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_not(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6067 in a6045 in k5968 in a5959 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in ... */
static void C_ccall f_6069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6069,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6065,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:780: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in k4371 in ... */
static void C_ccall f_6084(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6084,6,av);}
a=C_alloc(6);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6088,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6202,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:737: filter */
f_2293(t6,t7,t5);}

/* k6086 in a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in ... */
static void C_ccall f_6088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_6088,2,av);}
a=C_alloc(10);
if(C_truep(C_i_nullp(t1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:742: chicken.compiler.support#qnode */
t5=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=C_i_car(t1);
t5=C_a_i_list2(&a,2,((C_word*)t0)[2],t4);
/* c-platform.scm:744: chicken.compiler.support#make-node */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=t3;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t3=C_eqp(*((C_word*)lf[25]+1),lf[24]);
if(C_truep(t3)){
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6153,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:750: chicken.compiler.support#fold-inner */
t8=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}}

/* k6107 in k6086 in a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in ... */
static void C_ccall f_6109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6109,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:742: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6149 in k6086 in a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in ... */
static void C_ccall f_6151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6151,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:746: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a6152 in k6086 in a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in ... */
static void C_ccall f_6153(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_6153,4,av);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6160,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6196,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:752: chicken.compiler.support#node-class */
t6=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k6158 in a6152 in k6086 in a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in ... */
static void C_fcall f_6160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_6160,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:753: chicken.compiler.support#qnode */
t3=*((C_word*)lf[29]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
/* c-platform.scm:754: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[27];
av2[3]=lf[467];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k6169 in k6158 in a6152 in k6086 in a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in ... */
static void C_ccall f_6171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6171,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:753: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[27];
av2[3]=lf[466];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6190 in k6194 in a6152 in k6086 in a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in ... */
static void C_ccall f_6192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6192,2,av);}
t2=C_i_car(t1);
t3=((C_word*)t0)[2];
f_6160(t3,C_eqp(C_fix(2),t2));}

/* k6194 in a6152 in k6086 in a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in ... */
static void C_ccall f_6196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6196,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6192,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:752: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];
f_6160(t3,C_SCHEME_FALSE);}}

/* a6201 in a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in k4374 in ... */
static void C_ccall f_6202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6202,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6228,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:739: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6222 in k6226 in a6201 in a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in ... */
static void C_ccall f_6224(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6224,2,av);}
t2=C_i_car(t1);
t3=C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_not(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6226 in a6201 in a6083 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in ... */
static void C_ccall f_6228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6228,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6224,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:740: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_6230(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_6230,6,av);}
a=C_alloc(13);
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(2));
if(C_truep(t7)){
t8=t5;
t9=C_i_car(t8);
t10=t9;
t11=t5;
t12=C_i_cadr(t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6246,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t13,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6386,a[2]=t4,a[3]=t14,a[4]=t13,a[5]=t10,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:348: chicken.compiler.support#node-class */
t16=*((C_word*)lf[34]+1);{
C_word *av2=av;
av2[0]=t16;
av2[1]=t15;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t16+1)))(3,av2);}}
else{
t8=t1;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_6246(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_6246,2,av);}
a=C_alloc(15);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6273,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6340,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:352: chicken.compiler.support#node-class */
t5=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k6250 in k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_6252(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_6252,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6270,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:363: chicken.compiler.support#make-node */
t5=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[27];
av2[3]=lf[918];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* k6268 in k6250 in k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_6270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6270,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:361: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6271 in k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_fcall f_6273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_6273,2,t0,t1);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_6276(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6317,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:355: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k6274 in k6271 in k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_fcall f_6276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_6276,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:360: chicken.compiler.support#make-node */
t5=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[27];
av2[3]=lf[919];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_6252(2,av2);}}}

/* k6289 in k6274 in k6271 in k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in ... */
static void C_ccall f_6291(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6291,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:358: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6301 in k6311 in k6315 in k6271 in k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in ... */
static void C_ccall f_6303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6303,2,av);}
t2=((C_word*)t0)[2];
f_6276(t2,(C_truep(t1)?t1:C_i_symbolp(((C_word*)t0)[3])));}

/* k6311 in k6315 in k6271 in k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in ... */
static void C_ccall f_6313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6313,2,av);}
a=C_alloc(4);
t2=C_i_car(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6303,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:357: chicken.compiler.support#immediate? */
t5=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6315 in k6271 in k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_6317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6317,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:356: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];
f_6276(t3,C_SCHEME_FALSE);}}

/* k6324 in k6334 in k6338 in k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in ... */
static void C_ccall f_6326(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6326,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_6273(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_6273(t2,C_i_symbolp(((C_word*)t0)[3]));}}

/* k6334 in k6338 in k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_6336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6336,2,av);}
a=C_alloc(4);
t2=C_i_car(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6326,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:354: chicken.compiler.support#immediate? */
t5=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6338 in k6244 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_6340(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6340,2,av);}
a=C_alloc(3);
t2=C_eqp(lf[31],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:353: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];
f_6273(t3,C_SCHEME_FALSE);}}

/* k6368 in k6376 in k6372 in k6380 in k6384 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in ... */
static void C_ccall f_6370(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6370,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* c-platform.scm:351: chicken.compiler.support#make-node */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[23];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6372 in k6380 in k6384 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 in ... */
static void C_ccall f_6374(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_6374,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6378,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:350: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6376 in k6372 in k6380 in k6384 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in ... */
static void C_ccall f_6378(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_6378,2,av);}
a=C_alloc(8);
if(C_truep(C_i_equalp(((C_word*)t0)[2],t1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:351: chicken.compiler.support#qnode */
t5=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_6246(2,av2);}}}

/* k6380 in k6384 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_6382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_6382,2,av);}
a=C_alloc(5);
t2=C_eqp(lf[35],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:350: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_6246(2,av2);}}}

/* k6384 in a6229 in k3234 in k3231 in k3075 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_6386(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6386,2,av);}
a=C_alloc(6);
t2=C_eqp(lf[35],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:349: chicken.compiler.support#node-class */
t4=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_6246(2,av2);}}}

/* k6393 in k3072 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_6395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6395,2,av);}
/* c-platform.scm:313: chicken.compiler.optimizer#rewrite */
t2=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[921];
av2[3]=C_fix(8);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6397 in k3005 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_6399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6399,2,av);}
/* c-platform.scm:312: chicken.compiler.optimizer#rewrite */
t2=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[925];
av2[3]=C_fix(8);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* for-each-loop589 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_fcall f_6401(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_6401,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6411,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[929]+1);
/* c-platform.scm:284: g605 */
t6=*((C_word*)lf[929]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[930];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6409 in for-each-loop589 in k2996 in k2989 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_6411(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6411,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6401(t3,((C_word*)t0)[4],t2);}

/* map-loop551 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_fcall f_6424(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_6424,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6449,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* c-platform.scm:120: chicken.base#symbol-append */
t5=*((C_word*)lf[935]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[936];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6447 in map-loop551 in k2974 in k2971 in k2968 in k2961 in k1680 in k1677 in k1674 in k1671 in k1668 in k1665 in k1662 */
static void C_ccall f_6449(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6449,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6424(t6,((C_word*)t0)[5],t5);}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_c_2dplatform_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("c-platform"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void*)C_c_2dplatform_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(9958))){
C_save(t1);
C_rereclaim2(9958*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,944);
lf[0]=C_h_intern(&lf[0],10, C_text("c-platform"));
lf[1]=C_h_intern(&lf[1],28, C_text("chicken.compiler.c-platform#"));
lf[4]=C_h_intern(&lf[4],5, C_text("foldr"));
lf[5]=C_h_intern(&lf[5],48, C_text("chicken.compiler.c-platform#default-declarations"));
lf[6]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001always-bound\376\003\000\000\002\376\001\000\000\024\001##sys#standard-input\376\003\000\000\002\376\001\000\000\025\001##sys#stan"
"dard-output\376\003\000\000\002\376\001\000\000\024\001##sys#standard-error\376\003\000\000\002\376\001\000\000\025\001##sys#undefined-value\376\377\016\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\022\001bound-to-procedure\376\003\000\000\002\376\001\000\000\016\001##sys#for-each\376\003\000\000\002\376\001\000\000\011\001##sys#map\376\003\000\000"
"\002\376\001\000\000\013\001##sys#print\376\003\000\000\002\376\001\000\000\014\001##sys#setter\376\003\000\000\002\376\001\000\000\015\001##sys#setslot\376\003\000\000\002\376\001\000\000\022\001##sy"
"s#dynamic-wind\376\003\000\000\002\376\001\000\000\026\001##sys#call-with-values\376\003\000\000\002\376\001\000\000\021\001##sys#start-timer\376\003\000\000\002"
"\376\001\000\000\020\001##sys#stop-timer\376\003\000\000\002\376\001\000\000\011\001##sys#gcd\376\003\000\000\002\376\001\000\000\011\001##sys#lcm\376\003\000\000\002\376\001\000\000\020\001##sys#s"
"tructure\077\376\003\000\000\002\376\001\000\000\012\001##sys#slot\376\003\000\000\002\376\001\000\000\025\001##sys#allocate-vector\376\003\000\000\002\376\001\000\000\022\001##sys#l"
"ist->vector\376\003\000\000\002\376\001\000\000\017\001##sys#block-ref\376\003\000\000\002\376\001\000\000\020\001##sys#block-set!\376\003\000\000\002\376\001\000\000\012\001##sys"
"#list\376\003\000\000\002\376\001\000\000\012\001##sys#cons\376\003\000\000\002\376\001\000\000\014\001##sys#append\376\003\000\000\002\376\001\000\000\014\001##sys#vector\376\003\000\000\002\376\001\000"
"\000\033\001##sys#foreign-char-argument\376\003\000\000\002\376\001\000\000\035\001##sys#foreign-fixnum-argument\376\003\000\000\002\376\001\000\000\035"
"\001##sys#foreign-flonum-argument\376\003\000\000\002\376\001\000\000\013\001##sys#error\376\003\000\000\002\376\001\000\000\023\001##sys#peek-c-stri"
"ng\376\003\000\000\002\376\001\000\000\033\001##sys#peek-nonnull-c-string\376\003\000\000\002\376\001\000\000\034\001##sys#peek-and-free-c-string\376"
"\003\000\000\002\376\001\000\000$\001##sys#peek-and-free-nonnull-c-string\376\003\000\000\002\376\001\000\000\034\001##sys#foreign-block-arg"
"ument\376\003\000\000\002\376\001\000\000\035\001##sys#foreign-string-argument\376\003\000\000\002\376\001\000\000\036\001##sys#foreign-pointer-ar"
"gument\376\003\000\000\002\376\001\000\000$\001##sys#call-with-current-continuation\376\377\016\376\377\016"));
lf[7]=C_h_intern(&lf[7],58, C_text("chicken.compiler.c-platform#default-profiling-declarations"));
lf[8]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\001##core#declare\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001uses\376\003\000\000\002\376\001\000\000\010\001profiler\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\022\001bound-to-procedure\376\003\000\000\002\376\001\000\000\023\001##sys#profile-entry\376\003\000\000\002\376\001\000\000\022\001##sys#profile"
"-exit\376\377\016\376\377\016\376\377\016"));
lf[9]=C_h_intern(&lf[9],41, C_text("chicken.compiler.c-platform#default-units"));
lf[10]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\007\001library\376\003\000\000\002\376\001\000\000\004\001eval\376\377\016"));
lf[11]=C_h_intern(&lf[11],44, C_text("chicken.compiler.c-platform#words-per-flonum"));
lf[12]=C_h_intern(&lf[12],47, C_text("chicken.compiler.c-platform#target-include-file"));
lf[13]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011chicken.h"));
lf[14]=C_h_intern(&lf[14],50, C_text("chicken.compiler.c-platform#valid-compiler-options"));
lf[15]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\005\001-help\376\003\000\000\002\376\001\000\000\001\001h\376\003\000\000\002\376\001\000\000\004\001help\376\003\000\000\002\376\001\000\000\007\001version\376\003\000\000\002\376\001\000\000\007\001verbose\376"
"\003\000\000\002\376\001\000\000\014\001explicit-use\376\003\000\000\002\376\001\000\000\010\001no-trace\376\003\000\000\002\376\001\000\000\013\001no-warnings\376\003\000\000\002\376\001\000\000\006\001unsafe"
"\376\003\000\000\002\376\001\000\000\005\001block\376\003\000\000\002\376\001\000\000\014\001check-syntax\376\003\000\000\002\376\001\000\000\011\001to-stdout\376\003\000\000\002\376\001\000\000\025\001no-usual-i"
"ntegrations\376\003\000\000\002\376\001\000\000\020\001case-insensitive\376\003\000\000\002\376\001\000\000\016\001no-lambda-info\376\003\000\000\002\376\001\000\000\007\001profil"
"e\376\003\000\000\002\376\001\000\000\006\001inline\376\003\000\000\002\376\001\000\000\024\001keep-shadowed-macros\376\003\000\000\002\376\001\000\000\021\001ignore-repository\376\003\000"
"\000\002\376\001\000\000\021\001fixnum-arithmetic\376\003\000\000\002\376\001\000\000\022\001disable-interrupts\376\003\000\000\002\376\001\000\000\026\001optimize-leaf-r"
"outines\376\003\000\000\002\376\001\000\000\016\001compile-syntax\376\003\000\000\002\376\001\000\000\014\001tag-pointers\376\003\000\000\002\376\001\000\000\022\001accumulate-pro"
"file\376\003\000\000\002\376\001\000\000\035\001disable-stack-overflow-checks\376\003\000\000\002\376\001\000\000\003\001raw\376\003\000\000\002\376\001\000\000\012\001specialize\376"
"\003\000\000\002\376\001\000\000\036\001emit-external-prototypes-first\376\003\000\000\002\376\001\000\000\007\001release\376\003\000\000\002\376\001\000\000\005\001local\376\003\000\000\002\376"
"\001\000\000\015\001inline-global\376\003\000\000\002\376\001\000\000\014\001analyze-only\376\003\000\000\002\376\001\000\000\007\001dynamic\376\003\000\000\002\376\001\000\000\006\001static\376\003\000\000"
"\002\376\001\000\000\016\001no-argc-checks\376\003\000\000\002\376\001\000\000\023\001no-procedure-checks\376\003\000\000\002\376\001\000\000\027\001no-parentheses-syn"
"onyms\376\003\000\000\002\376\001\000\000)\001no-procedure-checks-for-toplevel-bindings\376\003\000\000\002\376\001\000\000\017\001no-bound-che"
"cks\376\003\000\000\002\376\001\000\000&\001no-procedure-checks-for-usual-bindings\376\003\000\000\002\376\001\000\000\022\001no-compiler-synta"
"x\376\003\000\000\002\376\001\000\000\027\001no-parentheses-synonyms\376\003\000\000\002\376\001\000\000\020\001no-symbol-escape\376\003\000\000\002\376\001\000\000\013\001r5rs-sy"
"ntax\376\003\000\000\002\376\001\000\000\031\001emit-all-import-libraries\376\003\000\000\002\376\001\000\000\014\001strict-types\376\003\000\000\002\376\001\000\000\012\001cluste"
"ring\376\003\000\000\002\376\001\000\000\004\001lfa2\376\003\000\000\002\376\001\000\000\012\001debug-info\376\003\000\000\002\376\001\000\000\033\001regenerate-import-libraries\376\003"
"\000\000\002\376\001\000\000\012\001setup-mode\376\003\000\000\002\376\001\000\000\026\001no-module-registration\376\377\016"));
lf[16]=C_h_intern(&lf[16],64, C_text("chicken.compiler.c-platform#valid-compiler-options-with-argument"));
lf[17]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\005\001debug\376\003\000\000\002\376\001\000\000\016\001emit-link-file\376\003\000\000\002\376\001\000\000\013\001output-file\376\003\000\000\002\376\001\000\000\014\001includ"
"e-path\376\003\000\000\002\376\001\000\000\011\001heap-size\376\003\000\000\002\376\001\000\000\012\001stack-size\376\003\000\000\002\376\001\000\000\004\001unit\376\003\000\000\002\376\001\000\000\004\001uses\376\003\000"
"\000\002\376\001\000\000\006\001module\376\003\000\000\002\376\001\000\000\015\001keyword-style\376\003\000\000\002\376\001\000\000\021\001require-extension\376\003\000\000\002\376\001\000\000\014\001inl"
"ine-limit\376\003\000\000\002\376\001\000\000\014\001profile-name\376\003\000\000\002\376\001\000\000\007\001prelude\376\003\000\000\002\376\001\000\000\010\001postlude\376\003\000\000\002\376\001\000\000\010\001"
"prologue\376\003\000\000\002\376\001\000\000\010\001epilogue\376\003\000\000\002\376\001\000\000\007\001nursery\376\003\000\000\002\376\001\000\000\006\001extend\376\003\000\000\002\376\001\000\000\007\001feature"
"\376\003\000\000\002\376\001\000\000\012\001no-feature\376\003\000\000\002\376\001\000\000\020\001emit-inline-file\376\003\000\000\002\376\001\000\000\023\001consult-inline-file\376\003"
"\000\000\002\376\001\000\000\017\001emit-types-file\376\003\000\000\002\376\001\000\000\022\001consult-types-file\376\003\000\000\002\376\001\000\000\023\001emit-import-libr"
"ary\376\377\016"));
lf[18]=C_h_intern(&lf[18],47, C_text("chicken.compiler.core#default-standard-bindings"));
lf[19]=C_h_intern(&lf[19],47, C_text("chicken.compiler.core#default-extended-bindings"));
lf[20]=C_h_intern(&lf[20],39, C_text("chicken.compiler.core#internal-bindings"));
lf[21]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\012\001##sys#slot\376\003\000\000\002\376\001\000\000\015\001##sys#setslot\376\003\000\000\002\376\001\000\000\017\001##sys#block-ref\376\003\000\000\002\376\001\000\000"
"\020\001##sys#block-set!\376\003\000\000\002\376\001\000\000\011\001##sys#/-2\376\003\000\000\002\376\001\000\000$\001##sys#call-with-current-continu"
"ation\376\003\000\000\002\376\001\000\000\012\001##sys#size\376\003\000\000\002\376\001\000\000\012\001##sys#byte\376\003\000\000\002\376\001\000\000\015\001##sys#setbyte\376\003\000\000\002\376\001\000\000"
"\016\001##sys#pointer\077\376\003\000\000\002\376\001\000\000\030\001##sys#generic-structure\077\376\003\000\000\002\376\001\000\000\020\001##sys#structure\077\376\003"
"\000\000\002\376\001\000\000\025\001##sys#check-structure\376\003\000\000\002\376\001\000\000\021\001##sys#check-exact\376\003\000\000\002\376\001\000\000\022\001##sys#check"
"-number\376\003\000\000\002\376\001\000\000\020\001##sys#check-list\376\003\000\000\002\376\001\000\000\020\001##sys#check-pair\376\003\000\000\002\376\001\000\000\022\001##sys#ch"
"eck-string\376\003\000\000\002\376\001\000\000\022\001##sys#check-symbol\376\003\000\000\002\376\001\000\000\023\001##sys#check-boolean\376\003\000\000\002\376\001\000\000\024\001"
"##sys#check-locative\376\003\000\000\002\376\001\000\000\020\001##sys#check-port\376\003\000\000\002\376\001\000\000\026\001##sys#check-input-port"
"\376\003\000\000\002\376\001\000\000\027\001##sys#check-output-port\376\003\000\000\002\376\001\000\000\025\001##sys#check-open-port\376\003\000\000\002\376\001\000\000\020\001##s"
"ys#check-char\376\003\000\000\002\376\001\000\000\022\001##sys#check-vector\376\003\000\000\002\376\001\000\000\027\001##sys#check-byte-vector\376\003\000\000"
"\002\376\001\000\000\012\001##sys#list\376\003\000\000\002\376\001\000\000\012\001##sys#cons\376\003\000\000\002\376\001\000\000\026\001##sys#call-with-values\376\003\000\000\002\376\001\000\000"
"\035\001##sys#flonum-in-fixnum-range\077\376\003\000\000\002\376\001\000\000\020\001##sys#immediate\077\376\003\000\000\002\376\001\000\000\024\001##sys#conte"
"xt-switch\376\003\000\000\002\376\001\000\000\024\001##sys#make-structure\376\003\000\000\002\376\001\000\000\013\001##sys#apply\376\003\000\000\002\376\001\000\000\022\001##sys#a"
"pply-values\376\003\000\000\002\376\001\000\000\047\001chicken.continuation#continuation-graft\376\003\000\000\002\376\001\000\000\021\001##sys#by"
"tevector\077\376\003\000\000\002\376\001\000\000\021\001##sys#make-vector\376\003\000\000\002\376\001\000\000\014\001##sys#setter\376\003\000\000\002\376\001\000\000\011\001##sys#car"
"\376\003\000\000\002\376\001\000\000\011\001##sys#cdr\376\003\000\000\002\376\001\000\000\013\001##sys#pair\077\376\003\000\000\002\376\001\000\000\011\001##sys#eq\077\376\003\000\000\002\376\001\000\000\013\001##sys#l"
"ist\077\376\003\000\000\002\376\001\000\000\015\001##sys#vector\077\376\003\000\000\002\376\001\000\000\012\001##sys#eqv\077\376\003\000\000\002\376\001\000\000\021\001##sys#get-keyword\376\003\000"
"\000\002\376\001\000\000\033\001##sys#foreign-char-argument\376\003\000\000\002\376\001\000\000\035\001##sys#foreign-fixnum-argument\376\003\000\000\002"
"\376\001\000\000\035\001##sys#foreign-flonum-argument\376\003\000\000\002\376\001\000\000\034\001##sys#foreign-block-argument\376\003\000\000\002\376"
"\001\000\000%\001##sys#foreign-struct-wrapper-argument\376\003\000\000\002\376\001\000\000\035\001##sys#foreign-string-argume"
"nt\376\003\000\000\002\376\001\000\000\036\001##sys#foreign-pointer-argument\376\003\000\000\002\376\001\000\000\012\001##sys#void\376\003\000\000\002\376\001\000\000%\001##sys"
"#foreign-ranged-integer-argument\376\003\000\000\002\376\001\000\000.\001##sys#foreign-unsigned-ranged-integer"
"-argument\376\003\000\000\002\376\001\000\000\021\001##sys#peek-fixnum\376\003\000\000\002\376\001\000\000\016\001##sys#setislot\376\003\000\000\002\376\001\000\000\022\001##sys#p"
"oke-integer\376\003\000\000\002\376\001\000\000\020\001##sys#permanent\077\376\003\000\000\002\376\001\000\000\014\001##sys#values\376\003\000\000\002\376\001\000\000\021\001##sys#po"
"ke-double\376\003\000\000\002\376\001\000\000\023\001##sys#intern-symbol\376\003\000\000\002\376\001\000\000\023\001##sys#null-pointer\077\376\003\000\000\002\376\001\000\000\017\001"
"##sys#peek-byte\376\003\000\000\002\376\001\000\000\022\001##sys#file-exists\077\376\003\000\000\002\376\001\000\000\025\001##sys#substring-index\376\003\000\000"
"\002\376\001\000\000\030\001##sys#substring-index-ci\376\003\000\000\002\376\001\000\000\011\001##sys#lcm\376\003\000\000\002\376\001\000\000\011\001##sys#gcd\376\377\016"));
lf[22]=C_h_intern(&lf[22],34, C_text("chicken.compiler.support#make-node"));
lf[23]=C_h_intern(&lf[23],11, C_text("##core#call"));
lf[24]=C_h_intern(&lf[24],6, C_text("fixnum"));
lf[25]=C_h_intern(&lf[25],36, C_text("chicken.compiler.support#number-type"));
lf[26]=C_h_intern(&lf[26],31, C_text("chicken.compiler.support#unsafe"));
lf[27]=C_h_intern(&lf[27],13, C_text("##core#inline"));
lf[28]=C_h_intern(&lf[28],22, C_text("##core#inline_allocate"));
lf[29]=C_h_intern(&lf[29],30, C_text("chicken.compiler.support#qnode"));
lf[30]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\005C_eqp\376\377\016"));
lf[31]=C_h_intern(&lf[31],5, C_text("quote"));
lf[32]=C_h_intern(&lf[32],35, C_text("chicken.compiler.support#immediate\077"));
lf[33]=C_h_intern(&lf[33],40, C_text("chicken.compiler.support#node-parameters"));
lf[34]=C_h_intern(&lf[34],35, C_text("chicken.compiler.support#node-class"));
lf[35]=C_h_intern(&lf[35],15, C_text("##core#variable"));
lf[36]=C_h_intern(&lf[36],3, C_text("map"));
lf[37]=C_h_intern(&lf[37],13, C_text("scheme#append"));
lf[38]=C_h_intern(&lf[38],20, C_text("chicken.base#butlast"));
lf[39]=C_h_intern(&lf[39],11, C_text("##core#proc"));
lf[40]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\007C_apply\376\003\000\000\002\376\377\006\001\376\377\016"));
lf[41]=C_h_intern(&lf[41],6, C_text("values"));
lf[42]=C_h_intern(&lf[42],12, C_text("##sys#values"));
lf[43]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\016C_apply_values\376\003\000\000\002\376\377\006\001\376\377\016"));
lf[44]=C_h_intern(&lf[44],35, C_text("chicken.compiler.support#intrinsic\077"));
lf[45]=C_h_intern(&lf[45],37, C_text("scheme#call-with-current-continuation"));
lf[46]=C_h_intern(&lf[46],34, C_text("chicken.compiler.optimizer#rewrite"));
lf[47]=C_h_intern(&lf[47],13, C_text("##core#lambda"));
lf[48]=C_h_intern(&lf[48],3, C_text("let"));
lf[49]=C_h_intern(&lf[49],32, C_text("chicken.compiler.support#varnode"));
lf[50]=C_h_intern(&lf[50],19, C_text("chicken.base#gensym"));
lf[51]=C_h_intern(&lf[51],2, C_text("f_"));
lf[52]=C_h_intern(&lf[52],34, C_text("chicken.compiler.support#debugging"));
lf[53]=C_h_intern(&lf[53],1, C_text("o"));
lf[54]=C_decode_literal(C_heaptop,C_text("\376B\000\000)removing single-valued `call-with-values\047"));
lf[55]=C_h_intern(&lf[55],1, C_text("r"));
lf[56]=C_h_intern(&lf[56],31, C_text("chicken.compiler.support#db-get"));
lf[57]=C_h_intern(&lf[57],5, C_text("value"));
lf[58]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\024C_fixnum_shift_right\376\377\016"));
lf[59]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\017C_fixnum_divide\376\377\016"));
lf[60]=C_h_intern(&lf[60],35, C_text("chicken.compiler.support#fold-inner"));
lf[61]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_a_i_vector"));
lf[62]=C_h_intern(&lf[62],16, C_text("##core#undefined"));
lf[63]=C_h_intern(&lf[63],16, C_text("inline-transient"));
lf[64]=C_h_intern(&lf[64],8, C_text("assigned"));
lf[65]=C_h_intern(&lf[65],10, C_text("references"));
lf[66]=C_h_intern(&lf[66],27, C_text("##sys#decompose-lambda-list"));
lf[67]=C_h_intern(&lf[67],17, C_text("##sys#get-keyword"));
lf[68]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_i_get_keyword"));
lf[69]=C_h_intern(&lf[69],27, C_text("chicken.keyword#get-keyword"));
lf[70]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_i_get_keyword"));
lf[71]=C_h_intern(&lf[71],33, C_text("chicken.string#substring-index-ci"));
lf[72]=C_h_intern(&lf[72],24, C_text("##sys#substring-index-ci"));
lf[73]=C_h_intern(&lf[73],30, C_text("chicken.string#substring-index"));
lf[74]=C_h_intern(&lf[74],21, C_text("##sys#substring-index"));
lf[75]=C_h_intern(&lf[75],29, C_text("chicken.string#substring-ci=\077"));
lf[76]=C_h_intern(&lf[76],20, C_text("##sys#substring-ci=\077"));
lf[77]=C_h_intern(&lf[77],26, C_text("chicken.string#substring=\077"));
lf[78]=C_h_intern(&lf[78],17, C_text("##sys#substring=\077"));
lf[79]=C_h_intern(&lf[79],17, C_text("scheme#write-char"));
lf[80]=C_h_intern(&lf[80],21, C_text("##sys#write-char/port"));
lf[81]=C_h_intern(&lf[81],21, C_text("##sys#standard-output"));
lf[82]=C_h_intern(&lf[82],16, C_text("scheme#read-char"));
lf[83]=C_h_intern(&lf[83],20, C_text("##sys#read-char/port"));
lf[84]=C_h_intern(&lf[84],20, C_text("##sys#standard-input"));
lf[85]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_fixnum_length"));
lf[86]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_integer_length"));
lf[87]=C_h_intern(&lf[87],30, C_text("chicken.bitwise#integer-length"));
lf[88]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_u_i_bit_to_bool"));
lf[89]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_i_bit_to_bool"));
lf[90]=C_h_intern(&lf[90],28, C_text("chicken.bitwise#bit->boolean"));
lf[91]=C_h_intern(&lf[91],31, C_text("chicken.base#current-error-port"));
lf[92]=C_h_intern(&lf[92],20, C_text("##sys#standard-error"));
lf[93]=C_h_intern(&lf[93],26, C_text("scheme#current-output-port"));
lf[94]=C_h_intern(&lf[94],25, C_text("scheme#current-input-port"));
lf[95]=C_h_intern(&lf[95],10, C_text("##sys#void"));
lf[96]=C_h_intern(&lf[96],21, C_text("##sys#undefined-value"));
lf[97]=C_h_intern(&lf[97],17, C_text("chicken.base#void"));
lf[98]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\001scheme#car\376\001\000\000\017\001scheme#set-car!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\001scheme#cdr\376\001\000\000\017\001s"
"cheme#set-cdr!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021\001scheme#string-ref\376\001\000\000\022\001scheme#string-set!\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\021\001scheme#vector-ref\376\001\000\000\022\001scheme#vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\023\001srfi-4#u8vector-"
"ref\376\001\000\000\024\001srfi-4#u8vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\023\001srfi-4#s8vector-ref\376\001\000\000\024\001srfi-4#s8v"
"ector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024\001srfi-4#u16vector-ref\376\001\000\000\025\001srfi-4#u16vector-set!\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\024\001srfi-4#s16vector-ref\376\001\000\000\025\001srfi-4#s16vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024\001srfi-4#u"
"32vector-ref\376\001\000\000\025\001srfi-4#u32vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024\001srfi-4#s32vector-ref\376\001\000\000\025"
"\001srfi-4#s32vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024\001srfi-4#u64vector-ref\376\001\000\000\025\001srfi-4#u64vector"
"-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024\001srfi-4#s64vector-ref\376\001\000\000\025\001srfi-4#s64vector-set!\376\003\000\000\002\376\003\000\000\002\376\001"
"\000\000\024\001srfi-4#f32vector-ref\376\001\000\000\025\001srfi-4#f32vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024\001srfi-4#f64vec"
"tor-ref\376\001\000\000\025\001srfi-4#f64vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\035\001chicken.locative#locative-ref\376"
"\001\000\000\036\001chicken.locative#locative-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\035\001chicken.memory#pointer-u8-ref"
"\376\001\000\000\036\001chicken.memory#pointer-u8-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\035\001chicken.memory#pointer-s8-re"
"f\376\001\000\000\036\001chicken.memory#pointer-s8-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\036\001chicken.memory#pointer-u16-"
"ref\376\001\000\000\037\001chicken.memory#pointer-u16-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\036\001chicken.memory#pointer-s"
"16-ref\376\001\000\000\037\001chicken.memory#pointer-s16-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\036\001chicken.memory#pointe"
"r-u32-ref\376\001\000\000\037\001chicken.memory#pointer-u32-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\036\001chicken.memory#poi"
"nter-s32-ref\376\001\000\000\037\001chicken.memory#pointer-s32-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\036\001chicken.memory#"
"pointer-f32-ref\376\001\000\000\037\001chicken.memory#pointer-f32-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\036\001chicken.memo"
"ry#pointer-f64-ref\376\001\000\000\037\001chicken.memory#pointer-f64-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\047\001chicken.m"
"emory.representation#block-ref\376\001\000\000(\001chicken.memory.representation#block-set!\376\377\016"));
lf[99]=C_h_intern(&lf[99],12, C_text("##sys#setter"));
lf[100]=C_h_intern(&lf[100],20, C_text("chicken.base#call/cc"));
lf[101]=C_h_intern(&lf[101],17, C_text("##sys#make-vector"));
lf[102]=C_h_intern(&lf[102],18, C_text("scheme#make-vector"));
lf[103]=C_h_intern(&lf[103],29, C_text("srfi-4#f64vector->blob/shared"));
lf[104]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[105]=C_h_intern(&lf[105],29, C_text("srfi-4#f32vector->blob/shared"));
lf[106]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[107]=C_h_intern(&lf[107],29, C_text("srfi-4#s64vector->blob/shared"));
lf[108]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[109]=C_h_intern(&lf[109],29, C_text("srfi-4#u64vector->blob/shared"));
lf[110]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[111]=C_h_intern(&lf[111],29, C_text("srfi-4#s32vector->blob/shared"));
lf[112]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[113]=C_h_intern(&lf[113],29, C_text("srfi-4#u32vector->blob/shared"));
lf[114]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[115]=C_h_intern(&lf[115],29, C_text("srfi-4#s16vector->blob/shared"));
lf[116]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[117]=C_h_intern(&lf[117],29, C_text("srfi-4#u16vector->blob/shared"));
lf[118]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[119]=C_h_intern(&lf[119],28, C_text("srfi-4#s8vector->blob/shared"));
lf[120]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[121]=C_h_intern(&lf[121],28, C_text("srfi-4#u8vector->blob/shared"));
lf[122]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[123]=C_h_intern(&lf[123],18, C_text("chicken.base#atom\077"));
lf[124]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_not_pair_p"));
lf[125]=C_h_intern(&lf[125],23, C_text("srfi-4#f64vector-length"));
lf[126]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_i_f64vector_length"));
lf[127]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_f64vector_length"));
lf[128]=C_h_intern(&lf[128],23, C_text("srfi-4#f32vector-length"));
lf[129]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_i_f32vector_length"));
lf[130]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_f32vector_length"));
lf[131]=C_h_intern(&lf[131],23, C_text("srfi-4#s64vector-length"));
lf[132]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_i_s64vector_length"));
lf[133]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_s64vector_length"));
lf[134]=C_h_intern(&lf[134],23, C_text("srfi-4#u64vector-length"));
lf[135]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_i_u64vector_length"));
lf[136]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_u64vector_length"));
lf[137]=C_h_intern(&lf[137],23, C_text("srfi-4#s32vector-length"));
lf[138]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_i_s32vector_length"));
lf[139]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_s32vector_length"));
lf[140]=C_h_intern(&lf[140],23, C_text("srfi-4#u32vector-length"));
lf[141]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_i_u32vector_length"));
lf[142]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_u32vector_length"));
lf[143]=C_h_intern(&lf[143],23, C_text("srfi-4#s16vector-length"));
lf[144]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_i_s16vector_length"));
lf[145]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_s16vector_length"));
lf[146]=C_h_intern(&lf[146],23, C_text("srfi-4#u16vector-length"));
lf[147]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_i_u16vector_length"));
lf[148]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_u16vector_length"));
lf[149]=C_h_intern(&lf[149],22, C_text("srfi-4#s8vector-length"));
lf[150]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_i_s8vector_length"));
lf[151]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_u_i_s8vector_length"));
lf[152]=C_h_intern(&lf[152],22, C_text("srfi-4#u8vector-length"));
lf[153]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_i_u8vector_length"));
lf[154]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_u_i_u8vector_length"));
lf[155]=C_h_intern(&lf[155],21, C_text("srfi-4#f64vector-set!"));
lf[156]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_f64vector_set"));
lf[157]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_f64vector_set"));
lf[158]=C_h_intern(&lf[158],21, C_text("srfi-4#f32vector-set!"));
lf[159]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_f32vector_set"));
lf[160]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_f32vector_set"));
lf[161]=C_h_intern(&lf[161],21, C_text("srfi-4#s64vector-set!"));
lf[162]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_s64vector_set"));
lf[163]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_s64vector_set"));
lf[164]=C_h_intern(&lf[164],21, C_text("srfi-4#u64vector-set!"));
lf[165]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_u64vector_set"));
lf[166]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_u64vector_set"));
lf[167]=C_h_intern(&lf[167],21, C_text("srfi-4#s32vector-set!"));
lf[168]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_s32vector_set"));
lf[169]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_s32vector_set"));
lf[170]=C_h_intern(&lf[170],21, C_text("srfi-4#u32vector-set!"));
lf[171]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_u32vector_set"));
lf[172]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_u32vector_set"));
lf[173]=C_h_intern(&lf[173],21, C_text("srfi-4#s16vector-set!"));
lf[174]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_s16vector_set"));
lf[175]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_s16vector_set"));
lf[176]=C_h_intern(&lf[176],21, C_text("srfi-4#u16vector-set!"));
lf[177]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_u16vector_set"));
lf[178]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_u16vector_set"));
lf[179]=C_h_intern(&lf[179],20, C_text("srfi-4#s8vector-set!"));
lf[180]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_s8vector_set"));
lf[181]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_u_i_s8vector_set"));
lf[182]=C_h_intern(&lf[182],20, C_text("srfi-4#u8vector-set!"));
lf[183]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_u8vector_set"));
lf[184]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_u_i_u8vector_set"));
lf[185]=C_h_intern(&lf[185],20, C_text("srfi-4#f64vector-ref"));
lf[186]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_a_i_f64vector_ref"));
lf[187]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_a_u_i_f64vector_ref"));
lf[188]=C_h_intern(&lf[188],20, C_text("srfi-4#f32vector-ref"));
lf[189]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_a_i_f32vector_ref"));
lf[190]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_a_u_i_f32vector_ref"));
lf[191]=C_h_intern(&lf[191],20, C_text("srfi-4#s32vector-ref"));
lf[192]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_a_i_s32vector_ref"));
lf[193]=C_h_intern(&lf[193],20, C_text("srfi-4#u32vector-ref"));
lf[194]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_a_i_u32vector_ref"));
lf[195]=C_h_intern(&lf[195],20, C_text("srfi-4#s16vector-ref"));
lf[196]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_s16vector_ref"));
lf[197]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_s16vector_ref"));
lf[198]=C_h_intern(&lf[198],20, C_text("srfi-4#u16vector-ref"));
lf[199]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_u16vector_ref"));
lf[200]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_u16vector_ref"));
lf[201]=C_h_intern(&lf[201],19, C_text("srfi-4#s8vector-ref"));
lf[202]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_s8vector_ref"));
lf[203]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_u_i_s8vector_ref"));
lf[204]=C_h_intern(&lf[204],19, C_text("srfi-4#u8vector-ref"));
lf[205]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_u8vector_ref"));
lf[206]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_u_i_u8vector_ref"));
lf[207]=C_h_intern(&lf[207],22, C_text("chicken.blob#blob-size"));
lf[208]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_block_size"));
lf[209]=C_h_intern(&lf[209],46, C_text("##sys#foreign-unsigned-ranged-integer-argument"));
lf[210]=C_decode_literal(C_heaptop,C_text("\376B\000\000-C_i_foreign_unsigned_ranged_integer_argumentp"));
lf[211]=C_h_intern(&lf[211],37, C_text("##sys#foreign-ranged-integer-argument"));
lf[212]=C_decode_literal(C_heaptop,C_text("\376B\000\000$C_i_foreign_ranged_integer_argumentp"));
lf[213]=C_h_intern(&lf[213],30, C_text("##sys#foreign-pointer-argument"));
lf[214]=C_decode_literal(C_heaptop,C_text("\376B\000\000\035C_i_foreign_pointer_argumentp"));
lf[215]=C_h_intern(&lf[215],29, C_text("##sys#foreign-string-argument"));
lf[216]=C_decode_literal(C_heaptop,C_text("\376B\000\000\034C_i_foreign_string_argumentp"));
lf[217]=C_h_intern(&lf[217],37, C_text("##sys#foreign-struct-wrapper-argument"));
lf[218]=C_decode_literal(C_heaptop,C_text("\376B\000\000$C_i_foreign_struct_wrapper_argumentp"));
lf[219]=C_h_intern(&lf[219],28, C_text("##sys#foreign-block-argument"));
lf[220]=C_decode_literal(C_heaptop,C_text("\376B\000\000\033C_i_foreign_block_argumentp"));
lf[221]=C_h_intern(&lf[221],29, C_text("##sys#foreign-flonum-argument"));
lf[222]=C_decode_literal(C_heaptop,C_text("\376B\000\000\034C_i_foreign_flonum_argumentp"));
lf[223]=C_h_intern(&lf[223],27, C_text("##sys#foreign-char-argument"));
lf[224]=C_decode_literal(C_heaptop,C_text("\376B\000\000\032C_i_foreign_char_argumentp"));
lf[225]=C_h_intern(&lf[225],29, C_text("##sys#foreign-fixnum-argument"));
lf[226]=C_decode_literal(C_heaptop,C_text("\376B\000\000\034C_i_foreign_fixnum_argumentp"));
lf[227]=C_h_intern(&lf[227],30, C_text("chicken.locative#locative-set!"));
lf[228]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_locative_set"));
lf[229]=C_h_intern(&lf[229],33, C_text("chicken.locative#locative->object"));
lf[230]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_i_locative_to_object"));
lf[231]=C_h_intern(&lf[231],16, C_text("##sys#immediate\077"));
lf[232]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_immp"));
lf[233]=C_h_intern(&lf[233],19, C_text("##sys#null-pointer\077"));
lf[234]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_null_pointerp"));
lf[235]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_null_pointerp"));
lf[236]=C_h_intern(&lf[236],16, C_text("##sys#permanent\077"));
lf[237]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_permanentp"));
lf[238]=C_h_intern(&lf[238],18, C_text("scheme#string-ci=\077"));
lf[239]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_i_string_ci_equal_p"));
lf[240]=C_h_intern(&lf[240],15, C_text("scheme#string=\077"));
lf[241]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_string_equal_p"));
lf[242]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_u_i_string_equal_p"));
lf[243]=C_h_intern(&lf[243],17, C_text("##sys#poke-double"));
lf[244]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_poke_double"));
lf[245]=C_h_intern(&lf[245],18, C_text("##sys#poke-integer"));
lf[246]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_poke_integer"));
lf[247]=C_h_intern(&lf[247],14, C_text("##sys#setislot"));
lf[248]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_set_i_slot"));
lf[249]=C_h_intern(&lf[249],30, C_text("chicken.memory#pointer->object"));
lf[250]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_pointer_to_object"));
lf[251]=C_h_intern(&lf[251],15, C_text("##sys#peek-byte"));
lf[252]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_peek_byte"));
lf[253]=C_h_intern(&lf[253],17, C_text("##sys#peek-fixnum"));
lf[254]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_peek_fixnum"));
lf[255]=C_h_intern(&lf[255],13, C_text("##sys#setbyte"));
lf[256]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_setbyte"));
lf[257]=C_h_intern(&lf[257],10, C_text("##sys#byte"));
lf[258]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_subbyte"));
lf[259]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\033C_i_fixnum_arithmetic_shift\376\377\016"));
lf[260]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030C_s_a_i_arithmetic_shift"));
lf[261]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\024C_fixnum_shift_right\376\377\016"));
lf[262]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\023C_fixnum_shift_left\376\377\016"));
lf[263]=C_h_intern(&lf[263],36, C_text("chicken.compiler.support#big-fixnum\077"));
lf[264]=C_h_intern(&lf[264],32, C_text("chicken.bitwise#arithmetic-shift"));
lf[265]=C_h_intern(&lf[265],20, C_text("chicken.fixnum#fxrem"));
lf[266]=C_decode_literal(C_heaptop,C_text("\376B\000\000\034C_i_fixnum_remainder_checked"));
lf[267]=C_h_intern(&lf[267],20, C_text("chicken.fixnum#fxmod"));
lf[268]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_fixnum_modulo"));
lf[269]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_u_fixnum_modulo"));
lf[270]=C_h_intern(&lf[270],18, C_text("chicken.fixnum#fx/"));
lf[271]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_fixnum_divide"));
lf[272]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_u_fixnum_divide"));
lf[273]=C_h_intern(&lf[273],20, C_text("chicken.fixnum#fxior"));
lf[274]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_fixnum_or"));
lf[275]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_u_fixnum_or"));
lf[276]=C_h_intern(&lf[276],20, C_text("chicken.fixnum#fxand"));
lf[277]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_fixnum_and"));
lf[278]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_u_fixnum_and"));
lf[279]=C_h_intern(&lf[279],20, C_text("chicken.fixnum#fxxor"));
lf[280]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_fixnum_xor"));
lf[281]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_fixnum_xor"));
lf[282]=C_h_intern(&lf[282],20, C_text("chicken.fixnum#fxneg"));
lf[283]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_fixnum_negate"));
lf[284]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_u_fixnum_negate"));
lf[285]=C_h_intern(&lf[285],20, C_text("chicken.fixnum#fxshr"));
lf[286]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_fixnum_shift_right"));
lf[287]=C_h_intern(&lf[287],20, C_text("chicken.fixnum#fxshl"));
lf[288]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_fixnum_shift_left"));
lf[289]=C_h_intern(&lf[289],18, C_text("chicken.fixnum#fx-"));
lf[290]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_fixnum_difference"));
lf[291]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_u_fixnum_difference"));
lf[292]=C_h_intern(&lf[292],18, C_text("chicken.fixnum#fx+"));
lf[293]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_fixnum_plus"));
lf[294]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_u_fixnum_plus"));
lf[295]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\016C_i_set_i_slot\376\377\016"));
lf[296]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\013C_i_setslot\376\377\016"));
lf[297]=C_h_intern(&lf[297],13, C_text("##sys#setslot"));
lf[298]=C_h_intern(&lf[298],30, C_text("chicken.memory#pointer-f64-ref"));
lf[299]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027C_a_u_i_pointer_f64_ref"));
lf[300]=C_h_intern(&lf[300],30, C_text("chicken.memory#pointer-f32-ref"));
lf[301]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027C_a_u_i_pointer_f32_ref"));
lf[302]=C_h_intern(&lf[302],30, C_text("chicken.memory#pointer-s32-ref"));
lf[303]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027C_a_u_i_pointer_s32_ref"));
lf[304]=C_h_intern(&lf[304],30, C_text("chicken.memory#pointer-u32-ref"));
lf[305]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027C_a_u_i_pointer_u32_ref"));
lf[306]=C_h_intern(&lf[306],31, C_text("chicken.memory#pointer-f64-set!"));
lf[307]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_u_i_pointer_f64_set"));
lf[308]=C_h_intern(&lf[308],31, C_text("chicken.memory#pointer-f32-set!"));
lf[309]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_u_i_pointer_f32_set"));
lf[310]=C_h_intern(&lf[310],31, C_text("chicken.memory#pointer-s32-set!"));
lf[311]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_u_i_pointer_s32_set"));
lf[312]=C_h_intern(&lf[312],31, C_text("chicken.memory#pointer-u32-set!"));
lf[313]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_u_i_pointer_u32_set"));
lf[314]=C_h_intern(&lf[314],31, C_text("chicken.memory#pointer-s16-set!"));
lf[315]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_u_i_pointer_s16_set"));
lf[316]=C_h_intern(&lf[316],31, C_text("chicken.memory#pointer-u16-set!"));
lf[317]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_u_i_pointer_u16_set"));
lf[318]=C_h_intern(&lf[318],30, C_text("chicken.memory#pointer-s8-set!"));
lf[319]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_u_i_pointer_s8_set"));
lf[320]=C_h_intern(&lf[320],30, C_text("chicken.memory#pointer-u8-set!"));
lf[321]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_u_i_pointer_u8_set"));
lf[322]=C_h_intern(&lf[322],30, C_text("chicken.memory#pointer-s16-ref"));
lf[323]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_u_i_pointer_s16_ref"));
lf[324]=C_h_intern(&lf[324],30, C_text("chicken.memory#pointer-u16-ref"));
lf[325]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_u_i_pointer_u16_ref"));
lf[326]=C_h_intern(&lf[326],29, C_text("chicken.memory#pointer-s8-ref"));
lf[327]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_u_i_pointer_s8_ref"));
lf[328]=C_h_intern(&lf[328],29, C_text("chicken.memory#pointer-u8-ref"));
lf[329]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_u_i_pointer_u8_ref"));
lf[330]=C_h_intern(&lf[330],29, C_text("chicken.locative#locative-ref"));
lf[331]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_a_i_locative_ref"));
lf[332]=C_h_intern(&lf[332],23, C_text("chicken.memory#pointer+"));
lf[333]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_a_u_i_pointer_inc"));
lf[334]=C_h_intern(&lf[334],31, C_text("chicken.memory#pointer->address"));
lf[335]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030C_a_i_pointer_to_address"));
lf[336]=C_h_intern(&lf[336],31, C_text("chicken.memory#address->pointer"));
lf[337]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030C_a_i_address_to_pointer"));
lf[338]=C_h_intern(&lf[338],13, C_text("scheme#string"));
lf[339]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_a_i_string"));
lf[340]=C_h_intern(&lf[340],20, C_text("##sys#make-structure"));
lf[341]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_a_i_record"));
lf[342]=C_h_intern(&lf[342],12, C_text("##sys#vector"));
lf[343]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_a_i_vector"));
lf[344]=C_h_intern(&lf[344],13, C_text("scheme#vector"));
lf[345]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_a_i_vector"));
lf[346]=C_h_intern(&lf[346],10, C_text("##sys#list"));
lf[347]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_a_i_list"));
lf[348]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016"));
lf[349]=C_h_intern(&lf[349],11, C_text("scheme#list"));
lf[350]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_a_i_list"));
lf[351]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016"));
lf[352]=C_h_intern(&lf[352],10, C_text("##sys#cons"));
lf[353]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_a_i_cons"));
lf[354]=C_h_intern(&lf[354],11, C_text("scheme#cons"));
lf[355]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_a_i_cons"));
lf[356]=C_h_intern(&lf[356],22, C_text("chicken.flonum#fpround"));
lf[357]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_a_i_flonum_floor"));
lf[358]=C_h_intern(&lf[358],24, C_text("chicken.flonum#fpceiling"));
lf[359]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_a_i_flonum_ceiling"));
lf[360]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_a_i_flonum_round"));
lf[361]=C_h_intern(&lf[361],25, C_text("chicken.flonum#fptruncate"));
lf[362]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_a_i_flonum_truncate"));
lf[363]=C_h_intern(&lf[363],20, C_text("chicken.flonum#fpabs"));
lf[364]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_a_i_flonum_abs"));
lf[365]=C_h_intern(&lf[365],21, C_text("chicken.flonum#fpsqrt"));
lf[366]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_a_i_flonum_sqrt"));
lf[367]=C_h_intern(&lf[367],20, C_text("chicken.flonum#fplog"));
lf[368]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_a_i_flonum_log"));
lf[369]=C_h_intern(&lf[369],21, C_text("chicken.flonum#fpexpt"));
lf[370]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_a_i_flonum_expt"));
lf[371]=C_h_intern(&lf[371],20, C_text("chicken.flonum#fpexp"));
lf[372]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_a_i_flonum_exp"));
lf[373]=C_h_intern(&lf[373],22, C_text("chicken.flonum#fpatan2"));
lf[374]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_a_i_flonum_atan2"));
lf[375]=C_h_intern(&lf[375],21, C_text("chicken.flonum#fpatan"));
lf[376]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_a_i_flonum_atan"));
lf[377]=C_h_intern(&lf[377],21, C_text("chicken.flonum#fpacos"));
lf[378]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_a_i_flonum_acos"));
lf[379]=C_h_intern(&lf[379],21, C_text("chicken.flonum#fpasin"));
lf[380]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_a_i_flonum_asin"));
lf[381]=C_h_intern(&lf[381],20, C_text("chicken.flonum#fptan"));
lf[382]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_a_i_flonum_tan"));
lf[383]=C_h_intern(&lf[383],20, C_text("chicken.flonum#fpcos"));
lf[384]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_a_i_flonum_cos"));
lf[385]=C_h_intern(&lf[385],20, C_text("chicken.flonum#fpsin"));
lf[386]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_a_i_flonum_sin"));
lf[387]=C_h_intern(&lf[387],15, C_text("scheme#truncate"));
lf[388]=C_h_intern(&lf[388],6, C_text("flonum"));
lf[389]=C_h_intern(&lf[389],14, C_text("scheme#ceiling"));
lf[390]=C_h_intern(&lf[390],12, C_text("scheme#floor"));
lf[391]=C_h_intern(&lf[391],22, C_text("chicken.flonum#fpfloor"));
lf[392]=C_h_intern(&lf[392],22, C_text("chicken.fixnum#fxeven\077"));
lf[393]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_i_fixnumevenp"));
lf[394]=C_h_intern(&lf[394],21, C_text("chicken.fixnum#fxodd\077"));
lf[395]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_fixnumoddp"));
lf[396]=C_h_intern(&lf[396],11, C_text("scheme#odd\077"));
lf[397]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_oddp"));
lf[398]=C_h_intern(&lf[398],12, C_text("scheme#even\077"));
lf[399]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_evenp"));
lf[400]=C_h_intern(&lf[400],16, C_text("scheme#remainder"));
lf[401]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_fixnum_modulo"));
lf[402]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_fixnum_modulo"));
lf[403]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_fixnumoddp"));
lf[404]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_fixnumoddp"));
lf[405]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_i_fixnumevenp"));
lf[406]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_i_fixnumevenp"));
lf[407]=C_h_intern(&lf[407],17, C_text("##sys#make-symbol"));
lf[408]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_make_symbol"));
lf[409]=C_h_intern(&lf[409],19, C_text("##sys#intern-symbol"));
lf[410]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_string_to_symbol"));
lf[411]=C_h_intern(&lf[411],20, C_text("##sys#context-switch"));
lf[412]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_context_switch"));
lf[413]=C_h_intern(&lf[413],31, C_text("chicken.platform#return-to-host"));
lf[414]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_return_to_host"));
lf[415]=C_h_intern(&lf[415],25, C_text("##sys#ensure-heap-reserve"));
lf[416]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_ensure_heap_reserve"));
lf[417]=C_h_intern(&lf[417],21, C_text("##sys#allocate-vector"));
lf[418]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_allocate_vector"));
lf[419]=C_h_intern(&lf[419],36, C_text("##sys#call-with-current-continuation"));
lf[420]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_call_cc"));
lf[421]=C_h_intern(&lf[421],21, C_text("scheme#number->string"));
lf[422]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\377\001\000\000\000\001\376\377\001\000\000\000\002"));
lf[423]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_number_to_string"));
lf[424]=C_h_intern(&lf[424],8, C_text("scheme#-"));
lf[425]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\377\001\000\000\000\001\376\377\006\000"));
lf[426]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007C_minus"));
lf[427]=C_h_intern(&lf[427],8, C_text("scheme#+"));
lf[428]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_plus"));
lf[429]=C_h_intern(&lf[429],8, C_text("scheme#\052"));
lf[430]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007C_times"));
lf[431]=C_h_intern(&lf[431],9, C_text("scheme#<="));
lf[432]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_less_or_equal_p"));
lf[433]=C_h_intern(&lf[433],9, C_text("scheme#>="));
lf[434]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_greater_or_equal_p"));
lf[435]=C_h_intern(&lf[435],8, C_text("scheme#<"));
lf[436]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007C_lessp"));
lf[437]=C_h_intern(&lf[437],8, C_text("scheme#>"));
lf[438]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_greaterp"));
lf[439]=C_h_intern(&lf[439],8, C_text("scheme#="));
lf[440]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_nequalp"));
lf[441]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_less_or_equalp"));
lf[442]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_i_greater_or_equalp"));
lf[443]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_lessp"));
lf[444]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_i_greaterp"));
lf[445]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_nequalp"));
lf[446]=C_h_intern(&lf[446],13, C_text("scheme#modulo"));
lf[447]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_s_a_i_modulo"));
lf[448]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_s_a_i_remainder"));
lf[449]=C_h_intern(&lf[449],15, C_text("scheme#quotient"));
lf[450]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_s_a_i_quotient"));
lf[451]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_s_a_i_times"));
lf[452]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_s_a_i_minus"));
lf[453]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_s_a_i_plus"));
lf[454]=C_h_intern(&lf[454],8, C_text("scheme#/"));
lf[455]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\024C_fixnum_shift_right\376\377\016"));
lf[456]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\017C_fixnum_divide\376\377\016"));
lf[457]=C_h_intern(&lf[457],9, C_text("##sys#/-2"));
lf[458]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\021C_u_fixnum_negate\376\377\016"));
lf[459]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\017C_fixnum_negate\376\377\016"));
lf[460]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\025C_u_fixnum_difference\376\377\016"));
lf[461]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\023C_fixnum_difference\376\377\016"));
lf[462]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\017C_u_fixnum_plus\376\377\016"));
lf[463]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\015C_fixnum_plus\376\377\016"));
lf[464]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\017C_u_fixnum_plus\376\377\016"));
lf[465]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\015C_fixnum_plus\376\377\016"));
lf[466]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\023C_fixnum_shift_left\376\377\016"));
lf[467]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\016C_fixnum_times\376\377\016"));
lf[468]=C_h_intern(&lf[468],10, C_text("scheme#lcm"));
lf[469]=C_h_intern(&lf[469],10, C_text("scheme#gcd"));
lf[470]=C_h_intern(&lf[470],21, C_text("chicken.base#identity"));
lf[471]=C_h_intern(&lf[471],9, C_text("##sys#lcm"));
lf[472]=C_h_intern(&lf[472],9, C_text("##sys#gcd"));
lf[473]=C_h_intern(&lf[473],18, C_text("scheme#vector-set!"));
lf[474]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_vector_set"));
lf[475]=C_h_intern(&lf[475],19, C_text("scheme#list->string"));
lf[476]=C_h_intern(&lf[476],18, C_text("##sys#list->string"));
lf[477]=C_h_intern(&lf[477],19, C_text("scheme#string->list"));
lf[478]=C_h_intern(&lf[478],18, C_text("##sys#string->list"));
lf[479]=C_h_intern(&lf[479],20, C_text("scheme#string-append"));
lf[480]=C_h_intern(&lf[480],19, C_text("##sys#string-append"));
lf[481]=C_h_intern(&lf[481],16, C_text("scheme#substring"));
lf[482]=C_h_intern(&lf[482],15, C_text("##sys#substring"));
lf[483]=C_h_intern(&lf[483],50, C_text("chicken.memory.representation#make-record-instance"));
lf[484]=C_h_intern(&lf[484],16, C_text("##sys#block-set!"));
lf[485]=C_h_intern(&lf[485],40, C_text("chicken.memory.representation#block-set!"));
lf[486]=C_h_intern(&lf[486],10, C_text("scheme#map"));
lf[487]=C_h_intern(&lf[487],9, C_text("##sys#map"));
lf[488]=C_h_intern(&lf[488],15, C_text("scheme#for-each"));
lf[489]=C_h_intern(&lf[489],14, C_text("##sys#for-each"));
lf[490]=C_h_intern(&lf[490],6, C_text("setter"));
lf[491]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030C_fixnum_less_or_equal_p"));
lf[492]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030C_flonum_less_or_equal_p"));
lf[493]=C_decode_literal(C_heaptop,C_text("\376B\000\000\033C_fixnum_greater_or_equal_p"));
lf[494]=C_decode_literal(C_heaptop,C_text("\376B\000\000\033C_flonum_greater_or_equal_p"));
lf[495]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_fixnum_lessp"));
lf[496]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_flonum_lessp"));
lf[497]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_fixnum_greaterp"));
lf[498]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_flonum_greaterp"));
lf[499]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005C_eqp"));
lf[500]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_i_equalp"));
lf[501]=C_h_intern(&lf[501],16, C_text("##sys#check-char"));
lf[502]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_check_char_2"));
lf[503]=C_h_intern(&lf[503],21, C_text("##sys#check-structure"));
lf[504]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_i_check_structure_2"));
lf[505]=C_h_intern(&lf[505],18, C_text("##sys#check-vector"));
lf[506]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_check_vector_2"));
lf[507]=C_h_intern(&lf[507],23, C_text("##sys#check-byte-vector"));
lf[508]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_i_check_bytevector_2"));
lf[509]=C_h_intern(&lf[509],18, C_text("##sys#check-string"));
lf[510]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_check_string_2"));
lf[511]=C_h_intern(&lf[511],18, C_text("##sys#check-symbol"));
lf[512]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_check_symbol_2"));
lf[513]=C_h_intern(&lf[513],20, C_text("##sys#check-locative"));
lf[514]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_i_check_locative_2"));
lf[515]=C_h_intern(&lf[515],19, C_text("##sys#check-boolean"));
lf[516]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_i_check_boolean_2"));
lf[517]=C_h_intern(&lf[517],16, C_text("##sys#check-pair"));
lf[518]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_check_pair_2"));
lf[519]=C_h_intern(&lf[519],16, C_text("##sys#check-list"));
lf[520]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_check_list_2"));
lf[521]=C_h_intern(&lf[521],18, C_text("##sys#check-number"));
lf[522]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_check_number_2"));
lf[523]=C_h_intern(&lf[523],18, C_text("##sys#check-fixnum"));
lf[524]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_check_fixnum_2"));
lf[525]=C_h_intern(&lf[525],17, C_text("##sys#check-exact"));
lf[526]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_check_exact_2"));
lf[527]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_check_char"));
lf[528]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_i_check_structure"));
lf[529]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_check_vector"));
lf[530]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_i_check_bytevector"));
lf[531]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_check_string"));
lf[532]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_check_symbol"));
lf[533]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_check_locative"));
lf[534]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_check_boolean"));
lf[535]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_check_pair"));
lf[536]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_check_list"));
lf[537]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_check_number"));
lf[538]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_i_check_fixnum"));
lf[539]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_i_check_exact"));
lf[540]=C_h_intern(&lf[540],20, C_text("scheme#string-length"));
lf[541]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_string_length"));
lf[542]=C_h_intern(&lf[542],19, C_text("##sys#vector-length"));
lf[543]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_vector_length"));
lf[544]=C_h_intern(&lf[544],20, C_text("scheme#vector-length"));
lf[545]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_vector_length"));
lf[546]=C_h_intern(&lf[546],20, C_text("scheme#integer->char"));
lf[547]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_make_character"));
lf[548]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007C_unfix"));
lf[549]=C_h_intern(&lf[549],20, C_text("scheme#char->integer"));
lf[550]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005C_fix"));
lf[551]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_character_code"));
lf[552]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005C_fix"));
lf[553]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_header_size"));
lf[554]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005C_fix"));
lf[555]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_header_size"));
lf[556]=C_h_intern(&lf[556],16, C_text("scheme#negative\077"));
lf[557]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_i_negativep"));
lf[558]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_flonum_lessp"));
lf[559]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_fixnum_lessp"));
lf[560]=C_h_intern(&lf[560],16, C_text("scheme#positive\077"));
lf[561]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_i_positivep"));
lf[562]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_flonum_greaterp"));
lf[563]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_fixnum_greaterp"));
lf[564]=C_h_intern(&lf[564],12, C_text("scheme#zero\077"));
lf[565]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_zerop"));
lf[566]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_u_i_zerop"));
lf[567]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005C_eqp"));
lf[568]=C_h_intern(&lf[568],20, C_text("chicken.flonum#fpgcd"));
lf[569]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_a_i_flonum_gcd"));
lf[570]=C_h_intern(&lf[570],20, C_text("chicken.flonum#fpneg"));
lf[571]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_a_i_flonum_negate"));
lf[572]=C_h_intern(&lf[572],19, C_text("chicken.flonum#fp/\077"));
lf[573]=C_decode_literal(C_heaptop,C_text("\376B\000\000\035C_a_i_flonum_quotient_checked"));
lf[574]=C_h_intern(&lf[574],18, C_text("chicken.flonum#fp/"));
lf[575]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_a_i_flonum_quotient"));
lf[576]=C_h_intern(&lf[576],18, C_text("chicken.flonum#fp\052"));
lf[577]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_a_i_flonum_times"));
lf[578]=C_h_intern(&lf[578],18, C_text("chicken.flonum#fp-"));
lf[579]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027C_a_i_flonum_difference"));
lf[580]=C_h_intern(&lf[580],18, C_text("chicken.flonum#fp+"));
lf[581]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_a_i_flonum_plus"));
lf[582]=C_h_intern(&lf[582],27, C_text("chicken.bitwise#bitwise-not"));
lf[583]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_s_a_i_bitwise_not"));
lf[584]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_fixnum_not"));
lf[585]=C_h_intern(&lf[585],27, C_text("chicken.bitwise#bitwise-ior"));
lf[586]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_fixnum_or"));
lf[587]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_u_fixnum_or"));
lf[588]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_s_a_i_bitwise_ior"));
lf[589]=C_h_intern(&lf[589],27, C_text("chicken.bitwise#bitwise-xor"));
lf[590]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_fixnum_xor"));
lf[591]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_fixnum_xor"));
lf[592]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_s_a_i_bitwise_xor"));
lf[593]=C_h_intern(&lf[593],27, C_text("chicken.bitwise#bitwise-and"));
lf[594]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_fixnum_and"));
lf[595]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_u_fixnum_and"));
lf[596]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_s_a_i_bitwise_and"));
lf[597]=C_h_intern(&lf[597],10, C_text("scheme#abs"));
lf[598]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_fixnum_abs"));
lf[599]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_fixnum_abs"));
lf[600]=C_h_intern(&lf[600],15, C_text("scheme#set-cdr!"));
lf[601]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_set_cdr"));
lf[602]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_u_i_set_cdr"));
lf[603]=C_h_intern(&lf[603],15, C_text("scheme#set-car!"));
lf[604]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_set_car"));
lf[605]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_u_i_set_car"));
lf[606]=C_h_intern(&lf[606],13, C_text("scheme#member"));
lf[607]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_i_member"));
lf[608]=C_h_intern(&lf[608],12, C_text("scheme#assoc"));
lf[609]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_assoc"));
lf[610]=C_h_intern(&lf[610],11, C_text("scheme#memq"));
lf[611]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_memq"));
lf[612]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_u_i_memq"));
lf[613]=C_h_intern(&lf[613],11, C_text("scheme#assq"));
lf[614]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_assq"));
lf[615]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_u_i_assq"));
lf[616]=C_h_intern(&lf[616],11, C_text("scheme#memv"));
lf[617]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_memv"));
lf[618]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_memq"));
lf[619]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_u_i_memq"));
lf[620]=C_h_intern(&lf[620],11, C_text("scheme#assv"));
lf[621]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_assv"));
lf[622]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_assq"));
lf[623]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_u_i_assq"));
lf[624]=C_h_intern(&lf[624],45, C_text("chicken.memory.representation#number-of-slots"));
lf[625]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_block_size"));
lf[626]=C_h_intern(&lf[626],39, C_text("chicken.memory.representation#block-ref"));
lf[627]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[628]=C_h_intern(&lf[628],17, C_text("##sys#bytevector\077"));
lf[629]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_bytevectorp"));
lf[630]=C_h_intern(&lf[630],16, C_text("##sys#structure\077"));
lf[631]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_structurep"));
lf[632]=C_h_intern(&lf[632],16, C_text("scheme#list-tail"));
lf[633]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_i_list_tail"));
lf[634]=C_h_intern(&lf[634],20, C_text("scheme#char-downcase"));
lf[635]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_char_downcase"));
lf[636]=C_h_intern(&lf[636],18, C_text("scheme#char-upcase"));
lf[637]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_u_i_char_upcase"));
lf[638]=C_h_intern(&lf[638],23, C_text("scheme#char-lower-case\077"));
lf[639]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_char_lower_casep"));
lf[640]=C_h_intern(&lf[640],23, C_text("scheme#char-upper-case\077"));
lf[641]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_char_upper_casep"));
lf[642]=C_h_intern(&lf[642],23, C_text("scheme#char-whitespace\077"));
lf[643]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_char_whitespacep"));
lf[644]=C_h_intern(&lf[644],23, C_text("scheme#char-alphabetic\077"));
lf[645]=C_decode_literal(C_heaptop,C_text("\376B\000\000\026C_u_i_char_alphabeticp"));
lf[646]=C_h_intern(&lf[646],20, C_text("scheme#char-numeric\077"));
lf[647]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_char_numericp"));
lf[648]=C_h_intern(&lf[648],20, C_text("chicken.fixnum#fxlen"));
lf[649]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_fixnum_length"));
lf[650]=C_h_intern(&lf[650],20, C_text("chicken.fixnum#fxgcd"));
lf[651]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_fixnum_gcd"));
lf[652]=C_h_intern(&lf[652],20, C_text("chicken.flonum#fpmin"));
lf[653]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_flonum_min"));
lf[654]=C_h_intern(&lf[654],20, C_text("chicken.flonum#fpmax"));
lf[655]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_flonum_max"));
lf[656]=C_h_intern(&lf[656],20, C_text("chicken.fixnum#fxmin"));
lf[657]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_fixnum_min"));
lf[658]=C_h_intern(&lf[658],20, C_text("chicken.fixnum#fxmax"));
lf[659]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_fixnum_max"));
lf[660]=C_h_intern(&lf[660],19, C_text("chicken.flonum#fp<="));
lf[661]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030C_flonum_less_or_equal_p"));
lf[662]=C_h_intern(&lf[662],19, C_text("chicken.flonum#fp>="));
lf[663]=C_decode_literal(C_heaptop,C_text("\376B\000\000\033C_flonum_greater_or_equal_p"));
lf[664]=C_h_intern(&lf[664],18, C_text("chicken.flonum#fp<"));
lf[665]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_flonum_lessp"));
lf[666]=C_h_intern(&lf[666],18, C_text("chicken.flonum#fp>"));
lf[667]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_flonum_greaterp"));
lf[668]=C_h_intern(&lf[668],18, C_text("chicken.flonum#fp="));
lf[669]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_flonum_equalp"));
lf[670]=C_h_intern(&lf[670],19, C_text("chicken.fixnum#fx<="));
lf[671]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030C_fixnum_less_or_equal_p"));
lf[672]=C_h_intern(&lf[672],19, C_text("chicken.fixnum#fx>="));
lf[673]=C_decode_literal(C_heaptop,C_text("\376B\000\000\033C_fixnum_greater_or_equal_p"));
lf[674]=C_h_intern(&lf[674],18, C_text("chicken.fixnum#fx<"));
lf[675]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_fixnum_lessp"));
lf[676]=C_h_intern(&lf[676],18, C_text("chicken.fixnum#fx>"));
lf[677]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_fixnum_greaterp"));
lf[678]=C_h_intern(&lf[678],18, C_text("chicken.fixnum#fx="));
lf[679]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005C_eqp"));
lf[680]=C_h_intern(&lf[680],19, C_text("chicken.fixnum#fx/\077"));
lf[681]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025C_i_o_fixnum_quotient"));
lf[682]=C_h_intern(&lf[682],19, C_text("chicken.fixnum#fx\052\077"));
lf[683]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_o_fixnum_times"));
lf[684]=C_h_intern(&lf[684],19, C_text("chicken.fixnum#fx-\077"));
lf[685]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027C_i_o_fixnum_difference"));
lf[686]=C_h_intern(&lf[686],19, C_text("chicken.fixnum#fx+\077"));
lf[687]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_o_fixnum_plus"));
lf[688]=C_h_intern(&lf[688],18, C_text("chicken.fixnum#fx\052"));
lf[689]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_fixnum_times"));
lf[690]=C_h_intern(&lf[690],20, C_text("chicken.fixnum#fxnot"));
lf[691]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_fixnum_not"));
lf[692]=C_h_intern(&lf[692],10, C_text("##sys#size"));
lf[693]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_block_size"));
lf[694]=C_h_intern(&lf[694],15, C_text("##sys#block-ref"));
lf[695]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_i_block_ref"));
lf[696]=C_h_intern(&lf[696],10, C_text("##sys#slot"));
lf[697]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[698]=C_h_intern(&lf[698],14, C_text("scheme#char<=\077"));
lf[699]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030C_i_char_less_or_equal_p"));
lf[700]=C_decode_literal(C_heaptop,C_text("\376B\000\000\032C_u_i_char_less_or_equal_p"));
lf[701]=C_h_intern(&lf[701],14, C_text("scheme#char>=\077"));
lf[702]=C_decode_literal(C_heaptop,C_text("\376B\000\000\033C_i_char_greater_or_equal_p"));
lf[703]=C_decode_literal(C_heaptop,C_text("\376B\000\000\035C_u_i_char_greater_or_equal_p"));
lf[704]=C_h_intern(&lf[704],13, C_text("scheme#char<\077"));
lf[705]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_char_lessp"));
lf[706]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_u_i_char_lessp"));
lf[707]=C_h_intern(&lf[707],13, C_text("scheme#char>\077"));
lf[708]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_char_greaterp"));
lf[709]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_i_char_greaterp"));
lf[710]=C_h_intern(&lf[710],13, C_text("scheme#char=\077"));
lf[711]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017C_i_char_equalp"));
lf[712]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_u_i_char_equalp"));
lf[713]=C_h_intern(&lf[713],17, C_text("scheme#vector-ref"));
lf[714]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_vector_ref"));
lf[715]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[716]=C_h_intern(&lf[716],18, C_text("scheme#string-set!"));
lf[717]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_string_set"));
lf[718]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_setsubchar"));
lf[719]=C_h_intern(&lf[719],17, C_text("scheme#string-ref"));
lf[720]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_string_ref"));
lf[721]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_subchar"));
lf[722]=C_h_intern(&lf[722],18, C_text("scheme#eof-object\077"));
lf[723]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_eofp"));
lf[724]=C_h_intern(&lf[724],12, C_text("scheme#list\077"));
lf[725]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_listp"));
lf[726]=C_h_intern(&lf[726],15, C_text("scheme#inexact\077"));
lf[727]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_u_i_inexactp"));
lf[728]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_i_inexactp"));
lf[729]=C_h_intern(&lf[729],13, C_text("scheme#exact\077"));
lf[730]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_exactp"));
lf[731]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_i_exactp"));
lf[732]=C_h_intern(&lf[732],24, C_text("##sys#generic-structure\077"));
lf[733]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_structurep"));
lf[734]=C_h_intern(&lf[734],8, C_text("pointer\077"));
lf[735]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_i_safe_pointerp"));
lf[736]=C_h_intern(&lf[736],14, C_text("##sys#pointer\077"));
lf[737]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_anypointerp"));
lf[738]=C_h_intern(&lf[738],25, C_text("chicken.flonum#fpinteger\077"));
lf[739]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020C_u_i_fpintegerp"));
lf[740]=C_h_intern(&lf[740],22, C_text("chicken.base#infinite\077"));
lf[741]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_i_infinitep"));
lf[742]=C_h_intern(&lf[742],20, C_text("chicken.base#finite\077"));
lf[743]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_finitep"));
lf[744]=C_h_intern(&lf[744],17, C_text("chicken.base#nan\077"));
lf[745]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_nanp"));
lf[746]=C_h_intern(&lf[746],20, C_text("chicken.base#ratnum\077"));
lf[747]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_ratnump"));
lf[748]=C_h_intern(&lf[748],21, C_text("chicken.base#cplxnum\077"));
lf[749]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_i_cplxnump"));
lf[750]=C_h_intern(&lf[750],20, C_text("chicken.base#bignum\077"));
lf[751]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_bignump"));
lf[752]=C_h_intern(&lf[752],20, C_text("chicken.base#fixnum\077"));
lf[753]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_fixnump"));
lf[754]=C_h_intern(&lf[754],20, C_text("chicken.base#flonum\077"));
lf[755]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_flonump"));
lf[756]=C_h_intern(&lf[756],27, C_text("chicken.base#exact-integer\077"));
lf[757]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_exact_integerp"));
lf[758]=C_h_intern(&lf[758],15, C_text("scheme#integer\077"));
lf[759]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_i_integerp"));
lf[760]=C_h_intern(&lf[760],12, C_text("scheme#real\077"));
lf[761]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_realp"));
lf[762]=C_h_intern(&lf[762],16, C_text("scheme#rational\077"));
lf[763]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_i_rationalp"));
lf[764]=C_h_intern(&lf[764],15, C_text("scheme#complex\077"));
lf[765]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_numberp"));
lf[766]=C_h_intern(&lf[766],14, C_text("scheme#number\077"));
lf[767]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_numberp"));
lf[768]=C_h_intern(&lf[768],15, C_text("scheme#boolean\077"));
lf[769]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_booleanp"));
lf[770]=C_h_intern(&lf[770],18, C_text("chicken.base#port\077"));
lf[771]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_portp"));
lf[772]=C_h_intern(&lf[772],17, C_text("scheme#procedure\077"));
lf[773]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_i_closurep"));
lf[774]=C_h_intern(&lf[774],11, C_text("##sys#pair\077"));
lf[775]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_pairp"));
lf[776]=C_h_intern(&lf[776],12, C_text("scheme#pair\077"));
lf[777]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_pairp"));
lf[778]=C_h_intern(&lf[778],17, C_text("srfi-4#f64vector\077"));
lf[779]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_f64vectorp"));
lf[780]=C_h_intern(&lf[780],17, C_text("srfi-4#f32vector\077"));
lf[781]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_f32vectorp"));
lf[782]=C_h_intern(&lf[782],17, C_text("srfi-4#s64vector\077"));
lf[783]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_s64vectorp"));
lf[784]=C_h_intern(&lf[784],17, C_text("srfi-4#u64vector\077"));
lf[785]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_u64vectorp"));
lf[786]=C_h_intern(&lf[786],17, C_text("srfi-4#s32vector\077"));
lf[787]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_s32vectorp"));
lf[788]=C_h_intern(&lf[788],17, C_text("srfi-4#u32vector\077"));
lf[789]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_u32vectorp"));
lf[790]=C_h_intern(&lf[790],17, C_text("srfi-4#s16vector\077"));
lf[791]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_s16vectorp"));
lf[792]=C_h_intern(&lf[792],17, C_text("srfi-4#u16vector\077"));
lf[793]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_i_u16vectorp"));
lf[794]=C_h_intern(&lf[794],16, C_text("srfi-4#s8vector\077"));
lf[795]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_i_s8vectorp"));
lf[796]=C_h_intern(&lf[796],16, C_text("srfi-4#u8vector\077"));
lf[797]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_i_u8vectorp"));
lf[798]=C_h_intern(&lf[798],20, C_text("##sys#srfi-4-vector\077"));
lf[799]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_i_srfi_4_vectorp"));
lf[800]=C_h_intern(&lf[800],13, C_text("##sys#vector\077"));
lf[801]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_vectorp"));
lf[802]=C_h_intern(&lf[802],14, C_text("scheme#vector\077"));
lf[803]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_vectorp"));
lf[804]=C_h_intern(&lf[804],14, C_text("scheme#symbol\077"));
lf[805]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_symbolp"));
lf[806]=C_h_intern(&lf[806],26, C_text("chicken.locative#locative\077"));
lf[807]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_i_locativep"));
lf[808]=C_h_intern(&lf[808],14, C_text("scheme#string\077"));
lf[809]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_i_stringp"));
lf[810]=C_h_intern(&lf[810],12, C_text("scheme#char\077"));
lf[811]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007C_charp"));
lf[812]=C_h_intern(&lf[812],10, C_text("scheme#not"));
lf[813]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007C_i_not"));
lf[814]=C_h_intern(&lf[814],13, C_text("scheme#length"));
lf[815]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_i_length"));
lf[816]=C_h_intern(&lf[816],11, C_text("##sys#null\077"));
lf[817]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_nullp"));
lf[818]=C_h_intern(&lf[818],12, C_text("scheme#null\077"));
lf[819]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_nullp"));
lf[820]=C_h_intern(&lf[820],15, C_text("scheme#list-ref"));
lf[821]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_i_list_ref"));
lf[822]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016C_u_i_list_ref"));
lf[823]=C_h_intern(&lf[823],10, C_text("##sys#eqv\077"));
lf[824]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_eqvp"));
lf[825]=C_h_intern(&lf[825],11, C_text("scheme#eqv\077"));
lf[826]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_eqvp"));
lf[827]=C_h_intern(&lf[827],9, C_text("##sys#eq\077"));
lf[828]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005C_eqp"));
lf[829]=C_h_intern(&lf[829],10, C_text("scheme#eq\077"));
lf[830]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005C_eqp"));
lf[831]=C_h_intern(&lf[831],10, C_text("scheme#cdr"));
lf[832]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007C_i_cdr"));
lf[833]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006C_slot"));
lf[834]=C_h_intern(&lf[834],13, C_text("scheme#cddddr"));
lf[835]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_i_cddddr"));
lf[836]=C_h_intern(&lf[836],12, C_text("scheme#cdddr"));
lf[837]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_cdddr"));
lf[838]=C_h_intern(&lf[838],11, C_text("scheme#cddr"));
lf[839]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_cddr"));
lf[840]=C_h_intern(&lf[840],11, C_text("scheme#cdar"));
lf[841]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_cdar"));
lf[842]=C_h_intern(&lf[842],11, C_text("scheme#caar"));
lf[843]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_caar"));
lf[844]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cddddr"));
lf[845]=C_h_intern(&lf[845],13, C_text("scheme#cdddar"));
lf[846]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cdddar"));
lf[847]=C_h_intern(&lf[847],13, C_text("scheme#cddadr"));
lf[848]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cddadr"));
lf[849]=C_h_intern(&lf[849],13, C_text("scheme#cddaar"));
lf[850]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cddaar"));
lf[851]=C_h_intern(&lf[851],13, C_text("scheme#cdaddr"));
lf[852]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cdaddr"));
lf[853]=C_h_intern(&lf[853],13, C_text("scheme#cdadar"));
lf[854]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cdadar"));
lf[855]=C_h_intern(&lf[855],13, C_text("scheme#cdaadr"));
lf[856]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cdaadr"));
lf[857]=C_h_intern(&lf[857],13, C_text("scheme#cdaaar"));
lf[858]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cdaaar"));
lf[859]=C_h_intern(&lf[859],13, C_text("scheme#cadddr"));
lf[860]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cadddr"));
lf[861]=C_h_intern(&lf[861],13, C_text("scheme#caddar"));
lf[862]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_caddar"));
lf[863]=C_h_intern(&lf[863],13, C_text("scheme#cadadr"));
lf[864]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cadadr"));
lf[865]=C_h_intern(&lf[865],13, C_text("scheme#cadaar"));
lf[866]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cadaar"));
lf[867]=C_h_intern(&lf[867],13, C_text("scheme#caaddr"));
lf[868]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_caaddr"));
lf[869]=C_h_intern(&lf[869],13, C_text("scheme#caadar"));
lf[870]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_caadar"));
lf[871]=C_h_intern(&lf[871],13, C_text("scheme#caaaar"));
lf[872]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_caaaar"));
lf[873]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_u_i_cdddr"));
lf[874]=C_h_intern(&lf[874],12, C_text("scheme#cddar"));
lf[875]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_u_i_cddar"));
lf[876]=C_h_intern(&lf[876],12, C_text("scheme#cdadr"));
lf[877]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_u_i_cdadr"));
lf[878]=C_h_intern(&lf[878],12, C_text("scheme#cdaar"));
lf[879]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_u_i_cdaar"));
lf[880]=C_h_intern(&lf[880],12, C_text("scheme#caddr"));
lf[881]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_u_i_caddr"));
lf[882]=C_h_intern(&lf[882],12, C_text("scheme#cadar"));
lf[883]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_u_i_cadar"));
lf[884]=C_h_intern(&lf[884],12, C_text("scheme#caaar"));
lf[885]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_u_i_caaar"));
lf[886]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_u_i_cddr"));
lf[887]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_u_i_cdar"));
lf[888]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_u_i_caar"));
lf[889]=C_h_intern(&lf[889],39, C_text("chicken.continuation#continuation-graft"));
lf[890]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_continuation_graft"));
lf[891]=C_h_intern(&lf[891],22, C_text("##sys#call-with-values"));
lf[892]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_call_with_values"));
lf[893]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_u_call_with_values"));
lf[894]=C_h_intern(&lf[894],23, C_text("scheme#call-with-values"));
lf[895]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022C_call_with_values"));
lf[896]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024C_u_call_with_values"));
lf[897]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_values"));
lf[898]=C_h_intern(&lf[898],13, C_text("scheme#values"));
lf[899]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_values"));
lf[900]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_i_cadddr"));
lf[901]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_u_i_cadddr"));
lf[902]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_i_caddr"));
lf[903]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013C_u_i_caddr"));
lf[904]=C_h_intern(&lf[904],11, C_text("scheme#cadr"));
lf[905]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_cadr"));
lf[906]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012C_u_i_cadr"));
lf[907]=C_h_intern(&lf[907],9, C_text("##sys#cdr"));
lf[908]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007C_i_cdr"));
lf[909]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_u_i_cdr"));
lf[910]=C_h_intern(&lf[910],9, C_text("##sys#car"));
lf[911]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007C_i_car"));
lf[912]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_u_i_car"));
lf[913]=C_h_intern(&lf[913],10, C_text("scheme#car"));
lf[914]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007C_i_car"));
lf[915]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011C_u_i_car"));
lf[916]=C_h_intern(&lf[916],11, C_text("##sys#apply"));
lf[917]=C_h_intern(&lf[917],12, C_text("scheme#apply"));
lf[918]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\012C_i_equalp\376\377\016"));
lf[919]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\005C_eqp\376\377\016"));
lf[920]=C_h_intern(&lf[920],13, C_text("scheme#equal\077"));
lf[921]=C_h_intern(&lf[921],17, C_text("chicken.base#sub1"));
lf[922]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_fixnum_decrease"));
lf[923]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_fixnum_decrease"));
lf[924]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015C_s_a_i_minus"));
lf[925]=C_h_intern(&lf[925],17, C_text("chicken.base#add1"));
lf[926]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021C_fixnum_increase"));
lf[927]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023C_u_fixnum_increase"));
lf[928]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014C_s_a_i_plus"));
lf[929]=C_h_intern(&lf[929],38, C_text("chicken.compiler.support#mark-variable"));
lf[930]=C_h_intern(&lf[930],15, C_text("##compiler#pure"));
lf[931]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\012\001##sys#slot\376\003\000\000\002\376\001\000\000\017\001##sys#block-ref\376\003\000\000\002\376\001\000\000\012\001##sys#size\376\003\000\000\002\376\001\000\000\012\001#"
"#sys#byte\376\003\000\000\002\376\001\000\000\016\001##sys#pointer\077\376\003\000\000\002\376\001\000\000\030\001##sys#generic-structure\077\376\003\000\000\002\376\001\000\000\020\001"
"##sys#immediate\077\376\003\000\000\002\376\001\000\000\021\001##sys#bytevector\077\376\003\000\000\002\376\001\000\000\013\001##sys#pair\077\376\003\000\000\002\376\001\000\000\011\001##s"
"ys#eq\077\376\003\000\000\002\376\001\000\000\013\001##sys#list\077\376\003\000\000\002\376\001\000\000\015\001##sys#vector\077\376\003\000\000\002\376\001\000\000\012\001##sys#eqv\077\376\003\000\000\002\376\001"
"\000\000\021\001##sys#get-keyword\376\003\000\000\002\376\001\000\000\012\001##sys#void\376\003\000\000\002\376\001\000\000\020\001##sys#permanent\077\376\377\016"));
lf[932]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\022\001chicken.fixnum#fx\052\376\003\000\000\002\376\001\000\000\023\001chicken.fixnum#fx\052\077\376\003\000\000\002\376\001\000\000\022\001chicken.fi"
"xnum#fx+\376\003\000\000\002\376\001\000\000\023\001chicken.fixnum#fx+\077\376\003\000\000\002\376\001\000\000\022\001chicken.fixnum#fx-\376\003\000\000\002\376\001\000\000\023\001ch"
"icken.fixnum#fx-\077\376\003\000\000\002\376\001\000\000\022\001chicken.fixnum#fx/\376\003\000\000\002\376\001\000\000\023\001chicken.fixnum#fx/\077\376\003\000\000"
"\002\376\001\000\000\022\001chicken.fixnum#fx<\376\003\000\000\002\376\001\000\000\023\001chicken.fixnum#fx<=\376\003\000\000\002\376\001\000\000\022\001chicken.fixnum"
"#fx=\376\003\000\000\002\376\001\000\000\022\001chicken.fixnum#fx>\376\003\000\000\002\376\001\000\000\023\001chicken.fixnum#fx>=\376\003\000\000\002\376\001\000\000\024\001chicke"
"n.fixnum#fxand\376\003\000\000\002\376\001\000\000\026\001chicken.fixnum#fxeven\077\376\003\000\000\002\376\001\000\000\024\001chicken.fixnum#fxgcd\376\003"
"\000\000\002\376\001\000\000\024\001chicken.fixnum#fxior\376\003\000\000\002\376\001\000\000\024\001chicken.fixnum#fxlen\376\003\000\000\002\376\001\000\000\024\001chicken.f"
"ixnum#fxmax\376\003\000\000\002\376\001\000\000\024\001chicken.fixnum#fxmin\376\003\000\000\002\376\001\000\000\024\001chicken.fixnum#fxmod\376\003\000\000\002\376\001"
"\000\000\024\001chicken.fixnum#fxneg\376\003\000\000\002\376\001\000\000\024\001chicken.fixnum#fxnot\376\003\000\000\002\376\001\000\000\025\001chicken.fixnum"
"#fxodd\077\376\003\000\000\002\376\001\000\000\024\001chicken.fixnum#fxrem\376\003\000\000\002\376\001\000\000\024\001chicken.fixnum#fxshl\376\003\000\000\002\376\001\000\000\024\001"
"chicken.fixnum#fxshr\376\003\000\000\002\376\001\000\000\024\001chicken.fixnum#fxxor\376\377\016"));
lf[933]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\023\001chicken.flonum#fp/\077\376\003\000\000\002\376\001\000\000\022\001chicken.flonum#fp+\376\003\000\000\002\376\001\000\000\022\001chicken.fl"
"onum#fp-\376\003\000\000\002\376\001\000\000\022\001chicken.flonum#fp\052\376\003\000\000\002\376\001\000\000\022\001chicken.flonum#fp/\376\003\000\000\002\376\001\000\000\022\001chi"
"cken.flonum#fp>\376\003\000\000\002\376\001\000\000\022\001chicken.flonum#fp<\376\003\000\000\002\376\001\000\000\022\001chicken.flonum#fp=\376\003\000\000\002\376\001"
"\000\000\023\001chicken.flonum#fp>=\376\003\000\000\002\376\001\000\000\023\001chicken.flonum#fp<=\376\003\000\000\002\376\001\000\000\024\001chicken.flonum#f"
"pmin\376\003\000\000\002\376\001\000\000\024\001chicken.flonum#fpmax\376\003\000\000\002\376\001\000\000\024\001chicken.flonum#fpneg\376\003\000\000\002\376\001\000\000\024\001chi"
"cken.flonum#fpgcd\376\003\000\000\002\376\001\000\000\026\001chicken.flonum#fpfloor\376\003\000\000\002\376\001\000\000\030\001chicken.flonum#fpce"
"iling\376\003\000\000\002\376\001\000\000\031\001chicken.flonum#fptruncate\376\003\000\000\002\376\001\000\000\026\001chicken.flonum#fpround\376\003\000\000\002\376"
"\001\000\000\024\001chicken.flonum#fpsin\376\003\000\000\002\376\001\000\000\024\001chicken.flonum#fpcos\376\003\000\000\002\376\001\000\000\024\001chicken.flonu"
"m#fptan\376\003\000\000\002\376\001\000\000\025\001chicken.flonum#fpasin\376\003\000\000\002\376\001\000\000\025\001chicken.flonum#fpacos\376\003\000\000\002\376\001\000\000"
"\025\001chicken.flonum#fpatan\376\003\000\000\002\376\001\000\000\026\001chicken.flonum#fpatan2\376\003\000\000\002\376\001\000\000\024\001chicken.flonu"
"m#fpexp\376\003\000\000\002\376\001\000\000\025\001chicken.flonum#fpexpt\376\003\000\000\002\376\001\000\000\024\001chicken.flonum#fplog\376\003\000\000\002\376\001\000\000\025"
"\001chicken.flonum#fpsqrt\376\003\000\000\002\376\001\000\000\024\001chicken.flonum#fpabs\376\003\000\000\002\376\001\000\000\031\001chicken.flonum#f"
"pinteger\077\376\377\016"));
lf[934]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\024\001chicken.base#bignum\077\376\003\000\000\002\376\001\000\000\025\001chicken.base#cplxnum\077\376\003\000\000\002\376\001\000\000\024\001chicke"
"n.base#fixnum\077\376\003\000\000\002\376\001\000\000\024\001chicken.base#flonum\077\376\003\000\000\002\376\001\000\000\024\001chicken.base#ratnum\077\376\003\000\000"
"\002\376\001\000\000\021\001chicken.base#add1\376\003\000\000\002\376\001\000\000\021\001chicken.base#sub1\376\003\000\000\002\376\001\000\000\021\001chicken.base#nan\077"
"\376\003\000\000\002\376\001\000\000\024\001chicken.base#finite\077\376\003\000\000\002\376\001\000\000\026\001chicken.base#infinite\077\376\003\000\000\002\376\001\000\000\023\001chick"
"en.base#gensym\376\003\000\000\002\376\001\000\000\021\001chicken.base#void\376\003\000\000\002\376\001\000\000\022\001chicken.base#print\376\003\000\000\002\376\001\000\000"
"\023\001chicken.base#print\052\376\003\000\000\002\376\001\000\000\022\001chicken.base#error\376\003\000\000\002\376\001\000\000\024\001chicken.base#call/c"
"c\376\003\000\000\002\376\001\000\000\026\001chicken.base#char-name\376\003\000\000\002\376\001\000\000\037\001chicken.base#current-error-port\376\003\000\000"
"\002\376\001\000\000\032\001chicken.base#symbol-append\376\003\000\000\002\376\001\000\000\022\001chicken.base#foldl\376\003\000\000\002\376\001\000\000\022\001chicken"
".base#foldr\376\003\000\000\002\376\001\000\000\023\001chicken.base#setter\376\003\000\000\002\376\001\000\000\037\001chicken.base#getter-with-set"
"ter\376\003\000\000\002\376\001\000\000\024\001chicken.base#equal=\077\376\003\000\000\002\376\001\000\000\033\001chicken.base#exact-integer\077\376\003\000\000\002\376\001\000"
"\000\031\001chicken.base#flush-output\376\003\000\000\002\376\001\000\000\025\001chicken.base#identity\376\003\000\000\002\376\001\000\000\016\001chicken.b"
"ase#o\376\003\000\000\002\376\001\000\000\022\001chicken.base#atom\077\376\003\000\000\002\376\001\000\000\026\001chicken.base#alist-ref\376\003\000\000\002\376\001\000\000\023\001ch"
"icken.base#rassoc\376\003\000\000\002\376\001\000\000\036\001chicken.bitwise#integer-length\376\003\000\000\002\376\001\000\000\033\001chicken.bit"
"wise#bitwise-and\376\003\000\000\002\376\001\000\000\033\001chicken.bitwise#bitwise-not\376\003\000\000\002\376\001\000\000\033\001chicken.bitwise"
"#bitwise-ior\376\003\000\000\002\376\001\000\000\033\001chicken.bitwise#bitwise-xor\376\003\000\000\002\376\001\000\000 \001chicken.bitwise#ari"
"thmetic-shift\376\003\000\000\002\376\001\000\000\034\001chicken.bitwise#bit->boolean\376\003\000\000\002\376\001\000\000\026\001chicken.blob#blob"
"-size\376\003\000\000\002\376\001\000\000\023\001chicken.blob#blob=\077\376\003\000\000\002\376\001\000\000\033\001chicken.keyword#get-keyword\376\003\000\000\002\376\001"
"\000\000\020\001srfi-4#u8vector\077\376\003\000\000\002\376\001\000\000\020\001srfi-4#s8vector\077\376\003\000\000\002\376\001\000\000\021\001srfi-4#u16vector\077\376\003\000\000\002"
"\376\001\000\000\021\001srfi-4#s16vector\077\376\003\000\000\002\376\001\000\000\021\001srfi-4#u32vector\077\376\003\000\000\002\376\001\000\000\021\001srfi-4#u64vector\077\376"
"\003\000\000\002\376\001\000\000\021\001srfi-4#s32vector\077\376\003\000\000\002\376\001\000\000\021\001srfi-4#s64vector\077\376\003\000\000\002\376\001\000\000\021\001srfi-4#f32vect"
"or\077\376\003\000\000\002\376\001\000\000\021\001srfi-4#f64vector\077\376\003\000\000\002\376\001\000\000\026\001srfi-4#u8vector-length\376\003\000\000\002\376\001\000\000\026\001srfi-"
"4#s8vector-length\376\003\000\000\002\376\001\000\000\027\001srfi-4#u16vector-length\376\003\000\000\002\376\001\000\000\027\001srfi-4#s16vector-l"
"ength\376\003\000\000\002\376\001\000\000\027\001srfi-4#u32vector-length\376\003\000\000\002\376\001\000\000\027\001srfi-4#u64vector-length\376\003\000\000\002\376\001"
"\000\000\027\001srfi-4#s32vector-length\376\003\000\000\002\376\001\000\000\027\001srfi-4#s64vector-length\376\003\000\000\002\376\001\000\000\027\001srfi-4#f"
"32vector-length\376\003\000\000\002\376\001\000\000\027\001srfi-4#f64vector-length\376\003\000\000\002\376\001\000\000\023\001srfi-4#u8vector-ref\376"
"\003\000\000\002\376\001\000\000\023\001srfi-4#s8vector-ref\376\003\000\000\002\376\001\000\000\024\001srfi-4#u16vector-ref\376\003\000\000\002\376\001\000\000\024\001srfi-4#s1"
"6vector-ref\376\003\000\000\002\376\001\000\000\024\001srfi-4#u32vector-ref\376\003\000\000\002\376\001\000\000\024\001srfi-4#u64vector-ref\376\003\000\000\002\376\001"
"\000\000\024\001srfi-4#s32vector-ref\376\003\000\000\002\376\001\000\000\024\001srfi-4#s64vector-ref\376\003\000\000\002\376\001\000\000\024\001srfi-4#f32vect"
"or-ref\376\003\000\000\002\376\001\000\000\024\001srfi-4#f64vector-ref\376\003\000\000\002\376\001\000\000\024\001srfi-4#u8vector-set!\376\003\000\000\002\376\001\000\000\024\001s"
"rfi-4#s8vector-set!\376\003\000\000\002\376\001\000\000\025\001srfi-4#u16vector-set!\376\003\000\000\002\376\001\000\000\025\001srfi-4#s16vector-s"
"et!\376\003\000\000\002\376\001\000\000\025\001srfi-4#u32vector-set!\376\003\000\000\002\376\001\000\000\025\001srfi-4#u64vector-set!\376\003\000\000\002\376\001\000\000\025\001sr"
"fi-4#s32vector-set!\376\003\000\000\002\376\001\000\000\025\001srfi-4#s64vector-set!\376\003\000\000\002\376\001\000\000\025\001srfi-4#f32vector-s"
"et!\376\003\000\000\002\376\001\000\000\025\001srfi-4#f64vector-set!\376\003\000\000\002\376\001\000\000\034\001srfi-4#u8vector->blob/shared\376\003\000\000\002\376"
"\001\000\000\034\001srfi-4#s8vector->blob/shared\376\003\000\000\002\376\001\000\000\035\001srfi-4#u16vector->blob/shared\376\003\000\000\002\376\001"
"\000\000\035\001srfi-4#s16vector->blob/shared\376\003\000\000\002\376\001\000\000\035\001srfi-4#u32vector->blob/shared\376\003\000\000\002\376\001"
"\000\000\035\001srfi-4#s32vector->blob/shared\376\003\000\000\002\376\001\000\000\035\001srfi-4#u64vector->blob/shared\376\003\000\000\002\376\001"
"\000\000\035\001srfi-4#s64vector->blob/shared\376\003\000\000\002\376\001\000\000\035\001srfi-4#f32vector->blob/shared\376\003\000\000\002\376\001"
"\000\000\035\001srfi-4#f64vector->blob/shared\376\003\000\000\002\376\001\000\000\034\001srfi-4#blob->u8vector/shared\376\003\000\000\002\376\001\000"
"\000\034\001srfi-4#blob->s8vector/shared\376\003\000\000\002\376\001\000\000\035\001srfi-4#blob->u16vector/shared\376\003\000\000\002\376\001\000\000"
"\035\001srfi-4#blob->s16vector/shared\376\003\000\000\002\376\001\000\000\035\001srfi-4#blob->u32vector/shared\376\003\000\000\002\376\001\000\000"
"\035\001srfi-4#blob->s32vector/shared\376\003\000\000\002\376\001\000\000\035\001srfi-4#blob->u64vector/shared\376\003\000\000\002\376\001\000\000"
"\035\001srfi-4#blob->s64vector/shared\376\003\000\000\002\376\001\000\000\035\001srfi-4#blob->f32vector/shared\376\003\000\000\002\376\001\000\000"
"\035\001srfi-4#blob->f64vector/shared\376\003\000\000\002\376\001\000\000\033\001chicken.memory#u8vector-ref\376\003\000\000\002\376\001\000\000\033\001"
"chicken.memory#s8vector-ref\376\003\000\000\002\376\001\000\000\034\001chicken.memory#u16vector-ref\376\003\000\000\002\376\001\000\000\034\001chi"
"cken.memory#s16vector-ref\376\003\000\000\002\376\001\000\000\034\001chicken.memory#u32vector-ref\376\003\000\000\002\376\001\000\000\034\001chick"
"en.memory#s32vector-ref\376\003\000\000\002\376\001\000\000\034\001chicken.memory#u64vector-ref\376\003\000\000\002\376\001\000\000\034\001chicken"
".memory#s64vector-ref\376\003\000\000\002\376\001\000\000\034\001chicken.memory#f32vector-ref\376\003\000\000\002\376\001\000\000\034\001chicken.m"
"emory#f64vector-ref\376\003\000\000\002\376\001\000\000\035\001chicken.memory#f32vector-set!\376\003\000\000\002\376\001\000\000\035\001chicken.me"
"mory#f64vector-set!\376\003\000\000\002\376\001\000\000\034\001chicken.memory#u8vector-set!\376\003\000\000\002\376\001\000\000\034\001chicken.mem"
"ory#s8vector-set!\376\003\000\000\002\376\001\000\000\035\001chicken.memory#u16vector-set!\376\003\000\000\002\376\001\000\000\035\001chicken.memo"
"ry#s16vector-set!\376\003\000\000\002\376\001\000\000\035\001chicken.memory#u32vector-set!\376\003\000\000\002\376\001\000\000\035\001chicken.memo"
"ry#s32vector-set!\376\003\000\000\002\376\001\000\000\035\001chicken.memory#u64vector-set!\376\003\000\000\002\376\001\000\000\035\001chicken.memo"
"ry#s64vector-set!\376\003\000\000\002\376\001\000\000-\001chicken.memory.representation#number-of-slots\376\003\000\000\002\376\001"
"\000\0002\001chicken.memory.representation#make-record-instance\376\003\000\000\002\376\001\000\000\047\001chicken.memory."
"representation#block-ref\376\003\000\000\002\376\001\000\000(\001chicken.memory.representation#block-set!\376\003\000\000\002"
"\376\001\000\000\035\001chicken.locative#locative-ref\376\003\000\000\002\376\001\000\000\036\001chicken.locative#locative-set!\376\003\000\000"
"\002\376\001\000\000!\001chicken.locative#locative->object\376\003\000\000\002\376\001\000\000\032\001chicken.locative#locative\077\376\003\000"
"\000\002\376\001\000\000\027\001chicken.memory#pointer+\376\003\000\000\002\376\001\000\000\030\001chicken.memory#pointer=\077\376\003\000\000\002\376\001\000\000\037\001chi"
"cken.memory#address->pointer\376\003\000\000\002\376\001\000\000\037\001chicken.memory#pointer->address\376\003\000\000\002\376\001\000\000\036"
"\001chicken.memory#pointer->object\376\003\000\000\002\376\001\000\000\036\001chicken.memory#object->pointer\376\003\000\000\002\376\001\000"
"\000\035\001chicken.memory#pointer-u8-ref\376\003\000\000\002\376\001\000\000\035\001chicken.memory#pointer-s8-ref\376\003\000\000\002\376\001\000"
"\000\036\001chicken.memory#pointer-u16-ref\376\003\000\000\002\376\001\000\000\036\001chicken.memory#pointer-s16-ref\376\003\000\000\002\376"
"\001\000\000\036\001chicken.memory#pointer-u32-ref\376\003\000\000\002\376\001\000\000\036\001chicken.memory#pointer-s32-ref\376\003\000\000"
"\002\376\001\000\000\036\001chicken.memory#pointer-f32-ref\376\003\000\000\002\376\001\000\000\036\001chicken.memory#pointer-f64-ref\376\003"
"\000\000\002\376\001\000\000\036\001chicken.memory#pointer-u8-set!\376\003\000\000\002\376\001\000\000\036\001chicken.memory#pointer-s8-set!"
"\376\003\000\000\002\376\001\000\000\037\001chicken.memory#pointer-u16-set!\376\003\000\000\002\376\001\000\000\037\001chicken.memory#pointer-s16-"
"set!\376\003\000\000\002\376\001\000\000\037\001chicken.memory#pointer-u32-set!\376\003\000\000\002\376\001\000\000\037\001chicken.memory#pointer-"
"s32-set!\376\003\000\000\002\376\001\000\000\037\001chicken.memory#pointer-f32-set!\376\003\000\000\002\376\001\000\000\037\001chicken.memory#poin"
"ter-f64-set!\376\003\000\000\002\376\001\000\000\036\001chicken.string#substring-index\376\003\000\000\002\376\001\000\000!\001chicken.string#s"
"ubstring-index-ci\376\003\000\000\002\376\001\000\000\032\001chicken.string#substring=\077\376\003\000\000\002\376\001\000\000\035\001chicken.string#"
"substring-ci=\077\376\003\000\000\002\376\001\000\000\026\001chicken.io#read-string\376\003\000\000\002\376\001\000\000\025\001chicken.format#format\376"
"\003\000\000\002\376\001\000\000\025\001chicken.format#printf\376\003\000\000\002\376\001\000\000\026\001chicken.format#sprintf\376\003\000\000\002\376\001\000\000\026\001chick"
"en.format#fprintf\376\377\016"));
lf[935]=C_h_intern(&lf[935],26, C_text("chicken.base#symbol-append"));
lf[936]=C_h_intern(&lf[936],7, C_text("scheme#"));
lf[937]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\003\001not\376\003\000\000\002\376\001\000\000\010\001boolean\077\376\003\000\000\002\376\001\000\000\005\001apply\376\003\000\000\002\376\001\000\000\036\001call-with-current-co"
"ntinuation\376\003\000\000\002\376\001\000\000\003\001eq\077\376\003\000\000\002\376\001\000\000\004\001eqv\077\376\003\000\000\002\376\001\000\000\006\001equal\077\376\003\000\000\002\376\001\000\000\005\001pair\077\376\003\000\000\002\376\001\000"
"\000\004\001cons\376\003\000\000\002\376\001\000\000\003\001car\376\003\000\000\002\376\001\000\000\003\001cdr\376\003\000\000\002\376\001\000\000\004\001caar\376\003\000\000\002\376\001\000\000\004\001cadr\376\003\000\000\002\376\001\000\000\004\001cdar"
"\376\003\000\000\002\376\001\000\000\004\001cddr\376\003\000\000\002\376\001\000\000\005\001caaar\376\003\000\000\002\376\001\000\000\005\001caadr\376\003\000\000\002\376\001\000\000\005\001cadar\376\003\000\000\002\376\001\000\000\005\001caddr\376"
"\003\000\000\002\376\001\000\000\005\001cdaar\376\003\000\000\002\376\001\000\000\005\001cdadr\376\003\000\000\002\376\001\000\000\005\001cddar\376\003\000\000\002\376\001\000\000\005\001cdddr\376\003\000\000\002\376\001\000\000\006\001caaaar"
"\376\003\000\000\002\376\001\000\000\006\001caaadr\376\003\000\000\002\376\001\000\000\006\001caadar\376\003\000\000\002\376\001\000\000\006\001caaddr\376\003\000\000\002\376\001\000\000\006\001cadaar\376\003\000\000\002\376\001\000\000\006\001c"
"adadr\376\003\000\000\002\376\001\000\000\006\001caddar\376\003\000\000\002\376\001\000\000\006\001cadddr\376\003\000\000\002\376\001\000\000\006\001cdaaar\376\003\000\000\002\376\001\000\000\006\001cdaadr\376\003\000\000\002\376\001"
"\000\000\006\001cdadar\376\003\000\000\002\376\001\000\000\006\001cdaddr\376\003\000\000\002\376\001\000\000\006\001cddaar\376\003\000\000\002\376\001\000\000\006\001cddadr\376\003\000\000\002\376\001\000\000\006\001cdddar\376\003"
"\000\000\002\376\001\000\000\006\001cddddr\376\003\000\000\002\376\001\000\000\010\001set-car!\376\003\000\000\002\376\001\000\000\010\001set-cdr!\376\003\000\000\002\376\001\000\000\005\001null\077\376\003\000\000\002\376\001\000\000\004\001"
"list\376\003\000\000\002\376\001\000\000\005\001list\077\376\003\000\000\002\376\001\000\000\006\001length\376\003\000\000\002\376\001\000\000\005\001zero\077\376\003\000\000\002\376\001\000\000\001\001\052\376\003\000\000\002\376\001\000\000\001\001-\376\003\000"
"\000\002\376\001\000\000\001\001+\376\003\000\000\002\376\001\000\000\001\001/\376\003\000\000\002\376\001\000\000\001\001-\376\003\000\000\002\376\001\000\000\001\001>\376\003\000\000\002\376\001\000\000\001\001<\376\003\000\000\002\376\001\000\000\002\001>=\376\003\000\000\002\376\001\000\000\002"
"\001<=\376\003\000\000\002\376\001\000\000\001\001=\376\003\000\000\002\376\001\000\000\023\001current-output-port\376\003\000\000\002\376\001\000\000\022\001current-input-port\376\003\000\000\002\376"
"\001\000\000\012\001write-char\376\003\000\000\002\376\001\000\000\007\001newline\376\003\000\000\002\376\001\000\000\005\001write\376\003\000\000\002\376\001\000\000\007\001display\376\003\000\000\002\376\001\000\000\006\001ap"
"pend\376\003\000\000\002\376\001\000\000\016\001symbol->string\376\003\000\000\002\376\001\000\000\010\001for-each\376\003\000\000\002\376\001\000\000\003\001map\376\003\000\000\002\376\001\000\000\005\001char\077\376\003"
"\000\000\002\376\001\000\000\015\001char->integer\376\003\000\000\002\376\001\000\000\015\001integer->char\376\003\000\000\002\376\001\000\000\013\001eof-object\077\376\003\000\000\002\376\001\000\000\015\001v"
"ector-length\376\003\000\000\002\376\001\000\000\015\001string-length\376\003\000\000\002\376\001\000\000\012\001string-ref\376\003\000\000\002\376\001\000\000\013\001string-set!\376"
"\003\000\000\002\376\001\000\000\012\001vector-ref\376\003\000\000\002\376\001\000\000\013\001vector-set!\376\003\000\000\002\376\001\000\000\006\001char=\077\376\003\000\000\002\376\001\000\000\006\001char<\077\376\003\000\000"
"\002\376\001\000\000\006\001char>\077\376\003\000\000\002\376\001\000\000\007\001char>=\077\376\003\000\000\002\376\001\000\000\007\001char<=\077\376\003\000\000\002\376\001\000\000\003\001gcd\376\003\000\000\002\376\001\000\000\003\001lcm\376\003\000"
"\000\002\376\001\000\000\007\001reverse\376\003\000\000\002\376\001\000\000\007\001symbol\077\376\003\000\000\002\376\001\000\000\016\001string->symbol\376\003\000\000\002\376\001\000\000\007\001number\077\376\003\000\000"
"\002\376\001\000\000\010\001complex\077\376\003\000\000\002\376\001\000\000\005\001real\077\376\003\000\000\002\376\001\000\000\010\001integer\077\376\003\000\000\002\376\001\000\000\011\001rational\077\376\003\000\000\002\376\001\000\000\004"
"\001odd\077\376\003\000\000\002\376\001\000\000\005\001even\077\376\003\000\000\002\376\001\000\000\011\001positive\077\376\003\000\000\002\376\001\000\000\011\001negative\077\376\003\000\000\002\376\001\000\000\006\001exact\077\376\003"
"\000\000\002\376\001\000\000\010\001inexact\077\376\003\000\000\002\376\001\000\000\003\001max\376\003\000\000\002\376\001\000\000\003\001min\376\003\000\000\002\376\001\000\000\010\001quotient\376\003\000\000\002\376\001\000\000\011\001remai"
"nder\376\003\000\000\002\376\001\000\000\006\001modulo\376\003\000\000\002\376\001\000\000\005\001floor\376\003\000\000\002\376\001\000\000\007\001ceiling\376\003\000\000\002\376\001\000\000\010\001truncate\376\003\000\000\002\376"
"\001\000\000\005\001round\376\003\000\000\002\376\001\000\000\013\001rationalize\376\003\000\000\002\376\001\000\000\016\001exact->inexact\376\003\000\000\002\376\001\000\000\016\001inexact->exa"
"ct\376\003\000\000\002\376\001\000\000\003\001exp\376\003\000\000\002\376\001\000\000\003\001log\376\003\000\000\002\376\001\000\000\003\001sin\376\003\000\000\002\376\001\000\000\004\001expt\376\003\000\000\002\376\001\000\000\004\001sqrt\376\003\000\000\002\376"
"\001\000\000\003\001cos\376\003\000\000\002\376\001\000\000\003\001tan\376\003\000\000\002\376\001\000\000\004\001asin\376\003\000\000\002\376\001\000\000\004\001acos\376\003\000\000\002\376\001\000\000\004\001atan\376\003\000\000\002\376\001\000\000\016\001nu"
"mber->string\376\003\000\000\002\376\001\000\000\016\001string->number\376\003\000\000\002\376\001\000\000\011\001char-ci=\077\376\003\000\000\002\376\001\000\000\011\001char-ci<\077\376\003\000"
"\000\002\376\001\000\000\011\001char-ci>\077\376\003\000\000\002\376\001\000\000\012\001char-ci>=\077\376\003\000\000\002\376\001\000\000\012\001char-ci<=\077\376\003\000\000\002\376\001\000\000\020\001char-alpha"
"betic\077\376\003\000\000\002\376\001\000\000\020\001char-whitespace\077\376\003\000\000\002\376\001\000\000\015\001char-numeric\077\376\003\000\000\002\376\001\000\000\020\001char-lower-c"
"ase\077\376\003\000\000\002\376\001\000\000\020\001char-upper-case\077\376\003\000\000\002\376\001\000\000\013\001char-upcase\376\003\000\000\002\376\001\000\000\015\001char-downcase\376\003\000"
"\000\002\376\001\000\000\007\001string\077\376\003\000\000\002\376\001\000\000\010\001string=\077\376\003\000\000\002\376\001\000\000\010\001string>\077\376\003\000\000\002\376\001\000\000\010\001string<\077\376\003\000\000\002\376\001\000"
"\000\011\001string>=\077\376\003\000\000\002\376\001\000\000\011\001string<=\077\376\003\000\000\002\376\001\000\000\013\001string-ci=\077\376\003\000\000\002\376\001\000\000\013\001string-ci<\077\376\003\000\000"
"\002\376\001\000\000\013\001string-ci>\077\376\003\000\000\002\376\001\000\000\014\001string-ci<=\077\376\003\000\000\002\376\001\000\000\014\001string-ci>=\077\376\003\000\000\002\376\001\000\000\015\001strin"
"g-append\376\003\000\000\002\376\001\000\000\014\001string->list\376\003\000\000\002\376\001\000\000\014\001list->string\376\003\000\000\002\376\001\000\000\007\001vector\077\376\003\000\000\002\376\001\000"
"\000\014\001vector->list\376\003\000\000\002\376\001\000\000\014\001list->vector\376\003\000\000\002\376\001\000\000\006\001string\376\003\000\000\002\376\001\000\000\004\001read\376\003\000\000\002\376\001\000\000\011"
"\001read-char\376\003\000\000\002\376\001\000\000\011\001substring\376\003\000\000\002\376\001\000\000\014\001string-fill!\376\003\000\000\002\376\001\000\000\014\001vector-copy!\376\003\000\000"
"\002\376\001\000\000\014\001vector-fill!\376\003\000\000\002\376\001\000\000\013\001make-string\376\003\000\000\002\376\001\000\000\013\001make-vector\376\003\000\000\002\376\001\000\000\017\001open-i"
"nput-file\376\003\000\000\002\376\001\000\000\020\001open-output-file\376\003\000\000\002\376\001\000\000\024\001call-with-input-file\376\003\000\000\002\376\001\000\000\025\001ca"
"ll-with-output-file\376\003\000\000\002\376\001\000\000\020\001close-input-port\376\003\000\000\002\376\001\000\000\021\001close-output-port\376\003\000\000\002\376"
"\001\000\000\006\001values\376\003\000\000\002\376\001\000\000\020\001call-with-values\376\003\000\000\002\376\001\000\000\006\001vector\376\003\000\000\002\376\001\000\000\012\001procedure\077\376\003\000\000"
"\002\376\001\000\000\004\001memq\376\003\000\000\002\376\001\000\000\004\001memv\376\003\000\000\002\376\001\000\000\006\001member\376\003\000\000\002\376\001\000\000\004\001assq\376\003\000\000\002\376\001\000\000\004\001assv\376\003\000\000\002\376\001"
"\000\000\005\001assoc\376\003\000\000\002\376\001\000\000\011\001list-tail\376\003\000\000\002\376\001\000\000\010\001list-ref\376\003\000\000\002\376\001\000\000\003\001abs\376\003\000\000\002\376\001\000\000\013\001char-re"
"ady\077\376\003\000\000\002\376\001\000\000\011\001peek-char\376\003\000\000\002\376\001\000\000\014\001list->string\376\003\000\000\002\376\001\000\000\014\001string->list\376\003\000\000\002\376\001\000\000\022"
"\001current-input-port\376\003\000\000\002\376\001\000\000\023\001current-output-port\376\003\000\000\002\376\001\000\000\012\001make-polar\376\003\000\000\002\376\001\000\000\020"
"\001make-rectangular\376\003\000\000\002\376\001\000\000\011\001real-part\376\003\000\000\002\376\001\000\000\011\001imag-part\376\003\000\000\002\376\001\000\000\004\001load\376\003\000\000\002\376\001\000"
"\000\004\001eval\376\003\000\000\002\376\001\000\000\027\001interaction-environment\376\003\000\000\002\376\001\000\000\020\001null-environment\376\003\000\000\002\376\001\000\000\031\001s"
"cheme-report-environment\376\377\016"));
lf[938]=C_h_intern(&lf[938],50, C_text("chicken.compiler.optimizer#membership-unfold-limit"));
lf[939]=C_h_intern(&lf[939],52, C_text("chicken.compiler.optimizer#membership-test-operators"));
lf[940]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376B\000\000\010C_i_memq\376B\000\000\005C_eqp\376\003\000\000\002\376\003\000\000\002\376B\000\000\012C_u_i_memq\376B\000\000\005C_eqp\376\003\000\000\002\376\003\000\000\002\376B"
"\000\000\012C_i_member\376B\000\000\012C_i_equalp\376\003\000\000\002\376\003\000\000\002\376B\000\000\010C_i_memv\376B\000\000\010C_i_eqvp\376\377\016"));
lf[941]=C_h_intern(&lf[941],45, C_text("chicken.compiler.optimizer#eq-inline-operator"));
lf[942]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005C_eqp"));
lf[943]=C_h_intern(&lf[943],54, C_text("chicken.compiler.optimizer#default-optimization-passes"));
C_register_lf2(lf,944,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1664,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[673] = {
{C_text("f_1664:c_2dplatform_2escm"),(void*)f_1664},
{C_text("f_1667:c_2dplatform_2escm"),(void*)f_1667},
{C_text("f_1670:c_2dplatform_2escm"),(void*)f_1670},
{C_text("f_1673:c_2dplatform_2escm"),(void*)f_1673},
{C_text("f_1676:c_2dplatform_2escm"),(void*)f_1676},
{C_text("f_1679:c_2dplatform_2escm"),(void*)f_1679},
{C_text("f_1682:c_2dplatform_2escm"),(void*)f_1682},
{C_text("f_2117:c_2dplatform_2escm"),(void*)f_2117},
{C_text("f_2123:c_2dplatform_2escm"),(void*)f_2123},
{C_text("f_2137:c_2dplatform_2escm"),(void*)f_2137},
{C_text("f_2293:c_2dplatform_2escm"),(void*)f_2293},
{C_text("f_2302:c_2dplatform_2escm"),(void*)f_2302},
{C_text("f_2310:c_2dplatform_2escm"),(void*)f_2310},
{C_text("f_2317:c_2dplatform_2escm"),(void*)f_2317},
{C_text("f_2331:c_2dplatform_2escm"),(void*)f_2331},
{C_text("f_2459:c_2dplatform_2escm"),(void*)f_2459},
{C_text("f_2701:c_2dplatform_2escm"),(void*)f_2701},
{C_text("f_2715:c_2dplatform_2escm"),(void*)f_2715},
{C_text("f_2719:c_2dplatform_2escm"),(void*)f_2719},
{C_text("f_2963:c_2dplatform_2escm"),(void*)f_2963},
{C_text("f_2970:c_2dplatform_2escm"),(void*)f_2970},
{C_text("f_2973:c_2dplatform_2escm"),(void*)f_2973},
{C_text("f_2976:c_2dplatform_2escm"),(void*)f_2976},
{C_text("f_2991:c_2dplatform_2escm"),(void*)f_2991},
{C_text("f_2998:c_2dplatform_2escm"),(void*)f_2998},
{C_text("f_3007:c_2dplatform_2escm"),(void*)f_3007},
{C_text("f_3009:c_2dplatform_2escm"),(void*)f_3009},
{C_text("f_3011:c_2dplatform_2escm"),(void*)f_3011},
{C_text("f_3033:c_2dplatform_2escm"),(void*)f_3033},
{C_text("f_3066:c_2dplatform_2escm"),(void*)f_3066},
{C_text("f_3074:c_2dplatform_2escm"),(void*)f_3074},
{C_text("f_3077:c_2dplatform_2escm"),(void*)f_3077},
{C_text("f_3079:c_2dplatform_2escm"),(void*)f_3079},
{C_text("f_3095:c_2dplatform_2escm"),(void*)f_3095},
{C_text("f_3104:c_2dplatform_2escm"),(void*)f_3104},
{C_text("f_3107:c_2dplatform_2escm"),(void*)f_3107},
{C_text("f_3122:c_2dplatform_2escm"),(void*)f_3122},
{C_text("f_3134:c_2dplatform_2escm"),(void*)f_3134},
{C_text("f_3148:c_2dplatform_2escm"),(void*)f_3148},
{C_text("f_3152:c_2dplatform_2escm"),(void*)f_3152},
{C_text("f_3161:c_2dplatform_2escm"),(void*)f_3161},
{C_text("f_3175:c_2dplatform_2escm"),(void*)f_3175},
{C_text("f_3179:c_2dplatform_2escm"),(void*)f_3179},
{C_text("f_3209:c_2dplatform_2escm"),(void*)f_3209},
{C_text("f_3213:c_2dplatform_2escm"),(void*)f_3213},
{C_text("f_3217:c_2dplatform_2escm"),(void*)f_3217},
{C_text("f_3221:c_2dplatform_2escm"),(void*)f_3221},
{C_text("f_3225:c_2dplatform_2escm"),(void*)f_3225},
{C_text("f_3233:c_2dplatform_2escm"),(void*)f_3233},
{C_text("f_3236:c_2dplatform_2escm"),(void*)f_3236},
{C_text("f_3239:c_2dplatform_2escm"),(void*)f_3239},
{C_text("f_3241:c_2dplatform_2escm"),(void*)f_3241},
{C_text("f_3269:c_2dplatform_2escm"),(void*)f_3269},
{C_text("f_3277:c_2dplatform_2escm"),(void*)f_3277},
{C_text("f_3294:c_2dplatform_2escm"),(void*)f_3294},
{C_text("f_3296:c_2dplatform_2escm"),(void*)f_3296},
{C_text("f_3321:c_2dplatform_2escm"),(void*)f_3321},
{C_text("f_3332:c_2dplatform_2escm"),(void*)f_3332},
{C_text("f_3336:c_2dplatform_2escm"),(void*)f_3336},
{C_text("f_3339:c_2dplatform_2escm"),(void*)f_3339},
{C_text("f_3353:c_2dplatform_2escm"),(void*)f_3353},
{C_text("f_3357:c_2dplatform_2escm"),(void*)f_3357},
{C_text("f_3380:c_2dplatform_2escm"),(void*)f_3380},
{C_text("f_3395:c_2dplatform_2escm"),(void*)f_3395},
{C_text("f_3403:c_2dplatform_2escm"),(void*)f_3403},
{C_text("f_3412:c_2dplatform_2escm"),(void*)f_3412},
{C_text("f_3416:c_2dplatform_2escm"),(void*)f_3416},
{C_text("f_3419:c_2dplatform_2escm"),(void*)f_3419},
{C_text("f_3422:c_2dplatform_2escm"),(void*)f_3422},
{C_text("f_3424:c_2dplatform_2escm"),(void*)f_3424},
{C_text("f_3430:c_2dplatform_2escm"),(void*)f_3430},
{C_text("f_3442:c_2dplatform_2escm"),(void*)f_3442},
{C_text("f_3461:c_2dplatform_2escm"),(void*)f_3461},
{C_text("f_3492:c_2dplatform_2escm"),(void*)f_3492},
{C_text("f_3495:c_2dplatform_2escm"),(void*)f_3495},
{C_text("f_3498:c_2dplatform_2escm"),(void*)f_3498},
{C_text("f_3501:c_2dplatform_2escm"),(void*)f_3501},
{C_text("f_3504:c_2dplatform_2escm"),(void*)f_3504},
{C_text("f_3507:c_2dplatform_2escm"),(void*)f_3507},
{C_text("f_3508:c_2dplatform_2escm"),(void*)f_3508},
{C_text("f_3534:c_2dplatform_2escm"),(void*)f_3534},
{C_text("f_3537:c_2dplatform_2escm"),(void*)f_3537},
{C_text("f_3539:c_2dplatform_2escm"),(void*)f_3539},
{C_text("f_3573:c_2dplatform_2escm"),(void*)f_3573},
{C_text("f_3600:c_2dplatform_2escm"),(void*)f_3600},
{C_text("f_3603:c_2dplatform_2escm"),(void*)f_3603},
{C_text("f_3606:c_2dplatform_2escm"),(void*)f_3606},
{C_text("f_3621:c_2dplatform_2escm"),(void*)f_3621},
{C_text("f_3625:c_2dplatform_2escm"),(void*)f_3625},
{C_text("f_3637:c_2dplatform_2escm"),(void*)f_3637},
{C_text("f_3649:c_2dplatform_2escm"),(void*)f_3649},
{C_text("f_3661:c_2dplatform_2escm"),(void*)f_3661},
{C_text("f_3665:c_2dplatform_2escm"),(void*)f_3665},
{C_text("f_3673:c_2dplatform_2escm"),(void*)f_3673},
{C_text("f_3680:c_2dplatform_2escm"),(void*)f_3680},
{C_text("f_3684:c_2dplatform_2escm"),(void*)f_3684},
{C_text("f_3688:c_2dplatform_2escm"),(void*)f_3688},
{C_text("f_3692:c_2dplatform_2escm"),(void*)f_3692},
{C_text("f_3696:c_2dplatform_2escm"),(void*)f_3696},
{C_text("f_3704:c_2dplatform_2escm"),(void*)f_3704},
{C_text("f_3707:c_2dplatform_2escm"),(void*)f_3707},
{C_text("f_3710:c_2dplatform_2escm"),(void*)f_3710},
{C_text("f_3713:c_2dplatform_2escm"),(void*)f_3713},
{C_text("f_3716:c_2dplatform_2escm"),(void*)f_3716},
{C_text("f_3719:c_2dplatform_2escm"),(void*)f_3719},
{C_text("f_3722:c_2dplatform_2escm"),(void*)f_3722},
{C_text("f_3725:c_2dplatform_2escm"),(void*)f_3725},
{C_text("f_3728:c_2dplatform_2escm"),(void*)f_3728},
{C_text("f_3731:c_2dplatform_2escm"),(void*)f_3731},
{C_text("f_3734:c_2dplatform_2escm"),(void*)f_3734},
{C_text("f_3737:c_2dplatform_2escm"),(void*)f_3737},
{C_text("f_3740:c_2dplatform_2escm"),(void*)f_3740},
{C_text("f_3743:c_2dplatform_2escm"),(void*)f_3743},
{C_text("f_3746:c_2dplatform_2escm"),(void*)f_3746},
{C_text("f_3749:c_2dplatform_2escm"),(void*)f_3749},
{C_text("f_3752:c_2dplatform_2escm"),(void*)f_3752},
{C_text("f_3755:c_2dplatform_2escm"),(void*)f_3755},
{C_text("f_3758:c_2dplatform_2escm"),(void*)f_3758},
{C_text("f_3761:c_2dplatform_2escm"),(void*)f_3761},
{C_text("f_3764:c_2dplatform_2escm"),(void*)f_3764},
{C_text("f_3767:c_2dplatform_2escm"),(void*)f_3767},
{C_text("f_3770:c_2dplatform_2escm"),(void*)f_3770},
{C_text("f_3773:c_2dplatform_2escm"),(void*)f_3773},
{C_text("f_3776:c_2dplatform_2escm"),(void*)f_3776},
{C_text("f_3779:c_2dplatform_2escm"),(void*)f_3779},
{C_text("f_3782:c_2dplatform_2escm"),(void*)f_3782},
{C_text("f_3785:c_2dplatform_2escm"),(void*)f_3785},
{C_text("f_3788:c_2dplatform_2escm"),(void*)f_3788},
{C_text("f_3791:c_2dplatform_2escm"),(void*)f_3791},
{C_text("f_3794:c_2dplatform_2escm"),(void*)f_3794},
{C_text("f_3797:c_2dplatform_2escm"),(void*)f_3797},
{C_text("f_3800:c_2dplatform_2escm"),(void*)f_3800},
{C_text("f_3803:c_2dplatform_2escm"),(void*)f_3803},
{C_text("f_3806:c_2dplatform_2escm"),(void*)f_3806},
{C_text("f_3809:c_2dplatform_2escm"),(void*)f_3809},
{C_text("f_3812:c_2dplatform_2escm"),(void*)f_3812},
{C_text("f_3815:c_2dplatform_2escm"),(void*)f_3815},
{C_text("f_3818:c_2dplatform_2escm"),(void*)f_3818},
{C_text("f_3821:c_2dplatform_2escm"),(void*)f_3821},
{C_text("f_3824:c_2dplatform_2escm"),(void*)f_3824},
{C_text("f_3827:c_2dplatform_2escm"),(void*)f_3827},
{C_text("f_3830:c_2dplatform_2escm"),(void*)f_3830},
{C_text("f_3833:c_2dplatform_2escm"),(void*)f_3833},
{C_text("f_3836:c_2dplatform_2escm"),(void*)f_3836},
{C_text("f_3839:c_2dplatform_2escm"),(void*)f_3839},
{C_text("f_3842:c_2dplatform_2escm"),(void*)f_3842},
{C_text("f_3845:c_2dplatform_2escm"),(void*)f_3845},
{C_text("f_3848:c_2dplatform_2escm"),(void*)f_3848},
{C_text("f_3851:c_2dplatform_2escm"),(void*)f_3851},
{C_text("f_3854:c_2dplatform_2escm"),(void*)f_3854},
{C_text("f_3857:c_2dplatform_2escm"),(void*)f_3857},
{C_text("f_3860:c_2dplatform_2escm"),(void*)f_3860},
{C_text("f_3863:c_2dplatform_2escm"),(void*)f_3863},
{C_text("f_3866:c_2dplatform_2escm"),(void*)f_3866},
{C_text("f_3869:c_2dplatform_2escm"),(void*)f_3869},
{C_text("f_3872:c_2dplatform_2escm"),(void*)f_3872},
{C_text("f_3875:c_2dplatform_2escm"),(void*)f_3875},
{C_text("f_3878:c_2dplatform_2escm"),(void*)f_3878},
{C_text("f_3881:c_2dplatform_2escm"),(void*)f_3881},
{C_text("f_3884:c_2dplatform_2escm"),(void*)f_3884},
{C_text("f_3887:c_2dplatform_2escm"),(void*)f_3887},
{C_text("f_3890:c_2dplatform_2escm"),(void*)f_3890},
{C_text("f_3893:c_2dplatform_2escm"),(void*)f_3893},
{C_text("f_3896:c_2dplatform_2escm"),(void*)f_3896},
{C_text("f_3899:c_2dplatform_2escm"),(void*)f_3899},
{C_text("f_3902:c_2dplatform_2escm"),(void*)f_3902},
{C_text("f_3905:c_2dplatform_2escm"),(void*)f_3905},
{C_text("f_3908:c_2dplatform_2escm"),(void*)f_3908},
{C_text("f_3911:c_2dplatform_2escm"),(void*)f_3911},
{C_text("f_3914:c_2dplatform_2escm"),(void*)f_3914},
{C_text("f_3917:c_2dplatform_2escm"),(void*)f_3917},
{C_text("f_3920:c_2dplatform_2escm"),(void*)f_3920},
{C_text("f_3923:c_2dplatform_2escm"),(void*)f_3923},
{C_text("f_3926:c_2dplatform_2escm"),(void*)f_3926},
{C_text("f_3929:c_2dplatform_2escm"),(void*)f_3929},
{C_text("f_3932:c_2dplatform_2escm"),(void*)f_3932},
{C_text("f_3935:c_2dplatform_2escm"),(void*)f_3935},
{C_text("f_3938:c_2dplatform_2escm"),(void*)f_3938},
{C_text("f_3941:c_2dplatform_2escm"),(void*)f_3941},
{C_text("f_3944:c_2dplatform_2escm"),(void*)f_3944},
{C_text("f_3947:c_2dplatform_2escm"),(void*)f_3947},
{C_text("f_3950:c_2dplatform_2escm"),(void*)f_3950},
{C_text("f_3953:c_2dplatform_2escm"),(void*)f_3953},
{C_text("f_3956:c_2dplatform_2escm"),(void*)f_3956},
{C_text("f_3959:c_2dplatform_2escm"),(void*)f_3959},
{C_text("f_3962:c_2dplatform_2escm"),(void*)f_3962},
{C_text("f_3965:c_2dplatform_2escm"),(void*)f_3965},
{C_text("f_3968:c_2dplatform_2escm"),(void*)f_3968},
{C_text("f_3971:c_2dplatform_2escm"),(void*)f_3971},
{C_text("f_3974:c_2dplatform_2escm"),(void*)f_3974},
{C_text("f_3977:c_2dplatform_2escm"),(void*)f_3977},
{C_text("f_3980:c_2dplatform_2escm"),(void*)f_3980},
{C_text("f_3983:c_2dplatform_2escm"),(void*)f_3983},
{C_text("f_3986:c_2dplatform_2escm"),(void*)f_3986},
{C_text("f_3989:c_2dplatform_2escm"),(void*)f_3989},
{C_text("f_3992:c_2dplatform_2escm"),(void*)f_3992},
{C_text("f_3995:c_2dplatform_2escm"),(void*)f_3995},
{C_text("f_3998:c_2dplatform_2escm"),(void*)f_3998},
{C_text("f_4001:c_2dplatform_2escm"),(void*)f_4001},
{C_text("f_4004:c_2dplatform_2escm"),(void*)f_4004},
{C_text("f_4007:c_2dplatform_2escm"),(void*)f_4007},
{C_text("f_4010:c_2dplatform_2escm"),(void*)f_4010},
{C_text("f_4013:c_2dplatform_2escm"),(void*)f_4013},
{C_text("f_4016:c_2dplatform_2escm"),(void*)f_4016},
{C_text("f_4019:c_2dplatform_2escm"),(void*)f_4019},
{C_text("f_4022:c_2dplatform_2escm"),(void*)f_4022},
{C_text("f_4025:c_2dplatform_2escm"),(void*)f_4025},
{C_text("f_4028:c_2dplatform_2escm"),(void*)f_4028},
{C_text("f_4031:c_2dplatform_2escm"),(void*)f_4031},
{C_text("f_4034:c_2dplatform_2escm"),(void*)f_4034},
{C_text("f_4037:c_2dplatform_2escm"),(void*)f_4037},
{C_text("f_4040:c_2dplatform_2escm"),(void*)f_4040},
{C_text("f_4043:c_2dplatform_2escm"),(void*)f_4043},
{C_text("f_4046:c_2dplatform_2escm"),(void*)f_4046},
{C_text("f_4049:c_2dplatform_2escm"),(void*)f_4049},
{C_text("f_4052:c_2dplatform_2escm"),(void*)f_4052},
{C_text("f_4055:c_2dplatform_2escm"),(void*)f_4055},
{C_text("f_4058:c_2dplatform_2escm"),(void*)f_4058},
{C_text("f_4061:c_2dplatform_2escm"),(void*)f_4061},
{C_text("f_4064:c_2dplatform_2escm"),(void*)f_4064},
{C_text("f_4067:c_2dplatform_2escm"),(void*)f_4067},
{C_text("f_4070:c_2dplatform_2escm"),(void*)f_4070},
{C_text("f_4073:c_2dplatform_2escm"),(void*)f_4073},
{C_text("f_4076:c_2dplatform_2escm"),(void*)f_4076},
{C_text("f_4079:c_2dplatform_2escm"),(void*)f_4079},
{C_text("f_4082:c_2dplatform_2escm"),(void*)f_4082},
{C_text("f_4085:c_2dplatform_2escm"),(void*)f_4085},
{C_text("f_4088:c_2dplatform_2escm"),(void*)f_4088},
{C_text("f_4091:c_2dplatform_2escm"),(void*)f_4091},
{C_text("f_4094:c_2dplatform_2escm"),(void*)f_4094},
{C_text("f_4097:c_2dplatform_2escm"),(void*)f_4097},
{C_text("f_4100:c_2dplatform_2escm"),(void*)f_4100},
{C_text("f_4103:c_2dplatform_2escm"),(void*)f_4103},
{C_text("f_4106:c_2dplatform_2escm"),(void*)f_4106},
{C_text("f_4109:c_2dplatform_2escm"),(void*)f_4109},
{C_text("f_4112:c_2dplatform_2escm"),(void*)f_4112},
{C_text("f_4115:c_2dplatform_2escm"),(void*)f_4115},
{C_text("f_4118:c_2dplatform_2escm"),(void*)f_4118},
{C_text("f_4121:c_2dplatform_2escm"),(void*)f_4121},
{C_text("f_4124:c_2dplatform_2escm"),(void*)f_4124},
{C_text("f_4127:c_2dplatform_2escm"),(void*)f_4127},
{C_text("f_4130:c_2dplatform_2escm"),(void*)f_4130},
{C_text("f_4133:c_2dplatform_2escm"),(void*)f_4133},
{C_text("f_4136:c_2dplatform_2escm"),(void*)f_4136},
{C_text("f_4139:c_2dplatform_2escm"),(void*)f_4139},
{C_text("f_4142:c_2dplatform_2escm"),(void*)f_4142},
{C_text("f_4145:c_2dplatform_2escm"),(void*)f_4145},
{C_text("f_4148:c_2dplatform_2escm"),(void*)f_4148},
{C_text("f_4151:c_2dplatform_2escm"),(void*)f_4151},
{C_text("f_4154:c_2dplatform_2escm"),(void*)f_4154},
{C_text("f_4157:c_2dplatform_2escm"),(void*)f_4157},
{C_text("f_4160:c_2dplatform_2escm"),(void*)f_4160},
{C_text("f_4163:c_2dplatform_2escm"),(void*)f_4163},
{C_text("f_4166:c_2dplatform_2escm"),(void*)f_4166},
{C_text("f_4169:c_2dplatform_2escm"),(void*)f_4169},
{C_text("f_4172:c_2dplatform_2escm"),(void*)f_4172},
{C_text("f_4175:c_2dplatform_2escm"),(void*)f_4175},
{C_text("f_4178:c_2dplatform_2escm"),(void*)f_4178},
{C_text("f_4181:c_2dplatform_2escm"),(void*)f_4181},
{C_text("f_4184:c_2dplatform_2escm"),(void*)f_4184},
{C_text("f_4187:c_2dplatform_2escm"),(void*)f_4187},
{C_text("f_4190:c_2dplatform_2escm"),(void*)f_4190},
{C_text("f_4193:c_2dplatform_2escm"),(void*)f_4193},
{C_text("f_4196:c_2dplatform_2escm"),(void*)f_4196},
{C_text("f_4199:c_2dplatform_2escm"),(void*)f_4199},
{C_text("f_4202:c_2dplatform_2escm"),(void*)f_4202},
{C_text("f_4205:c_2dplatform_2escm"),(void*)f_4205},
{C_text("f_4208:c_2dplatform_2escm"),(void*)f_4208},
{C_text("f_4211:c_2dplatform_2escm"),(void*)f_4211},
{C_text("f_4214:c_2dplatform_2escm"),(void*)f_4214},
{C_text("f_4217:c_2dplatform_2escm"),(void*)f_4217},
{C_text("f_4220:c_2dplatform_2escm"),(void*)f_4220},
{C_text("f_4223:c_2dplatform_2escm"),(void*)f_4223},
{C_text("f_4226:c_2dplatform_2escm"),(void*)f_4226},
{C_text("f_4229:c_2dplatform_2escm"),(void*)f_4229},
{C_text("f_4232:c_2dplatform_2escm"),(void*)f_4232},
{C_text("f_4235:c_2dplatform_2escm"),(void*)f_4235},
{C_text("f_4238:c_2dplatform_2escm"),(void*)f_4238},
{C_text("f_4241:c_2dplatform_2escm"),(void*)f_4241},
{C_text("f_4244:c_2dplatform_2escm"),(void*)f_4244},
{C_text("f_4247:c_2dplatform_2escm"),(void*)f_4247},
{C_text("f_4250:c_2dplatform_2escm"),(void*)f_4250},
{C_text("f_4253:c_2dplatform_2escm"),(void*)f_4253},
{C_text("f_4256:c_2dplatform_2escm"),(void*)f_4256},
{C_text("f_4259:c_2dplatform_2escm"),(void*)f_4259},
{C_text("f_4262:c_2dplatform_2escm"),(void*)f_4262},
{C_text("f_4265:c_2dplatform_2escm"),(void*)f_4265},
{C_text("f_4268:c_2dplatform_2escm"),(void*)f_4268},
{C_text("f_4271:c_2dplatform_2escm"),(void*)f_4271},
{C_text("f_4274:c_2dplatform_2escm"),(void*)f_4274},
{C_text("f_4277:c_2dplatform_2escm"),(void*)f_4277},
{C_text("f_4280:c_2dplatform_2escm"),(void*)f_4280},
{C_text("f_4283:c_2dplatform_2escm"),(void*)f_4283},
{C_text("f_4286:c_2dplatform_2escm"),(void*)f_4286},
{C_text("f_4289:c_2dplatform_2escm"),(void*)f_4289},
{C_text("f_4292:c_2dplatform_2escm"),(void*)f_4292},
{C_text("f_4295:c_2dplatform_2escm"),(void*)f_4295},
{C_text("f_4298:c_2dplatform_2escm"),(void*)f_4298},
{C_text("f_4301:c_2dplatform_2escm"),(void*)f_4301},
{C_text("f_4304:c_2dplatform_2escm"),(void*)f_4304},
{C_text("f_4307:c_2dplatform_2escm"),(void*)f_4307},
{C_text("f_4310:c_2dplatform_2escm"),(void*)f_4310},
{C_text("f_4313:c_2dplatform_2escm"),(void*)f_4313},
{C_text("f_4316:c_2dplatform_2escm"),(void*)f_4316},
{C_text("f_4319:c_2dplatform_2escm"),(void*)f_4319},
{C_text("f_4322:c_2dplatform_2escm"),(void*)f_4322},
{C_text("f_4325:c_2dplatform_2escm"),(void*)f_4325},
{C_text("f_4328:c_2dplatform_2escm"),(void*)f_4328},
{C_text("f_4331:c_2dplatform_2escm"),(void*)f_4331},
{C_text("f_4334:c_2dplatform_2escm"),(void*)f_4334},
{C_text("f_4337:c_2dplatform_2escm"),(void*)f_4337},
{C_text("f_4340:c_2dplatform_2escm"),(void*)f_4340},
{C_text("f_4343:c_2dplatform_2escm"),(void*)f_4343},
{C_text("f_4346:c_2dplatform_2escm"),(void*)f_4346},
{C_text("f_4349:c_2dplatform_2escm"),(void*)f_4349},
{C_text("f_4352:c_2dplatform_2escm"),(void*)f_4352},
{C_text("f_4355:c_2dplatform_2escm"),(void*)f_4355},
{C_text("f_4358:c_2dplatform_2escm"),(void*)f_4358},
{C_text("f_4361:c_2dplatform_2escm"),(void*)f_4361},
{C_text("f_4364:c_2dplatform_2escm"),(void*)f_4364},
{C_text("f_4367:c_2dplatform_2escm"),(void*)f_4367},
{C_text("f_4370:c_2dplatform_2escm"),(void*)f_4370},
{C_text("f_4373:c_2dplatform_2escm"),(void*)f_4373},
{C_text("f_4376:c_2dplatform_2escm"),(void*)f_4376},
{C_text("f_4379:c_2dplatform_2escm"),(void*)f_4379},
{C_text("f_4382:c_2dplatform_2escm"),(void*)f_4382},
{C_text("f_4385:c_2dplatform_2escm"),(void*)f_4385},
{C_text("f_4388:c_2dplatform_2escm"),(void*)f_4388},
{C_text("f_4391:c_2dplatform_2escm"),(void*)f_4391},
{C_text("f_4394:c_2dplatform_2escm"),(void*)f_4394},
{C_text("f_4397:c_2dplatform_2escm"),(void*)f_4397},
{C_text("f_4400:c_2dplatform_2escm"),(void*)f_4400},
{C_text("f_4403:c_2dplatform_2escm"),(void*)f_4403},
{C_text("f_4406:c_2dplatform_2escm"),(void*)f_4406},
{C_text("f_4409:c_2dplatform_2escm"),(void*)f_4409},
{C_text("f_4412:c_2dplatform_2escm"),(void*)f_4412},
{C_text("f_4415:c_2dplatform_2escm"),(void*)f_4415},
{C_text("f_4418:c_2dplatform_2escm"),(void*)f_4418},
{C_text("f_4421:c_2dplatform_2escm"),(void*)f_4421},
{C_text("f_4424:c_2dplatform_2escm"),(void*)f_4424},
{C_text("f_4427:c_2dplatform_2escm"),(void*)f_4427},
{C_text("f_4430:c_2dplatform_2escm"),(void*)f_4430},
{C_text("f_4433:c_2dplatform_2escm"),(void*)f_4433},
{C_text("f_4436:c_2dplatform_2escm"),(void*)f_4436},
{C_text("f_4439:c_2dplatform_2escm"),(void*)f_4439},
{C_text("f_4442:c_2dplatform_2escm"),(void*)f_4442},
{C_text("f_4444:c_2dplatform_2escm"),(void*)f_4444},
{C_text("f_4481:c_2dplatform_2escm"),(void*)f_4481},
{C_text("f_4483:c_2dplatform_2escm"),(void*)f_4483},
{C_text("f_4490:c_2dplatform_2escm"),(void*)f_4490},
{C_text("f_4501:c_2dplatform_2escm"),(void*)f_4501},
{C_text("f_4522:c_2dplatform_2escm"),(void*)f_4522},
{C_text("f_4526:c_2dplatform_2escm"),(void*)f_4526},
{C_text("f_4539:c_2dplatform_2escm"),(void*)f_4539},
{C_text("f_4541:c_2dplatform_2escm"),(void*)f_4541},
{C_text("f_4563:c_2dplatform_2escm"),(void*)f_4563},
{C_text("f_4567:c_2dplatform_2escm"),(void*)f_4567},
{C_text("f_4577:c_2dplatform_2escm"),(void*)f_4577},
{C_text("f_4580:c_2dplatform_2escm"),(void*)f_4580},
{C_text("f_4583:c_2dplatform_2escm"),(void*)f_4583},
{C_text("f_4586:c_2dplatform_2escm"),(void*)f_4586},
{C_text("f_4589:c_2dplatform_2escm"),(void*)f_4589},
{C_text("f_4592:c_2dplatform_2escm"),(void*)f_4592},
{C_text("f_4595:c_2dplatform_2escm"),(void*)f_4595},
{C_text("f_4598:c_2dplatform_2escm"),(void*)f_4598},
{C_text("f_4601:c_2dplatform_2escm"),(void*)f_4601},
{C_text("f_4604:c_2dplatform_2escm"),(void*)f_4604},
{C_text("f_4607:c_2dplatform_2escm"),(void*)f_4607},
{C_text("f_4610:c_2dplatform_2escm"),(void*)f_4610},
{C_text("f_4613:c_2dplatform_2escm"),(void*)f_4613},
{C_text("f_4616:c_2dplatform_2escm"),(void*)f_4616},
{C_text("f_4619:c_2dplatform_2escm"),(void*)f_4619},
{C_text("f_4622:c_2dplatform_2escm"),(void*)f_4622},
{C_text("f_4625:c_2dplatform_2escm"),(void*)f_4625},
{C_text("f_4628:c_2dplatform_2escm"),(void*)f_4628},
{C_text("f_4631:c_2dplatform_2escm"),(void*)f_4631},
{C_text("f_4634:c_2dplatform_2escm"),(void*)f_4634},
{C_text("f_4637:c_2dplatform_2escm"),(void*)f_4637},
{C_text("f_4640:c_2dplatform_2escm"),(void*)f_4640},
{C_text("f_4643:c_2dplatform_2escm"),(void*)f_4643},
{C_text("f_4646:c_2dplatform_2escm"),(void*)f_4646},
{C_text("f_4649:c_2dplatform_2escm"),(void*)f_4649},
{C_text("f_4652:c_2dplatform_2escm"),(void*)f_4652},
{C_text("f_4655:c_2dplatform_2escm"),(void*)f_4655},
{C_text("f_4658:c_2dplatform_2escm"),(void*)f_4658},
{C_text("f_4661:c_2dplatform_2escm"),(void*)f_4661},
{C_text("f_4664:c_2dplatform_2escm"),(void*)f_4664},
{C_text("f_4667:c_2dplatform_2escm"),(void*)f_4667},
{C_text("f_4670:c_2dplatform_2escm"),(void*)f_4670},
{C_text("f_4673:c_2dplatform_2escm"),(void*)f_4673},
{C_text("f_4676:c_2dplatform_2escm"),(void*)f_4676},
{C_text("f_4679:c_2dplatform_2escm"),(void*)f_4679},
{C_text("f_4682:c_2dplatform_2escm"),(void*)f_4682},
{C_text("f_4685:c_2dplatform_2escm"),(void*)f_4685},
{C_text("f_4688:c_2dplatform_2escm"),(void*)f_4688},
{C_text("f_4691:c_2dplatform_2escm"),(void*)f_4691},
{C_text("f_4694:c_2dplatform_2escm"),(void*)f_4694},
{C_text("f_4697:c_2dplatform_2escm"),(void*)f_4697},
{C_text("f_4700:c_2dplatform_2escm"),(void*)f_4700},
{C_text("f_4703:c_2dplatform_2escm"),(void*)f_4703},
{C_text("f_4706:c_2dplatform_2escm"),(void*)f_4706},
{C_text("f_4709:c_2dplatform_2escm"),(void*)f_4709},
{C_text("f_4712:c_2dplatform_2escm"),(void*)f_4712},
{C_text("f_4715:c_2dplatform_2escm"),(void*)f_4715},
{C_text("f_4718:c_2dplatform_2escm"),(void*)f_4718},
{C_text("f_4721:c_2dplatform_2escm"),(void*)f_4721},
{C_text("f_4724:c_2dplatform_2escm"),(void*)f_4724},
{C_text("f_4727:c_2dplatform_2escm"),(void*)f_4727},
{C_text("f_4730:c_2dplatform_2escm"),(void*)f_4730},
{C_text("f_4733:c_2dplatform_2escm"),(void*)f_4733},
{C_text("f_4736:c_2dplatform_2escm"),(void*)f_4736},
{C_text("f_4739:c_2dplatform_2escm"),(void*)f_4739},
{C_text("f_4742:c_2dplatform_2escm"),(void*)f_4742},
{C_text("f_4745:c_2dplatform_2escm"),(void*)f_4745},
{C_text("f_4748:c_2dplatform_2escm"),(void*)f_4748},
{C_text("f_4751:c_2dplatform_2escm"),(void*)f_4751},
{C_text("f_4754:c_2dplatform_2escm"),(void*)f_4754},
{C_text("f_4757:c_2dplatform_2escm"),(void*)f_4757},
{C_text("f_4760:c_2dplatform_2escm"),(void*)f_4760},
{C_text("f_4763:c_2dplatform_2escm"),(void*)f_4763},
{C_text("f_4766:c_2dplatform_2escm"),(void*)f_4766},
{C_text("f_4769:c_2dplatform_2escm"),(void*)f_4769},
{C_text("f_4772:c_2dplatform_2escm"),(void*)f_4772},
{C_text("f_4775:c_2dplatform_2escm"),(void*)f_4775},
{C_text("f_4778:c_2dplatform_2escm"),(void*)f_4778},
{C_text("f_4781:c_2dplatform_2escm"),(void*)f_4781},
{C_text("f_4784:c_2dplatform_2escm"),(void*)f_4784},
{C_text("f_4787:c_2dplatform_2escm"),(void*)f_4787},
{C_text("f_4790:c_2dplatform_2escm"),(void*)f_4790},
{C_text("f_4793:c_2dplatform_2escm"),(void*)f_4793},
{C_text("f_4796:c_2dplatform_2escm"),(void*)f_4796},
{C_text("f_4799:c_2dplatform_2escm"),(void*)f_4799},
{C_text("f_4802:c_2dplatform_2escm"),(void*)f_4802},
{C_text("f_4805:c_2dplatform_2escm"),(void*)f_4805},
{C_text("f_4808:c_2dplatform_2escm"),(void*)f_4808},
{C_text("f_4811:c_2dplatform_2escm"),(void*)f_4811},
{C_text("f_4814:c_2dplatform_2escm"),(void*)f_4814},
{C_text("f_4817:c_2dplatform_2escm"),(void*)f_4817},
{C_text("f_4820:c_2dplatform_2escm"),(void*)f_4820},
{C_text("f_4823:c_2dplatform_2escm"),(void*)f_4823},
{C_text("f_4826:c_2dplatform_2escm"),(void*)f_4826},
{C_text("f_4829:c_2dplatform_2escm"),(void*)f_4829},
{C_text("f_4832:c_2dplatform_2escm"),(void*)f_4832},
{C_text("f_4835:c_2dplatform_2escm"),(void*)f_4835},
{C_text("f_4838:c_2dplatform_2escm"),(void*)f_4838},
{C_text("f_4841:c_2dplatform_2escm"),(void*)f_4841},
{C_text("f_4844:c_2dplatform_2escm"),(void*)f_4844},
{C_text("f_4847:c_2dplatform_2escm"),(void*)f_4847},
{C_text("f_4850:c_2dplatform_2escm"),(void*)f_4850},
{C_text("f_4853:c_2dplatform_2escm"),(void*)f_4853},
{C_text("f_4856:c_2dplatform_2escm"),(void*)f_4856},
{C_text("f_4859:c_2dplatform_2escm"),(void*)f_4859},
{C_text("f_4862:c_2dplatform_2escm"),(void*)f_4862},
{C_text("f_4865:c_2dplatform_2escm"),(void*)f_4865},
{C_text("f_4868:c_2dplatform_2escm"),(void*)f_4868},
{C_text("f_4871:c_2dplatform_2escm"),(void*)f_4871},
{C_text("f_4874:c_2dplatform_2escm"),(void*)f_4874},
{C_text("f_4877:c_2dplatform_2escm"),(void*)f_4877},
{C_text("f_4880:c_2dplatform_2escm"),(void*)f_4880},
{C_text("f_4883:c_2dplatform_2escm"),(void*)f_4883},
{C_text("f_4886:c_2dplatform_2escm"),(void*)f_4886},
{C_text("f_4889:c_2dplatform_2escm"),(void*)f_4889},
{C_text("f_4892:c_2dplatform_2escm"),(void*)f_4892},
{C_text("f_4895:c_2dplatform_2escm"),(void*)f_4895},
{C_text("f_4898:c_2dplatform_2escm"),(void*)f_4898},
{C_text("f_4901:c_2dplatform_2escm"),(void*)f_4901},
{C_text("f_4904:c_2dplatform_2escm"),(void*)f_4904},
{C_text("f_4907:c_2dplatform_2escm"),(void*)f_4907},
{C_text("f_4910:c_2dplatform_2escm"),(void*)f_4910},
{C_text("f_4913:c_2dplatform_2escm"),(void*)f_4913},
{C_text("f_4916:c_2dplatform_2escm"),(void*)f_4916},
{C_text("f_4919:c_2dplatform_2escm"),(void*)f_4919},
{C_text("f_4922:c_2dplatform_2escm"),(void*)f_4922},
{C_text("f_4925:c_2dplatform_2escm"),(void*)f_4925},
{C_text("f_4928:c_2dplatform_2escm"),(void*)f_4928},
{C_text("f_4931:c_2dplatform_2escm"),(void*)f_4931},
{C_text("f_4934:c_2dplatform_2escm"),(void*)f_4934},
{C_text("f_4937:c_2dplatform_2escm"),(void*)f_4937},
{C_text("f_4940:c_2dplatform_2escm"),(void*)f_4940},
{C_text("f_4943:c_2dplatform_2escm"),(void*)f_4943},
{C_text("f_4946:c_2dplatform_2escm"),(void*)f_4946},
{C_text("f_4949:c_2dplatform_2escm"),(void*)f_4949},
{C_text("f_4952:c_2dplatform_2escm"),(void*)f_4952},
{C_text("f_4955:c_2dplatform_2escm"),(void*)f_4955},
{C_text("f_4958:c_2dplatform_2escm"),(void*)f_4958},
{C_text("f_4961:c_2dplatform_2escm"),(void*)f_4961},
{C_text("f_4964:c_2dplatform_2escm"),(void*)f_4964},
{C_text("f_4967:c_2dplatform_2escm"),(void*)f_4967},
{C_text("f_4970:c_2dplatform_2escm"),(void*)f_4970},
{C_text("f_4973:c_2dplatform_2escm"),(void*)f_4973},
{C_text("f_4976:c_2dplatform_2escm"),(void*)f_4976},
{C_text("f_4979:c_2dplatform_2escm"),(void*)f_4979},
{C_text("f_4982:c_2dplatform_2escm"),(void*)f_4982},
{C_text("f_4985:c_2dplatform_2escm"),(void*)f_4985},
{C_text("f_4988:c_2dplatform_2escm"),(void*)f_4988},
{C_text("f_4991:c_2dplatform_2escm"),(void*)f_4991},
{C_text("f_4994:c_2dplatform_2escm"),(void*)f_4994},
{C_text("f_4997:c_2dplatform_2escm"),(void*)f_4997},
{C_text("f_5000:c_2dplatform_2escm"),(void*)f_5000},
{C_text("f_5003:c_2dplatform_2escm"),(void*)f_5003},
{C_text("f_5006:c_2dplatform_2escm"),(void*)f_5006},
{C_text("f_5009:c_2dplatform_2escm"),(void*)f_5009},
{C_text("f_5012:c_2dplatform_2escm"),(void*)f_5012},
{C_text("f_5015:c_2dplatform_2escm"),(void*)f_5015},
{C_text("f_5018:c_2dplatform_2escm"),(void*)f_5018},
{C_text("f_5021:c_2dplatform_2escm"),(void*)f_5021},
{C_text("f_5024:c_2dplatform_2escm"),(void*)f_5024},
{C_text("f_5027:c_2dplatform_2escm"),(void*)f_5027},
{C_text("f_5030:c_2dplatform_2escm"),(void*)f_5030},
{C_text("f_5033:c_2dplatform_2escm"),(void*)f_5033},
{C_text("f_5036:c_2dplatform_2escm"),(void*)f_5036},
{C_text("f_5039:c_2dplatform_2escm"),(void*)f_5039},
{C_text("f_5042:c_2dplatform_2escm"),(void*)f_5042},
{C_text("f_5045:c_2dplatform_2escm"),(void*)f_5045},
{C_text("f_5048:c_2dplatform_2escm"),(void*)f_5048},
{C_text("f_5051:c_2dplatform_2escm"),(void*)f_5051},
{C_text("f_5054:c_2dplatform_2escm"),(void*)f_5054},
{C_text("f_5057:c_2dplatform_2escm"),(void*)f_5057},
{C_text("f_5060:c_2dplatform_2escm"),(void*)f_5060},
{C_text("f_5063:c_2dplatform_2escm"),(void*)f_5063},
{C_text("f_5066:c_2dplatform_2escm"),(void*)f_5066},
{C_text("f_5069:c_2dplatform_2escm"),(void*)f_5069},
{C_text("f_5072:c_2dplatform_2escm"),(void*)f_5072},
{C_text("f_5075:c_2dplatform_2escm"),(void*)f_5075},
{C_text("f_5078:c_2dplatform_2escm"),(void*)f_5078},
{C_text("f_5081:c_2dplatform_2escm"),(void*)f_5081},
{C_text("f_5084:c_2dplatform_2escm"),(void*)f_5084},
{C_text("f_5087:c_2dplatform_2escm"),(void*)f_5087},
{C_text("f_5090:c_2dplatform_2escm"),(void*)f_5090},
{C_text("f_5093:c_2dplatform_2escm"),(void*)f_5093},
{C_text("f_5096:c_2dplatform_2escm"),(void*)f_5096},
{C_text("f_5099:c_2dplatform_2escm"),(void*)f_5099},
{C_text("f_5102:c_2dplatform_2escm"),(void*)f_5102},
{C_text("f_5105:c_2dplatform_2escm"),(void*)f_5105},
{C_text("f_5108:c_2dplatform_2escm"),(void*)f_5108},
{C_text("f_5111:c_2dplatform_2escm"),(void*)f_5111},
{C_text("f_5114:c_2dplatform_2escm"),(void*)f_5114},
{C_text("f_5117:c_2dplatform_2escm"),(void*)f_5117},
{C_text("f_5120:c_2dplatform_2escm"),(void*)f_5120},
{C_text("f_5123:c_2dplatform_2escm"),(void*)f_5123},
{C_text("f_5126:c_2dplatform_2escm"),(void*)f_5126},
{C_text("f_5129:c_2dplatform_2escm"),(void*)f_5129},
{C_text("f_5132:c_2dplatform_2escm"),(void*)f_5132},
{C_text("f_5135:c_2dplatform_2escm"),(void*)f_5135},
{C_text("f_5138:c_2dplatform_2escm"),(void*)f_5138},
{C_text("f_5141:c_2dplatform_2escm"),(void*)f_5141},
{C_text("f_5144:c_2dplatform_2escm"),(void*)f_5144},
{C_text("f_5147:c_2dplatform_2escm"),(void*)f_5147},
{C_text("f_5149:c_2dplatform_2escm"),(void*)f_5149},
{C_text("f_5171:c_2dplatform_2escm"),(void*)f_5171},
{C_text("f_5186:c_2dplatform_2escm"),(void*)f_5186},
{C_text("f_5189:c_2dplatform_2escm"),(void*)f_5189},
{C_text("f_5204:c_2dplatform_2escm"),(void*)f_5204},
{C_text("f_5216:c_2dplatform_2escm"),(void*)f_5216},
{C_text("f_5224:c_2dplatform_2escm"),(void*)f_5224},
{C_text("f_5226:c_2dplatform_2escm"),(void*)f_5226},
{C_text("f_5247:c_2dplatform_2escm"),(void*)f_5247},
{C_text("f_5251:c_2dplatform_2escm"),(void*)f_5251},
{C_text("f_5254:c_2dplatform_2escm"),(void*)f_5254},
{C_text("f_5257:c_2dplatform_2escm"),(void*)f_5257},
{C_text("f_5259:c_2dplatform_2escm"),(void*)f_5259},
{C_text("f_5278:c_2dplatform_2escm"),(void*)f_5278},
{C_text("f_5295:c_2dplatform_2escm"),(void*)f_5295},
{C_text("f_5338:c_2dplatform_2escm"),(void*)f_5338},
{C_text("f_5342:c_2dplatform_2escm"),(void*)f_5342},
{C_text("f_5346:c_2dplatform_2escm"),(void*)f_5346},
{C_text("f_5350:c_2dplatform_2escm"),(void*)f_5350},
{C_text("f_5357:c_2dplatform_2escm"),(void*)f_5357},
{C_text("f_5361:c_2dplatform_2escm"),(void*)f_5361},
{C_text("f_5369:c_2dplatform_2escm"),(void*)f_5369},
{C_text("f_5373:c_2dplatform_2escm"),(void*)f_5373},
{C_text("f_5381:c_2dplatform_2escm"),(void*)f_5381},
{C_text("f_5384:c_2dplatform_2escm"),(void*)f_5384},
{C_text("f_5388:c_2dplatform_2escm"),(void*)f_5388},
{C_text("f_5391:c_2dplatform_2escm"),(void*)f_5391},
{C_text("f_5394:c_2dplatform_2escm"),(void*)f_5394},
{C_text("f_5397:c_2dplatform_2escm"),(void*)f_5397},
{C_text("f_5400:c_2dplatform_2escm"),(void*)f_5400},
{C_text("f_5403:c_2dplatform_2escm"),(void*)f_5403},
{C_text("f_5406:c_2dplatform_2escm"),(void*)f_5406},
{C_text("f_5409:c_2dplatform_2escm"),(void*)f_5409},
{C_text("f_5412:c_2dplatform_2escm"),(void*)f_5412},
{C_text("f_5415:c_2dplatform_2escm"),(void*)f_5415},
{C_text("f_5418:c_2dplatform_2escm"),(void*)f_5418},
{C_text("f_5421:c_2dplatform_2escm"),(void*)f_5421},
{C_text("f_5424:c_2dplatform_2escm"),(void*)f_5424},
{C_text("f_5427:c_2dplatform_2escm"),(void*)f_5427},
{C_text("f_5430:c_2dplatform_2escm"),(void*)f_5430},
{C_text("f_5433:c_2dplatform_2escm"),(void*)f_5433},
{C_text("f_5435:c_2dplatform_2escm"),(void*)f_5435},
{C_text("f_5457:c_2dplatform_2escm"),(void*)f_5457},
{C_text("f_5475:c_2dplatform_2escm"),(void*)f_5475},
{C_text("f_5497:c_2dplatform_2escm"),(void*)f_5497},
{C_text("f_5515:c_2dplatform_2escm"),(void*)f_5515},
{C_text("f_5540:c_2dplatform_2escm"),(void*)f_5540},
{C_text("f_5561:c_2dplatform_2escm"),(void*)f_5561},
{C_text("f_5569:c_2dplatform_2escm"),(void*)f_5569},
{C_text("f_5573:c_2dplatform_2escm"),(void*)f_5573},
{C_text("f_5580:c_2dplatform_2escm"),(void*)f_5580},
{C_text("f_5608:c_2dplatform_2escm"),(void*)f_5608},
{C_text("f_5611:c_2dplatform_2escm"),(void*)f_5611},
{C_text("f_5642:c_2dplatform_2escm"),(void*)f_5642},
{C_text("f_5664:c_2dplatform_2escm"),(void*)f_5664},
{C_text("f_5687:c_2dplatform_2escm"),(void*)f_5687},
{C_text("f_5691:c_2dplatform_2escm"),(void*)f_5691},
{C_text("f_5695:c_2dplatform_2escm"),(void*)f_5695},
{C_text("f_5702:c_2dplatform_2escm"),(void*)f_5702},
{C_text("f_5724:c_2dplatform_2escm"),(void*)f_5724},
{C_text("f_5734:c_2dplatform_2escm"),(void*)f_5734},
{C_text("f_5748:c_2dplatform_2escm"),(void*)f_5748},
{C_text("f_5752:c_2dplatform_2escm"),(void*)f_5752},
{C_text("f_5759:c_2dplatform_2escm"),(void*)f_5759},
{C_text("f_5790:c_2dplatform_2escm"),(void*)f_5790},
{C_text("f_5793:c_2dplatform_2escm"),(void*)f_5793},
{C_text("f_5808:c_2dplatform_2escm"),(void*)f_5808},
{C_text("f_5825:c_2dplatform_2escm"),(void*)f_5825},
{C_text("f_5829:c_2dplatform_2escm"),(void*)f_5829},
{C_text("f_5836:c_2dplatform_2escm"),(void*)f_5836},
{C_text("f_5846:c_2dplatform_2escm"),(void*)f_5846},
{C_text("f_5867:c_2dplatform_2escm"),(void*)f_5867},
{C_text("f_5895:c_2dplatform_2escm"),(void*)f_5895},
{C_text("f_5897:c_2dplatform_2escm"),(void*)f_5897},
{C_text("f_5920:c_2dplatform_2escm"),(void*)f_5920},
{C_text("f_5922:c_2dplatform_2escm"),(void*)f_5922},
{C_text("f_5941:c_2dplatform_2escm"),(void*)f_5941},
{C_text("f_5945:c_2dplatform_2escm"),(void*)f_5945},
{C_text("f_5960:c_2dplatform_2escm"),(void*)f_5960},
{C_text("f_5970:c_2dplatform_2escm"),(void*)f_5970},
{C_text("f_5991:c_2dplatform_2escm"),(void*)f_5991},
{C_text("f_6019:c_2dplatform_2escm"),(void*)f_6019},
{C_text("f_6021:c_2dplatform_2escm"),(void*)f_6021},
{C_text("f_6044:c_2dplatform_2escm"),(void*)f_6044},
{C_text("f_6046:c_2dplatform_2escm"),(void*)f_6046},
{C_text("f_6065:c_2dplatform_2escm"),(void*)f_6065},
{C_text("f_6069:c_2dplatform_2escm"),(void*)f_6069},
{C_text("f_6084:c_2dplatform_2escm"),(void*)f_6084},
{C_text("f_6088:c_2dplatform_2escm"),(void*)f_6088},
{C_text("f_6109:c_2dplatform_2escm"),(void*)f_6109},
{C_text("f_6151:c_2dplatform_2escm"),(void*)f_6151},
{C_text("f_6153:c_2dplatform_2escm"),(void*)f_6153},
{C_text("f_6160:c_2dplatform_2escm"),(void*)f_6160},
{C_text("f_6171:c_2dplatform_2escm"),(void*)f_6171},
{C_text("f_6192:c_2dplatform_2escm"),(void*)f_6192},
{C_text("f_6196:c_2dplatform_2escm"),(void*)f_6196},
{C_text("f_6202:c_2dplatform_2escm"),(void*)f_6202},
{C_text("f_6224:c_2dplatform_2escm"),(void*)f_6224},
{C_text("f_6228:c_2dplatform_2escm"),(void*)f_6228},
{C_text("f_6230:c_2dplatform_2escm"),(void*)f_6230},
{C_text("f_6246:c_2dplatform_2escm"),(void*)f_6246},
{C_text("f_6252:c_2dplatform_2escm"),(void*)f_6252},
{C_text("f_6270:c_2dplatform_2escm"),(void*)f_6270},
{C_text("f_6273:c_2dplatform_2escm"),(void*)f_6273},
{C_text("f_6276:c_2dplatform_2escm"),(void*)f_6276},
{C_text("f_6291:c_2dplatform_2escm"),(void*)f_6291},
{C_text("f_6303:c_2dplatform_2escm"),(void*)f_6303},
{C_text("f_6313:c_2dplatform_2escm"),(void*)f_6313},
{C_text("f_6317:c_2dplatform_2escm"),(void*)f_6317},
{C_text("f_6326:c_2dplatform_2escm"),(void*)f_6326},
{C_text("f_6336:c_2dplatform_2escm"),(void*)f_6336},
{C_text("f_6340:c_2dplatform_2escm"),(void*)f_6340},
{C_text("f_6370:c_2dplatform_2escm"),(void*)f_6370},
{C_text("f_6374:c_2dplatform_2escm"),(void*)f_6374},
{C_text("f_6378:c_2dplatform_2escm"),(void*)f_6378},
{C_text("f_6382:c_2dplatform_2escm"),(void*)f_6382},
{C_text("f_6386:c_2dplatform_2escm"),(void*)f_6386},
{C_text("f_6395:c_2dplatform_2escm"),(void*)f_6395},
{C_text("f_6399:c_2dplatform_2escm"),(void*)f_6399},
{C_text("f_6401:c_2dplatform_2escm"),(void*)f_6401},
{C_text("f_6411:c_2dplatform_2escm"),(void*)f_6411},
{C_text("f_6424:c_2dplatform_2escm"),(void*)f_6424},
{C_text("f_6449:c_2dplatform_2escm"),(void*)f_6449},
{C_text("toplevel:c_2dplatform_2escm"),(void*)C_c_2dplatform_toplevel},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding unexported module binding: chicken.compiler.c-platform#partition 
o|hiding unexported module binding: chicken.compiler.c-platform#span 
o|hiding unexported module binding: chicken.compiler.c-platform#take 
o|hiding unexported module binding: chicken.compiler.c-platform#drop 
o|hiding unexported module binding: chicken.compiler.c-platform#split-at 
o|hiding unexported module binding: chicken.compiler.c-platform#append-map 
o|hiding unexported module binding: chicken.compiler.c-platform#every 
o|hiding unexported module binding: chicken.compiler.c-platform#any 
o|hiding unexported module binding: chicken.compiler.c-platform#cons* 
o|hiding unexported module binding: chicken.compiler.c-platform#concatenate 
o|hiding unexported module binding: chicken.compiler.c-platform#delete 
o|hiding unexported module binding: chicken.compiler.c-platform#first 
o|hiding unexported module binding: chicken.compiler.c-platform#second 
o|hiding unexported module binding: chicken.compiler.c-platform#third 
o|hiding unexported module binding: chicken.compiler.c-platform#fourth 
o|hiding unexported module binding: chicken.compiler.c-platform#fifth 
o|hiding unexported module binding: chicken.compiler.c-platform#delete-duplicates 
o|hiding unexported module binding: chicken.compiler.c-platform#alist-cons 
o|hiding unexported module binding: chicken.compiler.c-platform#filter 
o|hiding unexported module binding: chicken.compiler.c-platform#filter-map 
o|hiding unexported module binding: chicken.compiler.c-platform#remove 
o|hiding unexported module binding: chicken.compiler.c-platform#unzip1 
o|hiding unexported module binding: chicken.compiler.c-platform#last 
o|hiding unexported module binding: chicken.compiler.c-platform#list-index 
o|hiding unexported module binding: chicken.compiler.c-platform#lset-adjoin/eq? 
o|hiding unexported module binding: chicken.compiler.c-platform#lset-difference/eq? 
o|hiding unexported module binding: chicken.compiler.c-platform#lset-union/eq? 
o|hiding unexported module binding: chicken.compiler.c-platform#lset-intersection/eq? 
o|hiding unexported module binding: chicken.compiler.c-platform#list-tabulate 
o|hiding unexported module binding: chicken.compiler.c-platform#lset<=/eq? 
o|hiding unexported module binding: chicken.compiler.c-platform#lset=/eq? 
o|hiding unexported module binding: chicken.compiler.c-platform#length+ 
o|hiding unexported module binding: chicken.compiler.c-platform#find 
o|hiding unexported module binding: chicken.compiler.c-platform#find-tail 
o|hiding unexported module binding: chicken.compiler.c-platform#iota 
o|hiding unexported module binding: chicken.compiler.c-platform#make-list 
o|hiding unexported module binding: chicken.compiler.c-platform#posq 
o|hiding unexported module binding: chicken.compiler.c-platform#posv 
o|hiding unexported module binding: chicken.compiler.c-platform#constant577 
o|hiding unexported module binding: chicken.compiler.c-platform#constant581 
o|hiding unexported module binding: chicken.compiler.c-platform#constant585 
o|hiding unexported module binding: chicken.compiler.c-platform#setter-map 
S|applied compiler syntax:
S|  scheme#for-each		1
S|  chicken.base#foldl		3
S|  scheme#map		5
S|  chicken.base#foldr		3
o|eliminated procedure checks: 34 
o|specializations:
o|  1 (chicken.base#add1 fixnum)
o|  1 (scheme#- *)
o|  1 (scheme#negative? *)
o|  4 (scheme#>= fixnum fixnum)
o|  2 (scheme#zero? *)
o|  1 (scheme#length list)
o|  1 (scheme#memq * list)
o|  15 (scheme#= fixnum fixnum)
o|  1 (scheme#eqv? * *)
o|  5 (##sys#check-list (or pair list) *)
o|  26 (scheme#cdr pair)
o|  10 (scheme#car pair)
(o e)|safe calls: 461 
(o e)|assignments to immediate values: 1 
o|safe globals: (chicken.compiler.c-platform#posv chicken.compiler.c-platform#posq chicken.compiler.c-platform#make-list chicken.compiler.c-platform#iota chicken.compiler.c-platform#find-tail chicken.compiler.c-platform#find chicken.compiler.c-platform#length+ chicken.compiler.c-platform#lset=/eq? chicken.compiler.c-platform#lset<=/eq? chicken.compiler.c-platform#list-tabulate chicken.compiler.c-platform#lset-intersection/eq? chicken.compiler.c-platform#lset-union/eq? chicken.compiler.c-platform#lset-difference/eq? chicken.compiler.c-platform#lset-adjoin/eq? chicken.compiler.c-platform#list-index chicken.compiler.c-platform#last chicken.compiler.c-platform#unzip1 chicken.compiler.c-platform#remove chicken.compiler.c-platform#filter-map chicken.compiler.c-platform#filter chicken.compiler.c-platform#alist-cons chicken.compiler.c-platform#delete-duplicates chicken.compiler.c-platform#fifth chicken.compiler.c-platform#fourth chicken.compiler.c-platform#third chicken.compiler.c-platform#second chicken.compiler.c-platform#first chicken.compiler.c-platform#delete chicken.compiler.c-platform#concatenate chicken.compiler.c-platform#cons* chicken.compiler.c-platform#any chicken.compiler.c-platform#every chicken.compiler.c-platform#append-map chicken.compiler.c-platform#split-at chicken.compiler.c-platform#drop chicken.compiler.c-platform#take chicken.compiler.c-platform#span chicken.compiler.c-platform#partition) 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#partition 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#span 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#drop 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#split-at 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#append-map 
o|inlining procedure: k2064 
o|inlining procedure: k2064 
o|inlining procedure: k2095 
o|inlining procedure: k2095 
o|merged explicitly consed rest parameter: xs203 
o|inlining procedure: k2125 
o|inlining procedure: k2125 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#concatenate 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#fourth 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#fifth 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#delete-duplicates 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#alist-cons 
o|inlining procedure: k2312 
o|inlining procedure: k2312 
o|inlining procedure: k2304 
o|inlining procedure: k2304 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#filter-map 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#remove 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#unzip1 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#list-index 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#lset-adjoin/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#lset-difference/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#lset-union/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#lset-intersection/eq? 
o|inlining procedure: k2703 
o|inlining procedure: k2703 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#lset<=/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#lset=/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#length+ 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#find 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#find-tail 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#iota 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#make-list 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#posq 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#posv 
o|inlining procedure: k3013 
o|inlining procedure: k3031 
o|inlining procedure: k3045 
o|inlining procedure: k3045 
o|inlining procedure: k3031 
o|inlining procedure: k3013 
o|substituted constant variable: a3071 
o|inlining procedure: k3081 
o|inlining procedure: k3099 
o|inlining procedure: k3099 
o|inlining procedure: k3123 
o|inlining procedure: "(c-platform.scm:331) chicken.compiler.c-platform#first" 
o|inlining procedure: k3123 
o|inlining procedure: k3162 
o|inlining procedure: k3162 
o|inlining procedure: "(c-platform.scm:328) chicken.compiler.c-platform#first" 
o|inlining procedure: k3183 
o|inlining procedure: k3183 
o|inlining procedure: "(c-platform.scm:322) chicken.compiler.c-platform#second" 
o|inlining procedure: "(c-platform.scm:321) chicken.compiler.c-platform#first" 
o|inlining procedure: k3081 
o|substituted constant variable: a3230 
o|inlining procedure: k3243 
o|consed rest parameter at call site: "(c-platform.scm:377) chicken.compiler.c-platform#cons*" 2 
o|inlining procedure: k3298 
o|inlining procedure: k3298 
o|inlining procedure: "(c-platform.scm:379) chicken.compiler.c-platform#first" 
o|inlining procedure: "(c-platform.scm:377) chicken.compiler.c-platform#first" 
o|inlining procedure: k3340 
o|inlining procedure: k3340 
o|consed rest parameter at call site: "(c-platform.scm:392) chicken.compiler.c-platform#cons*" 2 
o|inlining procedure: k3361 
o|substituted constant variable: a3374 
o|inlining procedure: k3375 
o|inlining procedure: k3375 
o|inlining procedure: k3361 
o|substituted constant variable: a3404 
o|contracted procedure: "(c-platform.scm:372) chicken.compiler.c-platform#last" 
o|inlining procedure: k2461 
o|inlining procedure: k2461 
o|inlining procedure: k3243 
o|inlining procedure: k3432 
o|inlining procedure: k3459 
o|inlining procedure: k3459 
o|inlining procedure: "(c-platform.scm:407) chicken.compiler.c-platform#first" 
o|inlining procedure: k3432 
o|substituted constant variable: a3489 
o|inlining procedure: k3510 
o|inlining procedure: k3510 
o|substituted constant variable: a3531 
o|inlining procedure: k3541 
o|inlining procedure: k3559 
o|inlining procedure: k3574 
o|inlining procedure: k3586 
o|substituted constant variable: a3674 
o|inlining procedure: k3586 
o|inlining procedure: "(c-platform.scm:443) chicken.compiler.c-platform#third" 
o|inlining procedure: k3574 
o|inlining procedure: k3559 
o|inlining procedure: k3541 
o|substituted constant variable: a3697 
o|inlining procedure: k4446 
o|inlining procedure: k4461 
o|inlining procedure: k4485 
o|inlining procedure: k4485 
o|inlining procedure: "(c-platform.scm:852) chicken.compiler.c-platform#first" 
o|inlining procedure: k4461 
o|substituted constant variable: a4531 
o|inlining procedure: k4547 
o|inlining procedure: "(c-platform.scm:843) chicken.compiler.c-platform#first" 
o|inlining procedure: k4547 
o|substituted constant variable: a4574 
o|inlining procedure: k4446 
o|inlining procedure: k5154 
o|inlining procedure: k5175 
o|inlining procedure: "(c-platform.scm:1153) chicken.compiler.c-platform#second" 
o|inlining procedure: k5175 
o|inlining procedure: "(c-platform.scm:1149) chicken.compiler.c-platform#first" 
o|inlining procedure: "(c-platform.scm:1146) chicken.compiler.c-platform#first" 
o|inlining procedure: k5154 
o|inlining procedure: k5261 
o|inlining procedure: k5279 
o|inlining procedure: k5297 
o|inlining procedure: k5312 
o|inlining procedure: k5312 
o|inlining procedure: "(c-platform.scm:1182) chicken.compiler.c-platform#second" 
o|inlining procedure: k5297 
o|inlining procedure: "(c-platform.scm:1177) chicken.compiler.c-platform#third" 
o|inlining procedure: k5279 
o|inlining procedure: "(c-platform.scm:1175) chicken.compiler.c-platform#first" 
o|inlining procedure: "(c-platform.scm:1173) chicken.compiler.c-platform#first" 
o|inlining procedure: k5261 
o|substituted constant variable: a5374 
o|inlining procedure: k5437 
o|inlining procedure: k5463 
o|inlining procedure: k5463 
o|inlining procedure: k5437 
o|substituted constant variable: a5469 
o|inlining procedure: k5477 
o|inlining procedure: k5503 
o|inlining procedure: k5503 
o|inlining procedure: k5477 
o|substituted constant variable: a5509 
o|inlining procedure: k5517 
o|inlining procedure: k5535 
o|substituted constant variable: chicken.compiler.c-platform#setter-map 
o|inlining procedure: k5535 
o|inlining procedure: k5517 
o|substituted constant variable: a5574 
o|inlining procedure: k5582 
o|inlining procedure: k5609 
o|inlining procedure: k5609 
o|inlining procedure: k5631 
o|inlining procedure: k5643 
o|inlining procedure: "(c-platform.scm:1029) chicken.compiler.c-platform#first" 
o|inlining procedure: "(c-platform.scm:1032) chicken.compiler.c-platform#first" 
o|inlining procedure: k5643 
o|inlining procedure: "(c-platform.scm:1024) chicken.compiler.c-platform#first" 
o|inlining procedure: k5631 
o|inlining procedure: "(c-platform.scm:1018) chicken.compiler.c-platform#second" 
o|inlining procedure: k5582 
o|substituted constant variable: a5696 
o|inlining procedure: k5704 
o|inlining procedure: k5729 
o|inlining procedure: k5729 
o|inlining procedure: "(c-platform.scm:989) chicken.compiler.c-platform#first" 
o|inlining procedure: "(c-platform.scm:987) chicken.compiler.c-platform#third" 
o|inlining procedure: k5704 
o|substituted constant variable: a5757 
o|inlining procedure: k5761 
o|inlining procedure: k5788 
o|inlining procedure: "(c-platform.scm:874) chicken.compiler.c-platform#first" 
o|inlining procedure: k5788 
o|inlining procedure: "(c-platform.scm:871) chicken.compiler.c-platform#first" 
o|inlining procedure: "(c-platform.scm:868) chicken.compiler.c-platform#second" 
o|substituted constant variable: a5834 
o|inlining procedure: k5761 
o|inlining procedure: k5838 
o|inlining procedure: k5838 
o|inlining procedure: k5869 
o|inlining procedure: k5869 
o|inlining procedure: k5875 
o|inlining procedure: k5875 
o|substituted constant variable: a5914 
o|inlining procedure: k5928 
o|inlining procedure: "(c-platform.scm:817) chicken.compiler.c-platform#first" 
o|inlining procedure: k5928 
o|inlining procedure: k5962 
o|inlining procedure: k5962 
o|inlining procedure: k5993 
o|inlining procedure: k5993 
o|inlining procedure: k5999 
o|inlining procedure: k5999 
o|substituted constant variable: a6038 
o|inlining procedure: k6052 
o|inlining procedure: "(c-platform.scm:780) chicken.compiler.c-platform#first" 
o|inlining procedure: k6052 
o|inlining procedure: k6089 
o|inlining procedure: k6089 
o|inlining procedure: "(c-platform.scm:744) chicken.compiler.c-platform#first" 
o|inlining procedure: k6131 
o|inlining procedure: k6155 
o|inlining procedure: k6155 
o|inlining procedure: "(c-platform.scm:752) chicken.compiler.c-platform#first" 
o|inlining procedure: k6131 
o|inlining procedure: k6208 
o|inlining procedure: "(c-platform.scm:740) chicken.compiler.c-platform#first" 
o|inlining procedure: k6208 
o|inlining procedure: k6232 
o|inlining procedure: k6253 
o|inlining procedure: k6253 
o|inlining procedure: k6292 
o|inlining procedure: "(c-platform.scm:356) chicken.compiler.c-platform#first" 
o|inlining procedure: k6292 
o|inlining procedure: k6327 
o|inlining procedure: k6327 
o|inlining procedure: "(c-platform.scm:353) chicken.compiler.c-platform#first" 
o|inlining procedure: k6344 
o|inlining procedure: k6344 
o|inlining procedure: "(c-platform.scm:347) chicken.compiler.c-platform#second" 
o|inlining procedure: "(c-platform.scm:346) chicken.compiler.c-platform#first" 
o|inlining procedure: k6232 
o|substituted constant variable: a6391 
o|inlining procedure: k6403 
o|contracted procedure: "(c-platform.scm:283) g590597" 
o|propagated global variable: g605606 chicken.compiler.support#mark-variable 
o|inlining procedure: k6403 
o|substituted constant variable: chicken.compiler.c-platform#constant581 
o|substituted constant variable: chicken.compiler.c-platform#constant577 
o|substituted constant variable: chicken.compiler.c-platform#constant585 
o|inlining procedure: k6426 
o|contracted procedure: "(c-platform.scm:120) g557566" 
o|inlining procedure: k6426 
o|simplifications: ((if . 1)) 
o|replaced variables: 448 
o|removed binding forms: 574 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#every 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#any 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#first 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#second 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#third 
o|substituted constant variable: r23056466 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#constant577 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#constant581 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#constant585 
o|substituted constant variable: r30146478 
o|substituted constant variable: r31006481 
o|substituted constant variable: r31246488 
o|substituted constant variable: r31846497 
o|substituted constant variable: r30826508 
o|substituted constant variable: r33766526 
o|substituted constant variable: r33626528 
o|substituted constant variable: r32446531 
o|substituted constant variable: r34336542 
o|substituted constant variable: r35116544 
o|substituted constant variable: r35876549 
o|substituted constant variable: r35756555 
o|substituted constant variable: r35606556 
o|substituted constant variable: r35426557 
o|substituted constant variable: r44626567 
o|substituted constant variable: r45486575 
o|substituted constant variable: r45486575 
o|folded constant expression: (scheme#not (quote #f)) 
o|substituted constant variable: r44476577 
o|contracted procedure: "(c-platform.scm:1165) chicken.compiler.c-platform#list-tabulate" 
o|substituted constant variable: r27046467 
o|substituted constant variable: r51766585 
o|substituted constant variable: r51556596 
o|substituted constant variable: r53136601 
o|substituted constant variable: r52986607 
o|substituted constant variable: r52806613 
o|substituted constant variable: r52626624 
o|removed side-effect free assignment to unused variable: chicken.compiler.c-platform#setter-map 
o|substituted constant variable: r54646626 
o|substituted constant variable: r54646626 
o|substituted constant variable: r54646628 
o|substituted constant variable: r54646628 
o|substituted constant variable: r54386630 
o|substituted constant variable: r55046632 
o|substituted constant variable: r55046632 
o|substituted constant variable: r55046634 
o|substituted constant variable: r55046634 
o|substituted constant variable: r54786636 
o|substituted constant variable: r55366639 
o|substituted constant variable: r55186640 
o|converted assignments to bindings: (rewrite-call/cc895) 
o|converted assignments to bindings: (rewrite-make-vector878) 
o|substituted constant variable: r56446658 
o|substituted constant variable: r56326664 
o|substituted constant variable: r55836670 
o|substituted constant variable: r57306672 
o|substituted constant variable: r57306672 
o|substituted constant variable: r57306674 
o|substituted constant variable: r57306674 
o|substituted constant variable: r57056686 
o|substituted constant variable: r57626707 
o|converted assignments to bindings: (rewrite-div826) 
o|substituted constant variable: r58396708 
o|substituted constant variable: r58706710 
o|substituted constant variable: r58706710 
o|substituted constant variable: r58706712 
o|substituted constant variable: r58706712 
o|substituted constant variable: r58766715 
o|substituted constant variable: r59296723 
o|substituted constant variable: r59296723 
o|folded constant expression: (scheme#not (quote #f)) 
o|substituted constant variable: r59636725 
o|substituted constant variable: r59946727 
o|substituted constant variable: r59946727 
o|substituted constant variable: r59946729 
o|substituted constant variable: r59946729 
o|substituted constant variable: r60006732 
o|substituted constant variable: r60536740 
o|substituted constant variable: r60536740 
o|folded constant expression: (scheme#not (quote #f)) 
o|substituted constant variable: r61326757 
o|substituted constant variable: r62096765 
o|substituted constant variable: r62096765 
o|folded constant expression: (scheme#not (quote #f)) 
o|converted assignments to bindings: (rewrite-c-w-v756) 
o|converted assignments to bindings: (rewrite-c..r727) 
o|converted assignments to bindings: (rewrite-apply683) 
o|substituted constant variable: r62936776 
o|substituted constant variable: r63456785 
o|substituted constant variable: r62336796 
o|converted assignments to bindings: (eqv?-id623) 
o|converted assignments to bindings: (op1612) 
o|substituted constant variable: g596598 
o|substituted constant variable: g563567 
o|simplifications: ((let . 8)) 
o|replaced variables: 42 
o|removed binding forms: 450 
o|replaced variables: 24 
o|removed binding forms: 123 
o|replaced variables: 35 
o|removed binding forms: 24 
o|removed binding forms: 35 
o|simplifications: ((if . 7) (##core#call . 280)) 
o|  call simplifications:
o|    scheme#symbol?	2
o|    scheme#assq
o|    scheme#=
o|    chicken.base#fixnum?	2
o|    scheme#<=
o|    chicken.fixnum#fx+
o|    chicken.fixnum#fx>=	5
o|    scheme#caddr	3
o|    scheme#list?
o|    scheme#cdr	6
o|    ##sys#setslot	2
o|    scheme#cadr	8
o|    scheme#equal?	2
o|    scheme#number?	2
o|    scheme#not	12
o|    scheme#length	19
o|    scheme#eq?	56
o|    scheme#list	84
o|    ##sys#check-list	2
o|    scheme#pair?	7
o|    ##sys#slot	10
o|    scheme#null?	8
o|    scheme#car	34
o|    scheme#cons	11
o|contracted procedure: k2128 
o|contracted procedure: k2139 
o|contracted procedure: k2295 
o|contracted procedure: k2307 
o|contracted procedure: k2325 
o|contracted procedure: k2333 
o|contracted procedure: k2981 
o|contracted procedure: k3068 
o|contracted procedure: k3016 
o|contracted procedure: k3023 
o|contracted procedure: k3027 
o|contracted procedure: k3034 
o|inlining procedure: k3041 
o|inlining procedure: k3041 
o|contracted procedure: k3052 
o|contracted procedure: k3060 
o|contracted procedure: k3056 
o|contracted procedure: k3227 
o|contracted procedure: k3084 
o|contracted procedure: k3087 
o|contracted procedure: k3090 
o|contracted procedure: k3112 
o|contracted procedure: k3116 
o|contracted procedure: k3126 
o|contracted procedure: k3129 
o|contracted procedure: k3142 
o|contracted procedure: k3153 
o|contracted procedure: k3156 
o|contracted procedure: k3169 
o|contracted procedure: k3180 
o|contracted procedure: k3186 
o|contracted procedure: k3192 
o|contracted procedure: k3199 
o|contracted procedure: k3203 
o|contracted procedure: k3246 
o|contracted procedure: k3256 
o|contracted procedure: k3263 
o|contracted procedure: k3271 
o|contracted procedure: k3279 
o|contracted procedure: k3283 
o|contracted procedure: k3286 
o|contracted procedure: k3289 
o|contracted procedure: k3301 
o|contracted procedure: k3304 
o|contracted procedure: k3307 
o|contracted procedure: k3315 
o|contracted procedure: k3323 
o|contracted procedure: k3347 
o|contracted procedure: k3358 
o|contracted procedure: k3406 
o|contracted procedure: k3364 
o|contracted procedure: k3367 
o|contracted procedure: k3385 
o|contracted procedure: k3397 
o|contracted procedure: k3389 
o|contracted procedure: k2474 
o|contracted procedure: k2464 
o|contracted procedure: k3486 
o|contracted procedure: k3435 
o|contracted procedure: k3444 
o|contracted procedure: k3451 
o|contracted procedure: k3455 
o|contracted procedure: k3462 
o|contracted procedure: k3469 
o|contracted procedure: k3479 
o|contracted procedure: k3528 
o|contracted procedure: k3513 
o|contracted procedure: k3520 
o|contracted procedure: k3524 
o|contracted procedure: k3699 
o|contracted procedure: k3544 
o|contracted procedure: k3547 
o|contracted procedure: k3550 
o|contracted procedure: k3556 
o|contracted procedure: k3562 
o|contracted procedure: k3565 
o|contracted procedure: k3580 
o|contracted procedure: k3583 
o|contracted procedure: k3589 
o|contracted procedure: k3595 
o|contracted procedure: k3611 
o|contracted procedure: k3615 
o|contracted procedure: k3627 
o|contracted procedure: k3631 
o|contracted procedure: k3667 
o|contracted procedure: k3639 
o|contracted procedure: k3643 
o|contracted procedure: k3651 
o|contracted procedure: k3655 
o|contracted procedure: k4449 
o|contracted procedure: k4571 
o|contracted procedure: k4455 
o|contracted procedure: k4533 
o|contracted procedure: k4458 
o|contracted procedure: k4528 
o|contracted procedure: k4464 
o|contracted procedure: k4471 
o|contracted procedure: k4475 
o|contracted procedure: k4495 
o|contracted procedure: k4506 
o|contracted procedure: k4509 
o|contracted procedure: k4516 
o|contracted procedure: k4550 
o|contracted procedure: k4557 
o|contracted procedure: k4547 
o|contracted procedure: k5151 
o|contracted procedure: k5157 
o|contracted procedure: k5160 
o|contracted procedure: k5166 
o|contracted procedure: k5172 
o|contracted procedure: k5178 
o|contracted procedure: k5194 
o|contracted procedure: k5198 
o|contracted procedure: k5206 
o|contracted procedure: k5210 
o|contracted procedure: k5218 
o|contracted procedure: k2706 
o|contracted procedure: k2721 
o|contracted procedure: k5233 
o|contracted procedure: k5376 
o|contracted procedure: k5264 
o|contracted procedure: k5267 
o|contracted procedure: k5273 
o|contracted procedure: k5282 
o|contracted procedure: k5288 
o|contracted procedure: k5300 
o|contracted procedure: k5303 
o|contracted procedure: k5309 
o|contracted procedure: k5315 
o|contracted procedure: k5321 
o|contracted procedure: k5328 
o|contracted procedure: k5332 
o|contracted procedure: k5363 
o|contracted procedure: k5471 
o|contracted procedure: k5440 
o|contracted procedure: k5447 
o|contracted procedure: k5451 
o|contracted procedure: k5466 
o|contracted procedure: k5459 
o|contracted procedure: k5511 
o|contracted procedure: k5480 
o|contracted procedure: k5487 
o|contracted procedure: k5491 
o|contracted procedure: k5506 
o|contracted procedure: k5499 
o|contracted procedure: k5576 
o|contracted procedure: k5520 
o|contracted procedure: k5523 
o|contracted procedure: k5529 
o|contracted procedure: k5532 
o|contracted procedure: k5541 
o|contracted procedure: k5551 
o|contracted procedure: k5555 
o|contracted procedure: k5563 
o|contracted procedure: k5698 
o|contracted procedure: k5585 
o|contracted procedure: k5588 
o|contracted procedure: k5595 
o|contracted procedure: k5603 
o|inlining procedure: k5599 
o|inlining procedure: k5599 
o|contracted procedure: k5615 
o|contracted procedure: k5625 
o|contracted procedure: k5628 
o|contracted procedure: k5634 
o|contracted procedure: k5658 
o|contracted procedure: k5654 
o|contracted procedure: k5675 
o|contracted procedure: k5671 
o|contracted procedure: k5678 
o|contracted procedure: k5754 
o|contracted procedure: k5707 
o|contracted procedure: k5714 
o|contracted procedure: k5718 
o|contracted procedure: k5726 
o|contracted procedure: k5735 
o|contracted procedure: k5742 
o|contracted procedure: k5764 
o|contracted procedure: k5831 
o|contracted procedure: k5770 
o|contracted procedure: k5777 
o|contracted procedure: k5781 
o|contracted procedure: k5784 
o|contracted procedure: k5802 
o|contracted procedure: k5798 
o|contracted procedure: k5812 
o|contracted procedure: k5819 
o|contracted procedure: k5841 
o|contracted procedure: k5949 
o|contracted procedure: k5850 
o|contracted procedure: k5857 
o|contracted procedure: k5861 
o|contracted procedure: k5872 
o|contracted procedure: k5911 
o|contracted procedure: k5878 
o|contracted procedure: k5885 
o|contracted procedure: k5889 
o|contracted procedure: k5903 
o|contracted procedure: k5907 
o|contracted procedure: k5931 
o|contracted procedure: k5935 
o|contracted procedure: k5956 
o|contracted procedure: k5965 
o|contracted procedure: k6073 
o|contracted procedure: k5974 
o|contracted procedure: k5981 
o|contracted procedure: k5985 
o|contracted procedure: k5996 
o|contracted procedure: k6035 
o|contracted procedure: k6002 
o|contracted procedure: k6009 
o|contracted procedure: k6013 
o|contracted procedure: k6027 
o|contracted procedure: k6031 
o|contracted procedure: k6055 
o|contracted procedure: k6059 
o|contracted procedure: k6080 
o|contracted procedure: k6092 
o|contracted procedure: k6099 
o|contracted procedure: k6103 
o|contracted procedure: k6198 
o|contracted procedure: k6113 
o|contracted procedure: k6120 
o|contracted procedure: k6128 
o|contracted procedure: k6124 
o|contracted procedure: k6134 
o|contracted procedure: k6141 
o|contracted procedure: k6145 
o|contracted procedure: k6165 
o|contracted procedure: k6176 
o|contracted procedure: k6179 
o|contracted procedure: k6186 
o|contracted procedure: k6211 
o|contracted procedure: k6218 
o|contracted procedure: k6208 
o|contracted procedure: k6388 
o|contracted procedure: k6235 
o|contracted procedure: k6238 
o|contracted procedure: k6241 
o|contracted procedure: k6260 
o|contracted procedure: k6264 
o|contracted procedure: k6281 
o|contracted procedure: k6285 
o|contracted procedure: k6295 
o|contracted procedure: k6298 
o|contracted procedure: k6318 
o|contracted procedure: k6321 
o|contracted procedure: k6341 
o|contracted procedure: k6347 
o|contracted procedure: k6353 
o|contracted procedure: k6360 
o|contracted procedure: k6364 
o|contracted procedure: k6406 
o|contracted procedure: k6416 
o|contracted procedure: k6420 
o|contracted procedure: k6429 
o|contracted procedure: k6432 
o|contracted procedure: k6435 
o|contracted procedure: k6443 
o|contracted procedure: k6451 
o|simplifications: ((let . 27)) 
o|removed binding forms: 256 
o|replaced variables: 32 
o|removed binding forms: 2 
o|removed binding forms: 18 
o|direct leaf routine/allocation: loop327 0 
o|contracted procedure: k3249 
o|converted assignments to bindings: (loop327) 
o|simplifications: ((let . 1)) 
o|removed binding forms: 1 
o|customizable procedures: (map-loop551569 for-each-loop589607 op1612 k6271 k6274 rewrite-c..r727 k6158 k5968 k5844 k5791 k5640 loop422 chicken.compiler.c-platform#filter k4488 map-loop693710 chicken.compiler.c-platform#cons* k3102 k3105 foldr254257 g259260 loop204) 
o|calls to known targets: 69 
o|identified direct recursive calls: f_2123 1 
o|identified direct recursive calls: f_2302 1 
o|identified direct recursive calls: f_2459 1 
o|fast box initializations: 6 
o|fast global references: 6 
o|fast global assignments: 2 
o|dropping unused closure argument: f_2117 
o|dropping unused closure argument: f_2293 
o|dropping unused closure argument: f_2459 
o|dropping unused closure argument: f_3009 
o|dropping unused closure argument: f_3424 
*/
/* end of file */
