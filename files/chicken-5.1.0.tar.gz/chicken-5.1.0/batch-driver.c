/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-cc.org
   Version 5.1.0rc1 (prerelease) (rev 7358d2e5)
   linux-unix-gnu-x86-64 [ 64bit dload ptables ]
   command line: batch-driver.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -consult-types-file ./types.db -no-lambda-info -no-trace -emit-import-library chicken.compiler.batch-driver -output-file batch-driver.c
   unit: batch-driver
   uses: library eval expand extras data-structures pathname support compiler-syntax compiler optimizer internal scrutinizer lfa2 c-platform c-backend user-pass
*/
#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_pathname_toplevel)
C_externimport void C_ccall C_pathname_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_compiler_2dsyntax_toplevel)
C_externimport void C_ccall C_compiler_2dsyntax_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_internal_toplevel)
C_externimport void C_ccall C_internal_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_scrutinizer_toplevel)
C_externimport void C_ccall C_scrutinizer_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_lfa2_toplevel)
C_externimport void C_ccall C_lfa2_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_c_2dplatform_toplevel)
C_externimport void C_ccall C_c_2dplatform_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_c_2dbackend_toplevel)
C_externimport void C_ccall C_c_2dbackend_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_user_2dpass_toplevel)
C_externimport void C_ccall C_user_2dpass_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[487];
static double C_possibly_force_alignment;


C_noret_decl(f8625)
static void C_ccall f8625(C_word c,C_word *av) C_noret;
C_noret_decl(f9103)
static void C_ccall f9103(C_word c,C_word *av) C_noret;
C_noret_decl(f9109)
static void C_ccall f9109(C_word c,C_word *av) C_noret;
C_noret_decl(f9115)
static void C_ccall f9115(C_word c,C_word *av) C_noret;
C_noret_decl(f9121)
static void C_ccall f9121(C_word c,C_word *av) C_noret;
C_noret_decl(f9127)
static void C_ccall f9127(C_word c,C_word *av) C_noret;
C_noret_decl(f9133)
static void C_ccall f9133(C_word c,C_word *av) C_noret;
C_noret_decl(f9145)
static void C_ccall f9145(C_word c,C_word *av) C_noret;
C_noret_decl(f9153)
static void C_ccall f9153(C_word c,C_word *av) C_noret;
C_noret_decl(f9165)
static void C_ccall f9165(C_word c,C_word *av) C_noret;
C_noret_decl(f9189)
static void C_ccall f9189(C_word c,C_word *av) C_noret;
C_noret_decl(f9195)
static void C_ccall f9195(C_word c,C_word *av) C_noret;
C_noret_decl(f9209)
static void C_ccall f9209(C_word c,C_word *av) C_noret;
C_noret_decl(f9215)
static void C_ccall f9215(C_word c,C_word *av) C_noret;
C_noret_decl(f9221)
static void C_ccall f9221(C_word c,C_word *av) C_noret;
C_noret_decl(f9227)
static void C_ccall f9227(C_word c,C_word *av) C_noret;
C_noret_decl(f9233)
static void C_ccall f9233(C_word c,C_word *av) C_noret;
C_noret_decl(f9247)
static void C_ccall f9247(C_word c,C_word *av) C_noret;
C_noret_decl(f9263)
static void C_ccall f9263(C_word c,C_word *av) C_noret;
C_noret_decl(f9269)
static void C_ccall f9269(C_word c,C_word *av) C_noret;
C_noret_decl(f9275)
static void C_ccall f9275(C_word c,C_word *av) C_noret;
C_noret_decl(f9281)
static void C_ccall f9281(C_word c,C_word *av) C_noret;
C_noret_decl(f9287)
static void C_ccall f9287(C_word c,C_word *av) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word *av) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word *av) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word *av) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word *av) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word *av) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word *av) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687(C_word c,C_word *av) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word *av) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word *av) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word *av) C_noret;
C_noret_decl(f_2699)
static void C_ccall f_2699(C_word c,C_word *av) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word *av) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word *av) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word *av) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word *av) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word *av) C_noret;
C_noret_decl(f_2915)
static void C_fcall f_2915(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2930)
static void C_fcall f_2930(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2938)
static void C_fcall f_2938(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word *av) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word *av) C_noret;
C_noret_decl(f_2970)
static void C_fcall f_2970(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word *av) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word *av) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word *av) C_noret;
C_noret_decl(f_3002)
static void C_fcall f_3002(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word *av) C_noret;
C_noret_decl(f_3051)
static void C_fcall f_3051(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3091)
static void C_fcall f_3091(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word *av) C_noret;
C_noret_decl(f_3125)
static C_word C_fcall f_3125(C_word t0);
C_noret_decl(f_3177)
static void C_fcall f_3177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_fcall f_3183(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word *av) C_noret;
C_noret_decl(f_3211)
static void C_fcall f_3211(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word *av) C_noret;
C_noret_decl(f_3325)
static void C_fcall f_3325(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3334)
static void C_fcall f_3334(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3342)
static void C_fcall f_3342(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word *av) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word *av) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word *av) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word *av) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word *av) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word *av) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word *av) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word *av) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word *av) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word *av) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word *av) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word *av) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word *av) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word *av) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word *av) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word *av) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word *av) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word *av) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word *av) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word *av) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word *av) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word *av) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word *av) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word *av) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word *av) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word *av) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word *av) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word *av) C_noret;
C_noret_decl(f_4093)
static void C_fcall f_4093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word *av) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word *av) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word *av) C_noret;
C_noret_decl(f_4133)
static void C_fcall f_4133(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word *av) C_noret;
C_noret_decl(f_4156)
static void C_fcall f_4156(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word *av) C_noret;
C_noret_decl(f_4179)
static void C_fcall f_4179(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word *av) C_noret;
C_noret_decl(f_4202)
static void C_fcall f_4202(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4206)
static void C_fcall f_4206(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word *av) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word *av) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word *av) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word *av) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word *av) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word *av) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word *av) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word *av) C_noret;
C_noret_decl(f_4261)
static void C_ccall f_4261(C_word c,C_word *av) C_noret;
C_noret_decl(f_4265)
static void C_ccall f_4265(C_word c,C_word *av) C_noret;
C_noret_decl(f_4273)
static void C_fcall f_4273(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word *av) C_noret;
C_noret_decl(f_4297)
static void C_fcall f_4297(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word *av) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word *av) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word *av) C_noret;
C_noret_decl(f_4324)
static void C_fcall f_4324(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word *av) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word *av) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word *av) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word *av) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word *av) C_noret;
C_noret_decl(f_4393)
static void C_fcall f_4393(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word *av) C_noret;
C_noret_decl(f_4417)
static void C_fcall f_4417(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4423)
static void C_ccall f_4423(C_word c,C_word *av) C_noret;
C_noret_decl(f_4496)
static void C_fcall f_4496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word *av) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word *av) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word *av) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word *av) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word *av) C_noret;
C_noret_decl(f_4787)
static void C_fcall f_4787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word *av) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word *av) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word *av) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word *av) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word *av) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word *av) C_noret;
C_noret_decl(f_4865)
static void C_fcall f_4865(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_fcall f_4885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word *av) C_noret;
C_noret_decl(f_4908)
static void C_fcall f_4908(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word *av) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word *av) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word *av) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word *av) C_noret;
C_noret_decl(f_4933)
static void C_ccall f_4933(C_word c,C_word *av) C_noret;
C_noret_decl(f_4935)
static void C_fcall f_4935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word *av) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word *av) C_noret;
C_noret_decl(f_4957)
static void C_fcall f_4957(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word *av) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word *av) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word *av) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word *av) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word *av) C_noret;
C_noret_decl(f_4984)
static void C_fcall f_4984(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word *av) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word *av) C_noret;
C_noret_decl(f_5007)
static void C_fcall f_5007(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word *av) C_noret;
C_noret_decl(f_5030)
static void C_fcall f_5030(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word *av) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word *av) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word *av) C_noret;
C_noret_decl(f_5090)
static void C_ccall f_5090(C_word c,C_word *av) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word *av) C_noret;
C_noret_decl(f_5115)
static void C_fcall f_5115(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5121)
static void C_fcall f_5121(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5129)
static void C_fcall f_5129(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word *av) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word *av) C_noret;
C_noret_decl(f_5150)
static void C_fcall f_5150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word *av) C_noret;
C_noret_decl(f_5160)
static void C_fcall f_5160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word *av) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word *av) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word *av) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179(C_word c,C_word *av) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word *av) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word *av) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word *av) C_noret;
C_noret_decl(f_5200)
static void C_fcall f_5200(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5202)
static void C_fcall f_5202(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word *av) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word *av) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word *av) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word *av) C_noret;
C_noret_decl(f_5225)
static void C_fcall f_5225(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5230)
static void C_fcall f_5230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5266)
static void C_fcall f_5266(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5269)
static void C_fcall f_5269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word *av) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word *av) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word *av) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word *av) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word *av) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word *av) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word *av) C_noret;
C_noret_decl(f_5317)
static void C_fcall f_5317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_fcall f_5320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word *av) C_noret;
C_noret_decl(f_5326)
static void C_fcall f_5326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_fcall f_5329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_fcall f_5332(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5335)
static void C_fcall f_5335(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_fcall f_5338(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_fcall f_5341(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_fcall f_5344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5347)
static void C_fcall f_5347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5350)
static void C_fcall f_5350(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5353)
static void C_fcall f_5353(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_fcall f_5356(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5359)
static void C_fcall f_5359(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5362)
static void C_fcall f_5362(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5365)
static void C_fcall f_5365(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_fcall f_5368(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5371)
static void C_fcall f_5371(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5374)
static void C_fcall f_5374(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_fcall f_5377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_fcall f_5382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5387)
static void C_fcall f_5387(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_fcall f_5392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5397)
static void C_fcall f_5397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word *av) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word *av) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word *av) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word *av) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word *av) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word *av) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word *av) C_noret;
C_noret_decl(f_5424)
static void C_fcall f_5424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5427)
static void C_fcall f_5427(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_fcall f_5430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5433)
static void C_fcall f_5433(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_fcall f_5436(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word *av) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word *av) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word *av) C_noret;
C_noret_decl(f_5451)
static void C_ccall f_5451(C_word c,C_word *av) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word *av) C_noret;
C_noret_decl(f_5460)
static void C_ccall f_5460(C_word c,C_word *av) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word *av) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word *av) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word *av) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word *av) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word *av) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word *av) C_noret;
C_noret_decl(f_5505)
static void C_ccall f_5505(C_word c,C_word *av) C_noret;
C_noret_decl(f_5508)
static void C_ccall f_5508(C_word c,C_word *av) C_noret;
C_noret_decl(f_5511)
static void C_fcall f_5511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word *av) C_noret;
C_noret_decl(f_5518)
static void C_fcall f_5518(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word *av) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word *av) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word *av) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word *av) C_noret;
C_noret_decl(f_5543)
static void C_fcall f_5543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word *av) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word *av) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word *av) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word *av) C_noret;
C_noret_decl(f_5571)
static void C_fcall f_5571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word *av) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word *av) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word *av) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word *av) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word *av) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word *av) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word *av) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word *av) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word *av) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word *av) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word *av) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word *av) C_noret;
C_noret_decl(f_5633)
static void C_ccall f_5633(C_word c,C_word *av) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word *av) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word *av) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word *av) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word *av) C_noret;
C_noret_decl(f_5648)
static void C_ccall f_5648(C_word c,C_word *av) C_noret;
C_noret_decl(f_5651)
static void C_fcall f_5651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5654)
static void C_ccall f_5654(C_word c,C_word *av) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657(C_word c,C_word *av) C_noret;
C_noret_decl(f_5661)
static void C_fcall f_5661(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5667)
static void C_ccall f_5667(C_word c,C_word *av) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word *av) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word *av) C_noret;
C_noret_decl(f_5684)
static void C_ccall f_5684(C_word c,C_word *av) C_noret;
C_noret_decl(f_5687)
static void C_fcall f_5687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5693)
static void C_ccall f_5693(C_word c,C_word *av) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word *av) C_noret;
C_noret_decl(f_5699)
static void C_ccall f_5699(C_word c,C_word *av) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word *av) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word *av) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word *av) C_noret;
C_noret_decl(f_5711)
static void C_ccall f_5711(C_word c,C_word *av) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word *av) C_noret;
C_noret_decl(f_5719)
static void C_ccall f_5719(C_word c,C_word *av) C_noret;
C_noret_decl(f_5722)
static void C_ccall f_5722(C_word c,C_word *av) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725(C_word c,C_word *av) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word *av) C_noret;
C_noret_decl(f_5731)
static void C_ccall f_5731(C_word c,C_word *av) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word *av) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word *av) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word *av) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word *av) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word *av) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word *av) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word *av) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word *av) C_noret;
C_noret_decl(f_5758)
static void C_ccall f_5758(C_word c,C_word *av) C_noret;
C_noret_decl(f_5761)
static void C_fcall f_5761(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5767)
static void C_ccall f_5767(C_word c,C_word *av) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word *av) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word *av) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word *av) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word *av) C_noret;
C_noret_decl(f_5784)
static void C_fcall f_5784(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word *av) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791(C_word c,C_word *av) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word *av) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word *av) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word *av) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word *av) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word *av) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word *av) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word *av) C_noret;
C_noret_decl(f_5830)
static void C_ccall f_5830(C_word c,C_word *av) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word *av) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word *av) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word *av) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word *av) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word *av) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883(C_word c,C_word *av) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word *av) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word *av) C_noret;
C_noret_decl(f_5892)
static void C_ccall f_5892(C_word c,C_word *av) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word *av) C_noret;
C_noret_decl(f_5911)
static void C_ccall f_5911(C_word c,C_word *av) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word *av) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word *av) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word *av) C_noret;
C_noret_decl(f_5924)
static void C_ccall f_5924(C_word c,C_word *av) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word *av) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word *av) C_noret;
C_noret_decl(f_5933)
static void C_ccall f_5933(C_word c,C_word *av) C_noret;
C_noret_decl(f_5936)
static void C_ccall f_5936(C_word c,C_word *av) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word *av) C_noret;
C_noret_decl(f_5942)
static void C_ccall f_5942(C_word c,C_word *av) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word *av) C_noret;
C_noret_decl(f_5953)
static void C_ccall f_5953(C_word c,C_word *av) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word *av) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word *av) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word *av) C_noret;
C_noret_decl(f_5966)
static void C_ccall f_5966(C_word c,C_word *av) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word *av) C_noret;
C_noret_decl(f_5972)
static void C_ccall f_5972(C_word c,C_word *av) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word *av) C_noret;
C_noret_decl(f_5978)
static void C_ccall f_5978(C_word c,C_word *av) C_noret;
C_noret_decl(f_5981)
static void C_ccall f_5981(C_word c,C_word *av) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word *av) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word *av) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word *av) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word *av) C_noret;
C_noret_decl(f_6035)
static void C_ccall f_6035(C_word c,C_word *av) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word *av) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word *av) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word *av) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word *av) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word *av) C_noret;
C_noret_decl(f_6068)
static void C_ccall f_6068(C_word c,C_word *av) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word *av) C_noret;
C_noret_decl(f_6075)
static void C_ccall f_6075(C_word c,C_word *av) C_noret;
C_noret_decl(f_6084)
static void C_ccall f_6084(C_word c,C_word *av) C_noret;
C_noret_decl(f_6087)
static void C_ccall f_6087(C_word c,C_word *av) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word *av) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word *av) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word *av) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word *av) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139(C_word c,C_word *av) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148(C_word c,C_word *av) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word *av) C_noret;
C_noret_decl(f_6163)
static void C_ccall f_6163(C_word c,C_word *av) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word *av) C_noret;
C_noret_decl(f_6173)
static void C_ccall f_6173(C_word c,C_word *av) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word *av) C_noret;
C_noret_decl(f_6181)
static void C_ccall f_6181(C_word c,C_word *av) C_noret;
C_noret_decl(f_6184)
static void C_ccall f_6184(C_word c,C_word *av) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word *av) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word *av) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word *av) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word *av) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word *av) C_noret;
C_noret_decl(f_6202)
static void C_ccall f_6202(C_word c,C_word *av) C_noret;
C_noret_decl(f_6208)
static void C_fcall f_6208(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6218)
static void C_ccall f_6218(C_word c,C_word *av) C_noret;
C_noret_decl(f_6231)
static void C_fcall f_6231(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6241)
static void C_ccall f_6241(C_word c,C_word *av) C_noret;
C_noret_decl(f_6260)
static void C_ccall f_6260(C_word c,C_word *av) C_noret;
C_noret_decl(f_6272)
static void C_ccall f_6272(C_word c,C_word *av) C_noret;
C_noret_decl(f_6283)
static void C_fcall f_6283(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6293)
static void C_ccall f_6293(C_word c,C_word *av) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word *av) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word *av) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word *av) C_noret;
C_noret_decl(f_6330)
static void C_fcall f_6330(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6340)
static void C_ccall f_6340(C_word c,C_word *av) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word *av) C_noret;
C_noret_decl(f_6367)
static void C_ccall f_6367(C_word c,C_word *av) C_noret;
C_noret_decl(f_6369)
static void C_fcall f_6369(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word *av) C_noret;
C_noret_decl(f_6409)
static void C_ccall f_6409(C_word c,C_word *av) C_noret;
C_noret_decl(f_6413)
static void C_ccall f_6413(C_word c,C_word *av) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word *av) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word *av) C_noret;
C_noret_decl(f_6429)
static void C_ccall f_6429(C_word c,C_word *av) C_noret;
C_noret_decl(f_6434)
static void C_fcall f_6434(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6459)
static void C_ccall f_6459(C_word c,C_word *av) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word *av) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word *av) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word *av) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word *av) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word *av) C_noret;
C_noret_decl(f_6506)
static void C_ccall f_6506(C_word c,C_word *av) C_noret;
C_noret_decl(f_6509)
static void C_ccall f_6509(C_word c,C_word *av) C_noret;
C_noret_decl(f_6512)
static void C_ccall f_6512(C_word c,C_word *av) C_noret;
C_noret_decl(f_6529)
static void C_fcall f_6529(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word *av) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word *av) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word *av) C_noret;
C_noret_decl(f_6572)
static void C_ccall f_6572(C_word c,C_word *av) C_noret;
C_noret_decl(f_6578)
static void C_ccall f_6578(C_word c,C_word *av) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word *av) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word *av) C_noret;
C_noret_decl(f_6588)
static void C_ccall f_6588(C_word c,C_word *av) C_noret;
C_noret_decl(f_6595)
static void C_ccall f_6595(C_word c,C_word *av) C_noret;
C_noret_decl(f_6597)
static void C_fcall f_6597(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word *av) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word *av) C_noret;
C_noret_decl(f_6645)
static void C_ccall f_6645(C_word c,C_word *av) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word *av) C_noret;
C_noret_decl(f_6651)
static void C_ccall f_6651(C_word c,C_word *av) C_noret;
C_noret_decl(f_6654)
static void C_ccall f_6654(C_word c,C_word *av) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word *av) C_noret;
C_noret_decl(f_6668)
static void C_ccall f_6668(C_word c,C_word *av) C_noret;
C_noret_decl(f_6670)
static void C_fcall f_6670(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word *av) C_noret;
C_noret_decl(f_6713)
static void C_ccall f_6713(C_word c,C_word *av) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word *av) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word *av) C_noret;
C_noret_decl(f_6748)
static void C_ccall f_6748(C_word c,C_word *av) C_noret;
C_noret_decl(f_6750)
static void C_fcall f_6750(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6775)
static void C_ccall f_6775(C_word c,C_word *av) C_noret;
C_noret_decl(f_6807)
static void C_ccall f_6807(C_word c,C_word *av) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word *av) C_noret;
C_noret_decl(f_6826)
static void C_fcall f_6826(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6830)
static void C_ccall f_6830(C_word c,C_word *av) C_noret;
C_noret_decl(f_6856)
static void C_fcall f_6856(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6890)
static void C_fcall f_6890(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6924)
static void C_fcall f_6924(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6949)
static void C_ccall f_6949(C_word c,C_word *av) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word *av) C_noret;
C_noret_decl(f_6981)
static void C_ccall f_6981(C_word c,C_word *av) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word *av) C_noret;
C_noret_decl(f_6993)
static void C_fcall f_6993(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7018)
static void C_ccall f_7018(C_word c,C_word *av) C_noret;
C_noret_decl(f_7028)
static void C_ccall f_7028(C_word c,C_word *av) C_noret;
C_noret_decl(f_7032)
static void C_ccall f_7032(C_word c,C_word *av) C_noret;
C_noret_decl(f_7037)
static void C_fcall f_7037(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7048)
static void C_ccall f_7048(C_word c,C_word *av) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word *av) C_noret;
C_noret_decl(f_7062)
static void C_ccall f_7062(C_word c,C_word *av) C_noret;
C_noret_decl(f_7072)
static void C_ccall f_7072(C_word c,C_word *av) C_noret;
C_noret_decl(f_7074)
static void C_fcall f_7074(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7099)
static void C_ccall f_7099(C_word c,C_word *av) C_noret;
C_noret_decl(f_7108)
static void C_fcall f_7108(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133(C_word c,C_word *av) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word *av) C_noret;
C_noret_decl(f_7149)
static void C_ccall f_7149(C_word c,C_word *av) C_noret;
C_noret_decl(f_7156)
static void C_ccall f_7156(C_word c,C_word *av) C_noret;
C_noret_decl(f_7161)
static void C_ccall f_7161(C_word c,C_word *av) C_noret;
C_noret_decl(f_7167)
static void C_fcall f_7167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7171)
static void C_ccall f_7171(C_word c,C_word *av) C_noret;
C_noret_decl(f_7189)
static void C_ccall f_7189(C_word c,C_word *av) C_noret;
C_noret_decl(f_7196)
static void C_ccall f_7196(C_word c,C_word *av) C_noret;
C_noret_decl(f_7204)
static void C_ccall f_7204(C_word c,C_word *av) C_noret;
C_noret_decl(f_7222)
static void C_ccall f_7222(C_word c,C_word *av) C_noret;
C_noret_decl(f_7228)
static void C_ccall f_7228(C_word c,C_word *av) C_noret;
C_noret_decl(f_7277)
static void C_ccall f_7277(C_word c,C_word *av) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word *av) C_noret;
C_noret_decl(f_7300)
static void C_ccall f_7300(C_word c,C_word *av) C_noret;
C_noret_decl(f_7303)
static void C_ccall f_7303(C_word c,C_word *av) C_noret;
C_noret_decl(f_7309)
static void C_ccall f_7309(C_word c,C_word *av) C_noret;
C_noret_decl(f_7311)
static void C_fcall f_7311(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7336)
static void C_ccall f_7336(C_word c,C_word *av) C_noret;
C_noret_decl(f_7360)
static void C_ccall f_7360(C_word c,C_word *av) C_noret;
C_noret_decl(f_7367)
static void C_ccall f_7367(C_word c,C_word *av) C_noret;
C_noret_decl(f_7372)
static void C_fcall f_7372(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7397)
static void C_ccall f_7397(C_word c,C_word *av) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word *av) C_noret;
C_noret_decl(f_7410)
static void C_fcall f_7410(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7420)
static void C_ccall f_7420(C_word c,C_word *av) C_noret;
C_noret_decl(f_7433)
static void C_fcall f_7433(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7443)
static void C_ccall f_7443(C_word c,C_word *av) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word *av) C_noret;
C_noret_decl(f_7464)
static void C_ccall f_7464(C_word c,C_word *av) C_noret;
C_noret_decl(f_7466)
static void C_fcall f_7466(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476(C_word c,C_word *av) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word *av) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word *av) C_noret;
C_noret_decl(f_7510)
static void C_ccall f_7510(C_word c,C_word *av) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word *av) C_noret;
C_noret_decl(f_7524)
static void C_ccall f_7524(C_word c,C_word *av) C_noret;
C_noret_decl(f_7535)
static void C_fcall f_7535(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7545)
static void C_ccall f_7545(C_word c,C_word *av) C_noret;
C_noret_decl(f_7558)
static void C_fcall f_7558(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7568)
static void C_ccall f_7568(C_word c,C_word *av) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613(C_word c,C_word *av) C_noret;
C_noret_decl(f_7619)
static void C_ccall f_7619(C_word c,C_word *av) C_noret;
C_noret_decl(f_7621)
static void C_fcall f_7621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646(C_word c,C_word *av) C_noret;
C_noret_decl(f_7658)
static void C_ccall f_7658(C_word c,C_word *av) C_noret;
C_noret_decl(f_7661)
static void C_ccall f_7661(C_word c,C_word *av) C_noret;
C_noret_decl(f_7664)
static void C_ccall f_7664(C_word c,C_word *av) C_noret;
C_noret_decl(f_7667)
static void C_ccall f_7667(C_word c,C_word *av) C_noret;
C_noret_decl(f_7675)
static void C_ccall f_7675(C_word c,C_word *av) C_noret;
C_noret_decl(f_7683)
static void C_ccall f_7683(C_word c,C_word *av) C_noret;
C_noret_decl(f_7689)
static void C_ccall f_7689(C_word c,C_word *av) C_noret;
C_noret_decl(f_7722)
static void C_ccall f_7722(C_word c,C_word *av) C_noret;
C_noret_decl(f_7725)
static void C_ccall f_7725(C_word c,C_word *av) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word *av) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word *av) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word *av) C_noret;
C_noret_decl(f_7745)
static void C_ccall f_7745(C_word c,C_word *av) C_noret;
C_noret_decl(f_7751)
static void C_ccall f_7751(C_word c,C_word *av) C_noret;
C_noret_decl(f_7755)
static void C_ccall f_7755(C_word c,C_word *av) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word *av) C_noret;
C_noret_decl(f_7834)
static void C_fcall f_7834(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7859)
static void C_ccall f_7859(C_word c,C_word *av) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word *av) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word *av) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word *av) C_noret;
C_noret_decl(f_7898)
static void C_fcall f_7898(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7923)
static void C_ccall f_7923(C_word c,C_word *av) C_noret;
C_noret_decl(f_7934)
static void C_ccall f_7934(C_word c,C_word *av) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word *av) C_noret;
C_noret_decl(f_7952)
static void C_ccall f_7952(C_word c,C_word *av) C_noret;
C_noret_decl(f_7969)
static void C_fcall f_7969(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7994)
static void C_ccall f_7994(C_word c,C_word *av) C_noret;
C_noret_decl(f_8005)
static void C_ccall f_8005(C_word c,C_word *av) C_noret;
C_noret_decl(f_8009)
static void C_fcall f_8009(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word *av) C_noret;
C_noret_decl(f_8037)
static void C_ccall f_8037(C_word c,C_word *av) C_noret;
C_noret_decl(f_8048)
static void C_fcall f_8048(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8067)
static void C_ccall f_8067(C_word c,C_word *av) C_noret;
C_noret_decl(f_8075)
static void C_fcall f_8075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8082)
static void C_fcall f_8082(C_word t0,C_word t1) C_noret;
C_noret_decl(C_batch_2ddriver_toplevel)
C_externexport void C_ccall C_batch_2ddriver_toplevel(C_word c,C_word *av) C_noret;

C_noret_decl(trf_2915)
static void C_ccall trf_2915(C_word c,C_word *av) C_noret;
static void C_ccall trf_2915(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2915(t0,t1,t2,t3);}

C_noret_decl(trf_2930)
static void C_ccall trf_2930(C_word c,C_word *av) C_noret;
static void C_ccall trf_2930(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2930(t0,t1,t2);}

C_noret_decl(trf_2938)
static void C_ccall trf_2938(C_word c,C_word *av) C_noret;
static void C_ccall trf_2938(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2938(t0,t1,t2,t3);}

C_noret_decl(trf_2970)
static void C_ccall trf_2970(C_word c,C_word *av) C_noret;
static void C_ccall trf_2970(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2970(t0,t1,t2);}

C_noret_decl(trf_3002)
static void C_ccall trf_3002(C_word c,C_word *av) C_noret;
static void C_ccall trf_3002(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3002(t0,t1,t2);}

C_noret_decl(trf_3051)
static void C_ccall trf_3051(C_word c,C_word *av) C_noret;
static void C_ccall trf_3051(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3051(t0,t1,t2);}

C_noret_decl(trf_3091)
static void C_ccall trf_3091(C_word c,C_word *av) C_noret;
static void C_ccall trf_3091(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3091(t0,t1,t2);}

C_noret_decl(trf_3177)
static void C_ccall trf_3177(C_word c,C_word *av) C_noret;
static void C_ccall trf_3177(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3177(t0,t1);}

C_noret_decl(trf_3183)
static void C_ccall trf_3183(C_word c,C_word *av) C_noret;
static void C_ccall trf_3183(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3183(t0,t1,t2);}

C_noret_decl(trf_3211)
static void C_ccall trf_3211(C_word c,C_word *av) C_noret;
static void C_ccall trf_3211(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3211(t0,t1,t2);}

C_noret_decl(trf_3325)
static void C_ccall trf_3325(C_word c,C_word *av) C_noret;
static void C_ccall trf_3325(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3325(t0,t1,t2);}

C_noret_decl(trf_3334)
static void C_ccall trf_3334(C_word c,C_word *av) C_noret;
static void C_ccall trf_3334(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3334(t0,t1,t2);}

C_noret_decl(trf_3342)
static void C_ccall trf_3342(C_word c,C_word *av) C_noret;
static void C_ccall trf_3342(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3342(t0,t1,t2,t3);}

C_noret_decl(trf_4093)
static void C_ccall trf_4093(C_word c,C_word *av) C_noret;
static void C_ccall trf_4093(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4093(t0,t1);}

C_noret_decl(trf_4133)
static void C_ccall trf_4133(C_word c,C_word *av) C_noret;
static void C_ccall trf_4133(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4133(t0,t1,t2);}

C_noret_decl(trf_4156)
static void C_ccall trf_4156(C_word c,C_word *av) C_noret;
static void C_ccall trf_4156(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4156(t0,t1,t2);}

C_noret_decl(trf_4179)
static void C_ccall trf_4179(C_word c,C_word *av) C_noret;
static void C_ccall trf_4179(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4179(t0,t1,t2);}

C_noret_decl(trf_4202)
static void C_ccall trf_4202(C_word c,C_word *av) C_noret;
static void C_ccall trf_4202(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4202(t0,t1,t2);}

C_noret_decl(trf_4206)
static void C_ccall trf_4206(C_word c,C_word *av) C_noret;
static void C_ccall trf_4206(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4206(t0,t1);}

C_noret_decl(trf_4273)
static void C_ccall trf_4273(C_word c,C_word *av) C_noret;
static void C_ccall trf_4273(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4273(t0,t1,t2);}

C_noret_decl(trf_4297)
static void C_ccall trf_4297(C_word c,C_word *av) C_noret;
static void C_ccall trf_4297(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4297(t0,t1);}

C_noret_decl(trf_4324)
static void C_ccall trf_4324(C_word c,C_word *av) C_noret;
static void C_ccall trf_4324(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4324(t0,t1);}

C_noret_decl(trf_4393)
static void C_ccall trf_4393(C_word c,C_word *av) C_noret;
static void C_ccall trf_4393(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4393(t0,t1,t2);}

C_noret_decl(trf_4417)
static void C_ccall trf_4417(C_word c,C_word *av) C_noret;
static void C_ccall trf_4417(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4417(t0,t1);}

C_noret_decl(trf_4496)
static void C_ccall trf_4496(C_word c,C_word *av) C_noret;
static void C_ccall trf_4496(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4496(t0,t1);}

C_noret_decl(trf_4787)
static void C_ccall trf_4787(C_word c,C_word *av) C_noret;
static void C_ccall trf_4787(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4787(t0,t1);}

C_noret_decl(trf_4865)
static void C_ccall trf_4865(C_word c,C_word *av) C_noret;
static void C_ccall trf_4865(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4865(t0,t1);}

C_noret_decl(trf_4885)
static void C_ccall trf_4885(C_word c,C_word *av) C_noret;
static void C_ccall trf_4885(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4885(t0,t1);}

C_noret_decl(trf_4908)
static void C_ccall trf_4908(C_word c,C_word *av) C_noret;
static void C_ccall trf_4908(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4908(t0,t1,t2);}

C_noret_decl(trf_4935)
static void C_ccall trf_4935(C_word c,C_word *av) C_noret;
static void C_ccall trf_4935(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_4935(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4957)
static void C_ccall trf_4957(C_word c,C_word *av) C_noret;
static void C_ccall trf_4957(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_4957(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4984)
static void C_ccall trf_4984(C_word c,C_word *av) C_noret;
static void C_ccall trf_4984(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_4984(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5007)
static void C_ccall trf_5007(C_word c,C_word *av) C_noret;
static void C_ccall trf_5007(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5007(t0,t1,t2);}

C_noret_decl(trf_5030)
static void C_ccall trf_5030(C_word c,C_word *av) C_noret;
static void C_ccall trf_5030(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5030(t0,t1);}

C_noret_decl(trf_5115)
static void C_ccall trf_5115(C_word c,C_word *av) C_noret;
static void C_ccall trf_5115(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5115(t0,t1,t2);}

C_noret_decl(trf_5121)
static void C_ccall trf_5121(C_word c,C_word *av) C_noret;
static void C_ccall trf_5121(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5121(t0,t1,t2);}

C_noret_decl(trf_5129)
static void C_ccall trf_5129(C_word c,C_word *av) C_noret;
static void C_ccall trf_5129(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5129(t0,t1,t2);}

C_noret_decl(trf_5150)
static void C_ccall trf_5150(C_word c,C_word *av) C_noret;
static void C_ccall trf_5150(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5150(t0,t1);}

C_noret_decl(trf_5160)
static void C_ccall trf_5160(C_word c,C_word *av) C_noret;
static void C_ccall trf_5160(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5160(t0,t1,t2);}

C_noret_decl(trf_5200)
static void C_ccall trf_5200(C_word c,C_word *av) C_noret;
static void C_ccall trf_5200(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_5200(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5202)
static void C_ccall trf_5202(C_word c,C_word *av) C_noret;
static void C_ccall trf_5202(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5202(t0,t1,t2,t3);}

C_noret_decl(trf_5225)
static void C_ccall trf_5225(C_word c,C_word *av) C_noret;
static void C_ccall trf_5225(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5225(t0,t1,t2);}

C_noret_decl(trf_5230)
static void C_ccall trf_5230(C_word c,C_word *av) C_noret;
static void C_ccall trf_5230(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5230(t0,t1);}

C_noret_decl(trf_5266)
static void C_ccall trf_5266(C_word c,C_word *av) C_noret;
static void C_ccall trf_5266(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5266(t0,t1);}

C_noret_decl(trf_5269)
static void C_ccall trf_5269(C_word c,C_word *av) C_noret;
static void C_ccall trf_5269(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5269(t0,t1);}

C_noret_decl(trf_5317)
static void C_ccall trf_5317(C_word c,C_word *av) C_noret;
static void C_ccall trf_5317(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5317(t0,t1);}

C_noret_decl(trf_5320)
static void C_ccall trf_5320(C_word c,C_word *av) C_noret;
static void C_ccall trf_5320(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5320(t0,t1);}

C_noret_decl(trf_5326)
static void C_ccall trf_5326(C_word c,C_word *av) C_noret;
static void C_ccall trf_5326(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5326(t0,t1);}

C_noret_decl(trf_5329)
static void C_ccall trf_5329(C_word c,C_word *av) C_noret;
static void C_ccall trf_5329(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5329(t0,t1);}

C_noret_decl(trf_5332)
static void C_ccall trf_5332(C_word c,C_word *av) C_noret;
static void C_ccall trf_5332(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5332(t0,t1);}

C_noret_decl(trf_5335)
static void C_ccall trf_5335(C_word c,C_word *av) C_noret;
static void C_ccall trf_5335(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5335(t0,t1);}

C_noret_decl(trf_5338)
static void C_ccall trf_5338(C_word c,C_word *av) C_noret;
static void C_ccall trf_5338(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5338(t0,t1);}

C_noret_decl(trf_5341)
static void C_ccall trf_5341(C_word c,C_word *av) C_noret;
static void C_ccall trf_5341(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5341(t0,t1);}

C_noret_decl(trf_5344)
static void C_ccall trf_5344(C_word c,C_word *av) C_noret;
static void C_ccall trf_5344(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5344(t0,t1);}

C_noret_decl(trf_5347)
static void C_ccall trf_5347(C_word c,C_word *av) C_noret;
static void C_ccall trf_5347(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5347(t0,t1);}

C_noret_decl(trf_5350)
static void C_ccall trf_5350(C_word c,C_word *av) C_noret;
static void C_ccall trf_5350(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5350(t0,t1);}

C_noret_decl(trf_5353)
static void C_ccall trf_5353(C_word c,C_word *av) C_noret;
static void C_ccall trf_5353(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5353(t0,t1);}

C_noret_decl(trf_5356)
static void C_ccall trf_5356(C_word c,C_word *av) C_noret;
static void C_ccall trf_5356(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5356(t0,t1);}

C_noret_decl(trf_5359)
static void C_ccall trf_5359(C_word c,C_word *av) C_noret;
static void C_ccall trf_5359(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5359(t0,t1);}

C_noret_decl(trf_5362)
static void C_ccall trf_5362(C_word c,C_word *av) C_noret;
static void C_ccall trf_5362(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5362(t0,t1);}

C_noret_decl(trf_5365)
static void C_ccall trf_5365(C_word c,C_word *av) C_noret;
static void C_ccall trf_5365(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5365(t0,t1);}

C_noret_decl(trf_5368)
static void C_ccall trf_5368(C_word c,C_word *av) C_noret;
static void C_ccall trf_5368(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5368(t0,t1);}

C_noret_decl(trf_5371)
static void C_ccall trf_5371(C_word c,C_word *av) C_noret;
static void C_ccall trf_5371(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5371(t0,t1);}

C_noret_decl(trf_5374)
static void C_ccall trf_5374(C_word c,C_word *av) C_noret;
static void C_ccall trf_5374(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5374(t0,t1);}

C_noret_decl(trf_5377)
static void C_ccall trf_5377(C_word c,C_word *av) C_noret;
static void C_ccall trf_5377(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5377(t0,t1);}

C_noret_decl(trf_5382)
static void C_ccall trf_5382(C_word c,C_word *av) C_noret;
static void C_ccall trf_5382(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5382(t0,t1);}

C_noret_decl(trf_5387)
static void C_ccall trf_5387(C_word c,C_word *av) C_noret;
static void C_ccall trf_5387(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5387(t0,t1);}

C_noret_decl(trf_5392)
static void C_ccall trf_5392(C_word c,C_word *av) C_noret;
static void C_ccall trf_5392(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5392(t0,t1);}

C_noret_decl(trf_5397)
static void C_ccall trf_5397(C_word c,C_word *av) C_noret;
static void C_ccall trf_5397(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5397(t0,t1);}

C_noret_decl(trf_5424)
static void C_ccall trf_5424(C_word c,C_word *av) C_noret;
static void C_ccall trf_5424(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5424(t0,t1);}

C_noret_decl(trf_5427)
static void C_ccall trf_5427(C_word c,C_word *av) C_noret;
static void C_ccall trf_5427(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5427(t0,t1);}

C_noret_decl(trf_5430)
static void C_ccall trf_5430(C_word c,C_word *av) C_noret;
static void C_ccall trf_5430(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5430(t0,t1);}

C_noret_decl(trf_5433)
static void C_ccall trf_5433(C_word c,C_word *av) C_noret;
static void C_ccall trf_5433(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5433(t0,t1);}

C_noret_decl(trf_5436)
static void C_ccall trf_5436(C_word c,C_word *av) C_noret;
static void C_ccall trf_5436(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5436(t0,t1);}

C_noret_decl(trf_5511)
static void C_ccall trf_5511(C_word c,C_word *av) C_noret;
static void C_ccall trf_5511(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5511(t0,t1);}

C_noret_decl(trf_5518)
static void C_ccall trf_5518(C_word c,C_word *av) C_noret;
static void C_ccall trf_5518(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5518(t0,t1);}

C_noret_decl(trf_5543)
static void C_ccall trf_5543(C_word c,C_word *av) C_noret;
static void C_ccall trf_5543(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5543(t0,t1);}

C_noret_decl(trf_5571)
static void C_ccall trf_5571(C_word c,C_word *av) C_noret;
static void C_ccall trf_5571(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5571(t0,t1);}

C_noret_decl(trf_5651)
static void C_ccall trf_5651(C_word c,C_word *av) C_noret;
static void C_ccall trf_5651(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5651(t0,t1);}

C_noret_decl(trf_5661)
static void C_ccall trf_5661(C_word c,C_word *av) C_noret;
static void C_ccall trf_5661(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5661(t0,t1,t2);}

C_noret_decl(trf_5687)
static void C_ccall trf_5687(C_word c,C_word *av) C_noret;
static void C_ccall trf_5687(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5687(t0,t1);}

C_noret_decl(trf_5761)
static void C_ccall trf_5761(C_word c,C_word *av) C_noret;
static void C_ccall trf_5761(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5761(t0,t1);}

C_noret_decl(trf_5784)
static void C_ccall trf_5784(C_word c,C_word *av) C_noret;
static void C_ccall trf_5784(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_5784(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6208)
static void C_ccall trf_6208(C_word c,C_word *av) C_noret;
static void C_ccall trf_6208(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6208(t0,t1,t2);}

C_noret_decl(trf_6231)
static void C_ccall trf_6231(C_word c,C_word *av) C_noret;
static void C_ccall trf_6231(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6231(t0,t1,t2);}

C_noret_decl(trf_6283)
static void C_ccall trf_6283(C_word c,C_word *av) C_noret;
static void C_ccall trf_6283(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6283(t0,t1,t2);}

C_noret_decl(trf_6330)
static void C_ccall trf_6330(C_word c,C_word *av) C_noret;
static void C_ccall trf_6330(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6330(t0,t1,t2);}

C_noret_decl(trf_6369)
static void C_ccall trf_6369(C_word c,C_word *av) C_noret;
static void C_ccall trf_6369(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6369(t0,t1,t2);}

C_noret_decl(trf_6434)
static void C_ccall trf_6434(C_word c,C_word *av) C_noret;
static void C_ccall trf_6434(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6434(t0,t1,t2);}

C_noret_decl(trf_6529)
static void C_ccall trf_6529(C_word c,C_word *av) C_noret;
static void C_ccall trf_6529(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6529(t0,t1,t2);}

C_noret_decl(trf_6597)
static void C_ccall trf_6597(C_word c,C_word *av) C_noret;
static void C_ccall trf_6597(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6597(t0,t1,t2);}

C_noret_decl(trf_6670)
static void C_ccall trf_6670(C_word c,C_word *av) C_noret;
static void C_ccall trf_6670(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6670(t0,t1,t2);}

C_noret_decl(trf_6750)
static void C_ccall trf_6750(C_word c,C_word *av) C_noret;
static void C_ccall trf_6750(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6750(t0,t1,t2);}

C_noret_decl(trf_6826)
static void C_ccall trf_6826(C_word c,C_word *av) C_noret;
static void C_ccall trf_6826(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6826(t0,t1);}

C_noret_decl(trf_6856)
static void C_ccall trf_6856(C_word c,C_word *av) C_noret;
static void C_ccall trf_6856(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6856(t0,t1,t2);}

C_noret_decl(trf_6890)
static void C_ccall trf_6890(C_word c,C_word *av) C_noret;
static void C_ccall trf_6890(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6890(t0,t1,t2);}

C_noret_decl(trf_6924)
static void C_ccall trf_6924(C_word c,C_word *av) C_noret;
static void C_ccall trf_6924(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6924(t0,t1,t2);}

C_noret_decl(trf_6993)
static void C_ccall trf_6993(C_word c,C_word *av) C_noret;
static void C_ccall trf_6993(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6993(t0,t1,t2);}

C_noret_decl(trf_7037)
static void C_ccall trf_7037(C_word c,C_word *av) C_noret;
static void C_ccall trf_7037(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7037(t0,t1,t2);}

C_noret_decl(trf_7074)
static void C_ccall trf_7074(C_word c,C_word *av) C_noret;
static void C_ccall trf_7074(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7074(t0,t1,t2);}

C_noret_decl(trf_7108)
static void C_ccall trf_7108(C_word c,C_word *av) C_noret;
static void C_ccall trf_7108(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7108(t0,t1,t2);}

C_noret_decl(trf_7167)
static void C_ccall trf_7167(C_word c,C_word *av) C_noret;
static void C_ccall trf_7167(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7167(t0,t1);}

C_noret_decl(trf_7311)
static void C_ccall trf_7311(C_word c,C_word *av) C_noret;
static void C_ccall trf_7311(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7311(t0,t1,t2);}

C_noret_decl(trf_7372)
static void C_ccall trf_7372(C_word c,C_word *av) C_noret;
static void C_ccall trf_7372(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7372(t0,t1,t2);}

C_noret_decl(trf_7410)
static void C_ccall trf_7410(C_word c,C_word *av) C_noret;
static void C_ccall trf_7410(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7410(t0,t1,t2);}

C_noret_decl(trf_7433)
static void C_ccall trf_7433(C_word c,C_word *av) C_noret;
static void C_ccall trf_7433(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7433(t0,t1,t2);}

C_noret_decl(trf_7466)
static void C_ccall trf_7466(C_word c,C_word *av) C_noret;
static void C_ccall trf_7466(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7466(t0,t1,t2);}

C_noret_decl(trf_7535)
static void C_ccall trf_7535(C_word c,C_word *av) C_noret;
static void C_ccall trf_7535(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7535(t0,t1,t2);}

C_noret_decl(trf_7558)
static void C_ccall trf_7558(C_word c,C_word *av) C_noret;
static void C_ccall trf_7558(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7558(t0,t1,t2);}

C_noret_decl(trf_7621)
static void C_ccall trf_7621(C_word c,C_word *av) C_noret;
static void C_ccall trf_7621(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7621(t0,t1,t2);}

C_noret_decl(trf_7834)
static void C_ccall trf_7834(C_word c,C_word *av) C_noret;
static void C_ccall trf_7834(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7834(t0,t1,t2);}

C_noret_decl(trf_7898)
static void C_ccall trf_7898(C_word c,C_word *av) C_noret;
static void C_ccall trf_7898(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7898(t0,t1,t2);}

C_noret_decl(trf_7969)
static void C_ccall trf_7969(C_word c,C_word *av) C_noret;
static void C_ccall trf_7969(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7969(t0,t1,t2);}

C_noret_decl(trf_8009)
static void C_ccall trf_8009(C_word c,C_word *av) C_noret;
static void C_ccall trf_8009(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8009(t0,t1,t2);}

C_noret_decl(trf_8048)
static void C_ccall trf_8048(C_word c,C_word *av) C_noret;
static void C_ccall trf_8048(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8048(t0,t1);}

C_noret_decl(trf_8075)
static void C_ccall trf_8075(C_word c,C_word *av) C_noret;
static void C_ccall trf_8075(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8075(t0,t1);}

C_noret_decl(trf_8082)
static void C_ccall trf_8082(C_word c,C_word *av) C_noret;
static void C_ccall trf_8082(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8082(t0,t1);}

/* f8625 in k5976 in k5973 in k5970 in k5967 in k5964 in k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in ... */
static void C_ccall f8625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f8625,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9109,a[2]=t2,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t3;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[180];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}

/* f9103 in k5982 in k5979 in k5976 in k5973 in k5970 in k5967 in k5964 in k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in ... */
static void C_ccall f9103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9103,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9109 */
static void C_ccall f9109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9109,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9115 in k5964 in k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in ... */
static void C_ccall f9115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9115,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9121 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in ... */
static void C_ccall f9121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9121,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9127 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in ... */
static void C_ccall f9127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9127,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9133 in k6088 in k6085 in k6082 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in ... */
static void C_ccall f9133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9133,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9145 in for-each-loop2006 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in ... */
static void C_ccall f9145(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9145,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9153 in k6307 in for-each-loop1984 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in ... */
static void C_ccall f9153(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9153,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9165 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in ... */
static void C_ccall f9165(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9165,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9189 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in ... */
static void C_ccall f9189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9189,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9195 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in ... */
static void C_ccall f9195(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9195,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9209 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in ... */
static void C_ccall f9209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9209,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9215 in k7226 in k7220 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in ... */
static void C_ccall f9215(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9215,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9221 in k7226 in k7220 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in ... */
static void C_ccall f9221(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9221,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9227 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in ... */
static void C_ccall f9227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9227,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9233 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in ... */
static void C_ccall f9233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9233,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9247 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in ... */
static void C_ccall f9247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9247,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9263 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in ... */
static void C_ccall f9263(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9263,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9269 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in ... */
static void C_ccall f9269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9269,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9275 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in ... */
static void C_ccall f9275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9275,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9281 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in ... */
static void C_ccall f9281(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9281,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f9287 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in ... */
static void C_ccall f9287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f9287,2,av);}
/* batch-driver.scm:253: chicken.compiler.support#debugging */
t2=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2667 */
static void C_ccall f_2669(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2669,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k2670 in k2667 */
static void C_ccall f_2672(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2672,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_expand_toplevel(2,av2);}}

/* k2673 in k2670 in k2667 */
static void C_ccall f_2675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2675,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2678(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2678,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_data_2dstructures_toplevel(2,av2);}}

/* k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2681(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2681,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_pathname_toplevel(2,av2);}}

/* k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2684(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2684,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2687,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_support_toplevel(2,av2);}}

/* k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2687,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_compiler_2dsyntax_toplevel(2,av2);}}

/* k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2690,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2693,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_compiler_toplevel(2,av2);}}

/* k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2693,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_optimizer_toplevel(2,av2);}}

/* k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2696,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2699,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_internal_toplevel(2,av2);}}

/* k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2699,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2702,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_scrutinizer_toplevel(2,av2);}}

/* k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2702,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2705,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_lfa2_toplevel(2,av2);}}

/* k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2705,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2708,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_c_2dplatform_toplevel(2,av2);}}

/* k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2708,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_c_2dbackend_toplevel(2,av2);}}

/* k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2711(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2711,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_user_2dpass_toplevel(2,av2);}}

/* k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(34,c,5)))){
C_save_and_reclaim((void *)f_2714,2,av);}
a=C_alloc(34);
t2=C_a_i_provide(&a,1,lf[0]);
t3=C_a_i_provide(&a,1,lf[1]);
t4=C_mutate(&lf[2] /* (set! chicken.compiler.batch-driver#append-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2915,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[6] /* (set! chicken.compiler.batch-driver#concatenate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3177,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[7] /* (set! chicken.compiler.batch-driver#filter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3325,tmp=(C_word)a,a+=2,tmp));
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate(&lf[8] /* (set! chicken.compiler.batch-driver#initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4093,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_mutate(&lf[18] /* (set! chicken.compiler.batch-driver#display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4202,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[74]+1 /* (set! chicken.compiler.batch-driver#compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4784,tmp=(C_word)a,a+=2,tmp));
t14=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t14;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}

/* chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_2915(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_2915,4,t1,t2,t3,t4);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t4))){
t5=t3;
t6=C_i_check_list_2(t5,lf[3]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2930,a[2]=t2,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_2930(t10,t1,t5);}
else{
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2970,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2970(t9,t1,t5);}}

/* foldr242 in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_2930(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_2930,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2957,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g247 in foldr242 in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_2938(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_2938,4,t0,t1,t2,t3);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2946,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* mini-srfi-1.scm:72: proc */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2944 in g247 in foldr242 in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2946(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2946,2,av);}
/* mini-srfi-1.scm:72: scheme#append */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2955 in foldr242 in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2957(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2957,2,av);}
/* mini-srfi-1.scm:72: g247 */
t2=((C_word*)t0)[2];
f_2938(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* loop in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_2970(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,0,3)))){
C_save_and_reclaim_args((void *)trf_2970,3,t0,t1,t2);}
a=C_alloc(23);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3125,tmp=(C_word)a,a+=2,tmp);
t5=(
  f_3125(t3)
);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2984,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=t2;
t12=C_i_check_list_2(t11,lf[5]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3049,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3051,a[2]=t9,a[3]=t15,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_3051(t17,t13,t11);}}

/* k2982 in loop in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2984(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
C_save_and_reclaim((void *)f_2984,2,av);}
a=C_alloc(20);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)t0)[3];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3002,a[2]=t6,a[3]=t11,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_3002(t13,t9,t8);}

/* k2986 in k2982 in loop in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_2988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2988,2,av);}
/* mini-srfi-1.scm:76: scheme#append */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2998 in k2982 in loop in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_3000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3000,2,av);}
/* mini-srfi-1.scm:77: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_2970(t2,((C_word*)t0)[3],t1);}

/* map-loop284 in k2982 in loop in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_3002(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_3002,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3047 in loop in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_3049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3049,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
C_apply(4,av2);}}

/* map-loop257 in loop in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_3051(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_3051,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in a3714 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in ... */
static void C_fcall f_3091(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3091,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3113,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(t2);
/* mini-srfi-1.scm:82: pred */
t6=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k3111 in loop in a3714 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in ... */
static void C_ccall f_3113(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3113,2,av);}
if(C_truep(C_i_not(t1))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* mini-srfi-1.scm:83: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3091(t4,((C_word*)t0)[2],t3);}}

/* loop in loop in chicken.compiler.batch-driver#append-map in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static C_word C_fcall f_3125(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=C_i_car(t1);
t3=C_i_nullp(t2);
if(C_truep(t3)){
return(t3);}
else{
t4=t1;
t5=C_u_i_cdr(t4);
t7=t5;
t1=t7;
goto loop;}}}

/* chicken.compiler.batch-driver#concatenate in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_3177(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_3177,2,t1,t2);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3183(t6,t1,t2);}

/* loop in chicken.compiler.batch-driver#concatenate in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_3183(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_3183,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3201,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=C_u_i_cdr(t6);
/* mini-srfi-1.scm:101: loop */
t9=t5;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* k3199 in loop in chicken.compiler.batch-driver#concatenate in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_3201(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3201,2,av);}
/* mini-srfi-1.scm:101: scheme#append */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* loop in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in ... */
static void C_fcall f_3211(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_3211,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t2))){
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=C_eqp(lf[133],t3);
if(C_truep(t4)){
t5=t2;
t6=C_u_i_cdr(t5);
/* mini-srfi-1.scm:107: loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}
else{
t5=t2;
t6=C_u_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3238,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t2;
t9=C_u_i_cdr(t8);
/* mini-srfi-1.scm:109: loop */
t11=t7;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}}

/* k3236 in loop in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in ... */
static void C_ccall f_3238(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3238,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* chicken.compiler.batch-driver#filter in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_3325(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,3)))){
C_save_and_reclaim_args((void *)trf_3325,3,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_check_list_2(t3,lf[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3334,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3334(t8,t1,t3);}

/* foldr389 in chicken.compiler.batch-driver#filter in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_3334(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_3334,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3363,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g394 in foldr389 in chicken.compiler.batch-driver#filter in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_3342(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3342,4,t0,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3349,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* mini-srfi-1.scm:131: pred */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3347 in g394 in foldr389 in chicken.compiler.batch-driver#filter in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_3349(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_3349,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3361 in foldr389 in chicken.compiler.batch-driver#filter in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_3363(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3363,2,av);}
/* mini-srfi-1.scm:131: g394 */
t2=((C_word*)t0)[2];
f_3342(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* a3423 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in ... */
static void C_ccall f_3424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_3424,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3432,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* mini-srfi-1.scm:141: pred */
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3430 in a3423 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in ... */
static void C_ccall f_3432(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3432,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_i_not(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a3714 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in ... */
static void C_ccall f_3715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,3)))){
C_save_and_reclaim((void *)f_3715,3,av);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t3;
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3091,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3091(t8,t1,((C_word*)t0)[2]);}

/* a3720 in a3714 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in ... */
static void C_ccall f_3721(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3721,3,av);}
t3=t1;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_i_memq(((C_word*)t0)[2],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a3999 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in ... */
static void C_ccall f_4000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4000,2,av);}
/* batch-driver.scm:70: chicken.compiler.core#compute-database-statistics */
t2=*((C_word*)lf[217]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in ... */
static void C_ccall f_4006(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_4006,9,av);}
a=C_alloc(10);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4013,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t6,a[6]=t5,a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:71: chicken.compiler.support#debugging */
t10=*((C_word*)lf[102]+1);{
C_word *av2=av;
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[216];
av2[3]=lf[225];
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}

/* k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in ... */
static void C_ccall f_4013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_4013,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:72: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[224];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in ... */
static void C_ccall f_4019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_4019,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:72: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[10];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in ... */
static void C_ccall f_4022(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_4022,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:72: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[223];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in ... */
static void C_ccall f_4025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_4025,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:72: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in ... */
static void C_ccall f_4028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_4028,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:72: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in ... */
static void C_ccall f_4031(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_4031,2,av);}
a=C_alloc(9);
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:73: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[222];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in ... */
static void C_ccall f_4037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_4037,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:73: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in ... */
static void C_ccall f_4040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_4040,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:73: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in ... */
static void C_ccall f_4043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,4)))){
C_save_and_reclaim((void *)f_4043,2,av);}
a=C_alloc(8);
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:74: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[221];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4047 in k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in ... */
static void C_ccall f_4049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_4049,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:74: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4050 in k4047 in k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in ... */
static void C_ccall f_4052(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_4052,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:74: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4053 in k4050 in k4047 in k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in ... */
static void C_ccall f_4055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_4055,2,av);}
a=C_alloc(7);
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:75: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[220];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4059 in k4053 in k4050 in k4047 in k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in ... */
static void C_ccall f_4061(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_4061,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:75: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4062 in k4059 in k4053 in k4050 in k4047 in k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in ... */
static void C_ccall f_4064(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4064,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:75: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4065 in k4062 in k4059 in k4053 in k4050 in k4047 in k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in ... */
static void C_ccall f_4067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_4067,2,av);}
a=C_alloc(6);
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:76: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[219];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4071 in k4065 in k4062 in k4059 in k4053 in k4050 in k4047 in k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in k5786 in ... */
static void C_ccall f_4073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4073,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:76: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4074 in k4071 in k4065 in k4062 in k4059 in k4053 in k4050 in k4047 in k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in k5789 in ... */
static void C_ccall f_4076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_4076,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:76: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4077 in k4074 in k4071 in k4065 in k4062 in k4059 in k4053 in k4050 in k4047 in k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in k5792 in ... */
static void C_ccall f_4079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4079,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:77: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[218];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4083 in k4077 in k4074 in k4071 in k4065 in k4062 in k4059 in k4053 in k4050 in k4047 in k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in k5796 in ... */
static void C_ccall f_4085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_4085,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:77: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4086 in k4083 in k4077 in k4074 in k4071 in k4065 in k4062 in k4059 in k4053 in k4050 in k4047 in k4041 in k4038 in k4035 in k4029 in k4026 in k4023 in k4020 in k4017 in k4011 in a4005 in k5799 in ... */
static void C_ccall f_4088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4088,2,av);}
/* batch-driver.scm:77: ##sys#write-char-0 */
t2=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* chicken.compiler.batch-driver#initialize-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_4093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,3)))){
C_save_and_reclaim_args((void *)trf_4093,2,t0,t1);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=*((C_word*)lf[9]+1);
t4=C_i_check_list_2(*((C_word*)lf[9]+1),lf[10]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4109,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4179,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4179(t9,t5,*((C_word*)lf[9]+1));}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4095 in chicken.compiler.batch-driver#initialize-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4097(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4097,2,av);}
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4107 in chicken.compiler.batch-driver#initialize-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_4109,2,av);}
a=C_alloc(8);
t2=*((C_word*)lf[11]+1);
t3=C_i_check_list_2(*((C_word*)lf[11]+1),lf[10]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4156,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4156(t8,t4,*((C_word*)lf[11]+1));}

/* k4118 in k4107 in chicken.compiler.batch-driver#initialize-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4120(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4120,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[12]+1);
t3=C_i_check_list_2(*((C_word*)lf[12]+1),lf[10]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4133,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4133(t7,((C_word*)t0)[2],*((C_word*)lf[12]+1));}

/* for-each-loop775 in k4118 in k4107 in chicken.compiler.batch-driver#initialize-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_4133(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_4133,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4143,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:99: chicken.compiler.support#mark-variable */
t5=*((C_word*)lf[13]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[14];
av2[4]=lf[15];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4141 in for-each-loop775 in k4118 in k4107 in chicken.compiler.batch-driver#initialize-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4143(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4143,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4133(t3,((C_word*)t0)[4],t2);}

/* for-each-loop757 in k4107 in chicken.compiler.batch-driver#initialize-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_4156(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_4156,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4166,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:95: chicken.compiler.support#mark-variable */
t5=*((C_word*)lf[13]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[14];
av2[4]=lf[16];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4164 in for-each-loop757 in k4107 in chicken.compiler.batch-driver#initialize-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4166,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4156(t3,((C_word*)t0)[4],t2);}

/* for-each-loop739 in chicken.compiler.batch-driver#initialize-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_4179(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_4179,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4189,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:91: chicken.compiler.support#mark-variable */
t5=*((C_word*)lf[13]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[14];
av2[4]=lf[17];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4187 in for-each-loop739 in chicken.compiler.batch-driver#initialize-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4189,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4179(t3,((C_word*)t0)[4],t2);}

/* chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_4202(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,4)))){
C_save_and_reclaim_args((void *)trf_4202,3,t0,t1,t2);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4206,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_4206(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:120: scheme#append */
t5=*((C_word*)lf[4]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[72]+1);
av2[3]=*((C_word*)lf[73]+1);
av2[4]=*((C_word*)lf[12]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_4206(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,4)))){
C_save_and_reclaim_args((void *)trf_4206,2,t0,t1);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4211,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:123: chicken.internal#hash-table-for-each */
t3=*((C_word*)lf[71]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4211(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,2)))){
C_save_and_reclaim((void *)f_4211,4,av);}
a=C_alloc(19);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=C_SCHEME_UNDEFINED;
t15=t1;{
C_word *av2=av;
av2[0]=t15;
av2[1]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4221,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=t7,a[6]=t11,a[7]=t13,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:131: scheme#write */
t15=*((C_word*)lf[70]+1);{
C_word *av2=av;
av2[0]=t15;
av2[1]=t14;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}}

/* k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4221(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_4221,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4393,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4393(t6,t2,((C_word*)t0)[8]);}

/* k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4224(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_4224,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[7])[1]))){
t3=*((C_word*)lf[20]+1);
t4=*((C_word*)lf[20]+1);
t5=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:157: ##sys#print */
t7=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[30];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_4227(2,av2);}}}

/* k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in ... */
static void C_ccall f_4227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,4)))){
C_save_and_reclaim((void *)f_4227,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[6])[1]))){
t3=*((C_word*)lf[20]+1);
t4=*((C_word*)lf[20]+1);
t5=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4368,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:158: ##sys#print */
t7=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[29];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_4230(2,av2);}}}

/* k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in ... */
static void C_ccall f_4230(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_4230,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4297,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[28]);
t5=t3;
f_4297(t5,C_i_not(t4));}
else{
t4=t3;
f_4297(t4,C_SCHEME_FALSE);}}

/* k4231 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in ... */
static void C_ccall f_4233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_4233,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4236,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_SCHEME_UNDEFINED;
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4273,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4273(t8,t2,t3);}
else{
/* batch-driver.scm:168: scheme#newline */
t3=*((C_word*)lf[19]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4234 in k4231 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in ... */
static void C_ccall f_4236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4236,2,av);}
/* batch-driver.scm:168: scheme#newline */
t2=*((C_word*)lf[19]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4248 in for-each-loop945 in k4231 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in ... */
static void C_ccall f_4250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4250,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:166: chicken.compiler.support#node-class */
t3=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4259 in k4248 in for-each-loop945 in k4231 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in ... */
static void C_ccall f_4261(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4261,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4265,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:166: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4263 in k4259 in k4248 in for-each-loop945 in k4231 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_ccall f_4265(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4265,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* batch-driver.scm:166: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* for-each-loop945 in k4231 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in ... */
static void C_fcall f_4273(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,4)))){
C_save_and_reclaim_args((void *)trf_4273,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4283,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=*((C_word*)lf[20]+1);
t8=*((C_word*)lf[20]+1);
t9=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4250,a[2]=t5,a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:166: ##sys#print */
t11=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[25];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4281 in for-each-loop945 in k4231 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in ... */
static void C_ccall f_4283(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4283,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4273(t3,((C_word*)t0)[4],t2);}

/* k4295 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in ... */
static void C_fcall f_4297(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_4297,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:160: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[26];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[3])[1],lf[28]);
t4=t2;
f_4324(t4,C_i_not(t3));}
else{
t3=t2;
f_4324(t3,C_SCHEME_FALSE);}}}

/* k4301 in k4295 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in ... */
static void C_ccall f_4303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4303,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:160: chicken.compiler.support#node-class */
t3=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4312 in k4301 in k4295 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in ... */
static void C_ccall f_4314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4314,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4318,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:160: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4316 in k4312 in k4301 in k4295 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in ... */
static void C_ccall f_4318(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4318,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* batch-driver.scm:160: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4322 in k4295 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in ... */
static void C_fcall f_4324(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_4324,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:162: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[27];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
f_4233(2,av2);}}}

/* k4328 in k4322 in k4295 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in ... */
static void C_ccall f_4330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4330,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:162: chicken.compiler.support#node-class */
t3=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4339 in k4328 in k4322 in k4295 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in ... */
static void C_ccall f_4341(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4341,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4345,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:162: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4343 in k4339 in k4328 in k4322 in k4295 in k4228 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_ccall f_4345(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4345,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* batch-driver.scm:162: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4366 in k4225 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in ... */
static void C_ccall f_4368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4368,2,av);}
t2=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm:158: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4382 in k4222 in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in ... */
static void C_ccall f_4384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4384,2,av);}
t2=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm:157: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* loop in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_4393(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,0,2)))){
C_save_and_reclaim_args((void *)trf_4393,3,t0,t1,t2);}
a=C_alloc(17);
if(C_truep(C_i_pairp(t2))){
t3=C_i_caar(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4406,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_eqp(t4,lf[31]);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4417,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t6)){
t8=t7;
f_4417(t8,t6);}
else{
t8=C_eqp(t4,lf[50]);
if(C_truep(t8)){
t9=t7;
f_4417(t9,t8);}
else{
t9=C_eqp(t4,lf[51]);
if(C_truep(t9)){
t10=t7;
f_4417(t10,t9);}
else{
t10=C_eqp(t4,lf[52]);
if(C_truep(t10)){
t11=t7;
f_4417(t11,t10);}
else{
t11=C_eqp(t4,lf[53]);
if(C_truep(t11)){
t12=t7;
f_4417(t12,t11);}
else{
t12=C_eqp(t4,lf[54]);
if(C_truep(t12)){
t13=t7;
f_4417(t13,t12);}
else{
t13=C_eqp(t4,lf[55]);
if(C_truep(t13)){
t14=t7;
f_4417(t14,t13);}
else{
t14=C_eqp(t4,lf[56]);
if(C_truep(t14)){
t15=t7;
f_4417(t15,t14);}
else{
t15=C_eqp(t4,lf[57]);
if(C_truep(t15)){
t16=t7;
f_4417(t16,t15);}
else{
t16=C_eqp(t4,lf[58]);
if(C_truep(t16)){
t17=t7;
f_4417(t17,t16);}
else{
t17=C_eqp(t4,lf[59]);
if(C_truep(t17)){
t18=t7;
f_4417(t18,t17);}
else{
t18=C_eqp(t4,lf[60]);
if(C_truep(t18)){
t19=t7;
f_4417(t19,t18);}
else{
t19=C_eqp(t4,lf[61]);
if(C_truep(t19)){
t20=t7;
f_4417(t20,t19);}
else{
t20=C_eqp(t4,lf[62]);
if(C_truep(t20)){
t21=t7;
f_4417(t21,t20);}
else{
t21=C_eqp(t4,lf[63]);
if(C_truep(t21)){
t22=t7;
f_4417(t22,t21);}
else{
t22=C_eqp(t4,lf[64]);
if(C_truep(t22)){
t23=t7;
f_4417(t23,t22);}
else{
t23=C_eqp(t4,lf[65]);
if(C_truep(t23)){
t24=t7;
f_4417(t24,t23);}
else{
t24=C_eqp(t4,lf[66]);
if(C_truep(t24)){
t25=t7;
f_4417(t25,t24);}
else{
t25=C_eqp(t4,lf[67]);
if(C_truep(t25)){
t26=t7;
f_4417(t26,t25);}
else{
t26=C_eqp(t4,lf[68]);
t27=t7;
f_4417(t27,(C_truep(t26)?t26:C_eqp(t4,lf[69])));}}}}}}}}}}}}}}}}}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4404 in loop in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in ... */
static void C_ccall f_4406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4406,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* batch-driver.scm:156: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4393(t4,((C_word*)t0)[4],t3);}

/* k4415 in loop in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in ... */
static void C_fcall f_4417(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_4417,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:139: ##sys#write-char-0 */
t6=*((C_word*)lf[33]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=C_make_character(9);
av2[3]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[28]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,lf[28]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* batch-driver.scm:156: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4393(t6,((C_word*)t0)[7],t5);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[34]);
if(C_truep(t3)){
t4=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[28]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* batch-driver.scm:156: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_4393(t7,((C_word*)t0)[7],t6);}
else{
t5=C_i_cdar(((C_word*)t0)[2]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=((C_word*)t0)[2];
t8=C_u_i_cdr(t7);
/* batch-driver.scm:156: loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_4393(t9,((C_word*)t0)[7],t8);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[35]);
if(C_truep(t4)){
t5=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[28]);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
/* batch-driver.scm:156: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_4393(t8,((C_word*)t0)[7],t7);}
else{
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_mutate(((C_word *)((C_word*)t0)[8])+1,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* batch-driver.scm:156: loop */
t10=((C_word*)((C_word*)t0)[6])[1];
f_4393(t10,((C_word*)t0)[7],t9);}}
else{
t5=C_eqp(((C_word*)t0)[4],lf[36]);
if(C_truep(t5)){
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_mutate(((C_word *)((C_word*)t0)[9])+1,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* batch-driver.scm:156: loop */
t10=((C_word*)((C_word*)t0)[6])[1];
f_4393(t10,((C_word*)t0)[7],t9);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[37]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t6)){
t8=t7;
f_4496(t8,t6);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[42]);
if(C_truep(t8)){
t9=t7;
f_4496(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[43]);
if(C_truep(t9)){
t10=t7;
f_4496(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[44]);
if(C_truep(t10)){
t11=t7;
f_4496(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[45]);
if(C_truep(t11)){
t12=t7;
f_4496(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[46]);
if(C_truep(t12)){
t13=t7;
f_4496(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[47]);
if(C_truep(t13)){
t14=t7;
f_4496(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[48]);
t15=t7;
f_4496(t15,(C_truep(t14)?t14:C_eqp(((C_word*)t0)[4],lf[49])));}}}}}}}}}}}}}

/* k4421 in k4415 in loop in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in ... */
static void C_ccall f_4423(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4423,2,av);}
t2=C_i_caar(((C_word*)t0)[2]);
t3=C_i_assq(t2,lf[32]);
t4=C_i_cdr(t3);
/* batch-driver.scm:139: ##sys#print */
t5=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k4494 in k4415 in loop in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in ... */
static void C_fcall f_4496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_4496,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:150: ##sys#write-char-0 */
t6=*((C_word*)lf[33]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=C_make_character(9);
av2[3]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[38]);
if(C_truep(t2)){
t3=C_i_cdar(((C_word*)t0)[2]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* batch-driver.scm:156: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_4393(t7,((C_word*)t0)[7],t6);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[39]);
if(C_truep(t3)){
t4=C_i_cdar(((C_word*)t0)[2]);
t5=C_mutate(((C_word *)((C_word*)t0)[8])+1,t4);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
/* batch-driver.scm:156: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_4393(t8,((C_word*)t0)[7],t7);}
else{
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
/* batch-driver.scm:155: chicken.compiler.support#bomb */
t6=*((C_word*)lf[40]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[41];
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}}}

/* k4500 in k4494 in k4415 in loop in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in ... */
static void C_ccall f_4502(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4502,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_caar(((C_word*)t0)[2]);
/* batch-driver.scm:150: ##sys#print */
t4=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4503 in k4500 in k4494 in k4415 in loop in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in ... */
static void C_ccall f_4505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4505,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:150: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(61);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4506 in k4503 in k4500 in k4494 in k4415 in loop in k4219 in a4210 in k4204 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in ... */
static void C_ccall f_4508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4508,2,av);}
t2=C_i_cdar(((C_word*)t0)[2]);
/* batch-driver.scm:150: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4780 in chicken.compiler.batch-driver#display-analysis-database in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4782,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_4206(t3,t2);}

/* chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4784(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +9,c,3)))){
C_save_and_reclaim((void*)f_4784,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+9);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4787,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4818,a[2]=t4,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:181: chicken.compiler.core#initialize-compiler */
t7=*((C_word*)lf[486]+1);{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* option-arg in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_4787(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_4787,2,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=C_u_i_car(t4);
/* batch-driver.scm:176: chicken.compiler.support#quit-compiling */
t6=*((C_word*)lf[75]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t1;
av2[2]=lf[76];
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t4=C_i_cadr(t2);
if(C_truep(C_i_symbolp(t4))){
/* batch-driver.scm:179: chicken.compiler.support#quit-compiling */
t5=*((C_word*)lf[75]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=lf[77];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}

/* k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_4818,2,av);}
a=C_alloc(7);
t2=((C_word*)t0)[2];
t3=C_mutate((C_word*)lf[78]+1 /* (set! chicken.compiler.core#explicit-use-flag ...) */,C_u_i_memq(lf[79],t2));
t4=((C_word*)t0)[2];
t5=C_mutate((C_word*)lf[80]+1 /* (set! chicken.compiler.core#emit-debug-info ...) */,C_u_i_memq(lf[81],t4));
t6=((C_word*)t0)[2];
t7=C_u_i_memq(lf[82],t6);
t8=C_i_not(t7);
t9=C_set_block_item(lf[83] /* chicken.compiler.core#enable-module-registration */,0,t8);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t11=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[484],t11))){
t12=C_set_block_item(lf[482] /* chicken.compiler.core#static-extensions */,0,C_SCHEME_TRUE);
/* batch-driver.scm:188: chicken.platform#register-feature! */
t13=*((C_word*)lf[131]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t13;
av2[1]=t10;
av2[2]=lf[485];
((C_proc)(void*)(*((C_word*)t13+1)))(3,av2);}}
else{
t12=t10;{
C_word *av2=av;
av2[0]=t12;
av2[1]=C_SCHEME_UNDEFINED;
f_4831(2,av2);}}}

/* k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4831(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,2)))){
C_save_and_reclaim((void *)f_4831,2,av);}
a=C_alloc(28);
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[84],t2);
t4=((C_word*)t0)[2];
t5=C_u_i_memq(lf[85],t4);
t6=C_a_i_cons(&a,2,lf[86],*((C_word*)lf[87]+1));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8048,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8067,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(C_truep(*((C_word*)lf[80]+1))?lf[479]:C_SCHEME_END_OF_LIST);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8075,a[2]=t9,a[3]=t11,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[78]+1))){
t13=t12;
f_8075(t13,C_SCHEME_END_OF_LIST);}
else{
t13=C_a_i_cons(&a,2,lf[381],*((C_word*)lf[483]+1));
t14=t12;
f_8075(t14,C_a_i_list(&a,1,t13));}}

/* k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_4845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,2)))){
C_save_and_reclaim((void *)f_4845,2,av);}
a=C_alloc(23);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=*((C_word*)lf[90]+1);
t8=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t5,a[13]=t7,a[14]=t6,tmp=(C_word)a,a+=15,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8005,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:222: chicken.process-context#get-environment-variable */
t10=*((C_word*)lf[472]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[473];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in ... */
static void C_ccall f_4851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
C_save_and_reclaim((void *)f_4851,2,av);}
a=C_alloc(20);
t2=C_i_check_list_2(t1,lf[5]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7969,a[2]=((C_word*)t0)[12],a[3]=t5,a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7969(t7,t3,t1);}

/* k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in ... */
static void C_ccall f_4857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_4857,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm:224: chicken.compiler.optimizer#default-optimization-passes */
t4=*((C_word*)lf[469]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in ... */
static void C_ccall f_4860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(31,c,2)))){
C_save_and_reclaim((void *)f_4860,2,av);}
a=C_alloc(31);
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=lf[91];
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t0)[2];
t15=C_u_i_memq(lf[92],t14);
t16=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_4865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t9,a[14]=t11,a[15]=t13,a[16]=t7,a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],tmp=(C_word)a,a+=19,tmp);
if(C_truep(t15)){
t17=t16;
f_4865(t17,t15);}
else{
t17=((C_word*)t0)[2];
t18=C_u_i_memq(lf[360],t17);
if(C_truep(t18)){
t19=t16;
f_4865(t19,t18);}
else{
t19=((C_word*)t0)[2];
t20=C_u_i_memq(lf[93],t19);
t21=t16;
f_4865(t21,t20);}}}

/* k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in ... */
static void C_fcall f_4865(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(38,0,2)))){
C_save_and_reclaim_args((void *)trf_4865,2,t0,t1);}
a=C_alloc(38);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_memq(lf[93],t3);
t5=(C_truep(t4)?C_i_cadr(t4):C_SCHEME_FALSE);
t6=t5;
t7=((C_word*)t0)[2];
t8=C_u_i_memq(lf[94],t7);
t9=((C_word*)t0)[2];
t10=C_u_i_memq(lf[95],t9);
t11=((C_word*)t0)[2];
t12=C_u_i_memq(lf[96],t11);
t13=((C_word*)t0)[2];
t14=C_u_i_memq(lf[97],t13);
t15=C_SCHEME_TRUE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=((C_word*)t0)[2];
t18=C_u_i_memq(lf[98],t17);
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_FALSE;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_FALSE;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=((C_word*)t0)[2];
t26=C_u_i_memq(lf[99],t25);
t27=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_4885,a[2]=((C_word*)t0)[2],a[3]=t20,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t24,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t22,a[13]=t12,a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=t14,a[18]=((C_word*)t0)[13],a[19]=t18,a[20]=((C_word*)t0)[14],a[21]=t16,a[22]=((C_word*)t0)[15],a[23]=t6,a[24]=((C_word*)t0)[16],a[25]=t2,a[26]=t8,a[27]=((C_word*)t0)[17],a[28]=t10,a[29]=((C_word*)t0)[18],tmp=(C_word)a,a+=30,tmp);
if(C_truep(t26)){
t28=t27;
f_4885(t28,t26);}
else{
t28=((C_word*)t0)[2];
t29=t27;
f_4885(t29,C_u_i_memq(lf[468],t28));}}

/* k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in ... */
static void C_fcall f_4885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(31,0,2)))){
C_save_and_reclaim_args((void *)trf_4885,2,t0,t1);}
a=C_alloc(31);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_memq(lf[100],t3);
t5=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_4890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=t2,a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],tmp=(C_word)a,a+=31,tmp);
if(C_truep(t4)){
/* batch-driver.scm:248: option-arg */
f_4787(t5,t4);}
else{
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
f_4890(2,av2);}}}

/* k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in ... */
static void C_ccall f_4890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(91,c,6)))){
C_save_and_reclaim((void *)f_4890,2,av);}
a=C_alloc(91);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4908,tmp=(C_word)a,a+=2,tmp));
t22=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t23=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4957,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t24=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4984,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5030,tmp=(C_word)a,a+=2,tmp));
t26=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t27=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5150,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp));
t28=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5160,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp));
t29=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5200,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp));
t30=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_5266,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=t18,a[12]=t16,a[13]=t20,a[14]=t6,a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=t8,a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=t14,a[25]=t10,a[26]=((C_word*)t0)[22],a[27]=((C_word*)t0)[23],a[28]=t2,a[29]=((C_word*)t0)[24],a[30]=((C_word*)t0)[25],a[31]=((C_word*)t0)[26],a[32]=t12,a[33]=((C_word*)t0)[3],a[34]=((C_word*)t0)[27],a[35]=((C_word*)t0)[28],a[36]=((C_word*)t0)[29],a[37]=((C_word*)t0)[5],tmp=(C_word)a,a+=38,tmp);
if(C_truep(((C_word*)t0)[30])){
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7948,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7952,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:317: option-arg */
f_4787(t32,((C_word*)t0)[30]);}
else{
t31=t30;
f_5266(t31,C_SCHEME_UNDEFINED);}}

/* print-header in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_fcall f_4908(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,4)))){
C_save_and_reclaim_args((void *)trf_4908,3,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4912,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:256: chicken.compiler.support#debugging */
t5=*((C_word*)lf[102]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[103];
av2[3]=lf[104];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k4910 in print-header in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_ccall f_4912(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4912,2,av);}
a=C_alloc(5);
if(C_truep(C_i_memq(((C_word*)t0)[2],*((C_word*)lf[101]+1)))){
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:259: ##sys#write-char-0 */
t6=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_make_character(91);
av2[3]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k4922 in k4910 in print-header in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in ... */
static void C_ccall f_4924(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_4924,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:259: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4925 in k4922 in k4910 in print-header in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_4927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_4927,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:259: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(93);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4928 in k4925 in k4922 in k4910 in print-header in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in ... */
static void C_ccall f_4930(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_4930,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4933,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:259: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4931 in k4928 in k4925 in k4922 in k4910 in print-header in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in ... */
static void C_ccall f_4933(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4933,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* print-node in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_fcall f_4935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_4935,5,t0,t1,t2,t3,t4);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:263: print-header */
f_4908(t5,t2,t3);}

/* k4940 in print-node in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_ccall f_4942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4942,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* batch-driver.scm:265: chicken.compiler.support#dump-nodes */
t2=*((C_word*)lf[105]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:266: chicken.compiler.support#build-expression-tree */
t3=*((C_word*)lf[107]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4953 in k4940 in print-node in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in ... */
static void C_ccall f_4955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4955,2,av);}
/* batch-driver.scm:266: chicken.pretty-print#pretty-print */
t2=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* print-db in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_fcall f_4957(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,3)))){
C_save_and_reclaim_args((void *)trf_4957,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(5);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4964,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:269: print-header */
f_4908(t6,t2,t3);}

/* k4962 in print-db in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_ccall f_4964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_4964,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=*((C_word*)lf[20]+1);
t3=*((C_word*)lf[20]+1);
t4=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:270: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[108];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4968 in k4962 in print-db in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in ... */
static void C_ccall f_4970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4970,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:270: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4971 in k4968 in k4962 in print-db in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_4973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4973,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:270: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(41);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4974 in k4971 in k4968 in k4962 in print-db in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in ... */
static void C_ccall f_4976(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_4976,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:270: ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4977 in k4974 in k4971 in k4968 in k4962 in print-db in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in ... */
static void C_ccall f_4979(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4979,2,av);}
/* batch-driver.scm:271: display-analysis-database */
t2=lf[18];
f_4202(t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* print-expr in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_fcall f_4984(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_4984,5,t0,t1,t2,t3,t4);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4991,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:274: print-header */
f_4908(t5,t2,t3);}

/* k4989 in print-expr in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_ccall f_4991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4991,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_check_list_2(t2,lf[10]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5007,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5007(t7,((C_word*)t0)[3],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4994 in for-each-loop1148 in k4989 in print-expr in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_4996(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4996,2,av);}
/* batch-driver.scm:278: scheme#newline */
t2=*((C_word*)lf[19]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop1148 in k4989 in print-expr in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in ... */
static void C_fcall f_5007(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_5007,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5017,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4996,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:277: chicken.pretty-print#pretty-print */
t7=*((C_word*)lf[106]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5015 in for-each-loop1148 in k4989 in print-expr in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_5017(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5017,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5007(t3,((C_word*)t0)[4],t2);}

/* arg-val in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_fcall f_5030(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,0,4)))){
C_save_and_reclaim_args((void *)trf_5030,2,t1,t2);}
a=C_alloc(16);
t3=C_i_string_length(t2);
t4=C_a_i_fixnum_difference(&a,2,t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5039,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm:285: scheme#string->number */
t6=*((C_word*)lf[110]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=C_i_string_ref(t2,t4);
t7=C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5070,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5074,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:287: scheme#substring */
t11=*((C_word*)lf[111]+1);{
C_word av2[5];
av2[0]=t11;
av2[1]=t10;
av2[2]=t2;
av2[3]=C_fix(0);
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}
else{
t9=C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5090,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5094,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:288: scheme#substring */
t13=*((C_word*)lf[111]+1);{
C_word av2[5];
av2[0]=t13;
av2[1]=t12;
av2[2]=t2;
av2[3]=C_fix(0);
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t13+1)))(5,av2);}}
else{
/* batch-driver.scm:289: scheme#string->number */
t11=*((C_word*)lf[110]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}}}}

/* k5037 in arg-val in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_ccall f_5039(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5039,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* batch-driver.scm:290: chicken.compiler.support#quit-compiling */
t2=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[109];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k5068 in arg-val in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_ccall f_5070(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,c,3)))){
C_save_and_reclaim((void *)f_5070,2,av);}
a=C_alloc(33);
t2=C_s_a_i_times(&a,2,t1,C_fix(1048576));
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* batch-driver.scm:290: chicken.compiler.support#quit-compiling */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[109];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k5072 in arg-val in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_ccall f_5074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5074,2,av);}
/* batch-driver.scm:287: scheme#string->number */
t2=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5088 in arg-val in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_ccall f_5090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,c,3)))){
C_save_and_reclaim((void *)f_5090,2,av);}
a=C_alloc(33);
t2=C_s_a_i_times(&a,2,t1,C_fix(1024));
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* batch-driver.scm:290: chicken.compiler.support#quit-compiling */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[109];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k5092 in arg-val in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_ccall f_5094(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5094,2,av);}
/* batch-driver.scm:288: scheme#string->number */
t2=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* collect-options in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_fcall f_5115(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,3)))){
C_save_and_reclaim_args((void *)trf_5115,3,t0,t1,t2);}
a=C_alloc(7);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5121,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5121(t6,t1,((C_word*)t0)[3]);}

/* loop in collect-options in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_fcall f_5121(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_5121,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_i_memq(((C_word*)t0)[2],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:294: g1192 */
t5=t4;
f_5129(t5,t1,t3);}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* g1192 in loop in collect-options in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in ... */
static void C_fcall f_5129(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_5129,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5137,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:294: option-arg */
f_4787(t3,t2);}

/* k5135 in g1192 in loop in collect-options in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_5137(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5137,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5141,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm:294: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5121(t5,t3,t4);}

/* k5139 in k5135 in g1192 in loop in collect-options in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in ... */
static void C_ccall f_5141(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_5141,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* begin-time in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_fcall f_5150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_5150,2,t0,t1);}
a=C_alloc(4);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5158,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:250: chicken.time#current-milliseconds */
t3=*((C_word*)lf[112]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5156 in begin-time in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_ccall f_5158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5158,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* end-time in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_fcall f_5160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_5160,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=*((C_word*)lf[20]+1);
t4=*((C_word*)lf[20]+1);
t5=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5170,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:302: ##sys#print */
t7=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[116];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5168 in end-time in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_ccall f_5170(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_5170,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:302: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5171 in k5168 in end-time in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in ... */
static void C_ccall f_5173(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_5173,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:302: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[115];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5174 in k5171 in k5168 in end-time in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_5176(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_5176,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5186,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5190,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:250: chicken.time#current-milliseconds */
t6=*((C_word*)lf[112]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k5177 in k5174 in k5171 in k5168 in end-time in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in ... */
static void C_ccall f_5179(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5179,2,av);}
/* batch-driver.scm:302: ##sys#write-char-0 */
t2=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5184 in k5174 in k5171 in k5168 in end-time in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in ... */
static void C_ccall f_5186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5186,2,av);}
/* batch-driver.scm:302: ##sys#print */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5188 in k5174 in k5171 in k5168 in end-time in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in ... */
static void C_ccall f_5190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5190,2,av);}
/* batch-driver.scm:304: scheme#inexact->exact */
t2=*((C_word*)lf[113]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5196 in k5174 in k5171 in k5168 in end-time in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in ... */
static void C_ccall f_5198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,2)))){
C_save_and_reclaim((void *)f_5198,2,av);}
a=C_alloc(29);
t2=C_s_a_i_minus(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm:304: scheme#round */
t3=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* analyze in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_fcall f_5200(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,4)))){
C_save_and_reclaim_args((void *)trf_5200,5,t0,t1,t2,t3,t4);}
a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5225,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5230,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t4))){
/* batch-driver.scm:307: def-no1213 */
t8=t7;
f_5230(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_u_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* batch-driver.scm:307: def-contf1214 */
t10=t6;
f_5225(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_u_i_cdr(t9);
/* batch-driver.scm:307: body1211 */
t12=t5;
f_5202(t12,t1,t8,t10);}}}

/* body1211 in analyze in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_fcall f_5202(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_5202,4,t0,t1,t2,t3);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5206,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:308: chicken.compiler.core#analyze-expression */
t5=*((C_word*)lf[119]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5204 in body1211 in analyze in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in ... */
static void C_ccall f_5206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,8)))){
C_save_and_reclaim((void *)f_5206,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5209,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5214,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5220,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:310: upap */
t6=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2;
if(c >= 9) {
  av2=av;
} else {
  av2=C_alloc(9);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
av2[4]=((C_word*)t0)[5];
av2[5]=t4;
av2[6]=t5;
av2[7]=((C_word*)t0)[6];
av2[8]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t6+1)))(9,av2);}}
else{
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5207 in k5204 in body1211 in analyze in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_5209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5209,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a5213 in k5204 in body1211 in analyze in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_5214(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_5214,4,av);}
t4=*((C_word*)lf[117]+1);
/* batch-driver.scm:311: g1233 */
t5=*((C_word*)lf[117]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* a5219 in k5204 in body1211 in analyze in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_5220(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_5220,5,av);}
t5=*((C_word*)lf[118]+1);
/* batch-driver.scm:312: g1247 */
t6=*((C_word*)lf[118]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
av2[4]=t3;
av2[5]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}

/* def-contf1214 in analyze in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_fcall f_5225(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_5225,3,t0,t1,t2);}
/* batch-driver.scm:307: body1211 */
t3=((C_word*)t0)[2];
f_5202(t3,t1,t2,C_SCHEME_TRUE);}

/* def-no1213 in analyze in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_fcall f_5230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_5230,2,t0,t1);}
/* batch-driver.scm:307: def-contf1214 */
t2=((C_word*)t0)[2];
f_5225(t2,t1,C_fix(0));}

/* k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_fcall f_5266(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(38,0,2)))){
C_save_and_reclaim_args((void *)trf_5266,2,t0,t1);}
a=C_alloc(38);
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=*((C_word*)lf[311]+1);
if(C_truep(*((C_word*)lf[311]+1))){
t4=*((C_word*)lf[311]+1);
if(C_truep(*((C_word*)lf[311]+1))){
t5=C_set_block_item(lf[322] /* chicken.compiler.core#standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_5269(t6,t5);}
else{
t5=t2;
f_5269(t5,C_SCHEME_UNDEFINED);}}
else{
if(C_truep(((C_word*)t0)[17])){
t4=C_set_block_item(lf[322] /* chicken.compiler.core#standalone-executable */,0,C_SCHEME_FALSE);
t5=t2;
f_5269(t5,t4);}
else{
t4=t2;
f_5269(t4,C_SCHEME_UNDEFINED);}}}

/* k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in ... */
static void C_fcall f_5269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(38,0,2)))){
C_save_and_reclaim_args((void *)trf_5269,2,t0,t1);}
a=C_alloc(38);
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_5272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[261],t3))){
t4=C_set_block_item(lf[466] /* ##sys#dload-disabled */,0,C_SCHEME_TRUE);
/* batch-driver.scm:322: chicken.platform#repository-path */
t5=*((C_word*)lf[467]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t2;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5272(2,av2);}}}

/* k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in ... */
static void C_ccall f_5272(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(44,c,3)))){
C_save_and_reclaim((void *)f_5272,2,av);}
a=C_alloc(44);
t2=((C_word*)t0)[2];
t3=C_mutate((C_word*)lf[120]+1 /* (set! chicken.compiler.core#enable-specialization ...) */,C_u_i_memq(lf[121],t2));
t4=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7877,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7934,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:329: collect-options */
t7=((C_word*)((C_word*)t0)[24])[1];
f_5115(t7,t6,lf[465]);}

/* k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_5279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(41,c,2)))){
C_save_and_reclaim((void *)f_5279,2,av);}
a=C_alloc(41);
t2=C_mutate((C_word*)lf[101]+1 /* (set! chicken.compiler.support#debugging-chicken ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
if(C_truep(C_i_memq(lf[356],*((C_word*)lf[101]+1)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7872,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:331: chicken.compiler.support#print-debug-options */
t5=*((C_word*)lf[463]+1);{
C_word *av2=av;
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5282(2,av2);}}}

/* k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in ... */
static void C_ccall f_5282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(44,c,2)))){
C_save_and_reclaim((void *)f_5282,2,av);}
a=C_alloc(44);
t2=C_i_memq(lf[122],*((C_word*)lf[101]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|38,a[1]=(C_word)f_5308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=t6,a[38]=t7,tmp=(C_word)a,a+=39,tmp);
/* batch-driver.scm:338: collect-options */
t9=((C_word*)((C_word*)t0)[24])[1];
f_5115(t9,t8,lf[462]);}

/* k5297 in map-loop1292 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in ... */
static void C_ccall f_5299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_5299,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5303,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#string-append */
t4=*((C_word*)lf[460]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[461];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5301 in k5297 in map-loop1292 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in ... */
static void C_ccall f_5303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_5303,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in ... */
static void C_ccall f_5308(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(44,c,3)))){
C_save_and_reclaim((void *)f_5308,2,av);}
a=C_alloc(44);
t2=C_i_check_list_2(t1,lf[5]);
t3=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_5314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7834,a[2]=((C_word*)t0)[37],a[3]=t5,a[4]=((C_word*)t0)[38],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7834(t7,t3,t1);}

/* k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in ... */
static void C_ccall f_5314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(37,c,2)))){
C_save_and_reclaim((void *)f_5314,2,av);}
a=C_alloc(37);
t2=C_mutate((C_word*)lf[123]+1 /* (set! chicken.compiler.core#import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_5317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t4=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[458],t4))){
if(C_truep(C_i_not(((C_word*)t0)[17]))){
t5=C_set_block_item(lf[459] /* chicken.compiler.core#all-import-libraries */,0,C_SCHEME_TRUE);
t6=t3;
f_5317(t6,t5);}
else{
t5=t3;
f_5317(t5,C_SCHEME_UNDEFINED);}}
else{
t5=t3;
f_5317(t5,C_SCHEME_UNDEFINED);}}

/* k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in ... */
static void C_fcall f_5317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(37,0,2)))){
C_save_and_reclaim_args((void *)trf_5317,2,t0,t1);}
a=C_alloc(37);
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_5320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep(*((C_word*)lf[120]+1))){
t3=C_set_block_item(((C_word*)t0)[22],0,C_SCHEME_TRUE);
t4=t2;
f_5320(t4,t3);}
else{
t3=t2;
f_5320(t3,C_SCHEME_UNDEFINED);}}

/* k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in ... */
static void C_fcall f_5320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(37,0,2)))){
C_save_and_reclaim_args((void *)trf_5320,2,t0,t1);}
a=C_alloc(37);
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_5323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep(C_i_memq(lf[182],*((C_word*)lf[101]+1)))){
/* batch-driver.scm:344: ##sys#start-timer */
t3=*((C_word*)lf[457]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5323(2,av2);}}}

/* k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in ... */
static void C_ccall f_5323(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,c,2)))){
C_save_and_reclaim((void *)f_5323,2,av);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(C_i_memq(lf[456],*((C_word*)lf[101]+1)))){
t3=C_set_block_item(((C_word*)t0)[36],0,C_SCHEME_TRUE);
t4=t2;
f_5326(t4,t3);}
else{
t3=t2;
f_5326(t3,C_SCHEME_UNDEFINED);}}

/* k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in ... */
static void C_fcall f_5326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5326,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[455],t3))){
t4=C_set_block_item(lf[78] /* chicken.compiler.core#explicit-use-flag */,0,C_SCHEME_TRUE);
t5=C_set_block_item(((C_word*)t0)[25],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t7=t2;
f_5329(t7,t6);}
else{
t4=t2;
f_5329(t4,C_SCHEME_UNDEFINED);}}

/* k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in ... */
static void C_fcall f_5329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5329,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[453],t3))){
t4=C_set_block_item(lf[454] /* chicken.compiler.core#emit-closure-info */,0,C_SCHEME_FALSE);
t5=t2;
f_5332(t5,t4);}
else{
t4=t2;
f_5332(t4,C_SCHEME_UNDEFINED);}}

/* k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in ... */
static void C_fcall f_5332(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5332,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[451],t3))){
t4=C_set_block_item(lf[452] /* chicken.compiler.core#compiler-syntax-enabled */,0,C_SCHEME_FALSE);
t5=t2;
f_5335(t5,t4);}
else{
t4=t2;
f_5335(t4,C_SCHEME_UNDEFINED);}}

/* k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in ... */
static void C_fcall f_5335(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5335,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[450],t3))){
t4=C_set_block_item(lf[430] /* chicken.compiler.core#local-definitions */,0,C_SCHEME_TRUE);
t5=t2;
f_5338(t5,t4);}
else{
t4=t2;
f_5338(t4,C_SCHEME_UNDEFINED);}}

/* k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in ... */
static void C_fcall f_5338(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5338,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[449],t3))){
t4=C_set_block_item(lf[267] /* chicken.compiler.core#enable-inline-files */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[164] /* chicken.compiler.core#inline-locally */,0,C_SCHEME_TRUE);
t6=t2;
f_5341(t6,t5);}
else{
t4=t2;
f_5341(t4,C_SCHEME_UNDEFINED);}}

/* k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in ... */
static void C_fcall f_5341(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5341,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=C_set_block_item(lf[448] /* ##sys#notices-enabled */,0,C_SCHEME_TRUE);
t4=t2;
f_5344(t4,t3);}
else{
t3=t2;
f_5344(t3,C_SCHEME_UNDEFINED);}}

/* k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in ... */
static void C_fcall f_5344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5344,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[447],t3))){
t4=C_set_block_item(lf[249] /* chicken.compiler.core#strict-variable-types */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[120] /* chicken.compiler.core#enable-specialization */,0,C_SCHEME_TRUE);
t6=t2;
f_5347(t6,t5);}
else{
t4=t2;
f_5347(t4,C_SCHEME_UNDEFINED);}}

/* k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in ... */
static void C_fcall f_5347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(43,0,4)))){
C_save_and_reclaim_args((void *)trf_5347,2,t0,t1);}
a=C_alloc(43);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[445],t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7787,a[2]=((C_word*)t0)[22],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9287,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[446];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t2;
f_5350(t4,C_SCHEME_UNDEFINED);}}

/* k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in ... */
static void C_fcall f_5350(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5350,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[444],t3))){
t4=C_set_block_item(lf[169] /* chicken.compiler.core#optimize-leaf-routines */,0,C_SCHEME_TRUE);
t5=t2;
f_5353(t5,t4);}
else{
t4=t2;
f_5353(t4,C_SCHEME_UNDEFINED);}}

/* k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in ... */
static void C_fcall f_5353(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5353,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[443],t3))){
t4=C_set_block_item(lf[242] /* chicken.compiler.support#unsafe */,0,C_SCHEME_TRUE);
t5=t2;
f_5356(t5,t4);}
else{
t4=t2;
f_5356(t4,C_SCHEME_UNDEFINED);}}

/* k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in ... */
static void C_fcall f_5356(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5356,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[441],t3))){
t4=C_set_block_item(lf[442] /* ##sys#setup-mode */,0,C_SCHEME_TRUE);
t5=t2;
f_5359(t5,t4);}
else{
t4=t2;
f_5359(t4,C_SCHEME_UNDEFINED);}}

/* k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in ... */
static void C_fcall f_5359(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5359,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[439],t3))){
t4=C_set_block_item(lf[440] /* chicken.compiler.core#preserve-unchanged-import-libraries */,0,C_SCHEME_FALSE);
t5=t2;
f_5362(t5,t4);}
else{
t4=t2;
f_5362(t4,C_SCHEME_UNDEFINED);}}

/* k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in ... */
static void C_fcall f_5362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5362,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[438],t3))){
t4=C_set_block_item(lf[205] /* chicken.compiler.core#insert-timer-checks */,0,C_SCHEME_FALSE);
t5=t2;
f_5365(t5,t4);}
else{
t4=t2;
f_5365(t4,C_SCHEME_UNDEFINED);}}

/* k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in ... */
static void C_fcall f_5365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5365,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[435],t3))){
t4=C_mutate((C_word*)lf[436]+1 /* (set! chicken.compiler.support#number-type ...) */,lf[437]);
t5=t2;
f_5368(t5,t4);}
else{
t4=t2;
f_5368(t4,C_SCHEME_UNDEFINED);}}

/* k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in ... */
static void C_fcall f_5368(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5368,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[434],t3))){
t4=C_set_block_item(lf[163] /* chicken.compiler.core#block-compilation */,0,C_SCHEME_TRUE);
t5=t2;
f_5371(t5,t4);}
else{
t4=t2;
f_5371(t4,C_SCHEME_UNDEFINED);}}

/* k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in ... */
static void C_fcall f_5371(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5371,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[432],t3))){
t4=C_set_block_item(lf[433] /* chicken.compiler.core#external-protos-first */,0,C_SCHEME_TRUE);
t5=t2;
f_5374(t5,t4);}
else{
t4=t2;
f_5374(t4,C_SCHEME_UNDEFINED);}}

/* k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in ... */
static void C_fcall f_5374(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,0,2)))){
C_save_and_reclaim_args((void *)trf_5374,2,t0,t1);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[431],t3))){
t4=C_set_block_item(lf[164] /* chicken.compiler.core#inline-locally */,0,C_SCHEME_TRUE);
t5=t2;
f_5377(t5,t4);}
else{
t4=t2;
f_5377(t4,C_SCHEME_UNDEFINED);}}

/* k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in ... */
static void C_fcall f_5377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(39,0,2)))){
C_save_and_reclaim_args((void *)trf_5377,2,t0,t1);}
a=C_alloc(39);
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[124],t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t3)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7755,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:382: option-arg */
f_4787(t5,t3);}
else{
t5=t4;
f_5382(t5,C_SCHEME_FALSE);}}

/* k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in ... */
static void C_fcall f_5382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(40,0,2)))){
C_save_and_reclaim_args((void *)trf_5382,2,t0,t1);}
a=C_alloc(40);
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[125],t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t3)){
t5=C_set_block_item(lf[164] /* chicken.compiler.core#inline-locally */,0,C_SCHEME_TRUE);
t6=C_set_block_item(lf[430] /* chicken.compiler.core#local-definitions */,0,C_SCHEME_TRUE);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7751,a[2]=((C_word*)t0)[19],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:386: option-arg */
f_4787(t7,t3);}
else{
t5=t4;
f_5387(t5,C_SCHEME_FALSE);}}

/* k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in ... */
static void C_fcall f_5387(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(40,0,2)))){
C_save_and_reclaim_args((void *)trf_5387,2,t0,t1);}
a=C_alloc(40);
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[126],t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t3)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7745,a[2]=((C_word*)t0)[21],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:388: option-arg */
f_4787(t5,t3);}
else{
t5=t4;
f_5392(t5,C_SCHEME_FALSE);}}

/* k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in ... */
static void C_fcall f_5392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(39,0,2)))){
C_save_and_reclaim_args((void *)trf_5392,2,t0,t1);}
a=C_alloc(39);
t2=((C_word*)t0)[2];
t3=C_u_i_memq(lf[127],t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t3)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7732,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:391: option-arg */
f_4787(t5,t3);}
else{
t5=t4;
f_5397(t5,C_SCHEME_FALSE);}}

/* k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in ... */
static void C_fcall f_5397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(42,0,4)))){
C_save_and_reclaim_args((void *)trf_5397,2,t0,t1);}
a=C_alloc(42);
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_5400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=((C_word*)t0)[5];
if(C_truep(C_u_i_memq(lf[427],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7722,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9281,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[428];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t2;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5400(2,av2);}}}

/* k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in ... */
static void C_ccall f_5400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(38,c,2)))){
C_save_and_reclaim((void *)f_5400,2,av);}
a=C_alloc(38);
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_5403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[35])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7689,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:400: option-arg */
f_4787(t3,((C_word*)t0)[35]);}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5403(2,av2);}}}

/* k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in ... */
static void C_ccall f_5403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(41,c,4)))){
C_save_and_reclaim((void *)f_5403,2,av);}
a=C_alloc(41);
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_5406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=((C_word*)t0)[5];
if(C_truep(C_u_i_memq(lf[419],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7683,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9275,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[420];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t2;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5406(2,av2);}}}

/* k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in ... */
static void C_ccall f_5406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(41,c,4)))){
C_save_and_reclaim((void *)f_5406,2,av);}
a=C_alloc(41);
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_5409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=((C_word*)t0)[5];
if(C_truep(C_u_i_memq(lf[417],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7675,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9269,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[418];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t2;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5409(2,av2);}}}

/* k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in ... */
static void C_ccall f_5409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(41,c,4)))){
C_save_and_reclaim((void *)f_5409,2,av);}
a=C_alloc(41);
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_5412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=((C_word*)t0)[5];
if(C_truep(C_u_i_memq(lf[410],t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7658,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9263,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[416];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t2;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5412(2,av2);}}}

/* k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in ... */
static void C_ccall f_5412(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(45,c,2)))){
C_save_and_reclaim((void *)f_5412,2,av);}
a=C_alloc(45);
t2=C_mutate((C_word*)lf[128]+1 /* (set! chicken.compiler.core#verbose-mode ...) */,((C_word*)t0)[2]);
t3=C_set_block_item(lf[129] /* ##sys#read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5418,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=*((C_word*)lf[90]+1);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7613,a[2]=t4,a[3]=((C_word*)t0)[34],a[4]=t7,a[5]=t9,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:421: collect-options */
t11=((C_word*)((C_word*)t0)[23])[1];
f_5115(t11,t10,lf[409]);}

/* k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in ... */
static void C_ccall f_5418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,c,2)))){
C_save_and_reclaim((void *)f_5418,2,av);}
a=C_alloc(33);
t2=C_mutate((C_word*)lf[130]+1 /* (set! ##sys#include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[13])){
if(C_truep(((C_word*)t0)[6])){
if(C_truep(C_i_string_equal_p(((C_word*)t0)[13],((C_word*)t0)[6]))){
/* batch-driver.scm:425: chicken.compiler.support#quit-compiling */
t4=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[408];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5421(2,av2);}}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5421(2,av2);}}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5421(2,av2);}}}

/* k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in ... */
static void C_ccall f_5421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,c,2)))){
C_save_and_reclaim((void *)f_5421,2,av);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[406],t3))){
t4=C_set_block_item(lf[407] /* chicken.compiler.core#undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t2;
f_5424(t5,t4);}
else{
t4=t2;
f_5424(t4,C_SCHEME_UNDEFINED);}}

/* k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in ... */
static void C_fcall f_5424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,0,2)))){
C_save_and_reclaim_args((void *)trf_5424,2,t0,t1);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[404],t3))){
t4=C_set_block_item(lf[405] /* chicken.compiler.core#no-argc-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_5427(t5,t4);}
else{
t4=t2;
f_5427(t4,C_SCHEME_UNDEFINED);}}

/* k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in ... */
static void C_fcall f_5427(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,0,2)))){
C_save_and_reclaim_args((void *)trf_5427,2,t0,t1);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[402],t3))){
t4=C_set_block_item(lf[403] /* chicken.compiler.core#no-bound-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_5430(t5,t4);}
else{
t4=t2;
f_5430(t4,C_SCHEME_UNDEFINED);}}

/* k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in ... */
static void C_fcall f_5430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,0,2)))){
C_save_and_reclaim_args((void *)trf_5430,2,t0,t1);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[400],t3))){
t4=C_set_block_item(lf[401] /* chicken.compiler.core#no-procedure-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_5433(t5,t4);}
else{
t4=t2;
f_5433(t4,C_SCHEME_UNDEFINED);}}

/* k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in ... */
static void C_fcall f_5433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,0,2)))){
C_save_and_reclaim_args((void *)trf_5433,2,t0,t1);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[398],t3))){
t4=C_set_block_item(lf[399] /* chicken.compiler.core#no-global-procedure-checks */,0,C_SCHEME_TRUE);
t5=t2;
f_5436(t5,t4);}
else{
t4=t2;
f_5436(t4,C_SCHEME_UNDEFINED);}}

/* k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in ... */
static void C_fcall f_5436(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(41,0,3)))){
C_save_and_reclaim_args((void *)trf_5436,2,t0,t1);}
a=C_alloc(41);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=((C_word*)t0)[4];
if(C_truep(C_u_i_memq(lf[395],t3))){
t4=*((C_word*)lf[72]+1);
t5=C_i_check_list_2(*((C_word*)lf[72]+1),lf[10]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7519,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7558,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=((C_word*)t8)[1];
f_7558(t10,t6,*((C_word*)lf[72]+1));}
else{
t4=t2;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5439(2,av2);}}}

/* k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in ... */
static void C_ccall f_5439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,c,2)))){
C_save_and_reclaim((void *)f_5439,2,av);}
a=C_alloc(33);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[103],*((C_word*)lf[101]+1)))){
/* batch-driver.scm:447: chicken.load#load-verbose */
t3=*((C_word*)lf[394]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5442(2,av2);}}}

/* k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in ... */
static void C_ccall f_5442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(40,c,3)))){
C_save_and_reclaim((void *)f_5442,2,av);}
a=C_alloc(40);
t2=*((C_word*)lf[131]+1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_5445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=t2,tmp=(C_word)a,a+=34,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7489,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7497,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:452: collect-options */
t6=((C_word*)((C_word*)t0)[22])[1];
f_5115(t6,t5,lf[393]);}

/* k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in ... */
static void C_ccall f_5445(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(39,c,3)))){
C_save_and_reclaim((void *)f_5445,2,av);}
a=C_alloc(39);
t2=C_i_check_list_2(t1,lf[10]);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7466,a[2]=t5,a[3]=((C_word*)t0)[33],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7466(t7,t3,t1);}

/* k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in ... */
static void C_ccall f_5451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(40,c,3)))){
C_save_and_reclaim((void *)f_5451,2,av);}
a=C_alloc(40);
t2=*((C_word*)lf[132]+1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_5454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=t2,tmp=(C_word)a,a+=34,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7456,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7464,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:455: collect-options */
t6=((C_word*)((C_word*)t0)[22])[1];
f_5115(t6,t5,lf[391]);}

/* k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in ... */
static void C_ccall f_5454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(39,c,3)))){
C_save_and_reclaim((void *)f_5454,2,av);}
a=C_alloc(39);
t2=C_i_check_list_2(t1,lf[10]);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7433,a[2]=t5,a[3]=((C_word*)t0)[33],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7433(t7,t3,t1);}

/* k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in ... */
static void C_ccall f_5460(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,c,2)))){
C_save_and_reclaim((void *)f_5460,2,av);}
a=C_alloc(36);
t2=C_a_i_cons(&a,2,lf[133],*((C_word*)lf[134]+1));
t3=C_mutate((C_word*)lf[134]+1 /* (set! ##sys#features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm:459: collect-options */
t5=((C_word*)((C_word*)t0)[22])[1];
f_5115(t5,t4,lf[389]);}

/* k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in ... */
static void C_ccall f_5467(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(37,c,4)))){
C_save_and_reclaim((void *)f_5467,2,av);}
a=C_alloc(37);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_5470,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9247,a[2]=t4,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[388];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}

/* k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in ... */
static void C_ccall f_5470(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(38,c,3)))){
C_save_and_reclaim((void *)f_5470,2,av);}
a=C_alloc(38);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[10]);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7410,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7410(t7,t3,((C_word*)t0)[2]);}

/* k5473 in for-each-loop1451 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in ... */
static void C_ccall f_5475(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_5475,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5478,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_not(t2))){
/* batch-driver.scm:464: chicken.compiler.support#quit-compiling */
t4=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[387];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
/* batch-driver.scm:465: scheme#load */
t4=*((C_word*)lf[386]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k5476 in k5473 in for-each-loop1451 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in ... */
static void C_ccall f_5478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5478,2,av);}
/* batch-driver.scm:465: scheme#load */
t2=*((C_word*)lf[386]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in ... */
static void C_ccall f_5493(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(38,c,3)))){
C_save_and_reclaim((void *)f_5493,2,av);}
a=C_alloc(38);
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=*((C_word*)lf[134]+1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3211,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3211(t7,t2,*((C_word*)lf[134]+1));}

/* k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in ... */
static void C_ccall f_5497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,c,2)))){
C_save_and_reclaim((void *)f_5497,2,av);}
a=C_alloc(36);
t2=C_mutate((C_word*)lf[134]+1 /* (set! ##sys#features ...) */,t1);
t3=C_a_i_cons(&a,2,lf[135],*((C_word*)lf[134]+1));
t4=C_mutate((C_word*)lf[134]+1 /* (set! ##sys#features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_5505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm:469: chicken.compiler.user-pass#user-post-analysis-pass */
t6=*((C_word*)lf[385]+1);{
C_word *av2=av;
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in ... */
static void C_ccall f_5505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(38,c,3)))){
C_save_and_reclaim((void *)f_5505,2,av);}
a=C_alloc(38);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_5508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7360,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7408,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:474: collect-options */
t6=((C_word*)((C_word*)t0)[22])[1];
f_5115(t6,t5,lf[381]);}

/* k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in ... */
static void C_ccall f_5508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(44,c,2)))){
C_save_and_reclaim((void *)f_5508,2,av);}
a=C_alloc(44);
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_5511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
if(C_truep(C_i_nullp(t1))){
t3=t2;
f_5511(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_a_i_cons(&a,2,lf[381],t1);
t4=C_a_i_list(&a,2,lf[382],t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[26])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[26])+1,t5);
t7=t2;
f_5511(t7,t6);}}

/* k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in ... */
static void C_fcall f_5511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(43,0,2)))){
C_save_and_reclaim_args((void *)trf_5511,2,t0,t1);}
a=C_alloc(43);
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7303,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:484: collect-options */
t8=((C_word*)((C_word*)t0)[21])[1];
f_5115(t8,t7,lf[380]);}

/* k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in ... */
static void C_ccall f_5515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(32,c,2)))){
C_save_and_reclaim((void *)f_5515,2,av);}
a=C_alloc(32);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_5518,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[2],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
t4=((C_word*)t0)[3];
if(C_truep(C_u_i_memq(lf[377],t4))){
t5=C_set_block_item(lf[378] /* ##sys#enable-runtime-macros */,0,C_SCHEME_TRUE);
t6=t3;
f_5518(t6,t5);}
else{
t5=t3;
f_5518(t5,C_SCHEME_UNDEFINED);}}

/* k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in ... */
static void C_fcall f_5518(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(35,0,2)))){
C_save_and_reclaim_args((void *)trf_5518,2,t0,t1);}
a=C_alloc(35);
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_5522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep(((C_word*)t0)[31])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7284,a[2]=((C_word*)t0)[29],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:490: option-arg */
f_4787(t3,((C_word*)t0)[31]);}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_5522(2,av2);}}}

/* k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in ... */
static void C_ccall f_5522(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(32,c,2)))){
C_save_and_reclaim((void *)f_5522,2,av);}
a=C_alloc(32);
t2=C_mutate((C_word*)lf[136]+1 /* (set! chicken.compiler.core#target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_5526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[28])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7277,a[2]=((C_word*)t0)[29],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:493: option-arg */
f_4787(t4,((C_word*)t0)[28]);}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_5526(2,av2);}}}

/* k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in ... */
static void C_ccall f_5526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,2)))){
C_save_and_reclaim((void *)f_5526,2,av);}
a=C_alloc(28);
t2=C_mutate((C_word*)lf[137]+1 /* (set! chicken.compiler.core#target-stack-size ...) */,t1);
t3=((C_word*)t0)[2];
t4=C_u_i_memq(lf[138],t3);
t5=C_i_not(t4);
t6=C_set_block_item(lf[139] /* chicken.compiler.core#emit-trace-info */,0,t5);
t7=((C_word*)t0)[2];
t8=C_mutate((C_word*)lf[140]+1 /* (set! chicken.compiler.core#disable-stack-overflow-checking ...) */,C_u_i_memq(lf[141],t7));
t9=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_5537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
/* batch-driver.scm:496: chicken.platform#feature? */
t10=*((C_word*)lf[375]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[376];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in ... */
static void C_ccall f_5537(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,2)))){
C_save_and_reclaim((void *)f_5537,2,av);}
a=C_alloc(28);
t2=C_set_block_item(lf[142] /* chicken.compiler.core#bootstrap-mode */,0,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_5540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
if(C_truep(C_i_memq(lf[373],*((C_word*)lf[101]+1)))){
/* batch-driver.scm:497: chicken.gc#set-gc-report! */
t4=*((C_word*)lf[374]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5540(2,av2);}}}

/* k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in ... */
static void C_ccall f_5540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,2)))){
C_save_and_reclaim((void *)f_5540,2,av);}
a=C_alloc(28);
t2=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[372],t3))){
t4=C_set_block_item(((C_word*)t0)[19],0,C_SCHEME_FALSE);
t5=t2;
f_5543(t5,t4);}
else{
t4=C_mutate((C_word*)lf[9]+1 /* (set! chicken.compiler.core#standard-bindings ...) */,*((C_word*)lf[72]+1));
t5=C_mutate((C_word*)lf[11]+1 /* (set! chicken.compiler.core#extended-bindings ...) */,*((C_word*)lf[73]+1));
t6=t2;
f_5543(t6,t5);}}

/* k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in ... */
static void C_fcall f_5543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(34,0,4)))){
C_save_and_reclaim_args((void *)trf_5543,2,t0,t1);}
a=C_alloc(34);
t2=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_5546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],tmp=(C_word)a,a+=28,tmp);
if(C_truep(*((C_word*)lf[139]+1))){
t3=t2;
t4=C_a_i_list(&a,1,lf[369]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9227,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[370];
av2[4]=t4;
C_apply(5,av2);}}
else{
t3=t2;
t4=C_a_i_list(&a,1,lf[371]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9233,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[370];
av2[4]=t4;
C_apply(5,av2);}}}

/* k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in ... */
static void C_ccall f_5546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(32,c,2)))){
C_save_and_reclaim((void *)f_5546,2,av);}
a=C_alloc(32);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[27])){
t3=C_i_car(((C_word*)t0)[27]);
t4=C_eqp(lf[360],t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7222,a[2]=((C_word*)t0)[25],a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
if(C_truep(C_i_not(((C_word*)t0)[23]))){
/* batch-driver.scm:510: chicken.compiler.support#quit-compiling */
t7=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[368];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t7=t6;{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
f_7222(2,av2);}}}
else{
t7=t6;{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
f_7222(2,av2);}}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5549(2,av2);}}}

/* k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in ... */
static void C_ccall f_5549(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,2)))){
C_save_and_reclaim((void *)f_5549,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:524: chicken.compiler.support#load-identifier-database */
t3=*((C_word*)lf[358]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[359];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in ... */
static void C_ccall f_5552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,2)))){
C_save_and_reclaim((void *)f_5552,2,av);}
a=C_alloc(27);
t2=((C_word*)t0)[2];
if(C_truep(C_u_i_memq(lf[143],t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5560,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:527: chicken.compiler.support#print-version */
t4=*((C_word*)lf[144]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];
t4=C_u_i_memq(lf[145],t3);
t5=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(t4)){
t6=t5;
f_5571(t6,t4);}
else{
t6=((C_word*)t0)[2];
t7=C_u_i_memq(lf[355],t6);
if(C_truep(t7)){
t8=t5;
f_5571(t8,t7);}
else{
t8=((C_word*)t0)[2];
t9=C_u_i_memq(lf[356],t8);
if(C_truep(t9)){
t10=t5;
f_5571(t10,t9);}
else{
t10=((C_word*)t0)[2];
t11=t5;
f_5571(t11,C_u_i_memq(lf[357],t10));}}}}}

/* k5558 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in ... */
static void C_ccall f_5560(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5560,2,av);}
/* batch-driver.scm:528: scheme#newline */
t2=*((C_word*)lf[19]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in ... */
static void C_fcall f_5571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,0,4)))){
C_save_and_reclaim_args((void *)trf_5571,2,t0,t1);}
a=C_alloc(33);
if(C_truep(t1)){
/* batch-driver.scm:530: chicken.compiler.support#print-usage */
t2=*((C_word*)lf[146]+1);{
C_word av2[2];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
if(C_truep(C_u_i_memq(lf[147],t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5582,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5589,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:532: chicken.platform#chicken-version */
t5=*((C_word*)lf[149]+1);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
if(C_truep(C_i_not(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:535: chicken.compiler.support#print-version */
t4=*((C_word*)lf[144]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5610,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[2],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[3],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
t4=t3;
t5=C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9209,a[2]=t4,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[354];
av2[4]=t5;
C_apply(5,av2);}}}}}

/* k5580 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in ... */
static void C_ccall f_5582(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5582,2,av);}
/* batch-driver.scm:533: scheme#newline */
t2=*((C_word*)lf[19]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5587 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in ... */
static void C_ccall f_5589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5589,2,av);}
/* batch-driver.scm:532: scheme#display */
t2=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5596 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in ... */
static void C_ccall f_5598(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5598,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5601,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:536: scheme#display */
t3=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[152];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5599 in k5596 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in ... */
static void C_ccall f_5601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5601,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5604,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:537: scheme#display */
t3=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[151];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5602 in k5599 in k5596 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in ... */
static void C_ccall f_5604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5604,2,av);}
/* batch-driver.scm:538: scheme#display */
t2=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[150];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in ... */
static void C_ccall f_5610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,4)))){
C_save_and_reclaim((void *)f_5610,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:543: chicken.compiler.support#debugging */
t3=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[349];
av2[3]=lf[353];
av2[4]=((C_word*)t0)[20];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in ... */
static void C_ccall f_5613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,4)))){
C_save_and_reclaim((void *)f_5613,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:544: chicken.compiler.support#debugging */
t3=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[349];
av2[3]=lf[352];
av2[4]=*((C_word*)lf[101]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in ... */
static void C_ccall f_5616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,4)))){
C_save_and_reclaim((void *)f_5616,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:545: chicken.compiler.support#debugging */
t3=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[349];
av2[3]=lf[351];
av2[4]=*((C_word*)lf[136]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in ... */
static void C_ccall f_5619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,4)))){
C_save_and_reclaim((void *)f_5619,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:546: chicken.compiler.support#debugging */
t3=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[349];
av2[3]=lf[350];
av2[4]=*((C_word*)lf[137]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in ... */
static void C_ccall f_5622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,2)))){
C_save_and_reclaim((void *)f_5622,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:250: chicken.time#current-milliseconds */
t3=*((C_word*)lf[112]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in ... */
static void C_ccall f_5626(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,3)))){
C_save_and_reclaim((void *)f_5626,2,av);}
a=C_alloc(27);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[2],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:550: scheme#make-vector */
t4=*((C_word*)lf[347]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[348]+1);
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in ... */
static void C_ccall f_5630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,2)))){
C_save_and_reclaim((void *)f_5630,2,av);}
a=C_alloc(27);
t2=C_mutate((C_word*)lf[153]+1 /* (set! ##sys#line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:551: collect-options */
t4=((C_word*)((C_word*)t0)[19])[1];
f_5115(t4,t3,lf[346]);}

/* k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in ... */
static void C_ccall f_5633(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,2)))){
C_save_and_reclaim((void *)f_5633,2,av);}
a=C_alloc(28);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=t2,tmp=(C_word)a,a+=28,tmp);
/* batch-driver.scm:552: collect-options */
t4=((C_word*)((C_word*)t0)[19])[1];
f_5115(t4,t3,lf[345]);}

/* k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in ... */
static void C_ccall f_5636(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(34,c,2)))){
C_save_and_reclaim((void *)f_5636,2,av);}
a=C_alloc(34);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=t2,tmp=(C_word)a,a+=29,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7196,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[19],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:554: collect-options */
t5=((C_word*)((C_word*)t0)[19])[1];
f_5115(t5,t4,lf[344]);}

/* k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in ... */
static void C_ccall f_5639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(30,c,2)))){
C_save_and_reclaim((void *)f_5639,2,av);}
a=C_alloc(30);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_5642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=t2,a[29]=((C_word*)t0)[28],tmp=(C_word)a,a+=30,tmp);
/* batch-driver.scm:558: chicken.compiler.user-pass#user-read-pass */
t4=*((C_word*)lf[342]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in ... */
static void C_ccall f_5642(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(38,c,4)))){
C_save_and_reclaim((void *)f_5642,2,av);}
a=C_alloc(38);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7028,a[2]=((C_word*)t0)[26],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[27],a[6]=((C_word*)t0)[28],a[7]=((C_word*)t0)[29],tmp=(C_word)a,a+=8,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9195,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[336];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7037,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[27],a[4]=((C_word*)t0)[29],a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7037(t7,t3,((C_word*)t0)[28]);}}

/* k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in ... */
static void C_ccall f_5645(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,2)))){
C_save_and_reclaim((void *)f_5645,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:581: chicken.compiler.user-pass#user-preprocessor-pass */
t3=*((C_word*)lf[335]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in ... */
static void C_ccall f_5648(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(35,c,4)))){
C_save_and_reclaim((void *)f_5648,2,av);}
a=C_alloc(35);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6981,a[2]=t2,a[3]=((C_word*)t0)[26],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9189,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[334];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t3;
f_5651(t4,C_SCHEME_UNDEFINED);}}

/* k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in ... */
static void C_fcall f_5651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,0,4)))){
C_save_and_reclaim_args((void *)trf_5651,2,t0,t1);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:586: print-expr */
t3=((C_word*)((C_word*)t0)[21])[1];
f_4984(t3,t2,lf[332],lf[333],((C_word*)((C_word*)t0)[26])[1]);}

/* k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in ... */
static void C_ccall f_5654(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,2)))){
C_save_and_reclaim((void *)f_5654,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm:587: begin-time */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5150(t3,t2);}

/* k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in ... */
static void C_ccall f_5657(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(36,c,3)))){
C_save_and_reclaim((void *)f_5657,2,av);}
a=C_alloc(36);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_5684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=t4,a[25]=t6,a[26]=t5,a[27]=((C_word*)t0)[24],tmp=(C_word)a,a+=28,tmp);
/* batch-driver.scm:592: scheme#append */
t8=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)((C_word*)t0)[25])[1];
av2[3]=((C_word*)((C_word*)t0)[26])[1];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* g1676 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in ... */
static void C_fcall f_5661(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,4)))){
C_save_and_reclaim_args((void *)trf_5661,3,t0,t1,t2);}
a=C_alloc(15);
t3=((C_word*)t0)[2];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5667,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5672,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5678,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:590: ##sys#dynamic-wind */
t10=*((C_word*)lf[156]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t1;
av2[2]=t7;
av2[3]=t8;
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}

/* a5666 in g1676 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in ... */
static void C_ccall f_5667(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5667,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[154]+1));
t3=C_mutate((C_word*)lf[154]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a5671 in g1676 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in ... */
static void C_ccall f_5672(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5672,2,av);}
/* batch-driver.scm:591: chicken.compiler.core#canonicalize-expression */
t2=*((C_word*)lf[155]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a5677 in g1676 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in ... */
static void C_ccall f_5678(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_5678,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[154]+1));
t3=C_mutate((C_word*)lf[154]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in ... */
static void C_ccall f_5684(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(31,c,2)))){
C_save_and_reclaim((void *)f_5684,2,av);}
a=C_alloc(31);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
if(C_truep(C_i_not(((C_word*)t0)[27]))){
t4=t3;
f_5687(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6974,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:596: scheme#string->symbol */
t5=*((C_word*)lf[331]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[27];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in ... */
static void C_fcall f_5687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(32,0,3)))){
C_save_and_reclaim_args((void *)trf_5687,2,t0,t1);}
a=C_alloc(32);
t2=C_i_check_list_2(t1,lf[5]);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6924,a[2]=((C_word*)t0)[24],a[3]=t5,a[4]=((C_word*)t0)[25],a[5]=((C_word*)t0)[26],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6924(t7,t3,t1);}

/* k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in ... */
static void C_ccall f_5693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(40,c,3)))){
C_save_and_reclaim((void *)f_5693,2,av);}
a=C_alloc(40);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=*((C_word*)lf[321]+1);
t9=C_i_check_list_2(*((C_word*)lf[321]+1),lf[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6807,a[2]=((C_word*)t0)[22],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[23],tmp=(C_word)a,a+=6,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6890,a[2]=t6,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_6890(t14,t10,*((C_word*)lf[321]+1));}

/* k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in ... */
static void C_ccall f_5696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(43,c,3)))){
C_save_and_reclaim((void *)f_5696,2,av);}
a=C_alloc(43);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t3,a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_i_nullp(*((C_word*)lf[123]+1)))){
t5=t4;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_5699(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6729,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=*((C_word*)lf[123]+1);
t11=C_i_check_list_2(*((C_word*)lf[123]+1),lf[5]);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6748,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6750,a[2]=t8,a[3]=t14,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t16=((C_word*)t14)[1];
f_6750(t16,t12,*((C_word*)lf[123]+1));}}

/* k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in ... */
static void C_ccall f_5699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,3)))){
C_save_and_reclaim((void *)f_5699,2,av);}
a=C_alloc(23);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:619: chicken.internal#hash-table-ref */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[274]+1);
av2[3]=lf[84];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in ... */
static void C_ccall f_5702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(33,c,3)))){
C_save_and_reclaim((void *)f_5702,2,av);}
a=C_alloc(33);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6553,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6715,tmp=(C_word)a,a+=2,tmp);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3424,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* mini-srfi-1.scm:141: filter */
f_3325(t4,t7,t2);}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_5705(2,av2);}}}

/* k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in ... */
static void C_ccall f_5705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,3)))){
C_save_and_reclaim((void *)f_5705,2,av);}
a=C_alloc(25);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_i_pairp(*((C_word*)lf[293]+1)))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6491,tmp=(C_word)a,a+=2,tmp);
/* batch-driver.scm:632: chicken.compiler.support#with-debugging-output */
t4=*((C_word*)lf[298]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[299];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5708(2,av2);}}}

/* k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in ... */
static void C_ccall f_5708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(26,c,3)))){
C_save_and_reclaim((void *)f_5708,2,av);}
a=C_alloc(26);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6480,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:639: chicken.compiler.support#debugging */
t4=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[291];
av2[3]=lf[292];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in ... */
static void C_ccall f_5711(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(26,c,3)))){
C_save_and_reclaim((void *)f_5711,2,av);}
a=C_alloc(26);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6474,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:641: chicken.compiler.support#debugging */
t4=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[288];
av2[3]=lf[289];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in ... */
static void C_ccall f_5714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,2)))){
C_save_and_reclaim((void *)f_5714,2,av);}
a=C_alloc(23);
t2=C_mutate((C_word*)lf[153]+1 /* (set! ##sys#line-number-database ...) */,*((C_word*)lf[157]+1));
t3=C_set_block_item(lf[157] /* chicken.compiler.core#line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:647: end-time */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5160(t5,t4,lf[286]);}

/* k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in ... */
static void C_ccall f_5719(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,4)))){
C_save_and_reclaim((void *)f_5719,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm:648: print-expr */
t3=((C_word*)((C_word*)t0)[22])[1];
f_4984(t3,t2,lf[284],lf[285],((C_word*)((C_word*)t0)[21])[1]);}

/* k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in ... */
static void C_ccall f_5722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,2)))){
C_save_and_reclaim((void *)f_5722,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
t3=((C_word*)t0)[20];
if(C_truep(C_u_i_memq(lf[283],t3))){
/* batch-driver.scm:650: chicken.base#exit */
t4=*((C_word*)lf[196]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=t2;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5725(2,av2);}}}

/* k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in ... */
static void C_ccall f_5725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,2)))){
C_save_and_reclaim((void *)f_5725,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm:653: chicken.compiler.user-pass#user-pass */
t3=*((C_word*)lf[282]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in ... */
static void C_ccall f_5728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(32,c,4)))){
C_save_and_reclaim((void *)f_5728,2,av);}
a=C_alloc(32);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6416,a[2]=t2,a[3]=((C_word*)t0)[21],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9165,a[2]=t5,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[281];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5731(2,av2);}}}

/* k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in ... */
static void C_ccall f_5731(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(27,c,2)))){
C_save_and_reclaim((void *)f_5731,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6409,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6413,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:663: chicken.compiler.support#canonicalize-begin-body */
t5=*((C_word*)lf[279]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)((C_word*)t0)[21])[1];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in ... */
static void C_ccall f_5734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(25,c,4)))){
C_save_and_reclaim((void *)f_5734,2,av);}
a=C_alloc(25);
t2=t1;
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t2,a[19]=((C_word*)t0)[18],a[20]=t4,a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:665: print-node */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4935(t6,t5,lf[275],lf[276],t2);}

/* k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in ... */
static void C_ccall f_5737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,2)))){
C_save_and_reclaim((void *)f_5737,2,av);}
a=C_alloc(23);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:666: initialize-analysis-database */
t3=lf[8];
f_4093(t3,t2);}

/* k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in ... */
static void C_ccall f_5740(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(26,c,2)))){
C_save_and_reclaim((void *)f_5740,2,av);}
a=C_alloc(26);
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6405,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:669: scheme#vector->list */
t4=*((C_word*)lf[273]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[274]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in ... */
static void C_ccall f_5743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(39,c,3)))){
C_save_and_reclaim((void *)f_5743,2,av);}
a=C_alloc(39);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=t2,tmp=(C_word)a,a+=24,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_i_check_list_2(t2,lf[5]);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6367,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6369,a[2]=t6,a[3]=t11,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6369(t13,t9,t2);}

/* k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in ... */
static void C_ccall f_5746(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,3)))){
C_save_and_reclaim((void *)f_5746,2,av);}
a=C_alloc(28);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=t2,a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6354,a[2]=t3,a[3]=((C_word*)t0)[23],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:671: chicken.compiler.support#debugging */
t5=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[271];
av2[3]=lf[272];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in ... */
static void C_ccall f_5749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,3)))){
C_save_and_reclaim((void *)f_5749,2,av);}
a=C_alloc(29);
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(*((C_word*)lf[267]+1))){
t3=C_i_check_list_2(((C_word*)t0)[20],lf[10]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6330,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6330(t7,t2,((C_word*)t0)[20]);}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5752(2,av2);}}}

/* k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in ... */
static void C_ccall f_5752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,2)))){
C_save_and_reclaim((void *)f_5752,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm:681: collect-options */
t3=((C_word*)((C_word*)t0)[22])[1];
f_5115(t3,t2,lf[266]);}

/* k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in ... */
static void C_ccall f_5755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,3)))){
C_save_and_reclaim((void *)f_5755,2,av);}
a=C_alloc(29);
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(C_i_nullp(t1))){
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5758(2,av2);}}
else{
t3=C_set_block_item(lf[164] /* chicken.compiler.core#inline-locally */,0,C_SCHEME_TRUE);
t4=C_i_check_list_2(t1,lf[10]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6283,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6283(t8,t2,t1);}}

/* k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in ... */
static void C_ccall f_5758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(35,c,3)))){
C_save_and_reclaim((void *)f_5758,2,av);}
a=C_alloc(35);
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=((C_word*)((C_word*)t0)[19])[1];
t4=(C_truep(t3)?t3:*((C_word*)lf[120]+1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6134,a[2]=((C_word*)t0)[20],a[3]=((C_word*)t0)[21],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[18],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[19],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[22],tmp=(C_word)a,a+=13,tmp);
t6=((C_word*)t0)[23];
if(C_truep(C_u_i_memq(lf[261],t6))){
t7=t5;{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
f_6134(2,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6260,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:693: chicken.compiler.scrutinizer#load-type-database */
t8=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[263];
av2[3]=*((C_word*)lf[120]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}}
else{
t5=t2;
f_5761(t5,C_SCHEME_UNDEFINED);}}

/* k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in ... */
static void C_fcall f_5761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,0,2)))){
C_save_and_reclaim_args((void *)trf_5761,2,t0,t1);}
a=C_alloc(22);
t2=C_set_block_item(lf[153] /* ##sys#line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[158] /* chicken.compiler.core#constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[159] /* chicken.compiler.core#inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
if(C_truep(*((C_word*)lf[242]+1))){
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_5767(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6128,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:729: chicken.compiler.support#node-subexpressions */
t7=*((C_word*)lf[244]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[18];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}

/* k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in ... */
static void C_ccall f_5767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,2)))){
C_save_and_reclaim((void *)f_5767,2,av);}
a=C_alloc(19);
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm:731: begin-time */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5150(t3,t2);}

/* k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in ... */
static void C_ccall f_5770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,2)))){
C_save_and_reclaim((void *)f_5770,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm:733: chicken.compiler.core#perform-cps-conversion */
t3=*((C_word*)lf[241]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[18];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in ... */
static void C_ccall f_5773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,2)))){
C_save_and_reclaim((void *)f_5773,2,av);}
a=C_alloc(19);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm:734: end-time */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5160(t4,t3,lf[240]);}

/* k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in ... */
static void C_ccall f_5776(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,4)))){
C_save_and_reclaim((void *)f_5776,2,av);}
a=C_alloc(19);
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm:735: print-node */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4935(t3,t2,lf[238],lf[239],((C_word*)t0)[18]);}

/* k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in ... */
static void C_ccall f_5779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,7)))){
C_save_and_reclaim((void *)f_5779,2,av);}
a=C_alloc(20);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5784,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp));
t5=((C_word*)t3)[1];
f_5784(t5,((C_word*)t0)[17],C_fix(1),((C_word*)t0)[18],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in ... */
static void C_fcall f_5784(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(26,0,2)))){
C_save_and_reclaim_args((void *)trf_5784,7,t0,t1,t2,t3,t4,t5,t6);}
a=C_alloc(26);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5788,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=t1,a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],a[21]=((C_word*)t0)[15],a[22]=((C_word*)t0)[16],a[23]=((C_word*)t0)[17],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm:743: begin-time */
t9=((C_word*)((C_word*)t0)[5])[1];
f_5150(t9,t8);}

/* k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in ... */
static void C_ccall f_5788(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(30,c,4)))){
C_save_and_reclaim((void *)f_5788,2,av);}
a=C_alloc(30);
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm:745: analyze */
t3=((C_word*)((C_word*)t0)[11])[1];
f_5200(t3,t2,lf[237],((C_word*)((C_word*)t0)[4])[1],C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]));}

/* k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in ... */
static void C_ccall f_5791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(30,c,2)))){
C_save_and_reclaim((void *)f_5791,2,av);}
a=C_alloc(30);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(*((C_word*)lf[160]+1))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6084,a[2]=((C_word*)t0)[23],a[3]=t3,a[4]=((C_word*)t0)[15],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_memq(lf[235],*((C_word*)lf[101]+1)))){
/* batch-driver.scm:748: chicken.compiler.support#dump-undefined-globals */
t5=*((C_word*)lf[236]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=t4;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_6084(2,av2);}}}
else{
t4=t3;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5794(2,av2);}}}

/* k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in ... */
static void C_ccall f_5794(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,2)))){
C_save_and_reclaim((void *)f_5794,2,av);}
a=C_alloc(24);
t2=C_set_block_item(lf[160] /* chicken.compiler.core#first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm:758: end-time */
t4=((C_word*)((C_word*)t0)[10])[1];
f_5160(t4,t3,lf[228]);}

/* k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in ... */
static void C_ccall f_5798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,5)))){
C_save_and_reclaim((void *)f_5798,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm:759: print-db */
t3=((C_word*)((C_word*)t0)[21])[1];
f_4957(t3,t2,lf[226],lf[227],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in ... */
static void C_ccall f_5801(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,9)))){
C_save_and_reclaim((void *)f_5801,2,av);}
a=C_alloc(29);
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(C_i_memq(lf[216],*((C_word*)lf[101]+1)))){
t3=((C_word*)t0)[5];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4000,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4006,tmp=(C_word)a,a+=2,tmp);
/* batch-driver.scm:69: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t2;
av2[2]=t4;
av2[3]=t5;
C_call_with_values(4,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5804(2,av2);}}}

/* k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in ... */
static void C_ccall f_5804(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,4)))){
C_save_and_reclaim((void *)f_5804,2,av);}
a=C_alloc(24);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:766: chicken.compiler.support#debugging */
t3=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[103];
av2[3]=lf[177];
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5911,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[18],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[20],a[14]=((C_word*)t0)[21],a[15]=((C_word*)t0)[6],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[23])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6047,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:805: begin-time */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5150(t4,t3);}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5911(2,av2);}}}}

/* k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in ... */
static void C_ccall f_5810(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,2)))){
C_save_and_reclaim((void *)f_5810,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:767: begin-time */
t3=((C_word*)((C_word*)t0)[10])[1];
f_5150(t3,t2);}

/* k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in ... */
static void C_ccall f_5813(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,4)))){
C_save_and_reclaim((void *)f_5813,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5830,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:768: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[13];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a5817 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in ... */
static void C_ccall f_5818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_5818,2,av);}
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm:770: chicken.compiler.optimizer#determine-loop-and-dispatch */
t2=*((C_word*)lf[161]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
/* batch-driver.scm:771: chicken.compiler.optimizer#perform-high-level-optimizations */
t2=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)t0)[4];
av2[4]=*((C_word*)lf[163]+1);
av2[5]=*((C_word*)lf[164]+1);
av2[6]=*((C_word*)lf[165]+1);
av2[7]=*((C_word*)lf[166]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}}

/* a5829 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in ... */
static void C_ccall f_5830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,2)))){
C_save_and_reclaim((void *)f_5830,4,av);}
a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5834,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:775: end-time */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5160(t5,t4,lf[176]);}

/* k5832 in a5829 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in ... */
static void C_ccall f_5834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,4)))){
C_save_and_reclaim((void *)f_5834,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm:776: print-node */
t3=((C_word*)((C_word*)t0)[13])[1];
f_4935(t3,t2,lf[174],lf[175],((C_word*)t0)[6]);}

/* k5835 in k5832 in a5829 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in ... */
static void C_ccall f_5837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,6)))){
C_save_and_reclaim((void *)f_5837,2,av);}
a=C_alloc(29);
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
t3=C_s_a_i_plus(&a,2,t2,C_fix(1));
/* batch-driver.scm:778: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5784(t4,((C_word*)t0)[5],t3,((C_word*)t0)[6],C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[7]);}
else{
t2=C_i_not(((C_word*)t0)[8]);
t3=(C_truep(t2)?((C_word*)t0)[9]:C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:780: chicken.compiler.support#debugging */
t5=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[103];
av2[3]=lf[167];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
if(C_truep(C_i_not(*((C_word*)lf[166]+1)))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:783: chicken.compiler.support#debugging */
t5=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[103];
av2[3]=lf[168];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
if(C_truep(*((C_word*)lf[169]+1))){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:787: begin-time */
t5=((C_word*)((C_word*)t0)[11])[1];
f_5150(t5,t4);}
else{
t4=((C_word*)t0)[3];
t5=C_s_a_i_plus(&a,2,t4,C_fix(1));
/* batch-driver.scm:800: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5784(t6,((C_word*)t0)[5],t5,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[8]);}}}}}

/* k5852 in k5835 in k5832 in a5829 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in ... */
static void C_ccall f_5854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,6)))){
C_save_and_reclaim((void *)f_5854,2,av);}
a=C_alloc(29);
t2=((C_word*)t0)[2];
t3=C_s_a_i_plus(&a,2,t2,C_fix(1));
/* batch-driver.scm:781: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5784(t4,((C_word*)t0)[4],t3,((C_word*)t0)[5],C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5866 in k5835 in k5832 in a5829 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in ... */
static void C_ccall f_5868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,6)))){
C_save_and_reclaim((void *)f_5868,2,av);}
a=C_alloc(29);
t2=C_set_block_item(lf[166] /* chicken.compiler.core#inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
t4=C_s_a_i_plus(&a,2,t3,C_fix(1));
/* batch-driver.scm:785: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5784(t5,((C_word*)t0)[4],t4,((C_word*)t0)[5],C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[6]);}

/* k5878 in k5835 in k5832 in a5829 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in ... */
static void C_ccall f_5880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,4)))){
C_save_and_reclaim((void *)f_5880,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:788: analyze */
t3=((C_word*)((C_word*)t0)[9])[1];
f_5200(t3,t2,lf[173],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k5881 in k5878 in k5835 in k5832 in a5829 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in ... */
static void C_ccall f_5883(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_5883,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:789: end-time */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5160(t4,t3,lf[172]);}

/* k5884 in k5881 in k5878 in k5835 in k5832 in a5829 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in ... */
static void C_ccall f_5886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_5886,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:790: begin-time */
t3=((C_word*)((C_word*)t0)[9])[1];
f_5150(t3,t2);}

/* k5887 in k5884 in k5881 in k5878 in k5835 in k5832 in a5829 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in ... */
static void C_ccall f_5889(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_5889,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:792: chicken.compiler.optimizer#transform-direct-lambdas! */
t3=*((C_word*)lf[171]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5890 in k5887 in k5884 in k5881 in k5878 in k5835 in k5832 in a5829 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in ... */
static void C_ccall f_5892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_5892,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:793: end-time */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5160(t4,t3,lf[170]);}

/* k5893 in k5890 in k5887 in k5884 in k5881 in k5878 in k5835 in k5832 in a5829 in k5811 in k5808 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in ... */
static void C_ccall f_5895(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,6)))){
C_save_and_reclaim((void *)f_5895,2,av);}
a=C_alloc(29);
t2=((C_word*)t0)[2];
t3=C_s_a_i_plus(&a,2,t2,C_fix(1));
/* batch-driver.scm:794: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5784(t4,((C_word*)t0)[4],t3,((C_word*)t0)[5],((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[7]);}

/* k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in ... */
static void C_ccall f_5911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,4)))){
C_save_and_reclaim((void *)f_5911,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm:814: print-node */
t3=((C_word*)((C_word*)t0)[12])[1];
f_4935(t3,t2,lf[208],lf[209],((C_word*)((C_word*)t0)[2])[1]);}

/* k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in ... */
static void C_ccall f_5914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(28,c,4)))){
C_save_and_reclaim((void *)f_5914,2,av);}
a=C_alloc(28);
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[16])[1])?*((C_word*)lf[205]+1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[16])[1];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6041,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=t5;
t7=C_a_i_list(&a,1,t4);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9127,a[2]=t6,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t8;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[207];
av2[4]=t7;
C_apply(5,av2);}}
else{
t4=t2;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5917(2,av2);}}}

/* k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in ... */
static void C_ccall f_5917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_5917,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm:823: begin-time */
t3=((C_word*)((C_word*)t0)[9])[1];
f_5150(t3,t2);}

/* k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in ... */
static void C_ccall f_5920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,3)))){
C_save_and_reclaim((void *)f_5920,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm:825: chicken.compiler.core#perform-closure-conversion */
t3=*((C_word*)lf[204]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in ... */
static void C_ccall f_5924(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_5924,2,av);}
a=C_alloc(16);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm:826: end-time */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5160(t4,t3,lf[203]);}

/* k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in ... */
static void C_ccall f_5927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,5)))){
C_save_and_reclaim((void *)f_5927,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:827: print-db */
t3=((C_word*)((C_word*)t0)[14])[1];
f_4957(t3,t2,lf[201],lf[202],((C_word*)t0)[3],((C_word*)t0)[15]);}

/* k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in ... */
static void C_ccall f_5930(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,2)))){
C_save_and_reclaim((void *)f_5930,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(*((C_word*)lf[199]+1))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6035,a[2]=((C_word*)t0)[13],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:250: chicken.time#current-milliseconds */
t4=*((C_word*)lf[112]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5933(2,av2);}}}

/* k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in ... */
static void C_ccall f_5933(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_5933,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm:831: print-node */
t3=((C_word*)((C_word*)t0)[12])[1];
f_4935(t3,t2,lf[197],lf[198],((C_word*)((C_word*)t0)[2])[1]);}

/* k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in ... */
static void C_ccall f_5936(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_5936,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[11])){
/* batch-driver.scm:832: chicken.base#exit */
t3=*((C_word*)lf[196]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5939(2,av2);}}}

/* k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in ... */
static void C_ccall f_5939(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_5939,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:833: begin-time */
t3=((C_word*)((C_word*)t0)[9])[1];
f_5150(t3,t2);}

/* k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in ... */
static void C_ccall f_5942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,7)))){
C_save_and_reclaim((void *)f_5942,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5953,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:835: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[10];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a5946 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in ... */
static void C_ccall f_5947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_5947,2,av);}
/* batch-driver.scm:836: chicken.compiler.core#prepare-for-code-generation */
t2=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in ... */
static void C_ccall f_5953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,2)))){
C_save_and_reclaim((void *)f_5953,7,av);}
a=C_alloc(14);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5957,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t4,a[7]=t5,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t6,a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:837: end-time */
t8=((C_word*)((C_word*)t0)[2])[1];
f_5160(t8,t7,lf[195]);}

/* k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in ... */
static void C_ccall f_5957(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_5957,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm:838: begin-time */
t3=((C_word*)((C_word*)t0)[13])[1];
f_5150(t3,t2);}

/* k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in ... */
static void C_ccall f_5960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,4)))){
C_save_and_reclaim((void *)f_5960,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(*((C_word*)lf[190]+1))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6006,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t3;
t5=C_a_i_list(&a,1,*((C_word*)lf[190]+1));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9121,a[2]=t4,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[194];
av2[4]=t5;
C_apply(5,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5963(2,av2);}}}

/* k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in ... */
static void C_ccall f_5963(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_5963,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[4])){
/* batch-driver.scm:848: scheme#open-output-file */
t3=*((C_word*)lf[189]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=*((C_word*)lf[20]+1);
f_5966(2,av2);}}}

/* k5964 in k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in ... */
static void C_ccall f_5966(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,4)))){
C_save_and_reclaim((void *)f_5966,2,av);}
a=C_alloc(20);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t4=t3;
t5=C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9115,a[2]=t4,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[188];
av2[4]=t5;
C_apply(5,av2);}}

/* k5967 in k5964 in k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in ... */
static void C_ccall f_5969(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,10)))){
C_save_and_reclaim((void *)f_5969,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:850: chicken.compiler.c-backend#generate-code */
t3=*((C_word*)lf[187]+1);{
C_word *av2;
if(c >= 11) {
  av2=av;
} else {
  av2=C_alloc(11);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[7];
av2[4]=((C_word*)t0)[8];
av2[5]=((C_word*)t0)[5];
av2[6]=((C_word*)t0)[9];
av2[7]=((C_word*)t0)[10];
av2[8]=((C_word*)t0)[11];
av2[9]=((C_word*)t0)[12];
av2[10]=((C_word*)t0)[13];
((C_proc)(void*)(*((C_word*)t3+1)))(11,av2);}}

/* k5970 in k5967 in k5964 in k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in ... */
static void C_ccall f_5972(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_5972,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* batch-driver.scm:853: scheme#close-output-port */
t3=*((C_word*)lf[186]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5975(2,av2);}}}

/* k5973 in k5970 in k5967 in k5964 in k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in ... */
static void C_ccall f_5975(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5975,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:854: end-time */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5160(t3,t2,lf[185]);}

/* k5976 in k5973 in k5970 in k5967 in k5964 in k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in ... */
static void C_ccall f_5978(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_5978,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5981,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_memq(lf[182],*((C_word*)lf[101]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5997,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:856: ##sys#stop-timer */
t4=*((C_word*)lf[184]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8625,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:857: chicken.compiler.support#compiler-cleanup-hook */
t4=*((C_word*)lf[181]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5979 in k5976 in k5973 in k5970 in k5967 in k5964 in k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in ... */
static void C_ccall f_5981(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_5981,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:857: chicken.compiler.support#compiler-cleanup-hook */
t3=*((C_word*)lf[181]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5982 in k5979 in k5976 in k5973 in k5970 in k5967 in k5964 in k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in ... */
static void C_ccall f_5984(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_5984,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9103,a[2]=t2,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t3;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[180];
av2[4]=C_SCHEME_END_OF_LIST;
C_apply(5,av2);}}

/* k5995 in k5976 in k5973 in k5970 in k5967 in k5964 in k5961 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in ... */
static void C_ccall f_5997(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_5997,2,av);}
/* batch-driver.scm:856: ##sys#display-times */
t2=*((C_word*)lf[183]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6004 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in ... */
static void C_ccall f_6006(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(2,c,3)))){
C_save_and_reclaim((void *)f_6006,2,av);}
a=C_alloc(2);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6011,tmp=(C_word)a,a+=2,tmp);
/* batch-driver.scm:843: scheme#with-output-to-file */
t3=*((C_word*)lf[193]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[190]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a6010 in k6004 in k5958 in k5955 in a5952 in k5940 in k5937 in k5934 in k5931 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in ... */
static void C_ccall f_6011(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6011,2,av);}
t2=*((C_word*)lf[191]+1);
/* batch-driver.scm:845: g2136 */
t3=*((C_word*)lf[191]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=*((C_word*)lf[192]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6033 in k5928 in k5925 in k5922 in k5918 in k5915 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in ... */
static void C_ccall f_6035(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,2)))){
C_save_and_reclaim((void *)f_6035,2,av);}
a=C_alloc(29);
t2=C_s_a_i_minus(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(C_i_greaterp(t2,C_fix(60000)))){
/* batch-driver.scm:830: scheme#display */
t3=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[200];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5933(2,av2);}}}

/* k6039 in k5912 in k5909 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in ... */
static void C_ccall f_6041(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,6)))){
C_save_and_reclaim((void *)f_6041,2,av);}
/* batch-driver.scm:820: chicken.compiler.support#emit-global-inline-file */
t2=*((C_word*)lf[206]+1);{
C_word *av2;
if(c >= 7) {
  av2=av;
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=*((C_word*)lf[163]+1);
av2[6]=*((C_word*)lf[165]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k6045 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in ... */
static void C_ccall f_6047(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_6047,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:806: chicken.compiler.support#debugging */
t3=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[103];
av2[3]=lf[215];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6048 in k6045 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in ... */
static void C_ccall f_6050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6050,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:807: chicken.compiler.lfa2#perform-secondary-flow-analysis */
t3=*((C_word*)lf[214]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6051 in k6048 in k6045 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in ... */
static void C_ccall f_6053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_6053,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6056,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:808: end-time */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5160(t4,t3,lf[213]);}

/* k6054 in k6051 in k6048 in k6045 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in ... */
static void C_ccall f_6056(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6056,2,av);}
a=C_alloc(6);
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
/* batch-driver.scm:813: end-time */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5160(t2,((C_word*)t0)[4],lf[210]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6068,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:810: begin-time */
t3=((C_word*)((C_word*)t0)[6])[1];
f_5150(t3,t2);}}

/* k6066 in k6054 in k6051 in k6048 in k6045 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in ... */
static void C_ccall f_6068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_6068,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:811: chicken.compiler.support#debugging */
t3=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[103];
av2[3]=lf[212];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6069 in k6066 in k6054 in k6051 in k6048 in k6045 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in ... */
static void C_ccall f_6071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6071,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:812: chicken.compiler.lfa2#perform-unboxing */
t3=*((C_word*)lf[211]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6073 in k6069 in k6066 in k6054 in k6051 in k6048 in k6045 in k5802 in k5799 in k5796 in k5792 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in ... */
static void C_ccall f_6075(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6075,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* batch-driver.scm:813: end-time */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5160(t3,((C_word*)t0)[4],lf[210]);}

/* k6082 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in ... */
static void C_ccall f_6084(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6084,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_memq(lf[233],*((C_word*)lf[101]+1)))){
/* batch-driver.scm:750: chicken.compiler.support#dump-defined-globals */
t3=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6087(2,av2);}}}

/* k6085 in k6082 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in ... */
static void C_ccall f_6087(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6087,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_memq(lf[231],*((C_word*)lf[101]+1)))){
/* batch-driver.scm:752: chicken.compiler.support#dump-global-refs */
t3=*((C_word*)lf[232]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6090(2,av2);}}}

/* k6088 in k6085 in k6082 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in ... */
static void C_ccall f_6090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_6090,2,av);}
a=C_alloc(12);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=t2;
t4=C_a_i_list(&a,1,((C_word*)((C_word*)t0)[2])[1]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9133,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[230];
av2[4]=t4;
C_apply(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
f_5794(2,av2);}}}

/* k6094 in k6088 in k6085 in k6082 in k5789 in k5786 in loop in k5777 in k5774 in k5771 in k5768 in k5765 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in ... */
static void C_ccall f_6096(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6096,2,av);}
/* batch-driver.scm:756: chicken.compiler.scrutinizer#emit-types-file */
t2=*((C_word*)lf[229]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)((C_word*)t0)[4])[1];
av2[4]=((C_word*)t0)[5];
av2[5]=*((C_word*)lf[163]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k6126 in k5759 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in ... */
static void C_ccall f_6128(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6128,2,av);}
t2=C_i_car(t1);
/* batch-driver.scm:729: chicken.compiler.optimizer#scan-toplevel-assignments */
t3=*((C_word*)lf[243]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in ... */
static void C_ccall f_6134(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,2)))){
C_save_and_reclaim((void *)f_6134,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm:701: collect-options */
t3=((C_word*)((C_word*)t0)[12])[1];
f_5115(t3,t2,lf[260]);}

/* k6137 in for-each-loop2029 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in ... */
static void C_ccall f_6139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6139,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* batch-driver.scm:700: chicken.compiler.support#quit-compiling */
t2=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[259];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in ... */
static void C_ccall f_6148(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,3)))){
C_save_and_reclaim((void *)f_6148,2,av);}
a=C_alloc(17);
t2=C_i_check_list_2(t1,lf[10]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6231,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6231(t7,t3,t1);}

/* k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in ... */
static void C_ccall f_6154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,3)))){
C_save_and_reclaim((void *)f_6154,2,av);}
a=C_alloc(16);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6173,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6208,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6208(t7,t3,((C_word*)t0)[2]);}

/* k6161 in for-each-loop2050 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in ... */
static void C_ccall f_6163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6163,2,av);}
/* batch-driver.scm:704: chicken.compiler.scrutinizer#load-type-database */
t2=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=*((C_word*)lf[120]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6165 in for-each-loop2050 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in ... */
static void C_ccall f_6167(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6167,2,av);}
/* batch-driver.scm:705: chicken.pathname#make-pathname */
t2=*((C_word*)lf[256]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=t1;
av2[4]=lf[257];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6171 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in ... */
static void C_ccall f_6173(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,2)))){
C_save_and_reclaim((void *)f_6173,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:708: begin-time */
t3=((C_word*)((C_word*)t0)[8])[1];
f_5150(t3,t2);}

/* k6174 in k6171 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in ... */
static void C_ccall f_6176(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_6176,2,av);}
a=C_alloc(10);
t2=C_set_block_item(lf[160] /* chicken.compiler.core#first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:710: analyze */
t4=((C_word*)((C_word*)t0)[10])[1];
f_5200(t4,t3,lf[254],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k6179 in k6174 in k6171 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in ... */
static void C_ccall f_6181(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,5)))){
C_save_and_reclaim((void *)f_6181,2,av);}
a=C_alloc(9);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6184,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:711: print-db */
t4=((C_word*)((C_word*)t0)[9])[1];
f_4957(t4,t3,lf[252],lf[253],((C_word*)((C_word*)t0)[2])[1],C_fix(0));}

/* k6182 in k6179 in k6174 in k6171 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in ... */
static void C_ccall f_6184(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_6184,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:712: end-time */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5160(t3,t2,lf[251]);}

/* k6185 in k6182 in k6179 in k6174 in k6171 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in ... */
static void C_ccall f_6187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_6187,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:713: begin-time */
t3=((C_word*)((C_word*)t0)[8])[1];
f_5150(t3,t2);}

/* k6188 in k6185 in k6182 in k6179 in k6174 in k6171 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in ... */
static void C_ccall f_6190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_6190,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:714: chicken.compiler.support#debugging */
t3=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[103];
av2[3]=lf[250];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6191 in k6188 in k6185 in k6182 in k6179 in k6174 in k6171 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in ... */
static void C_ccall f_6193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,7)))){
C_save_and_reclaim((void *)f_6193,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:715: chicken.compiler.scrutinizer#scrutinize */
t3=*((C_word*)lf[248]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)((C_word*)t0)[6])[1];
av2[4]=((C_word*)((C_word*)t0)[7])[1];
av2[5]=*((C_word*)lf[120]+1);
av2[6]=*((C_word*)lf[249]+1);
av2[7]=*((C_word*)lf[163]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k6194 in k6191 in k6188 in k6185 in k6182 in k6179 in k6174 in k6171 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in ... */
static void C_ccall f_6196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_6196,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:718: end-time */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5160(t3,t2,lf[247]);}

/* k6197 in k6194 in k6191 in k6188 in k6185 in k6182 in k6179 in k6174 in k6171 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in ... */
static void C_ccall f_6199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_6199,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6202,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[120]+1))){
/* batch-driver.scm:720: print-node */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4935(t3,t2,lf[245],lf[246],((C_word*)t0)[4]);}
else{
t3=C_set_block_item(lf[160] /* chicken.compiler.core#first-analysis */,0,C_SCHEME_TRUE);
t4=((C_word*)t0)[2];
f_5761(t4,t3);}}

/* k6200 in k6197 in k6194 in k6191 in k6188 in k6185 in k6182 in k6179 in k6174 in k6171 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in ... */
static void C_ccall f_6202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6202,2,av);}
t2=C_set_block_item(lf[160] /* chicken.compiler.core#first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_5761(t3,t2);}

/* for-each-loop2050 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in ... */
static void C_fcall f_6208(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,2)))){
C_save_and_reclaim_args((void *)trf_6208,3,t0,t1,t2);}
a=C_alloc(11);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6218,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6163,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6167,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:705: scheme#symbol->string */
t8=*((C_word*)lf[258]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6216 in for-each-loop2050 in k6152 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in ... */
static void C_ccall f_6218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6218,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6208(t3,((C_word*)t0)[4],t2);}

/* for-each-loop2029 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in ... */
static void C_fcall f_6231(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,4)))){
C_save_and_reclaim_args((void *)trf_6231,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6241,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6139,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:699: chicken.compiler.scrutinizer#load-type-database */
t8=*((C_word*)lf[255]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
av2[3]=*((C_word*)lf[120]+1);
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6239 in for-each-loop2029 in k6146 in k6132 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in ... */
static void C_ccall f_6241(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6241,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6231(t3,((C_word*)t0)[4],t2);}

/* k6258 in k5756 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in ... */
static void C_ccall f_6260(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6260,2,av);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
f_6134(2,av2);}}
else{
/* batch-driver.scm:695: chicken.compiler.support#quit-compiling */
t2=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[262];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k6270 in for-each-loop2006 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in ... */
static void C_ccall f_6272(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6272,2,av);}
/* batch-driver.scm:687: chicken.compiler.support#load-inline-file */
t2=*((C_word*)lf[264]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* for-each-loop2006 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in ... */
static void C_fcall f_6283(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,0,4)))){
C_save_and_reclaim_args((void *)trf_6283,3,t0,t1,t2);}
a=C_alloc(15);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6293,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6272,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t7;
t9=C_a_i_list(&a,1,t6);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9145,a[2]=t8,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t10;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[265];
av2[4]=t9;
C_apply(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6291 in for-each-loop2006 in k5753 in k5750 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in ... */
static void C_ccall f_6293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6293,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6283(t3,((C_word*)t0)[4],t2);}

/* k6307 in for-each-loop1984 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in ... */
static void C_ccall f_6309(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,4)))){
C_save_and_reclaim((void *)f_6309,2,av);}
a=C_alloc(10);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6315,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=C_a_i_list(&a,1,t2);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9153,a[2]=t4,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[268];
av2[4]=t5;
C_apply(5,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6313 in k6307 in for-each-loop1984 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in ... */
static void C_ccall f_6315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6315,2,av);}
/* batch-driver.scm:679: chicken.compiler.support#load-inline-file */
t2=*((C_word*)lf[264]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6320 in for-each-loop1984 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in ... */
static void C_ccall f_6322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,5)))){
C_save_and_reclaim((void *)f_6322,2,av);}
/* batch-driver.scm:676: ##sys#resolve-include-filename */
t2=*((C_word*)lf[269]+1);{
C_word *av2;
if(c >= 6) {
  av2=av;
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[270];
av2[4]=C_SCHEME_TRUE;
av2[5]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* for-each-loop1984 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in ... */
static void C_fcall f_6330(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,2)))){
C_save_and_reclaim_args((void *)trf_6330,3,t0,t1,t2);}
a=C_alloc(11);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6340,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6309,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6322,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:677: scheme#symbol->string */
t8=*((C_word*)lf[258]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6338 in for-each-loop1984 in k5747 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in ... */
static void C_ccall f_6340(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6340,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6330(t3,((C_word*)t0)[4],t2);}

/* k6352 in k5744 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in ... */
static void C_ccall f_6354(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6354,2,av);}
if(C_truep(t1)){
/* batch-driver.scm:672: chicken.pretty-print#pp */
t2=*((C_word*)lf[191]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_5749(2,av2);}}}

/* k6365 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in ... */
static void C_ccall f_6367(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6367,2,av);}
/* batch-driver.scm:670: concatenate */
f_3177(((C_word*)t0)[2],t1);}

/* map-loop1958 in k5741 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in ... */
static void C_fcall f_6369(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_6369,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6403 in k5738 in k5735 in k5732 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in ... */
static void C_ccall f_6405(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6405,2,av);}
/* batch-driver.scm:669: concatenate */
f_3177(((C_word*)t0)[2],t1);}

/* k6407 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in ... */
static void C_ccall f_6409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6409,2,av);}
/* batch-driver.scm:661: chicken.compiler.core#build-toplevel-procedure */
t2=*((C_word*)lf[277]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6411 in k5729 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in ... */
static void C_ccall f_6413(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6413,2,av);}
/* batch-driver.scm:662: chicken.compiler.support#build-node-graph */
t2=*((C_word*)lf[278]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6414 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in ... */
static void C_ccall f_6416(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_6416,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:656: begin-time */
t3=((C_word*)((C_word*)t0)[6])[1];
f_5150(t3,t2);}

/* k6417 in k6414 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in ... */
static void C_ccall f_6419(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_6419,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=((C_word*)t0)[2];
t7=((C_word*)((C_word*)t0)[3])[1];
t8=C_i_check_list_2(t7,lf[5]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6429,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6434,a[2]=t4,a[3]=t11,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_6434(t13,t9,t7);}

/* k6427 in k6417 in k6414 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in ... */
static void C_ccall f_6429(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6429,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* batch-driver.scm:658: end-time */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5160(t3,((C_word*)t0)[4],lf[280]);}

/* map-loop1925 in k6417 in k6414 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in ... */
static void C_fcall f_6434(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6434,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6459,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:657: g1931 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6457 in map-loop1925 in k6417 in k6414 in k5726 in k5723 in k5720 in k5717 in k5712 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in ... */
static void C_ccall f_6459(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6459,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6434(t6,((C_word*)t0)[5],t5);}

/* k6472 in k5709 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in ... */
static void C_ccall f_6474(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6474,2,av);}
if(C_truep(t1)){
/* batch-driver.scm:642: chicken.compiler.support#display-line-number-database */
t2=*((C_word*)lf[287]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_5714(2,av2);}}}

/* k6478 in k5706 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in ... */
static void C_ccall f_6480(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6480,2,av);}
if(C_truep(t1)){
/* batch-driver.scm:640: chicken.compiler.support#display-real-name-table */
t2=*((C_word*)lf[290]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_5711(2,av2);}}}

/* a6490 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in ... */
static void C_ccall f_6491(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6491,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6495,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:635: chicken.base#print */
t3=*((C_word*)lf[296]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[297];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6493 in a6490 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in ... */
static void C_ccall f_6495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_6495,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[293]+1);
t3=C_i_check_list_2(*((C_word*)lf[293]+1),lf[10]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6529,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6529(t7,((C_word*)t0)[2],*((C_word*)lf[293]+1));}

/* k6501 in for-each-loop1896 in k6493 in a6490 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in ... */
static void C_ccall f_6503(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_6503,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm:637: ##sys#print */
t4=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k6504 in k6501 in for-each-loop1896 in k6493 in a6490 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in ... */
static void C_ccall f_6506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_6506,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:637: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[294];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6507 in k6504 in k6501 in for-each-loop1896 in k6493 in a6490 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in ... */
static void C_ccall f_6509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_6509,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* batch-driver.scm:637: ##sys#print */
t4=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k6510 in k6507 in k6504 in k6501 in for-each-loop1896 in k6493 in a6490 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in ... */
static void C_ccall f_6512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6512,2,av);}
/* batch-driver.scm:637: ##sys#write-char-0 */
t2=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop1896 in k6493 in a6490 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in ... */
static void C_fcall f_6529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,4)))){
C_save_and_reclaim_args((void *)trf_6529,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6539,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=*((C_word*)lf[20]+1);
t8=*((C_word*)lf[20]+1);
t9=C_i_check_port_2(*((C_word*)lf[20]+1),C_fix(2),C_SCHEME_TRUE,lf[21]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6503,a[2]=t5,a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:637: ##sys#print */
t11=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[295];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6537 in for-each-loop1896 in k6493 in a6490 in k5703 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in ... */
static void C_ccall f_6539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6539,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6529(t3,((C_word*)t0)[4],t2);}

/* k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in ... */
static void C_ccall f_6553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,3)))){
C_save_and_reclaim((void *)f_6553,2,av);}
a=C_alloc(15);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6559,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6713,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_a_i_list(&a,1,*((C_word*)lf[315]+1));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3715,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* mini-srfi-1.scm:182: filter */
f_3325(t4,t6,lf[316]);}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_5705(2,av2);}}}

/* k6557 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in ... */
static void C_ccall f_6559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_6559,2,av);}
a=C_alloc(4);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6572,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:628: chicken.base#open-output-string */
t3=*((C_word*)lf[307]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_5705(2,av2);}}}

/* k6570 in k6557 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in ... */
static void C_ccall f_6572(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6572,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_fix(2),C_SCHEME_TRUE,lf[300]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6578,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:628: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[306];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k6576 in k6570 in k6557 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in ... */
static void C_ccall f_6578(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_6578,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6588,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=*((C_word*)lf[303]+1);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6595,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6597,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_6597(t13,t9,((C_word*)t0)[5]);}

/* k6579 in k6576 in k6570 in k6557 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in ... */
static void C_ccall f_6581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6581,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6584,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:628: chicken.base#get-output-string */
t3=*((C_word*)lf[302]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6582 in k6579 in k6576 in k6570 in k6557 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in ... */
static void C_ccall f_6584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6584,2,av);}
/* batch-driver.scm:627: chicken.base#warning */
t2=*((C_word*)lf[301]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6586 in k6576 in k6570 in k6557 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in ... */
static void C_ccall f_6588(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6588,2,av);}
/* batch-driver.scm:628: ##sys#print */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6593 in k6576 in k6570 in k6557 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in ... */
static void C_ccall f_6595(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6595,2,av);}
/* batch-driver.scm:629: chicken.string#string-intersperse */
t2=*((C_word*)lf[304]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[305];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop1865 in k6576 in k6570 in k6557 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in ... */
static void C_fcall f_6597(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6597,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6622,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:629: g1871 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6620 in map-loop1865 in k6576 in k6570 in k6557 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in ... */
static void C_ccall f_6622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6622,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6597(t6,((C_word*)t0)[5],t5);}

/* k6637 in k6711 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in ... */
static void C_ccall f_6639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6639,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_fix(2),C_SCHEME_TRUE,lf[300]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6645,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[311]+1))){
/* batch-driver.scm:623: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[312];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
if(C_truep(((C_word*)t0)[4])){
/* batch-driver.scm:623: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[313];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
/* batch-driver.scm:623: ##sys#print */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[314];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}}

/* k6643 in k6637 in k6711 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in ... */
static void C_ccall f_6645(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_6645,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:623: ##sys#print */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[310];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6646 in k6643 in k6637 in k6711 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in ... */
static void C_ccall f_6648(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,3)))){
C_save_and_reclaim((void *)f_6648,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6658,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=*((C_word*)lf[303]+1);
t9=C_i_check_list_2(((C_word*)t0)[5],lf[5]);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6668,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6670,a[2]=t6,a[3]=t12,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_6670(t14,t10,((C_word*)t0)[5]);}

/* k6649 in k6646 in k6643 in k6637 in k6711 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in ... */
static void C_ccall f_6651(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6651,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6654,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:623: chicken.base#get-output-string */
t3=*((C_word*)lf[302]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6652 in k6649 in k6646 in k6643 in k6637 in k6711 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in ... */
static void C_ccall f_6654(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_6654,2,av);}
/* batch-driver.scm:622: chicken.base#notice */
t2=*((C_word*)lf[308]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6656 in k6646 in k6643 in k6637 in k6711 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in ... */
static void C_ccall f_6658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_6658,2,av);}
/* batch-driver.scm:623: ##sys#print */
t2=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6666 in k6646 in k6643 in k6637 in k6711 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in ... */
static void C_ccall f_6668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6668,2,av);}
/* batch-driver.scm:625: chicken.string#string-intersperse */
t2=*((C_word*)lf[304]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[309];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop1827 in k6646 in k6643 in k6637 in k6711 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in ... */
static void C_fcall f_6670(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6670,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6695,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:625: g1833 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6693 in map-loop1827 in k6646 in k6643 in k6637 in k6711 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in ... */
static void C_ccall f_6695(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6695,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6670(t6,((C_word*)t0)[5],t5);}

/* k6711 in k6551 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in ... */
static void C_ccall f_6713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_6713,2,av);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:623: chicken.base#open-output-string */
t3=*((C_word*)lf[307]+1);{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_6559(2,av2);}}}

/* a6714 in k5700 in k5697 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in ... */
static void C_ccall f_6715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6715,3,av);}
t3=*((C_word*)lf[317]+1);
/* batch-driver.scm:620: g1812 */
t4=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6727 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in ... */
static void C_ccall f_6729(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6729,2,av);}
/* batch-driver.scm:612: chicken.compiler.support#quit-compiling */
t2=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[319];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6746 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in ... */
static void C_ccall f_6748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_6748,2,av);}
/* batch-driver.scm:615: chicken.string#string-intersperse */
t2=*((C_word*)lf[304]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[320];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop1779 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in ... */
static void C_fcall f_6750(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6750,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6775,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
/* batch-driver.scm:616: chicken.string#->string */
t6=*((C_word*)lf[303]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6773 in map-loop1779 in k5694 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in ... */
static void C_ccall f_6775(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6775,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6750(t6,((C_word*)t0)[5],t5);}

/* k6805 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in ... */
static void C_ccall f_6807(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,c,3)))){
C_save_and_reclaim((void *)f_6807,2,av);}
a=C_alloc(19);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=*((C_word*)lf[315]+1);
t8=C_i_check_list_2(*((C_word*)lf[315]+1),lf[5]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6856,a[2]=t5,a[3]=t11,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6856(t13,t9,*((C_word*)lf[315]+1));}

/* k6820 in k6805 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in ... */
static void C_ccall f_6822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,2)))){
C_save_and_reclaim((void *)f_6822,2,av);}
a=C_alloc(17);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(*((C_word*)lf[311]+1))){
t4=C_a_i_list(&a,2,lf[326],*((C_word*)lf[311]+1));
t5=t3;
f_6826(t5,C_a_i_list(&a,1,t4));}
else{
t4=t3;
f_6826(t4,C_SCHEME_END_OF_LIST);}}

/* k6824 in k6820 in k6805 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in ... */
static void C_fcall f_6826(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_6826,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(*((C_word*)lf[324]+1))){
if(C_truep(C_i_not(*((C_word*)lf[311]+1)))){
if(C_truep(((C_word*)t0)[7])){
/* batch-driver.scm:603: chicken.compiler.support#profiling-prelude-exps */
t4=*((C_word*)lf[325]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* batch-driver.scm:603: chicken.compiler.support#profiling-prelude-exps */
t4=*((C_word*)lf[325]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}
else{
/* batch-driver.scm:603: chicken.compiler.support#profiling-prelude-exps */
t4=*((C_word*)lf[325]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
f_6830(2,av2);}}}

/* k6828 in k6824 in k6820 in k6805 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in ... */
static void C_ccall f_6830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,7)))){
C_save_and_reclaim((void *)f_6830,2,av);}
if(C_truep(*((C_word*)lf[322]+1))){
t2=((C_word*)((C_word*)t0)[2])[1];
/* batch-driver.scm:598: scheme#append */
t3=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
av2[5]=t1;
av2[6]=((C_word*)t0)[7];
av2[7]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}
else{
/* batch-driver.scm:598: scheme#append */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 8) {
  av2=av;
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
av2[5]=t1;
av2[6]=((C_word*)t0)[7];
av2[7]=lf[323];
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}}

/* map-loop1742 in k6805 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in ... */
static void C_fcall f_6856(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_6856,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,lf[327],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop1712 in k5691 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in ... */
static void C_fcall f_6890(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(18,0,2)))){
C_save_and_reclaim_args((void *)trf_6890,3,t0,t1,t2);}
a=C_alloc(18);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_u_i_car(t3);
t6=C_a_i_list(&a,2,lf[328],t5);
t7=C_a_i_list(&a,3,lf[329],t4,t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t8);
t10=C_mutate(((C_word *)((C_word*)t0)[2])+1,t8);
t11=C_slot(t2,C_fix(1));
t13=t1;
t14=t11;
t1=t13;
t2=t14;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop1670 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in ... */
static void C_fcall f_6924(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6924,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6949,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:589: g1676 */
t5=((C_word*)t0)[4];
f_5661(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6947 in map-loop1670 in k5685 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in ... */
static void C_ccall f_6949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_6949,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6924(t6,((C_word*)t0)[5],t5);}

/* k6972 in k5682 in k5655 in k5652 in k5649 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in ... */
static void C_ccall f_6974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,1)))){
C_save_and_reclaim((void *)f_6974,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,lf[330],t3);
t5=((C_word*)t0)[3];
f_5687(t5,C_a_i_list(&a,1,t4));}

/* k6979 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in ... */
static void C_ccall f_6981(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,3)))){
C_save_and_reclaim((void *)f_6981,2,av);}
a=C_alloc(17);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=((C_word*)t0)[2];
t7=((C_word*)((C_word*)t0)[3])[1];
t8=C_i_check_list_2(t7,lf[5]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6993,a[2]=t4,a[3]=t11,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_6993(t13,t9,t7);}

/* k6989 in k6979 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in ... */
static void C_ccall f_6991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_6991,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_5651(t3,t2);}

/* map-loop1642 in k6979 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in ... */
static void C_fcall f_6993(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_6993,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7018,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:584: g1648 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7016 in map-loop1642 in k6979 in k5646 in k5643 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in ... */
static void C_ccall f_7018(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7018,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6993(t6,((C_word*)t0)[5],t5);}

/* k7026 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in ... */
static void C_ccall f_7028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_7028,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:561: proc */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k7030 in k7026 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in ... */
static void C_ccall f_7032(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7032,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
f_5645(2,av2);}}

/* doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in ... */
static void C_fcall f_7037(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,0,3)))){
C_save_and_reclaim_args((void *)trf_7037,3,t0,t1,t2);}
a=C_alloc(22);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7048,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=*((C_word*)lf[337]+1);
t9=C_i_check_list_2(((C_word*)t0)[3],lf[5]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7058,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7108,a[2]=t6,a[3]=t12,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_7108(t14,t10,((C_word*)t0)[3]);}
else{
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7146,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:570: chicken.compiler.support#check-and-open-input-file */
t6=*((C_word*)lf[341]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k7046 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in ... */
static void C_ccall f_7048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7048,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7056 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in ... */
static void C_ccall f_7058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_7058,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:567: scheme#reverse */
t4=*((C_word*)lf[338]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7060 in k7056 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in ... */
static void C_ccall f_7062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_7062,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=*((C_word*)lf[337]+1);
t8=C_i_check_list_2(((C_word*)t0)[2],lf[5]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7072,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7074,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_7074(t13,t9,((C_word*)t0)[2]);}

/* k7070 in k7060 in k7056 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in ... */
static void C_ccall f_7072(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7072,2,av);}
/* batch-driver.scm:566: scheme#append */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop1593 in k7060 in k7056 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in ... */
static void C_fcall f_7074(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7074,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7099,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:568: g1599 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7097 in map-loop1593 in k7060 in k7056 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in ... */
static void C_ccall f_7099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7099,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7074(t6,((C_word*)t0)[5],t5);}

/* map-loop1567 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in ... */
static void C_fcall f_7108(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7108,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7133,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:566: g1573 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7131 in map-loop1567 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in ... */
static void C_ccall f_7133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7133,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7108(t6,((C_word*)t0)[5],t5);}

/* k7144 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in ... */
static void C_ccall f_7146(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,4)))){
C_save_and_reclaim((void *)f_7146,2,av);}
a=C_alloc(22);
t2=t1;
t3=((C_word*)t0)[2];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7156,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7161,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7189,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:571: ##sys#dynamic-wind */
t11=*((C_word*)lf[156]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t11;
av2[1]=t7;
av2[2]=t8;
av2[3]=t9;
av2[4]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}

/* k7147 in k7144 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in ... */
static void C_ccall f_7149(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7149,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)((C_word*)t0)[3])[1];
f_7037(t4,((C_word*)t0)[4],t3);}

/* a7155 in k7144 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in ... */
static void C_ccall f_7156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7156,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[154]+1));
t3=C_mutate((C_word*)lf[154]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a7160 in k7144 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in ... */
static void C_ccall f_7161(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_7161,2,av);}
a=C_alloc(8);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7167(t5,t1);}

/* loop in a7160 in k7144 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in ... */
static void C_fcall f_7167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_7167,2,t0,t1);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7171,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:573: chicken.compiler.support#read/source-info */
t3=*((C_word*)lf[340]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7169 in loop in a7160 in k7144 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in ... */
static void C_ccall f_7171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_7171,2,av);}
a=C_alloc(3);
if(C_truep(C_eofp(t1))){
/* batch-driver.scm:575: chicken.compiler.support#close-checked-input-file */
t2=*((C_word*)lf[339]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
/* batch-driver.scm:578: loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_7167(t4,((C_word*)t0)[2]);}}

/* a7188 in k7144 in doloop1562 in k5640 in k5637 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in ... */
static void C_ccall f_7189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7189,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[154]+1));
t3=C_mutate((C_word*)lf[154]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k7194 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in ... */
static void C_ccall f_7196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_7196,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7204,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:556: collect-options */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5115(t6,t5,lf[343]);}

/* k7202 in k7194 in k5634 in k5631 in k5628 in k5624 in k5620 in k5617 in k5614 in k5611 in k5608 in k5569 in k5550 in k5547 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in ... */
static void C_ccall f_7204(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7204,2,av);}
/* batch-driver.scm:553: scheme#append */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7220 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in ... */
static void C_ccall f_7222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_7222,2,av);}
a=C_alloc(5);
t2=C_set_block_item(lf[324] /* chicken.compiler.core#emit-profile */,0,C_SCHEME_TRUE);
t3=C_mutate((C_word*)lf[361]+1 /* (set! chicken.compiler.core#profiled-procedures ...) */,lf[362]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm:515: scheme#append */
t5=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=*((C_word*)lf[366]+1);
av2[4]=lf[367];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
/* batch-driver.scm:515: scheme#append */
t5=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=*((C_word*)lf[366]+1);
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* k7226 in k7220 in k5544 in k5541 in k5538 in k5535 in k5524 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in ... */
static void C_ccall f_7228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_7228,2,av);}
a=C_alloc(6);
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[4];
t4=C_a_i_list(&a,1,lf[363]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9215,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[364];
av2[4]=t4;
C_apply(5,av2);}}
else{
t3=((C_word*)t0)[4];
t4=C_a_i_list(&a,1,lf[365]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f9221,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[179]+1);
av2[3]=lf[364];
av2[4]=t4;
C_apply(5,av2);}}}

/* k7275 in k5520 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in ... */
static void C_ccall f_7277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7277,2,av);}
/* batch-driver.scm:493: arg-val */
f_5030(((C_word*)t0)[3],t1);}

/* k7282 in k5516 in k5513 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in ... */
static void C_ccall f_7284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7284,2,av);}
/* batch-driver.scm:490: arg-val */
f_5030(((C_word*)t0)[3],t1);}

/* k7298 in map-loop1503 in k7301 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in ... */
static void C_ccall f_7300(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_7300,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[379],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7301 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in ... */
static void C_ccall f_7303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,c,3)))){
C_save_and_reclaim((void *)f_7303,2,av);}
a=C_alloc(11);
t2=C_i_check_list_2(t1,lf[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7311,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7311(t7,t3,t1);}

/* k7307 in k7301 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in ... */
static void C_ccall f_7309(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7309,2,av);}
/* batch-driver.scm:481: scheme#append */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop1503 in k7301 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in ... */
static void C_fcall f_7311(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,2)))){
C_save_and_reclaim_args((void *)trf_7311,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7336,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7300,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:483: scheme#string->symbol */
t7=*((C_word*)lf[331]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7334 in map-loop1503 in k7301 in k5509 in k5506 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in ... */
static void C_ccall f_7336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7336,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7311(t6,((C_word*)t0)[5],t5);}

/* a7359 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in ... */
static void C_ccall f_7360(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,3)))){
C_save_and_reclaim((void *)f_7360,3,av);}
a=C_alloc(10);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7367,a[2]=t5,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:473: chicken.string#string-split */
t8=*((C_word*)lf[383]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
av2[3]=lf[384];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k7365 in a7359 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in ... */
static void C_ccall f_7367(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_7367,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7372,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7372(t5,((C_word*)t0)[4],t1);}

/* map-loop1474 in k7365 in a7359 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in ... */
static void C_fcall f_7372(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7372,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7397,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:473: g1480 */
t5=*((C_word*)lf[331]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7395 in map-loop1474 in k7365 in a7359 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in ... */
static void C_ccall f_7397(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7397,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7372(t6,((C_word*)t0)[5],t5);}

/* k7406 in k5503 in k5495 in k5491 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in ... */
static void C_ccall f_7408(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7408,2,av);}
/* batch-driver.scm:472: append-map */
f_2915(((C_word*)t0)[2],((C_word*)t0)[3],t1,C_SCHEME_END_OF_LIST);}

/* for-each-loop1451 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in ... */
static void C_fcall f_7410(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,5)))){
C_save_and_reclaim_args((void *)trf_7410,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7420,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5475,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:463: ##sys#resolve-include-filename */
t8=*((C_word*)lf[269]+1);{
C_word av2[6];
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_TRUE;
av2[5]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(6,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7418 in for-each-loop1451 in k5468 in k5465 in k5458 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in ... */
static void C_ccall f_7420(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7420,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7410(t3,((C_word*)t0)[4],t2);}

/* for-each-loop1096 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in ... */
static void C_fcall f_7433(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7433,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7443,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:453: g1097 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7441 in for-each-loop1096 in k5452 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in ... */
static void C_ccall f_7443(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7443,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7433(t3,((C_word*)t0)[4],t2);}

/* a7455 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in ... */
static void C_ccall f_7456(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7456,3,av);}
t3=*((C_word*)lf[383]+1);
/* batch-driver.scm:455: g1441 */
t4=*((C_word*)lf[383]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[390];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7462 in k5449 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in ... */
static void C_ccall f_7464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7464,2,av);}
/* batch-driver.scm:455: append-map */
f_2915(((C_word*)t0)[2],((C_word*)t0)[3],t1,C_SCHEME_END_OF_LIST);}

/* for-each-loop1086 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in ... */
static void C_fcall f_7466(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_7466,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7476,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:450: g1087 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7474 in for-each-loop1086 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in ... */
static void C_ccall f_7476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7476,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7466(t3,((C_word*)t0)[4],t2);}

/* a7488 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in ... */
static void C_ccall f_7489(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7489,3,av);}
t3=*((C_word*)lf[383]+1);
/* batch-driver.scm:452: g1426 */
t4=*((C_word*)lf[383]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[392];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7495 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in ... */
static void C_ccall f_7497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7497,2,av);}
/* batch-driver.scm:452: append-map */
f_2915(((C_word*)t0)[2],((C_word*)t0)[3],t1,C_SCHEME_END_OF_LIST);}

/* k7508 in for-each-loop1381 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in ... */
static void C_ccall f_7510(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7510,2,av);}
/* batch-driver.scm:440: chicken.compiler.support#mark-variable */
t2=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[396];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7517 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in ... */
static void C_ccall f_7519(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_7519,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[73]+1);
t3=C_i_check_list_2(*((C_word*)lf[73]+1),lf[10]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7535,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7535(t7,((C_word*)t0)[2],*((C_word*)lf[73]+1));}

/* k7522 in for-each-loop1400 in k7517 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in ... */
static void C_ccall f_7524(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_7524,2,av);}
/* batch-driver.scm:445: chicken.compiler.support#mark-variable */
t2=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[396];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop1400 in k7517 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in ... */
static void C_fcall f_7535(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_7535,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7545,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7524,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:444: chicken.compiler.support#mark-variable */
t8=*((C_word*)lf[13]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[397];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7543 in for-each-loop1400 in k7517 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in ... */
static void C_ccall f_7545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7545,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7535(t3,((C_word*)t0)[4],t2);}

/* for-each-loop1381 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in ... */
static void C_fcall f_7558(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,0,3)))){
C_save_and_reclaim_args((void *)trf_7558,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7568,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7510,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:439: chicken.compiler.support#mark-variable */
t8=*((C_word*)lf[13]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[397];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7566 in for-each-loop1381 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in ... */
static void C_ccall f_7568(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7568,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7558(t3,((C_word*)t0)[4],t2);}

/* k7611 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in ... */
static void C_ccall f_7613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_7613,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(t1,lf[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7621,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7621(t7,t3,t1);}

/* k7617 in k7611 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in ... */
static void C_ccall f_7619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7619,2,av);}
/* batch-driver.scm:421: scheme#append */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=*((C_word*)lf[130]+1);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop1353 in k7611 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in ... */
static void C_fcall f_7621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7621,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7646,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:421: g1359 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7644 in map-loop1353 in k7611 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in ... */
static void C_ccall f_7646(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7646,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7621(t6,((C_word*)t0)[5],t5);}

/* k7656 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in ... */
static void C_ccall f_7658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7658,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:414: chicken.base#case-sensitive */
t3=*((C_word*)lf[415]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7659 in k7656 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in ... */
static void C_ccall f_7661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7661,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:415: chicken.base#keyword-style */
t3=*((C_word*)lf[413]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[414];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7662 in k7659 in k7656 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in ... */
static void C_ccall f_7664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7664,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:416: chicken.base#parentheses-synonyms */
t3=*((C_word*)lf[412]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7665 in k7662 in k7659 in k7656 in k5407 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in ... */
static void C_ccall f_7667(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7667,2,av);}
/* batch-driver.scm:417: chicken.base#symbol-escape */
t2=*((C_word*)lf[411]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7673 in k5404 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in ... */
static void C_ccall f_7675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7675,2,av);}
/* batch-driver.scm:411: chicken.base#symbol-escape */
t2=*((C_word*)lf[411]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7681 in k5401 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in ... */
static void C_ccall f_7683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7683,2,av);}
/* batch-driver.scm:408: chicken.base#parentheses-synonyms */
t2=*((C_word*)lf[412]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7687 in k5398 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in ... */
static void C_ccall f_7689(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7689,2,av);}
if(C_truep(C_i_string_equal_p(lf[421],t1))){
/* batch-driver.scm:401: chicken.base#keyword-style */
t2=*((C_word*)lf[413]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[422];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
if(C_truep(C_u_i_string_equal_p(lf[423],t1))){
/* batch-driver.scm:402: chicken.base#keyword-style */
t2=*((C_word*)lf[413]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[414];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
if(C_truep(C_u_i_string_equal_p(lf[424],t1))){
/* batch-driver.scm:403: chicken.base#keyword-style */
t2=*((C_word*)lf[413]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[425];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
/* batch-driver.scm:404: chicken.compiler.support#quit-compiling */
t2=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[426];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}}}

/* k7720 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in ... */
static void C_ccall f_7722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7722,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:397: chicken.platform#register-feature! */
t3=*((C_word*)lf[131]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[427];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7723 in k7720 in k5395 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in ... */
static void C_ccall f_7725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7725,2,av);}
/* batch-driver.scm:398: chicken.base#case-sensitive */
t2=*((C_word*)lf[415]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7730 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in ... */
static void C_ccall f_7732(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_7732,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7735,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:392: scheme#string->number */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7733 in k7730 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in ... */
static void C_ccall f_7735(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_7735,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7738,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t1;
t4=C_mutate((C_word*)lf[165]+1 /* (set! chicken.compiler.core#inline-max-size ...) */,t3);
t5=((C_word*)t0)[2];
f_5397(t5,t4);}
else{
/* batch-driver.scm:393: chicken.compiler.support#quit-compiling */
t3=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[429];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k7736 in k7733 in k7730 in k5390 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in ... */
static void C_ccall f_7738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7738,2,av);}
t2=C_mutate((C_word*)lf[165]+1 /* (set! chicken.compiler.core#inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_5397(t3,t2);}

/* k7743 in k5385 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in ... */
static void C_ccall f_7745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7745,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_5392(t3,t2);}

/* k7749 in k5380 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in ... */
static void C_ccall f_7751(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7751,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_5387(t3,t2);}

/* k7753 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in ... */
static void C_ccall f_7755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7755,2,av);}
t2=C_mutate((C_word*)lf[190]+1 /* (set! chicken.compiler.core#emit-link-file ...) */,t1);
t3=((C_word*)t0)[2];
f_5382(t3,t2);}

/* k7785 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5312 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in ... */
static void C_ccall f_7787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7787,2,av);}
t2=C_set_block_item(lf[199] /* ##sys#warnings-enabled */,0,C_SCHEME_FALSE);
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
f_5350(t4,t3);}

/* map-loop1292 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in ... */
static void C_fcall f_7834(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,2)))){
C_save_and_reclaim_args((void *)trf_7834,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7859,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5299,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:336: scheme#string->symbol */
t8=*((C_word*)lf[331]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7857 in map-loop1292 in k5306 in k5280 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in ... */
static void C_ccall f_7859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7859,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7834(t6,((C_word*)t0)[5],t5);}

/* k7870 in k5277 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in ... */
static void C_ccall f_7872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7872,2,av);}
/* batch-driver.scm:332: chicken.base#exit */
t2=*((C_word*)lf[196]+1);{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a7876 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_7877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_7877,3,av);}
a=C_alloc(10);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7893,a[2]=t5,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#string->list */
t8=*((C_word*)lf[464]+1);{
C_word *av2=av;
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k7891 in a7876 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in ... */
static void C_ccall f_7893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_7893,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7898,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7898(t5,((C_word*)t0)[4],t1);}

/* map-loop1264 in k7891 in a7876 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in ... */
static void C_fcall f_7898(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_7898,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7923,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_string(&a,1,t4);
/* batch-driver.scm:327: scheme#string->symbol */
t6=*((C_word*)lf[331]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7921 in map-loop1264 in k7891 in a7876 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in ... */
static void C_ccall f_7923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7923,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7898(t6,((C_word*)t0)[5],t5);}

/* k7932 in k5270 in k5267 in k5264 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in ... */
static void C_ccall f_7934(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_7934,2,av);}
/* batch-driver.scm:325: append-map */
f_2915(((C_word*)t0)[2],((C_word*)t0)[3],t1,C_SCHEME_END_OF_LIST);}

/* k7946 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_ccall f_7948(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_7948,2,av);}
t2=C_mutate((C_word*)lf[311]+1 /* (set! chicken.compiler.core#unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_5266(t3,t2);}

/* k7950 in k4888 in k4883 in k4863 in k4858 in k4855 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in ... */
static void C_ccall f_7952(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_7952,2,av);}
/* batch-driver.scm:317: scheme#string->symbol */
t2=*((C_word*)lf[331]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop1013 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in ... */
static void C_fcall f_7969(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_7969,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7994,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* batch-driver.scm:220: g1019 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7992 in map-loop1013 in k4849 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in ... */
static void C_ccall f_7994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_7994,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7969(t6,((C_word*)t0)[5],t5);}

/* k8003 in k4843 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in ... */
static void C_ccall f_8005(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8005,2,av);}
if(C_truep(t1)){
t2=t1;
/* batch-driver.scm:221: ##sys#split-path */
t3=*((C_word*)lf[470]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* batch-driver.scm:221: ##sys#split-path */
t2=*((C_word*)lf[470]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[471];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* g1006 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_8009(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_8009,3,t0,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8013,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:214: option-arg */
f_4787(t3,t2);}

/* k8011 in g1006 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in ... */
static void C_ccall f_8013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_8013,2,av);}
if(C_truep(C_i_symbolp(t1))){
/* batch-driver.scm:216: scheme#symbol->string */
t2=*((C_word*)lf[258]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k8035 in k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_8037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_8037,2,av);}
/* batch-driver.scm:219: chicken.pathname#make-pathname */
t2=*((C_word*)lf[256]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=t1;
av2[4]=lf[475];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k8046 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_8048(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(19,0,4)))){
C_save_and_reclaim_args((void *)trf_8048,2,t0,t1);}
a=C_alloc(19);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[3];
t6=C_u_i_memq(lf[88],t5);
t7=((C_word*)t0)[3];
t8=C_u_i_memq(lf[89],t7);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t8)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8009,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:212: g1006 */
t11=t10;
f_8009(t11,t9,t8);}
else{
t10=((C_word*)t0)[3];
if(C_truep(C_u_i_memq(lf[474],t10))){
t11=t9;{
C_word av2[2];
av2[0]=t11;
av2[1]=C_SCHEME_FALSE;
f_4845(2,av2);}}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8037,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[6])){
/* batch-driver.scm:219: chicken.pathname#pathname-file */
t12=*((C_word*)lf[476]+1);{
C_word av2[3];
av2[0]=t12;
av2[1]=t11;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
/* batch-driver.scm:219: chicken.pathname#make-pathname */
t12=*((C_word*)lf[256]+1);{
C_word av2[5];
av2[0]=t12;
av2[1]=t9;
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[477];
av2[4]=lf[475];
((C_proc)(void*)(*((C_word*)t12+1)))(5,av2);}}}}}

/* k8065 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_ccall f_8067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,1)))){
C_save_and_reclaim((void *)f_8067,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,lf[382],t1);
if(C_truep(*((C_word*)lf[78]+1))){
t3=((C_word*)t0)[2];
f_8048(t3,C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
t3=C_a_i_cons(&a,2,lf[379],*((C_word*)lf[478]+1));
t4=C_a_i_list(&a,1,t3);
t5=((C_word*)t0)[2];
f_8048(t5,C_a_i_cons(&a,2,t2,t4));}}

/* k8073 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_8075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_8075,2,t0,t1);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[482]+1))){
if(C_truep(*((C_word*)lf[83]+1))){
if(C_truep(C_i_not(((C_word*)t0)[4]))){
t4=C_i_not(((C_word*)t0)[5]);
t5=t3;
f_8082(t5,(C_truep(t4)?C_i_not(*((C_word*)lf[78]+1)):C_SCHEME_FALSE));}
else{
t4=t3;
f_8082(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8082(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8082(t4,C_SCHEME_FALSE);}}

/* k8080 in k8073 in k4829 in k4816 in chicken.compiler.batch-driver#compile-source-file in k2712 in k2709 in k2706 in k2703 in k2700 in k2697 in k2694 in k2691 in k2688 in k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2667 */
static void C_fcall f_8082(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,5)))){
C_save_and_reclaim_args((void *)trf_8082,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm:193: scheme#append */
t2=*((C_word*)lf[4]+1);{
C_word av2[6];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[480]+1);
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
av2[5]=lf[481];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}
else{
/* batch-driver.scm:193: scheme#append */
t2=*((C_word*)lf[4]+1);{
C_word av2[6];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[480]+1);
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
av2[5]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_batch_2ddriver_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("batch-driver"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void*)C_batch_2ddriver_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(3089))){
C_save(t1);
C_rereclaim2(3089*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,487);
lf[0]=C_h_intern(&lf[0],12, C_text("batch-driver"));
lf[1]=C_h_intern(&lf[1],30, C_text("chicken.compiler.batch-driver#"));
lf[3]=C_h_intern(&lf[3],5, C_text("foldr"));
lf[4]=C_h_intern(&lf[4],13, C_text("scheme#append"));
lf[5]=C_h_intern(&lf[5],3, C_text("map"));
lf[9]=C_h_intern(&lf[9],39, C_text("chicken.compiler.core#standard-bindings"));
lf[10]=C_h_intern(&lf[10],8, C_text("for-each"));
lf[11]=C_h_intern(&lf[11],39, C_text("chicken.compiler.core#extended-bindings"));
lf[12]=C_h_intern(&lf[12],39, C_text("chicken.compiler.core#internal-bindings"));
lf[13]=C_h_intern(&lf[13],38, C_text("chicken.compiler.support#mark-variable"));
lf[14]=C_h_intern(&lf[14],20, C_text("##compiler#intrinsic"));
lf[15]=C_h_intern(&lf[15],8, C_text("internal"));
lf[16]=C_h_intern(&lf[16],8, C_text("extended"));
lf[17]=C_h_intern(&lf[17],8, C_text("standard"));
lf[19]=C_h_intern(&lf[19],14, C_text("scheme#newline"));
lf[20]=C_h_intern(&lf[20],21, C_text("##sys#standard-output"));
lf[21]=C_h_intern(&lf[21],6, C_text("printf"));
lf[22]=C_h_intern(&lf[22],11, C_text("##sys#print"));
lf[23]=C_h_intern(&lf[23],40, C_text("chicken.compiler.support#node-parameters"));
lf[24]=C_h_intern(&lf[24],35, C_text("chicken.compiler.support#node-class"));
lf[25]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006\011pval="));
lf[26]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005\011val="));
lf[27]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006\011lval="));
lf[28]=C_h_intern(&lf[28],7, C_text("unknown"));
lf[29]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005\011css="));
lf[30]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006\011refs="));
lf[31]=C_h_intern(&lf[31],8, C_text("captured"));
lf[32]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001captured\376\001\000\000\003\001cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001assigned\376\001\000\000\003\001set\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\005\001boxed\376\001\000\000\003\001box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001global\376\001\000\000\003\001glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001assigned-locally\376"
"\001\000\000\003\001stl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001contractable\376\001\000\000\003\001con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001standard-binding\376\001\000"
"\000\003\001stb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001simple\376\001\000\000\003\001sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001inlinable\376\001\000\000\003\001inl\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\013\001collapsable\376\001\000\000\003\001col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001removable\376\001\000\000\003\001rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\001con"
"stant\376\001\000\000\003\001con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015\001inline-target\376\001\000\000\003\001ilt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001inline-trans"
"ient\376\001\000\000\003\001itr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001undefined\376\001\000\000\003\001und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\001replacing\376\001\000\000\003\001rp"
"g\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\001unused\376\001\000\000\003\001uud\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001extended-binding\376\001\000\000\003\001xtb\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\015\001inline-export\376\001\000\000\003\001ilx\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013\001hidden-refs\376\001\000\000\003\001hrf\376\003\000\000\002\376\003\000\000\002\376\001\000"
"\000\011\001value-ref\376\001\000\000\003\001vvf\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\001customizable\376\001\000\000\003\001cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025\001has-un"
"used-parameters\376\001\000\000\003\001hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\001boxed-rest\376\001\000\000\003\001bxr\376\377\016"));
lf[33]=C_h_intern(&lf[33],18, C_text("##sys#write-char-0"));
lf[34]=C_h_intern(&lf[34],5, C_text("value"));
lf[35]=C_h_intern(&lf[35],11, C_text("local-value"));
lf[36]=C_h_intern(&lf[36],16, C_text("potential-values"));
lf[37]=C_h_intern(&lf[37],10, C_text("replacable"));
lf[38]=C_h_intern(&lf[38],10, C_text("references"));
lf[39]=C_h_intern(&lf[39],10, C_text("call-sites"));
lf[40]=C_h_intern(&lf[40],29, C_text("chicken.compiler.support#bomb"));
lf[41]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020Illegal property"));
lf[42]=C_h_intern(&lf[42],4, C_text("home"));
lf[43]=C_h_intern(&lf[43],8, C_text("contains"));
lf[44]=C_h_intern(&lf[44],12, C_text("contained-in"));
lf[45]=C_h_intern(&lf[45],8, C_text("use-expr"));
lf[46]=C_h_intern(&lf[46],12, C_text("closure-size"));
lf[47]=C_h_intern(&lf[47],14, C_text("rest-parameter"));
lf[48]=C_h_intern(&lf[48],18, C_text("captured-variables"));
lf[49]=C_h_intern(&lf[49],13, C_text("explicit-rest"));
lf[50]=C_h_intern(&lf[50],8, C_text("assigned"));
lf[51]=C_h_intern(&lf[51],5, C_text("boxed"));
lf[52]=C_h_intern(&lf[52],6, C_text("global"));
lf[53]=C_h_intern(&lf[53],12, C_text("contractable"));
lf[54]=C_h_intern(&lf[54],16, C_text("standard-binding"));
lf[55]=C_h_intern(&lf[55],16, C_text("assigned-locally"));
lf[56]=C_h_intern(&lf[56],11, C_text("collapsable"));
lf[57]=C_h_intern(&lf[57],9, C_text("removable"));
lf[58]=C_h_intern(&lf[58],9, C_text("undefined"));
lf[59]=C_h_intern(&lf[59],9, C_text("replacing"));
lf[60]=C_h_intern(&lf[60],6, C_text("unused"));
lf[61]=C_h_intern(&lf[61],6, C_text("simple"));
lf[62]=C_h_intern(&lf[62],9, C_text("inlinable"));
lf[63]=C_h_intern(&lf[63],13, C_text("inline-export"));
lf[64]=C_h_intern(&lf[64],21, C_text("has-unused-parameters"));
lf[65]=C_h_intern(&lf[65],16, C_text("extended-binding"));
lf[66]=C_h_intern(&lf[66],12, C_text("customizable"));
lf[67]=C_h_intern(&lf[67],8, C_text("constant"));
lf[68]=C_h_intern(&lf[68],10, C_text("boxed-rest"));
lf[69]=C_h_intern(&lf[69],11, C_text("hidden-refs"));
lf[70]=C_h_intern(&lf[70],12, C_text("scheme#write"));
lf[71]=C_h_intern(&lf[71],36, C_text("chicken.internal#hash-table-for-each"));
lf[72]=C_h_intern(&lf[72],47, C_text("chicken.compiler.core#default-standard-bindings"));
lf[73]=C_h_intern(&lf[73],47, C_text("chicken.compiler.core#default-extended-bindings"));
lf[74]=C_h_intern(&lf[74],49, C_text("chicken.compiler.batch-driver#compile-source-file"));
lf[75]=C_h_intern(&lf[75],39, C_text("chicken.compiler.support#quit-compiling"));
lf[76]=C_decode_literal(C_heaptop,C_text("\376B\000\000 missing argument to `-~A\047 option"));
lf[77]=C_decode_literal(C_heaptop,C_text("\376B\000\000\037invalid argument to `~A\047 option"));
lf[78]=C_h_intern(&lf[78],39, C_text("chicken.compiler.core#explicit-use-flag"));
lf[79]=C_h_intern(&lf[79],12, C_text("explicit-use"));
lf[80]=C_h_intern(&lf[80],37, C_text("chicken.compiler.core#emit-debug-info"));
lf[81]=C_h_intern(&lf[81],10, C_text("debug-info"));
lf[82]=C_h_intern(&lf[82],22, C_text("no-module-registration"));
lf[83]=C_h_intern(&lf[83],48, C_text("chicken.compiler.core#enable-module-registration"));
lf[84]=C_h_intern(&lf[84],7, C_text("dynamic"));
lf[85]=C_h_intern(&lf[85],4, C_text("unit"));
lf[86]=C_h_intern(&lf[86],17, C_text("import-for-syntax"));
lf[87]=C_h_intern(&lf[87],39, C_text("chicken.internal#default-syntax-imports"));
lf[88]=C_h_intern(&lf[88],7, C_text("verbose"));
lf[89]=C_h_intern(&lf[89],11, C_text("output-file"));
lf[90]=C_h_intern(&lf[90],39, C_text("chicken.compiler.support#chop-separator"));
lf[91]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\042\001chicken.base#implicit-exit-handler\376\377\016\376\377\016\376\377\016"));
lf[92]=C_h_intern(&lf[92],7, C_text("profile"));
lf[93]=C_h_intern(&lf[93],12, C_text("profile-name"));
lf[94]=C_h_intern(&lf[94],9, C_text("heap-size"));
lf[95]=C_h_intern(&lf[95],13, C_text("keyword-style"));
lf[96]=C_h_intern(&lf[96],10, C_text("clustering"));
lf[97]=C_h_intern(&lf[97],12, C_text("analyze-only"));
lf[98]=C_h_intern(&lf[98],4, C_text("lfa2"));
lf[99]=C_h_intern(&lf[99],7, C_text("nursery"));
lf[100]=C_h_intern(&lf[100],6, C_text("module"));
lf[101]=C_h_intern(&lf[101],42, C_text("chicken.compiler.support#debugging-chicken"));
lf[102]=C_h_intern(&lf[102],34, C_text("chicken.compiler.support#debugging"));
lf[103]=C_h_intern(&lf[103],1, C_text("p"));
lf[104]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004pass"));
lf[105]=C_h_intern(&lf[105],35, C_text("chicken.compiler.support#dump-nodes"));
lf[106]=C_h_intern(&lf[106],33, C_text("chicken.pretty-print#pretty-print"));
lf[107]=C_h_intern(&lf[107],46, C_text("chicken.compiler.support#build-expression-tree"));
lf[108]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013(iteration "));
lf[109]=C_decode_literal(C_heaptop,C_text("\376B\000\000\033invalid numeric argument ~S"));
lf[110]=C_h_intern(&lf[110],21, C_text("scheme#string->number"));
lf[111]=C_h_intern(&lf[111],16, C_text("scheme#substring"));
lf[112]=C_h_intern(&lf[112],33, C_text("chicken.time#current-milliseconds"));
lf[113]=C_h_intern(&lf[113],21, C_text("scheme#inexact->exact"));
lf[114]=C_h_intern(&lf[114],12, C_text("scheme#round"));
lf[115]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003: \011"));
lf[116]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030milliseconds needed for "));
lf[117]=C_h_intern(&lf[117],31, C_text("chicken.compiler.support#db-get"));
lf[118]=C_h_intern(&lf[118],32, C_text("chicken.compiler.support#db-put!"));
lf[119]=C_h_intern(&lf[119],40, C_text("chicken.compiler.core#analyze-expression"));
lf[120]=C_h_intern(&lf[120],43, C_text("chicken.compiler.core#enable-specialization"));
lf[121]=C_h_intern(&lf[121],10, C_text("specialize"));
lf[122]=C_h_intern(&lf[122],1, C_text("D"));
lf[123]=C_h_intern(&lf[123],38, C_text("chicken.compiler.core#import-libraries"));
lf[124]=C_h_intern(&lf[124],14, C_text("emit-link-file"));
lf[125]=C_h_intern(&lf[125],16, C_text("emit-inline-file"));
lf[126]=C_h_intern(&lf[126],15, C_text("emit-types-file"));
lf[127]=C_h_intern(&lf[127],12, C_text("inline-limit"));
lf[128]=C_h_intern(&lf[128],34, C_text("chicken.compiler.core#verbose-mode"));
lf[129]=C_h_intern(&lf[129],33, C_text("##sys#read-error-with-line-number"));
lf[130]=C_h_intern(&lf[130],23, C_text("##sys#include-pathnames"));
lf[131]=C_h_intern(&lf[131],34, C_text("chicken.platform#register-feature!"));
lf[132]=C_h_intern(&lf[132],36, C_text("chicken.platform#unregister-feature!"));
lf[133]=C_h_intern_kw(&lf[133],18, C_text("compiler-extension"));
lf[134]=C_h_intern(&lf[134],14, C_text("##sys#features"));
lf[135]=C_h_intern_kw(&lf[135],9, C_text("compiling"));
lf[136]=C_h_intern(&lf[136],38, C_text("chicken.compiler.core#target-heap-size"));
lf[137]=C_h_intern(&lf[137],39, C_text("chicken.compiler.core#target-stack-size"));
lf[138]=C_h_intern(&lf[138],8, C_text("no-trace"));
lf[139]=C_h_intern(&lf[139],37, C_text("chicken.compiler.core#emit-trace-info"));
lf[140]=C_h_intern(&lf[140],53, C_text("chicken.compiler.core#disable-stack-overflow-checking"));
lf[141]=C_h_intern(&lf[141],29, C_text("disable-stack-overflow-checks"));
lf[142]=C_h_intern(&lf[142],36, C_text("chicken.compiler.core#bootstrap-mode"));
lf[143]=C_h_intern(&lf[143],7, C_text("version"));
lf[144]=C_h_intern(&lf[144],38, C_text("chicken.compiler.support#print-version"));
lf[145]=C_h_intern(&lf[145],4, C_text("help"));
lf[146]=C_h_intern(&lf[146],36, C_text("chicken.compiler.support#print-usage"));
lf[147]=C_h_intern(&lf[147],7, C_text("release"));
lf[148]=C_h_intern(&lf[148],14, C_text("scheme#display"));
lf[149]=C_h_intern(&lf[149],32, C_text("chicken.platform#chicken-version"));
lf[150]=C_decode_literal(C_heaptop,C_text("\376B\000\0001\012Run `csi\047 to start the interactive interpreter.\012"));
lf[151]=C_decode_literal(C_heaptop,C_text("\376B\000\000.or try `csc\047 for a more convenient interface.\012"));
lf[152]=C_decode_literal(C_heaptop,C_text("\376B\000\000C\012Enter `chicken -help\047 for information on how to use the compiler,\012"));
lf[153]=C_h_intern(&lf[153],26, C_text("##sys#line-number-database"));
lf[154]=C_h_intern(&lf[154],29, C_text("##sys#current-source-filename"));
lf[155]=C_h_intern(&lf[155],45, C_text("chicken.compiler.core#canonicalize-expression"));
lf[156]=C_h_intern(&lf[156],18, C_text("##sys#dynamic-wind"));
lf[157]=C_h_intern(&lf[157],44, C_text("chicken.compiler.core#line-number-database-2"));
lf[158]=C_h_intern(&lf[158],36, C_text("chicken.compiler.core#constant-table"));
lf[159]=C_h_intern(&lf[159],34, C_text("chicken.compiler.core#inline-table"));
lf[160]=C_h_intern(&lf[160],36, C_text("chicken.compiler.core#first-analysis"));
lf[161]=C_h_intern(&lf[161],54, C_text("chicken.compiler.optimizer#determine-loop-and-dispatch"));
lf[162]=C_h_intern(&lf[162],59, C_text("chicken.compiler.optimizer#perform-high-level-optimizations"));
lf[163]=C_h_intern(&lf[163],39, C_text("chicken.compiler.core#block-compilation"));
lf[164]=C_h_intern(&lf[164],36, C_text("chicken.compiler.core#inline-locally"));
lf[165]=C_h_intern(&lf[165],37, C_text("chicken.compiler.core#inline-max-size"));
lf[166]=C_h_intern(&lf[166],50, C_text("chicken.compiler.core#inline-substitutions-enabled"));
lf[167]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022clustering enabled"));
lf[168]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022rewritings enabled"));
lf[169]=C_h_intern(&lf[169],44, C_text("chicken.compiler.core#optimize-leaf-routines"));
lf[170]=C_decode_literal(C_heaptop,C_text("\376B\000\000\031leaf routine optimization"));
lf[171]=C_h_intern(&lf[171],52, C_text("chicken.compiler.optimizer#transform-direct-lambdas!"));
lf[172]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010analysis"));
lf[173]=C_h_intern(&lf[173],4, C_text("leaf"));
lf[174]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023optimized-iteration"));
lf[175]=C_h_intern(&lf[175],1, C_text("5"));
lf[176]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014optimization"));
lf[177]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021optimization pass"));
lf[178]=C_h_intern(&lf[178],49, C_text("chicken.compiler.core#prepare-for-code-generation"));
lf[179]=C_h_intern(&lf[179],22, C_text("chicken.format#sprintf"));
lf[180]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025compilation finished."));
lf[181]=C_h_intern(&lf[181],46, C_text("chicken.compiler.support#compiler-cleanup-hook"));
lf[182]=C_h_intern(&lf[182],1, C_text("t"));
lf[183]=C_h_intern(&lf[183],19, C_text("##sys#display-times"));
lf[184]=C_h_intern(&lf[184],16, C_text("##sys#stop-timer"));
lf[185]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017code generation"));
lf[186]=C_h_intern(&lf[186],24, C_text("scheme#close-output-port"));
lf[187]=C_h_intern(&lf[187],40, C_text("chicken.compiler.c-backend#generate-code"));
lf[188]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023generating `~A\047 ..."));
lf[189]=C_h_intern(&lf[189],23, C_text("scheme#open-output-file"));
lf[190]=C_h_intern(&lf[190],36, C_text("chicken.compiler.core#emit-link-file"));
lf[191]=C_h_intern(&lf[191],23, C_text("chicken.pretty-print#pp"));
lf[192]=C_h_intern(&lf[192],46, C_text("chicken.compiler.core#linked-static-extensions"));
lf[193]=C_h_intern(&lf[193],26, C_text("scheme#with-output-to-file"));
lf[194]=C_decode_literal(C_heaptop,C_text("\376B\000\000\035generating link file `~a\047 ..."));
lf[195]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013preparation"));
lf[196]=C_h_intern(&lf[196],17, C_text("chicken.base#exit"));
lf[197]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021closure-converted"));
lf[198]=C_h_intern(&lf[198],1, C_text("9"));
lf[199]=C_h_intern(&lf[199],22, C_text("##sys#warnings-enabled"));
lf[200]=C_decode_literal(C_heaptop,C_text("\376B\000\000#(don\047t worry - still compiling...)\012"));
lf[201]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016final-analysis"));
lf[202]=C_h_intern(&lf[202],1, C_text("8"));
lf[203]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022closure conversion"));
lf[204]=C_h_intern(&lf[204],48, C_text("chicken.compiler.core#perform-closure-conversion"));
lf[205]=C_h_intern(&lf[205],41, C_text("chicken.compiler.core#insert-timer-checks"));
lf[206]=C_h_intern(&lf[206],48, C_text("chicken.compiler.support#emit-global-inline-file"));
lf[207]=C_decode_literal(C_heaptop,C_text("\376B\000\000&generating global inline file `~a\047 ..."));
lf[208]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011optimized"));
lf[209]=C_h_intern(&lf[209],1, C_text("7"));
lf[210]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010unboxing"));
lf[211]=C_h_intern(&lf[211],38, C_text("chicken.compiler.lfa2#perform-unboxing"));
lf[212]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016doing unboxing"));
lf[213]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027secondary flow analysis"));
lf[214]=C_h_intern(&lf[214],53, C_text("chicken.compiler.lfa2#perform-secondary-flow-analysis"));
lf[215]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012doing lfa2"));
lf[216]=C_h_intern(&lf[216],1, C_text("s"));
lf[217]=C_h_intern(&lf[217],49, C_text("chicken.compiler.core#compute-database-statistics"));
lf[218]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027;   database entries: \011"));
lf[219]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027;   known call sites: \011"));
lf[220]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027;   global variables: \011"));
lf[221]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027;   known procedures: \011"));
lf[222]=C_decode_literal(C_heaptop,C_text("\376B\000\000\042;   variables with known values: \011"));
lf[223]=C_decode_literal(C_heaptop,C_text("\376B\000\000\032 \011original program size: \011"));
lf[224]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023;   program size: \011"));
lf[225]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023program statistics:"));
lf[226]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010analysis"));
lf[227]=C_h_intern(&lf[227],1, C_text("4"));
lf[228]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010analysis"));
lf[229]=C_h_intern(&lf[229],44, C_text("chicken.compiler.scrutinizer#emit-types-file"));
lf[230]=C_decode_literal(C_heaptop,C_text("\376B\000\000\035generating type file `~a\047 ..."));
lf[231]=C_h_intern(&lf[231],1, C_text("v"));
lf[232]=C_h_intern(&lf[232],41, C_text("chicken.compiler.support#dump-global-refs"));
lf[233]=C_h_intern(&lf[233],1, C_text("d"));
lf[234]=C_h_intern(&lf[234],45, C_text("chicken.compiler.support#dump-defined-globals"));
lf[235]=C_h_intern(&lf[235],1, C_text("u"));
lf[236]=C_h_intern(&lf[236],47, C_text("chicken.compiler.support#dump-undefined-globals"));
lf[237]=C_h_intern(&lf[237],3, C_text("opt"));
lf[238]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003cps"));
lf[239]=C_h_intern(&lf[239],1, C_text("3"));
lf[240]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016cps conversion"));
lf[241]=C_h_intern(&lf[241],44, C_text("chicken.compiler.core#perform-cps-conversion"));
lf[242]=C_h_intern(&lf[242],31, C_text("chicken.compiler.support#unsafe"));
lf[243]=C_h_intern(&lf[243],52, C_text("chicken.compiler.optimizer#scan-toplevel-assignments"));
lf[244]=C_h_intern(&lf[244],44, C_text("chicken.compiler.support#node-subexpressions"));
lf[245]=C_decode_literal(C_heaptop,C_text("\376B\000\000\016specialization"));
lf[246]=C_h_intern(&lf[246],1, C_text("P"));
lf[247]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010scrutiny"));
lf[248]=C_h_intern(&lf[248],39, C_text("chicken.compiler.scrutinizer#scrutinize"));
lf[249]=C_h_intern(&lf[249],43, C_text("chicken.compiler.core#strict-variable-types"));
lf[250]=C_decode_literal(C_heaptop,C_text("\376B\000\000\023performing scrutiny"));
lf[251]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027pre-analysis (scrutiny)"));
lf[252]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010analysis"));
lf[253]=C_h_intern(&lf[253],1, C_text("0"));
lf[254]=C_h_intern(&lf[254],8, C_text("scrutiny"));
lf[255]=C_h_intern(&lf[255],47, C_text("chicken.compiler.scrutinizer#load-type-database"));
lf[256]=C_h_intern(&lf[256],30, C_text("chicken.pathname#make-pathname"));
lf[257]=C_decode_literal(C_heaptop,C_text("\376B\000\000\005types"));
lf[258]=C_h_intern(&lf[258],21, C_text("scheme#symbol->string"));
lf[259]=C_decode_literal(C_heaptop,C_text("\376B\000\000\034type-database `~a\047 not found"));
lf[260]=C_h_intern(&lf[260],18, C_text("consult-types-file"));
lf[261]=C_h_intern(&lf[261],17, C_text("ignore-repository"));
lf[262]=C_decode_literal(C_heaptop,C_text("\376B\000\000\052default type-database `types.db\047 not found"));
lf[263]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010types.db"));
lf[264]=C_h_intern(&lf[264],41, C_text("chicken.compiler.support#load-inline-file"));
lf[265]=C_decode_literal(C_heaptop,C_text("\376B\000\000\032Loading inline file ~a ..."));
lf[266]=C_h_intern(&lf[266],19, C_text("consult-inline-file"));
lf[267]=C_h_intern(&lf[267],41, C_text("chicken.compiler.core#enable-inline-files"));
lf[268]=C_decode_literal(C_heaptop,C_text("\376B\000\000\032Loading inline file ~a ..."));
lf[269]=C_h_intern(&lf[269],30, C_text("##sys#resolve-include-filename"));
lf[270]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376B\000\000\007.inline\376\377\016"));
lf[271]=C_h_intern(&lf[271],1, C_text("M"));
lf[272]=C_decode_literal(C_heaptop,C_text("\376B\000\000\017; requirements:"));
lf[273]=C_h_intern(&lf[273],19, C_text("scheme#vector->list"));
lf[274]=C_h_intern(&lf[274],39, C_text("chicken.compiler.core#file-requirements"));
lf[275]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021initial node tree"));
lf[276]=C_h_intern(&lf[276],1, C_text("T"));
lf[277]=C_h_intern(&lf[277],46, C_text("chicken.compiler.core#build-toplevel-procedure"));
lf[278]=C_h_intern(&lf[278],41, C_text("chicken.compiler.support#build-node-graph"));
lf[279]=C_h_intern(&lf[279],48, C_text("chicken.compiler.support#canonicalize-begin-body"));
lf[280]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011user pass"));
lf[281]=C_decode_literal(C_heaptop,C_text("\376B\000\000\014User pass..."));
lf[282]=C_h_intern(&lf[282],36, C_text("chicken.compiler.user-pass#user-pass"));
lf[283]=C_h_intern(&lf[283],12, C_text("check-syntax"));
lf[284]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015canonicalized"));
lf[285]=C_h_intern(&lf[285],1, C_text("2"));
lf[286]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020canonicalization"));
lf[287]=C_h_intern(&lf[287],53, C_text("chicken.compiler.support#display-line-number-database"));
lf[288]=C_h_intern(&lf[288],1, C_text("n"));
lf[289]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025line number database:"));
lf[290]=C_h_intern(&lf[290],48, C_text("chicken.compiler.support#display-real-name-table"));
lf[291]=C_h_intern(&lf[291],1, C_text("N"));
lf[292]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020real name table:"));
lf[293]=C_h_intern(&lf[293],59, C_text("chicken.compiler.compiler-syntax#compiler-syntax-statistics"));
lf[294]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002\011\011"));
lf[295]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002  "));
lf[296]=C_h_intern(&lf[296],18, C_text("chicken.base#print"));
lf[297]=C_decode_literal(C_heaptop,C_text("\376B\000\000\030applied compiler syntax:"));
lf[298]=C_h_intern(&lf[298],46, C_text("chicken.compiler.support#with-debugging-output"));
lf[299]=C_h_intern(&lf[299],1, C_text("S"));
lf[300]=C_h_intern(&lf[300],6, C_text("format"));
lf[301]=C_h_intern(&lf[301],20, C_text("chicken.base#warning"));
lf[302]=C_h_intern(&lf[302],30, C_text("chicken.base#get-output-string"));
lf[303]=C_h_intern(&lf[303],23, C_text("chicken.string#->string"));
lf[304]=C_h_intern(&lf[304],33, C_text("chicken.string#string-intersperse"));
lf[305]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002, "));
lf[306]=C_decode_literal(C_heaptop,C_text("\376B\000\0006the following extensions are not currently installed: "));
lf[307]=C_h_intern(&lf[307],31, C_text("chicken.base#open-output-string"));
lf[308]=C_h_intern(&lf[308],19, C_text("chicken.base#notice"));
lf[309]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002, "));
lf[310]=C_decode_literal(C_heaptop,C_text("\376B\000\000; has dynamic requirements but doesn\047t load (chicken eval): "));
lf[311]=C_h_intern(&lf[311],31, C_text("chicken.compiler.core#unit-name"));
lf[312]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004unit"));
lf[313]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007library"));
lf[314]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007program"));
lf[315]=C_h_intern(&lf[315],32, C_text("chicken.compiler.core#used-units"));
lf[316]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\004\001eval\376\003\000\000\002\376\001\000\000\004\001repl\376\377\016"));
lf[317]=C_h_intern(&lf[317],35, C_text("chicken.load#find-dynamic-extension"));
lf[318]=C_h_intern(&lf[318],31, C_text("chicken.internal#hash-table-ref"));
lf[319]=C_decode_literal(C_heaptop,C_text("\376B\000\000;No module definition found for import libraries to emit: ~A"));
lf[320]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002, "));
lf[321]=C_h_intern(&lf[321],41, C_text("chicken.compiler.core#immutable-constants"));
lf[322]=C_h_intern(&lf[322],43, C_text("chicken.compiler.core#standalone-executable"));
lf[323]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020\001##core#undefined\376\377\016\376\377\016"));
lf[324]=C_h_intern(&lf[324],34, C_text("chicken.compiler.core#emit-profile"));
lf[325]=C_h_intern(&lf[325],47, C_text("chicken.compiler.support#profiling-prelude-exps"));
lf[326]=C_h_intern(&lf[326],14, C_text("##core#provide"));
lf[327]=C_h_intern(&lf[327],15, C_text("##core#callunit"));
lf[328]=C_h_intern(&lf[328],5, C_text("quote"));
lf[329]=C_h_intern(&lf[329],4, C_text("set!"));
lf[330]=C_h_intern(&lf[330],13, C_text("##core#module"));
lf[331]=C_h_intern(&lf[331],21, C_text("scheme#string->symbol"));
lf[332]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006source"));
lf[333]=C_h_intern(&lf[333],1, C_text("1"));
lf[334]=C_decode_literal(C_heaptop,C_text("\376B\000\000\032User preprocessing pass..."));
lf[335]=C_h_intern(&lf[335],49, C_text("chicken.compiler.user-pass#user-preprocessor-pass"));
lf[336]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021User read pass..."));
lf[337]=C_h_intern(&lf[337],37, C_text("chicken.compiler.support#string->expr"));
lf[338]=C_h_intern(&lf[338],14, C_text("scheme#reverse"));
lf[339]=C_h_intern(&lf[339],49, C_text("chicken.compiler.support#close-checked-input-file"));
lf[340]=C_h_intern(&lf[340],41, C_text("chicken.compiler.support#read/source-info"));
lf[341]=C_h_intern(&lf[341],50, C_text("chicken.compiler.support#check-and-open-input-file"));
lf[342]=C_h_intern(&lf[342],41, C_text("chicken.compiler.user-pass#user-read-pass"));
lf[343]=C_h_intern(&lf[343],8, C_text("epilogue"));
lf[344]=C_h_intern(&lf[344],8, C_text("prologue"));
lf[345]=C_h_intern(&lf[345],8, C_text("postlude"));
lf[346]=C_h_intern(&lf[346],7, C_text("prelude"));
lf[347]=C_h_intern(&lf[347],18, C_text("scheme#make-vector"));
lf[348]=C_h_intern(&lf[348],47, C_text("chicken.compiler.core#line-number-database-size"));
lf[349]=C_h_intern(&lf[349],1, C_text("r"));
lf[350]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021target stack size"));
lf[351]=C_decode_literal(C_heaptop,C_text("\376B\000\000\020target heap size"));
lf[352]=C_decode_literal(C_heaptop,C_text("\376B\000\000\021debugging options"));
lf[353]=C_decode_literal(C_heaptop,C_text("\376B\000\000\007options"));
lf[354]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022compiling `~a\047 ..."));
lf[355]=C_h_intern(&lf[355],5, C_text("-help"));
lf[356]=C_h_intern(&lf[356],1, C_text("h"));
lf[357]=C_h_intern(&lf[357],2, C_text("-h"));
lf[358]=C_h_intern(&lf[358],49, C_text("chicken.compiler.support#load-identifier-database"));
lf[359]=C_decode_literal(C_heaptop,C_text("\376B\000\000\012modules.db"));
lf[360]=C_h_intern(&lf[360],18, C_text("accumulate-profile"));
lf[361]=C_h_intern(&lf[361],41, C_text("chicken.compiler.core#profiled-procedures"));
lf[362]=C_h_intern(&lf[362],3, C_text("all"));
lf[363]=C_decode_literal(C_heaptop,C_text("\376B\000\000\015accumulative "));
lf[364]=C_decode_literal(C_heaptop,C_text("\376B\000\000\032generating ~aprofiled code"));
lf[365]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[366]=C_h_intern(&lf[366],58, C_text("chicken.compiler.c-platform#default-profiling-declarations"));
lf[367]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001set!\376\003\000\000\002\376\001\000\000\031\001##sys#profile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016"));
lf[368]=C_decode_literal(C_heaptop,C_text("\376B\000\000Eyou need to specify -profile-name if using accumulated profiling runs"));
lf[369]=C_decode_literal(C_heaptop,C_text("\376B\000\000\011calltrace"));
lf[370]=C_decode_literal(C_heaptop,C_text("\376B\000\000\022debugging info: ~A"));
lf[371]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004none"));
lf[372]=C_h_intern(&lf[372],21, C_text("no-usual-integrations"));
lf[373]=C_h_intern(&lf[373],1, C_text("m"));
lf[374]=C_h_intern(&lf[374],25, C_text("chicken.gc#set-gc-report!"));
lf[375]=C_h_intern(&lf[375],25, C_text("chicken.platform#feature\077"));
lf[376]=C_h_intern_kw(&lf[376],17, C_text("chicken-bootstrap"));
lf[377]=C_h_intern(&lf[377],14, C_text("compile-syntax"));
lf[378]=C_h_intern(&lf[378],27, C_text("##sys#enable-runtime-macros"));
lf[379]=C_h_intern(&lf[379],6, C_text("import"));
lf[380]=C_h_intern(&lf[380],17, C_text("require-extension"));
lf[381]=C_h_intern(&lf[381],4, C_text("uses"));
lf[382]=C_h_intern(&lf[382],14, C_text("##core#declare"));
lf[383]=C_h_intern(&lf[383],27, C_text("chicken.string#string-split"));
lf[384]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002, "));
lf[385]=C_h_intern(&lf[385],50, C_text("chicken.compiler.user-pass#user-post-analysis-pass"));
lf[386]=C_h_intern(&lf[386],11, C_text("scheme#load"));
lf[387]=C_decode_literal(C_heaptop,C_text("\376B\000\000\031cannot load extension: ~a"));
lf[388]=C_decode_literal(C_heaptop,C_text("\376B\000\000\036Loading compiler extensions..."));
lf[389]=C_h_intern(&lf[389],6, C_text("extend"));
lf[390]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001,"));
lf[391]=C_h_intern(&lf[391],10, C_text("no-feature"));
lf[392]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002, "));
lf[393]=C_h_intern(&lf[393],7, C_text("feature"));
lf[394]=C_h_intern(&lf[394],25, C_text("chicken.load#load-verbose"));
lf[395]=C_h_intern(&lf[395],38, C_text("no-procedure-checks-for-usual-bindings"));
lf[396]=C_h_intern(&lf[396],23, C_text("##compiler#always-bound"));
lf[397]=C_h_intern(&lf[397],36, C_text("##compiler#always-bound-to-procedure"));
lf[398]=C_h_intern(&lf[398],41, C_text("no-procedure-checks-for-toplevel-bindings"));
lf[399]=C_h_intern(&lf[399],48, C_text("chicken.compiler.core#no-global-procedure-checks"));
lf[400]=C_h_intern(&lf[400],19, C_text("no-procedure-checks"));
lf[401]=C_h_intern(&lf[401],41, C_text("chicken.compiler.core#no-procedure-checks"));
lf[402]=C_h_intern(&lf[402],15, C_text("no-bound-checks"));
lf[403]=C_h_intern(&lf[403],37, C_text("chicken.compiler.core#no-bound-checks"));
lf[404]=C_h_intern(&lf[404],14, C_text("no-argc-checks"));
lf[405]=C_h_intern(&lf[405],36, C_text("chicken.compiler.core#no-argc-checks"));
lf[406]=C_h_intern(&lf[406],20, C_text("keep-shadowed-macros"));
lf[407]=C_h_intern(&lf[407],46, C_text("chicken.compiler.core#undefine-shadowed-macros"));
lf[408]=C_decode_literal(C_heaptop,C_text("\376B\000\000(source- and output-filename are the same"));
lf[409]=C_h_intern(&lf[409],12, C_text("include-path"));
lf[410]=C_h_intern(&lf[410],11, C_text("r5rs-syntax"));
lf[411]=C_h_intern(&lf[411],26, C_text("chicken.base#symbol-escape"));
lf[412]=C_h_intern(&lf[412],33, C_text("chicken.base#parentheses-synonyms"));
lf[413]=C_h_intern(&lf[413],26, C_text("chicken.base#keyword-style"));
lf[414]=C_h_intern_kw(&lf[414],4, C_text("none"));
lf[415]=C_h_intern(&lf[415],27, C_text("chicken.base#case-sensitive"));
lf[416]=C_decode_literal(C_heaptop,C_text("\376B\000\000.Disabled the CHICKEN extensions to R5RS syntax"));
lf[417]=C_h_intern(&lf[417],16, C_text("no-symbol-escape"));
lf[418]=C_decode_literal(C_heaptop,C_text("\376B\000\000$Disabled support for escaped symbols"));
lf[419]=C_h_intern(&lf[419],23, C_text("no-parentheses-synonyms"));
lf[420]=C_decode_literal(C_heaptop,C_text("\376B\000\000)Disabled support for parentheses synonyms"));
lf[421]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006prefix"));
lf[422]=C_h_intern_kw(&lf[422],6, C_text("prefix"));
lf[423]=C_decode_literal(C_heaptop,C_text("\376B\000\000\004none"));
lf[424]=C_decode_literal(C_heaptop,C_text("\376B\000\000\006suffix"));
lf[425]=C_h_intern_kw(&lf[425],6, C_text("suffix"));
lf[426]=C_decode_literal(C_heaptop,C_text("\376B\000\000+invalid argument to `-keyword-style\047 option"));
lf[427]=C_h_intern(&lf[427],16, C_text("case-insensitive"));
lf[428]=C_decode_literal(C_heaptop,C_text("\376B\000\000,Identifiers and symbols are case insensitive"));
lf[429]=C_decode_literal(C_heaptop,C_text("\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047"));
lf[430]=C_h_intern(&lf[430],39, C_text("chicken.compiler.core#local-definitions"));
lf[431]=C_h_intern(&lf[431],6, C_text("inline"));
lf[432]=C_h_intern(&lf[432],30, C_text("emit-external-prototypes-first"));
lf[433]=C_h_intern(&lf[433],43, C_text("chicken.compiler.core#external-protos-first"));
lf[434]=C_h_intern(&lf[434],5, C_text("block"));
lf[435]=C_h_intern(&lf[435],17, C_text("fixnum-arithmetic"));
lf[436]=C_h_intern(&lf[436],36, C_text("chicken.compiler.support#number-type"));
lf[437]=C_h_intern(&lf[437],6, C_text("fixnum"));
lf[438]=C_h_intern(&lf[438],18, C_text("disable-interrupts"));
lf[439]=C_h_intern(&lf[439],27, C_text("regenerate-import-libraries"));
lf[440]=C_h_intern(&lf[440],57, C_text("chicken.compiler.core#preserve-unchanged-import-libraries"));
lf[441]=C_h_intern(&lf[441],10, C_text("setup-mode"));
lf[442]=C_h_intern(&lf[442],16, C_text("##sys#setup-mode"));
lf[443]=C_h_intern(&lf[443],6, C_text("unsafe"));
lf[444]=C_h_intern(&lf[444],22, C_text("optimize-leaf-routines"));
lf[445]=C_h_intern(&lf[445],11, C_text("no-warnings"));
lf[446]=C_decode_literal(C_heaptop,C_text("\376B\000\000\025Warnings are disabled"));
lf[447]=C_h_intern(&lf[447],12, C_text("strict-types"));
lf[448]=C_h_intern(&lf[448],21, C_text("##sys#notices-enabled"));
lf[449]=C_h_intern(&lf[449],13, C_text("inline-global"));
lf[450]=C_h_intern(&lf[450],5, C_text("local"));
lf[451]=C_h_intern(&lf[451],18, C_text("no-compiler-syntax"));
lf[452]=C_h_intern(&lf[452],45, C_text("chicken.compiler.core#compiler-syntax-enabled"));
lf[453]=C_h_intern(&lf[453],14, C_text("no-lambda-info"));
lf[454]=C_h_intern(&lf[454],39, C_text("chicken.compiler.core#emit-closure-info"));
lf[455]=C_h_intern(&lf[455],3, C_text("raw"));
lf[456]=C_h_intern(&lf[456],1, C_text("b"));
lf[457]=C_h_intern(&lf[457],17, C_text("##sys#start-timer"));
lf[458]=C_h_intern(&lf[458],25, C_text("emit-all-import-libraries"));
lf[459]=C_h_intern(&lf[459],42, C_text("chicken.compiler.core#all-import-libraries"));
lf[460]=C_h_intern(&lf[460],19, C_text("##sys#string-append"));
lf[461]=C_decode_literal(C_heaptop,C_text("\376B\000\000\013.import.scm"));
lf[462]=C_h_intern(&lf[462],19, C_text("emit-import-library"));
lf[463]=C_h_intern(&lf[463],44, C_text("chicken.compiler.support#print-debug-options"));
lf[464]=C_h_intern(&lf[464],18, C_text("##sys#string->list"));
lf[465]=C_h_intern(&lf[465],5, C_text("debug"));
lf[466]=C_h_intern(&lf[466],20, C_text("##sys#dload-disabled"));
lf[467]=C_h_intern(&lf[467],32, C_text("chicken.platform#repository-path"));
lf[468]=C_h_intern(&lf[468],10, C_text("stack-size"));
lf[469]=C_h_intern(&lf[469],54, C_text("chicken.compiler.optimizer#default-optimization-passes"));
lf[470]=C_h_intern(&lf[470],16, C_text("##sys#split-path"));
lf[471]=C_decode_literal(C_heaptop,C_text("\376B\000\000\000"));
lf[472]=C_h_intern(&lf[472],48, C_text("chicken.process-context#get-environment-variable"));
lf[473]=C_decode_literal(C_heaptop,C_text("\376B\000\000\024CHICKEN_INCLUDE_PATH"));
lf[474]=C_h_intern(&lf[474],9, C_text("to-stdout"));
lf[475]=C_decode_literal(C_heaptop,C_text("\376B\000\000\001c"));
lf[476]=C_h_intern(&lf[476],30, C_text("chicken.pathname#pathname-file"));
lf[477]=C_decode_literal(C_heaptop,C_text("\376B\000\000\003out"));
lf[478]=C_h_intern(&lf[478],32, C_text("chicken.internal#default-imports"));
lf[479]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001uses\376\003\000\000\002\376\001\000\000\017\001debugger-client\376\377\016\376\377\016"));
lf[480]=C_h_intern(&lf[480],48, C_text("chicken.compiler.c-platform#default-declarations"));
lf[481]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004\001uses\376\003\000\000\002\376\001\000\000\014\001eval-modules\376\377\016\376\377\016"));
lf[482]=C_h_intern(&lf[482],39, C_text("chicken.compiler.core#static-extensions"));
lf[483]=C_h_intern(&lf[483],41, C_text("chicken.compiler.c-platform#default-units"));
lf[484]=C_h_intern(&lf[484],6, C_text("static"));
lf[485]=C_h_intern(&lf[485],22, C_text("chicken-compile-static"));
lf[486]=C_h_intern(&lf[486],41, C_text("chicken.compiler.core#initialize-compiler"));
C_register_lf2(lf,487,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2669,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[563] = {
{C_text("f8625:batch_2ddriver_2escm"),(void*)f8625},
{C_text("f9103:batch_2ddriver_2escm"),(void*)f9103},
{C_text("f9109:batch_2ddriver_2escm"),(void*)f9109},
{C_text("f9115:batch_2ddriver_2escm"),(void*)f9115},
{C_text("f9121:batch_2ddriver_2escm"),(void*)f9121},
{C_text("f9127:batch_2ddriver_2escm"),(void*)f9127},
{C_text("f9133:batch_2ddriver_2escm"),(void*)f9133},
{C_text("f9145:batch_2ddriver_2escm"),(void*)f9145},
{C_text("f9153:batch_2ddriver_2escm"),(void*)f9153},
{C_text("f9165:batch_2ddriver_2escm"),(void*)f9165},
{C_text("f9189:batch_2ddriver_2escm"),(void*)f9189},
{C_text("f9195:batch_2ddriver_2escm"),(void*)f9195},
{C_text("f9209:batch_2ddriver_2escm"),(void*)f9209},
{C_text("f9215:batch_2ddriver_2escm"),(void*)f9215},
{C_text("f9221:batch_2ddriver_2escm"),(void*)f9221},
{C_text("f9227:batch_2ddriver_2escm"),(void*)f9227},
{C_text("f9233:batch_2ddriver_2escm"),(void*)f9233},
{C_text("f9247:batch_2ddriver_2escm"),(void*)f9247},
{C_text("f9263:batch_2ddriver_2escm"),(void*)f9263},
{C_text("f9269:batch_2ddriver_2escm"),(void*)f9269},
{C_text("f9275:batch_2ddriver_2escm"),(void*)f9275},
{C_text("f9281:batch_2ddriver_2escm"),(void*)f9281},
{C_text("f9287:batch_2ddriver_2escm"),(void*)f9287},
{C_text("f_2669:batch_2ddriver_2escm"),(void*)f_2669},
{C_text("f_2672:batch_2ddriver_2escm"),(void*)f_2672},
{C_text("f_2675:batch_2ddriver_2escm"),(void*)f_2675},
{C_text("f_2678:batch_2ddriver_2escm"),(void*)f_2678},
{C_text("f_2681:batch_2ddriver_2escm"),(void*)f_2681},
{C_text("f_2684:batch_2ddriver_2escm"),(void*)f_2684},
{C_text("f_2687:batch_2ddriver_2escm"),(void*)f_2687},
{C_text("f_2690:batch_2ddriver_2escm"),(void*)f_2690},
{C_text("f_2693:batch_2ddriver_2escm"),(void*)f_2693},
{C_text("f_2696:batch_2ddriver_2escm"),(void*)f_2696},
{C_text("f_2699:batch_2ddriver_2escm"),(void*)f_2699},
{C_text("f_2702:batch_2ddriver_2escm"),(void*)f_2702},
{C_text("f_2705:batch_2ddriver_2escm"),(void*)f_2705},
{C_text("f_2708:batch_2ddriver_2escm"),(void*)f_2708},
{C_text("f_2711:batch_2ddriver_2escm"),(void*)f_2711},
{C_text("f_2714:batch_2ddriver_2escm"),(void*)f_2714},
{C_text("f_2915:batch_2ddriver_2escm"),(void*)f_2915},
{C_text("f_2930:batch_2ddriver_2escm"),(void*)f_2930},
{C_text("f_2938:batch_2ddriver_2escm"),(void*)f_2938},
{C_text("f_2946:batch_2ddriver_2escm"),(void*)f_2946},
{C_text("f_2957:batch_2ddriver_2escm"),(void*)f_2957},
{C_text("f_2970:batch_2ddriver_2escm"),(void*)f_2970},
{C_text("f_2984:batch_2ddriver_2escm"),(void*)f_2984},
{C_text("f_2988:batch_2ddriver_2escm"),(void*)f_2988},
{C_text("f_3000:batch_2ddriver_2escm"),(void*)f_3000},
{C_text("f_3002:batch_2ddriver_2escm"),(void*)f_3002},
{C_text("f_3049:batch_2ddriver_2escm"),(void*)f_3049},
{C_text("f_3051:batch_2ddriver_2escm"),(void*)f_3051},
{C_text("f_3091:batch_2ddriver_2escm"),(void*)f_3091},
{C_text("f_3113:batch_2ddriver_2escm"),(void*)f_3113},
{C_text("f_3125:batch_2ddriver_2escm"),(void*)f_3125},
{C_text("f_3177:batch_2ddriver_2escm"),(void*)f_3177},
{C_text("f_3183:batch_2ddriver_2escm"),(void*)f_3183},
{C_text("f_3201:batch_2ddriver_2escm"),(void*)f_3201},
{C_text("f_3211:batch_2ddriver_2escm"),(void*)f_3211},
{C_text("f_3238:batch_2ddriver_2escm"),(void*)f_3238},
{C_text("f_3325:batch_2ddriver_2escm"),(void*)f_3325},
{C_text("f_3334:batch_2ddriver_2escm"),(void*)f_3334},
{C_text("f_3342:batch_2ddriver_2escm"),(void*)f_3342},
{C_text("f_3349:batch_2ddriver_2escm"),(void*)f_3349},
{C_text("f_3363:batch_2ddriver_2escm"),(void*)f_3363},
{C_text("f_3424:batch_2ddriver_2escm"),(void*)f_3424},
{C_text("f_3432:batch_2ddriver_2escm"),(void*)f_3432},
{C_text("f_3715:batch_2ddriver_2escm"),(void*)f_3715},
{C_text("f_3721:batch_2ddriver_2escm"),(void*)f_3721},
{C_text("f_4000:batch_2ddriver_2escm"),(void*)f_4000},
{C_text("f_4006:batch_2ddriver_2escm"),(void*)f_4006},
{C_text("f_4013:batch_2ddriver_2escm"),(void*)f_4013},
{C_text("f_4019:batch_2ddriver_2escm"),(void*)f_4019},
{C_text("f_4022:batch_2ddriver_2escm"),(void*)f_4022},
{C_text("f_4025:batch_2ddriver_2escm"),(void*)f_4025},
{C_text("f_4028:batch_2ddriver_2escm"),(void*)f_4028},
{C_text("f_4031:batch_2ddriver_2escm"),(void*)f_4031},
{C_text("f_4037:batch_2ddriver_2escm"),(void*)f_4037},
{C_text("f_4040:batch_2ddriver_2escm"),(void*)f_4040},
{C_text("f_4043:batch_2ddriver_2escm"),(void*)f_4043},
{C_text("f_4049:batch_2ddriver_2escm"),(void*)f_4049},
{C_text("f_4052:batch_2ddriver_2escm"),(void*)f_4052},
{C_text("f_4055:batch_2ddriver_2escm"),(void*)f_4055},
{C_text("f_4061:batch_2ddriver_2escm"),(void*)f_4061},
{C_text("f_4064:batch_2ddriver_2escm"),(void*)f_4064},
{C_text("f_4067:batch_2ddriver_2escm"),(void*)f_4067},
{C_text("f_4073:batch_2ddriver_2escm"),(void*)f_4073},
{C_text("f_4076:batch_2ddriver_2escm"),(void*)f_4076},
{C_text("f_4079:batch_2ddriver_2escm"),(void*)f_4079},
{C_text("f_4085:batch_2ddriver_2escm"),(void*)f_4085},
{C_text("f_4088:batch_2ddriver_2escm"),(void*)f_4088},
{C_text("f_4093:batch_2ddriver_2escm"),(void*)f_4093},
{C_text("f_4097:batch_2ddriver_2escm"),(void*)f_4097},
{C_text("f_4109:batch_2ddriver_2escm"),(void*)f_4109},
{C_text("f_4120:batch_2ddriver_2escm"),(void*)f_4120},
{C_text("f_4133:batch_2ddriver_2escm"),(void*)f_4133},
{C_text("f_4143:batch_2ddriver_2escm"),(void*)f_4143},
{C_text("f_4156:batch_2ddriver_2escm"),(void*)f_4156},
{C_text("f_4166:batch_2ddriver_2escm"),(void*)f_4166},
{C_text("f_4179:batch_2ddriver_2escm"),(void*)f_4179},
{C_text("f_4189:batch_2ddriver_2escm"),(void*)f_4189},
{C_text("f_4202:batch_2ddriver_2escm"),(void*)f_4202},
{C_text("f_4206:batch_2ddriver_2escm"),(void*)f_4206},
{C_text("f_4211:batch_2ddriver_2escm"),(void*)f_4211},
{C_text("f_4221:batch_2ddriver_2escm"),(void*)f_4221},
{C_text("f_4224:batch_2ddriver_2escm"),(void*)f_4224},
{C_text("f_4227:batch_2ddriver_2escm"),(void*)f_4227},
{C_text("f_4230:batch_2ddriver_2escm"),(void*)f_4230},
{C_text("f_4233:batch_2ddriver_2escm"),(void*)f_4233},
{C_text("f_4236:batch_2ddriver_2escm"),(void*)f_4236},
{C_text("f_4250:batch_2ddriver_2escm"),(void*)f_4250},
{C_text("f_4261:batch_2ddriver_2escm"),(void*)f_4261},
{C_text("f_4265:batch_2ddriver_2escm"),(void*)f_4265},
{C_text("f_4273:batch_2ddriver_2escm"),(void*)f_4273},
{C_text("f_4283:batch_2ddriver_2escm"),(void*)f_4283},
{C_text("f_4297:batch_2ddriver_2escm"),(void*)f_4297},
{C_text("f_4303:batch_2ddriver_2escm"),(void*)f_4303},
{C_text("f_4314:batch_2ddriver_2escm"),(void*)f_4314},
{C_text("f_4318:batch_2ddriver_2escm"),(void*)f_4318},
{C_text("f_4324:batch_2ddriver_2escm"),(void*)f_4324},
{C_text("f_4330:batch_2ddriver_2escm"),(void*)f_4330},
{C_text("f_4341:batch_2ddriver_2escm"),(void*)f_4341},
{C_text("f_4345:batch_2ddriver_2escm"),(void*)f_4345},
{C_text("f_4368:batch_2ddriver_2escm"),(void*)f_4368},
{C_text("f_4384:batch_2ddriver_2escm"),(void*)f_4384},
{C_text("f_4393:batch_2ddriver_2escm"),(void*)f_4393},
{C_text("f_4406:batch_2ddriver_2escm"),(void*)f_4406},
{C_text("f_4417:batch_2ddriver_2escm"),(void*)f_4417},
{C_text("f_4423:batch_2ddriver_2escm"),(void*)f_4423},
{C_text("f_4496:batch_2ddriver_2escm"),(void*)f_4496},
{C_text("f_4502:batch_2ddriver_2escm"),(void*)f_4502},
{C_text("f_4505:batch_2ddriver_2escm"),(void*)f_4505},
{C_text("f_4508:batch_2ddriver_2escm"),(void*)f_4508},
{C_text("f_4782:batch_2ddriver_2escm"),(void*)f_4782},
{C_text("f_4784:batch_2ddriver_2escm"),(void*)f_4784},
{C_text("f_4787:batch_2ddriver_2escm"),(void*)f_4787},
{C_text("f_4818:batch_2ddriver_2escm"),(void*)f_4818},
{C_text("f_4831:batch_2ddriver_2escm"),(void*)f_4831},
{C_text("f_4845:batch_2ddriver_2escm"),(void*)f_4845},
{C_text("f_4851:batch_2ddriver_2escm"),(void*)f_4851},
{C_text("f_4857:batch_2ddriver_2escm"),(void*)f_4857},
{C_text("f_4860:batch_2ddriver_2escm"),(void*)f_4860},
{C_text("f_4865:batch_2ddriver_2escm"),(void*)f_4865},
{C_text("f_4885:batch_2ddriver_2escm"),(void*)f_4885},
{C_text("f_4890:batch_2ddriver_2escm"),(void*)f_4890},
{C_text("f_4908:batch_2ddriver_2escm"),(void*)f_4908},
{C_text("f_4912:batch_2ddriver_2escm"),(void*)f_4912},
{C_text("f_4924:batch_2ddriver_2escm"),(void*)f_4924},
{C_text("f_4927:batch_2ddriver_2escm"),(void*)f_4927},
{C_text("f_4930:batch_2ddriver_2escm"),(void*)f_4930},
{C_text("f_4933:batch_2ddriver_2escm"),(void*)f_4933},
{C_text("f_4935:batch_2ddriver_2escm"),(void*)f_4935},
{C_text("f_4942:batch_2ddriver_2escm"),(void*)f_4942},
{C_text("f_4955:batch_2ddriver_2escm"),(void*)f_4955},
{C_text("f_4957:batch_2ddriver_2escm"),(void*)f_4957},
{C_text("f_4964:batch_2ddriver_2escm"),(void*)f_4964},
{C_text("f_4970:batch_2ddriver_2escm"),(void*)f_4970},
{C_text("f_4973:batch_2ddriver_2escm"),(void*)f_4973},
{C_text("f_4976:batch_2ddriver_2escm"),(void*)f_4976},
{C_text("f_4979:batch_2ddriver_2escm"),(void*)f_4979},
{C_text("f_4984:batch_2ddriver_2escm"),(void*)f_4984},
{C_text("f_4991:batch_2ddriver_2escm"),(void*)f_4991},
{C_text("f_4996:batch_2ddriver_2escm"),(void*)f_4996},
{C_text("f_5007:batch_2ddriver_2escm"),(void*)f_5007},
{C_text("f_5017:batch_2ddriver_2escm"),(void*)f_5017},
{C_text("f_5030:batch_2ddriver_2escm"),(void*)f_5030},
{C_text("f_5039:batch_2ddriver_2escm"),(void*)f_5039},
{C_text("f_5070:batch_2ddriver_2escm"),(void*)f_5070},
{C_text("f_5074:batch_2ddriver_2escm"),(void*)f_5074},
{C_text("f_5090:batch_2ddriver_2escm"),(void*)f_5090},
{C_text("f_5094:batch_2ddriver_2escm"),(void*)f_5094},
{C_text("f_5115:batch_2ddriver_2escm"),(void*)f_5115},
{C_text("f_5121:batch_2ddriver_2escm"),(void*)f_5121},
{C_text("f_5129:batch_2ddriver_2escm"),(void*)f_5129},
{C_text("f_5137:batch_2ddriver_2escm"),(void*)f_5137},
{C_text("f_5141:batch_2ddriver_2escm"),(void*)f_5141},
{C_text("f_5150:batch_2ddriver_2escm"),(void*)f_5150},
{C_text("f_5158:batch_2ddriver_2escm"),(void*)f_5158},
{C_text("f_5160:batch_2ddriver_2escm"),(void*)f_5160},
{C_text("f_5170:batch_2ddriver_2escm"),(void*)f_5170},
{C_text("f_5173:batch_2ddriver_2escm"),(void*)f_5173},
{C_text("f_5176:batch_2ddriver_2escm"),(void*)f_5176},
{C_text("f_5179:batch_2ddriver_2escm"),(void*)f_5179},
{C_text("f_5186:batch_2ddriver_2escm"),(void*)f_5186},
{C_text("f_5190:batch_2ddriver_2escm"),(void*)f_5190},
{C_text("f_5198:batch_2ddriver_2escm"),(void*)f_5198},
{C_text("f_5200:batch_2ddriver_2escm"),(void*)f_5200},
{C_text("f_5202:batch_2ddriver_2escm"),(void*)f_5202},
{C_text("f_5206:batch_2ddriver_2escm"),(void*)f_5206},
{C_text("f_5209:batch_2ddriver_2escm"),(void*)f_5209},
{C_text("f_5214:batch_2ddriver_2escm"),(void*)f_5214},
{C_text("f_5220:batch_2ddriver_2escm"),(void*)f_5220},
{C_text("f_5225:batch_2ddriver_2escm"),(void*)f_5225},
{C_text("f_5230:batch_2ddriver_2escm"),(void*)f_5230},
{C_text("f_5266:batch_2ddriver_2escm"),(void*)f_5266},
{C_text("f_5269:batch_2ddriver_2escm"),(void*)f_5269},
{C_text("f_5272:batch_2ddriver_2escm"),(void*)f_5272},
{C_text("f_5279:batch_2ddriver_2escm"),(void*)f_5279},
{C_text("f_5282:batch_2ddriver_2escm"),(void*)f_5282},
{C_text("f_5299:batch_2ddriver_2escm"),(void*)f_5299},
{C_text("f_5303:batch_2ddriver_2escm"),(void*)f_5303},
{C_text("f_5308:batch_2ddriver_2escm"),(void*)f_5308},
{C_text("f_5314:batch_2ddriver_2escm"),(void*)f_5314},
{C_text("f_5317:batch_2ddriver_2escm"),(void*)f_5317},
{C_text("f_5320:batch_2ddriver_2escm"),(void*)f_5320},
{C_text("f_5323:batch_2ddriver_2escm"),(void*)f_5323},
{C_text("f_5326:batch_2ddriver_2escm"),(void*)f_5326},
{C_text("f_5329:batch_2ddriver_2escm"),(void*)f_5329},
{C_text("f_5332:batch_2ddriver_2escm"),(void*)f_5332},
{C_text("f_5335:batch_2ddriver_2escm"),(void*)f_5335},
{C_text("f_5338:batch_2ddriver_2escm"),(void*)f_5338},
{C_text("f_5341:batch_2ddriver_2escm"),(void*)f_5341},
{C_text("f_5344:batch_2ddriver_2escm"),(void*)f_5344},
{C_text("f_5347:batch_2ddriver_2escm"),(void*)f_5347},
{C_text("f_5350:batch_2ddriver_2escm"),(void*)f_5350},
{C_text("f_5353:batch_2ddriver_2escm"),(void*)f_5353},
{C_text("f_5356:batch_2ddriver_2escm"),(void*)f_5356},
{C_text("f_5359:batch_2ddriver_2escm"),(void*)f_5359},
{C_text("f_5362:batch_2ddriver_2escm"),(void*)f_5362},
{C_text("f_5365:batch_2ddriver_2escm"),(void*)f_5365},
{C_text("f_5368:batch_2ddriver_2escm"),(void*)f_5368},
{C_text("f_5371:batch_2ddriver_2escm"),(void*)f_5371},
{C_text("f_5374:batch_2ddriver_2escm"),(void*)f_5374},
{C_text("f_5377:batch_2ddriver_2escm"),(void*)f_5377},
{C_text("f_5382:batch_2ddriver_2escm"),(void*)f_5382},
{C_text("f_5387:batch_2ddriver_2escm"),(void*)f_5387},
{C_text("f_5392:batch_2ddriver_2escm"),(void*)f_5392},
{C_text("f_5397:batch_2ddriver_2escm"),(void*)f_5397},
{C_text("f_5400:batch_2ddriver_2escm"),(void*)f_5400},
{C_text("f_5403:batch_2ddriver_2escm"),(void*)f_5403},
{C_text("f_5406:batch_2ddriver_2escm"),(void*)f_5406},
{C_text("f_5409:batch_2ddriver_2escm"),(void*)f_5409},
{C_text("f_5412:batch_2ddriver_2escm"),(void*)f_5412},
{C_text("f_5418:batch_2ddriver_2escm"),(void*)f_5418},
{C_text("f_5421:batch_2ddriver_2escm"),(void*)f_5421},
{C_text("f_5424:batch_2ddriver_2escm"),(void*)f_5424},
{C_text("f_5427:batch_2ddriver_2escm"),(void*)f_5427},
{C_text("f_5430:batch_2ddriver_2escm"),(void*)f_5430},
{C_text("f_5433:batch_2ddriver_2escm"),(void*)f_5433},
{C_text("f_5436:batch_2ddriver_2escm"),(void*)f_5436},
{C_text("f_5439:batch_2ddriver_2escm"),(void*)f_5439},
{C_text("f_5442:batch_2ddriver_2escm"),(void*)f_5442},
{C_text("f_5445:batch_2ddriver_2escm"),(void*)f_5445},
{C_text("f_5451:batch_2ddriver_2escm"),(void*)f_5451},
{C_text("f_5454:batch_2ddriver_2escm"),(void*)f_5454},
{C_text("f_5460:batch_2ddriver_2escm"),(void*)f_5460},
{C_text("f_5467:batch_2ddriver_2escm"),(void*)f_5467},
{C_text("f_5470:batch_2ddriver_2escm"),(void*)f_5470},
{C_text("f_5475:batch_2ddriver_2escm"),(void*)f_5475},
{C_text("f_5478:batch_2ddriver_2escm"),(void*)f_5478},
{C_text("f_5493:batch_2ddriver_2escm"),(void*)f_5493},
{C_text("f_5497:batch_2ddriver_2escm"),(void*)f_5497},
{C_text("f_5505:batch_2ddriver_2escm"),(void*)f_5505},
{C_text("f_5508:batch_2ddriver_2escm"),(void*)f_5508},
{C_text("f_5511:batch_2ddriver_2escm"),(void*)f_5511},
{C_text("f_5515:batch_2ddriver_2escm"),(void*)f_5515},
{C_text("f_5518:batch_2ddriver_2escm"),(void*)f_5518},
{C_text("f_5522:batch_2ddriver_2escm"),(void*)f_5522},
{C_text("f_5526:batch_2ddriver_2escm"),(void*)f_5526},
{C_text("f_5537:batch_2ddriver_2escm"),(void*)f_5537},
{C_text("f_5540:batch_2ddriver_2escm"),(void*)f_5540},
{C_text("f_5543:batch_2ddriver_2escm"),(void*)f_5543},
{C_text("f_5546:batch_2ddriver_2escm"),(void*)f_5546},
{C_text("f_5549:batch_2ddriver_2escm"),(void*)f_5549},
{C_text("f_5552:batch_2ddriver_2escm"),(void*)f_5552},
{C_text("f_5560:batch_2ddriver_2escm"),(void*)f_5560},
{C_text("f_5571:batch_2ddriver_2escm"),(void*)f_5571},
{C_text("f_5582:batch_2ddriver_2escm"),(void*)f_5582},
{C_text("f_5589:batch_2ddriver_2escm"),(void*)f_5589},
{C_text("f_5598:batch_2ddriver_2escm"),(void*)f_5598},
{C_text("f_5601:batch_2ddriver_2escm"),(void*)f_5601},
{C_text("f_5604:batch_2ddriver_2escm"),(void*)f_5604},
{C_text("f_5610:batch_2ddriver_2escm"),(void*)f_5610},
{C_text("f_5613:batch_2ddriver_2escm"),(void*)f_5613},
{C_text("f_5616:batch_2ddriver_2escm"),(void*)f_5616},
{C_text("f_5619:batch_2ddriver_2escm"),(void*)f_5619},
{C_text("f_5622:batch_2ddriver_2escm"),(void*)f_5622},
{C_text("f_5626:batch_2ddriver_2escm"),(void*)f_5626},
{C_text("f_5630:batch_2ddriver_2escm"),(void*)f_5630},
{C_text("f_5633:batch_2ddriver_2escm"),(void*)f_5633},
{C_text("f_5636:batch_2ddriver_2escm"),(void*)f_5636},
{C_text("f_5639:batch_2ddriver_2escm"),(void*)f_5639},
{C_text("f_5642:batch_2ddriver_2escm"),(void*)f_5642},
{C_text("f_5645:batch_2ddriver_2escm"),(void*)f_5645},
{C_text("f_5648:batch_2ddriver_2escm"),(void*)f_5648},
{C_text("f_5651:batch_2ddriver_2escm"),(void*)f_5651},
{C_text("f_5654:batch_2ddriver_2escm"),(void*)f_5654},
{C_text("f_5657:batch_2ddriver_2escm"),(void*)f_5657},
{C_text("f_5661:batch_2ddriver_2escm"),(void*)f_5661},
{C_text("f_5667:batch_2ddriver_2escm"),(void*)f_5667},
{C_text("f_5672:batch_2ddriver_2escm"),(void*)f_5672},
{C_text("f_5678:batch_2ddriver_2escm"),(void*)f_5678},
{C_text("f_5684:batch_2ddriver_2escm"),(void*)f_5684},
{C_text("f_5687:batch_2ddriver_2escm"),(void*)f_5687},
{C_text("f_5693:batch_2ddriver_2escm"),(void*)f_5693},
{C_text("f_5696:batch_2ddriver_2escm"),(void*)f_5696},
{C_text("f_5699:batch_2ddriver_2escm"),(void*)f_5699},
{C_text("f_5702:batch_2ddriver_2escm"),(void*)f_5702},
{C_text("f_5705:batch_2ddriver_2escm"),(void*)f_5705},
{C_text("f_5708:batch_2ddriver_2escm"),(void*)f_5708},
{C_text("f_5711:batch_2ddriver_2escm"),(void*)f_5711},
{C_text("f_5714:batch_2ddriver_2escm"),(void*)f_5714},
{C_text("f_5719:batch_2ddriver_2escm"),(void*)f_5719},
{C_text("f_5722:batch_2ddriver_2escm"),(void*)f_5722},
{C_text("f_5725:batch_2ddriver_2escm"),(void*)f_5725},
{C_text("f_5728:batch_2ddriver_2escm"),(void*)f_5728},
{C_text("f_5731:batch_2ddriver_2escm"),(void*)f_5731},
{C_text("f_5734:batch_2ddriver_2escm"),(void*)f_5734},
{C_text("f_5737:batch_2ddriver_2escm"),(void*)f_5737},
{C_text("f_5740:batch_2ddriver_2escm"),(void*)f_5740},
{C_text("f_5743:batch_2ddriver_2escm"),(void*)f_5743},
{C_text("f_5746:batch_2ddriver_2escm"),(void*)f_5746},
{C_text("f_5749:batch_2ddriver_2escm"),(void*)f_5749},
{C_text("f_5752:batch_2ddriver_2escm"),(void*)f_5752},
{C_text("f_5755:batch_2ddriver_2escm"),(void*)f_5755},
{C_text("f_5758:batch_2ddriver_2escm"),(void*)f_5758},
{C_text("f_5761:batch_2ddriver_2escm"),(void*)f_5761},
{C_text("f_5767:batch_2ddriver_2escm"),(void*)f_5767},
{C_text("f_5770:batch_2ddriver_2escm"),(void*)f_5770},
{C_text("f_5773:batch_2ddriver_2escm"),(void*)f_5773},
{C_text("f_5776:batch_2ddriver_2escm"),(void*)f_5776},
{C_text("f_5779:batch_2ddriver_2escm"),(void*)f_5779},
{C_text("f_5784:batch_2ddriver_2escm"),(void*)f_5784},
{C_text("f_5788:batch_2ddriver_2escm"),(void*)f_5788},
{C_text("f_5791:batch_2ddriver_2escm"),(void*)f_5791},
{C_text("f_5794:batch_2ddriver_2escm"),(void*)f_5794},
{C_text("f_5798:batch_2ddriver_2escm"),(void*)f_5798},
{C_text("f_5801:batch_2ddriver_2escm"),(void*)f_5801},
{C_text("f_5804:batch_2ddriver_2escm"),(void*)f_5804},
{C_text("f_5810:batch_2ddriver_2escm"),(void*)f_5810},
{C_text("f_5813:batch_2ddriver_2escm"),(void*)f_5813},
{C_text("f_5818:batch_2ddriver_2escm"),(void*)f_5818},
{C_text("f_5830:batch_2ddriver_2escm"),(void*)f_5830},
{C_text("f_5834:batch_2ddriver_2escm"),(void*)f_5834},
{C_text("f_5837:batch_2ddriver_2escm"),(void*)f_5837},
{C_text("f_5854:batch_2ddriver_2escm"),(void*)f_5854},
{C_text("f_5868:batch_2ddriver_2escm"),(void*)f_5868},
{C_text("f_5880:batch_2ddriver_2escm"),(void*)f_5880},
{C_text("f_5883:batch_2ddriver_2escm"),(void*)f_5883},
{C_text("f_5886:batch_2ddriver_2escm"),(void*)f_5886},
{C_text("f_5889:batch_2ddriver_2escm"),(void*)f_5889},
{C_text("f_5892:batch_2ddriver_2escm"),(void*)f_5892},
{C_text("f_5895:batch_2ddriver_2escm"),(void*)f_5895},
{C_text("f_5911:batch_2ddriver_2escm"),(void*)f_5911},
{C_text("f_5914:batch_2ddriver_2escm"),(void*)f_5914},
{C_text("f_5917:batch_2ddriver_2escm"),(void*)f_5917},
{C_text("f_5920:batch_2ddriver_2escm"),(void*)f_5920},
{C_text("f_5924:batch_2ddriver_2escm"),(void*)f_5924},
{C_text("f_5927:batch_2ddriver_2escm"),(void*)f_5927},
{C_text("f_5930:batch_2ddriver_2escm"),(void*)f_5930},
{C_text("f_5933:batch_2ddriver_2escm"),(void*)f_5933},
{C_text("f_5936:batch_2ddriver_2escm"),(void*)f_5936},
{C_text("f_5939:batch_2ddriver_2escm"),(void*)f_5939},
{C_text("f_5942:batch_2ddriver_2escm"),(void*)f_5942},
{C_text("f_5947:batch_2ddriver_2escm"),(void*)f_5947},
{C_text("f_5953:batch_2ddriver_2escm"),(void*)f_5953},
{C_text("f_5957:batch_2ddriver_2escm"),(void*)f_5957},
{C_text("f_5960:batch_2ddriver_2escm"),(void*)f_5960},
{C_text("f_5963:batch_2ddriver_2escm"),(void*)f_5963},
{C_text("f_5966:batch_2ddriver_2escm"),(void*)f_5966},
{C_text("f_5969:batch_2ddriver_2escm"),(void*)f_5969},
{C_text("f_5972:batch_2ddriver_2escm"),(void*)f_5972},
{C_text("f_5975:batch_2ddriver_2escm"),(void*)f_5975},
{C_text("f_5978:batch_2ddriver_2escm"),(void*)f_5978},
{C_text("f_5981:batch_2ddriver_2escm"),(void*)f_5981},
{C_text("f_5984:batch_2ddriver_2escm"),(void*)f_5984},
{C_text("f_5997:batch_2ddriver_2escm"),(void*)f_5997},
{C_text("f_6006:batch_2ddriver_2escm"),(void*)f_6006},
{C_text("f_6011:batch_2ddriver_2escm"),(void*)f_6011},
{C_text("f_6035:batch_2ddriver_2escm"),(void*)f_6035},
{C_text("f_6041:batch_2ddriver_2escm"),(void*)f_6041},
{C_text("f_6047:batch_2ddriver_2escm"),(void*)f_6047},
{C_text("f_6050:batch_2ddriver_2escm"),(void*)f_6050},
{C_text("f_6053:batch_2ddriver_2escm"),(void*)f_6053},
{C_text("f_6056:batch_2ddriver_2escm"),(void*)f_6056},
{C_text("f_6068:batch_2ddriver_2escm"),(void*)f_6068},
{C_text("f_6071:batch_2ddriver_2escm"),(void*)f_6071},
{C_text("f_6075:batch_2ddriver_2escm"),(void*)f_6075},
{C_text("f_6084:batch_2ddriver_2escm"),(void*)f_6084},
{C_text("f_6087:batch_2ddriver_2escm"),(void*)f_6087},
{C_text("f_6090:batch_2ddriver_2escm"),(void*)f_6090},
{C_text("f_6096:batch_2ddriver_2escm"),(void*)f_6096},
{C_text("f_6128:batch_2ddriver_2escm"),(void*)f_6128},
{C_text("f_6134:batch_2ddriver_2escm"),(void*)f_6134},
{C_text("f_6139:batch_2ddriver_2escm"),(void*)f_6139},
{C_text("f_6148:batch_2ddriver_2escm"),(void*)f_6148},
{C_text("f_6154:batch_2ddriver_2escm"),(void*)f_6154},
{C_text("f_6163:batch_2ddriver_2escm"),(void*)f_6163},
{C_text("f_6167:batch_2ddriver_2escm"),(void*)f_6167},
{C_text("f_6173:batch_2ddriver_2escm"),(void*)f_6173},
{C_text("f_6176:batch_2ddriver_2escm"),(void*)f_6176},
{C_text("f_6181:batch_2ddriver_2escm"),(void*)f_6181},
{C_text("f_6184:batch_2ddriver_2escm"),(void*)f_6184},
{C_text("f_6187:batch_2ddriver_2escm"),(void*)f_6187},
{C_text("f_6190:batch_2ddriver_2escm"),(void*)f_6190},
{C_text("f_6193:batch_2ddriver_2escm"),(void*)f_6193},
{C_text("f_6196:batch_2ddriver_2escm"),(void*)f_6196},
{C_text("f_6199:batch_2ddriver_2escm"),(void*)f_6199},
{C_text("f_6202:batch_2ddriver_2escm"),(void*)f_6202},
{C_text("f_6208:batch_2ddriver_2escm"),(void*)f_6208},
{C_text("f_6218:batch_2ddriver_2escm"),(void*)f_6218},
{C_text("f_6231:batch_2ddriver_2escm"),(void*)f_6231},
{C_text("f_6241:batch_2ddriver_2escm"),(void*)f_6241},
{C_text("f_6260:batch_2ddriver_2escm"),(void*)f_6260},
{C_text("f_6272:batch_2ddriver_2escm"),(void*)f_6272},
{C_text("f_6283:batch_2ddriver_2escm"),(void*)f_6283},
{C_text("f_6293:batch_2ddriver_2escm"),(void*)f_6293},
{C_text("f_6309:batch_2ddriver_2escm"),(void*)f_6309},
{C_text("f_6315:batch_2ddriver_2escm"),(void*)f_6315},
{C_text("f_6322:batch_2ddriver_2escm"),(void*)f_6322},
{C_text("f_6330:batch_2ddriver_2escm"),(void*)f_6330},
{C_text("f_6340:batch_2ddriver_2escm"),(void*)f_6340},
{C_text("f_6354:batch_2ddriver_2escm"),(void*)f_6354},
{C_text("f_6367:batch_2ddriver_2escm"),(void*)f_6367},
{C_text("f_6369:batch_2ddriver_2escm"),(void*)f_6369},
{C_text("f_6405:batch_2ddriver_2escm"),(void*)f_6405},
{C_text("f_6409:batch_2ddriver_2escm"),(void*)f_6409},
{C_text("f_6413:batch_2ddriver_2escm"),(void*)f_6413},
{C_text("f_6416:batch_2ddriver_2escm"),(void*)f_6416},
{C_text("f_6419:batch_2ddriver_2escm"),(void*)f_6419},
{C_text("f_6429:batch_2ddriver_2escm"),(void*)f_6429},
{C_text("f_6434:batch_2ddriver_2escm"),(void*)f_6434},
{C_text("f_6459:batch_2ddriver_2escm"),(void*)f_6459},
{C_text("f_6474:batch_2ddriver_2escm"),(void*)f_6474},
{C_text("f_6480:batch_2ddriver_2escm"),(void*)f_6480},
{C_text("f_6491:batch_2ddriver_2escm"),(void*)f_6491},
{C_text("f_6495:batch_2ddriver_2escm"),(void*)f_6495},
{C_text("f_6503:batch_2ddriver_2escm"),(void*)f_6503},
{C_text("f_6506:batch_2ddriver_2escm"),(void*)f_6506},
{C_text("f_6509:batch_2ddriver_2escm"),(void*)f_6509},
{C_text("f_6512:batch_2ddriver_2escm"),(void*)f_6512},
{C_text("f_6529:batch_2ddriver_2escm"),(void*)f_6529},
{C_text("f_6539:batch_2ddriver_2escm"),(void*)f_6539},
{C_text("f_6553:batch_2ddriver_2escm"),(void*)f_6553},
{C_text("f_6559:batch_2ddriver_2escm"),(void*)f_6559},
{C_text("f_6572:batch_2ddriver_2escm"),(void*)f_6572},
{C_text("f_6578:batch_2ddriver_2escm"),(void*)f_6578},
{C_text("f_6581:batch_2ddriver_2escm"),(void*)f_6581},
{C_text("f_6584:batch_2ddriver_2escm"),(void*)f_6584},
{C_text("f_6588:batch_2ddriver_2escm"),(void*)f_6588},
{C_text("f_6595:batch_2ddriver_2escm"),(void*)f_6595},
{C_text("f_6597:batch_2ddriver_2escm"),(void*)f_6597},
{C_text("f_6622:batch_2ddriver_2escm"),(void*)f_6622},
{C_text("f_6639:batch_2ddriver_2escm"),(void*)f_6639},
{C_text("f_6645:batch_2ddriver_2escm"),(void*)f_6645},
{C_text("f_6648:batch_2ddriver_2escm"),(void*)f_6648},
{C_text("f_6651:batch_2ddriver_2escm"),(void*)f_6651},
{C_text("f_6654:batch_2ddriver_2escm"),(void*)f_6654},
{C_text("f_6658:batch_2ddriver_2escm"),(void*)f_6658},
{C_text("f_6668:batch_2ddriver_2escm"),(void*)f_6668},
{C_text("f_6670:batch_2ddriver_2escm"),(void*)f_6670},
{C_text("f_6695:batch_2ddriver_2escm"),(void*)f_6695},
{C_text("f_6713:batch_2ddriver_2escm"),(void*)f_6713},
{C_text("f_6715:batch_2ddriver_2escm"),(void*)f_6715},
{C_text("f_6729:batch_2ddriver_2escm"),(void*)f_6729},
{C_text("f_6748:batch_2ddriver_2escm"),(void*)f_6748},
{C_text("f_6750:batch_2ddriver_2escm"),(void*)f_6750},
{C_text("f_6775:batch_2ddriver_2escm"),(void*)f_6775},
{C_text("f_6807:batch_2ddriver_2escm"),(void*)f_6807},
{C_text("f_6822:batch_2ddriver_2escm"),(void*)f_6822},
{C_text("f_6826:batch_2ddriver_2escm"),(void*)f_6826},
{C_text("f_6830:batch_2ddriver_2escm"),(void*)f_6830},
{C_text("f_6856:batch_2ddriver_2escm"),(void*)f_6856},
{C_text("f_6890:batch_2ddriver_2escm"),(void*)f_6890},
{C_text("f_6924:batch_2ddriver_2escm"),(void*)f_6924},
{C_text("f_6949:batch_2ddriver_2escm"),(void*)f_6949},
{C_text("f_6974:batch_2ddriver_2escm"),(void*)f_6974},
{C_text("f_6981:batch_2ddriver_2escm"),(void*)f_6981},
{C_text("f_6991:batch_2ddriver_2escm"),(void*)f_6991},
{C_text("f_6993:batch_2ddriver_2escm"),(void*)f_6993},
{C_text("f_7018:batch_2ddriver_2escm"),(void*)f_7018},
{C_text("f_7028:batch_2ddriver_2escm"),(void*)f_7028},
{C_text("f_7032:batch_2ddriver_2escm"),(void*)f_7032},
{C_text("f_7037:batch_2ddriver_2escm"),(void*)f_7037},
{C_text("f_7048:batch_2ddriver_2escm"),(void*)f_7048},
{C_text("f_7058:batch_2ddriver_2escm"),(void*)f_7058},
{C_text("f_7062:batch_2ddriver_2escm"),(void*)f_7062},
{C_text("f_7072:batch_2ddriver_2escm"),(void*)f_7072},
{C_text("f_7074:batch_2ddriver_2escm"),(void*)f_7074},
{C_text("f_7099:batch_2ddriver_2escm"),(void*)f_7099},
{C_text("f_7108:batch_2ddriver_2escm"),(void*)f_7108},
{C_text("f_7133:batch_2ddriver_2escm"),(void*)f_7133},
{C_text("f_7146:batch_2ddriver_2escm"),(void*)f_7146},
{C_text("f_7149:batch_2ddriver_2escm"),(void*)f_7149},
{C_text("f_7156:batch_2ddriver_2escm"),(void*)f_7156},
{C_text("f_7161:batch_2ddriver_2escm"),(void*)f_7161},
{C_text("f_7167:batch_2ddriver_2escm"),(void*)f_7167},
{C_text("f_7171:batch_2ddriver_2escm"),(void*)f_7171},
{C_text("f_7189:batch_2ddriver_2escm"),(void*)f_7189},
{C_text("f_7196:batch_2ddriver_2escm"),(void*)f_7196},
{C_text("f_7204:batch_2ddriver_2escm"),(void*)f_7204},
{C_text("f_7222:batch_2ddriver_2escm"),(void*)f_7222},
{C_text("f_7228:batch_2ddriver_2escm"),(void*)f_7228},
{C_text("f_7277:batch_2ddriver_2escm"),(void*)f_7277},
{C_text("f_7284:batch_2ddriver_2escm"),(void*)f_7284},
{C_text("f_7300:batch_2ddriver_2escm"),(void*)f_7300},
{C_text("f_7303:batch_2ddriver_2escm"),(void*)f_7303},
{C_text("f_7309:batch_2ddriver_2escm"),(void*)f_7309},
{C_text("f_7311:batch_2ddriver_2escm"),(void*)f_7311},
{C_text("f_7336:batch_2ddriver_2escm"),(void*)f_7336},
{C_text("f_7360:batch_2ddriver_2escm"),(void*)f_7360},
{C_text("f_7367:batch_2ddriver_2escm"),(void*)f_7367},
{C_text("f_7372:batch_2ddriver_2escm"),(void*)f_7372},
{C_text("f_7397:batch_2ddriver_2escm"),(void*)f_7397},
{C_text("f_7408:batch_2ddriver_2escm"),(void*)f_7408},
{C_text("f_7410:batch_2ddriver_2escm"),(void*)f_7410},
{C_text("f_7420:batch_2ddriver_2escm"),(void*)f_7420},
{C_text("f_7433:batch_2ddriver_2escm"),(void*)f_7433},
{C_text("f_7443:batch_2ddriver_2escm"),(void*)f_7443},
{C_text("f_7456:batch_2ddriver_2escm"),(void*)f_7456},
{C_text("f_7464:batch_2ddriver_2escm"),(void*)f_7464},
{C_text("f_7466:batch_2ddriver_2escm"),(void*)f_7466},
{C_text("f_7476:batch_2ddriver_2escm"),(void*)f_7476},
{C_text("f_7489:batch_2ddriver_2escm"),(void*)f_7489},
{C_text("f_7497:batch_2ddriver_2escm"),(void*)f_7497},
{C_text("f_7510:batch_2ddriver_2escm"),(void*)f_7510},
{C_text("f_7519:batch_2ddriver_2escm"),(void*)f_7519},
{C_text("f_7524:batch_2ddriver_2escm"),(void*)f_7524},
{C_text("f_7535:batch_2ddriver_2escm"),(void*)f_7535},
{C_text("f_7545:batch_2ddriver_2escm"),(void*)f_7545},
{C_text("f_7558:batch_2ddriver_2escm"),(void*)f_7558},
{C_text("f_7568:batch_2ddriver_2escm"),(void*)f_7568},
{C_text("f_7613:batch_2ddriver_2escm"),(void*)f_7613},
{C_text("f_7619:batch_2ddriver_2escm"),(void*)f_7619},
{C_text("f_7621:batch_2ddriver_2escm"),(void*)f_7621},
{C_text("f_7646:batch_2ddriver_2escm"),(void*)f_7646},
{C_text("f_7658:batch_2ddriver_2escm"),(void*)f_7658},
{C_text("f_7661:batch_2ddriver_2escm"),(void*)f_7661},
{C_text("f_7664:batch_2ddriver_2escm"),(void*)f_7664},
{C_text("f_7667:batch_2ddriver_2escm"),(void*)f_7667},
{C_text("f_7675:batch_2ddriver_2escm"),(void*)f_7675},
{C_text("f_7683:batch_2ddriver_2escm"),(void*)f_7683},
{C_text("f_7689:batch_2ddriver_2escm"),(void*)f_7689},
{C_text("f_7722:batch_2ddriver_2escm"),(void*)f_7722},
{C_text("f_7725:batch_2ddriver_2escm"),(void*)f_7725},
{C_text("f_7732:batch_2ddriver_2escm"),(void*)f_7732},
{C_text("f_7735:batch_2ddriver_2escm"),(void*)f_7735},
{C_text("f_7738:batch_2ddriver_2escm"),(void*)f_7738},
{C_text("f_7745:batch_2ddriver_2escm"),(void*)f_7745},
{C_text("f_7751:batch_2ddriver_2escm"),(void*)f_7751},
{C_text("f_7755:batch_2ddriver_2escm"),(void*)f_7755},
{C_text("f_7787:batch_2ddriver_2escm"),(void*)f_7787},
{C_text("f_7834:batch_2ddriver_2escm"),(void*)f_7834},
{C_text("f_7859:batch_2ddriver_2escm"),(void*)f_7859},
{C_text("f_7872:batch_2ddriver_2escm"),(void*)f_7872},
{C_text("f_7877:batch_2ddriver_2escm"),(void*)f_7877},
{C_text("f_7893:batch_2ddriver_2escm"),(void*)f_7893},
{C_text("f_7898:batch_2ddriver_2escm"),(void*)f_7898},
{C_text("f_7923:batch_2ddriver_2escm"),(void*)f_7923},
{C_text("f_7934:batch_2ddriver_2escm"),(void*)f_7934},
{C_text("f_7948:batch_2ddriver_2escm"),(void*)f_7948},
{C_text("f_7952:batch_2ddriver_2escm"),(void*)f_7952},
{C_text("f_7969:batch_2ddriver_2escm"),(void*)f_7969},
{C_text("f_7994:batch_2ddriver_2escm"),(void*)f_7994},
{C_text("f_8005:batch_2ddriver_2escm"),(void*)f_8005},
{C_text("f_8009:batch_2ddriver_2escm"),(void*)f_8009},
{C_text("f_8013:batch_2ddriver_2escm"),(void*)f_8013},
{C_text("f_8037:batch_2ddriver_2escm"),(void*)f_8037},
{C_text("f_8048:batch_2ddriver_2escm"),(void*)f_8048},
{C_text("f_8067:batch_2ddriver_2escm"),(void*)f_8067},
{C_text("f_8075:batch_2ddriver_2escm"),(void*)f_8075},
{C_text("f_8082:batch_2ddriver_2escm"),(void*)f_8082},
{C_text("toplevel:batch_2ddriver_2escm"),(void*)C_batch_2ddriver_toplevel},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding unexported module binding: chicken.compiler.batch-driver#partition 
o|hiding unexported module binding: chicken.compiler.batch-driver#span 
o|hiding unexported module binding: chicken.compiler.batch-driver#take 
o|hiding unexported module binding: chicken.compiler.batch-driver#drop 
o|hiding unexported module binding: chicken.compiler.batch-driver#split-at 
o|hiding unexported module binding: chicken.compiler.batch-driver#append-map 
o|hiding unexported module binding: chicken.compiler.batch-driver#every 
o|hiding unexported module binding: chicken.compiler.batch-driver#any 
o|hiding unexported module binding: chicken.compiler.batch-driver#cons* 
o|hiding unexported module binding: chicken.compiler.batch-driver#concatenate 
o|hiding unexported module binding: chicken.compiler.batch-driver#delete 
o|hiding unexported module binding: chicken.compiler.batch-driver#first 
o|hiding unexported module binding: chicken.compiler.batch-driver#second 
o|hiding unexported module binding: chicken.compiler.batch-driver#third 
o|hiding unexported module binding: chicken.compiler.batch-driver#fourth 
o|hiding unexported module binding: chicken.compiler.batch-driver#fifth 
o|hiding unexported module binding: chicken.compiler.batch-driver#delete-duplicates 
o|hiding unexported module binding: chicken.compiler.batch-driver#alist-cons 
o|hiding unexported module binding: chicken.compiler.batch-driver#filter 
o|hiding unexported module binding: chicken.compiler.batch-driver#filter-map 
o|hiding unexported module binding: chicken.compiler.batch-driver#remove 
o|hiding unexported module binding: chicken.compiler.batch-driver#unzip1 
o|hiding unexported module binding: chicken.compiler.batch-driver#last 
o|hiding unexported module binding: chicken.compiler.batch-driver#list-index 
o|hiding unexported module binding: chicken.compiler.batch-driver#lset-adjoin/eq? 
o|hiding unexported module binding: chicken.compiler.batch-driver#lset-difference/eq? 
o|hiding unexported module binding: chicken.compiler.batch-driver#lset-union/eq? 
o|hiding unexported module binding: chicken.compiler.batch-driver#lset-intersection/eq? 
o|hiding unexported module binding: chicken.compiler.batch-driver#list-tabulate 
o|hiding unexported module binding: chicken.compiler.batch-driver#lset<=/eq? 
o|hiding unexported module binding: chicken.compiler.batch-driver#lset=/eq? 
o|hiding unexported module binding: chicken.compiler.batch-driver#length+ 
o|hiding unexported module binding: chicken.compiler.batch-driver#find 
o|hiding unexported module binding: chicken.compiler.batch-driver#find-tail 
o|hiding unexported module binding: chicken.compiler.batch-driver#iota 
o|hiding unexported module binding: chicken.compiler.batch-driver#make-list 
o|hiding unexported module binding: chicken.compiler.batch-driver#posq 
o|hiding unexported module binding: chicken.compiler.batch-driver#posv 
o|hiding unexported module binding: chicken.compiler.batch-driver#print-program-statistics 
o|hiding unexported module binding: chicken.compiler.batch-driver#initialize-analysis-database 
o|hiding unexported module binding: chicken.compiler.batch-driver#display-analysis-database 
S|applied compiler syntax:
S|  chicken.format#sprintf		2
S|  scheme#for-each		15
S|  chicken.format#printf		17
S|  chicken.base#foldl		3
S|  scheme#map		20
S|  chicken.base#foldr		3
o|eliminated procedure checks: 192 
o|folded constant expression: (scheme#* (quote 1024) (quote 1024)) 
o|specializations:
o|  1 (scheme#current-output-port)
o|  5 (chicken.base#add1 *)
o|  2 (scheme#string=? string string)
o|  1 (scheme#string-append string string)
o|  4 (scheme#eqv? (or eof null fixnum char boolean symbol keyword) *)
o|  1 (scheme#< fixnum fixnum)
o|  1 (scheme#- fixnum fixnum)
o|  66 (scheme#memq * list)
o|  36 (scheme#eqv? * (or eof null fixnum char boolean symbol keyword))
o|  19 (##sys#check-output-port * * *)
o|  1 (scheme#eqv? * *)
o|  6 (##sys#check-list (or pair list) *)
o|  27 (scheme#cdr pair)
o|  10 (scheme#car pair)
(o e)|safe calls: 676 
(o e)|assignments to immediate values: 5 
o|safe globals: (chicken.compiler.batch-driver#compile-source-file chicken.compiler.batch-driver#display-analysis-database chicken.compiler.batch-driver#initialize-analysis-database chicken.compiler.batch-driver#print-program-statistics chicken.compiler.batch-driver#posv chicken.compiler.batch-driver#posq chicken.compiler.batch-driver#make-list chicken.compiler.batch-driver#iota chicken.compiler.batch-driver#find-tail chicken.compiler.batch-driver#find chicken.compiler.batch-driver#length+ chicken.compiler.batch-driver#lset=/eq? chicken.compiler.batch-driver#lset<=/eq? chicken.compiler.batch-driver#list-tabulate chicken.compiler.batch-driver#lset-intersection/eq? chicken.compiler.batch-driver#lset-union/eq? chicken.compiler.batch-driver#lset-difference/eq? chicken.compiler.batch-driver#lset-adjoin/eq? chicken.compiler.batch-driver#list-index chicken.compiler.batch-driver#last chicken.compiler.batch-driver#unzip1 chicken.compiler.batch-driver#remove chicken.compiler.batch-driver#filter-map chicken.compiler.batch-driver#filter chicken.compiler.batch-driver#alist-cons chicken.compiler.batch-driver#delete-duplicates chicken.compiler.batch-driver#fifth chicken.compiler.batch-driver#fourth chicken.compiler.batch-driver#third chicken.compiler.batch-driver#second chicken.compiler.batch-driver#first chicken.compiler.batch-driver#delete chicken.compiler.batch-driver#concatenate chicken.compiler.batch-driver#cons* chicken.compiler.batch-driver#any chicken.compiler.batch-driver#every chicken.compiler.batch-driver#append-map chicken.compiler.batch-driver#split-at chicken.compiler.batch-driver#drop chicken.compiler.batch-driver#take chicken.compiler.batch-driver#span chicken.compiler.batch-driver#partition) 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#partition 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#span 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#drop 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#split-at 
o|merged explicitly consed rest parameter: lsts237 
o|inlining procedure: k2917 
o|inlining procedure: k2932 
o|inlining procedure: k2932 
o|inlining procedure: k2917 
o|inlining procedure: k2972 
o|inlining procedure: k2972 
o|inlining procedure: k3004 
o|contracted procedure: "(mini-srfi-1.scm:77) g290299" 
o|inlining procedure: k3004 
o|inlining procedure: k3053 
o|contracted procedure: "(mini-srfi-1.scm:76) g263272" 
o|inlining procedure: k3053 
o|inlining procedure: k3096 
o|inlining procedure: k3096 
o|inlining procedure: k3127 
o|inlining procedure: k3127 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#cons* 
o|inlining procedure: k3185 
o|inlining procedure: k3185 
o|inlining procedure: k3213 
o|inlining procedure: k3213 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#second 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#third 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#fourth 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#fifth 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#delete-duplicates 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#alist-cons 
o|inlining procedure: k3344 
o|inlining procedure: k3344 
o|inlining procedure: k3336 
o|inlining procedure: k3336 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#filter-map 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#unzip1 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#last 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#list-index 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#lset-adjoin/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#lset-difference/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#lset-union/eq? 
o|inlining procedure: k3735 
o|inlining procedure: k3735 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#lset<=/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#lset=/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#length+ 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#find 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#find-tail 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#iota 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#make-list 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#posq 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#posv 
o|inlining procedure: k4095 
o|inlining procedure: k4135 
o|contracted procedure: "(batch-driver.scm:97) g776783" 
o|inlining procedure: k4135 
o|propagated global variable: g782784 chicken.compiler.core#internal-bindings 
o|inlining procedure: k4158 
o|contracted procedure: "(batch-driver.scm:93) g758765" 
o|inlining procedure: k4158 
o|propagated global variable: g764766 chicken.compiler.core#extended-bindings 
o|inlining procedure: k4181 
o|contracted procedure: "(batch-driver.scm:89) g740747" 
o|inlining procedure: k4181 
o|propagated global variable: g746748 chicken.compiler.core#standard-bindings 
o|inlining procedure: k4095 
o|inlining procedure: k4213 
o|inlining procedure: k4213 
o|inlining procedure: k4275 
o|contracted procedure: "(batch-driver.scm:164) g946953" 
o|propagated global variable: out956959 ##sys#standard-output 
o|substituted constant variable: a4246 
o|substituted constant variable: a4247 
o|propagated global variable: out956959 ##sys#standard-output 
o|inlining procedure: k4275 
o|propagated global variable: out930933 ##sys#standard-output 
o|substituted constant variable: a4299 
o|substituted constant variable: a4300 
o|propagated global variable: out930933 ##sys#standard-output 
o|propagated global variable: out937940 ##sys#standard-output 
o|substituted constant variable: a4326 
o|substituted constant variable: a4327 
o|inlining procedure: k4319 
o|propagated global variable: out937940 ##sys#standard-output 
o|inlining procedure: k4319 
o|propagated global variable: out919922 ##sys#standard-output 
o|substituted constant variable: a4364 
o|substituted constant variable: a4365 
o|propagated global variable: out919922 ##sys#standard-output 
o|propagated global variable: out913916 ##sys#standard-output 
o|substituted constant variable: a4380 
o|substituted constant variable: a4381 
o|propagated global variable: out913916 ##sys#standard-output 
o|inlining procedure: k4395 
o|propagated global variable: out873876 ##sys#standard-output 
o|substituted constant variable: a4419 
o|substituted constant variable: a4420 
o|substituted constant variable: names795 
o|propagated global variable: out873876 ##sys#standard-output 
o|inlining procedure: k4439 
o|inlining procedure: k4439 
o|inlining procedure: k4452 
o|inlining procedure: k4452 
o|inlining procedure: k4462 
o|inlining procedure: k4462 
o|propagated global variable: out903906 ##sys#standard-output 
o|substituted constant variable: a4498 
o|substituted constant variable: a4499 
o|inlining procedure: k4488 
o|propagated global variable: out903906 ##sys#standard-output 
o|inlining procedure: k4488 
o|inlining procedure: k4530 
o|inlining procedure: k4530 
o|substituted constant variable: a4546 
o|substituted constant variable: a4548 
o|inlining procedure: k4552 
o|inlining procedure: k4552 
o|inlining procedure: k4564 
o|inlining procedure: k4564 
o|inlining procedure: k4576 
o|inlining procedure: k4576 
o|inlining procedure: k4588 
o|inlining procedure: k4588 
o|substituted constant variable: a4595 
o|substituted constant variable: a4597 
o|substituted constant variable: a4599 
o|substituted constant variable: a4601 
o|substituted constant variable: a4603 
o|substituted constant variable: a4605 
o|substituted constant variable: a4607 
o|substituted constant variable: a4609 
o|substituted constant variable: a4611 
o|substituted constant variable: a4613 
o|substituted constant variable: a4615 
o|substituted constant variable: a4617 
o|substituted constant variable: a4619 
o|inlining procedure: k4623 
o|inlining procedure: k4623 
o|inlining procedure: k4635 
o|inlining procedure: k4635 
o|inlining procedure: k4647 
o|inlining procedure: k4647 
o|inlining procedure: k4659 
o|inlining procedure: k4659 
o|inlining procedure: k4671 
o|inlining procedure: k4671 
o|inlining procedure: k4683 
o|inlining procedure: k4683 
o|inlining procedure: k4695 
o|inlining procedure: k4695 
o|inlining procedure: k4707 
o|inlining procedure: k4707 
o|inlining procedure: k4719 
o|inlining procedure: k4719 
o|inlining procedure: k4731 
o|inlining procedure: k4731 
o|substituted constant variable: a4738 
o|substituted constant variable: a4740 
o|substituted constant variable: a4742 
o|substituted constant variable: a4744 
o|substituted constant variable: a4746 
o|substituted constant variable: a4748 
o|substituted constant variable: a4750 
o|substituted constant variable: a4752 
o|substituted constant variable: a4754 
o|substituted constant variable: a4756 
o|substituted constant variable: a4758 
o|substituted constant variable: a4760 
o|substituted constant variable: a4762 
o|substituted constant variable: a4764 
o|substituted constant variable: a4766 
o|substituted constant variable: a4768 
o|substituted constant variable: a4770 
o|substituted constant variable: a4772 
o|substituted constant variable: a4774 
o|substituted constant variable: a4776 
o|substituted constant variable: a4778 
o|inlining procedure: k4395 
o|inlining procedure: k4789 
o|inlining procedure: k4789 
o|substituted constant variable: a4820 
o|substituted constant variable: a4823 
o|substituted constant variable: a4832 
o|substituted constant variable: a4834 
o|substituted constant variable: a4839 
o|substituted constant variable: a4841 
o|substituted constant variable: a4861 
o|substituted constant variable: a4866 
o|substituted constant variable: a4871 
o|substituted constant variable: a4873 
o|substituted constant variable: a4875 
o|substituted constant variable: a4877 
o|substituted constant variable: a4879 
o|substituted constant variable: a4881 
o|substituted constant variable: a4886 
o|merged explicitly consed rest parameter: args1113 
o|propagated global variable: out11171120 ##sys#standard-output 
o|substituted constant variable: a4920 
o|substituted constant variable: a4921 
o|inlining procedure: k4913 
o|propagated global variable: out11171120 ##sys#standard-output 
o|inlining procedure: k4913 
o|inlining procedure: k4937 
o|inlining procedure: k4937 
o|propagated global variable: out11341137 ##sys#standard-output 
o|substituted constant variable: a4966 
o|substituted constant variable: a4967 
o|inlining procedure: k4959 
o|propagated global variable: out11341137 ##sys#standard-output 
o|inlining procedure: k4959 
o|inlining procedure: k4986 
o|inlining procedure: k5009 
o|contracted procedure: "(batch-driver.scm:275) g11491156" 
o|inlining procedure: k5009 
o|inlining procedure: k4986 
o|substituted constant variable: a5036 
o|inlining procedure: k5040 
o|inlining procedure: k5040 
o|inlining procedure: k5055 
o|inlining procedure: k5055 
o|substituted constant variable: a5102 
o|substituted constant variable: a5104 
o|substituted constant variable: a5109 
o|substituted constant variable: a5111 
o|substituted constant variable: a5113 
o|inlining procedure: k5126 
o|inlining procedure: k5126 
o|inlining procedure: k5152 
o|inlining procedure: "(batch-driver.scm:298) cputime1073" 
o|inlining procedure: k5152 
o|propagated global variable: out11971200 ##sys#standard-output 
o|substituted constant variable: a5166 
o|substituted constant variable: a5167 
o|inlining procedure: k5162 
o|inlining procedure: "(batch-driver.scm:304) cputime1073" 
o|propagated global variable: out11971200 ##sys#standard-output 
o|inlining procedure: k5162 
o|merged explicitly consed rest parameter: args1208 
o|inlining procedure: k5207 
o|propagated global variable: g12331234 chicken.compiler.support#db-get 
o|propagated global variable: g12471248 chicken.compiler.support#db-put! 
o|inlining procedure: k5207 
o|inlining procedure: k5235 
o|inlining procedure: k5235 
o|substituted constant variable: a5274 
o|substituted constant variable: a5378 
o|substituted constant variable: a5383 
o|substituted constant variable: a5388 
o|substituted constant variable: a5393 
o|substituted constant variable: a5532 
o|substituted constant variable: a5556 
o|inlining procedure: k5553 
o|inlining procedure: k5553 
o|substituted constant variable: a5567 
o|substituted constant variable: a5578 
o|inlining procedure: k5575 
o|inlining procedure: k5575 
o|inlining procedure: k5805 
o|inlining procedure: k5820 
o|inlining procedure: k5820 
o|inlining procedure: k5838 
o|inlining procedure: k5838 
o|inlining procedure: k5860 
o|inlining procedure: k5860 
o|consed rest parameter at call site: "(batch-driver.scm:788) analyze1083" 3 
o|inlining procedure: k5805 
o|consed rest parameter at call site: "(batch-driver.scm:858) dribble1074" 2 
o|consed rest parameter at call site: "(batch-driver.scm:849) dribble1074" 2 
o|propagated global variable: g21362137 chicken.pretty-print#pp 
o|consed rest parameter at call site: "(batch-driver.scm:842) dribble1074" 2 
o|inlining procedure: "(batch-driver.scm:829) cputime1073" 
o|consed rest parameter at call site: "(batch-driver.scm:819) dribble1074" 2 
o|inlining procedure: k6057 
o|inlining procedure: k6057 
o|contracted procedure: "(batch-driver.scm:762) chicken.compiler.batch-driver#print-program-statistics" 
o|propagated global variable: out686689 ##sys#standard-output 
o|substituted constant variable: a4015 
o|substituted constant variable: a4016 
o|propagated global variable: out695698 ##sys#standard-output 
o|substituted constant variable: a4033 
o|substituted constant variable: a4034 
o|propagated global variable: out702705 ##sys#standard-output 
o|substituted constant variable: a4045 
o|substituted constant variable: a4046 
o|propagated global variable: out709712 ##sys#standard-output 
o|substituted constant variable: a4057 
o|substituted constant variable: a4058 
o|propagated global variable: out716719 ##sys#standard-output 
o|substituted constant variable: a4069 
o|substituted constant variable: a4070 
o|propagated global variable: out723726 ##sys#standard-output 
o|substituted constant variable: a4081 
o|substituted constant variable: a4082 
o|inlining procedure: k4008 
o|propagated global variable: out723726 ##sys#standard-output 
o|propagated global variable: out716719 ##sys#standard-output 
o|propagated global variable: out709712 ##sys#standard-output 
o|propagated global variable: out702705 ##sys#standard-output 
o|propagated global variable: out695698 ##sys#standard-output 
o|propagated global variable: out686689 ##sys#standard-output 
o|inlining procedure: k4008 
o|inlining procedure: k6091 
o|consed rest parameter at call site: "(batch-driver.scm:755) dribble1074" 2 
o|inlining procedure: k6091 
o|consed rest parameter at call site: "(batch-driver.scm:745) analyze1083" 3 
o|contracted procedure: "(batch-driver.scm:729) chicken.compiler.batch-driver#first" 
o|inlining procedure: k6200 
o|inlining procedure: k6200 
o|consed rest parameter at call site: "(batch-driver.scm:710) analyze1083" 3 
o|inlining procedure: k6210 
o|contracted procedure: "(batch-driver.scm:702) g20512058" 
o|inlining procedure: k6210 
o|inlining procedure: k6233 
o|contracted procedure: "(batch-driver.scm:697) g20302037" 
o|inlining procedure: k6140 
o|inlining procedure: k6140 
o|inlining procedure: k6233 
o|substituted constant variable: a6253 
o|inlining procedure: k6255 
o|inlining procedure: k6255 
o|consed rest parameter at call site: "(batch-driver.scm:686) dribble1074" 2 
o|inlining procedure: k6285 
o|inlining procedure: k6285 
o|inlining procedure: k6310 
o|consed rest parameter at call site: "(batch-driver.scm:678) dribble1074" 2 
o|inlining procedure: k6310 
o|inlining procedure: k6332 
o|inlining procedure: k6332 
o|inlining procedure: k6371 
o|inlining procedure: k6371 
o|inlining procedure: k6436 
o|inlining procedure: k6436 
o|consed rest parameter at call site: "(batch-driver.scm:655) dribble1074" 2 
o|substituted constant variable: a6467 
o|inlining procedure: k6531 
o|contracted procedure: "(batch-driver.scm:636) g18971904" 
o|propagated global variable: out19071910 ##sys#standard-output 
o|substituted constant variable: a6499 
o|substituted constant variable: a6500 
o|propagated global variable: out19071910 ##sys#standard-output 
o|inlining procedure: k6531 
o|propagated global variable: g19031905 chicken.compiler.compiler-syntax#compiler-syntax-statistics 
o|inlining procedure: k6554 
o|substituted constant variable: a6574 
o|substituted constant variable: a6575 
o|inlining procedure: k6599 
o|inlining procedure: k6599 
o|substituted constant variable: a6641 
o|substituted constant variable: a6642 
o|inlining procedure: k6672 
o|inlining procedure: k6672 
o|inlining procedure: k6704 
o|inlining procedure: k6704 
o|contracted procedure: "(batch-driver.scm:621) chicken.compiler.batch-driver#lset-intersection/eq?" 
o|inlining procedure: k6554 
o|propagated global variable: g18121813 chicken.load#find-dynamic-extension 
o|contracted procedure: "(batch-driver.scm:620) chicken.compiler.batch-driver#remove" 
o|inlining procedure: k6752 
o|contracted procedure: "(batch-driver.scm:616) g17851794" 
o|inlining procedure: k6752 
o|propagated global variable: g17911795 chicken.compiler.core#import-libraries 
o|inlining procedure: k6832 
o|inlining procedure: k6832 
o|inlining procedure: k6839 
o|inlining procedure: k6839 
o|inlining procedure: k6858 
o|contracted procedure: "(batch-driver.scm:600) g17481757" 
o|inlining procedure: k6858 
o|propagated global variable: g17541758 chicken.compiler.core#used-units 
o|inlining procedure: k6892 
o|contracted procedure: "(batch-driver.scm:599) g17181727" 
o|inlining procedure: k6892 
o|propagated global variable: g17241728 chicken.compiler.core#immutable-constants 
o|inlining procedure: k6926 
o|inlining procedure: k6926 
o|inlining procedure: k6995 
o|inlining procedure: k6995 
o|consed rest parameter at call site: "(batch-driver.scm:583) dribble1074" 2 
o|consed rest parameter at call site: "(batch-driver.scm:560) dribble1074" 2 
o|inlining procedure: k7039 
o|inlining procedure: k7076 
o|inlining procedure: k7076 
o|inlining procedure: k7110 
o|inlining procedure: k7110 
o|inlining procedure: k7039 
o|inlining procedure: k7172 
o|inlining procedure: k7172 
o|inlining procedure: "(batch-driver.scm:547) cputime1073" 
o|consed rest parameter at call site: "(batch-driver.scm:542) dribble1074" 2 
o|substituted constant variable: a7205 
o|inlining procedure: k7207 
o|substituted constant variable: a7210 
o|inlining procedure: k7207 
o|substituted constant variable: a7215 
o|consed rest parameter at call site: "(batch-driver.scm:521) dribble1074" 2 
o|inlining procedure: k7233 
o|consed rest parameter at call site: "(batch-driver.scm:521) dribble1074" 2 
o|inlining procedure: k7233 
o|consed rest parameter at call site: "(batch-driver.scm:521) dribble1074" 2 
o|inlining procedure: k7237 
o|inlining procedure: k7237 
o|consed rest parameter at call site: "(batch-driver.scm:503) dribble1074" 2 
o|inlining procedure: k7254 
o|consed rest parameter at call site: "(batch-driver.scm:503) dribble1074" 2 
o|inlining procedure: k7254 
o|consed rest parameter at call site: "(batch-driver.scm:503) dribble1074" 2 
o|substituted constant variable: a7257 
o|substituted constant variable: a7269 
o|substituted constant variable: a7285 
o|inlining procedure: k7313 
o|contracted procedure: "(batch-driver.scm:483) g15091518" 
o|inlining procedure: k7313 
o|inlining procedure: k7374 
o|inlining procedure: k7374 
o|consed rest parameter at call site: "(batch-driver.scm:472) chicken.compiler.batch-driver#append-map" 3 
o|inlining procedure: k7412 
o|contracted procedure: "(batch-driver.scm:461) g14521459" 
o|inlining procedure: k5476 
o|inlining procedure: k5476 
o|inlining procedure: k7412 
o|consed rest parameter at call site: "(batch-driver.scm:460) dribble1074" 2 
o|inlining procedure: k7435 
o|inlining procedure: k7435 
o|propagated global variable: g14411442 chicken.string#string-split 
o|consed rest parameter at call site: "(batch-driver.scm:455) chicken.compiler.batch-driver#append-map" 3 
o|inlining procedure: k7468 
o|inlining procedure: k7468 
o|propagated global variable: g14261427 chicken.string#string-split 
o|consed rest parameter at call site: "(batch-driver.scm:452) chicken.compiler.batch-driver#append-map" 3 
o|substituted constant variable: a7504 
o|inlining procedure: k7537 
o|contracted procedure: "(batch-driver.scm:442) g14011408" 
o|inlining procedure: k7537 
o|propagated global variable: g14071409 chicken.compiler.core#default-extended-bindings 
o|inlining procedure: k7560 
o|contracted procedure: "(batch-driver.scm:437) g13821389" 
o|inlining procedure: k7560 
o|propagated global variable: g13881390 chicken.compiler.core#default-standard-bindings 
o|substituted constant variable: a7580 
o|substituted constant variable: a7583 
o|substituted constant variable: a7586 
o|substituted constant variable: a7589 
o|substituted constant variable: a7592 
o|inlining procedure: k7601 
o|inlining procedure: k7601 
o|inlining procedure: k7623 
o|inlining procedure: k7623 
o|substituted constant variable: a7654 
o|consed rest parameter at call site: "(batch-driver.scm:413) dribble1074" 2 
o|substituted constant variable: a7671 
o|consed rest parameter at call site: "(batch-driver.scm:410) dribble1074" 2 
o|substituted constant variable: a7679 
o|consed rest parameter at call site: "(batch-driver.scm:407) dribble1074" 2 
o|inlining procedure: k7690 
o|inlining procedure: k7690 
o|substituted constant variable: a7702 
o|substituted constant variable: a7710 
o|inlining procedure: k7707 
o|inlining procedure: k7707 
o|substituted constant variable: a7718 
o|consed rest parameter at call site: "(batch-driver.scm:396) dribble1074" 2 
o|inlining procedure: k7736 
o|inlining procedure: k7736 
o|substituted constant variable: a7756 
o|substituted constant variable: a7759 
o|substituted constant variable: a7762 
o|substituted constant variable: a7765 
o|substituted constant variable: a7768 
o|substituted constant variable: a7771 
o|substituted constant variable: a7774 
o|substituted constant variable: a7777 
o|substituted constant variable: a7780 
o|substituted constant variable: a7783 
o|consed rest parameter at call site: "(batch-driver.scm:365) dribble1074" 2 
o|substituted constant variable: a7790 
o|substituted constant variable: a7795 
o|substituted constant variable: a7799 
o|substituted constant variable: a7802 
o|substituted constant variable: a7805 
o|substituted constant variable: a7808 
o|substituted constant variable: a7828 
o|inlining procedure: k7824 
o|inlining procedure: k7824 
o|inlining procedure: k7836 
o|contracted procedure: "(batch-driver.scm:335) g12981307" 
o|substituted constant variable: a5305 
o|inlining procedure: k7836 
o|inlining procedure: k7900 
o|contracted procedure: "(batch-driver.scm:327) g12701279" 
o|inlining procedure: k7900 
o|consed rest parameter at call site: "(batch-driver.scm:325) chicken.compiler.batch-driver#append-map" 3 
o|substituted constant variable: a7935 
o|propagated global variable: tmp12571259 chicken.compiler.core#unit-name 
o|inlining procedure: k7941 
o|propagated global variable: tmp12571259 chicken.compiler.core#unit-name 
o|inlining procedure: k7941 
o|substituted constant variable: a7956 
o|substituted constant variable: a7961 
o|inlining procedure: k7963 
o|inlining procedure: k7963 
o|substituted constant variable: a7966 
o|inlining procedure: k7971 
o|inlining procedure: k7971 
o|inlining procedure: k8006 
o|inlining procedure: k8006 
o|inlining procedure: k8014 
o|inlining procedure: k8014 
o|substituted constant variable: a8029 
o|inlining procedure: k8026 
o|inlining procedure: k8026 
o|inlining procedure: k8035 
o|inlining procedure: k8035 
o|inlining procedure: k8054 
o|inlining procedure: k8054 
o|inlining procedure: k8077 
o|inlining procedure: k8077 
o|inlining procedure: k8083 
o|inlining procedure: k8092 
o|inlining procedure: k8092 
o|inlining procedure: k8083 
o|substituted constant variable: a8108 
o|substituted constant variable: a8115 
o|replaced variables: 692 
o|removed binding forms: 526 
o|substituted constant variable: r29338119 
o|substituted constant variable: r29738121 
o|contracted procedure: "(mini-srfi-1.scm:74) chicken.compiler.batch-driver#any" 
o|substituted constant variable: r31288129 
o|substituted constant variable: r31868131 
o|substituted constant variable: r33378138 
o|removed side-effect free assignment to unused variable: chicken.compiler.batch-driver#list-tabulate 
o|propagated global variable: out956959 ##sys#standard-output 
o|inlining procedure: k4234 
o|propagated global variable: out930933 ##sys#standard-output 
o|propagated global variable: out937940 ##sys#standard-output 
o|propagated global variable: out919922 ##sys#standard-output 
o|propagated global variable: out913916 ##sys#standard-output 
o|propagated global variable: out873876 ##sys#standard-output 
o|propagated global variable: out903906 ##sys#standard-output 
o|removed side-effect free assignment to unused variable: cputime1073 
o|propagated global variable: out11171120 ##sys#standard-output 
o|substituted constant variable: r49148201 
o|substituted constant variable: r49148202 
o|propagated global variable: out11341137 ##sys#standard-output 
o|substituted constant variable: r51278216 
o|propagated global variable: out11971200 ##sys#standard-output 
o|propagated global variable: out686689 ##sys#standard-output 
o|propagated global variable: out695698 ##sys#standard-output 
o|propagated global variable: out702705 ##sys#standard-output 
o|propagated global variable: out709712 ##sys#standard-output 
o|propagated global variable: out716719 ##sys#standard-output 
o|propagated global variable: out723726 ##sys#standard-output 
o|substituted constant variable: r63118282 
o|propagated global variable: out19071910 ##sys#standard-output 
o|substituted constant variable: r67058296 
o|substituted constant variable: r67058296 
o|inlining procedure: k6704 
o|inlining procedure: k6704 
o|contracted procedure: "(mini-srfi-1.scm:183) chicken.compiler.batch-driver#every" 
o|substituted constant variable: ls1550 
o|substituted constant variable: r65558300 
o|substituted constant variable: r68338305 
o|substituted constant variable: r68338305 
o|inlining procedure: k6839 
o|inlining procedure: k6839 
o|substituted constant variable: r68408309 
o|substituted constant variable: r68408309 
o|substituted constant variable: r72348333 
o|substituted constant variable: r72348333 
o|substituted constant variable: r72348335 
o|substituted constant variable: r72348335 
o|substituted constant variable: r72388337 
o|substituted constant variable: r72388337 
o|substituted constant variable: r72388339 
o|substituted constant variable: r72388339 
o|substituted constant variable: r72558341 
o|substituted constant variable: r72558341 
o|substituted constant variable: r72558343 
o|substituted constant variable: r72558343 
o|contracted procedure: "(batch-driver.scm:467) chicken.compiler.batch-driver#delete" 
o|propagated global variable: lst350 ##sys#features 
o|substituted constant variable: r76028370 
o|substituted constant variable: r78258383 
o|propagated global variable: r79428389 chicken.compiler.core#unit-name 
o|substituted constant variable: r80078399 
o|substituted constant variable: r80078399 
o|substituted constant variable: r80278403 
o|substituted constant variable: r80368407 
o|substituted constant variable: r80368407 
o|substituted constant variable: r80558409 
o|substituted constant variable: r80558409 
o|substituted constant variable: r80788413 
o|substituted constant variable: r80788413 
o|substituted constant variable: r80788415 
o|substituted constant variable: r80788415 
o|substituted constant variable: r80938419 
o|substituted constant variable: r80848420 
o|converted assignments to bindings: (option-arg978) 
o|simplifications: ((let . 1)) 
o|replaced variables: 22 
o|removed binding forms: 842 
o|removed conditional forms: 1 
o|inlining procedure: k4404 
o|inlining procedure: k4404 
o|inlining procedure: k4404 
o|inlining procedure: k4404 
o|inlining procedure: k4404 
o|inlining procedure: k4404 
o|inlining procedure: k4404 
o|inlining procedure: k4404 
o|inlining procedure: k5979 
o|inlining procedure: k6019 
o|substituted constant variable: r68408512 
o|inlining procedure: k7240 
o|substituted constant variable: x349 
o|inlining procedure: k7595 
o|inlining procedure: k7595 
o|replaced variables: 29 
o|removed binding forms: 86 
o|substituted constant variable: r60208627 
o|substituted constant variable: r67058500 
o|substituted constant variable: r67058502 
o|substituted constant variable: r72418668 
o|substituted constant variable: r75968685 
o|substituted constant variable: r75968686 
o|replaced variables: 4 
o|removed binding forms: 41 
o|removed conditional forms: 4 
o|removed binding forms: 11 
o|simplifications: ((if . 8) (##core#call . 401)) 
o|  call simplifications:
o|    scheme#string->list
o|    scheme#string
o|    scheme#string=?	2
o|    scheme#list
o|    scheme#eof-object?
o|    ##sys#cons	11
o|    ##sys#list	10
o|    scheme#>
o|    ##sys#call-with-values	3
o|    scheme#-	2
o|    scheme#cddr
o|    scheme#string-length
o|    chicken.fixnum#fx<
o|    scheme#string-ref
o|    scheme#*	2
o|    scheme#cadr	2
o|    scheme#symbol?	2
o|    scheme#memq	15
o|    scheme#cdar	6
o|    scheme#caar	3
o|    scheme#assq
o|    scheme#length	2
o|    scheme#eq?	46
o|    scheme#not	17
o|    scheme#null?	15
o|    scheme#car	12
o|    scheme#apply	2
o|    scheme#cdr	5
o|    scheme#cons	50
o|    ##sys#setslot	19
o|    ##sys#check-list	32
o|    scheme#pair?	42
o|    ##sys#slot	91
o|contracted procedure: k2920 
o|contracted procedure: k2923 
o|contracted procedure: k2935 
o|contracted procedure: k2951 
o|contracted procedure: k2959 
o|contracted procedure: k2966 
o|contracted procedure: k2990 
o|contracted procedure: k3007 
o|contracted procedure: k3029 
o|contracted procedure: k3025 
o|contracted procedure: k3010 
o|contracted procedure: k3013 
o|contracted procedure: k3021 
o|contracted procedure: k3036 
o|contracted procedure: k3044 
o|contracted procedure: k3056 
o|contracted procedure: k3078 
o|contracted procedure: k3074 
o|contracted procedure: k3059 
o|contracted procedure: k3062 
o|contracted procedure: k3070 
o|contracted procedure: k3130 
o|contracted procedure: k3145 
o|contracted procedure: k3133 
o|contracted procedure: k3188 
o|contracted procedure: k3195 
o|contracted procedure: k3327 
o|contracted procedure: k3339 
o|contracted procedure: k3357 
o|contracted procedure: k3365 
o|contracted procedure: k4104 
o|contracted procedure: k4115 
o|contracted procedure: k4126 
o|contracted procedure: k4138 
o|contracted procedure: k4148 
o|contracted procedure: k4152 
o|propagated global variable: g782784 chicken.compiler.core#internal-bindings 
o|contracted procedure: k4161 
o|contracted procedure: k4171 
o|contracted procedure: k4175 
o|propagated global variable: g764766 chicken.compiler.core#extended-bindings 
o|contracted procedure: k4184 
o|contracted procedure: k4194 
o|contracted procedure: k4198 
o|propagated global variable: g746748 chicken.compiler.core#standard-bindings 
o|contracted procedure: k4216 
o|contracted procedure: k4240 
o|contracted procedure: k4266 
o|contracted procedure: k4278 
o|contracted procedure: k4288 
o|contracted procedure: k4292 
o|contracted procedure: k4255 
o|contracted procedure: k4308 
o|contracted procedure: k4335 
o|contracted procedure: k4350 
o|contracted procedure: k4357 
o|contracted procedure: k4360 
o|contracted procedure: k4373 
o|contracted procedure: k4376 
o|contracted procedure: k4389 
o|contracted procedure: k4398 
o|contracted procedure: k4401 
o|contracted procedure: k4412 
o|contracted procedure: k4436 
o|contracted procedure: k4432 
o|contracted procedure: k4428 
o|contracted procedure: k4442 
o|contracted procedure: k4449 
o|contracted procedure: k4455 
o|contracted procedure: k4459 
o|contracted procedure: k4465 
o|contracted procedure: k4471 
o|contracted procedure: k4475 
o|contracted procedure: k4481 
o|contracted procedure: k4485 
o|contracted procedure: k4491 
o|contracted procedure: k4513 
o|contracted procedure: k4517 
o|contracted procedure: k4523 
o|contracted procedure: k4527 
o|contracted procedure: k4533 
o|contracted procedure: k4537 
o|contracted procedure: k4549 
o|contracted procedure: k4555 
o|contracted procedure: k4561 
o|contracted procedure: k4567 
o|contracted procedure: k4573 
o|contracted procedure: k4579 
o|contracted procedure: k4585 
o|contracted procedure: k4620 
o|contracted procedure: k4626 
o|contracted procedure: k4632 
o|contracted procedure: k4638 
o|contracted procedure: k4644 
o|contracted procedure: k4650 
o|contracted procedure: k4656 
o|contracted procedure: k4662 
o|contracted procedure: k4668 
o|contracted procedure: k4674 
o|contracted procedure: k4680 
o|contracted procedure: k4686 
o|contracted procedure: k4692 
o|contracted procedure: k4698 
o|contracted procedure: k4704 
o|contracted procedure: k4710 
o|contracted procedure: k4716 
o|contracted procedure: k4722 
o|contracted procedure: k4728 
o|contracted procedure: k4813 
o|contracted procedure: k4792 
o|contracted procedure: k4800 
o|contracted procedure: k4806 
o|contracted procedure: k4826 
o|contracted procedure: k8042 
o|contracted procedure: k4836 
o|contracted procedure: k4846 
o|contracted procedure: k4852 
o|contracted procedure: k4868 
o|contracted procedure: k4916 
o|contracted procedure: k5000 
o|contracted procedure: k5012 
o|contracted procedure: k5022 
o|contracted procedure: k5026 
o|contracted procedure: k5032 
o|contracted procedure: k5046 
o|contracted procedure: k5052 
o|contracted procedure: k5058 
o|contracted procedure: k5061 
o|inlining procedure: k5037 
o|contracted procedure: k5078 
o|contracted procedure: k5081 
o|inlining procedure: k5037 
o|contracted procedure: k5123 
o|contracted procedure: k5143 
o|contracted procedure: k5192 
o|contracted procedure: k5238 
o|contracted procedure: k5244 
o|contracted procedure: k5251 
o|contracted procedure: k5257 
o|contracted procedure: k5284 
o|contracted procedure: k5288 
o|contracted procedure: k5309 
o|contracted procedure: k5446 
o|contracted procedure: k5455 
o|contracted procedure: k5462 
o|contracted procedure: k5488 
o|contracted procedure: k5499 
o|contracted procedure: k5528 
o|contracted procedure: k5593 
o|contracted procedure: k5658 
o|contracted procedure: k5688 
o|contracted procedure: k5906 
o|contracted procedure: k5849 
o|contracted procedure: k5863 
o|inlining procedure: "(batch-driver.scm:858) dribble1074" 
o|contracted procedure: k5988 
o|inlining procedure: "(batch-driver.scm:858) dribble1074" 
o|inlining procedure: "(batch-driver.scm:849) dribble1074" 
o|inlining procedure: "(batch-driver.scm:842) dribble1074" 
o|contracted procedure: k6029 
o|contracted procedure: k6019 
o|contracted procedure: k6036 
o|inlining procedure: "(batch-driver.scm:819) dribble1074" 
o|contracted procedure: k6063 
o|contracted procedure: k6076 
o|inlining procedure: "(batch-driver.scm:755) dribble1074" 
o|contracted procedure: k6100 
o|contracted procedure: k6106 
o|contracted procedure: k6112 
o|contracted procedure: k6122 
o|contracted procedure: k6129 
o|contracted procedure: k6149 
o|contracted procedure: k6168 
o|contracted procedure: k6213 
o|contracted procedure: k6223 
o|contracted procedure: k6227 
o|contracted procedure: k6236 
o|contracted procedure: k6246 
o|contracted procedure: k6250 
o|contracted procedure: k6264 
o|inlining procedure: "(batch-driver.scm:686) dribble1074" 
o|contracted procedure: k6276 
o|contracted procedure: k6288 
o|contracted procedure: k6298 
o|contracted procedure: k6302 
o|inlining procedure: "(batch-driver.scm:678) dribble1074" 
o|contracted procedure: k6323 
o|contracted procedure: k6335 
o|contracted procedure: k6345 
o|contracted procedure: k6349 
o|contracted procedure: k6359 
o|contracted procedure: k6362 
o|contracted procedure: k6374 
o|contracted procedure: k6396 
o|contracted procedure: k6392 
o|contracted procedure: k6377 
o|contracted procedure: k6380 
o|contracted procedure: k6388 
o|contracted procedure: k6421 
o|contracted procedure: k6424 
o|contracted procedure: k6439 
o|contracted procedure: k6442 
o|contracted procedure: k6445 
o|contracted procedure: k6453 
o|contracted procedure: k6461 
o|inlining procedure: "(batch-driver.scm:655) dribble1074" 
o|contracted procedure: k6484 
o|contracted procedure: k6522 
o|contracted procedure: k6534 
o|contracted procedure: k6544 
o|contracted procedure: k6548 
o|contracted procedure: k6519 
o|propagated global variable: g19031905 chicken.compiler.compiler-syntax#compiler-syntax-statistics 
o|contracted procedure: k6563 
o|contracted procedure: k6590 
o|contracted procedure: k6602 
o|contracted procedure: k6605 
o|contracted procedure: k6608 
o|contracted procedure: k6616 
o|contracted procedure: k6624 
o|contracted procedure: k6630 
o|contracted procedure: k6660 
o|contracted procedure: k6663 
o|contracted procedure: k6675 
o|contracted procedure: k6678 
o|contracted procedure: k6681 
o|contracted procedure: k6689 
o|contracted procedure: k6697 
o|contracted procedure: k3093 
o|contracted procedure: k3102 
o|contracted procedure: k3115 
o|contracted procedure: k6720 
o|contracted procedure: k6731 
o|contracted procedure: k6743 
o|contracted procedure: k6755 
o|contracted procedure: k6758 
o|contracted procedure: k6761 
o|contracted procedure: k6769 
o|contracted procedure: k6777 
o|contracted procedure: k6740 
o|propagated global variable: g17911795 chicken.compiler.core#import-libraries 
o|contracted procedure: k6784 
o|contracted procedure: k6802 
o|contracted procedure: k6809 
o|contracted procedure: k6817 
o|contracted procedure: k6842 
o|contracted procedure: k6852 
o|contracted procedure: k6861 
o|contracted procedure: k6883 
o|contracted procedure: k6879 
o|contracted procedure: k6864 
o|contracted procedure: k6867 
o|contracted procedure: k6875 
o|propagated global variable: g17541758 chicken.compiler.core#used-units 
o|contracted procedure: k6895 
o|contracted procedure: k6898 
o|contracted procedure: k6901 
o|contracted procedure: k6909 
o|contracted procedure: k6917 
o|contracted procedure: k6793 
o|contracted procedure: k6797 
o|propagated global variable: g17241728 chicken.compiler.core#immutable-constants 
o|contracted procedure: k6929 
o|contracted procedure: k6932 
o|contracted procedure: k6935 
o|contracted procedure: k6943 
o|contracted procedure: k6951 
o|contracted procedure: k6957 
o|contracted procedure: k6976 
o|contracted procedure: k6968 
o|contracted procedure: k6964 
o|contracted procedure: k6983 
o|contracted procedure: k6986 
o|contracted procedure: k6998 
o|contracted procedure: k7001 
o|contracted procedure: k7004 
o|contracted procedure: k7012 
o|contracted procedure: k7020 
o|inlining procedure: "(batch-driver.scm:583) dribble1074" 
o|inlining procedure: "(batch-driver.scm:560) dribble1074" 
o|contracted procedure: k7042 
o|contracted procedure: k7050 
o|contracted procedure: k7053 
o|contracted procedure: k7064 
o|contracted procedure: k7067 
o|contracted procedure: k7079 
o|contracted procedure: k7082 
o|contracted procedure: k7085 
o|contracted procedure: k7093 
o|contracted procedure: k7101 
o|contracted procedure: k7113 
o|contracted procedure: k7116 
o|contracted procedure: k7119 
o|contracted procedure: k7127 
o|contracted procedure: k7135 
o|contracted procedure: k7141 
o|contracted procedure: k7175 
o|contracted procedure: k7182 
o|contracted procedure: k7198 
o|inlining procedure: "(batch-driver.scm:542) dribble1074" 
o|contracted procedure: k7250 
o|contracted procedure: k7217 
o|inlining procedure: "(batch-driver.scm:521) dribble1074" 
o|inlining procedure: "(batch-driver.scm:521) dribble1074" 
o|contracted procedure: k7240 
o|inlining procedure: "(batch-driver.scm:503) dribble1074" 
o|inlining procedure: "(batch-driver.scm:503) dribble1074" 
o|contracted procedure: k7262 
o|contracted procedure: k7289 
o|contracted procedure: k7304 
o|contracted procedure: k7316 
o|contracted procedure: k7319 
o|contracted procedure: k7322 
o|contracted procedure: k7330 
o|contracted procedure: k7338 
o|contracted procedure: k7344 
o|contracted procedure: k7356 
o|contracted procedure: k7352 
o|contracted procedure: k7348 
o|contracted procedure: k7362 
o|contracted procedure: k7377 
o|contracted procedure: k7380 
o|contracted procedure: k7383 
o|contracted procedure: k7391 
o|contracted procedure: k7399 
o|contracted procedure: k3216 
o|contracted procedure: k3242 
o|contracted procedure: k3222 
o|contracted procedure: k7415 
o|contracted procedure: k7425 
o|contracted procedure: k7429 
o|contracted procedure: k5482 
o|inlining procedure: "(batch-driver.scm:460) dribble1074" 
o|contracted procedure: k7438 
o|contracted procedure: k7448 
o|contracted procedure: k7452 
o|contracted procedure: k7471 
o|contracted procedure: k7481 
o|contracted procedure: k7485 
o|contracted procedure: k7498 
o|contracted procedure: k7514 
o|contracted procedure: k7528 
o|contracted procedure: k7540 
o|contracted procedure: k7550 
o|contracted procedure: k7554 
o|propagated global variable: g14071409 chicken.compiler.core#default-extended-bindings 
o|contracted procedure: k7563 
o|contracted procedure: k7573 
o|contracted procedure: k7577 
o|propagated global variable: g13881390 chicken.compiler.core#default-standard-bindings 
o|contracted procedure: k7595 
o|contracted procedure: k7608 
o|contracted procedure: k7614 
o|contracted procedure: k7626 
o|contracted procedure: k7629 
o|contracted procedure: k7632 
o|contracted procedure: k7640 
o|contracted procedure: k7648 
o|inlining procedure: "(batch-driver.scm:413) dribble1074" 
o|inlining procedure: "(batch-driver.scm:410) dribble1074" 
o|inlining procedure: "(batch-driver.scm:407) dribble1074" 
o|contracted procedure: k7693 
o|inlining procedure: "(batch-driver.scm:396) dribble1074" 
o|inlining procedure: "(batch-driver.scm:365) dribble1074" 
o|contracted procedure: k7813 
o|contracted procedure: k7817 
o|contracted procedure: k7824 
o|contracted procedure: k7839 
o|contracted procedure: k7842 
o|contracted procedure: k7845 
o|contracted procedure: k7853 
o|contracted procedure: k7861 
o|contracted procedure: k7867 
o|contracted procedure: k7879 
o|contracted procedure: k7903 
o|contracted procedure: k7906 
o|contracted procedure: k7909 
o|contracted procedure: k7917 
o|contracted procedure: k7925 
o|contracted procedure: k7888 
o|contracted procedure: k7974 
o|contracted procedure: k7977 
o|contracted procedure: k7980 
o|contracted procedure: k7988 
o|contracted procedure: k7996 
o|contracted procedure: k8017 
o|contracted procedure: k8050 
o|contracted procedure: k8061 
o|contracted procedure: k8054 
o|contracted procedure: k8069 
o|contracted procedure: k8089 
o|contracted procedure: k8095 
o|contracted procedure: k8105 
o|simplifications: ((let . 83)) 
o|removed binding forms: 360 
o|removed side-effect free assignment to unused variable: dribble1074 
o|substituted constant variable: fstr11129100 
o|substituted constant variable: args11139101 
o|substituted constant variable: fstr11129106 
o|substituted constant variable: args11139107 
o|substituted constant variable: fstr11129112 
o|substituted constant variable: fstr11129118 
o|substituted constant variable: fstr11129124 
o|substituted constant variable: fstr11129130 
o|contracted procedure: "(batch-driver.scm:684) g20072014" 
o|substituted constant variable: fstr11129142 
o|contracted procedure: "(batch-driver.scm:674) g19851992" 
o|substituted constant variable: fstr11129150 
o|substituted constant variable: fstr11129162 
o|substituted constant variable: args11139163 
o|substituted constant variable: fstr11129186 
o|substituted constant variable: args11139187 
o|substituted constant variable: fstr11129192 
o|substituted constant variable: args11139193 
o|substituted constant variable: fstr11129206 
o|substituted constant variable: fstr11129212 
o|substituted constant variable: fstr11129218 
o|substituted constant variable: fstr11129224 
o|substituted constant variable: fstr11129230 
o|substituted constant variable: fstr11129244 
o|substituted constant variable: args11139245 
o|substituted constant variable: fstr11129260 
o|substituted constant variable: args11139261 
o|substituted constant variable: fstr11129266 
o|substituted constant variable: args11139267 
o|substituted constant variable: fstr11129272 
o|substituted constant variable: args11139273 
o|substituted constant variable: fstr11129278 
o|substituted constant variable: args11139279 
o|substituted constant variable: fstr11129284 
o|substituted constant variable: args11139285 
o|replaced variables: 122 
o|removed binding forms: 2 
o|simplifications: ((if . 2)) 
o|replaced variables: 1 
o|removed binding forms: 104 
o|contracted procedure: k6913 
o|removed binding forms: 2 
o|direct leaf routine/allocation: loop326 0 
o|contracted procedure: k2975 
o|converted assignments to bindings: (loop326) 
o|simplifications: ((let . 1)) 
o|removed binding forms: 1 
x|eliminated type checks:
x|  C_i_check_list_2:	1
o|customizable procedures: (k8073 k8080 k8046 g10061007 map-loop10131033 k4863 k4883 k5264 k5267 map-loop12641282 map-loop12921310 k5315 k5318 k5324 k5327 k5330 k5333 k5336 k5339 k5342 k5345 k5348 k5351 k5354 k5357 k5360 k5363 k5366 k5369 k5372 k5375 k5380 k5385 k5390 k5395 map-loop13531370 k5422 k5425 k5428 k5431 k5434 for-each-loop13811393 for-each-loop14001412 for-each-loop10861428 for-each-loop10961443 for-each-loop14511464 loop352 chicken.compiler.batch-driver#append-map map-loop14741491 k5509 map-loop15031524 k5516 arg-val1079 k5541 k5569 loop1627 doloop15621563 map-loop15671584 map-loop15931610 map-loop16421659 k5649 k5685 g16761685 map-loop16701702 map-loop17121733 map-loop17421763 k6824 map-loop17791797 chicken.compiler.batch-driver#filter loop313 map-loop18271844 map-loop18651882 for-each-loop18961916 print-expr1078 map-loop19251942 chicken.compiler.batch-driver#initialize-analysis-database map-loop19581975 chicken.compiler.batch-driver#concatenate for-each-loop19841998 for-each-loop20062018 collect-options1080 for-each-loop20292043 for-each-loop20502061 k5759 print-db1077 print-node1076 analyze1083 begin-time1081 end-time1082 loop2083 def-no12131252 def-contf12141250 body12111220 g11921193 option-arg978 loop1184 for-each-loop11481160 chicken.compiler.batch-driver#display-analysis-database print-header1075 k4204 k4415 k4494 loop805 k4295 k4322 for-each-loop945962 for-each-loop739750 for-each-loop757768 for-each-loop775786 foldr389392 g394395 loop345 map-loop257275 map-loop284302 loop253 foldr242245 g247248) 
o|calls to known targets: 385 
o|identified direct recursive calls: f_2930 1 
o|identified direct recursive calls: f_3125 1 
o|identified direct recursive calls: f_3002 1 
o|identified direct recursive calls: f_3051 1 
o|identified direct recursive calls: f_3183 1 
o|identified direct recursive calls: f_3334 1 
o|identified direct recursive calls: f_6369 1 
o|identified direct recursive calls: f_6856 1 
o|identified direct recursive calls: f_6890 1 
o|identified direct recursive calls: f_3211 2 
o|fast box initializations: 54 
o|fast global references: 10 
o|fast global assignments: 5 
o|dropping unused closure argument: f_2915 
o|dropping unused closure argument: f_3125 
o|dropping unused closure argument: f_3177 
o|dropping unused closure argument: f_3325 
o|dropping unused closure argument: f_4787 
o|dropping unused closure argument: f_4908 
o|dropping unused closure argument: f_5030 
*/
/* end of file */
