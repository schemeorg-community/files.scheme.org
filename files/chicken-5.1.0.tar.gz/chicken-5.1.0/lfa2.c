/* Generated from lfa2.scm by the CHICKEN compiler
   http://www.call-cc.org
   Version 5.1.0rc1 (prerelease) (rev 7358d2e5)
   linux-unix-gnu-x86-64 [ 64bit dload ptables ]
   command line: lfa2.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -consult-types-file ./types.db -no-lambda-info -no-trace -emit-import-library chicken.compiler.lfa2 -output-file lfa2.c
   unit: lfa2
   uses: library eval expand extras support
*/
#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[102];
static double C_possibly_force_alignment;


C_noret_decl(f5313)
static void C_ccall f5313(C_word c,C_word *av) C_noret;
C_noret_decl(f5371)
static void C_ccall f5371(C_word c,C_word *av) C_noret;
C_noret_decl(f5392)
static void C_ccall f5392(C_word c,C_word *av) C_noret;
C_noret_decl(f5404)
static void C_ccall f5404(C_word c,C_word *av) C_noret;
C_noret_decl(f5411)
static void C_ccall f5411(C_word c,C_word *av) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word *av) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word *av) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word *av) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word *av) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word *av) C_noret;
C_noret_decl(f_2074)
static void C_fcall f_2074(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2082)
static void C_fcall f_2082(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word *av) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word *av) C_noret;
C_noret_decl(f_2118)
static void C_fcall f_2118(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2126)
static void C_fcall f_2126(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word *av) C_noret;
C_noret_decl(f_2134)
static C_word C_fcall f_2134(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word *av) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word *av) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word *av) C_noret;
C_noret_decl(f_2668)
static void C_fcall f_2668(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2674)
static C_word C_fcall f_2674(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word *av) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word *av) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word *av) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word *av) C_noret;
C_noret_decl(f_2870)
static void C_fcall f_2870(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2896)
static void C_fcall f_2896(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2902)
static void C_fcall f_2902(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word *av) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word *av) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word *av) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word *av) C_noret;
C_noret_decl(f_2943)
static void C_fcall f_2943(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word *av) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word *av) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word *av) C_noret;
C_noret_decl(f_2958)
static void C_fcall f_2958(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word *av) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word *av) C_noret;
C_noret_decl(f_2966)
static void C_fcall f_2966(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word *av) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word *av) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word *av) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word *av) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word *av) C_noret;
C_noret_decl(f_3037)
static void C_fcall f_3037(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word *av) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word *av) C_noret;
C_noret_decl(f_3083)
static void C_fcall f_3083(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3093)
static void C_fcall f_3093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static C_word C_fcall f_3129(C_word t0,C_word t1);
C_noret_decl(f_3135)
static void C_fcall f_3135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word *av) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word *av) C_noret;
C_noret_decl(f_3152)
static void C_fcall f_3152(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3159)
static void C_fcall f_3159(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_fcall f_3163(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word *av) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word *av) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word *av) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word *av) C_noret;
C_noret_decl(f_3208)
static void C_fcall f_3208(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3214)
static void C_fcall f_3214(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3220)
static void C_fcall f_3220(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3226)
static void C_fcall f_3226(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word *av) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word *av) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word *av) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word *av) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word *av) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word *av) C_noret;
C_noret_decl(f_3301)
static void C_fcall f_3301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word *av) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word *av) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word *av) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word *av) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word *av) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word *av) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word *av) C_noret;
C_noret_decl(f_3402)
static void C_fcall f_3402(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3409)
static void C_fcall f_3409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word *av) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word *av) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word *av) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word *av) C_noret;
C_noret_decl(f_3453)
static void C_fcall f_3453(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word *av) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word *av) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word *av) C_noret;
C_noret_decl(f_3520)
static void C_fcall f_3520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word *av) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word *av) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word *av) C_noret;
C_noret_decl(f_3570)
static void C_fcall f_3570(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word *av) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word *av) C_noret;
C_noret_decl(f_3593)
static void C_fcall f_3593(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word *av) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word *av) C_noret;
C_noret_decl(f_3615)
static void C_fcall f_3615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word *av) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word *av) C_noret;
C_noret_decl(f_3675)
static void C_fcall f_3675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_fcall f_3723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word *av) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word *av) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word *av) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word *av) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word *av) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word *av) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word *av) C_noret;
C_noret_decl(f_3771)
static void C_fcall f_3771(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word *av) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word *av) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word *av) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word *av) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word *av) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word *av) C_noret;
C_noret_decl(f_3863)
static void C_fcall f_3863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word *av) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word *av) C_noret;
C_noret_decl(f_3923)
static void C_fcall f_3923(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_fcall f_3967(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3977)
static void C_fcall f_3977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word *av) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word *av) C_noret;
C_noret_decl(f_4040)
static void C_fcall f_4040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word *av) C_noret;
C_noret_decl(f_4066)
static void C_fcall f_4066(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word *av) C_noret;
C_noret_decl(f_4078)
static void C_fcall f_4078(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word *av) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word *av) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word *av) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word *av) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word *av) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word *av) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word *av) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word *av) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word *av) C_noret;
C_noret_decl(f_4189)
static void C_fcall f_4189(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word *av) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word *av) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word *av) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word *av) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word *av) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word *av) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word *av) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word *av) C_noret;
C_noret_decl(f_4293)
static void C_fcall f_4293(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word *av) C_noret;
C_noret_decl(f_4324)
static void C_fcall f_4324(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word *av) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word *av) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word *av) C_noret;
C_noret_decl(f_4385)
static void C_fcall f_4385(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word *av) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word *av) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word *av) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word *av) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word *av) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word *av) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word *av) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word *av) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501(C_word c,C_word *av) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word *av) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word *av) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word *av) C_noret;
C_noret_decl(f_4542)
static void C_fcall f_4542(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word *av) C_noret;
C_noret_decl(f_4590)
static void C_fcall f_4590(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word *av) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word *av) C_noret;
C_noret_decl(f_4636)
static void C_fcall f_4636(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word *av) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word *av) C_noret;
C_noret_decl(f_4689)
static void C_fcall f_4689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word *av) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word *av) C_noret;
C_noret_decl(f_4740)
static void C_fcall f_4740(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word *av) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word *av) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word *av) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word *av) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word *av) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word *av) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word *av) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word *av) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word *av) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word *av) C_noret;
C_noret_decl(C_lfa2_toplevel)
C_externexport void C_ccall C_lfa2_toplevel(C_word c,C_word *av) C_noret;

C_noret_decl(trf_2074)
static void C_ccall trf_2074(C_word c,C_word *av) C_noret;
static void C_ccall trf_2074(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2074(t0,t1,t2);}

C_noret_decl(trf_2082)
static void C_ccall trf_2082(C_word c,C_word *av) C_noret;
static void C_ccall trf_2082(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2082(t0,t1,t2,t3);}

C_noret_decl(trf_2118)
static void C_ccall trf_2118(C_word c,C_word *av) C_noret;
static void C_ccall trf_2118(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2118(t0,t1,t2);}

C_noret_decl(trf_2126)
static void C_ccall trf_2126(C_word c,C_word *av) C_noret;
static void C_ccall trf_2126(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2126(t0,t1,t2,t3);}

C_noret_decl(trf_2668)
static void C_ccall trf_2668(C_word c,C_word *av) C_noret;
static void C_ccall trf_2668(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2668(t0,t1,t2);}

C_noret_decl(trf_2870)
static void C_ccall trf_2870(C_word c,C_word *av) C_noret;
static void C_ccall trf_2870(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2870(t0,t1,t2);}

C_noret_decl(trf_2896)
static void C_ccall trf_2896(C_word c,C_word *av) C_noret;
static void C_ccall trf_2896(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2896(t0,t1,t2);}

C_noret_decl(trf_2902)
static void C_ccall trf_2902(C_word c,C_word *av) C_noret;
static void C_ccall trf_2902(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2902(t0,t1,t2);}

C_noret_decl(trf_2943)
static void C_ccall trf_2943(C_word c,C_word *av) C_noret;
static void C_ccall trf_2943(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2943(t0,t1,t2);}

C_noret_decl(trf_2958)
static void C_ccall trf_2958(C_word c,C_word *av) C_noret;
static void C_ccall trf_2958(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2958(t0,t1,t2,t3);}

C_noret_decl(trf_2966)
static void C_ccall trf_2966(C_word c,C_word *av) C_noret;
static void C_ccall trf_2966(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2966(t0,t1,t2);}

C_noret_decl(trf_3037)
static void C_ccall trf_3037(C_word c,C_word *av) C_noret;
static void C_ccall trf_3037(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3037(t0,t1,t2);}

C_noret_decl(trf_3083)
static void C_ccall trf_3083(C_word c,C_word *av) C_noret;
static void C_ccall trf_3083(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3083(t0,t1,t2);}

C_noret_decl(trf_3093)
static void C_ccall trf_3093(C_word c,C_word *av) C_noret;
static void C_ccall trf_3093(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3093(t0,t1);}

C_noret_decl(trf_3135)
static void C_ccall trf_3135(C_word c,C_word *av) C_noret;
static void C_ccall trf_3135(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3135(t0,t1,t2);}

C_noret_decl(trf_3152)
static void C_ccall trf_3152(C_word c,C_word *av) C_noret;
static void C_ccall trf_3152(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_3152(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3159)
static void C_ccall trf_3159(C_word c,C_word *av) C_noret;
static void C_ccall trf_3159(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3159(t0,t1);}

C_noret_decl(trf_3163)
static void C_ccall trf_3163(C_word c,C_word *av) C_noret;
static void C_ccall trf_3163(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3163(t0,t1,t2);}

C_noret_decl(trf_3208)
static void C_ccall trf_3208(C_word c,C_word *av) C_noret;
static void C_ccall trf_3208(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3208(t0,t1,t2);}

C_noret_decl(trf_3214)
static void C_ccall trf_3214(C_word c,C_word *av) C_noret;
static void C_ccall trf_3214(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3214(t0,t1,t2);}

C_noret_decl(trf_3220)
static void C_ccall trf_3220(C_word c,C_word *av) C_noret;
static void C_ccall trf_3220(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3220(t0,t1,t2);}

C_noret_decl(trf_3226)
static void C_ccall trf_3226(C_word c,C_word *av) C_noret;
static void C_ccall trf_3226(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_3226(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3301)
static void C_ccall trf_3301(C_word c,C_word *av) C_noret;
static void C_ccall trf_3301(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3301(t0,t1);}

C_noret_decl(trf_3402)
static void C_ccall trf_3402(C_word c,C_word *av) C_noret;
static void C_ccall trf_3402(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3402(t0,t1);}

C_noret_decl(trf_3409)
static void C_ccall trf_3409(C_word c,C_word *av) C_noret;
static void C_ccall trf_3409(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3409(t0,t1);}

C_noret_decl(trf_3453)
static void C_ccall trf_3453(C_word c,C_word *av) C_noret;
static void C_ccall trf_3453(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3453(t0,t1);}

C_noret_decl(trf_3520)
static void C_ccall trf_3520(C_word c,C_word *av) C_noret;
static void C_ccall trf_3520(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3520(t0,t1);}

C_noret_decl(trf_3570)
static void C_ccall trf_3570(C_word c,C_word *av) C_noret;
static void C_ccall trf_3570(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3570(t0,t1,t2);}

C_noret_decl(trf_3593)
static void C_ccall trf_3593(C_word c,C_word *av) C_noret;
static void C_ccall trf_3593(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3593(t0,t1,t2);}

C_noret_decl(trf_3615)
static void C_ccall trf_3615(C_word c,C_word *av) C_noret;
static void C_ccall trf_3615(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3615(t0,t1);}

C_noret_decl(trf_3675)
static void C_ccall trf_3675(C_word c,C_word *av) C_noret;
static void C_ccall trf_3675(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3675(t0,t1);}

C_noret_decl(trf_3723)
static void C_ccall trf_3723(C_word c,C_word *av) C_noret;
static void C_ccall trf_3723(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3723(t0,t1,t2);}

C_noret_decl(trf_3771)
static void C_ccall trf_3771(C_word c,C_word *av) C_noret;
static void C_ccall trf_3771(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3771(t0,t1,t2);}

C_noret_decl(trf_3863)
static void C_ccall trf_3863(C_word c,C_word *av) C_noret;
static void C_ccall trf_3863(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3863(t0,t1);}

C_noret_decl(trf_3923)
static void C_ccall trf_3923(C_word c,C_word *av) C_noret;
static void C_ccall trf_3923(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3923(t0,t1);}

C_noret_decl(trf_3967)
static void C_ccall trf_3967(C_word c,C_word *av) C_noret;
static void C_ccall trf_3967(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3967(t0,t1,t2);}

C_noret_decl(trf_3977)
static void C_ccall trf_3977(C_word c,C_word *av) C_noret;
static void C_ccall trf_3977(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3977(t0,t1);}

C_noret_decl(trf_4040)
static void C_ccall trf_4040(C_word c,C_word *av) C_noret;
static void C_ccall trf_4040(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4040(t0,t1,t2);}

C_noret_decl(trf_4066)
static void C_ccall trf_4066(C_word c,C_word *av) C_noret;
static void C_ccall trf_4066(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4066(t0,t1,t2);}

C_noret_decl(trf_4078)
static void C_ccall trf_4078(C_word c,C_word *av) C_noret;
static void C_ccall trf_4078(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4078(t0,t1,t2);}

C_noret_decl(trf_4189)
static void C_ccall trf_4189(C_word c,C_word *av) C_noret;
static void C_ccall trf_4189(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4189(t0,t1,t2);}

C_noret_decl(trf_4293)
static void C_ccall trf_4293(C_word c,C_word *av) C_noret;
static void C_ccall trf_4293(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4293(t0,t1,t2);}

C_noret_decl(trf_4324)
static void C_ccall trf_4324(C_word c,C_word *av) C_noret;
static void C_ccall trf_4324(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4324(t0,t1,t2);}

C_noret_decl(trf_4385)
static void C_ccall trf_4385(C_word c,C_word *av) C_noret;
static void C_ccall trf_4385(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4385(t0,t1,t2);}

C_noret_decl(trf_4542)
static void C_ccall trf_4542(C_word c,C_word *av) C_noret;
static void C_ccall trf_4542(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4542(t0,t1,t2);}

C_noret_decl(trf_4590)
static void C_ccall trf_4590(C_word c,C_word *av) C_noret;
static void C_ccall trf_4590(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4590(t0,t1,t2);}

C_noret_decl(trf_4636)
static void C_ccall trf_4636(C_word c,C_word *av) C_noret;
static void C_ccall trf_4636(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4636(t0,t1,t2);}

C_noret_decl(trf_4689)
static void C_ccall trf_4689(C_word c,C_word *av) C_noret;
static void C_ccall trf_4689(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4689(t0,t1,t2);}

C_noret_decl(trf_4740)
static void C_ccall trf_4740(C_word c,C_word *av) C_noret;
static void C_ccall trf_4740(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4740(t0,t1,t2);}

/* f5313 in k3518 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f5313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f5313,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[61];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* f5371 in count-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f5371(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f5371,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_eqp(lf[9],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* f5392 in k3400 in k3389 in k3386 in k3383 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f5392(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f5392,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_eqp(lf[9],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* f5404 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f5404(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f5404,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_eqp(lf[9],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* f5411 in g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f5411(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f5411,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_eqp(lf[9],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1440 */
static void C_ccall f_1442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1442,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k1443 in k1440 */
static void C_ccall f_1445(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1445,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_expand_toplevel(2,av2);}}

/* k1446 in k1443 in k1440 */
static void C_ccall f_1448(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1448,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_1451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_1451,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_support_toplevel(2,av2);}}

/* k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_1454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(22,c,4)))){
C_save_and_reclaim((void *)f_1454,2,av);}
a=C_alloc(22);
t2=C_a_i_provide(&a,1,lf[0]);
t3=C_a_i_provide(&a,1,lf[1]);
t4=C_mutate(&lf[2] /* (set! chicken.compiler.lfa2#posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2668,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[3] /* (set! chicken.compiler.lfa2#+unboxed-map+ ...) */,lf[4]);
t6=C_mutate((C_word*)lf[5]+1 /* (set! chicken.compiler.lfa2#perform-secondary-flow-analysis ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2739,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[88]+1 /* (set! chicken.compiler.lfa2#perform-unboxing ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4212,tmp=(C_word)a,a+=2,tmp));
t8=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* foldr245 in eliminate-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_2074(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_2074,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2082,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2103,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g250 in foldr245 in eliminate-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_2082(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_2082,4,t0,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2089,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* mini-srfi-1.scm:131: pred */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2087 in g250 in foldr245 in eliminate-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2089(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,1)))){
C_save_and_reclaim((void *)f_2089,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2101 in foldr245 in eliminate-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2103,2,av);}
/* mini-srfi-1.scm:131: g250 */
t2=((C_word*)t0)[2];
f_2082(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* foldr263 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_2118(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_2118,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2152,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g268 in foldr263 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_2126(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_2126,4,t0,t1,t2,t3);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2130,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* mini-srfi-1.scm:135: pred */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2128 in g268 in foldr263 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_2130,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* mini-srfi-1.scm:135: g278 */
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=(
/* mini-srfi-1.scm:135: g278 */
  f_2134(C_a_i(&a,3),t2,t1)
);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g278 in k2128 in g268 in foldr263 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static C_word C_fcall f_2134(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2150 in foldr263 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2152,2,av);}
/* mini-srfi-1.scm:134: g268 */
t2=((C_word*)t0)[2];
f_2126(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* a2163 in eliminate-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_2164,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2172,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* mini-srfi-1.scm:141: pred */
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2170 in a2163 in eliminate-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2172(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_2172,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=C_i_not(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* chicken.compiler.lfa2#posq in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_2668(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,3)))){
C_save_and_reclaim_args((void *)trf_2668,3,t1,t2,t3);}
a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=(
  f_2674(t4,C_fix(0),t3)
);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* loop in chicken.compiler.lfa2#posq in k1452 in k1449 in k1446 in k1443 in k1440 */
static C_word C_fcall f_2674(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=C_i_car(t2);
t4=C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
return(t1);}
else{
t5=C_fixnum_plus(t1,C_fix(1));
t6=t2;
t7=C_u_i_cdr(t6);
t9=t5;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}}

/* chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2739(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(78,c,5)))){
C_save_and_reclaim((void *)f_2739,4,av);}
a=C_alloc(78);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2870,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t33=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2896,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t34=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2902,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2943,a[2]=t29,tmp=(C_word)a,a+=3,tmp));
t36=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2958,a[2]=t15,a[3]=t13,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t37=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t38=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3135,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t39=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3152,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t40=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3208,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t41=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3214,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t42=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3220,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t43=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3226,a[2]=t25,a[3]=t19,a[4]=t21,a[5]=t31,a[6]=t11,a[7]=t7,a[8]=t27,a[9]=t17,tmp=(C_word)a,a+=10,tmp));
t44=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4140,a[2]=t1,a[3]=t7,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:489: walk */
t45=((C_word*)t31)[1];
f_3226(t45,t44,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k2753 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2755,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[37];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[38];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:245: chicken.compiler.support#big-fixnum? */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}}

/* k2765 in k2753 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2767,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;{
C_word *av2=av;
av2[0]=t3;
av2[1]=t1;
f_2770(2,av2);}}
else{
/* lfa2.scm:245: chicken.compiler.support#small-bignum? */
t3=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k2768 in k2765 in k2753 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_2770,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[39];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[40];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_bignump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[41];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_flonump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[42];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_ratnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[43];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_cplxnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[44];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_booleanp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[34];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[45];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[46];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[47];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_eofp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[48];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[49];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_immp(((C_word*)t0)[3]);
t3=C_i_not(t2);
t4=(C_truep(t3)?C_structurep(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[3],C_fix(0));
t6=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_list(&a,2,lf[50],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_charp(((C_word*)t0)[3]);
t6=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t6;
av2[1]=(C_truep(t5)?lf[51]:lf[30]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}}}}}}}}}}}}

/* report in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_2870(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,0,1)))){
C_save_and_reclaim_args((void *)trf_2870,3,t0,t1,t2);}
a=C_alloc(29);
t3=C_i_assoc(t2,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t3)){
t4=t1;
t5=C_i_cdr(t3);
t6=C_s_a_i_plus(&a,2,t5,C_fix(1));
t7=t4;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_i_set_cdr(t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t4=t2;
t5=((C_word*)((C_word*)t0)[2])[1];
t6=C_a_i_cons(&a,2,t4,C_fix(1));
t7=C_a_i_cons(&a,2,t6,t5);
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=t1;{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* assigned? in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_2896(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_2896,3,t0,t1,t2);}
/* lfa2.scm:268: chicken.compiler.support#db-get */
t3=*((C_word*)lf[6]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
av2[4]=lf[7];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* droppable? in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_2902(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_2902,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2907,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:271: chicken.compiler.support#node-class */
t4=*((C_word*)lf[14]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2905 in droppable? in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2907(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_2907,2,av);}
a=C_alloc(5);
t2=C_u_i_memq(t1,lf[8]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:273: chicken.compiler.support#node-class */
t4=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k2931 in k2935 in k2939 in k2905 in droppable? in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2933(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2933,2,av);}
t2=C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* lfa2.scm:276: chicken.compiler.support#variable-mark */
t3=*((C_word*)lf[10]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[11];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k2935 in k2939 in k2905 in droppable? in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2937(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_2937,2,av);}
a=C_alloc(4);
t2=C_i_car(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2933,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:275: chicken.compiler.support#db-get */
t5=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=t3;
av2[4]=lf[12];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k2939 in k2905 in droppable? in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_2941,2,av);}
a=C_alloc(4);
t2=C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:274: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* drop! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_2943(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,2)))){
C_save_and_reclaim_args((void *)trf_2943,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2947,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:279: sub-boxed */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3220(t4,t3,t2);}

/* k2945 in drop! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_2947,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:280: chicken.compiler.support#node-class-set! */
t3=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[18];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2948 in k2945 in drop! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2950(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_2950,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:281: chicken.compiler.support#node-parameters-set! */
t3=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2951 in k2948 in k2945 in drop! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_2953,2,av);}
/* lfa2.scm:282: chicken.compiler.support#node-subexpressions-set! */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_2958(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(11,0,2)))){
C_save_and_reclaim_args((void *)trf_2958,4,t0,t1,t2,t3);}
a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:285: chicken.compiler.support#node-parameters */
t6=*((C_word*)lf[13]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k2960 in extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_2962,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lfa2.scm:286: chicken.compiler.support#node-subexpressions */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2963 in k2960 in extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,3)))){
C_save_and_reclaim((void *)f_2965,2,av);}
a=C_alloc(20);
t2=C_SCHEME_TRUE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=C_i_check_list_2(t1,lf[19]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2983,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3037,a[2]=t8,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_3037(t10,t6,t1);}

/* g601 in k2963 in k2960 in extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_2966(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_2966,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* lfa2.scm:290: droppable? */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2902(t4,t3,t2);}

/* k2971 in g601 in k2963 in k2960 in extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_2973,2,av);}
if(C_truep(t1)){
/* lfa2.scm:291: drop! */
t2=((C_word*)((C_word*)t0)[2])[1];
f_2943(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2981 in k2963 in k2960 in extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_2983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_2983,2,av);}
a=C_alloc(8);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* lfa2.scm:295: drop! */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2943(t2,((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3035,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:301: chicken.compiler.support#node-subexpressions */
t4=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k2998 in k2981 in k2963 in k2960 in extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,3)))){
C_save_and_reclaim((void *)f_3000,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* lfa2.scm:296: chicken.compiler.support#node-parameters-set! */
t3=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k3005 in k3033 in k2981 in k2963 in k2960 in extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3007,2,av);}
/* lfa2.scm:299: scheme#string-append */
t2=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3033 in k2981 in k2963 in k2960 in extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3035(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_3035,2,av);}
a=C_alloc(4);
t2=C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
switch(t2){
case C_fix(1):
/* lfa2.scm:299: scheme#string-append */
t4=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[21];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}
case C_fix(2):
/* lfa2.scm:299: scheme#string-append */
t4=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[22];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}
case C_fix(3):
/* lfa2.scm:299: scheme#string-append */
t4=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[23];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}
default:
/* lfa2.scm:305: chicken.compiler.support#bomb */
t4=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[25];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* for-each-loop600 in k2963 in k2960 in extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3037(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3037,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3047,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:288: g601 */
t5=((C_word*)t0)[3];
f_2966(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3045 in for-each-loop600 in k2963 in k2960 in extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3047(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3047,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3037(t3,((C_word*)t0)[4],t2);}

/* k3064 in extinguish! in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3066,2,av);}
t2=C_i_car(t1);
/* lfa2.scm:285: report */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2870(t3,((C_word*)t0)[3],t2);}

/* loop in k3246 in k3243 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3083(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_3083,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[30];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3093,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_cdar(t2);
t5=C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t2;
t7=C_u_i_car(t6);
t8=C_u_i_car(t7);
t9=t3;
f_3093(t9,C_i_assq(t8,((C_word*)t0)[4]));}
else{
t6=t3;
f_3093(t6,C_SCHEME_FALSE);}}}

/* k3091 in loop in k3246 in k3243 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,2)))){
C_save_and_reclaim_args((void *)trf_3093,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_i_cdr(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* lfa2.scm:315: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3083(t4,((C_word*)t0)[2],t3);}}

/* floatvar? in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static C_word C_fcall f_3129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_i_assq(t1,((C_word*)((C_word*)t0)[2])[1]));}

/* eliminate-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,0,3)))){
C_save_and_reclaim_args((void *)trf_3135,3,t0,t1,t2);}
a=C_alloc(16);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3140,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3142,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=((C_word*)((C_word*)t0)[2])[1];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2164,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=t7;
t9=C_i_check_list_2(t6,lf[27]);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2074,a[2]=t8,a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_2074(t13,t3,t6);}

/* k3138 in eliminate-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3140,2,av);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a3141 in eliminate-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3142,3,av);}
t3=C_i_car(t2);
t4=t1;{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_eqp(((C_word*)t0)[2],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* count-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3152(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,0,2)))){
C_save_and_reclaim_args((void *)trf_3152,5,t0,t1,t2,t3,t4);}
a=C_alloc(13);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_fix(1):C_i_car(t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3159,a[2]=t7,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3189,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=t9;
t11=t2;
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5371,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:318: chicken.compiler.support#node-class */
t13=*((C_word*)lf[14]+1);{
C_word av2[3];
av2[0]=t13;
av2[1]=t12;
av2[2]=t11;
((C_proc)(void*)(*((C_word*)t13+1)))(3,av2);}}

/* k3157 in count-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3159(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,3)))){
C_save_and_reclaim_args((void *)trf_3159,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:328: g666 */
t3=t2;
f_3163(t3,((C_word*)t0)[4],t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g666 in k3157 in count-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3163(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_3163,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lfa2.scm:332: acc */
t4=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3169 in g666 in k3157 in count-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_3171,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:332: acc */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3181 in k3169 in g666 in k3157 in count-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(29,c,1)))){
C_save_and_reclaim((void *)f_3183,2,av);}
a=C_alloc(29);
t2=C_i_car(t1);
t3=C_s_a_i_plus(&a,2,((C_word*)t0)[2],t2);
t4=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t4;
av2[1]=C_i_set_car(((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3187 in count-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3189,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:329: chicken.compiler.support#node-parameters */
t3=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];
f_3159(t2,C_SCHEME_FALSE);}}

/* k3198 in k3187 in count-floatvar in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3200(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3200,2,av);}
t2=C_i_car(t1);
t3=((C_word*)t0)[2];
f_3159(t3,C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]));}

/* add-boxed in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3208(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_3208,3,t0,t1,t2);}
/* lfa2.scm:334: count-floatvar */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3152(t3,t1,t2,*((C_word*)lf[28]+1),C_SCHEME_END_OF_LIST);}

/* add-unboxed in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3214(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_3214,3,t0,t1,t2);}
/* lfa2.scm:335: count-floatvar */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3152(t3,t1,t2,*((C_word*)lf[29]+1),C_SCHEME_END_OF_LIST);}

/* sub-boxed in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3220(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,4)))){
C_save_and_reclaim_args((void *)trf_3220,3,t0,t1,t2);}
a=C_alloc(3);
/* lfa2.scm:336: count-floatvar */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3152(t3,t1,t2,*((C_word*)lf[28]+1),C_a_i_list(&a,1,C_fix(-1)));}

/* walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3226(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,2)))){
C_save_and_reclaim_args((void *)trf_3226,5,t0,t1,t2,t3,t4);}
a=C_alloc(14);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3230,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* lfa2.scm:339: chicken.compiler.support#node-class */
t6=*((C_word*)lf[14]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3230(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_3230,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3233,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* lfa2.scm:340: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_3233,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* lfa2.scm:341: chicken.compiler.support#node-subexpressions */
t4=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(24,c,4)))){
C_save_and_reclaim((void *)f_3236,2,av);}
a=C_alloc(24);
t2=t1;
t3=C_eqp(((C_word*)t0)[2],lf[9]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=C_i_car(((C_word*)t0)[3]);
t6=(
/* lfa2.scm:344: floatvar? */
  f_3129(((C_word*)((C_word*)t0)[9])[1],t5)
);
if(C_truep(t6)){
t7=C_i_car(((C_word*)t0)[3]);
t8=C_i_assq(t7,((C_word*)t0)[5]);
if(C_truep(C_i_not(t8))){
t9=C_i_car(((C_word*)t0)[3]);
/* lfa2.scm:346: eliminate-floatvar */
t10=((C_word*)((C_word*)t0)[10])[1];
f_3135(t10,t4,t9);}
else{
t9=t4;{
C_word *av2=av;
av2[0]=t9;
av2[1]=C_SCHEME_UNDEFINED;
f_3245(2,av2);}}}
else{
t7=t4;{
C_word *av2=av;
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
f_3245(2,av2);}}}
else{
t4=C_eqp(((C_word*)t0)[2],lf[31]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[2],lf[32]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3295,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=C_i_car(t2);
/* lfa2.scm:350: walk */
t8=((C_word*)((C_word*)t0)[11])[1];
f_3226(t8,t6,t7,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t6=C_eqp(((C_word*)t0)[2],lf[35]);
if(C_truep(t6)){
t7=C_i_car(((C_word*)t0)[3]);
t8=((C_word*)t0)[4];
t9=t7;
if(C_truep(C_i_stringp(t9))){
t10=t8;{
C_word *av2=av;
av2[0]=t10;
av2[1]=lf[36];
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2755,a[2]=t8,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:242: chicken.keyword#keyword? */
t11=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}}
else{
t7=C_eqp(((C_word*)t0)[2],lf[55]);
if(C_truep(t7)){
t8=C_i_car(t2);
t9=t8;
t10=C_i_car(((C_word*)t0)[3]);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3385,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=t9,a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* lfa2.scm:365: walk */
t13=((C_word*)((C_word*)t0)[11])[1];
f_3226(t13,t12,t9,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t8=C_eqp(((C_word*)t0)[2],lf[56]);
t9=(C_truep(t8)?t8:C_eqp(((C_word*)t0)[2],lf[57]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3495,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t11=C_i_car(t2);
/* lfa2.scm:387: walk */
t12=((C_word*)((C_word*)t0)[11])[1];
f_3226(t12,t10,t11,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t10=C_eqp(((C_word*)t0)[2],lf[59]);
t11=(C_truep(t10)?t10:C_eqp(((C_word*)t0)[2],lf[60]));
if(C_truep(t11)){
t12=C_i_car(t2);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3514,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=t13,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[10],a[3]=t14,a[4]=t13,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3534,a[2]=t15,a[3]=((C_word*)t0)[9],a[4]=t13,tmp=(C_word)a,a+=5,tmp);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5404,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:318: chicken.compiler.support#node-class */
t19=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t19;
av2[1]=t18;
av2[2]=t13;
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}
else{
t12=C_eqp(((C_word*)t0)[2],lf[18]);
if(C_truep(t12)){
t13=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t13;
av2[1]=lf[61];
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t13=C_eqp(((C_word*)t0)[2],lf[62]);
if(C_truep(t13)){
t14=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t14;
av2[1]=lf[58];
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t14=C_eqp(((C_word*)t0)[2],lf[63]);
t15=(C_truep(t14)?t14:C_eqp(((C_word*)t0)[2],lf[64]));
if(C_truep(t15)){
t16=C_i_car(((C_word*)t0)[3]);
t17=C_i_assoc(t16,lf[3]);
t18=t17;
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3570,a[2]=t18,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t20=C_i_check_list_2(t2,lf[19]);
t21=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[8],a[5]=t2,a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4040,a[2]=t23,a[3]=t19,tmp=(C_word)a,a+=4,tmp));
t25=((C_word*)t23)[1];
f_4040(t25,t21,t2);}
else{
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t17=C_i_check_list_2(t2,lf[19]);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4078,a[2]=t20,a[3]=t16,tmp=(C_word)a,a+=4,tmp));
t22=((C_word*)t20)[1];
f_4078(t22,t18,t2);}}}}}}}}}}

/* k3243 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,2)))){
C_save_and_reclaim((void *)f_3245,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* lfa2.scm:347: add-boxed */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3208(t3,t2,((C_word*)t0)[7]);}

/* k3246 in k3243 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3248(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_3248,2,av);}
a=C_alloc(7);
t2=C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=t2;
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[5];
t7=C_i_assq(t4,t5);
if(C_truep(t7)){
t8=t3;{
C_word *av2=av;
av2[0]=t8;
av2[1]=C_i_cdr(t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3083,a[2]=t9,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_3083(t11,t3,t6);}}

/* k3293 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3295(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_3295,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_u_i_car(t2);
t5=t3;
f_3301(t5,C_eqp(lf[34],t4));}
else{
t4=t3;
f_3301(t4,C_SCHEME_FALSE);}}

/* k3299 in k3293 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,4)))){
C_save_and_reclaim_args((void *)trf_3301,2,t0,t1);}
a=C_alloc(14);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=C_i_cadr(((C_word*)t0)[6]);
/* lfa2.scm:353: scheme#append */
t7=*((C_word*)lf[33]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* lfa2.scm:359: walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3226(t4,t2,t3,((C_word*)t0)[7],((C_word*)t0)[5]);}}

/* k3302 in k3299 in k3293 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3304(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,3)))){
C_save_and_reclaim((void *)f_3304,2,av);}
a=C_alloc(6);
t2=C_i_caddr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=C_i_caddr(((C_word*)t0)[6]);
/* lfa2.scm:356: scheme#append */
t6=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k3313 in k3302 in k3299 in k3293 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3315,2,av);}
/* lfa2.scm:355: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3226(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5]);}

/* k3325 in k3299 in k3293 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3327(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3327,2,av);}
/* lfa2.scm:352: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3226(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5]);}

/* k3332 in k3299 in k3293 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_3334,2,av);}
t2=C_i_caddr(((C_word*)t0)[2]);
/* lfa2.scm:360: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3226(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k3383 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3385(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_3385,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* lfa2.scm:366: assigned? */
t4=((C_word*)((C_word*)t0)[8])[1];
f_2896(t4,t3,((C_word*)t0)[4]);}

/* k3386 in k3383 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3388(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(20,c,2)))){
C_save_and_reclaim((void *)f_3388,2,av);}
a=C_alloc(20);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_not(t2))){
t5=C_eqp(lf[42],((C_word*)t0)[10]);
if(C_truep(t5)){
t6=(
/* lfa2.scm:369: floatvar? */
  f_3129(((C_word*)((C_word*)t0)[14])[1],((C_word*)t0)[4])
);
t7=t4;
f_3453(t7,C_i_not(t6));}
else{
t6=t4;
f_3453(t6,C_SCHEME_FALSE);}}
else{
t5=t4;
f_3453(t5,C_SCHEME_FALSE);}}

/* k3389 in k3386 in k3383 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3391(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(16,c,2)))){
C_save_and_reclaim((void *)f_3391,2,av);}
a=C_alloc(16);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[8])){
t5=t4;
f_3402(t5,((C_word*)t0)[10]);}
else{
t5=((C_word*)t0)[10];
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[11]);
t7=t4;
f_3402(t7,C_a_i_cons(&a,2,t6,t5));}}

/* k3400 in k3389 in k3386 in k3383 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3402(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,0,2)))){
C_save_and_reclaim_args((void *)trf_3402,2,t0,t1);}
a=C_alloc(18);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3426,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5392,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:318: chicken.compiler.support#node-class */
t7=*((C_word*)lf[14]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k3407 in k3400 in k3389 in k3386 in k3383 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,4)))){
C_save_and_reclaim_args((void *)trf_3409,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* lfa2.scm:380: chicken.compiler.support#node-parameters */
t3=*((C_word*)lf[13]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];
/* lfa2.scm:373: walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3226(t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],t2);}}

/* k3421 in k3407 in k3400 in k3389 in k3386 in k3383 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3423(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,4)))){
C_save_and_reclaim((void *)f_3423,2,av);}
a=C_alloc(12);
t2=C_i_car(t1);
t3=((C_word*)t0)[2];
t4=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t4,t3);
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t7=C_a_i_cons(&a,2,t6,t5);
/* lfa2.scm:373: walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3226(t8,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],t7);}

/* k3424 in k3400 in k3389 in k3386 in k3383 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3426(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,2)))){
C_save_and_reclaim((void *)f_3426,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
if(C_truep(C_i_not(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3447,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:379: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];
f_3409(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_3409(t2,C_SCHEME_FALSE);}}

/* k3437 in k3424 in k3400 in k3389 in k3386 in k3383 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3439,2,av);}
t2=((C_word*)t0)[2];
f_3409(t2,C_i_not(t1));}

/* k3445 in k3424 in k3400 in k3389 in k3386 in k3383 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3447,2,av);}
t2=C_i_car(t1);
/* lfa2.scm:379: assigned? */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2896(t3,((C_word*)t0)[3],t2);}

/* k3451 in k3386 in k3383 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3453(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,0,2)))){
C_save_and_reclaim_args((void *)trf_3453,2,t0,t1);}
a=C_alloc(12);
if(C_truep(t1)){
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],C_fix(0),C_fix(0));
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
/* lfa2.scm:371: add-unboxed */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3214(t5,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
/* lfa2.scm:372: add-boxed */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3208(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k3493 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3495,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[58];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3512 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3514(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_3514,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:394: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3226(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k3515 in k3512 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3517,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[61];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3518 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,0,4)))){
C_save_and_reclaim_args((void *)trf_3520,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:393: chicken.compiler.support#node-parameters */
t3=*((C_word*)lf[13]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5313,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:394: walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3226(t3,t2,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[8]);}}

/* k3529 in k3518 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3531(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3531,2,av);}
t2=C_i_car(t1);
/* lfa2.scm:393: eliminate-floatvar */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3135(t3,((C_word*)t0)[3],t2);}

/* k3532 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3534(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3534,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:392: chicken.compiler.support#node-parameters */
t3=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];
f_3520(t2,C_SCHEME_FALSE);}}

/* k3543 in k3532 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3545,2,av);}
t2=C_i_car(t1);
/* lfa2.scm:392: floatvar? */
t3=((C_word*)t0)[2];
f_3520(t3,(
/* lfa2.scm:392: floatvar? */
  f_3129(((C_word*)((C_word*)t0)[3])[1],t2)
));}

/* g731 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3570(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_3570,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lfa2.scm:402: walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3226(t4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k3572 in g731 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3574(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_3574,2,av);}
if(C_truep(((C_word*)t0)[2])){
/* lfa2.scm:403: add-unboxed */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3214(t2,((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_3586,2,av);}
a=C_alloc(8);
t2=C_i_car(((C_word*)t0)[2]);
t3=C_i_assoc(t2,lf[65]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* lfa2.scm:405: g753 */
t5=t4;
f_3593(t5,((C_word*)t0)[9],t3);}
else{
t4=C_i_car(((C_word*)t0)[2]);
t5=C_i_assoc(t4,lf[72]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* lfa2.scm:405: g768 */
t7=t6;
f_3723(t7,((C_word*)t0)[9],t5);}
else{
t6=C_i_car(((C_word*)t0)[2]);
t7=C_i_assoc(t6,lf[73]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3771,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* lfa2.scm:405: g777 */
t9=t8;
f_3771(t9,((C_word*)t0)[9],t7);}
else{
t8=C_i_car(((C_word*)t0)[2]);
t9=C_i_assoc(t8,lf[77]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:405: g804 */
t11=t10;
f_3967(t11,((C_word*)t0)[9],t9);}
else{
t10=C_SCHEME_UNDEFINED;
t11=((C_word*)t0)[9];{
C_word *av2=av;
av2[0]=t11;
av2[1]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}}}}

/* g753 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3593(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,4)))){
C_save_and_reclaim_args((void *)trf_3593,3,t0,t1,t2);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3597,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_i_car(((C_word*)t0)[4]);
/* lfa2.scm:407: walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3226(t5,t3,t4,((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k3595 in g753 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3597(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,3)))){
C_save_and_reclaim((void *)f_3597,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3600,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[66]+1))){
/* lfa2.scm:409: extinguish! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2958(t4,t3,((C_word*)t0)[4],lf[67]);}
else{
t4=C_i_cadr(((C_word*)t0)[5]);
t5=C_eqp(lf[68],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3615,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_i_car(t2);
t8=C_eqp(lf[50],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3661,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t10=C_i_cadr(((C_word*)t0)[6]);
/* lfa2.scm:414: chicken.compiler.support#node-class */
t11=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t9;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t9=t6;
f_3615(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_3615(t7,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_u_i_car(t2);
t8=t6;
f_3675(t8,C_eqp(lf[34],t7));}
else{
t7=t6;
f_3675(t7,C_SCHEME_FALSE);}}}}

/* k3598 in k3595 in g753 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3600(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3600,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[30];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3613 in k3595 in g753 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_3615,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cadr(((C_word*)t0)[7]);
/* lfa2.scm:415: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[13]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[30];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3639 in k3613 in k3595 in g753 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3641(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3641,2,av);}
t2=C_i_car(t1);
if(C_truep(C_i_symbolp(t2))){
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_eqp(t2,t3);
if(C_truep(t4)){
/* lfa2.scm:418: extinguish! */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2958(t5,((C_word*)t0)[4],((C_word*)t0)[5],lf[69]);}
else{
t5=((C_word*)t0)[6];{
C_word *av2=av;
av2[0]=t5;
av2[1]=lf[30];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=((C_word*)t0)[6];{
C_word *av2=av;
av2[0]=t3;
av2[1]=lf[30];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3659 in k3595 in g753 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3661,2,av);}
t2=((C_word*)t0)[2];
f_3615(t2,C_eqp(lf[35],t1));}

/* k3673 in k3595 in g753 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_3675,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_memq(lf[34],t3))){
/* lfa2.scm:421: extinguish! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2958(t4,((C_word*)t0)[4],((C_word*)t0)[5],lf[70]);}
else{
t4=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[30];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_member(((C_word*)t0)[7],t3))){
/* lfa2.scm:424: extinguish! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2958(t4,((C_word*)t0)[4],((C_word*)t0)[5],lf[71]);}
else{
t4=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[30];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* g768 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,4)))){
C_save_and_reclaim_args((void *)trf_3723,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3730,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* lfa2.scm:429: walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3226(t6,t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k3728 in g768 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(13,c,2)))){
C_save_and_reclaim((void *)f_3730,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
if(C_truep(C_i_member(t2,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3739,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3757,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:431: chicken.compiler.support#node-class */
t7=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t5=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t5;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k3731 in k3728 in g768 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3733,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3737 in k3728 in g768 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3739(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_3739,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3753,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:432: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3740 in k3737 in k3728 in g768 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3742(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_3742,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:433: chicken.compiler.support#node-subexpressions */
t3=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3747 in k3740 in k3737 in k3728 in g768 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3749,2,av);}
/* lfa2.scm:433: chicken.compiler.support#node-subexpressions-set! */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3751 in k3737 in k3728 in g768 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3753,2,av);}
/* lfa2.scm:432: chicken.compiler.support#node-parameters-set! */
t2=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3755 in k3728 in g768 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3757(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3757,2,av);}
/* lfa2.scm:431: chicken.compiler.support#node-class-set! */
t2=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3771(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,0,2)))){
C_save_and_reclaim_args((void *)trf_3771,3,t0,t1,t2);}
a=C_alloc(14);
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3781,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5411,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:318: chicken.compiler.support#node-class */
t8=*((C_word*)lf[14]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k3779 in g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3781(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,4)))){
C_save_and_reclaim((void *)f_3781,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:442: chicken.compiler.support#node-parameters */
t3=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* lfa2.scm:456: walk */
t3=((C_word*)((C_word*)t0)[8])[1];
f_3226(t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k3823 in k3831 in k3846 in k3779 in g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3825(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,1)))){
C_save_and_reclaim((void *)f_3825,2,av);}
a=C_alloc(21);
t2=C_i_car(t1);
if(C_truep(C_i_symbolp(t2))){
t3=C_a_i_list(&a,2,lf[50],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[34],t5,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],lf[50]);
t4=C_a_i_list(&a,1,t3);
t5=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[34],t4,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k3831 in k3846 in k3779 in g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_3833,2,av);}
a=C_alloc(15);
t2=C_eqp(lf[35],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[4]);
/* lfa2.scm:447: chicken.compiler.support#node-parameters */
t5=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],lf[50]);
t4=C_a_i_list(&a,1,t3);
t5=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[34],t4,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k3846 in k3779 in g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(15,c,2)))){
C_save_and_reclaim((void *)f_3848,2,av);}
a=C_alloc(15);
t2=C_i_car(t1);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_eqp(lf[68],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3833,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=C_i_cadr(((C_word*)t0)[4]);
/* lfa2.scm:445: chicken.compiler.support#node-class */
t8=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t6=C_i_cadr(((C_word*)t0)[2]);
t7=C_a_i_cons(&a,2,t3,t6);
t8=C_a_i_list(&a,1,t7);
t9=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t9;
av2[1]=C_a_i_list(&a,3,lf[34],t8,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* k3849 in k3779 in g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(14,c,2)))){
C_save_and_reclaim((void *)f_3851,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_i_cadr(((C_word*)t0)[3]);
t5=C_eqp(lf[68],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3863,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_i_car(t2);
t8=C_eqp(lf[50],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3909,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t10=C_i_cadr(((C_word*)t0)[6]);
/* lfa2.scm:461: chicken.compiler.support#node-class */
t11=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t9;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t9=t6;
f_3863(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_3863(t7,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_u_i_car(t2);
t8=t6;
f_3923(t8,C_eqp(lf[34],t7));}
else{
t7=t6;
f_3923(t7,C_SCHEME_FALSE);}}}

/* k3852 in k3849 in k3779 in g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3854,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[34];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3861 in k3849 in k3779 in g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,0,2)))){
C_save_and_reclaim_args((void *)trf_3863,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cadr(((C_word*)t0)[7]);
/* lfa2.scm:463: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[13]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[34];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3887 in k3861 in k3849 in k3779 in g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3889(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_3889,2,av);}
t2=C_i_car(t1);
if(C_truep(C_i_symbolp(t2))){
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_eqp(t2,t3);
if(C_truep(t4)){
/* lfa2.scm:466: extinguish! */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2958(t5,((C_word*)t0)[4],((C_word*)t0)[5],lf[74]);}
else{
t5=((C_word*)t0)[6];{
C_word *av2=av;
av2[0]=t5;
av2[1]=lf[34];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=((C_word*)t0)[6];{
C_word *av2=av;
av2[0]=t3;
av2[1]=lf[34];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3907 in k3849 in k3779 in g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_3909,2,av);}
t2=((C_word*)t0)[2];
f_3863(t2,C_eqp(lf[35],t1));}

/* k3921 in k3849 in k3779 in g777 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3923(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,3)))){
C_save_and_reclaim_args((void *)trf_3923,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_memq(lf[34],t3))){
/* lfa2.scm:469: extinguish! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2958(t4,((C_word*)t0)[4],((C_word*)t0)[5],lf[75]);}
else{
t4=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[34];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_member(((C_word*)t0)[7],t3))){
/* lfa2.scm:472: extinguish! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2958(t4,((C_word*)t0)[4],((C_word*)t0)[5],lf[76]);}
else{
t4=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[34];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* g804 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3967(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,0,2)))){
C_save_and_reclaim_args((void *)trf_3967,3,t0,t1,t2);}
a=C_alloc(8);
t3=C_i_pairp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3977,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=C_i_cadr(t2);
t8=C_eqp(lf[68],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:479: chicken.compiler.support#node-class */
t10=*((C_word*)lf[14]+1);{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
t9=t6;
f_3977(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_3977(t7,C_SCHEME_FALSE);}}

/* k3975 in g804 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_3977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,0,2)))){
C_save_and_reclaim_args((void *)trf_3977,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:480: chicken.compiler.support#node-parameters */
t3=*((C_word*)lf[13]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_i_cadr(((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3991 in k3975 in g804 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_3993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,1)))){
C_save_and_reclaim((void *)f_3993,2,av);}
a=C_alloc(6);
t2=C_i_car(t1);
t3=C_i_symbolp(t2);
t4=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t4;
av2[1]=(C_truep(t3)?C_a_i_list(&a,2,lf[50],t2):lf[50]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4007 in g804 in k3584 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4009(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4009,2,av);}
t2=((C_word*)t0)[2];
f_3977(t2,C_eqp(lf[35],t1));}

/* for-each-loop730 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_4040,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4050,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:400: g731 */
t5=((C_word*)t0)[3];
f_3570(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4048 in for-each-loop730 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4050,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4040(t3,((C_word*)t0)[4],t2);}

/* g819 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4066(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,0,4)))){
C_save_and_reclaim_args((void *)trf_4066,3,t0,t1,t2);}
/* lfa2.scm:486: g834 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3226(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k4074 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4076,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=lf[30];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop818 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4078(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,0,2)))){
C_save_and_reclaim_args((void *)trf_4078,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4088,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:486: g819 */
t5=((C_word*)t0)[3];
f_4066(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4086 in for-each-loop818 in k3234 in k3231 in k3228 in walk in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4088,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4078(t3,((C_word*)t0)[4],t2);}

/* k4138 in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(7,c,3)))){
C_save_and_reclaim((void *)f_4140,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[4])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4151,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:491: chicken.compiler.support#with-debugging-output */
t4=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[87];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t3;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4141 in k4138 in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4143(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4143,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a4150 in k4138 in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,2)))){
C_save_and_reclaim((void *)f_4151,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4155,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:494: chicken.base#print */
t3=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[85];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4153 in a4150 in k4138 in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4155(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,3)))){
C_save_and_reclaim((void *)f_4155,2,av);}
a=C_alloc(5);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_i_check_list_2(t2,lf[19]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4189,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4189(t7,((C_word*)t0)[3],t2);}

/* k4161 in for-each-loop844 in k4153 in a4150 in k4138 in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4163,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* lfa2.scm:496: ##sys#print */
t4=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4164 in k4161 in for-each-loop844 in k4153 in a4150 in k4138 in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4166,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:496: ##sys#print */
t3=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[82];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4167 in k4164 in k4161 in for-each-loop844 in k4153 in a4150 in k4138 in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_4169,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* lfa2.scm:496: ##sys#print */
t4=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4170 in k4167 in k4164 in k4161 in for-each-loop844 in k4153 in a4150 in k4138 in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4172(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4172,2,av);}
/* lfa2.scm:496: ##sys#write-char-0 */
t2=*((C_word*)lf[80]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop844 in k4153 in a4150 in k4138 in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4189(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,0,4)))){
C_save_and_reclaim_args((void *)trf_4189,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4199,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=*((C_word*)lf[78]+1);
t8=*((C_word*)lf[78]+1);
t9=C_i_check_port_2(*((C_word*)lf[78]+1),C_fix(2),C_SCHEME_TRUE,lf[79]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4163,a[2]=t5,a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:496: ##sys#print */
t11=*((C_word*)lf[81]+1);{
C_word av2[5];
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[83];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[78]+1);
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4197 in for-each-loop844 in k4153 in a4150 in k4138 in chicken.compiler.lfa2#perform-secondary-flow-analysis in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,2)))){
C_save_and_reclaim((void *)f_4199,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4189(t3,((C_word*)t0)[4],t2);}

/* chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4212(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(12,c,3)))){
C_save_and_reclaim((void *)f_4212,4,av);}
a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4216,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4822,tmp=(C_word)a,a+=2,tmp);
t6=t5;
t7=C_i_check_list_2(t3,lf[27]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2118,a[2]=t6,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_2118(t11,t4,t3);}

/* k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4216(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(23,c,3)))){
C_save_and_reclaim((void *)f_4216,2,av);}
a=C_alloc(23);
t2=t1;
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4218,a[2]=t2,a[3]=t4,a[4]=t6,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4445,a[2]=t2,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4786,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:582: walk */
t12=((C_word*)t8)[1];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=((C_word*)t0)[3];
f_4445(3,av2);}}

/* walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_4218,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4222,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* lfa2.scm:510: chicken.compiler.support#node-class */
t4=*((C_word*)lf[14]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_4222,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4225,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* lfa2.scm:511: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4225(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_4225,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* lfa2.scm:512: chicken.compiler.support#node-subexpressions */
t4=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4226 in k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(21,c,4)))){
C_save_and_reclaim((void *)f_4228,2,av);}
a=C_alloc(21);
t2=t1;
t3=C_eqp(((C_word*)t0)[2],lf[35]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_flonump(t4))){
t5=C_a_i_list1(&a,1,t4);
/* lfa2.scm:517: chicken.compiler.support#make-node */
t6=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[90];
av2[3]=t5;
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t5=((C_word*)t0)[4];{
C_word *av2=av;
av2[0]=t5;
av2[1]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t4=C_eqp(((C_word*)t0)[2],lf[9]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=C_i_car(((C_word*)t0)[3]);
/* lfa2.scm:520: posq */
f_2668(t5,t6,((C_word*)t0)[6]);}
else{
t5=C_eqp(((C_word*)t0)[2],lf[63]);
t6=(C_truep(t5)?t5:C_eqp(((C_word*)t0)[2],lf[64]));
if(C_truep(t6)){
t7=C_i_car(((C_word*)t0)[3]);
t8=C_i_assoc(t7,lf[3]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lfa2.scm:525: g917 */
t10=t9;
f_4293(t10,((C_word*)t0)[4],t8);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t10=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=((C_word*)t12)[1];
t14=((C_word*)((C_word*)t0)[9])[1];
t15=C_i_check_list_2(t2,lf[94]);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4383,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4385,a[2]=t12,a[3]=t18,a[4]=t14,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_4385(t20,t16,t2);}}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4432,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* lfa2.scm:540: walk */
t8=((C_word*)((C_word*)t0)[9])[1];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[5];
f_4445(3,av2);}}}}}

/* k4254 in k4226 in k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4256(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4256,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* lfa2.scm:522: chicken.compiler.support#make-node */
t3=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[91];
av2[3]=t2;
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=C_a_i_list1(&a,1,((C_word*)t0)[4]);
/* lfa2.scm:523: chicken.compiler.support#make-node */
t3=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[92];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* g917 in k4226 in k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4293(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(49,0,3)))){
C_save_and_reclaim_args((void *)trf_4293,3,t0,t1,t2);}
a=C_alloc(49);
t3=t2;
t4=C_i_cadr(t3);
t5=t2;
t6=C_i_caddr(t5);
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_s_a_i_plus(&a,2,t7,C_fix(1)));
t9=C_a_i_list1(&a,1,t4);
t10=t9;
t11=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t12=t11;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t13)[1];
t15=C_eqp(t6,lf[93]);
t16=(C_truep(t15)?((C_word*)((C_word*)t0)[3])[1]:((C_word*)((C_word*)t0)[4])[1]);
t17=t16;
t18=C_i_check_list_2(((C_word*)t0)[5],lf[94]);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4322,a[2]=t1,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4324,a[2]=t13,a[3]=t21,a[4]=t17,a[5]=t14,tmp=(C_word)a,a+=6,tmp));
t23=((C_word*)t21)[1];
f_4324(t23,t19,((C_word*)t0)[5]);}

/* k4320 in g917 in k4226 in k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4322,2,av);}
/* lfa2.scm:530: chicken.compiler.support#make-node */
t2=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[63];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop924 in g917 in k4226 in k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4324(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_4324,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:532: g930 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4347 in map-loop924 in g917 in k4226 in k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4349(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4349,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4324(t6,((C_word*)t0)[5],t5);}

/* k4371 in k4226 in k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4373,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* lfa2.scm:537: chicken.compiler.support#make-node */
t3=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[92];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4381 in k4226 in k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4383,2,av);}
/* lfa2.scm:538: chicken.compiler.support#make-node */
t2=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop951 in k4226 in k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4385(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_4385,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:539: g957 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4408 in map-loop951 in k4226 in k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4410,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4385(t6,((C_word*)t0)[5],t5);}

/* k4430 in k4226 in k4223 in k4220 in walk/unbox in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4432(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4432,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* lfa2.scm:540: chicken.compiler.support#make-node */
t3=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[92];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4445(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,2)))){
C_save_and_reclaim((void *)f_4445,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4449,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* lfa2.scm:543: chicken.compiler.support#node-class */
t4=*((C_word*)lf[14]+1);{
C_word *av2=av;
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4449(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(9,c,2)))){
C_save_and_reclaim((void *)f_4449,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4452,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* lfa2.scm:544: chicken.compiler.support#node-parameters */
t4=*((C_word*)lf[13]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4452(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(10,c,2)))){
C_save_and_reclaim((void *)f_4452,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* lfa2.scm:545: chicken.compiler.support#node-subexpressions */
t4=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(18,c,3)))){
C_save_and_reclaim((void *)f_4455,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_eqp(((C_word*)t0)[2],lf[9]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(((C_word*)t0)[4]);
/* lfa2.scm:548: posq */
f_2668(t4,t5,((C_word*)t0)[6]);}
else{
t4=C_eqp(((C_word*)t0)[2],lf[55]);
if(C_truep(t4)){
t5=C_i_car(t2);
t6=t5;
t7=C_i_car(((C_word*)t0)[4]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4501,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t6,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* lfa2.scm:557: posq */
f_2668(t9,t8,((C_word*)t0)[6]);}
else{
t5=C_eqp(((C_word*)t0)[2],lf[63]);
t6=(C_truep(t5)?t5:C_eqp(((C_word*)t0)[2],lf[64]));
if(C_truep(t6)){
t7=C_i_car(((C_word*)t0)[4]);
t8=C_i_assoc(t7,lf[3]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4590,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lfa2.scm:564: g1024 */
t10=t9;
f_4590(t10,((C_word*)t0)[3],t8);}
else{
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=((C_word*)((C_word*)t0)[7])[1];
t14=C_i_check_list_2(t2,lf[94]);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4687,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4689,a[2]=t11,a[3]=t17,a[4]=t13,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_4689(t19,t15,t2);}}
else{
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=((C_word*)((C_word*)t0)[7])[1];
t12=C_i_check_list_2(t2,lf[94]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4738,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4740,a[2]=t9,a[3]=t15,a[4]=t11,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_4740(t17,t13,t2);}}}}

/* k4462 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_4464,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4478,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* lfa2.scm:551: chicken.compiler.support#make-node */
t4=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[91];
av2[3]=t3;
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k4476 in k4462 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4478,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* lfa2.scm:550: chicken.compiler.support#make-node */
t3=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[95];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4499 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4501(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(17,c,3)))){
C_save_and_reclaim((void *)f_4501,2,av);}
a=C_alloc(17);
if(C_truep(t1)){
t2=C_a_i_list2(&a,2,t1,((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* lfa2.scm:560: walk/unbox */
t5=((C_word*)((C_word*)t0)[6])[1];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[7];
f_4218(3,av2);}}
else{
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=((C_word*)((C_word*)t0)[5])[1];
t7=C_i_check_list_2(((C_word*)t0)[4],lf[94]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4540,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4542,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_4542(t12,t8,((C_word*)t0)[4]);}}

/* k4517 in k4499 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4519(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,2)))){
C_save_and_reclaim((void *)f_4519,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4523,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_cadr(((C_word*)t0)[4]);
/* lfa2.scm:561: walk */
t5=((C_word*)((C_word*)t0)[5])[1];{
C_word *av2;
if(c >= 3) {
  av2=av;
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
f_4445(3,av2);}}

/* k4521 in k4517 in k4499 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_4523,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* lfa2.scm:559: chicken.compiler.support#make-node */
t3=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[96];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4538 in k4499 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4540,2,av);}
/* lfa2.scm:562: chicken.compiler.support#make-node */
t2=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[55];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop991 in k4499 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4542(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_4542,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:562: g997 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4565 in map-loop991 in k4499 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4567,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4542(t6,((C_word*)t0)[5],t5);}

/* g1024 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4590(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(53,0,3)))){
C_save_and_reclaim_args((void *)trf_4590,3,t0,t1,t2);}
a=C_alloc(53);
t3=t2;
t4=C_i_cadr(t3);
t5=t2;
t6=C_i_caddr(t5);
t7=t6;
t8=((C_word*)((C_word*)t0)[2])[1];
t9=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_s_a_i_plus(&a,2,t8,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4602,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=C_a_i_list1(&a,1,t4);
t12=t11;
t13=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t14=t13;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=((C_word*)t15)[1];
t17=C_eqp(t7,lf[98]);
t18=(C_truep(t17)?((C_word*)((C_word*)t0)[3])[1]:((C_word*)((C_word*)t0)[4])[1]);
t19=t18;
t20=C_i_check_list_2(((C_word*)t0)[5],lf[94]);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4634,a[2]=t10,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4636,a[2]=t15,a[3]=t23,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t25=((C_word*)t23)[1];
f_4636(t25,t21,((C_word*)t0)[5]);}

/* k4600 in g1024 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,4)))){
C_save_and_reclaim((void *)f_4602,2,av);}
a=C_alloc(3);
t2=C_eqp(((C_word*)t0)[2],lf[97]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word *av2=av;
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_a_i_list1(&a,1,t1);
/* lfa2.scm:577: chicken.compiler.support#make-node */
t4=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[95];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* k4632 in g1024 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4634(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4634,2,av);}
/* lfa2.scm:569: chicken.compiler.support#make-node */
t2=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[63];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop1032 in g1024 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4636(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_4636,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4661,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:571: g1038 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4659 in map-loop1032 in g1024 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4661,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4636(t6,((C_word*)t0)[5],t5);}

/* k4685 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4687,2,av);}
/* lfa2.scm:579: chicken.compiler.support#make-node */
t2=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop1065 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4689(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_4689,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4714,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:579: g1071 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4712 in map-loop1065 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4714,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4689(t6,((C_word*)t0)[5],t5);}

/* k4736 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,4)))){
C_save_and_reclaim((void *)f_4738,2,av);}
/* lfa2.scm:580: chicken.compiler.support#make-node */
t2=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop1091 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_fcall f_4740(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,0,2)))){
C_save_and_reclaim_args((void *)trf_4740,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4765,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* lfa2.scm:580: g1097 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4763 in map-loop1091 in k4453 in k4450 in k4447 in walk in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void *)f_4765,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4740(t6,((C_word*)t0)[5],t5);}

/* k4784 in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(8,c,3)))){
C_save_and_reclaim((void *)f_4786,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4789,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:583: chicken.compiler.support#with-debugging-output */
t5=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[101];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k4787 in k4784 in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4789(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4789,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2=av;
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a4790 in k4784 in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(6,c,4)))){
C_save_and_reclaim((void *)f_4791,2,av);}
a=C_alloc(6);
t2=*((C_word*)lf[78]+1);
t3=*((C_word*)lf[78]+1);
t4=C_i_check_port_2(*((C_word*)lf[78]+1),C_fix(2),C_SCHEME_TRUE,lf[79]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4798,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* lfa2.scm:586: ##sys#print */
t6=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[100];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[78]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4796 in a4790 in k4784 in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4798,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_length(((C_word*)t0)[5]);
/* lfa2.scm:586: ##sys#print */
t4=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4799 in k4796 in a4790 in k4784 in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4801(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,3)))){
C_save_and_reclaim((void *)f_4801,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:586: ##sys#write-char-0 */
t3=*((C_word*)lf[80]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4802 in k4799 in k4796 in a4790 in k4784 in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4804(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(5,c,4)))){
C_save_and_reclaim((void *)f_4804,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[78]+1);
t3=*((C_word*)lf[78]+1);
t4=C_i_check_port_2(*((C_word*)lf[78]+1),C_fix(2),C_SCHEME_TRUE,lf[79]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lfa2.scm:588: ##sys#print */
t6=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[99];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[78]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4808 in k4802 in k4799 in k4796 in a4790 in k4784 in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4810(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(4,c,4)))){
C_save_and_reclaim((void *)f_4810,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lfa2.scm:588: ##sys#print */
t3=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 5) {
  av2=av;
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4811 in k4808 in k4802 in k4799 in k4796 in a4790 in k4784 in k4214 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4813(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,3)))){
C_save_and_reclaim((void *)f_4813,2,av);}
/* lfa2.scm:588: ##sys#write-char-0 */
t2=*((C_word*)lf[80]+1);{
C_word *av2;
if(c >= 4) {
  av2=av;
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a4821 in chicken.compiler.lfa2#perform-unboxing in k1452 in k1449 in k1446 in k1443 in k1440 */
static void C_ccall f_4822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_unlikely(!C_demand(C_calculate_demand(0,c,1)))){
C_save_and_reclaim((void *)f_4822,3,av);}
t3=C_i_cadr(t2);
t4=C_i_caddr(t2);
if(C_truep(C_i_nequalp(t3,t4))){
t5=t2;
t6=C_u_i_car(t5);
t7=t1;{
C_word *av2=av;
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t5=t1;{
C_word *av2=av;
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_lfa2_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("lfa2"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(C_unlikely(!C_demand(C_calculate_demand(3,c,2)))){
C_save_and_reclaim((void*)C_lfa2_toplevel,c,av);}
toplevel_initialized=1;
if(C_unlikely(!C_demand_2(3518))){
C_save(t1);
C_rereclaim2(3518*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,102);
lf[0]=C_h_intern(&lf[0],4, C_text("lfa2"));
lf[1]=C_h_intern(&lf[1],22, C_text("chicken.compiler.lfa2#"));
lf[4]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_a_i_flonum_plus\376\003\000\000\002\376B\000\000\022C_ub_i_flonum_plus\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376B\000\000\027C_a_i_flonum_difference\376\003\000\000\002\376B\000\000\030C_ub_i_flonum_difference\376\003\000\000\002\376\001\000\000\002\001o"
"p\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_a_i_flonum_times\376\003\000\000\002\376B\000\000\023C_ub_i_flonum_times\376\003\000\000\002\376\001\000\000\002\001op\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\025C_a_i_flonum_quotient\376\003\000\000\002\376B\000\000\026C_ub_i_flonum_quotient\376\003\000\000\002\376\001\000\000\002"
"\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\017C_flonum_equalp\376\003\000\000\002\376B\000\000\024C_ub_i_flonum_equalp\376\003\000\000\002\376\001\000\000\004\001pre"
"d\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_flonum_greaterp\376\003\000\000\002\376B\000\000\026C_ub_i_flonum_greaterp\376\003\000\000\002\376\001\000\000\004\001p"
"red\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\016C_flonum_lessp\376\003\000\000\002\376B\000\000\023C_ub_i_flonum_lessp\376\003\000\000\002\376\001\000\000\004\001pred\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\033C_flonum_greater_or_equal_p\376\003\000\000\002\376B\000\000 C_ub_i_flonum_greater_or_e"
"qual_p\376\003\000\000\002\376\001\000\000\004\001pred\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\030C_flonum_less_or_equal_p\376\003\000\000\002\376B\000\000\035C_ub_i_"
"flonum_less_or_equal_p\376\003\000\000\002\376\001\000\000\004\001pred\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_u_i_flonum_nanp\376\003\000\000\002\376B\000"
"\000\022C_ub_i_flonum_nanp\376\003\000\000\002\376\001\000\000\004\001pred\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\026C_u_i_flonum_infinitep\376\003\000\000\002"
"\376B\000\000\026C_ub_i_flonum_infnitep\376\003\000\000\002\376\001\000\000\004\001pred\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\025C_u_i_flonum_finitep"
"p\376\003\000\000\002\376B\000\000\025C_ub_i_flonum_finitep\376\003\000\000\002\376\001\000\000\004\001pred\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_flonum_si"
"n\376\003\000\000\002\376B\000\000\005C_sin\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_flonum_cos\376\003\000\000\002\376B\000\000\005C_cos\376\003"
"\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_flonum_tan\376\003\000\000\002\376B\000\000\005C_tan\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376B\000\000\021C_a_i_flonum_asin\376\003\000\000\002\376B\000\000\006C_asin\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_a_i"
"_flonum_acos\376\003\000\000\002\376B\000\000\006C_acos\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_a_i_flonum_atan\376\003\000\000"
"\002\376B\000\000\006C_atan\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_a_i_flonum_atan2\376\003\000\000\002\376B\000\000\007C_atan2\376\003"
"\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_flonum_exp\376\003\000\000\002\376B\000\000\005C_exp\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376B\000\000\021C_a_i_flonum_expr\376\003\000\000\002\376B\000\000\005C_pow\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_"
"flonum_log\376\003\000\000\002\376B\000\000\005C_log\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_a_i_flonum_sqrt\376\003\000\000\002\376B"
"\000\000\006C_sqrt\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\025C_a_i_flonum_truncate\376\003\000\000\002\376B\000\000\007C_trunc\376\003"
"\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\024C_a_i_flonum_ceiling\376\003\000\000\002\376B\000\000\006C_ceil\376\003\000\000\002\376\001\000\000\002\001op\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_a_i_flonum_floor\376\003\000\000\002\376B\000\000\007C_floor\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000"
"\000\022C_a_i_flonum_round\376\003\000\000\002\376B\000\000\007C_round\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_flonum"
"_abs\376\003\000\000\002\376B\000\000\006C_fabs\376\003\000\000\002\376\001\000\000\002\001op\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\025C_a_u_i_f32vector_ref\376\003\000\000\002\376B\000"
"\000\024C_ub_i_f32vector_ref\376\003\000\000\002\376\001\000\000\003\001acc\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\025C_a_u_i_f64vector_ref\376\003\000\000\002"
"\376B\000\000\024C_ub_i_f64vector_ref\376\003\000\000\002\376\001\000\000\003\001acc\376\377\016\376\377\016"));
lf[5]=C_h_intern(&lf[5],53, C_text("chicken.compiler.lfa2#perform-secondary-flow-analysis"));
lf[6]=C_h_intern(&lf[6],31, C_text("chicken.compiler.support#db-get"));
lf[7]=C_h_intern(&lf[7],8, C_text("assigned"));
lf[8]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\005\001quote\376\003\000\000\002\376\001\000\000\020\001##core#undefined\376\003\000\000\002\376\001\000\000\020\001##core#primitive\376\003\000\000\002\376\001\000\000\015"
"\001##core#lambda\376\377\016"));
lf[9]=C_h_intern(&lf[9],15, C_text("##core#variable"));
lf[10]=C_h_intern(&lf[10],38, C_text("chicken.compiler.support#variable-mark"));
lf[11]=C_h_intern(&lf[11],23, C_text("##compiler#always-bound"));
lf[12]=C_h_intern(&lf[12],6, C_text("global"));
lf[13]=C_h_intern(&lf[13],40, C_text("chicken.compiler.support#node-parameters"));
lf[14]=C_h_intern(&lf[14],35, C_text("chicken.compiler.support#node-class"));
lf[15]=C_h_intern(&lf[15],49, C_text("chicken.compiler.support#node-subexpressions-set!"));
lf[16]=C_h_intern(&lf[16],45, C_text("chicken.compiler.support#node-parameters-set!"));
lf[17]=C_h_intern(&lf[17],40, C_text("chicken.compiler.support#node-class-set!"));
lf[18]=C_h_intern(&lf[18],16, C_text("##core#undefined"));
lf[19]=C_h_intern(&lf[19],8, C_text("for-each"));
lf[20]=C_h_intern(&lf[20],20, C_text("scheme#string-append"));
lf[21]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0011"));
lf[22]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0012"));
lf[23]=C_decode_literal(C_heaptop,C_text("\376B\000\000\0013"));
lf[24]=C_h_intern(&lf[24],29, C_text("chicken.compiler.support#bomb"));
lf[25]=C_decode_literal(C_heaptop,C_text("\376B\000\0005bad number of arguments to extinguished ##core#inline"));
lf[26]=C_h_intern(&lf[26],44, C_text("chicken.compiler.support#node-subexpressions"));
lf[27]=C_h_intern(&lf[27],5, C_text("foldr"));
lf[28]=C_h_intern(&lf[28],10, C_text("scheme#cdr"));
lf[29]=C_h_intern(&lf[29],11, C_text("scheme#cddr"));
lf[30]=C_h_intern(&lf[30],1, C_text("\052"));
lf[31]=C_h_intern(&lf[31],2, C_text("if"));
lf[32]=C_h_intern(&lf[32],11, C_text("##core#cond"));
lf[33]=C_h_intern(&lf[33],13, C_text("scheme#append"));
lf[34]=C_h_intern(&lf[34],7, C_text("boolean"));
lf[35]=C_h_intern(&lf[35],5, C_text("quote"));
lf[36]=C_h_intern(&lf[36],6, C_text("string"));
lf[37]=C_h_intern(&lf[37],7, C_text("keyword"));
lf[38]=C_h_intern(&lf[38],6, C_text("symbol"));
lf[39]=C_h_intern(&lf[39],7, C_text("integer"));
lf[40]=C_h_intern(&lf[40],6, C_text("fixnum"));
lf[41]=C_h_intern(&lf[41],6, C_text("bignum"));
lf[42]=C_h_intern(&lf[42],5, C_text("float"));
lf[43]=C_h_intern(&lf[43],6, C_text("ratnum"));
lf[44]=C_h_intern(&lf[44],7, C_text("cplxnum"));
lf[45]=C_h_intern(&lf[45],4, C_text("null"));
lf[46]=C_h_intern(&lf[46],4, C_text("list"));
lf[47]=C_h_intern(&lf[47],4, C_text("pair"));
lf[48]=C_h_intern(&lf[48],3, C_text("eof"));
lf[49]=C_h_intern(&lf[49],6, C_text("vector"));
lf[50]=C_h_intern(&lf[50],6, C_text("struct"));
lf[51]=C_h_intern(&lf[51],4, C_text("char"));
lf[52]=C_h_intern(&lf[52],38, C_text("chicken.compiler.support#small-bignum\077"));
lf[53]=C_h_intern(&lf[53],36, C_text("chicken.compiler.support#big-fixnum\077"));
lf[54]=C_h_intern(&lf[54],24, C_text("chicken.keyword#keyword\077"));
lf[55]=C_h_intern(&lf[55],3, C_text("let"));
lf[56]=C_h_intern(&lf[56],13, C_text("##core#lambda"));
lf[57]=C_h_intern(&lf[57],20, C_text("##core#direct_lambda"));
lf[58]=C_h_intern(&lf[58],9, C_text("procedure"));
lf[59]=C_h_intern(&lf[59],4, C_text("set!"));
lf[60]=C_h_intern(&lf[60],11, C_text("##core#set!"));
lf[61]=C_h_intern(&lf[61],9, C_text("undefined"));
lf[62]=C_h_intern(&lf[62],16, C_text("##core#primitive"));
lf[63]=C_h_intern(&lf[63],13, C_text("##core#inline"));
lf[64]=C_h_intern(&lf[64],22, C_text("##core#inline_allocate"));
lf[65]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_i_check_closure\376\003\000\000\002\376\001\000\000\011\001procedure\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\017C_i_check_"
"exact\376\003\000\000\002\376\001\000\000\006\001fixnum\376\003\000\000\002\376\001\000\000\006\001bignum\376\003\000\000\002\376\001\000\000\007\001integer\376\003\000\000\002\376\001\000\000\006\001ratnum\376\377\016\376\003\000"
"\000\002\376\003\000\000\002\376B\000\000\021C_i_check_inexact\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_i_check_number\376"
"\003\000\000\002\376\001\000\000\006\001fixnum\376\003\000\000\002\376\001\000\000\007\001integer\376\003\000\000\002\376\001\000\000\006\001bignum\376\003\000\000\002\376\001\000\000\006\001ratnum\376\003\000\000\002\376\001\000\000\005\001f"
"loat\376\003\000\000\002\376\001\000\000\007\001cplxnum\376\003\000\000\002\376\001\000\000\006\001number\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_i_check_string\376\003\000\000\002\376\001"
"\000\000\006\001string\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\024C_i_check_bytevector\376\003\000\000\002\376\001\000\000\004\001blob\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000"
"\020C_i_check_symbol\376\003\000\000\002\376\001\000\000\006\001symbol\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_i_check_keyword\376\003\000\000\002\376\001\000\000\007\001"
"keyword\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\016C_i_check_list\376\003\000\000\002\376\001\000\000\004\001null\376\003\000\000\002\376\001\000\000\004\001pair\376\003\000\000\002\376\001\000\000\004\001"
"list\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\016C_i_check_pair\376\003\000\000\002\376\001\000\000\004\001pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_i_check_l"
"ocative\376\003\000\000\002\376\001\000\000\010\001locative\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_i_check_boolean\376\003\000\000\002\376\001\000\000\007\001boolean\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_i_check_vector\376\003\000\000\002\376\001\000\000\006\001vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\023C_i_check_st"
"ructure\376\003\000\000\002\376\001\000\000\010\001\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\016C_i_check_char\376\003\000\000\002\376\001\000\000\004\001char\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376B\000\000\023C_i_check_closure_2\376\003\000\000\002\376\001\000\000\011\001procedure\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_i_check_ex"
"act_2\376\003\000\000\002\376\001\000\000\006\001fixnum\376\003\000\000\002\376\001\000\000\006\001bignum\376\003\000\000\002\376\001\000\000\007\001integer\376\003\000\000\002\376\001\000\000\006\001ratnum\376\377\016\376\003\000"
"\000\002\376\003\000\000\002\376B\000\000\023C_i_check_inexact_2\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_i_check_numbe"
"r_2\376\003\000\000\002\376\001\000\000\006\001fixnum\376\003\000\000\002\376\001\000\000\007\001integer\376\003\000\000\002\376\001\000\000\006\001bignum\376\003\000\000\002\376\001\000\000\006\001ratnum\376\003\000\000\002\376\001\000"
"\000\005\001float\376\003\000\000\002\376\001\000\000\007\001cplxnum\376\003\000\000\002\376\001\000\000\006\001number\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_i_check_string_2\376"
"\003\000\000\002\376\001\000\000\006\001string\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\026C_i_check_bytevector_2\376\003\000\000\002\376\001\000\000\004\001blob\376\377\016\376\003\000\000\002\376"
"\003\000\000\002\376B\000\000\022C_i_check_symbol_2\376\003\000\000\002\376\001\000\000\006\001symbol\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\023C_i_check_keyword_"
"2\376\003\000\000\002\376\001\000\000\007\001keyword\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_i_check_list_2\376\003\000\000\002\376\001\000\000\004\001null\376\003\000\000\002\376\001\000\000\004\001p"
"air\376\003\000\000\002\376\001\000\000\004\001list\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_i_check_pair_2\376\003\000\000\002\376\001\000\000\004\001pair\376\377\016\376\003\000\000\002\376\003\000\000\002"
"\376B\000\000\024C_i_check_locative_2\376\003\000\000\002\376\001\000\000\010\001locative\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\023C_i_check_boolean_"
"2\376\003\000\000\002\376\001\000\000\007\001boolean\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_i_check_vector_2\376\003\000\000\002\376\001\000\000\006\001vector\376\377\016\376\003\000\000\002"
"\376\003\000\000\002\376B\000\000\025C_i_check_structure_2\376\003\000\000\002\376\001\000\000\010\001\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_i_check_ch"
"ar_2\376\003\000\000\002\376\001\000\000\004\001char\376\377\016\376\377\016"));
lf[66]=C_h_intern(&lf[66],31, C_text("chicken.compiler.support#unsafe"));
lf[67]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_noop"));
lf[68]=C_h_intern(&lf[68],8, C_text("\052struct\052"));
lf[69]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_noop"));
lf[70]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_noop"));
lf[71]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_noop"));
lf[72]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376B\000\000\034C_i_foreign_fixnum_argumentp\376\003\000\000\002\376\001\000\000\006\001fixnum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\035C_"
"i_foreign_integer_argumentp\376\003\000\000\002\376\001\000\000\007\001integer\376\003\000\000\002\376\001\000\000\006\001fixnum\376\003\000\000\002\376\001\000\000\006\001bignum\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\032C_i_foreign_char_argumentp\376\003\000\000\002\376\001\000\000\004\001char\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\034C_i_"
"foreign_flonum_argumentp\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\034C_i_foreign_string_arg"
"umentp\376\003\000\000\002\376\001\000\000\006\001string\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\034C_i_foreign_symbol_argumentp\376\003\000\000\002\376\001\000\000\006\001"
"symbol\376\377\016\376\377\016"));
lf[73]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376B\000\000\014C_i_closurep\376\003\000\000\002\376\001\000\000\011\001procedure\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\011C_fixnump\376\003\000\000\002\376"
"\001\000\000\006\001fixnum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\011C_bignump\376\003\000\000\002\376\001\000\000\006\001bignum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_i_exa"
"ct_integerp\376\003\000\000\002\376\001\000\000\007\001integer\376\003\000\000\002\376\001\000\000\006\001fixnum\376\003\000\000\002\376\001\000\000\006\001bignum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000"
"\013C_i_flonump\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_i_numberp\376\003\000\000\002\376\001\000\000\006\001number\376\003\000\000\002\376"
"\001\000\000\006\001fixnum\376\003\000\000\002\376\001\000\000\007\001integer\376\003\000\000\002\376\001\000\000\006\001bignum\376\003\000\000\002\376\001\000\000\006\001ratnum\376\003\000\000\002\376\001\000\000\005\001float\376"
"\003\000\000\002\376\001\000\000\007\001cplxnum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_i_ratnump\376\003\000\000\002\376\001\000\000\006\001ratnum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000"
"\014C_i_cplxnump\376\003\000\000\002\376\001\000\000\007\001cplxnum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\011C_stringp\376\003\000\000\002\376\001\000\000\006\001string\376\377\016\376\003"
"\000\000\002\376\003\000\000\002\376B\000\000\015C_bytevectorp\376\003\000\000\002\376\001\000\000\004\001blob\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\014C_i_keywordp\376\003\000\000\002\376\001\000\000"
"\007\001keyword\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_i_symbolp\376\003\000\000\002\376\001\000\000\006\001symbol\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\011C_i_lis"
"tp\376\003\000\000\002\376\001\000\000\004\001list\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\011C_i_pairp\376\003\000\000\002\376\001\000\000\004\001pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_l"
"ocativep\376\003\000\000\002\376\001\000\000\010\001locative\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\012C_booleanp\376\003\000\000\002\376\001\000\000\007\001boolean\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376B\000\000\013C_i_vectorp\376\003\000\000\002\376\001\000\000\006\001vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\014C_structurep\376\003\000\000\002\376\001\000\000\006\001"
"struct\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\016C_i_structurep\376\003\000\000\002\376\001\000\000\010\001\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\007C_cha"
"rp\376\003\000\000\002\376\001\000\000\004\001char\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\011C_i_portp\376\003\000\000\002\376\001\000\000\004\001port\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\011C_i"
"_nullp\376\003\000\000\002\376\001\000\000\004\001null\376\377\016\376\377\016"));
lf[74]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_true"));
lf[75]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_true"));
lf[76]=C_decode_literal(C_heaptop,C_text("\376B\000\000\010C_i_true"));
lf[77]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record1\376\003\000\000\002\376\001\000\000\010\001\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record2\376\003"
"\000\000\002\376\001\000\000\010\001\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record3\376\003\000\000\002\376\001\000\000\010\001\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002"
"\376B\000\000\015C_a_i_record4\376\003\000\000\002\376\001\000\000\010\001\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record5\376\003\000\000\002\376\001\000\000\010\001\052"
"struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record6\376\003\000\000\002\376\001\000\000\010\001\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i"
"_record7\376\003\000\000\002\376\001\000\000\010\001\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_record8\376\003\000\000\002\376\001\000\000\010\001\052struct\052\376\377\016"
"\376\003\000\000\002\376\003\000\000\002\376B\000\000\014C_a_i_record\376\003\000\000\002\376\001\000\000\010\001\052struct\052\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\014C_a_i_string\376\003\000\000"
"\002\376\001\000\000\006\001string\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\012C_a_i_port\376\003\000\000\002\376\001\000\000\004\001port\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_"
"vector1\376\003\000\000\002\376\001\000\000\006\001vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_vector2\376\003\000\000\002\376\001\000\000\006\001vector\376\377\016\376\003\000\000\002"
"\376\003\000\000\002\376B\000\000\015C_a_i_vector3\376\003\000\000\002\376\001\000\000\006\001vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_vector4\376\003\000\000\002\376\001\000\000"
"\006\001vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_vector5\376\003\000\000\002\376\001\000\000\006\001vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_"
"vector6\376\003\000\000\002\376\001\000\000\006\001vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_vector7\376\003\000\000\002\376\001\000\000\006\001vector\376\377\016\376\003\000\000\002"
"\376\003\000\000\002\376B\000\000\015C_a_i_vector8\376\003\000\000\002\376\001\000\000\006\001vector\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\010C_a_pair\376\003\000\000\002\376\001\000\000\004\001pai"
"r\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_bytevector\376\003\000\000\002\376\001\000\000\004\001blob\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\023C_a_i_make_l"
"ocative\376\003\000\000\002\376\001\000\000\010\001locative\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\014C_a_i_vector\376\003\000\000\002\376\001\000\000\006\001vector\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376B\000\000\013C_a_i_list1\376\003\000\000\002\376\001\000\000\004\001pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_list2\376\003\000\000\002\376\001\000\000\004\001pai"
"r\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_list3\376\003\000\000\002\376\001\000\000\004\001pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_list4\376\003\000\000\002\376"
"\001\000\000\004\001pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_list5\376\003\000\000\002\376\001\000\000\004\001pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_lis"
"t6\376\003\000\000\002\376\001\000\000\004\001pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C_a_i_list7\376\003\000\000\002\376\001\000\000\004\001pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\013C"
"_a_i_list8\376\003\000\000\002\376\001\000\000\004\001pair\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\012C_a_i_cons\376\003\000\000\002\376\001\000\000\004\001pair\376\377\016\376\003\000\000\002\376\003\000\000"
"\002\376B\000\000\014C_a_i_flonum\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_fix_to_flo\376\003\000\000\002\376\001\000\000\005\001f"
"loat\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_big_to_flo\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_fi"
"x_to_big\376\003\000\000\002\376\001\000\000\006\001bignum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_bignum0\376\003\000\000\002\376\001\000\000\006\001bignum\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376B\000\000\015C_a_i_bignum1\376\003\000\000\002\376\001\000\000\006\001bignum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\015C_a_i_bignum2\376\003\000\000\002\376\001\000"
"\000\006\001bignum\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_flonum_abs\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_a"
"_i_flonum_acos\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000$C_a_i_flonum_actual_quotient_che"
"cked\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_a_i_flonum_asin\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376"
"\003\000\000\002\376B\000\000\022C_a_i_flonum_atan2\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_a_i_flonum_atan\376\003"
"\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\024C_a_i_flonum_ceiling\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000"
"\002\376B\000\000\020C_a_i_flonum_cos\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\027C_a_i_flonum_difference\376"
"\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_flonum_exp\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B"
"\000\000\021C_a_i_flonum_expt\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_a_i_flonum_floor\376\003\000\000\002\376\001\000"
"\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_flonum_gcd\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_"
"i_flonum_log\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\033C_a_i_flonum_modulo_checked\376\003\000\000\002\376\001"
"\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\023C_a_i_flonum_negate\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021"
"C_a_i_flonum_plus\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\035C_a_i_flonum_quotient_checked"
"\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\025C_a_i_flonum_quotient\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376"
"\003\000\000\002\376B\000\000\036C_a_i_flonum_remainder_checked\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_a_i_f"
"lonum_round\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\031C_a_i_flonum_round_proper\376\003\000\000\002\376\001\000\000\005"
"\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_flonum_sin\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\021C_a_i_"
"flonum_sqrt\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\020C_a_i_flonum_tan\376\003\000\000\002\376\001\000\000\005\001float\376\377\016"
"\376\003\000\000\002\376\003\000\000\002\376B\000\000\022C_a_i_flonum_times\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\025C_a_i_flonum_"
"truncate\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\025C_a_u_i_f64vector_ref\376\003\000\000\002\376\001\000\000\005\001float\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376B\000\000\025C_a_u_i_f32vector_ref\376\003\000\000\002\376\001\000\000\005\001float\376\377\016\376\377\016"));
lf[78]=C_h_intern(&lf[78],21, C_text("##sys#standard-output"));
lf[79]=C_h_intern(&lf[79],6, C_text("printf"));
lf[80]=C_h_intern(&lf[80],18, C_text("##sys#write-char-0"));
lf[81]=C_h_intern(&lf[81],11, C_text("##sys#print"));
lf[82]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002:\011"));
lf[83]=C_decode_literal(C_heaptop,C_text("\376B\000\000\002  "));
lf[84]=C_h_intern(&lf[84],18, C_text("chicken.base#print"));
lf[85]=C_decode_literal(C_heaptop,C_text("\376B\000\000\027eliminated type checks:"));
lf[86]=C_h_intern(&lf[86],46, C_text("chicken.compiler.support#with-debugging-output"));
lf[87]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001x\376\003\000\000\002\376\001\000\000\001\001o\376\377\016"));
lf[88]=C_h_intern(&lf[88],38, C_text("chicken.compiler.lfa2#perform-unboxing"));
lf[89]=C_h_intern(&lf[89],34, C_text("chicken.compiler.support#make-node"));
lf[90]=C_h_intern(&lf[90],12, C_text("##core#float"));
lf[91]=C_h_intern(&lf[91],21, C_text("##core#float-variable"));
lf[92]=C_h_intern(&lf[92],18, C_text("##core#unbox_float"));
lf[93]=C_h_intern(&lf[93],2, C_text("op"));
lf[94]=C_h_intern(&lf[94],3, C_text("map"));
lf[95]=C_h_intern(&lf[95],16, C_text("##core#box_float"));
lf[96]=C_h_intern(&lf[96],16, C_text("##core#let_float"));
lf[97]=C_h_intern(&lf[97],4, C_text("pred"));
lf[98]=C_h_intern(&lf[98],3, C_text("acc"));
lf[99]=C_decode_literal(C_heaptop,C_text("\376B\000\0008number of inline operations replaced with unboxed ones: "));
lf[100]=C_decode_literal(C_heaptop,C_text("\376B\000\000#number of unboxed float variables: "));
lf[101]=C_decode_literal(C_heaptop,C_text("\376\003\000\000\002\376\001\000\000\001\001x\376\003\000\000\002\376\001\000\000\001\001o\376\377\016"));
C_register_lf2(lf,102,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1442,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2=av;
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[194] = {
{C_text("f5313:lfa2_2escm"),(void*)f5313},
{C_text("f5371:lfa2_2escm"),(void*)f5371},
{C_text("f5392:lfa2_2escm"),(void*)f5392},
{C_text("f5404:lfa2_2escm"),(void*)f5404},
{C_text("f5411:lfa2_2escm"),(void*)f5411},
{C_text("f_1442:lfa2_2escm"),(void*)f_1442},
{C_text("f_1445:lfa2_2escm"),(void*)f_1445},
{C_text("f_1448:lfa2_2escm"),(void*)f_1448},
{C_text("f_1451:lfa2_2escm"),(void*)f_1451},
{C_text("f_1454:lfa2_2escm"),(void*)f_1454},
{C_text("f_2074:lfa2_2escm"),(void*)f_2074},
{C_text("f_2082:lfa2_2escm"),(void*)f_2082},
{C_text("f_2089:lfa2_2escm"),(void*)f_2089},
{C_text("f_2103:lfa2_2escm"),(void*)f_2103},
{C_text("f_2118:lfa2_2escm"),(void*)f_2118},
{C_text("f_2126:lfa2_2escm"),(void*)f_2126},
{C_text("f_2130:lfa2_2escm"),(void*)f_2130},
{C_text("f_2134:lfa2_2escm"),(void*)f_2134},
{C_text("f_2152:lfa2_2escm"),(void*)f_2152},
{C_text("f_2164:lfa2_2escm"),(void*)f_2164},
{C_text("f_2172:lfa2_2escm"),(void*)f_2172},
{C_text("f_2668:lfa2_2escm"),(void*)f_2668},
{C_text("f_2674:lfa2_2escm"),(void*)f_2674},
{C_text("f_2739:lfa2_2escm"),(void*)f_2739},
{C_text("f_2755:lfa2_2escm"),(void*)f_2755},
{C_text("f_2767:lfa2_2escm"),(void*)f_2767},
{C_text("f_2770:lfa2_2escm"),(void*)f_2770},
{C_text("f_2870:lfa2_2escm"),(void*)f_2870},
{C_text("f_2896:lfa2_2escm"),(void*)f_2896},
{C_text("f_2902:lfa2_2escm"),(void*)f_2902},
{C_text("f_2907:lfa2_2escm"),(void*)f_2907},
{C_text("f_2933:lfa2_2escm"),(void*)f_2933},
{C_text("f_2937:lfa2_2escm"),(void*)f_2937},
{C_text("f_2941:lfa2_2escm"),(void*)f_2941},
{C_text("f_2943:lfa2_2escm"),(void*)f_2943},
{C_text("f_2947:lfa2_2escm"),(void*)f_2947},
{C_text("f_2950:lfa2_2escm"),(void*)f_2950},
{C_text("f_2953:lfa2_2escm"),(void*)f_2953},
{C_text("f_2958:lfa2_2escm"),(void*)f_2958},
{C_text("f_2962:lfa2_2escm"),(void*)f_2962},
{C_text("f_2965:lfa2_2escm"),(void*)f_2965},
{C_text("f_2966:lfa2_2escm"),(void*)f_2966},
{C_text("f_2973:lfa2_2escm"),(void*)f_2973},
{C_text("f_2983:lfa2_2escm"),(void*)f_2983},
{C_text("f_3000:lfa2_2escm"),(void*)f_3000},
{C_text("f_3007:lfa2_2escm"),(void*)f_3007},
{C_text("f_3035:lfa2_2escm"),(void*)f_3035},
{C_text("f_3037:lfa2_2escm"),(void*)f_3037},
{C_text("f_3047:lfa2_2escm"),(void*)f_3047},
{C_text("f_3066:lfa2_2escm"),(void*)f_3066},
{C_text("f_3083:lfa2_2escm"),(void*)f_3083},
{C_text("f_3093:lfa2_2escm"),(void*)f_3093},
{C_text("f_3129:lfa2_2escm"),(void*)f_3129},
{C_text("f_3135:lfa2_2escm"),(void*)f_3135},
{C_text("f_3140:lfa2_2escm"),(void*)f_3140},
{C_text("f_3142:lfa2_2escm"),(void*)f_3142},
{C_text("f_3152:lfa2_2escm"),(void*)f_3152},
{C_text("f_3159:lfa2_2escm"),(void*)f_3159},
{C_text("f_3163:lfa2_2escm"),(void*)f_3163},
{C_text("f_3171:lfa2_2escm"),(void*)f_3171},
{C_text("f_3183:lfa2_2escm"),(void*)f_3183},
{C_text("f_3189:lfa2_2escm"),(void*)f_3189},
{C_text("f_3200:lfa2_2escm"),(void*)f_3200},
{C_text("f_3208:lfa2_2escm"),(void*)f_3208},
{C_text("f_3214:lfa2_2escm"),(void*)f_3214},
{C_text("f_3220:lfa2_2escm"),(void*)f_3220},
{C_text("f_3226:lfa2_2escm"),(void*)f_3226},
{C_text("f_3230:lfa2_2escm"),(void*)f_3230},
{C_text("f_3233:lfa2_2escm"),(void*)f_3233},
{C_text("f_3236:lfa2_2escm"),(void*)f_3236},
{C_text("f_3245:lfa2_2escm"),(void*)f_3245},
{C_text("f_3248:lfa2_2escm"),(void*)f_3248},
{C_text("f_3295:lfa2_2escm"),(void*)f_3295},
{C_text("f_3301:lfa2_2escm"),(void*)f_3301},
{C_text("f_3304:lfa2_2escm"),(void*)f_3304},
{C_text("f_3315:lfa2_2escm"),(void*)f_3315},
{C_text("f_3327:lfa2_2escm"),(void*)f_3327},
{C_text("f_3334:lfa2_2escm"),(void*)f_3334},
{C_text("f_3385:lfa2_2escm"),(void*)f_3385},
{C_text("f_3388:lfa2_2escm"),(void*)f_3388},
{C_text("f_3391:lfa2_2escm"),(void*)f_3391},
{C_text("f_3402:lfa2_2escm"),(void*)f_3402},
{C_text("f_3409:lfa2_2escm"),(void*)f_3409},
{C_text("f_3423:lfa2_2escm"),(void*)f_3423},
{C_text("f_3426:lfa2_2escm"),(void*)f_3426},
{C_text("f_3439:lfa2_2escm"),(void*)f_3439},
{C_text("f_3447:lfa2_2escm"),(void*)f_3447},
{C_text("f_3453:lfa2_2escm"),(void*)f_3453},
{C_text("f_3495:lfa2_2escm"),(void*)f_3495},
{C_text("f_3514:lfa2_2escm"),(void*)f_3514},
{C_text("f_3517:lfa2_2escm"),(void*)f_3517},
{C_text("f_3520:lfa2_2escm"),(void*)f_3520},
{C_text("f_3531:lfa2_2escm"),(void*)f_3531},
{C_text("f_3534:lfa2_2escm"),(void*)f_3534},
{C_text("f_3545:lfa2_2escm"),(void*)f_3545},
{C_text("f_3570:lfa2_2escm"),(void*)f_3570},
{C_text("f_3574:lfa2_2escm"),(void*)f_3574},
{C_text("f_3586:lfa2_2escm"),(void*)f_3586},
{C_text("f_3593:lfa2_2escm"),(void*)f_3593},
{C_text("f_3597:lfa2_2escm"),(void*)f_3597},
{C_text("f_3600:lfa2_2escm"),(void*)f_3600},
{C_text("f_3615:lfa2_2escm"),(void*)f_3615},
{C_text("f_3641:lfa2_2escm"),(void*)f_3641},
{C_text("f_3661:lfa2_2escm"),(void*)f_3661},
{C_text("f_3675:lfa2_2escm"),(void*)f_3675},
{C_text("f_3723:lfa2_2escm"),(void*)f_3723},
{C_text("f_3730:lfa2_2escm"),(void*)f_3730},
{C_text("f_3733:lfa2_2escm"),(void*)f_3733},
{C_text("f_3739:lfa2_2escm"),(void*)f_3739},
{C_text("f_3742:lfa2_2escm"),(void*)f_3742},
{C_text("f_3749:lfa2_2escm"),(void*)f_3749},
{C_text("f_3753:lfa2_2escm"),(void*)f_3753},
{C_text("f_3757:lfa2_2escm"),(void*)f_3757},
{C_text("f_3771:lfa2_2escm"),(void*)f_3771},
{C_text("f_3781:lfa2_2escm"),(void*)f_3781},
{C_text("f_3825:lfa2_2escm"),(void*)f_3825},
{C_text("f_3833:lfa2_2escm"),(void*)f_3833},
{C_text("f_3848:lfa2_2escm"),(void*)f_3848},
{C_text("f_3851:lfa2_2escm"),(void*)f_3851},
{C_text("f_3854:lfa2_2escm"),(void*)f_3854},
{C_text("f_3863:lfa2_2escm"),(void*)f_3863},
{C_text("f_3889:lfa2_2escm"),(void*)f_3889},
{C_text("f_3909:lfa2_2escm"),(void*)f_3909},
{C_text("f_3923:lfa2_2escm"),(void*)f_3923},
{C_text("f_3967:lfa2_2escm"),(void*)f_3967},
{C_text("f_3977:lfa2_2escm"),(void*)f_3977},
{C_text("f_3993:lfa2_2escm"),(void*)f_3993},
{C_text("f_4009:lfa2_2escm"),(void*)f_4009},
{C_text("f_4040:lfa2_2escm"),(void*)f_4040},
{C_text("f_4050:lfa2_2escm"),(void*)f_4050},
{C_text("f_4066:lfa2_2escm"),(void*)f_4066},
{C_text("f_4076:lfa2_2escm"),(void*)f_4076},
{C_text("f_4078:lfa2_2escm"),(void*)f_4078},
{C_text("f_4088:lfa2_2escm"),(void*)f_4088},
{C_text("f_4140:lfa2_2escm"),(void*)f_4140},
{C_text("f_4143:lfa2_2escm"),(void*)f_4143},
{C_text("f_4151:lfa2_2escm"),(void*)f_4151},
{C_text("f_4155:lfa2_2escm"),(void*)f_4155},
{C_text("f_4163:lfa2_2escm"),(void*)f_4163},
{C_text("f_4166:lfa2_2escm"),(void*)f_4166},
{C_text("f_4169:lfa2_2escm"),(void*)f_4169},
{C_text("f_4172:lfa2_2escm"),(void*)f_4172},
{C_text("f_4189:lfa2_2escm"),(void*)f_4189},
{C_text("f_4199:lfa2_2escm"),(void*)f_4199},
{C_text("f_4212:lfa2_2escm"),(void*)f_4212},
{C_text("f_4216:lfa2_2escm"),(void*)f_4216},
{C_text("f_4218:lfa2_2escm"),(void*)f_4218},
{C_text("f_4222:lfa2_2escm"),(void*)f_4222},
{C_text("f_4225:lfa2_2escm"),(void*)f_4225},
{C_text("f_4228:lfa2_2escm"),(void*)f_4228},
{C_text("f_4256:lfa2_2escm"),(void*)f_4256},
{C_text("f_4293:lfa2_2escm"),(void*)f_4293},
{C_text("f_4322:lfa2_2escm"),(void*)f_4322},
{C_text("f_4324:lfa2_2escm"),(void*)f_4324},
{C_text("f_4349:lfa2_2escm"),(void*)f_4349},
{C_text("f_4373:lfa2_2escm"),(void*)f_4373},
{C_text("f_4383:lfa2_2escm"),(void*)f_4383},
{C_text("f_4385:lfa2_2escm"),(void*)f_4385},
{C_text("f_4410:lfa2_2escm"),(void*)f_4410},
{C_text("f_4432:lfa2_2escm"),(void*)f_4432},
{C_text("f_4445:lfa2_2escm"),(void*)f_4445},
{C_text("f_4449:lfa2_2escm"),(void*)f_4449},
{C_text("f_4452:lfa2_2escm"),(void*)f_4452},
{C_text("f_4455:lfa2_2escm"),(void*)f_4455},
{C_text("f_4464:lfa2_2escm"),(void*)f_4464},
{C_text("f_4478:lfa2_2escm"),(void*)f_4478},
{C_text("f_4501:lfa2_2escm"),(void*)f_4501},
{C_text("f_4519:lfa2_2escm"),(void*)f_4519},
{C_text("f_4523:lfa2_2escm"),(void*)f_4523},
{C_text("f_4540:lfa2_2escm"),(void*)f_4540},
{C_text("f_4542:lfa2_2escm"),(void*)f_4542},
{C_text("f_4567:lfa2_2escm"),(void*)f_4567},
{C_text("f_4590:lfa2_2escm"),(void*)f_4590},
{C_text("f_4602:lfa2_2escm"),(void*)f_4602},
{C_text("f_4634:lfa2_2escm"),(void*)f_4634},
{C_text("f_4636:lfa2_2escm"),(void*)f_4636},
{C_text("f_4661:lfa2_2escm"),(void*)f_4661},
{C_text("f_4687:lfa2_2escm"),(void*)f_4687},
{C_text("f_4689:lfa2_2escm"),(void*)f_4689},
{C_text("f_4714:lfa2_2escm"),(void*)f_4714},
{C_text("f_4738:lfa2_2escm"),(void*)f_4738},
{C_text("f_4740:lfa2_2escm"),(void*)f_4740},
{C_text("f_4765:lfa2_2escm"),(void*)f_4765},
{C_text("f_4786:lfa2_2escm"),(void*)f_4786},
{C_text("f_4789:lfa2_2escm"),(void*)f_4789},
{C_text("f_4791:lfa2_2escm"),(void*)f_4791},
{C_text("f_4798:lfa2_2escm"),(void*)f_4798},
{C_text("f_4801:lfa2_2escm"),(void*)f_4801},
{C_text("f_4804:lfa2_2escm"),(void*)f_4804},
{C_text("f_4810:lfa2_2escm"),(void*)f_4810},
{C_text("f_4813:lfa2_2escm"),(void*)f_4813},
{C_text("f_4822:lfa2_2escm"),(void*)f_4822},
{C_text("toplevel:lfa2_2escm"),(void*)C_lfa2_toplevel},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding unexported module binding: chicken.compiler.lfa2#partition 
o|hiding unexported module binding: chicken.compiler.lfa2#span 
o|hiding unexported module binding: chicken.compiler.lfa2#take 
o|hiding unexported module binding: chicken.compiler.lfa2#drop 
o|hiding unexported module binding: chicken.compiler.lfa2#split-at 
o|hiding unexported module binding: chicken.compiler.lfa2#append-map 
o|hiding unexported module binding: chicken.compiler.lfa2#every 
o|hiding unexported module binding: chicken.compiler.lfa2#any 
o|hiding unexported module binding: chicken.compiler.lfa2#cons* 
o|hiding unexported module binding: chicken.compiler.lfa2#concatenate 
o|hiding unexported module binding: chicken.compiler.lfa2#delete 
o|hiding unexported module binding: chicken.compiler.lfa2#first 
o|hiding unexported module binding: chicken.compiler.lfa2#second 
o|hiding unexported module binding: chicken.compiler.lfa2#third 
o|hiding unexported module binding: chicken.compiler.lfa2#fourth 
o|hiding unexported module binding: chicken.compiler.lfa2#fifth 
o|hiding unexported module binding: chicken.compiler.lfa2#delete-duplicates 
o|hiding unexported module binding: chicken.compiler.lfa2#alist-cons 
o|hiding unexported module binding: chicken.compiler.lfa2#filter 
o|hiding unexported module binding: chicken.compiler.lfa2#filter-map 
o|hiding unexported module binding: chicken.compiler.lfa2#remove 
o|hiding unexported module binding: chicken.compiler.lfa2#unzip1 
o|hiding unexported module binding: chicken.compiler.lfa2#last 
o|hiding unexported module binding: chicken.compiler.lfa2#list-index 
o|hiding unexported module binding: chicken.compiler.lfa2#lset-adjoin/eq? 
o|hiding unexported module binding: chicken.compiler.lfa2#lset-difference/eq? 
o|hiding unexported module binding: chicken.compiler.lfa2#lset-union/eq? 
o|hiding unexported module binding: chicken.compiler.lfa2#lset-intersection/eq? 
o|hiding unexported module binding: chicken.compiler.lfa2#list-tabulate 
o|hiding unexported module binding: chicken.compiler.lfa2#lset<=/eq? 
o|hiding unexported module binding: chicken.compiler.lfa2#lset=/eq? 
o|hiding unexported module binding: chicken.compiler.lfa2#length+ 
o|hiding unexported module binding: chicken.compiler.lfa2#find 
o|hiding unexported module binding: chicken.compiler.lfa2#find-tail 
o|hiding unexported module binding: chicken.compiler.lfa2#iota 
o|hiding unexported module binding: chicken.compiler.lfa2#make-list 
o|hiding unexported module binding: chicken.compiler.lfa2#posq 
o|hiding unexported module binding: chicken.compiler.lfa2#posv 
o|hiding unexported module binding: chicken.compiler.lfa2#+type-check-map+ 
o|hiding unexported module binding: chicken.compiler.lfa2#+predicate-map+ 
o|hiding unexported module binding: chicken.compiler.lfa2#+ffi-type-check-map+ 
o|hiding unexported module binding: chicken.compiler.lfa2#+constructor-map+ 
o|hiding unexported module binding: chicken.compiler.lfa2#+unboxed-map+ 
S|applied compiler syntax:
S|  chicken.format#printf		3
S|  scheme#for-each		4
S|  chicken.base#foldl		3
S|  scheme#map		9
S|  chicken.base#foldr		3
o|eliminated procedure checks: 71 
o|specializations:
o|  3 (##sys#check-output-port * * *)
o|  22 (scheme#eqv? * (or eof null fixnum char boolean symbol keyword))
o|  1 (scheme#caar (pair pair *))
o|  3 (scheme#eqv? (or eof null fixnum char boolean symbol keyword) *)
o|  1 (scheme#memq * list)
o|  3 (chicken.base#add1 *)
o|  1 (scheme#eqv? * *)
o|  3 (##sys#check-list (or pair list) *)
o|  28 (scheme#cdr pair)
o|  11 (scheme#car pair)
(o e)|safe calls: 465 
o|safe globals: (chicken.compiler.lfa2#perform-unboxing chicken.compiler.lfa2#perform-secondary-flow-analysis chicken.compiler.lfa2#+unboxed-map+ chicken.compiler.lfa2#+constructor-map+ chicken.compiler.lfa2#+ffi-type-check-map+ chicken.compiler.lfa2#+predicate-map+ chicken.compiler.lfa2#+type-check-map+ chicken.compiler.lfa2#posv chicken.compiler.lfa2#posq chicken.compiler.lfa2#make-list chicken.compiler.lfa2#iota chicken.compiler.lfa2#find-tail chicken.compiler.lfa2#find chicken.compiler.lfa2#length+ chicken.compiler.lfa2#lset=/eq? chicken.compiler.lfa2#lset<=/eq? chicken.compiler.lfa2#list-tabulate chicken.compiler.lfa2#lset-intersection/eq? chicken.compiler.lfa2#lset-union/eq? chicken.compiler.lfa2#lset-difference/eq? chicken.compiler.lfa2#lset-adjoin/eq? chicken.compiler.lfa2#list-index chicken.compiler.lfa2#last chicken.compiler.lfa2#unzip1 chicken.compiler.lfa2#remove chicken.compiler.lfa2#filter-map chicken.compiler.lfa2#filter chicken.compiler.lfa2#alist-cons chicken.compiler.lfa2#delete-duplicates chicken.compiler.lfa2#fifth chicken.compiler.lfa2#fourth chicken.compiler.lfa2#third chicken.compiler.lfa2#second chicken.compiler.lfa2#first chicken.compiler.lfa2#delete chicken.compiler.lfa2#concatenate chicken.compiler.lfa2#cons* chicken.compiler.lfa2#any chicken.compiler.lfa2#every chicken.compiler.lfa2#append-map chicken.compiler.lfa2#split-at chicken.compiler.lfa2#drop chicken.compiler.lfa2#take chicken.compiler.lfa2#span chicken.compiler.lfa2#partition) 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#partition 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#span 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#drop 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#split-at 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#append-map 
o|inlining procedure: k1836 
o|inlining procedure: k1836 
o|inlining procedure: k1867 
o|inlining procedure: k1867 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#cons* 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#concatenate 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#fourth 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#fifth 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#delete-duplicates 
o|inlining procedure: k2084 
o|inlining procedure: k2084 
o|inlining procedure: k2076 
o|inlining procedure: k2076 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#unzip1 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#last 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#list-index 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#lset-adjoin/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#lset-difference/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#lset-union/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#lset-intersection/eq? 
o|inlining procedure: k2475 
o|inlining procedure: k2475 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#lset<=/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#lset=/eq? 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#length+ 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#find 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#find-tail 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#iota 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#make-list 
o|inlining procedure: k2676 
o|inlining procedure: k2676 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#posv 
o|inlining procedure: k2875 
o|contracted procedure: "(lfa2.scm:263) g577578" 
o|inlining procedure: k2875 
o|substituted constant variable: a2908 
o|inlining procedure: k2909 
o|inlining procedure: k2909 
o|inlining procedure: k2924 
o|inlining procedure: k2924 
o|inlining procedure: "(lfa2.scm:274) chicken.compiler.lfa2#first" 
o|inlining procedure: k2968 
o|inlining procedure: k2968 
o|inlining procedure: k2984 
o|inlining procedure: k2984 
o|inlining procedure: k3005 
o|inlining procedure: k3005 
o|inlining procedure: k3017 
o|inlining procedure: k3017 
o|substituted constant variable: a3027 
o|substituted constant variable: a3029 
o|substituted constant variable: a3031 
o|inlining procedure: k3039 
o|inlining procedure: k3039 
o|inlining procedure: "(lfa2.scm:285) chicken.compiler.lfa2#first" 
o|contracted procedure: "(lfa2.scm:325) chicken.compiler.lfa2#remove" 
o|merged explicitly consed rest parameter: rest650653 
o|inlining procedure: k3160 
o|inlining procedure: k3160 
o|inlining procedure: "(lfa2.scm:329) chicken.compiler.lfa2#first" 
o|consed rest parameter at call site: "(lfa2.scm:334) count-floatvar553" 3 
o|consed rest parameter at call site: "(lfa2.scm:335) count-floatvar553" 3 
o|consed rest parameter at call site: "(lfa2.scm:336) count-floatvar553" 3 
o|inlining procedure: k3237 
o|contracted procedure: "(lfa2.scm:348) vartype549" 
o|inlining procedure: k3073 
o|inlining procedure: k3073 
o|inlining procedure: k3085 
o|inlining procedure: k3085 
o|inlining procedure: "(lfa2.scm:348) chicken.compiler.lfa2#first" 
o|inlining procedure: "(lfa2.scm:346) chicken.compiler.lfa2#first" 
o|inlining procedure: "(lfa2.scm:345) chicken.compiler.lfa2#first" 
o|inlining procedure: "(lfa2.scm:344) chicken.compiler.lfa2#first" 
o|inlining procedure: k3237 
o|inlining procedure: k3296 
o|inlining procedure: "(lfa2.scm:356) chicken.compiler.lfa2#third" 
o|inlining procedure: "(lfa2.scm:355) chicken.compiler.lfa2#third" 
o|inlining procedure: "(lfa2.scm:353) chicken.compiler.lfa2#second" 
o|inlining procedure: "(lfa2.scm:352) chicken.compiler.lfa2#second" 
o|inlining procedure: k3296 
o|inlining procedure: "(lfa2.scm:360) chicken.compiler.lfa2#third" 
o|inlining procedure: "(lfa2.scm:359) chicken.compiler.lfa2#second" 
o|inlining procedure: "(lfa2.scm:350) chicken.compiler.lfa2#first" 
o|inlining procedure: k3358 
o|contracted procedure: "(lfa2.scm:361) constant-result543" 
o|inlining procedure: k2744 
o|inlining procedure: k2744 
o|inlining procedure: k2756 
o|inlining procedure: k2756 
o|inlining procedure: k2771 
o|inlining procedure: k2771 
o|inlining procedure: k2783 
o|inlining procedure: k2783 
o|inlining procedure: k2795 
o|inlining procedure: k2795 
o|inlining procedure: k2807 
o|inlining procedure: k2807 
o|inlining procedure: k2819 
o|inlining procedure: k2819 
o|inlining procedure: k2831 
o|inlining procedure: k2831 
o|inlining procedure: k2850 
o|inlining procedure: k2850 
o|inlining procedure: "(lfa2.scm:361) chicken.compiler.lfa2#first" 
o|inlining procedure: k3358 
o|inlining procedure: k3404 
o|inlining procedure: "(lfa2.scm:380) chicken.compiler.lfa2#first" 
o|inlining procedure: k3404 
o|inlining procedure: k3427 
o|inlining procedure: "(lfa2.scm:379) chicken.compiler.lfa2#first" 
o|inlining procedure: k3427 
o|inlining procedure: "(lfa2.scm:373) chicken.compiler.lfa2#second" 
o|inlining procedure: k3471 
o|inlining procedure: k3471 
o|inlining procedure: "(lfa2.scm:364) chicken.compiler.lfa2#first" 
o|inlining procedure: "(lfa2.scm:363) chicken.compiler.lfa2#first" 
o|inlining procedure: k3484 
o|inlining procedure: "(lfa2.scm:387) chicken.compiler.lfa2#first" 
o|inlining procedure: k3484 
o|inlining procedure: "(lfa2.scm:393) chicken.compiler.lfa2#first" 
o|inlining procedure: "(lfa2.scm:392) chicken.compiler.lfa2#first" 
o|inlining procedure: "(lfa2.scm:390) chicken.compiler.lfa2#first" 
o|inlining procedure: k3546 
o|inlining procedure: k3546 
o|inlining procedure: k3575 
o|inlining procedure: k3575 
o|inlining procedure: k3558 
o|inlining procedure: k3598 
o|inlining procedure: k3598 
o|inlining procedure: k3610 
o|inlining procedure: "(lfa2.scm:417) chicken.compiler.lfa2#second" 
o|inlining procedure: "(lfa2.scm:415) chicken.compiler.lfa2#first" 
o|inlining procedure: "(lfa2.scm:415) chicken.compiler.lfa2#second" 
o|inlining procedure: k3610 
o|inlining procedure: k3649 
o|inlining procedure: "(lfa2.scm:414) chicken.compiler.lfa2#second" 
o|inlining procedure: k3649 
o|inlining procedure: "(lfa2.scm:413) chicken.compiler.lfa2#first" 
o|inlining procedure: k3670 
o|inlining procedure: k3670 
o|inlining procedure: "(lfa2.scm:407) chicken.compiler.lfa2#first" 
o|inlining procedure: k3731 
o|inlining procedure: k3731 
o|inlining procedure: "(lfa2.scm:428) chicken.compiler.lfa2#first" 
o|inlining procedure: k3720 
o|inlining procedure: k3720 
o|inlining procedure: k3776 
o|inlining procedure: k3798 
o|inlining procedure: k3813 
o|inlining procedure: k3813 
o|inlining procedure: "(lfa2.scm:446) chicken.compiler.lfa2#first" 
o|inlining procedure: "(lfa2.scm:448) chicken.compiler.lfa2#second" 
o|inlining procedure: "(lfa2.scm:445) chicken.compiler.lfa2#second" 
o|inlining procedure: k3798 
o|inlining procedure: "(lfa2.scm:442) chicken.compiler.lfa2#first" 
o|inlining procedure: k3776 
o|inlining procedure: k3858 
o|inlining procedure: "(lfa2.scm:465) chicken.compiler.lfa2#second" 
o|inlining procedure: "(lfa2.scm:462) chicken.compiler.lfa2#first" 
o|inlining procedure: "(lfa2.scm:463) chicken.compiler.lfa2#second" 
o|inlining procedure: k3858 
o|inlining procedure: k3897 
o|inlining procedure: "(lfa2.scm:461) chicken.compiler.lfa2#second" 
o|inlining procedure: k3897 
o|inlining procedure: "(lfa2.scm:460) chicken.compiler.lfa2#first" 
o|inlining procedure: k3918 
o|inlining procedure: k3918 
o|inlining procedure: "(lfa2.scm:439) chicken.compiler.lfa2#first" 
o|inlining procedure: k3972 
o|inlining procedure: "(lfa2.scm:480) chicken.compiler.lfa2#first" 
o|inlining procedure: k3972 
o|inlining procedure: k3997 
o|inlining procedure: k3997 
o|inlining procedure: "(lfa2.scm:476) chicken.compiler.lfa2#first" 
o|inlining procedure: k3964 
o|inlining procedure: k3964 
o|substituted constant variable: chicken.compiler.lfa2#+constructor-map+ 
o|inlining procedure: "(lfa2.scm:474) chicken.compiler.lfa2#first" 
o|substituted constant variable: chicken.compiler.lfa2#+predicate-map+ 
o|inlining procedure: "(lfa2.scm:437) chicken.compiler.lfa2#first" 
o|substituted constant variable: chicken.compiler.lfa2#+ffi-type-check-map+ 
o|inlining procedure: "(lfa2.scm:426) chicken.compiler.lfa2#first" 
o|substituted constant variable: chicken.compiler.lfa2#+type-check-map+ 
o|inlining procedure: "(lfa2.scm:405) chicken.compiler.lfa2#first" 
o|inlining procedure: k4042 
o|inlining procedure: k4042 
o|inlining procedure: "(lfa2.scm:399) chicken.compiler.lfa2#first" 
o|inlining procedure: k3558 
o|inlining procedure: k4080 
o|inlining procedure: k4080 
o|substituted constant variable: a4104 
o|substituted constant variable: a4106 
o|substituted constant variable: a4108 
o|substituted constant variable: a4110 
o|substituted constant variable: a4115 
o|substituted constant variable: a4117 
o|substituted constant variable: a4122 
o|substituted constant variable: a4124 
o|substituted constant variable: a4126 
o|substituted constant variable: a4128 
o|substituted constant variable: a4133 
o|substituted constant variable: a4135 
o|substituted constant variable: a4137 
o|inlining procedure: k4141 
o|inlining procedure: k4191 
o|contracted procedure: "(lfa2.scm:495) g845852" 
o|propagated global variable: out855858 ##sys#standard-output 
o|substituted constant variable: a4159 
o|substituted constant variable: a4160 
o|propagated global variable: out855858 ##sys#standard-output 
o|inlining procedure: k4191 
o|inlining procedure: k4141 
o|inlining procedure: k4229 
o|inlining procedure: "(lfa2.scm:515) chicken.compiler.lfa2#first" 
o|inlining procedure: k4229 
o|inlining procedure: k4257 
o|inlining procedure: k4257 
o|inlining procedure: "(lfa2.scm:520) chicken.compiler.lfa2#first" 
o|inlining procedure: k4278 
o|inlining procedure: k4326 
o|inlining procedure: k4326 
o|inlining procedure: "(lfa2.scm:528) chicken.compiler.lfa2#third" 
o|inlining procedure: "(lfa2.scm:527) chicken.compiler.lfa2#second" 
o|inlining procedure: k4387 
o|inlining procedure: k4387 
o|inlining procedure: "(lfa2.scm:525) chicken.compiler.lfa2#first" 
o|inlining procedure: k4278 
o|substituted constant variable: a4437 
o|substituted constant variable: a4439 
o|substituted constant variable: a4441 
o|substituted constant variable: a4443 
o|inlining procedure: k4456 
o|inlining procedure: "(lfa2.scm:548) chicken.compiler.lfa2#first" 
o|inlining procedure: k4456 
o|inlining procedure: k4502 
o|inlining procedure: "(lfa2.scm:561) chicken.compiler.lfa2#second" 
o|inlining procedure: k4502 
o|inlining procedure: k4544 
o|inlining procedure: k4544 
o|inlining procedure: "(lfa2.scm:556) chicken.compiler.lfa2#first" 
o|inlining procedure: "(lfa2.scm:555) chicken.compiler.lfa2#first" 
o|inlining procedure: k4575 
o|inlining procedure: k4603 
o|inlining procedure: k4603 
o|substituted constant variable: a4617 
o|inlining procedure: k4638 
o|inlining procedure: k4638 
o|inlining procedure: "(lfa2.scm:567) chicken.compiler.lfa2#third" 
o|inlining procedure: "(lfa2.scm:566) chicken.compiler.lfa2#second" 
o|inlining procedure: k4691 
o|inlining procedure: k4691 
o|inlining procedure: "(lfa2.scm:564) chicken.compiler.lfa2#first" 
o|inlining procedure: k4575 
o|inlining procedure: k4742 
o|inlining procedure: k4742 
o|substituted constant variable: a4777 
o|substituted constant variable: a4779 
o|substituted constant variable: a4781 
o|substituted constant variable: a4783 
o|propagated global variable: out11161122 ##sys#standard-output 
o|substituted constant variable: a4794 
o|substituted constant variable: a4795 
o|propagated global variable: out11191126 ##sys#standard-output 
o|substituted constant variable: a4806 
o|substituted constant variable: a4807 
o|propagated global variable: out11191126 ##sys#standard-output 
o|propagated global variable: out11161122 ##sys#standard-output 
o|inlining procedure: k4824 
o|inlining procedure: k4824 
o|contracted procedure: "(lfa2.scm:502) chicken.compiler.lfa2#filter-map" 
o|inlining procedure: k2131 
o|inlining procedure: k2131 
o|inlining procedure: k2120 
o|inlining procedure: k2120 
o|replaced variables: 484 
o|removed binding forms: 153 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#every 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#any 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#first 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#second 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#third 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#list-tabulate 
o|substituted constant variable: r26774849 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#+type-check-map+ 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#+predicate-map+ 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#+ffi-type-check-map+ 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#+constructor-map+ 
o|substituted constant variable: r30064866 
o|substituted constant variable: r30064866 
o|inlining procedure: k3005 
o|inlining procedure: k3005 
o|substituted constant variable: r30184870 
o|contracted procedure: "(mini-srfi-1.scm:141) chicken.compiler.lfa2#filter" 
o|substituted constant variable: r20774846 
o|substituted constant variable: r30864889 
o|substituted constant variable: r27454950 
o|substituted constant variable: r27574952 
o|substituted constant variable: r27724954 
o|substituted constant variable: r27844956 
o|substituted constant variable: r27964958 
o|substituted constant variable: r28084960 
o|substituted constant variable: r28204962 
o|substituted constant variable: r28324964 
o|substituted constant variable: r28514966 
o|substituted constant variable: r28514967 
o|substituted constant variable: r34284989 
o|substituted constant variable: r34724996 
o|substituted constant variable: r34855007 
o|inlining procedure: k3512 
o|substituted constant variable: r35475029 
o|inlining procedure: k3598 
o|inlining procedure: k3598 
o|substituted constant variable: r36505061 
o|inlining procedure: k3598 
o|inlining procedure: k3598 
o|inlining procedure: k3798 
o|substituted constant variable: r38145089 
o|inlining procedure: k3798 
o|substituted constant variable: r37775112 
o|inlining procedure: k3852 
o|inlining procedure: k3852 
o|substituted constant variable: r38985136 
o|inlining procedure: k3852 
o|inlining procedure: k3852 
o|substituted constant variable: r39985157 
o|substituted constant variable: r35595192 
o|propagated global variable: out855858 ##sys#standard-output 
o|propagated global variable: out11161122 ##sys#standard-output 
o|propagated global variable: out11191126 ##sys#standard-output 
o|substituted constant variable: r48255288 
o|substituted constant variable: r21215292 
o|replaced variables: 111 
o|removed binding forms: 480 
o|inlining procedure: "(lfa2.scm:265) chicken.compiler.lfa2#alist-cons" 
o|inlining procedure: "(lfa2.scm:328) varnode?550" 
o|inlining procedure: "(lfa2.scm:381) chicken.compiler.lfa2#alist-cons" 
o|inlining procedure: "(lfa2.scm:381) chicken.compiler.lfa2#alist-cons" 
o|inlining procedure: "(lfa2.scm:377) varnode?550" 
o|inlining procedure: "(lfa2.scm:376) chicken.compiler.lfa2#alist-cons" 
o|inlining procedure: "(lfa2.scm:391) varnode?550" 
o|inlining procedure: k3622 
o|substituted constant variable: r37995319 
o|substituted constant variable: r37995321 
o|substituted constant variable: r377751125324 
o|substituted constant variable: r377751125326 
o|substituted constant variable: r377751125328 
o|substituted constant variable: r377751125330 
o|inlining procedure: "(lfa2.scm:440) varnode?550" 
o|replaced variables: 14 
o|removed binding forms: 165 
o|removed side-effect free assignment to unused variable: chicken.compiler.lfa2#alist-cons 
o|substituted constant variable: y2365359 
o|substituted constant variable: r30065297 
o|substituted constant variable: r30065299 
o|removed side-effect free assignment to unused variable: varnode?550 
o|substituted constant variable: r36235406 
o|inlining procedure: k3870 
o|replaced variables: 69 
o|removed binding forms: 23 
o|removed conditional forms: 1 
o|substituted constant variable: r38715441 
o|removed binding forms: 77 
o|removed conditional forms: 1 
o|removed binding forms: 1 
o|simplifications: ((if . 13) (##core#call . 298)) 
o|  call simplifications:
o|    scheme#=
o|    ##sys#setslot	6
o|    ##sys#cons	3
o|    scheme#member	3
o|    scheme#memq	2
o|    scheme#string?
o|    scheme#symbol?	5
o|    chicken.base#fixnum?
o|    chicken.base#bignum?
o|    chicken.base#flonum?
o|    chicken.base#ratnum?
o|    chicken.base#cplxnum?
o|    scheme#boolean?
o|    scheme#list?
o|    scheme#eof-object?
o|    scheme#vector?
o|    ##sys#immediate?
o|    ##sys#generic-structure?
o|    scheme#char?
o|    ##sys#list	5
o|    scheme#cadr	22
o|    scheme#caddr	6
o|    scheme#cdar
o|    scheme#+
o|    scheme#set-car!
o|    scheme#assq	5
o|    ##sys#check-list	12
o|    scheme#pair?	20
o|    ##sys#slot	31
o|    scheme#length	2
o|    scheme#list	12
o|    scheme#not	8
o|    scheme#assoc	8
o|    scheme#cons	25
o|    scheme#cdr	4
o|    scheme#set-cdr!
o|    scheme#null?	4
o|    scheme#car	45
o|    scheme#eq?	51
o|    chicken.fixnum#fx+
o|contracted procedure: k2679 
o|contracted procedure: k2698 
o|contracted procedure: k2685 
o|contracted procedure: k2692 
o|contracted procedure: k2872 
o|contracted procedure: k2885 
o|contracted procedure: k20615363 
o|contracted procedure: k2915 
o|contracted procedure: k2918 
o|contracted procedure: k2921 
o|contracted procedure: k2978 
o|contracted procedure: k2994 
o|contracted procedure: k3002 
o|contracted procedure: k3008 
o|contracted procedure: k3014 
o|contracted procedure: k3020 
o|contracted procedure: k3042 
o|contracted procedure: k3052 
o|contracted procedure: k3056 
o|contracted procedure: k3060 
o|contracted procedure: k3148 
o|contracted procedure: k2067 
o|contracted procedure: k2079 
o|contracted procedure: k2097 
o|contracted procedure: k2105 
o|contracted procedure: k3201 
o|contracted procedure: k3154 
o|contracted procedure: k3177 
o|contracted procedure: k3173 
o|contracted procedure: k3194 
o|contracted procedure: k3240 
o|contracted procedure: k3253 
o|contracted procedure: k3070 
o|contracted procedure: k3088 
o|contracted procedure: k3115 
o|contracted procedure: k3105 
o|contracted procedure: k3263 
o|contracted procedure: k3277 
o|contracted procedure: k3273 
o|contracted procedure: k3281 
o|contracted procedure: k3287 
o|contracted procedure: k3290 
o|contracted procedure: k3309 
o|contracted procedure: k3317 
o|contracted procedure: k3321 
o|contracted procedure: k3329 
o|contracted procedure: k3339 
o|contracted procedure: k3343 
o|contracted procedure: k3346 
o|contracted procedure: k3355 
o|contracted procedure: k3361 
o|contracted procedure: k3368 
o|contracted procedure: k2747 
o|contracted procedure: k2759 
o|contracted procedure: k2774 
o|contracted procedure: k2780 
o|contracted procedure: k2786 
o|contracted procedure: k2792 
o|contracted procedure: k2798 
o|contracted procedure: k2804 
o|contracted procedure: k2810 
o|contracted procedure: k2816 
o|contracted procedure: k2822 
o|contracted procedure: k2828 
o|contracted procedure: k2834 
o|contracted procedure: k2863 
o|contracted procedure: k2856 
o|contracted procedure: k2840 
o|contracted procedure: k2847 
o|contracted procedure: k2853 
o|contracted procedure: k3374 
o|contracted procedure: k3377 
o|contracted procedure: k3380 
o|contracted procedure: k3396 
o|contracted procedure: k3410 
o|contracted procedure: k20615381 
o|contracted procedure: k20615388 
o|contracted procedure: k3430 
o|contracted procedure: k3441 
o|contracted procedure: k20615400 
o|contracted procedure: k3462 
o|contracted procedure: k3455 
o|contracted procedure: k3468 
o|contracted procedure: k3474 
o|contracted procedure: k3487 
o|contracted procedure: k3490 
o|contracted procedure: k3497 
o|contracted procedure: k3503 
o|contracted procedure: k3506 
o|contracted procedure: k3509 
o|contracted procedure: k3525 
o|contracted procedure: k3539 
o|contracted procedure: k3549 
o|contracted procedure: k3555 
o|contracted procedure: k3561 
o|contracted procedure: k3564 
o|contracted procedure: k4063 
o|contracted procedure: k3567 
o|contracted procedure: k3581 
o|contracted procedure: k4036 
o|contracted procedure: k3587 
o|contracted procedure: k3707 
o|contracted procedure: k3607 
o|contracted procedure: k3616 
o|contracted procedure: k3628 
o|contracted procedure: k3635 
o|contracted procedure: k3622 
o|contracted procedure: k3643 
o|contracted procedure: k3646 
o|contracted procedure: k3667 
o|contracted procedure: k3652 
o|contracted procedure: k3663 
o|contracted procedure: k3679 
o|contracted procedure: k3690 
o|contracted procedure: k3698 
o|contracted procedure: k3711 
o|contracted procedure: k4032 
o|contracted procedure: k3717 
o|contracted procedure: k3725 
o|contracted procedure: k3759 
o|contracted procedure: k3734 
o|contracted procedure: k4028 
o|contracted procedure: k3765 
o|contracted procedure: k3773 
o|contracted procedure: k3786 
o|contracted procedure: k3794 
o|contracted procedure: k3842 
o|contracted procedure: k3801 
o|contracted procedure: k3807 
o|contracted procedure: k3810 
o|contracted procedure: k3816 
o|inlining procedure: k3798 
o|contracted procedure: k3827 
o|contracted procedure: k3835 
o|inlining procedure: k3798 
o|contracted procedure: k3955 
o|contracted procedure: k3855 
o|contracted procedure: k3864 
o|contracted procedure: k3876 
o|contracted procedure: k3883 
o|contracted procedure: k3870 
o|contracted procedure: k3891 
o|contracted procedure: k3894 
o|contracted procedure: k3915 
o|contracted procedure: k3900 
o|contracted procedure: k3911 
o|contracted procedure: k3927 
o|contracted procedure: k3938 
o|contracted procedure: k3946 
o|contracted procedure: k4024 
o|contracted procedure: k3961 
o|contracted procedure: k4014 
o|contracted procedure: k3969 
o|contracted procedure: k3978 
o|contracted procedure: k3984 
o|contracted procedure: k4011 
o|contracted procedure: k4000 
o|contracted procedure: k4045 
o|contracted procedure: k4055 
o|contracted procedure: k4059 
o|contracted procedure: k4071 
o|contracted procedure: k4083 
o|contracted procedure: k4093 
o|contracted procedure: k4097 
o|contracted procedure: k4144 
o|contracted procedure: k4182 
o|contracted procedure: k4194 
o|contracted procedure: k4204 
o|contracted procedure: k4208 
o|contracted procedure: k4179 
o|contracted procedure: k4232 
o|contracted procedure: k4235 
o|contracted procedure: k4245 
o|contracted procedure: k4251 
o|contracted procedure: k4264 
o|contracted procedure: k4271 
o|contracted procedure: k4275 
o|contracted procedure: k4281 
o|contracted procedure: k4284 
o|contracted procedure: k4419 
o|contracted procedure: k4287 
o|contracted procedure: k4295 
o|contracted procedure: k4298 
o|contracted procedure: k4307 
o|contracted procedure: k4311 
o|contracted procedure: k4357 
o|contracted procedure: k4314 
o|contracted procedure: k4317 
o|contracted procedure: k4329 
o|contracted procedure: k4332 
o|contracted procedure: k4335 
o|contracted procedure: k4343 
o|contracted procedure: k4351 
o|contracted procedure: k4367 
o|contracted procedure: k4375 
o|contracted procedure: k4378 
o|contracted procedure: k4390 
o|contracted procedure: k4393 
o|contracted procedure: k4396 
o|contracted procedure: k4404 
o|contracted procedure: k4412 
o|contracted procedure: k4426 
o|contracted procedure: k4459 
o|contracted procedure: k4472 
o|contracted procedure: k4480 
o|contracted procedure: k4484 
o|contracted procedure: k4490 
o|contracted procedure: k4493 
o|contracted procedure: k4496 
o|contracted procedure: k4509 
o|contracted procedure: k4513 
o|contracted procedure: k4525 
o|contracted procedure: k4532 
o|contracted procedure: k4535 
o|contracted procedure: k4547 
o|contracted procedure: k4550 
o|contracted procedure: k4553 
o|contracted procedure: k4561 
o|contracted procedure: k4569 
o|contracted procedure: k4578 
o|contracted procedure: k4581 
o|contracted procedure: k4723 
o|contracted procedure: k4584 
o|contracted procedure: k4592 
o|contracted procedure: k4595 
o|contracted procedure: k4606 
o|contracted procedure: k4613 
o|contracted procedure: k4619 
o|contracted procedure: k4623 
o|contracted procedure: k4669 
o|contracted procedure: k4626 
o|contracted procedure: k4629 
o|contracted procedure: k4641 
o|contracted procedure: k4644 
o|contracted procedure: k4647 
o|contracted procedure: k4655 
o|contracted procedure: k4663 
o|contracted procedure: k4679 
o|contracted procedure: k4682 
o|contracted procedure: k4694 
o|contracted procedure: k4697 
o|contracted procedure: k4700 
o|contracted procedure: k4708 
o|contracted procedure: k4716 
o|contracted procedure: k4730 
o|contracted procedure: k4733 
o|contracted procedure: k4745 
o|contracted procedure: k4748 
o|contracted procedure: k4751 
o|contracted procedure: k4759 
o|contracted procedure: k4767 
o|contracted procedure: k4818 
o|contracted procedure: k4832 
o|contracted procedure: k4836 
o|contracted procedure: k4827 
o|contracted procedure: k2111 
o|contracted procedure: k2123 
o|contracted procedure: k2146 
o|contracted procedure: k2154 
o|simplifications: ((let . 46)) 
o|removed binding forms: 257 
o|inlining procedure: k3256 
o|inlining procedure: k3256 
o|inlining procedure: k3790 
o|inlining procedure: k3790 
o|inlining procedure: k3790 
o|inlining procedure: k3790 
o|replaced variables: 82 
o|removed binding forms: 1 
o|inlining procedure: k2892 
o|substituted constant variable: r32575615 
o|inlining procedure: k3404 
o|simplifications: ((let . 1)) 
o|removed binding forms: 42 
o|removed conditional forms: 1 
o|contracted procedure: k3417 
o|removed binding forms: 4 
o|replaced variables: 2 
o|removed binding forms: 1 
o|direct leaf routine/allocation: loop477 0 
o|direct leaf routine/allocation: floatvar?551 0 
o|direct leaf routine/allocation: g278279 3 
o|converted assignments to bindings: (loop477) 
o|contracted procedure: "(lfa2.scm:344) k3266" 
o|contracted procedure: "(lfa2.scm:369) k3481" 
o|simplifications: ((let . 1)) 
o|removed binding forms: 2 
o|customizable procedures: (foldr263266 g268269 map-loop10911108 map-loop10651082 g10241025 map-loop10321049 map-loop9911008 map-loop951968 g917918 map-loop924941 chicken.compiler.lfa2#posq for-each-loop844864 g819826 for-each-loop818836 g731738 for-each-loop730742 g804805 k3975 g777778 k3921 k3861 g768769 g753754 k3673 k3613 extinguish!548 k3518 k3451 add-unboxed555 k3400 assigned?545 k3407 k3299 walk557 eliminate-floatvar552 add-boxed554 k3091 loop633 count-floatvar553 k3157 g666667 foldr245248 g250251 report544 g601608 for-each-loop600611 droppable?546 drop!547 sub-boxed556) 
o|calls to known targets: 117 
o|identified direct recursive calls: f_2674 1 
o|identified direct recursive calls: f_2074 1 
o|identified direct recursive calls: f_2118 1 
o|fast box initializations: 27 
o|fast global references: 6 
o|fast global assignments: 2 
o|dropping unused closure argument: f_2668 
*/
/* end of file */
